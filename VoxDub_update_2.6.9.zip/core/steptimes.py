"""
steptimes.py - how long each step of a dub took (2.6.8).

    with steptimes.timed(project, "STT"):
        ...

At the end of a Batch episode (or of Auto Dub) one line goes to the log:

    [time] EP004: separate 17s · STT 22s · OCR 31s · AI check 6s · characters 4s
           · translate 12s · voice 33s · export 2m27s · total 5m32s

so a slow step shows at once (the Test copy writes it to logs\\crash_trace.log).
Times live in memory for the run, keyed by the video, so the export stage
(another worker, the project loaded again) adds to the same line.
"""

import os
import threading
import time
from contextlib import contextmanager
from typing import Dict

ORDER = ("prepare", "separate", "STT", "OCR", "characters", "AI check", "translate",
         "voice", "export")

_lock = threading.Lock()
_runs: Dict[str, Dict[str, float]] = {}


def _key(project) -> str:
    return os.path.normcase(os.path.abspath(getattr(project, "video_path", "") or "?"))


def add(project, step: str, seconds: float) -> None:
    with _lock:
        run = _runs.setdefault(_key(project), {})
        run[step] = run.get(step, 0.0) + max(0.0, seconds)


@contextmanager
def timed(project, step: str):
    t0 = time.monotonic()
    try:
        yield
    finally:
        add(project, step, time.monotonic() - t0)


def fmt(sec: float) -> str:
    sec = int(round(sec))
    return f"{sec // 60}m{sec % 60:02d}s" if sec >= 60 else f"{sec}s"


def line(project, forget: bool = False) -> str:
    """'EP004: separate 17s · STT 22s · … · total 5m32s' ('' when nothing was timed)."""
    with _lock:
        run = dict(_runs.get(_key(project), {}))
        if forget:
            _runs.pop(_key(project), None)
    if not run:
        return ""
    steps = [s for s in ORDER if s in run] + sorted(s for s in run if s not in ORDER)
    parts = [f"{s} {fmt(run[s])}" for s in steps if run[s] >= 0.5]
    name = os.path.splitext(os.path.basename(getattr(project, "video_path", "") or "?"))[0]
    return f"{name}: " + " · ".join(parts + [f"total {fmt(sum(run.values()))}"])


def report(project, forget: bool = False) -> str:
    """Print the line and write it to the crash trace (the Test copy's only log)."""
    text = line(project, forget)
    if text:
        print(f"[time] {text}")
        try:
            from . import crashlog

            crashlog.note(f"[time] {text}")
        except Exception:
            pass
    return text
