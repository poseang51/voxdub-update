"""
ocr_subs.py - Read the subtitles that are burned into the picture (OCR) and
use them to double-check Whisper.

Chinese dramas almost always carry their own Chinese subtitles. Reading them
gives the exact words and names (云霆, 孝顺, 跪 ...) where Whisper hears a
sound-alike (云青, 消失, 贵), and finds lines Whisper missed (shouting, crying,
loud music). RapidOCR (PP-OCR models on onnxruntime, offline, ~15 MB) does the
reading:  pip install rapidocr_onnxruntime

Speed: only the subtitle band is decoded (3 frames a second, small), and a
frame is read only when the text in the band changes - about one OCR call per
subtitle, ~0.2-0.5 s each on a CPU.
"""

import subprocess
import threading
from dataclasses import dataclass
from typing import Callable, List, Optional, Sequence, Tuple

import numpy as np

from .hardsub import text_mask
from .media import no_window, find_ffmpeg, get_media_info
from .project import Segment, new_id

FPS = 3.0
BAND_W = 480                # px, width the band is scaled to
MIN_SCORE = 0.6
OCR_LANGS = ("zh", "en")    # what the bundled PP-OCR model reads

_engine = None
device = "cpu"              # what the OCR runs on ("gpu (DirectML)" when it could)


@dataclass
class SubEvent:
    start: float
    end: float
    text: str
    score: float = 1.0


def available() -> bool:
    try:
        import importlib.util

        return importlib.util.find_spec("rapidocr_onnxruntime") is not None
    except Exception:
        return False


_engine_lock = threading.Lock()


def use_gpu() -> bool:
    """2.4: Settings "ocr_gpu" (default on): read on the graphics card when
    onnxruntime-directml is installed (any DirectX 12 GPU, no CUDA needed)."""
    from . import settings

    return bool(settings.get("ocr_gpu", True))


def _to_gpu(engine) -> str:
    """Put RapidOCR's models on the GPU (DirectML); keeps the CPU on failure."""
    import onnxruntime as ort

    if "DmlExecutionProvider" not in ort.get_available_providers():
        return "cpu"
    done = 0
    for part in ("text_recognizer", "text_detector"):
        holder = getattr(getattr(engine, part, None), "session", None)
        sess = getattr(holder, "session", None)
        path = getattr(sess, "_model_path", None)
        if not path:
            continue
        opt = ort.SessionOptions()
        opt.log_severity_level = 4
        opt.enable_mem_pattern = False                  # (DirectML needs these two)
        opt.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        try:
            holder.session = ort.InferenceSession(
                path, sess_options=opt,
                providers=["DmlExecutionProvider", "CPUExecutionProvider"])
            done += 1
        except Exception as e:
            print(f"[ocr] GPU (DirectML) not used for {part}: {e}")
    return "gpu (DirectML)" if done else "cpu"


def _ocr():
    global _engine, device
    with _engine_lock:          # several videos at once must not load it twice
        if _engine is None:
            from rapidocr_onnxruntime import RapidOCR

            engine = RapidOCR()
            device = "cpu"
            if use_gpu():
                try:
                    device = _to_gpu(engine)
                except Exception as e:
                    print(f"[ocr] GPU not used: {e}")
            print(f"[ocr] reading on: {device}")
            # DirectML cannot run one model from two threads at once (Batch
            # "At once 2": both episodes reading subtitles = access violation,
            # the app closed): on the GPU one reading at a time
            _engine = _OneAtATime(engine) if device != "cpu" else engine
    return _engine


class _OneAtATime:
    """The OCR engine, called by one thread at a time."""

    def __init__(self, engine):
        self.engine = engine

    def __call__(self, *a, **k):
        from .media import GPU_LOCK     # shared with the music separation

        with GPU_LOCK:
            return self.engine(*a, **k)

    def __getattr__(self, name):
        return getattr(self.engine, name)


def band_of(rect: Sequence[float]) -> Tuple[float, float]:
    """Vertical band (top, height as fractions) around the detected subtitle
    line - roomy enough for a second line above it and for small shifts."""
    _x, y, _w, h = rect
    top = max(0.0, y - h * 1.6)
    bottom = min(1.0, y + h * 2.0)
    return top, bottom - top


def _frames(video: str, top: float, height: float, should_stop=None):
    """(t, gray band) at FPS frames a second, streamed from ffmpeg."""
    info = get_media_info(video)
    W, H = max(2, info.width), max(2, info.height)
    ch = max(2, int(H * height) // 2 * 2)
    cy = int(H * top) // 2 * 2
    bh = max(2, int(round(ch * BAND_W / W)) // 2 * 2)
    from . import settings

    # 2.4: Settings "ocr_hwdec": the graphics card decodes the video (off
    # until OCR_SPEED_TEST shows it helps on this PC); ffmpeg falls back to
    # the CPU by itself where it cannot
    hw = ["-hwaccel", "auto"] if settings.get("ocr_hwdec", False) else []
    cmd = [find_ffmpeg(), "-v", "error", *hw, "-i", video,
           "-vf", f"fps={FPS},crop={W}:{ch}:0:{cy},scale={BAND_W}:{bh},format=gray",
           "-f", "rawvideo", "-pix_fmt", "gray", "pipe:1"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            creationflags=no_window())
    size = BAND_W * bh
    k = 0
    try:
        while True:
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            buf = proc.stdout.read(size)
            if len(buf) < size:
                break
            yield k / FPS, np.frombuffer(buf, dtype=np.uint8).reshape(bh, BAND_W)
            k += 1
    finally:
        proc.kill()
        proc.wait()


def _text_lines(gray: np.ndarray) -> List[np.ndarray]:
    """Cut the band into its subtitle lines (rows / columns that hold outlined
    text) and widen each strip with black, so RapidOCR only RECOGNISES it:
    a strip wider than 8x its height skips text detection, which upscales the
    picture and costs ~0.7 s, against ~0.03 s for recognition alone."""
    from .hardsub import _bands

    m = text_mask(gray)
    h, w = m.shape
    out = []
    for a, b in _bands(m.sum(axis=1).astype(float), max(2.0, 0.004 * w), 3):
        lh = b - a + 1
        if lh < 6:
            continue
        pad = max(3, int(lh * 0.35))
        y0, y1 = max(0, a - pad), min(h, b + pad + 1)
        cols = np.flatnonzero(m[a:b + 1].any(axis=0))
        x0, x1 = max(0, cols[0] - lh), min(w, cols[-1] + lh + 1)
        strip = gray[y0:y1, x0:x1]
        sh, sw = strip.shape
        if sh > 48:              # the recogniser works at 48 px: shrink smoothly ourselves
            import cv2

            strip = cv2.resize(strip, (max(8, int(sw * 48 / sh)), 48),
                               interpolation=cv2.INTER_AREA)
            sh, sw = strip.shape
        want = int(sh * 8.6) + 1
        if sw < want:
            left = (want - sw) // 2
            strip = np.pad(strip, ((0, 0), (left, want - sw - left)), constant_values=0)
        out.append(np.ascontiguousarray(strip))
    return out


def _recognise(strips: List[np.ndarray]) -> List[Tuple[str, float]]:
    """(text, score) of each one-line strip.

    2.6.8: the recogniser is called directly, all the lines of a frame in one
    call. The whole RapidOCR call also ran its angle classifier and box
    handling on every strip - 36 ms against 20 ms a strip (EP004: 192 of 193
    strips read the same, one subtitle more was read). Falls back to the
    whole call if this RapidOCR has no text_recognizer."""
    eng = _ocr()
    inner = getattr(eng, "engine", eng)              # (_OneAtATime: the real one)
    rec = getattr(inner, "text_recognizer", None)
    if rec is not None:
        imgs = [np.ascontiguousarray(np.repeat(s[:, :, None], 3, axis=2)) for s in strips]
        try:
            if inner is not eng:                     # on the GPU: one at a time
                from .media import GPU_LOCK

                with GPU_LOCK:
                    res, _ = rec(imgs)
            else:
                res, _ = rec(imgs)
            if len(res) == len(strips):
                return [(str(r[0] or ""), float(r[1] or 0.0)) for r in res]
        except Exception:
            pass                                     # the whole call below
    out = []
    for s in strips:
        try:
            res, _ = eng(s)
        except Exception:
            res = None
        out.append(("".join(r[1] for r in res), min(float(r[2]) for r in res))
                   if res else ("", 0.0))
    return out


def _read(gray: np.ndarray) -> Tuple[str, float]:
    """Text of one band image (lines top to bottom) and its mean confidence."""
    strips = _text_lines(gray)
    if strips and len(strips) <= 3:
        parts, scores = [], []
        for text, score in _recognise(strips):
            text = _trim(text)
            if text and score >= MIN_SCORE * 0.8:
                parts.append(text)
                scores.append(score)
        if parts:
            return _join(parts), sum(scores) / len(scores)
        return "", 0.0
    try:
        res, _ = _ocr()(gray, use_cls=False)      # subtitles are never upside down
    except TypeError:                             # older RapidOCR
        res, _ = _ocr()(gray)
    if not res:
        return "", 0.0
    lines = []
    for box, text, score in res:
        ys = [p[1] for p in box]
        xs = [p[0] for p in box]
        lines.append((sum(ys) / len(ys), min(xs), text.strip(), float(score)))
    lines = [ln for ln in lines if ln[2] and ln[3] >= MIN_SCORE * 0.8]
    if not lines:
        return "", 0.0
    lines.sort(key=lambda ln: (round(ln[0] / 12), ln[1]))
    parts = []
    for _y, _x, text, _s in lines:
        text = text.rstrip("-—")
        if text:
            parts.append(text)
    score = sum(ln[3] for ln in lines) / len(lines)
    return _join(parts), score


def _trim(text: str) -> str:
    """Stray marks read at the edges of a strip ('，你…', '…1,000万→')."""
    keep = "?!？！…"
    text = text.strip()
    while text and not (text[0].isalnum() or text[0] in "\"“《(（"):
        text = text[1:]
    while text and not (text[-1].isalnum() or text[-1] in keep + "\"”》)）"):
        text = text[:-1]
    return text.strip()


def _join(parts: List[str]) -> str:
    out = ""
    for p in parts:
        if out and (out[-1].isascii() and p[:1].isascii()):
            out += " "
        out += p
    return out


def _same(a: np.ndarray, b: np.ndarray) -> bool:
    """Do two text masks show the same subtitle?"""
    na, nb = int(a.sum()), int(b.sum())
    if na == 0 and nb == 0:
        return True
    diff = int(np.logical_xor(a, b).sum())
    return diff <= 0.35 * max(na, nb)


def read_burned_subtitles(video: str, rect: Sequence[float],
                          progress: Optional[Callable[[int, str], None]] = None,
                          should_stop: Optional[Callable[[], bool]] = None) -> List[SubEvent]:
    """Every subtitle shown in the band around `rect` with its on-screen time."""
    top, height = band_of(rect)
    total = max(0.1, get_media_info(video).duration)
    events: List[SubEvent] = []
    run: List[Tuple[float, np.ndarray]] = []
    run_mask = None
    min_px = None

    # 2.4: the OCR runs beside the decoding (it used to stop ffmpeg for every
    # subtitle); results are put together in order afterwards
    from concurrent.futures import ThreadPoolExecutor

    pool = ThreadPoolExecutor(max_workers=1)
    pending: list = []
    found = [0]
    import time as _time

    busy = [0.0, 0]                     # 2.6.8: time spent reading, reads (for the log)
    t_begin = _time.monotonic()

    def ocr_run(t0: float, t1: float, picks: List[np.ndarray]):
        text, score = "", 0.0
        if should_stop and should_stop():
            return t0, t1, "", 0.0
        t_read = _time.monotonic()
        # the middle frame first; a frame in a fade or over a busy background
        # can read badly, so try two more and keep the most confident
        for g in picks:
            busy[1] += 1
            t_, s_ = _read(g)
            if s_ > score:
                text, score = t_, s_
            if score >= 0.7:
                break
        if text and score >= MIN_SCORE:
            found[0] += 1
        busy[0] += _time.monotonic() - t_read
        return t0, t1, text, score

    def close_run():
        if not run:
            return
        t0, t1 = run[0][0], run[-1][0] + 1.0 / FPS
        n = len(run)
        picks = [run[k][1] for k in dict.fromkeys((n // 2, n // 4, (3 * n) // 4))]
        pending.append(pool.submit(ocr_run, t0, t1, picks))
        # do not run far ahead of the OCR (memory)
        while sum(1 for f in pending[-400:] if not f.done()) > 200:
            pending[-200].result()

    try:
        calls = 0
        for t, g in _frames(video, top, height, should_stop):
            m = text_mask(g)
            if min_px is None:
                min_px = max(30, int(m.size * 0.002))
            has_text = int(m.sum()) >= min_px
            if not has_text:
                if run:
                    close_run()
                    calls += 1
                run, run_mask = [], None
            elif run_mask is not None and _same(run_mask, m):
                run.append((t, g))
            else:
                if run:
                    close_run()
                    calls += 1
                run, run_mask = [(t, g)], m
            if progress and int(t * FPS) % 15 == 0:
                progress(int(100 * min(1.0, t / total)),
                         f"Reading burned-in subtitles {_mmss(t)} / {_mmss(total)} "
                         f"({found[0]} found)")
        close_run()
        for f in pending:
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            t0, t1, text, score = f.result()
            if text and score >= MIN_SCORE:
                if events and events[-1].text == text and t0 - events[-1].end <= 0.5:
                    events[-1].end = t1
                else:
                    events.append(SubEvent(round(t0, 3), round(t1, 3), text, round(score, 3)))
    finally:
        pool.shutdown(wait=True, cancel_futures=True)
    msg = (f"[ocr] {_mmss(total)} of video: {calls + 1} pieces, {busy[1]} reads on {device} "
           f"{busy[0]:.0f}s, all {_time.monotonic() - t_begin:.0f}s (the rest is decoding "
           f"the video)")
    print(msg)
    try:
        from . import crashlog

        crashlog.note(msg)
    except Exception:
        pass
    return _drop_static(events, total)


def _drop_static(events: List[SubEvent], total: float) -> List[SubEvent]:
    """A channel name / watermark in the band is not a subtitle: drop text that
    stays on screen for a very long time or covers a large part of the video."""
    from collections import defaultdict

    cover = defaultdict(float)
    for e in events:
        cover[e.text] += e.end - e.start
    bad = {t for t, d in cover.items() if d > max(20.0, 0.3 * total)}
    return [e for e in events if e.text not in bad and e.end - e.start <= 15.0]


def _overlap(a0, a1, b0, b1) -> float:
    return max(0.0, min(a1, b1) - max(a0, b0))


FLICKER = 0.5               # s: a reading this short between two of one subtitle is a misread


def _clean(events: List[SubEvent]) -> List[SubEvent]:
    """Fade-in frames read as '.5.1.需要抵押担保' next to '需要抵押担保':
    keep one, without the junk."""
    out: List[SubEvent] = []
    for e in events:
        if out and e.start - out[-1].end <= 0.5:
            p = out[-1]
            short, long_ = (e, p) if len(e.text) <= len(p.text) else (p, e)
            if short.text and short.text in long_.text:
                extra = long_.text.replace(short.text, "", 1)
                keep = short.text if not any(_cjk(ch) for ch in extra) else long_.text
                p.start, p.end = min(p.start, e.start), max(p.end, e.end)
                p.text, p.score = keep, max(p.score, e.score)
                continue
            if len(out) >= 2 and p.end - p.start <= FLICKER and \
                    e.start - out[-2].end <= 1.0 and _same_line(out[-2].text, e.text):
                # "灭了 | 早就我我们顾回 | 灭了": one subtitle, a frame read wrongly
                # in the middle - it was joined and voiced twice (EP004)
                out.pop()
                p = out[-1]
                p.end = max(p.end, e.end)
                p.score = max(p.score, e.score)
                continue
            if _same_line(p.text, e.text):
                # the same subtitle read twice, once wrongly ("1.400公里" /
                # "1,400公里", "嫌贵…" / "赚责…"): joined it was voiced twice
                # and the long Khmer line slowed the video down. Keep the
                # reading seen longer (more frames agree with it).
                if (e.end - e.start) > (p.end - p.start):
                    p.text = e.text
                p.start, p.end = min(p.start, e.start), max(p.end, e.end)
                p.score = max(p.score, e.score)
                continue
        out.append(e)
    return out


def _same_line(a: str, b: str) -> bool:
    """Two OCR readings of one subtitle (a few letters differ)."""
    x, y = _norm(a), _norm(b)
    if not x or not y:
        return False
    if x == y:
        return True
    if min(len(x), len(y)) < 4 or abs(len(x) - len(y)) > 2:
        return False
    from difflib import SequenceMatcher
    return SequenceMatcher(None, x, y).ratio() >= 0.7


def _cjk(ch: str) -> bool:
    return "\u3400" <= ch <= "\u9fff" or "\uac00" <= ch <= "\ud7af" or "\u3040" <= ch <= "\u30ff"


def merge_with_segments(segments: List[Segment], events: List[SubEvent]
                        ) -> Tuple[List[Segment], int, int]:
    """Whisper gives the timing, the burned-in subtitles the words.

    A Whisper line and a subtitle that clearly overlap (by half of the shorter
    one) belong together. Groups are joined: one Whisper line showing as two
    subtitles gets both texts; two Whisper lines inside one subtitle become one
    line (no word is voiced twice). A subtitle with no Whisper line is added.
    Returns (segments, corrected, added)."""
    events = _clean(sorted(events, key=lambda e: e.start))
    segs = sorted(segments, key=lambda s: s.start)
    n = len(segs)
    parent = list(range(n + len(events)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i, e in enumerate(events):
        for j, s in enumerate(segs):
            if s.end < e.start - 1.0:
                continue
            if s.start > e.end + 1.0:
                break
            ov = _overlap(s.start, s.end, e.start, e.end)
            short = min(s.end - s.start, e.end - e.start)
            if short > 0 and ov >= 0.5 * short:
                parent[find(n + i)] = find(j)
    groups = {}
    for k in range(n + len(events)):
        groups.setdefault(find(k), []).append(k)

    out: List[Segment] = []
    fixed_ids = set()                       # lines whose words come from the screen
    corrected = added = 0
    for members in groups.values():
        ss = [segs[k] for k in sorted(members) if k < n]
        ee = [events[k - n] for k in sorted(members) if k >= n]
        if not ee:
            out.extend(ss)
            continue
        ee.sort(key=lambda e: e.start)
        sep = "，" if any(not e.text.isascii() for e in ee) else " "
        text = sep.join(e.text for e in ee)
        if not ss:
            seg = Segment(id=new_id(), start=ee[0].start, end=ee[-1].end, text=text)
            out.append(seg)
            fixed_ids.add(seg.id)
            added += 1
            continue
        ss.sort(key=lambda s: s.start)
        first = ss[0]
        changed = len(ss) > 1 or _norm(text) != _norm(first.text)
        first.start = min(s.start for s in ss)
        first.end = max(s.end for s in ss)
        if first.start < ee[0].start - SNAP_EARLY:
            # Whisper's line began long before its subtitle shows (EP004: the
            # music intro at 0.16 s, "骗谁呢" on the screen at 5.0 s; whole-
            # second guesses "9.16" for 10.0): the voice started too early and
            # ran ahead of the subtitles. The subtitle tells when it is said.
            first.start = max(first.start, ee[0].start - SNAP_LEAD)
            first.end = max(first.end, first.start + 0.3)
        if changed:
            first.text = text
            first.translation, first.tts_path, first.tts_text = "", "", ""
            corrected += 1
        out.append(first)
        fixed_ids.add(first.id)
    out.sort(key=lambda s: s.start)
    # a Whisper-only line that is just a piece of its neighbour's subtitle
    # (Whisper split '桂香 | 好样的' differently): drop it, or it is voiced twice
    keep: List[Segment] = []
    for k, s in enumerate(out):
        if s.id not in fixed_ids and _echo(s, k, out, fixed_ids, events):
            corrected += 1
            continue
        keep.append(s)
    out = keep
    if len(events) >= 10:          # the film shows its subtitles: Smart Review
        for s in out:
            # not confirmed: "nosub"; and Whisper was not sure either: "nosub_unsure"
            s.check = "" if s.id in fixed_ids else (
                "nosub_unsure" if s.check in ("unsure", "nosub_unsure") else "nosub")
    for a, b in zip(out, out[1:]):
        if a.end > b.start:
            a.end = max(a.start + 0.2, b.start)
    return out, corrected, added


SNAP_EARLY = 0.5            # s: a line starting this much before its subtitle ...
SNAP_LEAD = 0.15            # ... starts this much before it (subtitles are read 3 x a second)
ECHO_GAP = 5.0              # s: a confirmed line this close
ECHO_MAX = 5                # letters: only a short line can be an echo
NOISE_CHARS = set("嗯啊呃哦噢哎唉嘿哼呀喔欸诶哇")


def _echo(s: Segment, k: int, out: List[Segment], fixed_ids: set, events) -> bool:
    """A line no subtitle confirms that only repeats a piece of a confirmed
    line next to it ('桂香 | 好样的' split differently; "的使者？" before
    "我是太阳的使者"; "焦炭就。" before "…劈成焦炭就跟上"), or a short
    grunt with words around it ("面嗯我下，") where the film shows no subtitle:
    noise heard as speech. It would be voiced twice / voiced as nonsense."""
    core = _norm(s.text)
    if not core:
        return False
    for j in (k - 1, k + 1):                      # the old rule: right next to it
        if 0 <= j < len(out) and out[j].id in fixed_ids and core in _norm(out[j].text) \
                and min(abs(out[j].start - s.end), abs(s.start - out[j].end)) <= 0.6:
            return True
    if len(core) > ECHO_MAX:
        return False
    for o in out:
        if o is s or o.id not in fixed_ids or len(_norm(o.text)) <= len(core):
            continue
        gap = max(o.start - s.end, s.start - o.end, 0.0)
        if gap <= ECHO_GAP and core in _norm(o.text):
            return True
    if len(events) >= 10 and any(c in NOISE_CHARS for c in s.text):
        shown = any(e.start - 0.3 <= s.end and s.start <= e.end + 0.3 for e in events)
        if not shown:
            return True
    return False


def _norm(t: str) -> str:
    return "".join(ch for ch in t if ch.isalnum()).lower()


def _mmss(t: float) -> str:
    t = int(t)
    return f"{t // 60}:{t % 60:02d}" if t < 3600 else f"{t // 3600}:{t % 3600 // 60:02d}:{t % 60:02d}"
