"""
funasr_worker.py - speech-to-text with FunASR (Alibaba, MIT) for SARIKA VOXDUB PRO.

Runs with the VoxCPM Python (venv-voxcpm already has torch + funasr +
modelscope). The app starts it once per transcription:

    python -u funasr_worker.py            (one JSON request on stdin)
    -> {"wav": "C:/.../audio.wav", "model": "paraformer" | "sensevoice",
        "device": "auto" | "cuda" | "cpu", "start_at": 0.0}

and reads one JSON object per line from stdout:

    {"p": 40, "msg": "..."}                     progress
    {"seg": {"start": 1.2, "end": 3.4, "text": "...", "lang": "zh"}}
    {"ok": true, "lang": "zh", "device": "cuda", "count": 120}   at the end
    {"ok": false, "error": "..."}

paraformer: Paraformer-zh + fsmn-vad + ct-punc (Mandarin, sentence times).
sensevoice: fsmn-vad cuts the speech, SenseVoice-Small reads every part
            (zh / yue / en / ja / ko).
The models download from ModelScope the first time (about 1 GB), then cached.
"""

import json
import os
import re
import sys
import traceback

# this file sits in the app's core/ folder: keep that folder off the path
_HERE = os.path.normcase(os.path.dirname(os.path.abspath(__file__)))
sys.path[:] = [p for p in sys.path
               if os.path.normcase(os.path.abspath(p or os.getcwd())) != _HERE]

SR = 16000
MAX_PART_MS = 6000           # SenseVoice: one subtitle line is at most ~6 s
                             # (12 s put 4-5 sentences of 2 people in one line)
TAG = re.compile(r"<\|[^|]*\|>")
LANGS = {"zh", "yue", "en", "ja", "ko"}


def say(obj) -> None:
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _device(want: str) -> str:
    if want in ("cpu", "cuda"):
        return want
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"


def _load_audio(path: str):
    import numpy as np
    import soundfile as sf

    data, sr = sf.read(path, dtype="float32", always_2d=True)
    data = data.mean(axis=1)
    if sr != SR:
        n = int(len(data) * SR / sr)
        data = np.interp(np.linspace(0, len(data), n, endpoint=False),
                         np.arange(len(data)), data).astype("float32")
    return data


CJK = "\u3000-\u303f\u3400-\u9fff\uff00-\uffef"


def _clean(text: str) -> str:
    t = re.sub(r"\s+", " ", TAG.sub("", text or "")).strip()
    return re.sub(f"(?<=[{CJK}]) (?=[{CJK}])", "", t)      # 你 好 -> 你好


_MODELS = {}                # (name, device) -> model: kept while the worker serves (2.6.8)


def _model(name, dev, make):
    key = (name, dev)
    if key not in _MODELS:
        _MODELS[key] = make()
    return _MODELS[key]


def run_paraformer(req, dev):
    from funasr import AutoModel

    if ("paraformer", dev) not in _MODELS:
        say({"p": 5, "msg": "Loading Paraformer-zh (first time downloads ~1 GB)..."})
    model = _model("paraformer", dev, lambda: AutoModel(
        model="paraformer-zh", vad_model="fsmn-vad", punc_model="ct-punc",
        vad_kwargs={"max_single_segment_time": 20000},
        device=dev, disable_update=True, disable_pbar=True, log_level="ERROR"))
    say({"p": 20, "msg": f"Paraformer-zh reading the speech on {dev}..."})
    res = model.generate(input=req["wav"], batch_size_s=300, sentence_timestamp=True)
    count = 0
    start_at = float(req.get("start_at") or 0.0)
    for item in res or []:
        for s in item.get("sentence_info") or []:
            for text, a, b in split_sentence(_clean(s.get("text", "")),
                                             s.get("timestamp") or [],
                                             float(s.get("start", 0)), float(s.get("end", 0))):
                if not has_words(text) or b <= start_at or b - a < 0.15:
                    continue
                say({"seg": {"start": round(a, 3), "end": round(b, 3), "text": text,
                             "lang": "zh"}})
                count += 1
    return "zh", count


GAP_MS = 700                 # a pause this long inside a "sentence" starts a new line
PUNCT = set("，。？！、；：,.?!;:…“”\"'‘’（）()《》-— ")


def split_sentence(text, stamps, start_ms, end_ms):
    """One Paraformer sentence -> subtitle lines [(text, start_s, end_s)].
    The sentence times can stretch over a long music pause ("烛灭即退" shown
    for 20 s): the times of the characters cut it at every pause."""
    units = [i for i, ch in enumerate(text) if ch not in PUNCT]
    ok = stamps and len(units) == len(stamps) and all(len(t) == 2 for t in stamps)
    if not ok:
        return [(text, start_ms / 1000.0, end_ms / 1000.0)] if text else []
    lines, first = [], 0
    for k in range(1, len(stamps) + 1):
        if k == len(stamps) or stamps[k][0] - stamps[k - 1][1] > GAP_MS:
            a_i = units[first]
            b_i = units[k] if k < len(stamps) else len(text)
            piece = text[a_i:b_i].strip()
            if k < len(stamps):                 # punctuation before the pause stays here
                piece = piece.rstrip()
            lines.append((piece, stamps[first][0] / 1000.0, stamps[k - 1][1] / 1000.0))
            first = k
    return [l for l in lines if l[0]]


def run_sensevoice(req, dev):
    from funasr import AutoModel

    if ("sensevoice", dev) not in _MODELS:
        say({"p": 5, "msg": "Loading SenseVoice-Small (first time downloads ~1 GB)..."})
    vad, asr = _model("sensevoice", dev, lambda: (
        AutoModel(model="fsmn-vad", max_single_segment_time=MAX_PART_MS,
                  device=dev, disable_update=True, disable_pbar=True, log_level="ERROR"),
        AutoModel(model="iic/SenseVoiceSmall", device=dev, disable_update=True,
                  disable_pbar=True, log_level="ERROR")))
    audio = _load_audio(req["wav"])
    say({"p": 15, "msg": f"Finding speech on {dev}..."})
    parts = []
    for item in vad.generate(input=audio) or []:
        parts += [p for p in item.get("value") or [] if len(p) == 2]
    start_at = float(req.get("start_at") or 0.0)
    parts = [(a, b) for a, b in parts if b / 1000.0 > start_at]
    langs = {}
    count = 0
    found = []
    for k, (a, b) in enumerate(parts):
        piece = audio[int(a * SR / 1000):int(b * SR / 1000)]
        if len(piece) < SR // 5:
            continue
        out = asr.generate(input=piece, language=req.get("language") or "auto",
                           use_itn=True, batch_size=1)
        raw = (out[0].get("text", "") if out else "")
        m = re.search(r"<\|(zh|yue|en|ja|ko)\|>", raw)
        lang = m.group(1) if m else ""
        text = _clean(raw)
        if has_words(text):
            if lang:
                langs[lang] = langs.get(lang, 0) + 1
            found.append((a, b, text, lang))
        if k % 5 == 0:
            say({"p": 15 + int(85 * (k + 1) / max(1, len(parts))),
                 "msg": f"SenseVoice: {k + 1} / {len(parts)} parts"})
    best = max(langs, key=langs.get) if langs else "zh"
    for a, b, text, lang in found:
        # music / a shout heard as "Yes。" "Okay。" "う。" in a Chinese film: drop it
        if lang and lang != best and not (best in ("zh", "yue") and lang in ("zh", "yue")):
            continue
        say({"seg": {"start": round(a / 1000.0, 3), "end": round(b / 1000.0, 3),
                     "text": text, "lang": lang}})
        count += 1
    return ("zh" if best == "yue" else best), count


WORD = re.compile(r"[^\W_]", re.UNICODE)


def has_words(text: str) -> bool:
    """Not only punctuation ("，" alone came back as a line)."""
    return bool(WORD.search(text or ""))


def handle(req) -> bool:
    try:
        dev = _device(req.get("device", "auto"))
        if req.get("model") == "sensevoice":
            lang, count = run_sensevoice(req, dev)
        else:
            lang, count = run_paraformer(req, dev)
        say({"ok": True, "lang": lang, "device": dev, "count": count})
        return True
    except Exception as e:
        traceback.print_exc(file=sys.stderr)
        say({"ok": False, "error": f"{type(e).__name__}: {e}"[:400]})
        return False


def main() -> int:
    if "--serve" not in sys.argv:              # one request, then exit (as before)
        return 0 if handle(json.loads(sys.stdin.readline() or "{}")) else 1
    # 2.6.8 --serve: one request per line, the models stay loaded between them
    # (a Batch no longer loads Paraformer again for every episode). The app
    # closes stdin (or ends the process) when it is idle or quits.
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            say({"ok": False, "error": "bad request"})
            continue
        handle(req)
    return 0


if __name__ == "__main__":
    sys.exit(main())
