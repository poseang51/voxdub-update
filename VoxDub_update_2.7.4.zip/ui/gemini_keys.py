"""
gemini_keys.py - 2.6.14: the Gemini keys at work, live.

  * GeminiKeysPanel  - one card per key: Ready / Translating / Resting (limit
    per minute) / Used up today / Refused, the lines it translated today, and
    the totals on top (keys ready, translating now, lines today, need attention).
  * GeminiKeysDialog - Router (ui/gemini_router.py) and Keys tabs in their own
    window (Batch 🔑, Settings › Gemini), with Get a free key, Test keys and
    "Remove refused keys".
  * KeysChip         - the small button in the Batch top bar ("🔑 9/15 ready").

Only masked keys (••••••••wxyz) are ever shown.
"""

import threading
import time

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import (QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QMessageBox, QPushButton, QScrollArea, QVBoxLayout, QWidget)

from core import gemini
from core.i18n import tr

COLOR = {gemini.READY: "#3ddc97", gemini.BUSY: "#4cc9f0", gemini.RESTING: "#f4b740",
         gemini.SPENT: "#f4b740", gemini.REFUSED: "#ff6b6b"}

STYLE = """
QWidget#KeysPanel, QScrollArea#KeysScroll, QWidget#KeysGrid { background: transparent; }
QLabel#KeysTitle { font-size: 15pt; font-weight: 800; color: #ffffff; }
QLabel#KeysSub { color: #8b949e; }
QLabel#KeysChip { background: #1a1f26; border: 1px solid #2b3440; border-radius: 13px;
                  padding: 4px 12px; color: #c9d1d9; font-weight: 600; }
QLabel#KeysChip[tone="busy"] { border-color: #1f5f78; color: #8fdcf5; }
QLabel#KeysChip[tone="ok"] { border-color: #1f5a3c; color: #6ee7a8; }
QLabel#KeysChip[tone="warn"] { border-color: #6b3a3a; color: #ff9c9c; }
QFrame#KeyCard { background: #161b22; border: 1px solid #262d36; border-radius: 10px; }
QFrame#KeyCard[state="busy"] { border: 1px solid #4cc9f0; background: #12212b; }
QFrame#KeyCard[state="refused"] { border: 1px solid #7a3434; background: #221516; }
QFrame#KeyCard[state="spent"], QFrame#KeyCard[state="resting"] { border-color: #5c4a1e; }
QLabel#KeyName { color: #ffffff; font-weight: 700; font-family: Consolas, monospace; }
QLabel#KeyState { color: #8b949e; font-size: 9pt; }
QLabel#KeyLines { color: #c9d1d9; font-weight: 700; }
"""


def _summary(rows):
    n = len(rows)
    ready = sum(r["state"] in (gemini.READY, gemini.BUSY) for r in rows)
    busy = sum(r["state"] == gemini.BUSY for r in rows)
    lines = sum(r["lines"] for r in rows)
    bad = sum(r["state"] == gemini.REFUSED for r in rows)
    spent = sum(r["state"] == gemini.SPENT for r in rows)
    return n, ready, busy, lines, bad, spent


def state_text(r, now=None) -> str:
    now = now or time.time()
    s = r["state"]
    if s == gemini.READY:
        return "Ready" + (f" · {r['models_left']}/{r['models']} models"
                          if r.get("models", 1) > 1 else "")
    if s == gemini.BUSY:
        return "Translating…"
    if s == gemini.RESTING:
        return f"Resting – limit per minute ({max(1, int(r['until'] - now))} s)"
    if s == gemini.SPENT:
        return ("Used up today" if r.get("models", 1) == 1 else "Every model used up") + \
            " – free again " + time.strftime("%H:%M", time.localtime(r["until"]))
    return "Refused – replace this key"


class _Card(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("KeyCard")
        self.setMinimumWidth(220)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 9, 12, 9)
        self.dot = QLabel("●")
        self.dot.setFixedWidth(16)
        mid = QVBoxLayout()
        mid.setSpacing(1)
        self.name = QLabel()
        self.name.setObjectName("KeyName")
        self.state = QLabel()
        self.state.setObjectName("KeyState")
        mid.addWidget(self.name)
        mid.addWidget(self.state)
        self.lines = QLabel()
        self.lines.setObjectName("KeyLines")
        self.lines.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(self.dot)
        lay.addLayout(mid, 1)
        lay.addWidget(self.lines)

    def show_row(self, i, r, now):
        self.dot.setStyleSheet(f"color: {COLOR[r['state']]}; font-size: 13pt;")
        self.name.setText(f"Key {i + 1}   {r['mask']}")
        self.state.setText(state_text(r, now))
        self.lines.setText(f"{r['lines']:,}\nlines" if r["lines"] else "–")
        self.setToolTip(r["why"][:300] if r["why"] else "")
        if self.property("state") != r["state"]:
            self.setProperty("state", r["state"])
            self.style().unpolish(self)
            self.style().polish(self)


class GeminiKeysPanel(QWidget):
    """Live: refreshes itself every second while it is shown."""

    COLS = 3

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("KeysPanel")
        self.setStyleSheet(STYLE)
        title = QLabel("Gemini keys")
        title.setObjectName("KeysTitle")
        sub = QLabel("Khmer subtitles go round your keys. A key that reached its limit "
                     "rests and the next one carries on; a refused key is taken out.")
        sub.setObjectName("KeysSub")
        sub.setWordWrap(True)
        self.chips = {}
        chip_row = QHBoxLayout()
        chip_row.setSpacing(8)
        for k in ("keys", "busy", "lines", "bad"):
            c = QLabel()
            c.setObjectName("KeysChip")
            self.chips[k] = c
            chip_row.addWidget(c)
        chip_row.addStretch(1)
        self.grid_box = QWidget()
        self.grid_box.setObjectName("KeysGrid")
        self.grid = QGridLayout(self.grid_box)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(8)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setObjectName("KeysScroll")
        scroll.viewport().setAutoFillBackground(False)
        scroll.setWidget(self.grid_box)
        self.empty = QLabel("No Gemini key yet – add one in Settings › AI engines & API keys.")
        self.empty.setObjectName("KeysSub")
        self.hint = QLabel()
        self.hint.setObjectName("KeysSub")
        self.hint.setWordWrap(True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(title)
        lay.addWidget(sub)
        lay.addSpacing(4)
        lay.addLayout(chip_row)
        lay.addWidget(scroll, 1)
        lay.addWidget(self.empty)
        lay.addWidget(self.hint)
        self.cards = []
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(1000)
        self.refresh()

    def _chip(self, k, text, tone=""):
        c = self.chips[k]
        c.setText(text)
        if c.property("tone") != tone:
            c.setProperty("tone", tone)
            c.style().unpolish(c)
            c.style().polish(c)

    def refresh(self):
        if not self.isVisible() and self.cards:
            return
        rows = gemini.status(gemini.view_models())
        now = time.time()
        while len(self.cards) < len(rows):
            card = _Card()
            i = len(self.cards)
            self.grid.addWidget(card, i // self.COLS, i % self.COLS)
            self.cards.append(card)
        while len(self.cards) > len(rows):
            card = self.cards.pop()
            self.grid.removeWidget(card)
            card.deleteLater()
        for i, (card, r) in enumerate(zip(self.cards, rows)):
            card.show_row(i, r, now)
        n, ready, busy, lines, bad, spent = _summary(rows)
        self._chip("keys", f"🔑 {n} keys · {ready} ready", "ok" if ready else "warn")
        self._chip("busy", f"⟳ {busy} translating now", "busy" if busy else "")
        self._chip("lines", f"✓ {lines:,} lines today")
        self._chip("bad", f"⚠ {bad + spent} need attention", "warn" if bad + spent else "")
        self.empty.setVisible(not rows)
        hint = []
        if bad:
            hint.append(f"{bad} key(s) refused by Google (deleted, wrong or blocked) – they "
                        "are not used any more. Remove them and add new keys; “Test keys” "
                        "checks them again.")
        if spent:
            hint.append(f"{spent} key(s) used today's free quota – they work again after "
                        "Google's daily reset (shown on the card).")
        if rows and not ready:
            hint.append("No key can translate now: Google Translate (free) finishes the "
                        "lines by itself – the work does not stop.")
        from core.i18n import tr
        self.hint.setText("\n".join(tr(h) for h in hint))
        self.hint.setVisible(bool(hint))
        self.counts = (n, ready, busy, lines, bad, spent)


class _Tester(QObject):
    done = Signal(object)


class GeminiKeysDialog(QDialog):
    _open = None

    @classmethod
    def show_for(cls, parent=None):
        if cls._open is None:
            cls._open = cls(parent)
        cls._open.show()
        cls._open.raise_()
        cls._open.activateWindow()
        return cls._open

    def __init__(self, parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QTabWidget

        self.setWindowTitle("Gemini Router")
        self.resize(1300, 900)            # 2.7.2: the Live traffic page
        self.setStyleSheet("QDialog { background: #0d1117; } "
                           "QTabWidget::pane { border: 1px solid #262d36; border-radius: 8px; "
                           "background: #0d1117; top: -1px; } "
                           "QTabWidget > QWidget > QWidget { background: #0d1117; }")
        self.panel = GeminiKeysPanel(self)
        self.tabs = QTabWidget()
        from ui.router_hub import RouterHub

        # 2.7.2 (20/11): the Router as one live page (first)
        self.router = RouterHub(self, test_keys=self.test_keys, add_key=self.free_key,
                                show_keys=lambda: self.tabs.setCurrentWidget(self.panel))
        # (20/11: "Live traffic" taken out - its live feed and numbers are on
        # the Router page now; one page to watch)
        self.tabs.addTab(self.router, "🔀  Router")
        self.tabs.addTab(self.panel, "🔑  Keys")
        try:                # 2.7.3: Admin + customers with the Gemini web add-on
            from core import gemini_web

            self.web = GeminiWebPanel()
            self.tabs.addTab(self.web, "🌐  Gemini web" + (" (Admin)" if gemini_web.is_admin()
                                                         else ""))
        except Exception as e:
            print(f"[gemini-web] panel not shown: {e}")
        self.b_free = QPushButton("✨ Get a free key…")
        self.b_free.setToolTip("Make a free key in Google AI Studio – copied keys are saved "
                               "by themselves")
        self.b_free.clicked.connect(self.free_key)
        self.b_test = QPushButton("Test keys")
        self.b_test.setObjectName("AccentButton")
        self.b_test.setToolTip("Ask Google with every key (a refused key that works again "
                               "is put back in the queue)")
        self.b_test.clicked.connect(self.test_keys)
        self.b_drop = QPushButton("Remove refused keys")
        self.b_drop.clicked.connect(self.drop_refused)
        self.lb = QLabel()
        self.lb.setObjectName("MutedLabel")
        close = QPushButton("Close")
        close.clicked.connect(self.close)
        # 2.7.2 (20/11): "+ Add key" and "Test keys" are on the Router page
        self.b_free.setVisible(False)
        self.b_test.setVisible(False)
        row = QHBoxLayout()
        row.addWidget(self.b_drop)
        row.addWidget(self.lb, 1)
        row.addWidget(close)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 14)
        lay.addWidget(self.tabs, 1)
        lay.addLayout(row)
        self._tester = _Tester()
        self._tester.done.connect(self._tested)

    def free_key(self):
        from ui.gemini_router import FreeKeyWizard

        FreeKeyWizard(self).exec()
        self.panel.refresh()

    def closeEvent(self, e):
        type(self)._open = None
        super().closeEvent(e)

    def test_keys(self):
        ks = gemini.keys()
        if not ks:
            return
        self.b_test.setEnabled(False)
        self.lb.setText(f"Testing {len(ks)} key(s)…")
        try:
            self.router.b_test.setEnabled(False)
            self.router.b_test.setText(tr("Testing…"))
        except Exception:
            pass

        def work():
            res = [gemini.test_key(k) for k in ks]
            self._tester.done.emit(res)
        threading.Thread(target=work, daemon=True).start()

    def _tested(self, res):
        self.b_test.setEnabled(True)
        ok = sum(1 for r in res if not r)
        self.lb.setText(f"{ok} of {len(res)} key(s) work.")
        try:
            self.router.b_test.setEnabled(True)
            self.router.b_test.setText(f"✓  {ok}/{len(res)} " + tr("work"))
        except Exception:
            pass
        self.panel.refresh()

    def drop_refused(self):
        bad = [k for k, r in zip(gemini.keys(), gemini.status()) if r["state"] == gemini.REFUSED]
        if not bad:
            self.lb.setText("No refused key.")
            return
        ans = QMessageBox.question(
            self, "Gemini keys",
            f"Remove the {len(bad)} refused key(s) from this computer?\n\n"
            "Add new keys from aistudio.google.com/apikey in Settings › Gemini.")
        if ans != QMessageBox.StandardButton.Yes:
            return
        for k in bad:
            gemini.forget(k)
        gemini.set_keys([k for k in gemini.keys() if k not in bad])
        self.lb.setText(f"{len(bad)} key(s) removed.")
        self.panel.refresh()


class KeysChip(QPushButton):
    """Batch top bar: '🔑 9/15 ready' - red when a key needs attention."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setToolTip("Gemini Router – the keys at work, live (click)")
        self.clicked.connect(lambda: GeminiKeysDialog.show_for(self.window()))
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(2000)
        self.refresh()

    def refresh(self):
        rows = gemini.status(gemini.view_models()) if gemini.configured() else []
        self.setVisible(bool(rows))
        if not rows:
            return
        n, ready, busy, lines, bad, spent = _summary(rows)
        self.setText(f"🔑 {ready}/{n} ready" + (f" · {busy} working" if busy else "")
                     + (f" · {lines:,} lines" if lines else "")
                     + (f" · ⚠ {bad + spent}" if bad + spent else ""))
        self.setStyleSheet("color: #ff9c9c;" if bad + spent or not (ready or busy) else "")


WEB_RISK = ("Not an official API: Google's terms do not allow automated use of "
            "gemini.google.com, and Google may limit, ask to verify or close the Google "
            "accounts used here. Use separate Google accounts, not your main one. The cookies "
            "you paste open that Google account - they stay only on this computer and are "
            "never shown again.")
WEB_ADDON = ("🔒 Gemini web add-on\n\nTranslate with your own Google accounts "
             "(gemini.google.com) when the free API keys are used up for the day - no Google "
             "Translate lines.\n\nIt is a paid add-on: ask the seller for the Gemini web "
             "add-on and send your Machine ID (Help › License). You get a new licence key "
             "with it.")


WEB_INSTALLER = ("Gemini web needs SARIKA VOXDUB PRO 2.7.3 installed from the new installer "
                 "(an update cannot add it) – ask the seller for the installer.")


class GeminiWebPanel(QWidget):
    """2.7.2: Gemini web (gemini.google.com) with the user's own Google accounts.
    2.7.3: the Admin, and customers whose licence has the Gemini web add-on and
    who agreed to the warning once. The cookies are typed here, kept on this
    PC, never shown again (core/gemini_web.py)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import (QCheckBox, QComboBox, QFormLayout, QLineEdit,
                                       QListWidget, QListWidgetItem)
        from core import gemini_web

        self.gw = gemini_web
        self._Item = QListWidgetItem
        # 2.7.3: the add-on page, the warning to agree to, the missing library
        self.gate = QWidget()
        gl = QVBoxLayout(self.gate)
        self.gate_text = QLabel()
        self.gate_text.setWordWrap(True)
        self.gate_text.setStyleSheet("font-size: 10.5pt;")
        self.chk_agree = QCheckBox("I understand – I use my own separate Google accounts, "
                                   "at my own risk")
        self.btn_agree = QPushButton("Agree and continue")
        self.btn_agree.setEnabled(False)
        self.chk_agree.toggled.connect(self.btn_agree.setEnabled)
        self.btn_agree.clicked.connect(self._agree)
        gl.addWidget(self.gate_text)
        gl.addWidget(self.chk_agree)
        gl.addWidget(self.btn_agree, 0, Qt.AlignLeft)
        gl.addStretch(1)
        self.body = QWidget()
        warn = QLabel(
            "⚠ " + WEB_RISK + "\nText only (translation, names, proofreading, shorter "
            "lines) - the sound of an episode still goes to the API keys. One request per "
            "account at a time.")
        warn.setWordWrap(True)
        warn.setStyleSheet("color:#f0b429;")
        how = QLabel(
            "How: open gemini.google.com in Chrome, signed in with that account → F12 → "
            "Application → Cookies → https://gemini.google.com → copy the values of "
            "__Secure-1PSID and __Secure-1PSIDTS.")
        how.setWordWrap(True)
        how.setStyleSheet("color:#8b949e;")
        self.lst = QListWidget()
        self.lst.setMaximumHeight(150)
        self.ed_label = QLineEdit()
        self.ed_label.setPlaceholderText("e.g. heang@gmail.com (shown as hea***@***)")
        self.ed_psid = QLineEdit()
        self.ed_psidts = QLineEdit()
        for ed in (self.ed_psid, self.ed_psidts):
            ed.setEchoMode(QLineEdit.Password)
            ed.setPlaceholderText("paste the value")
        self.cmb_mode = QComboBox()
        for m, text in (("fallback", "When every API key is used up"),
                        ("first", "First – before the API keys (saves their quota)"),
                        ("off", "Off")):
            self.cmb_mode.addItem(text, m)
        self.cmb_mode.setCurrentIndex(max(0, self.cmb_mode.findData(gemini_web.mode())))
        self.cmb_mode.currentIndexChanged.connect(
            lambda *_: (self.gw.set_mode(self.cmb_mode.currentData()), self._fill()))
        self.cmb_model = QComboBox()            # 2.7.2: Flash answers fastest
        for m, text in (("gemini-flash", "Flash – fast (recommended)"),
                        ("gemini-flash-lite", "Flash-Lite – fastest"),
                        ("", "Auto – Gemini chooses (may think long)")):
            self.cmb_model.addItem(text, m)
        self.cmb_model.setCurrentIndex(max(0, self.cmb_model.findData(gemini_web.web_model())))
        self.cmb_model.currentIndexChanged.connect(
            lambda *_: self.gw.set_model(self.cmb_model.currentData()))
        self.btn_add = QPushButton("➕ Add account")
        self.btn_upd = QPushButton("New cookies for the selected")
        self.btn_test = QPushButton("Test the selected")
        self.btn_del = QPushButton("Remove the selected")
        self.lbl = QLabel("")
        self.lbl.setWordWrap(True)
        self.btn_add.clicked.connect(self._add)
        self.btn_upd.clicked.connect(self._update)
        self.btn_test.clicked.connect(self._test)
        self.btn_del.clicked.connect(self._remove)
        form = QFormLayout()
        form.addRow("Use it", self.cmb_mode)
        form.addRow("Model", self.cmb_model)
        form.addRow("Account name", self.ed_label)
        form.addRow("__Secure-1PSID", self.ed_psid)
        form.addRow("__Secure-1PSIDTS", self.ed_psidts)
        row = QHBoxLayout()
        for b in (self.btn_add, self.btn_upd, self.btn_test, self.btn_del):
            row.addWidget(b)
        row.addStretch(1)
        lay = QVBoxLayout(self.body)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(warn)
        lay.addWidget(how)
        lay.addWidget(self.lst)
        lay.addLayout(form)
        lay.addLayout(row)
        lay.addWidget(self.lbl)
        lay.addStretch(1)
        top = QVBoxLayout(self)
        top.addWidget(self.gate)
        top.addWidget(self.body)
        self._show_state()
        self._fill()

    def _show_state(self):
        """Add-on missing / warning not agreed / library missing / the panel."""
        if not self.gw.allowed():
            from core import license as lic

            self.gate_text.setText(tr(WEB_ADDON) + f"\n\nMachine ID: {lic.machine_id()}")
            agree = False
        elif not self.gw.consented():
            self.gate_text.setText("⚠ " + tr("Before you use Gemini web") + "\n\n" + tr(WEB_RISK))
            agree = True
        elif not self.gw.installed():
            self.gate_text.setText(tr(WEB_INSTALLER))
            agree = False
        else:
            self.gate.setVisible(False)
            self.body.setVisible(True)
            return
        self.chk_agree.setVisible(agree)
        self.btn_agree.setVisible(agree)
        self.gate.setVisible(True)
        self.body.setVisible(False)

    def _agree(self):
        if self.chk_agree.isChecked():
            self.gw.set_consent(True)
            self._show_state()

    def _fill(self):
        sel = self._selected()
        self.lst.clear()
        for a in self.gw.accounts():
            st = {"ready": "✅ Ready", "working": "⏳ Working",
                  "resting": "⏸ Resting – " + (a["error"] or "")[:60]}[a["state"]]
            it = self._Item(f"{a['masked']}   ·   {st}   ·   {a['used']} answers since start")
            it.setData(Qt.UserRole, a["id"])
            self.lst.addItem(it)
            if a["id"] == sel:
                self.lst.setCurrentItem(it)
        self.lbl.setText(self.gw.status())

    def _selected(self):
        it = self.lst.currentItem() if hasattr(self, "lst") else None
        return it.data(Qt.UserRole) if it else None

    def _clear(self):
        for ed in (self.ed_label, self.ed_psid, self.ed_psidts):
            ed.clear()

    def _add(self):
        psid = self.ed_psid.text().strip()
        if not psid:
            self.lbl.setText("Paste the __Secure-1PSID value first")
            return
        self.gw.add(self.ed_label.text().strip(), psid, self.ed_psidts.text().strip())
        self._clear()
        self._fill()

    def _update(self):
        aid = self._selected()
        if not aid or not self.ed_psid.text().strip():
            self.lbl.setText("Select an account and paste its new cookies")
            return
        self.gw.update(aid, self.ed_psid.text().strip(), self.ed_psidts.text().strip(),
                       self.ed_label.text().strip() or None)
        self._clear()
        self._fill()

    def _test(self):
        from PySide6.QtWidgets import QApplication

        aid = self._selected()
        self.lbl.setText("Signing in…")
        QApplication.processEvents()
        ok, msg = self.gw.test(aid)
        self._fill()
        self.lbl.setText(("✅ " if ok else "❌ ") + msg)

    def _remove(self):
        aid = self._selected()
        if aid:
            self.gw.remove(aid)
            self._fill()
