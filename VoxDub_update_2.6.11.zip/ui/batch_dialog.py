"""
batch_dialog.py - Batch queue dashboard: add many videos, dub + export them
one after another.

Layout (SARIKA VOXDUB PRO style): top bar with Start / Stop, stat cards, total
progress, "now dubbing" / "now exporting" cards with a thumbnail, the queue
(status pills + progress per row) and a settings side panel with tabs.

  * Two threads: one video exports while the next one is dubbed.
  * "Dub only" mode: check each video in the editor, then Export.
  * Each row can have its own language / voice; one video can be queued in
    several languages (Whisper runs once).
  * The queue is saved and comes back after a restart.
  * Sound + Windows notification (and optional PC shutdown) when finished,
    and a CSV report in the output folder.

The window can be closed while the queue runs (it keeps going in the
background); File > Batch queue opens it again.
"""

import copy
import hashlib
import os
import subprocess
import sys
import threading
import time
from typing import Dict, List, Optional

from PySide6.QtCore import QObject, QRectF, QSize, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QBrush, QColor, QIcon, QLinearGradient, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QScrollArea, QSpinBox,
    QFileDialog, QFormLayout, QFrame, QHBoxLayout, QHeaderView, QInputDialog, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMenu, QMessageBox, QProgressBar, QPushButton,
    QGridLayout, QSplitter, QStackedWidget, QStyle, QStyledItemDelegate, QSystemTrayIcon,
    QTableWidget,
    QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

from core import batch, errors, settings
from core import license as lic
from core.export import ENCODERS, LOUDNESS, ExportOptions
from core.project import Project
from core.media import no_window, find_ffmpeg, format_time, get_media_info
from core.transcribe import WHISPER_MODELS
from core.translate import LANGUAGES, SOURCE_LANGUAGES

AUTO_RETRIES = 2                # internet / busy / quota errors: tried again by itself
RETRY_DELAYS = (60, 300)        # s before retry 1, 2
GPU_RETRY_DELAY = 30            # s: the graphics card was full / reset - let it settle
LOW_VRAM_MB = 900               # small card with less free: the next video waits
from core.tts import AUTO_VOICE, TTS_ENGINES, voice_for_gender, voices_for
from ui.workers import TaskWorker

STATUS_TEXT = {
    batch.WAITING: "⏳ Waiting",
    batch.RUNNING: "▶ Dubbing",
    batch.DUBBED: "🎙 Dubbed – check",
    batch.EXPORT_WAIT: "⏳ To export",
    batch.EXPORTING: "⬆ Exporting",
    batch.DONE: "✅ Done",
    batch.FAILED: "❌ Failed",
    batch.STOPPED: "⏸ Stopped",
    batch.SKIPPED: "⏭ Skipped",
}
# status pill colours: (background, text)
PILL = {
    batch.WAITING: ("#232a33", "#9aa4b0"),
    batch.RUNNING: ("#123d36", "#5ff0d2"),
    batch.DUBBED: ("#2b2450", "#b9a8ff"),
    batch.EXPORT_WAIT: ("#232a33", "#c9b8ff"),
    batch.EXPORTING: ("#30285e", "#cfc2ff"),
    batch.DONE: ("#143823", "#6ee7a8"),
    batch.FAILED: ("#44171c", "#ff8a8a"),
    batch.STOPPED: ("#3f2e0e", "#ffcf6b"),
    batch.SKIPPED: ("#1d2229", "#6e7681"),
}
THUMB_W, THUMB_H = 64, 96
MODEL_TEXT = {
    "tiny": "tiny – fastest, lowest accuracy",
    "base": "base – fast",
    "small": "small – good (recommended)",
    "medium": "medium – better, slow",
    "large-v3": "large-v3 – best, slowest (GPU)",
}
COLS = ["Video", "Story", "Language", "Voice", "Length", "Status", "Progress", "Result"]
COL_STORY, COL_VOICE, COL_LENGTH, COL_STATUS, COL_PROGRESS, COL_RESULT = 1, 3, 4, 5, 6, 7
MODE_EXPORT, MODE_DUB_ONLY = "export", "dub_only"
MAX_JOBS = 8                    # videos dubbed (and exported) at the same time


def human_time(sec: float) -> str:
    """'1h 20m' / '9m 41s' / '35s'."""
    sec = int(max(0, sec))
    h, m, s = sec // 3600, sec // 60 % 60, sec % 60
    if h:
        return f"{h}h {m:02d}m"
    if m:
        return f"{m}m {s:02d}s"
    return f"{s}s"


def lang_name(code: str) -> str:
    return LANGUAGES.get(code, (code,))[0]


def _short(engine: str, lang: str, vid: str) -> str:
    for v, label in voices_for(engine, lang, with_auto=False):
        if v == vid:
            return label.split(" (")[0]
    return vid


def auto_label(engine: str, lang: str) -> str:
    """'Auto (Piseth ♂ / Sreymom ♀)' - the two voices Auto switches between."""
    m = voice_for_gender(engine, lang, "male")
    f = voice_for_gender(engine, lang, "female")
    if not m or m == f:
        return "Auto"
    return f"Auto ({_short(engine, lang, m)} ♂ / {_short(engine, lang, f)} ♀)"


def has_auto(engine: str, lang: str) -> bool:
    return any(v == AUTO_VOICE for v, _ in voices_for(engine, lang))


def voice_name(engine: str, lang: str, voice: str) -> str:
    if voice == AUTO_VOICE or not voice:
        return auto_label(engine, lang)
    return _short(engine, lang, voice)


def thumb_path(video_path: str, big: bool = False) -> str:
    key = hashlib.sha1(os.path.abspath(video_path).lower().encode("utf-8")).hexdigest()[:16]
    return os.path.join(settings.settings_dir(), "thumbs", key + ("_big" if big else "") + ".jpg")


def make_thumb(video_path: str, out: str, height: int = 0) -> bool:
    """One small frame of the video (a few seconds in) as a JPEG."""
    os.makedirs(os.path.dirname(out), exist_ok=True)
    for t in ("5", "1", "0"):
        try:
            subprocess.run([find_ffmpeg(), "-hide_banner", "-loglevel", "error", "-y",
                            "-ss", t, "-i", video_path, "-frames:v", "1",
                            "-vf", f"scale=-2:{height or THUMB_H * 2}", "-q:v", "4", out],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           creationflags=no_window(), timeout=30)
        except (OSError, subprocess.SubprocessError):
            return False
        if os.path.isfile(out) and os.path.getsize(out) > 0:
            return True
    return False


ROW_THUMB = QSize(72, 44)        # 2.3: a frame of every video in the queue (left)
PREVIEW_H = 720                  # the frame in the preview on the left (sharp)
PREFETCH = 6                     # Preview frames made ahead (the next rows)


class ThumbLoader(QObject):
    """Makes the queue thumbnails one after the other in ONE thread (160
    videos must not start 160 ffmpeg at once), newest request first."""
    ready = Signal(str)

    def __init__(self, parent=None, big: bool = False, wait_for=None):
        super().__init__(parent)
        self.big = big                  # the larger frame of the preview (left)
        self.wait_for = wait_for        # () -> True while the Preview frame is made first
        self._todo: List[str] = []
        self._lock = threading.Lock()
        self._running = False
        self.stopped = False

    def want(self, path: str):
        with self._lock:
            if path in self._todo:
                return
            self._todo.append(path)
            if self._running:
                return
            self._running = True
        threading.Thread(target=self._work, daemon=True).start()

    def _work(self):
        while not self.stopped:
            with self._lock:
                if not self._todo:
                    self._running = False
                    return
                path = self._todo.pop(0)
            while self.wait_for is not None and self.wait_for() and not self.stopped:
                time.sleep(0.05)        # the clicked video's Preview frame goes first
            out = thumb_path(path, self.big)
            ok = os.path.isfile(out) or (os.path.isfile(path) and make_thumb(
                path, out, PREVIEW_H if self.big else 0))
            if ok and not self.stopped:
                try:
                    self.ready.emit(path)
                except RuntimeError:
                    return


class StyledFrames(QObject):
    """The Preview on the left shows a frame AS EXPORTED with the queue's
    tools (logo, brand text, hidden original subtitles, crop, colour,
    subtitles …) - rendered in one background thread, newest request first,
    kept on disk per video + settings."""
    ready = Signal(str, str)                # video path, png

    def __init__(self, parent=None):
        super().__init__(parent)
        self._todo = None                   # (video, base, burn, out) - the clicked video
        self._later: List[tuple] = []       # the next rows, made while nothing is clicked
        self._lock = threading.Lock()
        self._running = False
        self.urgent = False                 # the clicked video is being made (others wait)
        self.stopped = False

    @staticmethod
    def key(video: str, base: dict, burn: bool) -> str:
        import json

        blob = json.dumps({k: base.get(k) for k in sorted(base) if k in batch.SETTING_FIELDS},
                          sort_keys=True, default=str)
        h = hashlib.sha1(f"{os.path.abspath(video).lower()}|{burn}|{blob}".encode("utf-8"))
        return os.path.join(settings.settings_dir(), "thumbs", "styled_"
                            + h.hexdigest()[:20] + ".png")

    def want(self, video: str, base: dict, burn: bool, later: bool = False) -> str:
        """The rendered frame if it is made already, else "" (made now -
        or, later=True, after the clicked one: the next rows are ready when
        the user gets to them)."""
        out = self.key(video, base, burn)
        if os.path.isfile(out):
            return out
        job = (video, copy.deepcopy(base), burn, out)
        with self._lock:
            if later:
                if all(j[3] != out for j in self._later):
                    self._later.append(job)
            else:
                self._todo = job
                self.urgent = True
                self._later = [j for j in self._later if j[3] != out]
            if self._running:
                return ""
            self._running = True
        threading.Thread(target=self._work, daemon=True).start()
        return ""

    def _work(self):
        while not self.stopped:
            with self._lock:
                job, self._todo = self._todo, None
                if job is None:
                    self.urgent = False
                    while self._later and os.path.isfile(self._later[0][3]):
                        self._later.pop(0)
                    job = self._later.pop(0) if self._later else None
                if job is None:
                    self._running = False
                    return
            video, base, burn, out = job
            try:
                if not os.path.isfile(out):
                    render_styled_frame(video, base, burn, out)
            except Exception as e:
                print(f"[batch] preview frame: {e}")
                continue
            if not self.stopped:
                try:
                    self.ready.emit(video, out)
                except RuntimeError:
                    return


def render_styled_frame(video: str, base: dict, burn: bool, out: str) -> str:
    """One frame of `video` (5 s in) as the queue would export it."""
    from core.export import ExportOptions, render_frame
    from core.project import SubtitleClip
    from ui.batch_tools import SAMPLE_SUB

    q = batch.preview_project(base, video)
    t = min(5.0, max(0.0, q.sequence_duration() * 0.3))
    sample = SAMPLE_SUB.get(q.target_lang, SAMPLE_SUB["en"]) \
        if burn and not getattr(q, "subs_hidden", False) else ""
    q.subtitle_clips = [SubtitleClip("sample", max(0.0, t - 1.0), t + 2.0, sample)] \
        if sample else []
    os.makedirs(os.path.dirname(out), exist_ok=True)
    tmp = out + ".part.png"
    render_frame(q, ExportOptions(output_path="", resolution="720p",
                                  burn_subtitles=bool(sample)), t, tmp)
    os.replace(tmp, out)
    return out


# --------------------------------------------------------------------------- #
# Queue cell painters
# --------------------------------------------------------------------------- #
class PillDelegate(QStyledItemDelegate):
    """Status as a coloured rounded pill."""

    def paint(self, painter, option, index):
        self.initStyleOption(option, index)
        text = option.text
        option.text = ""
        option.widget.style().drawControl(QStyle.ControlElement.CE_ItemViewItem, option,
                                          painter, option.widget)
        key = index.data(Qt.ItemDataRole.UserRole)
        bg, fg = PILL.get(key, ("#232a33", "#c9d1d9"))
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        fm = option.fontMetrics
        w = fm.horizontalAdvance(text) + 20
        r = option.rect
        pill = QRectF(r.left() + 6, r.center().y() - 11, min(w, r.width() - 12), 22)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(bg))
        painter.drawRoundedRect(pill, 11, 11)
        painter.setPen(QColor(fg))
        painter.drawText(pill, Qt.AlignmentFlag.AlignCenter, text)
        painter.restore()

    def sizeHint(self, option, index):
        sz = super().sizeHint(option, index)
        sz.setWidth(sz.width() + 28)
        return sz


class BarDelegate(QStyledItemDelegate):
    """Progress of one row as a thin gradient bar (UserRole = 0..100, -1 = none)."""

    def paint(self, painter, option, index):
        self.initStyleOption(option, index)
        option.text = ""
        option.widget.style().drawControl(QStyle.ControlElement.CE_ItemViewItem, option,
                                          painter, option.widget)
        v = index.data(Qt.ItemDataRole.UserRole)
        if v is None or v < 0:
            return
        painter.save()
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = option.rect
        track = QRectF(r.left() + 8, r.center().y() - 4, r.width() - 50, 8)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor("#0b0e12"))
        painter.drawRoundedRect(track, 4, 4)
        if v > 0:
            fill = QRectF(track.left(), track.top(), track.width() * min(100, v) / 100, 8)
            g = QLinearGradient(track.topLeft(), track.topRight())
            g.setColorAt(0, QColor("#22c3a6"))
            g.setColorAt(1, QColor("#7c5cff"))
            painter.setBrush(QBrush(g))
            painter.drawRoundedRect(fill, 4, 4)
        painter.setPen(QPen(QColor("#9aa4b0")))
        painter.drawText(QRectF(track.right() + 4, r.top(), 40, r.height()),
                         Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, f"{v}%")
        painter.restore()


# --------------------------------------------------------------------------- #
# Small dialogs
# --------------------------------------------------------------------------- #
class LanguagesDialog(QDialog):
    """Tick the extra languages to dub the selected videos into."""

    def __init__(self, parent, skip: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Add languages")
        self.list = QListWidget()
        for code, (name, _g) in LANGUAGES.items():
            if code == skip:
                continue
            it = QListWidgetItem(name)
            it.setData(Qt.ItemDataRole.UserRole, code)
            it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Unchecked)
            self.list.addItem(it)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Also dub the selected videos into:\n"
                             "(the speech is recognised only once)"))
        lay.addWidget(self.list, 1)
        lay.addWidget(bb)

    def codes(self) -> List[str]:
        return [self.list.item(i).data(Qt.ItemDataRole.UserRole)
                for i in range(self.list.count())
                if self.list.item(i).checkState() == Qt.CheckState.Checked]


class ItemSettingsDialog(QDialog):
    """Language + voice for the selected rows."""

    def __init__(self, parent, engine: str, lang: str = "", voice: str = "",
                 base_lang: str = "km", row_engine: str = ""):
        super().__init__(parent)
        self.engine = engine                # the batch's engine
        self.base_lang = base_lang
        self.setWindowTitle("Language, voice engine & voice")
        self.cmb_engine = QComboBox()
        self.cmb_engine.addItem(f"Same as batch settings ({TTS_ENGINES.get(engine, engine)})", "")
        for code, name in TTS_ENGINES.items():
            self.cmb_engine.addItem(name, code)
        self.cmb_engine.setCurrentIndex(max(0, self.cmb_engine.findData(row_engine)))
        self.cmb_engine.setToolTip("e.g. VoxCPM2 voice clone for the important episodes, "
                                   "Edge for the rest")
        self.cmb_lang = QComboBox()
        self.cmb_lang.addItem("Same as batch settings", "")
        for code, (name, _g) in LANGUAGES.items():
            self.cmb_lang.addItem(name, code)
        self.cmb_lang.setCurrentIndex(max(0, self.cmb_lang.findData(lang)))
        self.cmb_voice = QComboBox()
        self.cmb_lang.currentIndexChanged.connect(self._voices)
        self.cmb_engine.currentIndexChanged.connect(self._voices)
        self._voices()
        self.cmb_voice.setCurrentIndex(max(0, self.cmb_voice.findData(voice)))
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok |
                              QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        form = QFormLayout(self)
        form.addRow("Language", self.cmb_lang)
        form.addRow("Voice engine", self.cmb_engine)
        form.addRow("Voice", self.cmb_voice)
        form.addRow(bb)

    def _voices(self):
        self.cmb_voice.clear()
        self.cmb_voice.addItem("Same as batch settings", "")
        lang = self.cmb_lang.currentData() or self.base_lang
        engine = self.cmb_engine.currentData() or self.engine
        for vid, label in voices_for(engine, lang):
            self.cmb_voice.addItem(auto_label(engine, lang) + " – per line"
                                   if vid == AUTO_VOICE else label, vid)

    def values(self):
        """(language, voice engine, voice) - "" = batch settings."""
        return (self.cmb_lang.currentData() or "", self.cmb_engine.currentData() or "",
                self.cmb_voice.currentData() or "")


# --------------------------------------------------------------------------- #
# Batch window
# --------------------------------------------------------------------------- #
class BatchDialog(QDialog):
    def __init__(self, window, output_dir: str, queue_file: Optional[str] = None):
        super().__init__(window)
        self.win = window
        self.work_root = output_dir
        self.queue_file = queue_file
        self.items: List[batch.BatchItem] = []
        self.base: Dict = {}
        # running jobs: id(item) -> (item, worker); several at once ("At once")
        self.dub_jobs: Dict[int, tuple] = {}
        self.exp_jobs: Dict[int, tuple] = {}
        self._pct: Dict[int, int] = {}      # id(item) -> progress of its current stage
        self._row_of: Dict[int, int] = {}   # id(item) -> table row
        self._msg: Dict[str, str] = {"dub": "", "exp": ""}
        self._t_item: Dict[int, float] = {}
        self._skip = set()
        self._later = {}        # id(item) -> not before (time): automatic retry
        self._orphans = []      # workers left by "Stop now" (still ending their piece)
        self._tries = {}        # id(item) -> automatic retries used
        self.running = False
        self._stop_all = False
        self._started = 0.0
        self._run_items: List[batch.BatchItem] = []
        self._only: set = set()         # 2.6.9: Start these now - only these run
        self._gpu_one = False   # 2.6.10: the GPU was full / reset - one video at a time
        self._vram_wait = False  # a re-check of the free VRAM is planned
        self._tray: Optional[QSystemTrayIcon] = None
        self._thumb_workers: List[TaskWorker] = []
        self.mode = MODE_EXPORT
        self.last_report = ""
        self.setWindowTitle("SARIKA VOXDUB PRO – Batch queue")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.setMinimumSize(1040, 700)
        self.resize(1320, 860)
        self.setAcceptDrops(True)
        # video lengths are read in a background thread (ffprobe takes ~0.1 s
        # per video: thousands of videos froze the window)
        self._probe_ready: List = []
        self._probe_thread: Optional[threading.Thread] = None
        self._probe = QTimer(self)
        self._probe.setInterval(300)
        self._probe.timeout.connect(self._probe_next)
        self._save_timer = QTimer(self)     # the queue file is written at most every 2 s
        self._save_timer.setSingleShot(True)
        self._save_timer.setInterval(2000)
        self._save_timer.timeout.connect(self._save)
        self._build()
        self._load()

    # ------------------------------------------------------------------ #
    def _build(self):
        def btn(text, slot, tip="", name=""):
            b = QPushButton(text)
            b.clicked.connect(slot)
            if tip:
                b.setToolTip(tip)
            if name:
                b.setObjectName(name)
            return b

        # ================= top bar (like the main window) =================
        top = QWidget()
        top.setObjectName("TopBar")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(16, 10, 16, 10)
        title = QLabel("🎙️ SARIKA VOXDUB")
        title.setObjectName("AppTitle")
        pro = QLabel("PRO")
        pro.setObjectName("AppTitlePro")
        sub = QLabel("Batch queue")
        sub.setObjectName("DashSubtitle")
        self.btn_open = btn("📂 Output folder", self._open_folder)
        self.btn_report = btn("📄 Report", self._open_report, "Open the last CSV report")
        self.btn_qc = btn("✅ Quality check", self.run_qc,
                          "Check the finished videos now (the selected ones, or all): lines "
                          "heard wrong, Chinese left, too long / short, sound too loud / "
                          "quiet / clipping")
        self.btn_merge = btn("🔗 Merge finished", self._merge_done,
                             "Join the exported videos (in queue order) into one long video "
                             "– and cut it into parts of N minutes if you like")
        self.btn_stop = btn("■  Stop", self.stop, "Stop after the current line", "DangerButton")
        self.btn_start = btn("▶  Start", self.start, "", "TopAuto")
        self.btn_start.setMinimumWidth(110)
        self.lb_jobs = QLabel("At once")
        self.lb_jobs.setObjectName("MutedLabel")
        self.spn_jobs = QSpinBox()
        self.spn_jobs.setRange(1, MAX_JOBS)
        self.spn_jobs.setValue(1)
        self.spn_jobs.setFixedWidth(64)
        self.spn_jobs.setToolTip(
            "How many videos are dubbed at the same time (and how many are exported).\n"
            "2–3 is faster on a good PC; more needs more RAM / GPU memory, and many Edge\n"
            "voices at once can be slowed down by Microsoft. VoxCPM2 makes one voice line\n"
            "at a time anyway. Can be changed while the queue runs.")
        self.spn_jobs.valueChanged.connect(self._jobs_changed)
        tl.addWidget(title)
        tl.addWidget(pro)
        tl.addSpacing(14)
        tl.addWidget(sub)
        tl.addStretch(1)
        # 2.3: GPU / VRAM / RAM while the queue runs (too full: fewer "At once")
        from ui.resource_monitor import ResourceMonitor

        self.res_monitor = ResourceMonitor(
            self, jobs=lambda: f"{len(self.dub_jobs)} dubbing, {len(self.exp_jobs)} exporting"
            if self.running else "")
        tl.addWidget(self.res_monitor)
        tl.addSpacing(8)
        tl.addWidget(self.btn_open)
        tl.addWidget(self.btn_report)
        tl.addWidget(self.btn_qc)
        tl.addWidget(self.btn_merge)
        tl.addSpacing(8)
        tl.addWidget(self.lb_jobs)
        tl.addWidget(self.spn_jobs)
        # 2.4: Dub / Output / Tools / Auto / Finish open from here (the queue
        # and the preview get the whole width)
        self.btn_settings = btn("⚙  Settings", lambda: self.toggle_settings(),
                                "Dub · Output · Tools · Auto · Finish – and presets")
        tl.addWidget(self.btn_settings)
        tl.addWidget(self.btn_stop)
        tl.addWidget(self.btn_start)

        # ================= stat cards =================
        self.cards = {}
        cards_row = QHBoxLayout()
        cards_row.setSpacing(10)
        for key, caption, tone in (("total", "Videos in queue", ""),
                                   ("done", "Done", "done"),
                                   ("working", "Working now", "work"),
                                   ("failed", "Failed", "fail"),
                                   ("left", "Time left", "time")):
            card = QFrame()
            card.setObjectName("StatCard")
            card.setProperty("tone", tone)
            cl = QVBoxLayout(card)
            cl.setContentsMargins(14, 10, 14, 10)
            cl.setSpacing(0)
            val = QLabel("0" if key != "left" else "–")
            val.setObjectName("StatValue")
            cap = QLabel(caption)
            cap.setObjectName("StatCaption")
            cl.addWidget(val)
            cl.addWidget(cap)
            cards_row.addWidget(card, 1)
            self.cards[key] = val
            if key == "failed":
                # 2.6.9: click -> the failed videos are selected, and can start again
                card.setCursor(Qt.CursorShape.PointingHandCursor)
                card.setToolTip("Click: show the failed videos and start them again")
                card.mousePressEvent = lambda _e: self._show_failed()

        # ================= total progress =================
        self.pb_total = QProgressBar()
        self.pb_total.setObjectName("BigBar")
        self.pb_total.setFormat("%p%")
        self.lb_total = QLabel("Add videos (or drop them / a folder here), then click Start.")
        self.lb_total.setObjectName("MutedLabel")
        self.lb_total.setWordWrap(True)

        # ================= now dubbing / exporting =================
        def now_card(title_text):
            card = QFrame()
            card.setObjectName("NowCard")
            h = QHBoxLayout(card)
            h.setContentsMargins(12, 10, 12, 10)
            h.setSpacing(12)
            thumb = QLabel()
            thumb.setObjectName("Thumb")
            thumb.setFixedSize(THUMB_W, THUMB_H)
            thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
            v = QVBoxLayout()
            v.setSpacing(4)
            t = QLabel(title_text)
            t.setObjectName("NowTitle")
            name = QLabel("Idle")
            name.setObjectName("NowName")
            msg = QLabel("")
            msg.setObjectName("MutedLabel")
            msg.setWordWrap(True)
            bar = QProgressBar()
            bar.setTextVisible(True)
            v.addWidget(t)
            v.addWidget(name)
            v.addWidget(msg)
            v.addStretch(1)
            v.addWidget(bar)
            h.addWidget(thumb)
            h.addLayout(v, 1)
            return card, thumb, name, msg, bar

        dub_card, self.th_dub, self.nm_dub, self.lb_dub, self.pb_dub = now_card("🎙  NOW DUBBING")
        exp_card, self.th_exp, self.nm_exp, self.lb_exp, self.pb_exp = now_card("⬆  NOW EXPORTING")
        now_row = QHBoxLayout()
        now_row.setSpacing(10)
        now_row.addWidget(dub_card, 1)
        now_row.addWidget(exp_card, 1)
        self._idle_card("dub")
        self._idle_card("exp")

        # ================= queue =================
        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(COL_PROGRESS, QHeaderView.ResizeMode.Fixed)
        hh.setSectionResizeMode(COL_RESULT, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(COL_PROGRESS, 120)
        hh.setHighlightSections(False)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(ROW_THUMB.height() + 6)
        self.table.setIconSize(ROW_THUMB)
        self._row_icons: Dict[str, QIcon] = {}
        self.thumbs = ThumbLoader(self, wait_for=lambda: getattr(getattr(self, "styled", None), "urgent", False))
        self.thumbs.ready.connect(self._thumb_ready)
        self.big_thumbs = ThumbLoader(self, big=True, wait_for=lambda: getattr(getattr(self, "styled", None), "urgent", False))
        self.big_thumbs.ready.connect(lambda p: self.preview.refresh_poster(p))
        # the Preview shows the frame as exported (logo, blur, subtitles …)
        self.styled = StyledFrames(self)
        self.styled.ready.connect(lambda v, _png: self.preview.refresh_poster(v))
        self.table.setShowGrid(False)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._menu)
        self.table.cellDoubleClicked.connect(lambda r, _c: self._edit_rows([r]))
        self.table.itemSelectionChanged.connect(self._update_buttons)
        self.table.itemSelectionChanged.connect(self._preview_selected)
        self.table.setItemDelegateForColumn(COL_STATUS, PillDelegate(self.table))
        self.table.setItemDelegateForColumn(COL_PROGRESS, BarDelegate(self.table))

        self.btn_add = btn("➕ Videos…", self._browse, "", "AccentButton")
        self.btn_folder_add = btn("📁 Folder…", self._browse_folder,
                                  "Add every video in a folder (and its sub-folders)")
        self.btn_langs = btn("🌐 Languages…", self._add_languages,
                             "Dub the selected videos into more languages")
        self.btn_item = btn("🗣 Language & voice…", self._item_settings,
                            "Own language / voice engine (e.g. VoxCPM2) / voice for the "
                            "selected rows")
        self.btn_up = btn("▲", lambda: self._move(-1), "Move up")
        self.btn_down = btn("▼", lambda: self._move(1), "Move down")
        self.btn_edit = btn("✏ Edit", lambda: self._edit_rows(self._rows()),
                            "Open the dubbed video in the editor to check / fix it")
        self.btn_retry = btn("↻ Retry", self._retry)
        self.btn_skip = btn("⏭ Skip", self._skip_rows)
        self.btn_remove = btn("Remove", self._remove_selected)
        self.btn_clear = btn("Clear finished", self._clear_done)
        self.btn_remove_all = btn("🗑 Remove all", self._remove_all,
                                  "Empty the queue (videos being worked on now stay)")
        self.btn_export_sel = btn("⬆ Export selected", self._export_selected,
                                  "Export the selected dubbed videos (after checking them)")
        self.btn_export_all = btn("⬆ Export all dubbed", self._export_all_dubbed, "",
                                  "TopExport")
        for b in (self.btn_up, self.btn_down):
            b.setFixedWidth(34)

        qhead = QHBoxLayout()
        qt = QLabel("Queue")
        qt.setObjectName("SectionTitle")
        qhead.addWidget(qt)
        qhead.addSpacing(8)
        for b in (self.btn_add, self.btn_folder_add, self.btn_langs, self.btn_item):
            qhead.addWidget(b)
        qhead.addStretch(1)
        qhead.addWidget(self.btn_clear)
        qhead.addWidget(self.btn_remove_all)

        qfoot = QHBoxLayout()
        for b in (self.btn_up, self.btn_down, self.btn_edit, self.btn_retry, self.btn_skip,
                  self.btn_remove):
            qfoot.addWidget(b)
        qfoot.addStretch(1)
        hint = QLabel("Right-click for more")
        hint.setObjectName("MutedLabel")
        hint.setToolTip("Right-click a row for more · double-click a row to edit it")
        qfoot.addWidget(hint)
        qfoot.addSpacing(10)
        qfoot.addWidget(self.btn_export_sel)
        qfoot.addWidget(self.btn_export_all)

        # empty queue: a big drop zone instead of an empty table
        drop = QFrame()
        drop.setObjectName("DropZone")
        dl = QVBoxLayout(drop)
        dl.addStretch(1)
        icon = QLabel("📥")
        icon.setObjectName("DropIcon")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dtext = QLabel("Drop videos or a whole folder here\n"
                       "or use  ➕ Videos…  /  📁 Folder…")
        dtext.setObjectName("DropText")
        dtext.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dl.addWidget(icon)
        dl.addWidget(dtext)
        dl.addStretch(1)
        self.queue_stack = QStackedWidget()
        self.queue_stack.addWidget(drop)
        self.queue_stack.addWidget(self.table)

        queue = QFrame()
        queue.setObjectName("DashPanel")
        ql = QVBoxLayout(queue)
        ql.setContentsMargins(12, 10, 12, 10)
        ql.addLayout(qhead)
        ql.addWidget(self.queue_stack, 1)
        ql.addLayout(qfoot)

        # ================= settings side panel =================
        self.lb_base = QLabel()
        self.lb_base.setToolTip("Rows without their own language / voice use these settings")
        self.lb_base.setWordWrap(True)
        self.lb_base.setObjectName("BaseSummary")
        self.btn_take = btn("↻ Take from main window", self.take_settings,
                            "Use the language, voice, volumes, Style tab (logo, brand text, "
                            "original subtitles) and Tools (crop, color, audio effects, "
                            "Project settings …) of the main window")
        # editor Tools for every video
        self.lb_tools = QLabel()
        self.lb_tools.setWordWrap(True)
        self.lb_tools.setObjectName("BaseSummary")
        self.btn_tools = btn("🛠  Open Tools…", self.open_tools,
                             "Crop & Rotate, Color Adjustments, video fades, Audio Properties, "
                             "Equalizer, Noise Removal, Audio Effects – with a preview of any "
                             "queued video", "AccentButton")
        self.btn_style = btn("🎨  Style · Subtitles · Logo…", lambda: self.open_tools("style"),
                             "Hide the original subtitles, how our subtitles look, logo and "
                             "brand text – with a preview of any queued video")
        self.btn_proj = btn("📐  Project settings…", self.open_project_settings,
                            "Size / ratio (16:9, 9:16 TikTok …), framing, FPS, sample rate, "
                            "channels of every exported video")
        self.btn_tools_reset = btn("Reset tools", self.reset_tools,
                                   "Every video exactly as it is (no tools)")

        self.ed_out = QLineEdit(self.work_root)
        b_out = btn("…", self._browse_out)
        b_out.setFixedWidth(36)
        out_row = QHBoxLayout()
        out_row.addWidget(self.ed_out, 1)
        out_row.addWidget(b_out)
        self.cmb_res = QComboBox()
        self.cmb_res.addItem("1080p (Full HD)", "1080p")
        self.cmb_res.addItem("720p (HD)", "720p")
        self.cmb_res.addItem("1440p (2K)", "1440p")
        self.cmb_res.addItem("2160p (4K)", "2160p")
        self.cmb_res.addItem("Original size", "original")
        self.cmb_quality = QComboBox()
        self.cmb_quality.addItem("High (bigger file)", 18)
        self.cmb_quality.addItem("Normal", 20)
        self.cmb_quality.addItem("Small file", 24)
        self.cmb_quality.setCurrentIndex(1)
        self.cmb_encoder = QComboBox()
        for key, label in ENCODERS.items():
            self.cmb_encoder.addItem(label, key)
        self.cmb_voice = QComboBox()
        self.cmb_voice.setToolTip("Voice for the rows without their own voice.\n"
                                  "Auto = male / female voice chosen for each line")
        self.cmb_voice.currentIndexChanged.connect(self._voice_changed)
        self.cmb_src = QComboBox()
        for code, name in SOURCE_LANGUAGES.items():
            self.cmb_src.addItem(name, code)
        self.cmb_src.setToolTip("Language spoken in the videos (Auto detect works for most)")
        self.cmb_model = QComboBox()
        for m in WHISPER_MODELS:
            self.cmb_model.addItem(MODEL_TEXT.get(m, m), m)
        self.cmb_model.setToolTip("Whisper speech recognition model.\n"
                                  "Bigger = more accurate but slower (use a GPU for medium / large)")
        self.chk_ocr = QCheckBox("Double-check with the burned-in\nsubtitles (OCR)")
        self.chk_ocr.setToolTip("Correct Whisper's words with the subtitles shown in each "
                                "video and add the lines it missed")
        # the same choices as the editor's left panel
        self.cmb_tgt = QComboBox()
        for code, (name, _g) in LANGUAGES.items():
            self.cmb_tgt.addItem(name, code)
        self.cmb_tgt.setToolTip("Language every video is dubbed into (a row can have its own: "
                                "🗣 Language & voice…)")
        self.cmb_engine = QComboBox()
        for code, name in TTS_ENGINES.items():
            self.cmb_engine.addItem(name, code)
        self.spn_speed = QDoubleSpinBox()
        self.spn_speed.setRange(1.0, 2.0)
        self.spn_speed.setSingleStep(0.1)
        self.spn_speed.setSuffix(" ×")
        self.spn_speed.setToolTip(
            "A translated line LONGER than the original speech is sped up\n"
            "at most this much (1.10 × = still sounds natural).\n"
            "Lines that already fit keep their normal speed.\n"
            "To make the whole video faster: Tools › Video › Speed.")
        self.chk_stretch = QCheckBox("Slow the video for long lines")
        self.chk_stretch.setToolTip(
            "Where a line is still too long, that part of the video plays a\n"
            "little slower, so the voice is not rushed and stays on the lips.\n"
            "Off: the line is sped up more and its end may be cut.")
        self.chk_stretch.toggled.connect(self._voice_setting_changed)
        from ui.voice_style import PLAIN_TIP, make_voice_style_combo

        self.chk_plain = QCheckBox("Piseth / Sreymom as they are (first VoxDub)")
        self.chk_plain.setChecked(True)
        self.chk_plain.setToolTip(PLAIN_TIP)
        self.chk_plain.toggled.connect(self._voice_setting_changed)

        self.cmb_style = make_voice_style_combo(self.spn_speed, self.chk_stretch)
        self.btn_test_voice = QPushButton("▶  Test voice")
        self.btn_test_voice.clicked.connect(self._test_voice)
        self.btn_keys = QPushButton("🔑  API keys / voice clone…")
        self.btn_keys.setToolTip("Gemini API keys, VoxCPM2 voice clone settings")
        self.btn_keys.clicked.connect(self._open_engines)
        self.vox_box = self._voxcpm_box()
        self.cmb_tgt.currentIndexChanged.connect(self._voice_setting_changed)
        self.cmb_engine.currentIndexChanged.connect(self._voice_setting_changed)
        self.spn_speed.valueChanged.connect(self._voice_setting_changed)
        self.cmb_stt = QComboBox()
        self.cmb_stt.addItem("Whisper (offline, free)", "whisper")
        self.cmb_stt.addItem("Gemini (Google API key)", "gemini")
        self.cmb_stt.addItem("Paraformer-zh – Chinese, fast (VoxCPM engine)", "paraformer")
        self.cmb_stt.addItem("SenseVoice-Small – zh/en/ja/ko, fast (VoxCPM engine)", "sensevoice")
        self.cmb_tr = QComboBox()
        self.cmb_tr.addItem("Google Translate (free)", "google")
        self.cmb_tr.addItem("Gemini – follows the story (API key)", "gemini")
        self.cmb_src.currentIndexChanged.connect(self._speech_changed)
        self.cmb_model.currentIndexChanged.connect(self._speech_changed)
        self.cmb_stt.currentIndexChanged.connect(self._speech_changed)
        self.cmb_tr.currentIndexChanged.connect(self._speech_changed)
        self.chk_ocr.toggled.connect(self._speech_changed)
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItem("Export automatically", MODE_EXPORT)
        self.cmb_mode.addItem("Stop so I can check (dub only)", MODE_DUB_ONLY)
        self.chk_burn = QCheckBox("Burn subtitles into the video")
        self.chk_burn.toggled.connect(lambda *_: self._show_base())   # (Preview follows)
        self.chk_burn.setChecked(True)
        self.chk_srt = QCheckBox("Also save .srt subtitle file")
        self.chk_srt.setChecked(True)
        self.chk_cover = QCheckBox("Find and hide the original subtitles\nin each video")
        self.chk_cover.setToolTip("Scans every video for burned-in subtitles and covers them; "
                                  "not found → uses the area of another episode in the folder.\n"
                                  "ON: each video gets its OWN box (the box of the preset / "
                                  "Tools is moved).\nOFF: every video uses the box exactly "
                                  "where you put it.")
        self.chk_bars = QCheckBox("Remove black bars in each video")
        self.chk_bars.setToolTip("Finds black borders around the picture of every video and "
                                 "crops them off (crop / zoom: Style tab of the main window)")
        self.chk_series = QCheckBox("Same voice for each character\nin every episode")
        self.chk_series.setChecked(True)
        self.chk_series.setToolTip(
            "The episodes of a series share one list of characters (series_cast.json in the "
            "output folder of the story).\nA character found again in the next episode "
            "(recognised by voice) keeps the same name, voice and pitch.\n"
            "Fix a character once in the editor (👥 Characters) and every later episode "
            "follows it.\nVideos that are not one series: put them in different story "
            "folders.")
        self.chk_parallel = QCheckBox("Faster: export while the next\nvideos are dubbed")
        self.chk_parallel.setChecked(True)
        self.chk_same = QCheckBox("Same format for every episode\n(Merge joins them in seconds)")
        self.chk_same.setChecked(True)
        self.chk_same.setToolTip(
            "Every episode is exported in ONE standard format: 1080×1920 (portrait),\n"
            "1920×1080 (landscape) or 1080×1080, 30 fps, 44.1 kHz stereo\n"
            "(e.g. 1080×1934 and 1080×1920 both → 1080×1920).\n"
            "Then Merge joins the episodes without re-encoding: seconds instead of\n"
            "half an hour, and no quality is lost. A size set in Project settings is kept.")
        self.chk_merge = QCheckBox("Merge the episodes of each story\ninto one video")
        self.chk_merge.setToolTip(
            "When the queue is finished, every story whose episodes are ALL exported\n"
            "is joined in episode order: <story folder>/<story>_merged.mp4.\n"
            "A story with an episode missing (failed / stopped) is not joined.")
        self.chk_parts = QCheckBox("then cut into parts of")
        self.chk_parts.setChecked(True)
        self.spn_part_min = QSpinBox()
        self.spn_part_min.setRange(1, 600)
        self.spn_part_min.setValue(40)
        self.spn_part_min.setSuffix(" min")
        self.ed_part_name = QLineEdit("{story} ភាគ{n}")
        self.ed_part_name.setToolTip(
            "Name of the parts: {story} = the story's name, {n} = the part number (01, 02 …).\n"
            "The parts go to <story folder>/parts.")
        self.spn_part_start = QSpinBox()
        self.spn_part_start.setRange(0, 9999)
        self.spn_part_start.setValue(1)
        self.spn_part_start.setPrefix("from ")
        self.chk_kit = QCheckBox("Title + description + thumbnail\nfor every part")
        self.chk_kit.setChecked(True)
        self.chk_kit.setToolTip(
            "Next to every part: a .txt (title, description, hashtags - written by\n"
            "Gemini from what is said in that part when a Gemini key is set) and a\n"
            ".jpg thumbnail (a clear frame, the title, your logo).")
        self.chk_qc = QCheckBox("Quality check: list the lines to look at")
        self.chk_qc.setChecked(True)
        self.chk_qc.setToolTip(
            "After the queue: every line with no voice, not translated, sped up a lot,\n"
            "cut off at the end, or a character not surely man / woman - in a list\n"
            "(double-click → the editor opens there) and a qc_report CSV.")
        self.btn_glossary = QPushButton("📖 Glossary (names in every episode)…")
        self.btn_glossary.setToolTip(
            "Names / words translated the same way in every episode: 糖宝 → តាំងប៉ៅ.\n"
            "The story's list also learns the names Gemini chooses.")
        self.btn_glossary.clicked.connect(self._show_glossary)
        self.chk_sound = QCheckBox("Sound + Windows notification")
        self.chk_sound.setChecked(True)
        self.chk_shutdown = QCheckBox("Shut down the PC")
        self.chk_shutdown.setToolTip("Windows shuts down 2 minutes after the queue ends "
                                     "(you can cancel it)")

        def page(*rows):
            w = QWidget()
            f = QFormLayout(w)
            f.setContentsMargins(10, 12, 10, 10)
            f.setVerticalSpacing(10)
            f.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
            for r in rows:
                if isinstance(r, tuple):
                    f.addRow(*r)
                else:
                    f.addRow(r)
            # scrolls instead of squeezing the rows when the window is short
            sc = QScrollArea()
            sc.setWidgetResizable(True)
            sc.setFrameShape(QFrame.Shape.NoFrame)
            sc.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            sc.setWidget(w)
            return sc

        def head(text):
            lb = QLabel(text)
            lb.setObjectName("SideHead")
            return lb

        self.side_tabs = QTabWidget()
        self.side_tabs.setObjectName("SideTabs")
        # 2.3: the Dub page shows only what is chosen for every queue; the rest
        # (set once, or already decided by "Voice style") folds away
        self.dub_more = QWidget()
        more = QFormLayout(self.dub_more)
        more.setContentsMargins(0, 0, 0, 0)
        more.setVerticalSpacing(10)
        more.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        more.addRow("Speech", self.cmb_src)
        more.addRow("Voice speed", self.spn_speed)
        more.addRow(self.chk_stretch)
        more.addRow(self.chk_plain)
        more.addRow(head("🧠 SPEECH RECOGNITION"))
        more.addRow("Engine", self.cmb_stt)
        more.addRow("Whisper", self.cmb_model)
        more.addRow(self.chk_ocr)
        more.addRow(self.btn_keys)
        self.btn_dub_more = QPushButton()
        self.btn_dub_more.setFlat(True)
        self.btn_dub_more.setCheckable(True)

        def show_more(on):
            self.dub_more.setVisible(on)
            self.btn_dub_more.setText(("▾" if on else "▸") + "  More settings (speed, "
                                      "speech recognition, API keys)")
            settings.set("batch_dub_more", bool(on))

        self.btn_dub_more.toggled.connect(show_more)
        on = bool(settings.get("batch_dub_more", False))
        self.btn_dub_more.setChecked(on)
        show_more(on)
        self.side_tabs.addTab(page(
            head("BASE SETTINGS"), self.lb_base, self.btn_take,
            head("🌐 LANGUAGE"), ("Dub to", self.cmb_tgt), ("Translate", self.cmb_tr),
            head("🎙 AI VOICE"), ("Engine", self.cmb_engine), ("Voice", self.cmb_voice),
            ("Voice style", self.cmb_style), self.btn_test_voice,
            self.vox_box,
            head("WORKFLOW"), ("After dubbing", self.cmb_mode),
            self.btn_dub_more, self.dub_more), "⚙ Dub")
        self.side_tabs.addTab(page(
            head("SAVE TO"), out_row,
            head("VIDEO"), ("Resolution", self.cmb_res), ("Quality", self.cmb_quality),
            ("Encoder", self.cmb_encoder),
            head("SUBTITLES"), self.chk_burn, self.chk_srt,
            head("MERGE"), self.chk_same), "⬆ Output")
        tools_note = QLabel("The same tools as the editor, used for every video when it is "
                            "dubbed. Videos that are already dubbed keep their own.")
        tools_note.setWordWrap(True)
        tools_note.setObjectName("MutedLabel")
        self.side_tabs.addTab(page(
            head("TOOLS FOR EVERY VIDEO"), self.lb_tools, self.btn_tools, self.btn_style,
            self.btn_proj,
            self.btn_tools_reset, tools_note), "🛠 Tools")
        self.side_tabs.addTab(page(
            head("EACH VIDEO"), self.chk_cover, self.chk_bars,
            head("👥 CHARACTERS"), self.chk_series, self._series_note(),
            head("📖 TRANSLATION"), self.btn_glossary,
            head("SPEED"), self.chk_parallel, self._jobs_note()), "✨ Auto")
        report_note = QLabel("A CSV report (video, status, time, output) is saved in the "
                             "output folder after every run.")
        report_note.setWordWrap(True)
        report_note.setObjectName("MutedLabel")
        parts_row = QHBoxLayout()
        parts_row.addWidget(self.chk_parts)
        parts_row.addWidget(self.spn_part_min)
        parts_row.addStretch(1)
        name_row = QHBoxLayout()
        name_row.addWidget(self.ed_part_name, 1)
        name_row.addWidget(self.spn_part_start)
        self.side_tabs.addTab(page(
            head("🎬 EACH STORY"), self.chk_merge, parts_row, ("Part name", name_row),
            self.chk_kit,
            head("✅ CHECK"), self.chk_qc,
            head("WHEN THE QUEUE IS FINISHED"), self.chk_sound, self.chk_shutdown,
            head("REPORT"), report_note), "🔔 Finish")
        # 2.4: like SARIKA Studio - a rail of page buttons on the right edge;
        # the settings panel opens beside it and folds away (⚙ Settings or a
        # click on the open page), so the queue gets the whole width
        self.side_tabs.tabBar().hide()
        rail = QWidget()
        rail.setObjectName("SideRail")
        rail.setFixedWidth(78)
        rl = QVBoxLayout(rail)
        rl.setContentsMargins(6, 0, 0, 0)
        rl.setSpacing(6)
        self.side_buttons = []
        for i in range(self.side_tabs.count()):
            icon, _sp, name = self.side_tabs.tabText(i).partition(" ")
            b = QPushButton(f"{icon}\n{name}")
            b.setObjectName("RailButton")
            b.setCheckable(True)
            b.setMinimumHeight(62)
            b.setToolTip(name)
            b.clicked.connect(lambda _=False, i=i: self._rail_clicked(i))
            rl.addWidget(b)
            self.side_buttons.append(b)
        rl.addStretch(1)
        self.btn_rail_fold = QPushButton("»")
        self.btn_rail_fold.setObjectName("RailButton")
        self.btn_rail_fold.setToolTip("Hide / show the settings panel")
        self.btn_rail_fold.clicked.connect(lambda: self.toggle_settings())
        rl.addWidget(self.btn_rail_fold)
        self.rail = rail

        def sync(i):
            for k, b in enumerate(self.side_buttons):
                b.setChecked(k == i and not self.side.isHidden())

        self._sync_rail = lambda: sync(self.side_tabs.currentIndex())
        self.side_tabs.currentChanged.connect(sync)
        self.side = QFrame()
        self.side.setObjectName("DashPanel")
        sl = QVBoxLayout(self.side)
        sl.setContentsMargins(10, 10, 10, 10)
        sl.setSpacing(8)
        self.cmb_preset2 = QComboBox()           # the same presets as the strip
        self.cmb_preset2.activated.connect(
            lambda *_: self.apply_preset(self.cmb_preset2.currentData() or ""))
        b_psave = btn("💾 Save…", self.save_preset,
                      "Save these settings (language, voice, style, logo, blur, output, "
                      "tools) as a preset – also in the Editor")
        self.btn_preset_del = btn("🗑", self.delete_preset, "Delete the chosen preset")
        self.btn_preset_del.setFixedWidth(40)
        prow = QHBoxLayout()
        prow.addWidget(QLabel("⭐"))
        prow.addWidget(self.cmb_preset2, 1)
        prow.addWidget(b_psave)
        prow.addWidget(self.btn_preset_del)
        sl.addLayout(prow)
        sl.addWidget(self.side_tabs, 1)
        self.side.setMinimumWidth(400)

        # 2.4: always-visible summary strip above the queue
        self.cmb_preset = QComboBox()
        self.cmb_preset.setMinimumWidth(220)
        self.cmb_preset.setToolTip("Presets – the same as in the Editor")
        self.cmb_preset.activated.connect(
            lambda *_: self.apply_preset(self.cmb_preset.currentData() or ""))
        self.btn_summary = QPushButton()
        self.btn_summary.setObjectName("BaseSummary")
        self.btn_summary.setFlat(True)
        self.btn_summary.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_summary.setStyleSheet("text-align: left; padding: 6px 10px;")
        self.btn_summary.clicked.connect(lambda: self.open_settings())
        strip = QHBoxLayout()
        strip.setSpacing(8)
        lbp = QLabel("⭐ Preset")
        lbp.setObjectName("MutedLabel")
        strip.addWidget(lbp)
        strip.addWidget(self.cmb_preset)
        strip.addWidget(self.btn_summary, 1)
        self.summary_strip = strip
        self._fill_presets()

        for w in (self.cmb_res, self.cmb_quality, self.cmb_encoder, self.cmb_mode):
            w.currentIndexChanged.connect(lambda *_: self._save())
        for w in (self.chk_burn, self.chk_srt, self.chk_cover, self.chk_bars,
                  self.chk_series, self.chk_parallel, self.chk_sound, self.chk_same,
                  self.chk_merge, self.chk_parts, self.chk_kit, self.chk_qc):
            w.toggled.connect(lambda *_: self._save())
        for w in (self.spn_part_min, self.spn_part_start):
            w.valueChanged.connect(lambda *_: self._save())
        self.ed_part_name.editingFinished.connect(self._save)
        self.chk_parts.toggled.connect(lambda on: (self.spn_part_min.setEnabled(on),
                                                   self.chk_kit.setEnabled(on)))
        self.ed_out.editingFinished.connect(self._save)

        # ================= put it together =================
        body = QWidget()
        bl = QVBoxLayout(body)
        bl.setContentsMargins(16, 14, 16, 14)
        bl.setSpacing(10)
        bl.addLayout(cards_row)
        bl.addWidget(self.pb_total)
        bl.addWidget(self.lb_total)
        bl.addLayout(now_row)
        bl.addLayout(self.summary_strip)
        # the settings column can be made wider by dragging the bar between them
        split = QSplitter(Qt.Orientation.Horizontal)
        split.setChildrenCollapsible(False)
        split.setHandleWidth(10)
        # 2.3: the selected video on the left, the queue in the middle,
        # Dub / Output / Tools on the right (as before)
        from ui.batch_preview import BatchPreview

        self.preview = BatchPreview(self._preview_thumb)
        split.addWidget(self.preview)
        split.addWidget(queue)
        split.addWidget(self.side)
        split.setStretchFactor(0, 0)
        split.setStretchFactor(1, 1)
        split.setStretchFactor(2, 0)
        split.setSizes([400, 900, 460])
        self.split = split
        row = QHBoxLayout()
        row.setSpacing(0)
        row.addWidget(split, 1)
        row.addWidget(self.rail)
        bl.addLayout(row, 1)
        self.toggle_settings(bool(settings.get("batch_side_open", True)), save=False)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(top)
        lay.addWidget(body, 1)

    # ------------------------------------------------------------------ #
    # Dashboard widgets
    # ------------------------------------------------------------------ #
    def _idle_card(self, stage: str):
        th, nm, lb, pb = ((self.th_dub, self.nm_dub, self.lb_dub, self.pb_dub) if stage == "dub"
                          else (self.th_exp, self.nm_exp, self.lb_exp, self.pb_exp))
        th.clear()
        th.setText("🎙" if stage == "dub" else "⬆")
        nm.setText("Idle")
        lb.setText("")
        pb.setValue(0)

    def _busy_card(self, stage: str, it=None):
        """Show what this stage works on (the first job + how many more)."""
        jobs = self.dub_jobs if stage == "dub" else self.exp_jobs
        if not jobs:
            self._idle_card(stage)
            return
        items = [j[0] for j in jobs.values()]
        it = items[0]
        th, nm = (self.th_dub, self.nm_dub) if stage == "dub" else (self.th_exp, self.nm_exp)
        lang = it.target_lang or self._base_lang()
        more = f"   (+{len(items) - 1} more)" if len(items) > 1 else ""
        nm.setText(f"{os.path.splitext(os.path.basename(it.video_path))[0]}  ·  {lang}{more}")
        nm.setToolTip("\n".join(i.video_path for i in items))
        self._thumb_for(it.video_path, th)

    def _thumb_for(self, path: str, label: QLabel):
        """Show a frame of the video (made once in a thread, then cached)."""
        out = thumb_path(path)
        if os.path.isfile(out):
            pix = QPixmap(out)
            if not pix.isNull():
                label.setPixmap(pix.scaled(label.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                           Qt.TransformationMode.SmoothTransformation))
                return
        w = TaskWorker(lambda _p, _s: make_thumb(path, out), "thumb", self)
        w.done.connect(lambda res, lb=label, p=path: (
            self._thumb_for(p, lb) if res and self._card_shows(lb, p) else None))
        self._thumb_workers = [x for x in self._thumb_workers if x.isRunning()] + [w]
        w.start()

    def _card_shows(self, label, path) -> bool:
        cur = self.dub_cur if label is self.th_dub else self.exp_cur
        return cur is not None and cur.video_path == path

    # the first running job of each stage (dashboard card, tests)
    @property
    def dub_cur(self):
        return next(iter(self.dub_jobs.values()))[0] if self.dub_jobs else None

    @property
    def exp_cur(self):
        return next(iter(self.exp_jobs.values()))[0] if self.exp_jobs else None

    def _jobs_note(self) -> QLabel:
        lb = QLabel("How many videos run at the same time: <b>At once</b> next to ▶ Start "
                    "(1–8). 2–3 is a good start on a strong PC.")
        lb.setWordWrap(True)
        lb.setObjectName("MutedLabel")
        return lb

    def _jobs_changed(self, *_):
        self._save_later()
        if self.running:
            self._pump()            # more lanes: start more videos right away

    def _update_dashboard(self):
        items = self.items
        self.cards["total"].setText(str(len(items)))
        self.cards["done"].setText(str(sum(1 for i in items if i.status == batch.DONE)))
        self.cards["working"].setText(str(sum(1 for i in items if i.status in batch.ACTIVE)))
        self.cards["failed"].setText(str(sum(1 for i in items if i.status == batch.FAILED)))
        if not self.running:
            self.cards["left"].setText("–")
            # idle: how much of the whole queue is finished
            fin = sum(1 for i in items if i.status not in batch.PENDING + batch.ACTIVE
                      and i.status != batch.STOPPED)
            self.pb_total.setValue(int(fin * 100 / len(items)) if items else 0)
            if not items:
                self.lb_total.setText("Add videos (or drop them / a folder here), "
                                      "then click Start.")
            elif not (self.lb_total.property("_en_text") or self.lb_total.text()).startswith(
                    ("Queue ", "Added ")):          # (the English text, in any language)
                left = len(items) - fin
                self.lb_total.setText(f"{fin} of {len(items)} videos finished" +
                                      (f"  ·  {left} to do – click ▶ Start" if left else ""))
        self.queue_stack.setCurrentIndex(1 if items else 0)

    def _row_progress(self, it) -> int:
        """Progress shown in the queue row (-1 = no bar)."""
        if it.status in (batch.WAITING, batch.SKIPPED, batch.STOPPED, batch.FAILED):
            return -1
        return int(round(self._fraction(it) * 100))

    def _row(self, it) -> int:
        r = self._row_of.get(id(it), -1)
        if 0 <= r < len(self.items) and self.items[r] is it:
            return r
        return -1

    def _set_row_progress(self, it):
        r = self._row(it)
        if r < 0:
            return
        cell = self.table.item(r, COL_PROGRESS)
        if cell is not None:
            cell.setData(Qt.ItemDataRole.UserRole, self._row_progress(it))

    def _update_row(self, it):
        """One video changed status: update its row only (rebuilding thousands
        of rows on every change froze the window)."""
        r = self._row(it)
        if r < 0:
            self._refresh_table()
            return
        cell = self.table.item(r, COL_STATUS)
        if cell is not None:
            cell.setText(STATUS_TEXT.get(it.status, it.status))
            cell.setData(Qt.ItemDataRole.UserRole, it.status)
        cell = self.table.item(r, COL_RESULT)
        if cell is not None:
            cell.setText(it.message)
            cell.setToolTip(it.output or it.message)
        if self.preview.source == it.video_path and it in self._sel():
            self._show_in_preview(it)       # e.g. just exported: "Dubbed" can play
        self._set_row_progress(it)
        self._update_dashboard()
        self._update_buttons()
        self._save_later()

    def _save_later(self):
        self._save_timer.start()

    # ------------------------------------------------------------------ #
    # Save / load
    # ------------------------------------------------------------------ #
    def _series_note(self) -> QLabel:
        lb = QLabel("Characters are recognised by voice in every episode: no need to check "
                    "each one. Fix a name or voice once in the editor → the next episodes "
                    "use it.")
        lb.setWordWrap(True)
        lb.setObjectName("MutedLabel")
        return lb

    def _options(self) -> dict:
        return {
            "out_dir": self.ed_out.text().strip(),
            "resolution": self.cmb_res.currentData(),
            "crf": self.cmb_quality.currentData(),
            "encoder": self.cmb_encoder.currentData(),
            "mode": self.cmb_mode.currentData(),
            "burn": self.chk_burn.isChecked(),
            "srt": self.chk_srt.isChecked(),
            "auto_cover": self.chk_cover.isChecked(),
            "auto_crop": self.chk_bars.isChecked(),
            "series": self.chk_series.isChecked(),
            "parallel": self.chk_parallel.isChecked(),
            "jobs": self.spn_jobs.value(),
            "sound": self.chk_sound.isChecked(),
            "same_format": self.chk_same.isChecked(),
            "merge": self.chk_merge.isChecked(),
            "parts": self.chk_parts.isChecked(),
            "part_minutes": self.spn_part_min.value(),
            "part_name": self.ed_part_name.text(),
            "part_start": self.spn_part_start.value(),
            "kit": self.chk_kit.isChecked(),
            "qc": self.chk_qc.isChecked(),
            "base": self.base,
            "last_report": self.last_report,
            "batch_voice": True,
        }

    def _save(self):
        try:
            batch.save_queue(self.items, self._options(), self.queue_file)
        except Exception as e:
            print(f"[batch] could not save the queue: {e}")

    def _load(self):
        self.items, o = batch.load_queue(self.queue_file)

        def combo(c, v):
            i = c.findData(v)
            if i >= 0:
                c.setCurrentIndex(i)
        if o:
            self.ed_out.setText(o.get("out_dir") or self.work_root)
            combo(self.cmb_res, o.get("resolution"))
            combo(self.cmb_quality, o.get("crf"))
            combo(self.cmb_encoder, o.get("encoder"))
            combo(self.cmb_mode, o.get("mode"))
            self.chk_burn.setChecked(o.get("burn", True))
            self.chk_srt.setChecked(o.get("srt", True))
            self.chk_cover.setChecked(o.get("auto_cover", False))
            self.chk_bars.setChecked(o.get("auto_crop", False))
            self.chk_series.setChecked(o.get("series", True))
            self.chk_parallel.setChecked(o.get("parallel", True))
            self.spn_jobs.setValue(max(1, min(MAX_JOBS, int(o.get("jobs", 1) or 1))))
            self.chk_sound.setChecked(o.get("sound", True))
            self.chk_same.setChecked(o.get("same_format", True))
            self.chk_merge.setChecked(o.get("merge", False))
            self.chk_parts.setChecked(o.get("parts", True))
            self.spn_part_min.setValue(int(o.get("part_minutes", 40) or 40))
            self.ed_part_name.setText(o.get("part_name") or "{story} ភាគ{n}")
            self.spn_part_start.setValue(int(o.get("part_start", 1)))
            self.chk_kit.setChecked(o.get("kit", True))
            self.chk_qc.setChecked(o.get("qc", True))
            self.base = o.get("base") or {}
            self.last_report = o.get("last_report", "")
            if self.base and not o.get("batch_voice"):
                # queues saved before the batch had its own Voice choice took
                # the editor's single voice: switch them to Auto once
                if has_auto(self.base.get("tts_engine", "edge"), self.base.get("target_lang", "")):
                    self.base["voice"] = AUTO_VOICE
            if self.base and "stretch_video" not in self.base:
                # queues from before the natural-voice change sped long lines
                # up to 1.5 x (too fast): slow the video there instead
                self.base["stretch_video"] = True
                self.base["max_speed"] = min(float(self.base.get("max_speed", 1.1) or 1.1), 1.1)
        if not self.base:
            self.take_settings(save=False, voice=AUTO_VOICE)
        self._fill_voice_settings()
        self._fill_voices()
        self._fill_speech()
        self._refresh_table()

    def take_settings(self, save: bool = True, voice: Optional[str] = None):
        """Copy the main window settings. The batch Voice choice is kept
        (default Auto) unless it does not exist for the new language."""
        w = self.win
        w.left.apply_to_project(w.project)
        keep = voice or self.base.get("voice") or AUTO_VOICE
        self.base = batch.settings_of(w.project)
        engine, lang = self.base.get("tts_engine", "edge"), self.base.get("target_lang", "")
        ids = [v for v, _ in voices_for(engine, lang)]
        self.base["voice"] = keep if keep in ids else (
            AUTO_VOICE if has_auto(engine, lang) else (ids[0] if ids else ""))
        self._fill_voice_settings()
        self._fill_voices()
        self._fill_speech()
        self._show_base()
        if save:
            self._refresh_table()

    # ------------------------------------------------------------------ #
    # Editor tools for every video
    # ------------------------------------------------------------------ #
    def _queued_videos(self) -> List[str]:
        sel = [i.video_path for i in self._sel()]
        rest = [i.video_path for i in self.items if i.video_path not in sel]
        return list(dict.fromkeys(sel + rest))

    def open_tools(self, key: str = ""):
        from ui.batch_tools import NAV, BatchToolsDialog

        if not self.base:
            self.take_settings(save=False)
        dlg = BatchToolsDialog(self, self.base, self._queued_videos())
        keys = [k for _t, k in NAV]
        if key in keys:
            dlg.nav.setCurrentRow(keys.index(key))
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.base.update(dlg.values())
            if getattr(dlg, "auto_cover", False):     # 🔍 Auto detect was used
                self.chk_cover.setChecked(True)       # every video finds its own
            elif getattr(dlg, "cover_by_hand", False) and self.chk_cover.isChecked():
                self.chk_cover.setChecked(False)      # 2.4: the box placed by hand stays
                self.win.log("Batch: the hide box you placed is used for every video "
                             "(✨ Auto › find the original subtitles is now off)")
            self._show_base()
            self._save()

    def open_project_settings(self):
        from ui.dialogs import ProjectSettingsDialog

        if not self.base:
            self.take_settings(save=False)
        videos = self._queued_videos()
        try:
            q = batch.preview_project(self.base, videos[0]) if videos else None
        except Exception:
            q = None
        if q is None:
            q = Project()
            for k, v in self.base.items():
                if hasattr(q, k):
                    setattr(q, k, v)
        dlg = ProjectSettingsDialog(q, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.base.update(dlg.values())
            self._show_base()
            self._save()

    # ------------------------------------------------------------------ #
    # 2.4: ⚙ Settings window + presets (shared with the Editor)
    # ------------------------------------------------------------------ #
    def open_settings(self, page: int = -1):
        """Show the settings panel (at this page)."""
        if isinstance(page, int) and 0 <= page < self.side_tabs.count():
            self.side_tabs.setCurrentIndex(page)
        self.toggle_settings(True)

    def toggle_settings(self, on: Optional[bool] = None, save: bool = True):
        """⚙ Settings / » : fold the settings panel away or open it again."""
        on = self.side.isHidden() if on is None else bool(on)
        self.side.setVisible(on)
        self.btn_rail_fold.setText("»" if on else "«")
        self.btn_settings.setProperty("on", on)
        self.btn_settings.style().polish(self.btn_settings)
        self._sync_rail()
        if on:
            self._fill_presets()
        if save:
            settings.set("batch_side_open", on)

    def _rail_clicked(self, i: int):
        if not self.side.isHidden() and self.side_tabs.currentIndex() == i:
            self.toggle_settings(False)              # a click on the open page folds it
            return
        self.side_tabs.setCurrentIndex(i)
        self.toggle_settings(True)

    def _fill_presets(self, select: str = ""):
        from core import presets

        select = select or getattr(self, "_preset_name", "")
        for cmb in (self.cmb_preset, self.cmb_preset2):
            cmb.blockSignals(True)
            cmb.clear()
            cmb.addItem("— Choose a preset —", "")
            for name in presets.list_presets():
                cmb.addItem(("⭐ " if not presets.is_builtin(name) else "") + name, name)
            cmb.setCurrentIndex(max(0, cmb.findData(select)) if select else 0)
            cmb.blockSignals(False)
        self.btn_preset_del.setEnabled(bool(select) and select in presets.list_presets()
                                       and not presets.is_builtin(select))

    def apply_preset(self, name: str):
        from core import presets

        values = presets.get(name) if name else None
        if values is None:
            self._fill_presets()
            return
        if self.running:
            QMessageBox.information(self, "Batch queue",
                                    "Stop the queue first – a preset changes the settings of "
                                    "every video still waiting.")
            self._fill_presets()
            return
        if not self.base:
            self.take_settings(save=False)
        self.base = presets.apply_dict(self.base, values)
        engine, lang = self.base.get("tts_engine", "edge"), self.base.get("target_lang", "")
        ids = [v for v, _ in voices_for(engine, lang)]
        if self.base.get("voice") not in ids:
            self.base["voice"] = AUTO_VOICE if has_auto(engine, lang) else (ids[0] if ids else "")
        self._preset_name = name
        if values.get("cover_enabled") and self.chk_cover.isChecked():
            # 2.4: the preset's hide box is used exactly there (each video
            # looking for its own moved it to another place)
            self.chk_cover.setChecked(False)
            self.win.log("Batch: the preset's hide box is used for every video "
                         "(✨ Auto › find the original subtitles in each video is now off)")
        self._fill_voice_settings()
        self._fill_voices()
        self._fill_speech()
        self._show_base()
        self._fill_presets(name)
        self._refresh_table()
        self._save()
        self.win.log(f"⭐ Batch preset “{name}”")

    def save_preset(self):
        from PySide6.QtWidgets import QInputDialog

        from core import presets

        if not self.base:
            self.take_settings(save=False)
        name, ok = QInputDialog.getText(
            self, "Save as preset",
            "Preset name (e.g. “រឿងចិន → ខ្មែរ (F2 Movie)”, “TikTok 9:16”):\n"
            "Keeps language, voice, style, logo, blur, output size and tools.",
            text=getattr(self, "_preset_name", ""))
        name = presets.clean_name(name)
        if not ok or not name:
            return
        if name in presets.list_presets() and not presets.is_builtin(name):
            if QMessageBox.question(self, "Save as preset", f"Replace the preset “{name}”?") \
                    != QMessageBox.StandardButton.Yes:
                return
        presets.save(name, self.base)
        self._preset_name = name
        self._fill_presets(name)
        self.win.log(f"⭐ Saved preset “{name}” (also in the Editor)")
        left = getattr(self.win, "left", None)
        if left is not None and hasattr(left, "reload_presets"):
            left.reload_presets(left.cmb_preset.currentData() or "")

    def delete_preset(self):
        from core import presets

        name = self.cmb_preset2.currentData() or getattr(self, "_preset_name", "")
        if not name or presets.is_builtin(name):
            return
        if QMessageBox.question(self, "Delete preset", f"Delete the preset “{name}”?") \
                != QMessageBox.StandardButton.Yes:
            return
        presets.delete(name)
        self._preset_name = ""
        self._fill_presets()
        left = getattr(self.win, "left", None)
        if left is not None and hasattr(left, "reload_presets"):
            left.reload_presets()

    def reset_tools(self):
        from ui.batch_tools import EDIT_FIELDS

        fresh = Project()
        for k in EDIT_FIELDS:
            if k != "original_volume":
                self.base[k] = copy.deepcopy(getattr(fresh, k))
        self._show_base()
        self._save()

    def _fill_voices(self):
        engine, lang = self.base.get("tts_engine", "edge"), self._base_lang()
        self.cmb_voice.blockSignals(True)
        self.cmb_voice.clear()
        for vid, label in voices_for(engine, lang):
            self.cmb_voice.addItem(auto_label(engine, lang) + " – per line"
                                   if vid == AUTO_VOICE else label, vid)
        self.cmb_voice.setCurrentIndex(max(0, self.cmb_voice.findData(self.base.get("voice"))))
        self.cmb_voice.blockSignals(False)

    def _fill_voice_settings(self):
        """Dub to / Engine / Max speed from the queue's settings."""
        for w in (self.cmb_tgt, self.cmb_engine, self.spn_speed, self.chk_stretch, self.chk_plain):
            w.blockSignals(True)
        i = self.cmb_tgt.findData(self.base.get("target_lang", "km"))
        self.cmb_tgt.setCurrentIndex(max(0, i))
        i = self.cmb_engine.findData(self.base.get("tts_engine", "edge"))
        self.cmb_engine.setCurrentIndex(max(0, i))
        self.spn_speed.setValue(float(self.base.get("max_speed", 1.5) or 1.5))
        self.chk_stretch.setChecked(bool(self.base.get("stretch_video", False)))
        self.chk_plain.setChecked(bool(self.base.get("plain_voice", True)))
        for w in (self.cmb_tgt, self.cmb_engine, self.spn_speed, self.chk_stretch, self.chk_plain):
            w.blockSignals(False)
        self.cmb_style.follow()

    def _voice_setting_changed(self, *_):
        if not self.base:
            return
        old_lang, old_engine = self.base.get("target_lang"), self.base.get("tts_engine")
        self.base["target_lang"] = self.cmb_tgt.currentData()
        self.base["tts_engine"] = self.cmb_engine.currentData()
        self.base["max_speed"] = round(self.spn_speed.value(), 2)
        self.base["stretch_video"] = self.chk_stretch.isChecked()
        self.base["plain_voice"] = self.chk_plain.isChecked()
        if (old_lang, old_engine) != (self.base["target_lang"], self.base["tts_engine"]):
            ids = [v for v, _ in voices_for(self.base["tts_engine"], self.base["target_lang"])]
            if self.base.get("voice") not in ids:
                self.base["voice"] = AUTO_VOICE if AUTO_VOICE in ids else (ids[0] if ids else "")
            self._fill_voices()
        self._show_base()
        if hasattr(self, "vox_box"):
            self._vox_status()          # (the VoxCPM box shows / hides at once)
        self._refresh_table_soon()

    # ------------------------------------------------------------------ #
    # VoxCPM2 voice clone, right in the batch
    # ------------------------------------------------------------------ #
    def _voxcpm_box(self) -> QFrame:
        from core import voxcpm

        box = QFrame()
        box.setObjectName("DashPanel")
        f = QFormLayout(box)
        f.setContentsMargins(10, 8, 10, 8)
        head = QLabel("🎙 VOICE CLONE – VoxCPM2")
        head.setObjectName("SideHead")
        self.lb_vox = QLabel("")
        self.lb_vox.setWordWrap(True)
        self.lb_vox.setObjectName("MutedLabel")
        f.addRow(head)
        f.addRow(self.lb_vox)
        self.vox_refs = {}
        for g, label in (("male", "Male voice"), ("female", "Female voice")):
            ed = QLineEdit(settings.get(f"voxcpm_ref_{g}", "") or "")
            ed.setPlaceholderText("5–15 s recording (wav / mp3 / m4a)")
            ed.editingFinished.connect(lambda g=g, ed=ed: (
                settings.set(f"voxcpm_ref_{g}", ed.text().strip()), self._vox_status()))
            b = QPushButton("…")
            b.setFixedWidth(32)
            b.clicked.connect(lambda _=False, g=g, ed=ed: self._pick_vox_ref(g, ed))
            row = QHBoxLayout()
            row.addWidget(ed, 1)
            row.addWidget(b)
            f.addRow(label, row)
            self.vox_refs[g] = ed
        self.cmb_vox_steps = QComboBox()
        for n, name in voxcpm.STEPS.items():
            self.cmb_vox_steps.addItem(f"{name} ({n} steps)", n)
        self.cmb_vox_steps.setCurrentIndex(max(0, self.cmb_vox_steps.findData(
            int(settings.get("voxcpm_steps", 10) or 10))))
        self.cmb_vox_steps.currentIndexChanged.connect(
            lambda *_: settings.set("voxcpm_steps", self.cmb_vox_steps.currentData()))
        f.addRow("Quality", self.cmb_vox_steps)
        more = QPushButton("⚙ VoxCPM settings…")
        more.clicked.connect(lambda: (self.win.show_engines("voxcpm"), self._vox_status()))
        f.addRow(more)
        tip = QLabel("Slower than Edge (seconds per line on the GPU). If VoxCPM cannot run, "
                     "the queue goes on with Edge voices. Tip: 🗣 Language & voice… can give "
                     "only some rows VoxCPM2.")
        tip.setWordWrap(True)
        tip.setObjectName("MutedLabel")
        f.addRow(tip)
        return box

    def _pick_vox_ref(self, g: str, ed: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(
            self, f"{g.title()} reference voice", "",
            "Audio (*.wav *.mp3 *.m4a *.flac *.ogg *.aac)")
        if path:
            ed.setText(path)
            settings.set(f"voxcpm_ref_{g}", path)
            self._vox_status()

    def _vox_status(self):
        """Show the VoxCPM2 panel when the batch or a row uses it, with what is set up."""
        from core import voxcpm

        used = self.base.get("tts_engine") == "voxcpm" or any(
            i.engine == "voxcpm" for i in self.items)
        self.vox_box.setVisible(used)
        if not used:
            return
        py = (settings.get("voxcpm_python", "") or "").strip()
        if not py or voxcpm._same_as_app(py):
            py = next((c for c in voxcpm.candidates() if os.path.isfile(c)), "")
        refs = [g for g in ("male", "female") if settings.get(f"voxcpm_ref_{g}", "")]
        parts = [("✅ Python: " + py) if py else "❌ VoxCPM Python not found – ⚙ VoxCPM settings…"]
        parts.append(("✅ cloned: " + " + ".join(refs)) if refs else
                     "ℹ no reference voice – VoxCPM's own voice is used")
        self.lb_vox.setText("\n".join(parts))

    def _open_engines(self):
        tab = "voxcpm" if self.base.get("tts_engine") == "voxcpm" else "gemini"
        self.win.show_engines(tab)

    def _test_voice(self):
        """Play a sample line with the queue's engine and voice."""
        from ui.main_window import SAMPLE_TEXT
        from core.tts import synthesize

        engine, lang = self.base.get("tts_engine", "edge"), self._base_lang() or "km"
        voice = self.base.get("voice") or AUTO_VOICE
        if voice == AUTO_VOICE:
            voice = voice_for_gender(engine, lang, "male")
        out = os.path.join(self.work_root, f"batch_sample_{int(time.time())}.wav")
        os.makedirs(self.work_root, exist_ok=True)
        self.btn_test_voice.setEnabled(False)
        w = TaskWorker(lambda p, s: synthesize(SAMPLE_TEXT.get(lang, SAMPLE_TEXT["en"]), out,
                                               engine, voice, lang), "Test voice", self)

        def done(path):
            self.btn_test_voice.setEnabled(True)
            self.win.sample_player.setSource(QUrl.fromLocalFile(path))
            self.win.sample_player.play()

        def failed(err):
            self.btn_test_voice.setEnabled(True)
            QMessageBox.warning(self, "Test voice", err)

        w.done.connect(done)
        w.failed.connect(failed)
        self._thumb_workers.append(w)
        w.start()

    def _fill_speech(self):
        for combo, key, default in ((self.cmb_src, "source_lang", "auto"),
                                    (self.cmb_model, "whisper_model", "small"),
                                    (self.cmb_stt, "stt_engine", "whisper"),
                                    (self.cmb_tr, "translate_engine", "google")):
            combo.blockSignals(True)
            i = combo.findData(self.base.get(key, default))
            combo.setCurrentIndex(i if i >= 0 else max(0, combo.findData(default)))
            combo.blockSignals(False)
        self.chk_ocr.blockSignals(True)
        self.chk_ocr.setChecked(bool(self.base.get("ocr_check", True)))
        self.chk_ocr.blockSignals(False)

    def _speech_changed(self):
        if self.base:
            self.base["source_lang"] = self.cmb_src.currentData()
            self.base["whisper_model"] = self.cmb_model.currentData()
            self.base["stt_engine"] = self.cmb_stt.currentData()
            self.base["translate_engine"] = self.cmb_tr.currentData()
            self.base["ocr_check"] = self.chk_ocr.isChecked()
            self._show_base()
            self._save()

    def _voice_changed(self):
        vid = self.cmb_voice.currentData()
        if vid is not None and self.base:
            self.base["voice"] = vid
            self._refresh_table()

    def _show_base(self):
        # the queue's tools changed: the Preview shows the new look
        prev = getattr(self, "preview", None)
        if prev is not None and prev.source:
            prev.refresh_poster(prev.source)
        b = self.base
        if not b:
            self.lb_base.setText("")
            return
        extras = []
        if b.get("logo_path"):
            extras.append("logo")
        if b.get("brand_text"):
            extras.append("brand text")
        if b.get("cover_enabled"):
            extras.append("hide original subtitles")
        tools = batch.tools_summary(b)
        self.lb_tools.setText("🛠  " + " · ".join(tools) if tools
                              else "No tools – every video is exported as it is.")
        # Speech → Dub to in front: a wrong Speech (Khmer for a Chinese drama)
        # is seen at once, not hidden under ▸ More settings
        src, tgt = b.get("source_lang", "auto") or "auto", b.get("target_lang", "")
        speech = "Auto detect" if src == "auto" else lang_name(src)
        same = src != "auto" and src == tgt
        self.lb_base.setText(
            ("⚠ " if same else "") + f"Speech: {speech} → {lang_name(tgt)} · "
            f"{voice_name(b.get('tts_engine', 'edge'), tgt, b.get('voice', ''))}"
            f" · {b.get('tts_engine', '')}"
            + (" · " + ", ".join(extras) if extras else ""))
        self.lb_base.setStyleSheet("color: #ffb84d;" if same else "")
        if hasattr(self, "btn_summary"):
            from core import presets

            text = presets.summary(b)
            if tools:
                text += f" · 🛠 {len(tools)}"
            self.btn_summary.setText(("⚠ " if same else "") + text + "   ⚙")
            self.btn_summary.setStyleSheet(
                "text-align: left; padding: 6px 10px;" + (" color: #ffb84d;" if same else ""))
            self.btn_summary.setToolTip(self.lb_base.text() + "\nClick: ⚙ Settings")
        self.lb_base.setToolTip(
            "Speech is the SAME language as Dub to – for a Chinese video choose Speech = "
            "Auto detect (▸ More settings)." if same else
            "Rows without their own language / voice use these settings")

    # ------------------------------------------------------------------ #
    # Queue list
    # ------------------------------------------------------------------ #
    def _base_lang(self) -> str:
        return self.base.get("target_lang", "")

    def _keys(self):
        return {i.key(self._base_lang()) for i in self.items}

    def add_videos(self, paths, lang: str = ""):
        """Add videos and folders. Every video found in a folder remembers its
        story (the sub-folder it is in) so it is exported into that story's
        own output folder."""
        known = self._keys()
        found = []
        for p in paths:
            if os.path.isdir(p):
                found += batch.find_stories(p)
            else:
                found.append((p, ""))
        for p, story in found:
            if not (os.path.isfile(p) and p.lower().endswith(batch.VIDEO_EXT)):
                continue
            it = batch.BatchItem(os.path.abspath(p), target_lang=lang, story=story)
            if it.key(self._base_lang()) not in known:
                known.add(it.key(self._base_lang()))
                self.items.append(it)
        self._refresh_table()

    def _browse(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Add videos to the queue", "",
            "Video files (*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.ts *.m2ts *.mts *.flv *.wmv *.mpg *.mpeg *.3gp *.vob)")
        self.add_videos(paths)

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Add all videos in a folder")
        if d:
            n = len(self.items)
            self.add_videos([d])
            stories = {i.story for i in self.items[n:]}
            self.lb_total.setText(f"Added {len(self.items) - n} videos in {len(stories)} "
                                  f"stor{'y' if len(stories) == 1 else 'ies'} from {d}")

    def _browse_out(self):
        d = QFileDialog.getExistingDirectory(self, "Save dubbed videos to", self.ed_out.text())
        if d:
            self.ed_out.setText(d)
            self._save()

    def _rows(self) -> List[int]:
        return sorted({i.row() for i in self.table.selectedIndexes()})

    def _sel(self) -> List[batch.BatchItem]:
        return [self.items[r] for r in self._rows() if r < len(self.items)]

    def _select(self, items):
        self.table.clearSelection()
        mode = self.table.selectionMode()
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.MultiSelection)
        for it in items:
            if it in self.items:
                self.table.selectRow(self.items.index(it))
        self.table.setSelectionMode(mode)

    def _busy(self, it) -> bool:
        return it.status in batch.ACTIVE

    def _remove_selected(self):
        drop = [i for i in self._sel() if not self._busy(i)]
        self.items = [i for i in self.items if i not in drop]
        self._refresh_table()

    def _remove_all(self):
        if not self.items:
            return
        keep = [i for i in self.items if self._busy(i)]
        n = len(self.items) - len(keep)
        if not n:
            return
        msg = f"Remove all {n} videos from the queue?"
        if keep:
            msg += f"\n({len(keep)} being worked on now will stay.)"
        msg += "\n\nFinished videos and their files are not deleted."
        ans = QMessageBox.question(self, "Remove all", msg)
        if ans != QMessageBox.StandardButton.Yes:
            return
        self.items = keep
        self._refresh_table()

    def _clear_done(self):
        self.items = [i for i in self.items if i.status not in (batch.DONE, batch.SKIPPED)]
        self._refresh_table()

    def _move(self, step: int):
        sel = self._sel()
        if not sel:
            return
        order = sel if step < 0 else list(reversed(sel))
        for it in order:
            i = self.items.index(it)
            j = i + step
            if 0 <= j < len(self.items) and self.items[j] not in sel:
                self.items[i], self.items[j] = self.items[j], self.items[i]
        self._refresh_table()
        self._select(sel)

    def _retry(self):
        for it in self._sel():
            if it.status in (batch.FAILED, batch.STOPPED, batch.SKIPPED, batch.DONE,
                             batch.DUBBED):
                it.status, it.message = batch.WAITING, ""
        self._refresh_table()
        if self.running:
            self._pump()

    def _show_failed(self):
        """Failed card: select the failed videos (scrolled to the first) and
        offer to start them again."""
        failed = [i for i in self.items if i.status == batch.FAILED]
        if not failed:
            return
        self._select(failed)
        self.table.scrollToItem(self.table.item(self.items.index(failed[0]), 0),
                                QAbstractItemView.ScrollHint.PositionAtCenter)
        ans = QMessageBox.question(
            self, "Failed videos",
            f"{len(failed)} video(s) failed – they are selected in the queue "
            f"(the reason is in the Result column).\n\nStart them again now?")
        if ans == QMessageBox.StandardButton.Yes:
            self._start_rows(failed)

    def _start_rows(self, items=None):
        """Right-click › Start these now: the chosen videos go first. A queue
        that is not running runs only them; a running queue takes them next."""
        if not isinstance(items, (list, tuple)):    # (a menu click passes checked=False)
            items = None
        sel = [i for i in (items if items is not None else self._sel()) if not self._busy(i)]
        if not sel:
            return
        for it in sel:
            it.status, it.message = batch.WAITING, ""
            self._later.pop(id(it), None)
        self.items = sel + [i for i in self.items if i not in sel]     # first in line
        self._refresh_table()
        self._select(sel)
        self._save()
        if self.running:
            if self._only:                  # running "only these": add them
                self._only.update(id(i) for i in sel)
            for i in sel:
                if i not in self._run_items:
                    i.seconds = 0.0         # "Time spent": this run only
                    self._run_items.append(i)
            self._pump()
        else:
            self.start(only=sel)

    def _redo_rows(self):
        """Throw the earlier work away (transcript, translation, voices) and dub
        the selected videos again - e.g. after a wrong Speech language. The old
        work folder stays on disk; the exported video is replaced."""
        sel = [it for it in self._sel() if not self._busy(it)]
        if not sel:
            return
        ans = QMessageBox.question(
            self, "Dub again",
            f"Dub {len(sel)} video(s) again from the start?\n"
            "The transcript, translation and voices are made new (with the settings now).")
        if ans != QMessageBox.StandardButton.Yes:
            return
        for it in sel:
            it.work_dir = ""                    # a fresh work folder on the next run
            it.status, it.message = batch.WAITING, ""
        self._refresh_table()
        self._save()
        if self.running:
            self._pump()

    def _skip_rows(self):
        for it in self._sel():
            if self._busy(it):
                self._skip.add(id(it))
                job = self.dub_jobs.get(id(it)) or self.exp_jobs.get(id(it))
                if job:
                    job[1].stop()
            elif it.status in batch.PENDING:
                it.status, it.message = batch.SKIPPED, ""
        self._refresh_table()

    def _add_languages(self):
        sel = self._sel()
        if not sel:
            QMessageBox.information(self, "Add languages", "Select one or more videos first.")
            return
        dlg = LanguagesDialog(self, skip=self._base_lang())
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        videos = []
        for it in sel:
            if it.video_path not in videos:
                videos.append(it.video_path)
        known = self._keys()
        for code in dlg.codes():
            for v in videos:
                new = batch.BatchItem(v, target_lang=code)
                if new.key(self._base_lang()) not in known:
                    known.add(new.key(self._base_lang()))
                    # keep the languages of one video next to each other
                    last = max(i for i, x in enumerate(self.items) if x.video_path == v)
                    self.items.insert(last + 1, new)
        self._refresh_table()

    def _item_settings(self):
        sel = [i for i in self._sel() if not self._busy(i)]
        if not sel:
            QMessageBox.information(self, "Language & voice",
                                    "Select one or more videos that are not running.")
            return
        dlg = ItemSettingsDialog(self, self.base.get("tts_engine", "edge"),
                                 sel[0].target_lang, sel[0].voice, self._base_lang(),
                                 sel[0].engine)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        lang, engine, voice = dlg.values()
        for it in sel:
            if (lang, engine, voice) == (it.target_lang, it.engine, it.voice):
                continue
            it.target_lang, it.engine, it.voice = lang, engine, voice
            if it.work_dir:         # dub again with the new language / voice
                it.work_dir, it.output = "", ""
            it.status, it.message = batch.WAITING, ""
        self._refresh_table()

    def _refresh_table(self):
        if hasattr(self, "vox_box"):
            self._vox_status()
        engine = self.base.get("tts_engine", "edge")
        base_lang = self._base_lang()
        # Filling the cells with "resize to contents" columns measured EVERY
        # row again after EVERY cell (100 videos = 160 000 measures, ~10 s per
        # refresh): the columns are fixed while filling and measured once after.
        hh = self.table.horizontalHeader()
        modes = [hh.sectionResizeMode(c) for c in range(self.table.columnCount())]
        for c, m in enumerate(modes):
            if m == QHeaderView.ResizeMode.ResizeToContents:
                hh.setSectionResizeMode(c, QHeaderView.ResizeMode.Interactive)
        self.table.setUpdatesEnabled(False)
        try:
            self._fill_rows(engine, base_lang)
        finally:
            for c, m in enumerate(modes):
                hh.setSectionResizeMode(c, m)
            self.table.setUpdatesEnabled(True)
        self._show_base()
        self._update_dashboard()
        self._update_buttons()
        self._save()

    def _refresh_table_soon(self):
        """Several settings change at once (Voice style sets the speed AND
        'slow the video'): one table refresh after them, not one each."""
        if not hasattr(self, "_refresh_timer"):
            self._refresh_timer = QTimer(self)
            self._refresh_timer.setSingleShot(True)
            self._refresh_timer.setInterval(0)
            self._refresh_timer.timeout.connect(self._refresh_table)
        self._refresh_timer.start()

    def _fill_rows(self, engine: str, base_lang: str):
        self.table.setRowCount(len(self.items))
        self._row_of = {id(it): r for r, it in enumerate(self.items)}
        self._start_probe()
        for r, it in enumerate(self.items):
            lang = it.target_lang or base_lang
            own = it.engine and it.engine != engine
            row_engine = it.engine or engine
            voice = it.voice or (self.base.get("voice", "") if not own and (
                not it.target_lang or it.target_lang == base_lang) else AUTO_VOICE)
            cells = [
                os.path.basename(it.video_path),
                it.story or "—",
                lang_name(lang) + ("" if it.target_lang else " ·"),
                ("🎙 VoxCPM2 · " if row_engine == "voxcpm" else
                 f"{TTS_ENGINES.get(row_engine, row_engine).split(' ')[0]} · " if own else "")
                + voice_name(row_engine, lang, voice),
                format_time(it.duration, False) if it.duration else "",
                STATUS_TEXT.get(it.status, it.status),
                "",
                it.message,
            ]
            tips = [it.video_path,
                    f"Exported into the ‘{it.story}’ folder" if it.story else
                    "Single video – exported straight into the output folder",
                    "· = batch settings" if not it.target_lang else "",
                    "", "", "", "", it.output or it.message]
            for c, (text, tip) in enumerate(zip(cells, tips)):
                cell = QTableWidgetItem(text)
                if tip:
                    cell.setToolTip(tip)
                if c == COL_STATUS:
                    cell.setData(Qt.ItemDataRole.UserRole, it.status)
                elif c == COL_PROGRESS:
                    cell.setData(Qt.ItemDataRole.UserRole, self._row_progress(it))
                elif c == 0:
                    icon = self._row_icon(it.video_path)
                    if icon is not None:
                        cell.setIcon(icon)
                self.table.setItem(r, c, cell)

    def _row_icon(self, path: str) -> Optional[QIcon]:
        """The video's frame for its row (made in the background the first time)."""
        icon = self._row_icons.get(path)
        if icon is not None:
            return icon
        out = thumb_path(path)
        if os.path.isfile(out):
            pix = QPixmap(out)
            if not pix.isNull():
                # fill the box (a tall 9:16 video would be a thin strip): centre crop
                pix = pix.scaled(ROW_THUMB, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                 Qt.TransformationMode.SmoothTransformation)
                x = max(0, (pix.width() - ROW_THUMB.width()) // 2)
                y = max(0, (pix.height() - ROW_THUMB.height()) // 2)
                icon = QIcon(pix.copy(x, y, ROW_THUMB.width(), ROW_THUMB.height()))
                self._row_icons[path] = icon
                return icon
        self.thumbs.want(path)
        return None

    # ---- the preview on the left
    def _preview_thumb(self, path: str):
        """(frame, still making the export look?) for the Preview."""
        waiting = False
        if self.base:
            styled = self.styled.want(path, self.base, self.chk_burn.isChecked())
            if styled:
                return styled, False        # as exported with the queue's tools
            waiting = True
        big = thumb_path(path, True)
        if os.path.isfile(big):
            return big, waiting
        self.big_thumbs.want(path)          # shown when ready
        small = thumb_path(path)
        return (small if os.path.isfile(small) else ""), waiting

    def _preview_selected(self):
        sel = self._sel()
        it = sel[0] if sel else None
        if it is None:
            return
        self._show_in_preview(it)
        # the next rows too (in the background): they show at once when clicked
        if self.base and it in self.items:
            i = self.items.index(it)
            burn = self.chk_burn.isChecked()
            for nxt in self.items[i + 1:i + 1 + PREFETCH] + self.items[max(0, i - 2):i]:
                self.styled.want(nxt.video_path, self.base, burn, later=True)

    def _show_in_preview(self, it):
        lang = it.target_lang or self._base_lang()
        bits = [lang_name(lang)] if lang else []
        if it.duration:
            bits.append(format_time(it.duration, False))
        bits.append(STATUS_TEXT.get(it.status, it.status))
        if it.output and os.path.isfile(it.output):
            bits.append("Dubbed: " + os.path.basename(it.output))
        self.preview.set_item(it.video_path, it.output, " · ".join(bits))

    def _thumb_ready(self, path: str):
        self.preview.refresh_poster(path)
        icon = self._row_icon(path)
        if icon is None:
            return
        for r, it in enumerate(self.items):
            if it.video_path == path:
                cell = self.table.item(r, 0)
                if cell is not None:
                    cell.setIcon(icon)

    def _update_buttons(self):
        sel = self._sel()
        has_dubbed = any(i.status in (batch.DUBBED, batch.DONE) for i in sel)
        self.btn_start.setEnabled(not self.running and any(
            i.status not in (batch.DONE, batch.DUBBED, batch.SKIPPED) for i in self.items))
        self.btn_stop.setEnabled(self.running)
        self.btn_export_sel.setEnabled(has_dubbed)
        self.btn_export_all.setEnabled(any(i.status == batch.DUBBED for i in self.items))
        self.btn_edit.setEnabled(len(sel) == 1 and bool(sel[0].work_dir)
                                 and not self._busy(sel[0]))
        for b in (self.btn_langs, self.btn_item, self.btn_up, self.btn_down, self.btn_retry,
                  self.btn_skip, self.btn_remove):
            b.setEnabled(bool(sel))
        self.btn_report.setEnabled(bool(self.last_report) and os.path.isfile(self.last_report))
        self.btn_merge.setEnabled(sum(1 for i in self.items if i.status == batch.DONE
                                      and i.output) >= 2)
        for w in (self.cmb_res, self.cmb_quality, self.cmb_encoder, self.chk_burn,
                  self.chk_srt, self.ed_out, self.chk_parallel, self.btn_take, self.chk_cover,
                  self.chk_bars, self.chk_series,
                  self.cmb_voice, self.cmb_src, self.cmb_model):
            w.setEnabled(not self.running)
        self.btn_remove_all.setEnabled(any(not self._busy(i) for i in self.items))

    def _menu(self, pos):
        if not self._sel():
            return
        m = QMenu(self)
        idle = [i for i in self._sel() if not self._busy(i)]
        for text, slot, ok in (
                ("▶ Start these now", lambda: self._start_rows(), bool(idle)),
                (None, None, None),
                ("✏ Edit in editor", lambda: self._edit_rows(self._rows()),
                 self.btn_edit.isEnabled()),
                ("⬆ Export", self._export_selected, self.btn_export_sel.isEnabled()),
                (None, None, None),
                ("Language & voice…", self._item_settings, True),
                ("🌐 Add languages…", self._add_languages, True),
                (None, None, None),
                ("↻ Retry", self._retry, True),
                ("↺ Dub again from the start (new transcript)", self._redo_rows, True),
                ("⏭ Skip", self._skip_rows, True),
                ("▲ Move up", lambda: self._move(-1), True),
                ("▼ Move down", lambda: self._move(1), True),
                (None, None, None),
                ("📂 Open result folder", self._open_item_folder, True),
                ("Remove", self._remove_selected, True)):
            if text is None:
                m.addSeparator()
                continue
            a = m.addAction(text)
            a.setEnabled(ok)
            a.triggered.connect(slot)
        m.exec(self.table.viewport().mapToGlobal(pos))

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        self.add_videos([os.path.normpath(u.toLocalFile()) for u in event.mimeData().urls()])

    def _start_probe(self):
        """Read the length of new videos in a background thread."""
        todo = [it for it in self.items if not it.duration and not getattr(it, "_probed", False)]
        if not todo or (self._probe_thread and self._probe_thread.is_alive()):
            if todo and not self._probe.isActive():
                self._probe.start()
            return
        for it in todo:
            it._probed = True
        ready = self._probe_ready

        def work():
            for it in todo:
                try:
                    it.duration = get_media_info(it.video_path).duration
                except Exception:
                    continue
                ready.append(it)

        self._probe_thread = threading.Thread(target=work, daemon=True)
        self._probe_thread.start()
        self._probe.start()

    def _probe_next(self):
        """Show the lengths the background thread has read so far."""
        while self._probe_ready:
            it = self._probe_ready.pop(0)
            r = self._row(it)
            if r >= 0:
                self.table.setItem(r, COL_LENGTH,
                                   QTableWidgetItem(format_time(it.duration, False)))
        if not (self._probe_thread and self._probe_thread.is_alive()):
            if any(not i.duration and not getattr(i, "_probed", False) for i in self.items):
                self._start_probe()
            elif not self._probe_ready:
                self._probe.stop()

    def _open_item_folder(self):
        from ui.main_window import open_path
        for it in self._sel()[:1]:
            open_path(os.path.dirname(it.output) if it.output else self.ed_out.text())

    def _open_folder(self):
        from ui.main_window import open_path
        os.makedirs(self.ed_out.text(), exist_ok=True)
        open_path(self.ed_out.text())

    def _done_items(self) -> List[batch.BatchItem]:
        """Exported items in queue order (selected rows only, if 2+ are selected)."""
        rows = [i for i in self._sel() if i.status == batch.DONE and i.output]
        pool = rows if len(rows) >= 2 else [i for i in self.items if i.status == batch.DONE
                                            and i.output]
        return [i for i in pool if os.path.isfile(i.output)]

    def done_outputs(self) -> List[str]:
        return [i.output for i in self._done_items()]

    def _merge_done(self):
        """Join the exported episodes of one story into one video."""
        items = self._done_items()
        stories = list(dict.fromkeys(i.story for i in items))
        if len(stories) > 1:            # never join episodes of different stories
            sel = list({i.story for i in self._sel()})
            if len(sel) == 1 and sel[0] in stories:
                story = sel[0]
            else:
                story, ok = QInputDialog.getItem(
                    self, "Merge", "Which story should be joined into one video?",
                    [s or "(single videos)" for s in stories], 0, False)
                if not ok:
                    return
                story = "" if story == "(single videos)" else story
            items = [i for i in items if i.story == story]
        paths = [i.output for i in items]
        if len(paths) < 2:
            QMessageBox.information(self, "Merge", "At least 2 exported videos are needed.")
            return
        name = os.path.basename((items[0].story or "").rstrip("/")) or \
            os.path.basename(os.path.dirname(items[0].video_path)) or "merged"
        out = os.path.join(os.path.dirname(paths[0]), f"{batch.safe_name(name)}_merged.mp4")
        self.win.show_merge_split(paths, out)

    def run_qc(self):
        """✅ Quality check of the finished videos (selected, or all) - any time,
        not only at the end of a queue."""
        sel = [i for i in self._sel() if i.status in (batch.DONE, batch.DUBBED)]
        items = sel or [i for i in self.items if i.status in (batch.DONE, batch.DUBBED)]
        if not items:
            QMessageBox.information(self, "Quality check",
                                    "No dubbed / exported video yet in the queue.")
            return
        if getattr(self, "_qc_worker", None) is not None and self._qc_worker.isRunning():
            return
        lang = self._base_lang()
        keys = {i.key(lang) for i in items}
        out_dir = self.ed_out.text().strip() or self.work_root
        cfg = after_queue_config(self)
        self.btn_qc.setEnabled(False)
        self.btn_qc.setText("✅ Checking…")
        w = TaskWorker(lambda prog, stop: after_queue(items, keys, out_dir, lang, cfg, True,
                                                      False, prog, stop), "Quality check", self)

        def done(res):
            self.btn_qc.setEnabled(True)
            self.btn_qc.setText("✅ Quality check")
            rows = (res or {}).get("qc", [])
            self.win.log(f"✅ Quality check: {len(rows)} lines to look at in {len(items)} videos")
            if not rows:
                QMessageBox.information(self, "Quality check",
                                        f"✓ Nothing to look at in {len(items)} videos.")
                return
            from ui.qc_dialog import QCDialog

            QCDialog(self.win, rows, res.get("qc_csv", ""), res.get("episodes", 0)).show()

        def failed(e):
            self.btn_qc.setEnabled(True)
            self.btn_qc.setText("✅ Quality check")
            self.win.log(f"Quality check failed: {e}")

        w.progress.connect(lambda p, m: self.btn_qc.setText(f"✅ {p}%"))
        w.done.connect(done)
        w.failed.connect(failed)
        self._qc_worker = w
        w.start()

    def _open_report(self):
        from ui.main_window import open_path
        if self.last_report and os.path.isfile(self.last_report):
            open_path(self.last_report)

    def _edit_rows(self, rows):
        if not rows:
            return
        it = self.items[rows[0]]
        if self._busy(it):
            QMessageBox.information(self, "Edit", "This video is being worked on right now.")
            return
        if not (it.autosave() and os.path.isfile(it.autosave())):
            QMessageBox.information(self, "Edit", "This video was not dubbed yet.")
            return
        if self.win.open_batch_item(it.autosave()):
            self.win.raise_()
            self.win.activateWindow()

    # ------------------------------------------------------------------ #
    # Running
    # ------------------------------------------------------------------ #
    def is_running(self) -> bool:
        return self.running

    def is_busy_dir(self, work_dir: str) -> bool:
        """The queue is changing the files of this work folder right now."""
        return bool(work_dir) and any(
            it.work_dir and os.path.normcase(it.work_dir) == os.path.normcase(work_dir)
            for it, _w in self.dub_jobs.values())

    def _export_opts(self) -> ExportOptions:
        return ExportOptions(
            output_path="",
            resolution=self.cmb_res.currentData(),
            burn_subtitles=self.chk_burn.isChecked(),
            export_srt=self.chk_srt.isChecked(),
            crf=int(self.cmb_quality.currentData()),
            subtitle_font="",               # by language (see batch.export_item)
            encoder=self.cmb_encoder.currentData(),
            watermark=lic.watermark_text(),
            loudness=LOUDNESS if settings.get("export_loudness", True) else 0.0,
        )

    def _rights_ok(self) -> bool:
        """Stories in the queue without rights (or with an ended licence): ask first."""
        from core import rights

        todo = [i for i in self.items if i.status in (batch.WAITING, batch.EXPORT_WAIT,
                                                      batch.DUBBED)]
        bad = {}
        for it in todo:
            key, state, text = rights.check(it.video_path, it.story)
            if state in ("missing", "expired"):
                bad.setdefault(key, text)
        if not bad:
            return True
        names = "\n".join(f"• {k}: {t}" for k, t in list(bad.items())[:8])
        ans = QMessageBox.question(
            self, "Rights",
            f"These stories have no rights recorded, or the licence has ended:\n\n{names}\n\n"
            "Tools › © Copyright check records them. Start anyway?")
        return ans == QMessageBox.StandardButton.Yes

    # ------------------------------------------------------------------ #
    # 2.6.10: checked before the queue starts, so a problem is told at once
    # and not after an hour (videos moved out of D:\21_10_2026, 3/11)
    # ------------------------------------------------------------------ #
    MB_PER_MINUTE = 250             # work files + dubbed video, per minute of video
    MB_SPARE = 1024

    def _preflight_ok(self) -> bool:
        return self._videos_there() and self._disk_ok() and self._gemini_ok()

    def _videos_there(self) -> bool:
        gone = [i for i in self._run_items if not os.path.isfile(i.video_path)]
        if not gone:
            return True
        names = "\n".join(f"• {i.video_path}" for i in gone[:8])
        more = f"\n… and {len(gone) - 8} more" if len(gone) > 8 else ""
        for it in gone:
            it.status = batch.FAILED
            it.message = "The original video is not there any more (moved, renamed or deleted)"
        self._run_items = [i for i in self._run_items if i not in gone]
        self._save()
        if not self._run_items:
            QMessageBox.warning(
                self, "Batch queue",
                f"The videos are not there any more – they were moved, renamed or "
                f"deleted:\n\n{names}{more}\n\nRemove them from the queue and add them "
                f"again from their new folder.")
            return False
        ans = QMessageBox.question(
            self, "Batch queue",
            f"{len(gone)} video(s) are not there any more – moved, renamed or deleted "
            f"(marked Failed):\n\n{names}{more}\n\nStart the other "
            f"{len(self._run_items)} video(s)?")
        return ans == QMessageBox.StandardButton.Yes

    def _disk_need_mb(self) -> float:
        mins = sum(max(i.duration, 120.0) / 60.0 for i in self._run_items)
        return self.MB_SPARE + mins * self.MB_PER_MINUTE

    def _disk_ok(self) -> bool:
        import shutil

        need = self._disk_need_mb()
        low = []
        seen = set()
        for folder in (self.ed_out.text().strip(), self.work_root):
            if not folder:
                continue
            probe = folder
            while probe and not os.path.isdir(probe):
                up = os.path.dirname(probe)
                if up == probe:
                    break
                probe = up
            try:
                du = shutil.disk_usage(probe)
            except OSError:
                continue
            drive = os.path.splitdrive(os.path.abspath(probe))[0] or probe
            if drive in seen:
                continue
            seen.add(drive)
            free = du.free / 1048576
            if free < need:
                low.append(f"• {drive}  {free / 1024:.1f} GB free")
        if not low:
            return True
        ans = QMessageBox.question(
            self, "Batch queue",
            "The disk is almost full:\n\n" + "\n".join(low) +
            f"\n\nThis queue needs about {need / 1024:.1f} GB (work files and the dubbed "
            f"videos). A full disk stops the queue half way.\n\nStart anyway?")
        return ans == QMessageBox.StandardButton.Yes

    _key_checked: Dict[str, tuple] = {}     # key -> (time, reason)
    KEY_CHECK_TTL = 1800

    def _gemini_used(self) -> bool:
        from core import gemini

        if not gemini.configured():
            return False
        return "gemini" in (self.base.get("stt_engine"), self.base.get("translate_engine")) \
            or bool(settings.get("ai_verify_lines", True))

    def _gemini_ok(self) -> bool:
        """Every Gemini key refused (wrong key / limit reached): say so now. No
        internet / no answer in time: start anyway (it retries by itself)."""
        if not self._gemini_used():
            return True
        from core import gemini

        now = time.time()
        todo = [k for k in gemini.keys()
                if now - self._key_checked.get(k, (0, ""))[0] > self.KEY_CHECK_TTL]
        if todo:
            res = {}

            def check():
                for k in todo:
                    res[k] = gemini.test_key(k)
            t = threading.Thread(target=check, daemon=True)
            t.start()
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            self._checking = True           # (a second click on Start waits)
            try:
                end = time.time() + 15
                while t.is_alive() and time.time() < end:
                    QApplication.processEvents()
                    t.join(0.05)
            finally:
                self._checking = False
                QApplication.restoreOverrideCursor()
            for k, why in res.items():
                if not why or errors.advice(why) in (errors.KEY, errors.QUOTA):
                    BatchDialog._key_checked[k] = (now, why)
        why = [self._key_checked.get(k, (0, ""))[1] for k in gemini.keys()]
        if not why or any(w == "" for w in why) or \
                any(k not in self._key_checked for k in gemini.keys()):
            return True             # a key works, or could not be checked
        kind = errors.advice(why[0])
        text = ("The Gemini API key was refused" if kind == errors.KEY
                else "Every Gemini API key has reached its limit (quota)")
        ans = QMessageBox.question(
            self, "Batch queue",
            f"{text} – the AI check and Gemini translation will not work.\n\n"
            f"({why[0].splitlines()[0][:160]})\n\nFix it in Tools › AI engines & API keys. "
            "Start anyway?")
        return ans == QMessageBox.StandardButton.Yes

    def start(self, only=None):
        if getattr(self, "_checking", False):
            return
        if self.running:
            self._pump()
            return
        self._only = set()
        self._gpu_one = False
        if any(o.isRunning() for o in self._orphans):
            QMessageBox.information(self, "Batch queue",
                                    "A few seconds please: the videos that were stopped are "
                                    "finishing their last piece.")
            return
        src, tgt = self.base.get("source_lang", "auto"), self._base_lang()
        if src and src != "auto" and src == tgt:
            ans = QMessageBox.question(
                self, "Batch queue",
                f"Speech (the language spoken in the videos) is set to the SAME language as "
                f"Dub to ({lang_name(tgt)}).\n\nFor Chinese videos choose Speech = Auto detect "
                f"(▸ More settings) - otherwise Whisper listens for the wrong language: slow, "
                f"and nothing is translated.\n\nStart anyway?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        if not self._odd_rows_ok():
            return
        if not self._cover_choice_ok():
            return
        w = self.win
        if w.worker and w.worker.isRunning():
            QMessageBox.information(self, "Batch queue",
                                    "Please wait for the task in the main window to finish.")
            return
        after = getattr(self, "_after_worker", None)
        if after is not None and after.isRunning():
            QMessageBox.information(self, "Batch queue",
                                    "Please wait: the last queue is still being checked / "
                                    "joined.")
            return
        if self.base.get("tts_engine") == "azure" and not w._azure_ready():
            return
        from core import gemini
        if "gemini" in (self.base.get("stt_engine"), self.base.get("translate_engine")) \
                and not gemini.configured():
            QMessageBox.information(self, "Batch queue",
                                    "Gemini is chosen but there is no API key yet.\n"
                                    "Add one in Tools › AI engines & API keys.")
            w.show_engines("gemini")
            if not gemini.configured():
                return
        out_dir = self.ed_out.text().strip()
        if not out_dir:
            return
        if not self._rights_ok():
            return
        os.makedirs(out_dir, exist_ok=True)
        if not self.base:
            self.take_settings(save=False)
        self.out_dir = out_dir
        self.opts = self._export_opts()
        self.mode = self.cmb_mode.currentData()
        self.auto_cover = self.chk_cover.isChecked()
        self.auto_crop = self.chk_bars.isChecked()
        self.use_series = self.chk_series.isChecked()
        if only:
            # 2.6.9: only the chosen videos (right-click › Start these now)
            self._only = {id(i) for i in only}
            self._run_items = [i for i in only if i in self.items and i.status in batch.PENDING]
        else:
            for it in self.items:
                if it.status in (batch.FAILED, batch.STOPPED):
                    it.status, it.message = batch.WAITING, ""
            self._run_items = [i for i in self.items if i.status in batch.PENDING]
        if not self._run_items:
            self._refresh_table()
            return
        if not self._preflight_ok():        # 2.6.10: missing videos, disk, Gemini key
            self._refresh_table()
            return
        for it in self._run_items:
            it.seconds = 0.0                # 2.6.10: "Time spent" = this run, not all runs
        self._stop_all = False
        self._skip.clear()
        self._later.clear()
        self._tries.clear()
        self.running = True
        self._started = time.time()
        self.win.log(f"▶ Batch queue: {len(self._run_items)} videos")
        self._refresh_table()
        self._pump()

    def _cover_choice_ok(self) -> bool:
        """2.4: a hide box is set (preset / Tools) AND each video would look for
        its own - which one? (Asked once; the answer is kept.)"""
        if not (self.chk_cover.isChecked() and self.base.get("cover_enabled")) \
                or getattr(self, "_cover_each_ok", False):
            return True
        if not any(i.status == batch.WAITING and not i.work_dir for i in self.items):
            return True
        r = self.base.get("cover_rect") or [0, 0, 0, 0]
        box = QMessageBox(self)
        box.setWindowTitle("Batch queue")
        box.setIcon(QMessageBox.Icon.Question)
        box.setText("Hide the original subtitles – which box?\n\n"
                    f"• Your box (preset / Tools): top {r[1] * 100:.0f} %, height "
                    f"{r[3] * 100:.0f} %, left {r[0] * 100:.0f} %, width {r[2] * 100:.0f} %\n"
                    "• Or each video finds its own (the box moves to where that video's "
                    "subtitles are)")
        mine = box.addButton("Use my box for every video", QMessageBox.ButtonRole.YesRole)
        each = box.addButton("Each video finds its own", QMessageBox.ButtonRole.NoRole)
        box.addButton(QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(mine)
        box.exec()
        if box.clickedButton() is mine:
            self.chk_cover.setChecked(False)
            return True
        if box.clickedButton() is each:
            self._cover_each_ok = True            # (not asked again this time)
            return True
        return False

    def _odd_rows_ok(self) -> bool:
        """2.4: rows that dub into another language than the queue's Dub to
        (e.g. a story added as Chinese) - asked before the queue starts."""
        base = self._base_lang()
        odd = batch.odd_rows(self.items, base)
        if not odd:
            return True
        n = sum(len(v) for v in odd.values())
        langs = "\n".join(f"   • {lang_name(k)}: {len(v)} video(s)" for k, v in odd.items())
        box = QMessageBox(self)
        box.setWindowTitle("Batch queue")
        box.setIcon(QMessageBox.Icon.Warning)
        box.setText(f"{n} video(s) are set to dub into another language than "
                    f"{lang_name(base)}:\n\n{langs}\n\n"
                    f"Dub them into {lang_name(base)} too?")
        yes = box.addButton(f"Use {lang_name(base)}", QMessageBox.ButtonRole.YesRole)
        keep = box.addButton("Keep as they are", QMessageBox.ButtonRole.NoRole)
        box.addButton(QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(yes)
        box.exec()
        clicked = box.clickedButton()
        if clicked is yes:
            have = {i.key(base) for i in self.items}
            for items in odd.values():
                for it in items:
                    if (it.key(base)[0], base) in have:    # already queued in that language
                        continue
                    it.target_lang, it.voice = "", ""
                    if it.work_dir:                        # dub again in the right language
                        it.work_dir, it.output = "", ""
                    it.status, it.message = batch.WAITING, ""
            self._refresh_table()
            self._save()
            return True
        return clicked is keep

    def _pump(self):
        """Start whatever can run now (up to "At once" videos per stage);
        finish when nothing is left."""
        if not self.running:
            return
        parallel = self.chk_parallel.isChecked()
        n = 1 if self._gpu_one else self.spn_jobs.value()
        if not self._stop_all:
            while len(self.exp_jobs) < n and (parallel or not self.dub_jobs):
                it = next((i for i in self.items if i.status == batch.EXPORT_WAIT), None)
                if it is None:
                    break
                self._start_export(it)
            while len(self.dub_jobs) < n and (parallel or not self.exp_jobs):
                if (self.dub_jobs or self.exp_jobs) and self._vram_low():
                    break           # the next video waits until the card has room
                busy = {os.path.normcase(i.video_path) for i, _w in self.dub_jobs.values()}
                # the same video in another language waits: it then reuses the
                # transcript instead of listening to the video twice at once
                now = time.time()
                it = next((i for i in self.items if i.status == batch.WAITING
                           and self._later.get(id(i), 0) <= now
                           and (not self._only or id(i) in self._only)
                           and os.path.normcase(i.video_path) not in busy), None)
                if it is None:
                    break
                self._start_dub(it)
        if not self.dub_jobs and not self.exp_jobs:
            wait = [self._later[id(i)] for i in self.items
                    if i.status == batch.WAITING and id(i) in self._later
                    and (not self._only or id(i) in self._only)]
            if wait and not self._stop_all:
                # only automatic retries are left: come back when the first is due
                QTimer.singleShot(int(max(1.0, min(wait) - time.time()) * 1000) + 100,
                                  self._pump)
                return
            self._finished()

    def _vram_low(self) -> bool:
        """2.6.10: a small graphics card (under 7 GB) that is almost full does
        not take one more video now - it is asked again in 20 s. (A 4 GB card
        with two videos at once: VRAM 3.9 / 4.0 GB, black screen.)"""
        try:
            from core import resources

            if not resources.small_gpu():
                return False
            free = resources.free_vram_mb()
        except Exception:
            return False
        if free is None or free >= LOW_VRAM_MB:
            return False
        if not self._vram_wait:
            self._vram_wait = True
            self.win.log(f"⏸ Batch: the graphics card is almost full ({free:.0f} MB free) "
                         "– the next video waits a little")

            def again():
                self._vram_wait = False
                self._pump()
            QTimer.singleShot(20_000, again)
        return True

    def _label(self, it) -> str:
        n = self.items.index(it) + 1 if it in self.items else 0
        lang = it.target_lang or self._base_lang()
        return f"[{n}/{len(self.items)}] {os.path.basename(it.video_path)} ({lang})"

    def _flush_editor(self, it):
        """The editor has this video open: save its edits first."""
        p = self.win.project
        if it.work_dir and p.work_dir and \
                os.path.normcase(p.work_dir) == os.path.normcase(it.work_dir):
            self.win._autosave_now()
            return True
        return False

    def _start_dub(self, it):
        self._flush_editor(it)
        it.status, it.message = batch.RUNNING, ""
        self._t_item[id(it)] = time.time()
        self._pct[id(it)] = 0
        donors = [o.autosave() for o in self.items
                  if o is not it and o.video_path == it.video_path and o.autosave()
                  and os.path.isfile(o.autosave()) and o.status != batch.RUNNING]
        base, root, cover, crop = self.base, self.work_root, self.auto_cover, self.auto_crop
        hint = self._series_cover(it) if cover else None
        cast_file = batch.series_path(self.out_dir, it.story) \
            if getattr(self, "use_series", False) else ""
        w = TaskWorker(
            lambda prog, stop: batch.dub_item(it, base, root, cover, donors, prog, stop,
                                              cover_hint=hint, auto_crop=crop,
                                              series_cast=cast_file),
            "Batch dub", self)
        w.progress.connect(lambda p, m: self._on_progress("dub", it, p, m))
        w.done.connect(lambda r: self._dub_done(it, r))
        w.failed.connect(lambda e: self._failed(it, e, "dub"))
        self.dub_jobs[id(it)] = (it, w)
        self._busy_card("dub")
        self._update_row(it)
        w.start()

    def _series_cover(self, it) -> Optional[List[float]]:
        """Original-subtitle area found in another episode of the same folder
        (nearest one first), used when this episode's own search finds nothing."""
        folder = os.path.normcase(os.path.dirname(it.video_path))
        i = self.items.index(it)
        others = sorted((o for o in self.items if o is not it and o.status != batch.RUNNING
                         and o.autosave()
                         and os.path.normcase(os.path.dirname(o.video_path)) == folder),
                        key=lambda o: abs(self.items.index(o) - i))
        for o in others:
            rect = batch.cover_of(o.autosave())
            if rect:
                return rect
        return None

    def _start_export(self, it):
        self._flush_editor(it)
        it.status, it.message = batch.EXPORTING, ""
        self._t_item[id(it)] = time.time()
        self._pct[id(it)] = 0
        opts, out_dir, uniform = self.opts, self.out_dir, self.chk_same.isChecked()
        w = TaskWorker(
            lambda prog, stop: batch.export_item(it, opts, out_dir, prog, stop, uniform=uniform),
            "Batch export", self)
        w.progress.connect(lambda p, m: self._on_progress("exp", it, p, m))
        w.done.connect(lambda r: self._export_done(it, r))
        w.failed.connect(lambda e: self._failed(it, e, "exp"))
        self.exp_jobs[id(it)] = (it, w)
        self._busy_card("exp")
        self._update_row(it)
        w.start()

    def _spent(self, it):
        it.seconds += time.time() - self._t_item.pop(id(it), time.time())

    def _on_progress(self, stage, it, pct, msg):
        self._pct[id(it)] = pct
        jobs = self.dub_jobs if stage == "dub" else self.exp_jobs
        pb, lb = (self.pb_dub, self.lb_dub) if stage == "dub" else (self.pb_exp, self.lb_exp)
        if len(jobs) > 1:       # several videos: the average, and who said what
            pb.setValue(int(sum(self._pct.get(k, 0) for k in jobs) / len(jobs)))
            name = os.path.splitext(os.path.basename(it.video_path))[0]
            lb.setText(f"{name}: {msg}")
        else:
            pb.setValue(pct)
            lb.setText(msg)
        self._set_row_progress(it)
        self._show_total()

    def _fraction(self, it) -> float:
        """How much of this item's work is done (0..1)."""
        dub_share = 1.0 if self.mode == MODE_DUB_ONLY else 0.8
        if it.status in (batch.DONE, batch.SKIPPED, batch.FAILED):
            return 1.0
        if it.status == batch.DUBBED:
            return 1.0 if self.mode == MODE_DUB_ONLY else dub_share
        if it.status == batch.RUNNING:
            return dub_share * self._pct.get(id(it), 0) / 100
        if it.status == batch.EXPORT_WAIT:
            return dub_share
        if it.status == batch.EXPORTING:
            return dub_share + (1 - dub_share) * self._pct.get(id(it), 0) / 100
        return 0.0

    def _show_total(self):
        items = [i for i in self._run_items if i in self.items]
        if not items:
            return
        weight = [max(i.duration, 1.0) for i in items]
        total = sum(weight)
        done = sum(w * self._fraction(i) for w, i in zip(weight, items))
        frac = done / total if total else 0
        self.pb_total.setValue(int(frac * 100))
        finished = sum(1 for i in items if self._fraction(i) >= 1.0)
        text = f"{finished} of {len(items)} videos finished"
        el = time.time() - self._started
        if frac > 0.03 and el > 30:
            left = human_time(el * (1 - frac) / frac)
            text += f"  ·  ~{left} left"
            if self.running:
                self.cards["left"].setText(f"~{left}")
        elif self.running:
            self.cards["left"].setText("…")
        self.lb_total.setText(text)

    def _reload_editor(self, it):
        p = self.win.project
        if it.work_dir and p.work_dir and \
                os.path.normcase(p.work_dir) == os.path.normcase(it.work_dir):
            self.win._open_project_file(it.autosave(), as_autosave=True)

    def _dub_done(self, it, project=None):
        self._spent(it)
        self.dub_jobs.pop(id(it), None)
        notes = list(getattr(project, "engine_notes", []) or [])
        for n in notes:                     # Gemini / VoxCPM gave up: what took over
            self.win.log(f"{n}  [{os.path.basename(it.video_path)}]")
        if self.mode == MODE_DUB_ONLY:
            it.status, it.message = batch.DUBBED, "Ready – ✏ Edit to check, then ⬆ Export"
        else:
            it.status = batch.EXPORT_WAIT
            if notes:
                it.message = "fallback: " + "; ".join(n.split(" - ")[-1] for n in notes)
        self.win.log(f"✔ Batch dubbed: {self._label(it)}")
        self._reload_editor(it)
        self._busy_card("dub")
        self._update_row(it)
        self._show_total()
        self._pump()

    def _export_done(self, it, result: dict):
        self._spent(it)
        self.exp_jobs.pop(id(it), None)
        it.status, it.output = batch.DONE, result["video"]
        it.message = os.path.basename(result["video"])
        if it.cover == "none" and self.auto_cover:
            it.message += "  ⚠ original subtitles not found – check / Edit"
        if result.get("warning"):
            it.message += "  ⚠ " + result["warning"].splitlines()[0]
        self.win.log(f"✔ Batch: {it.video_path} → {result['video']}")
        self._busy_card("exp")
        self._update_row(it)
        self._show_total()
        self._pump()

    def _failed(self, it, err: str, stage: str):
        self._spent(it)
        (self.dub_jobs if stage == "dub" else self.exp_jobs).pop(id(it), None)
        self._busy_card(stage)
        cancelled = "Cancelled" in err or "Stopped" in err
        if id(it) in self._skip:
            self._skip.discard(id(it))
            it.status, it.message = batch.SKIPPED, "Skipped"
        elif cancelled or self._stop_all:
            it.status, it.message = batch.STOPPED, "Stopped – Start again to continue"
        elif errors.gpu_trouble(err) and self._tries.get(id(it), 0) < AUTO_RETRIES:
            # 2.6.10: GPU memory full / driver reset - again in 30 s, and from
            # now on one video at a time (the rest of this queue)
            k = self._tries[id(it)] = self._tries.get(id(it), 0) + 1
            self._later[id(it)] = time.time() + GPU_RETRY_DELAY
            it.status = batch.WAITING
            it.message = f"↻ Retry {k}/{AUTO_RETRIES} (GPU) – " + err.splitlines()[0][:60]
            if not self._gpu_one and self.spn_jobs.value() > 1:
                self.win.log("⚠ Batch: the graphics card was full – one video at a time "
                             "for the rest of this queue")
            self._gpu_one = True
            self.win.log(f"↻ Batch: {os.path.basename(it.video_path)}: {err.splitlines()[0]} "
                         f"– trying again in {GPU_RETRY_DELAY} s ({k}/{AUTO_RETRIES})")
        elif errors.transient(err) and self._tries.get(id(it), 0) < AUTO_RETRIES:
            # internet / busy / quota: try again by itself (finished work is kept)
            k = self._tries[id(it)] = self._tries.get(id(it), 0) + 1
            delay = RETRY_DELAYS[min(k, len(RETRY_DELAYS)) - 1]
            self._later[id(it)] = time.time() + delay
            it.status = batch.WAITING
            it.message = f"↻ Retry {k}/{AUTO_RETRIES} in {delay // 60} min – " + \
                err.splitlines()[0][:60]
            self.win.log(f"↻ Batch: {os.path.basename(it.video_path)}: {err.splitlines()[0]} "
                         f"– trying again in {delay // 60} min ({k}/{AUTO_RETRIES})")
        else:
            it.status, it.message = batch.FAILED, err.splitlines()[0]
            self.win.log(f"✖ Batch: {os.path.basename(it.video_path)}: {err}")
        if stage == "dub":
            self._reload_editor(it)
        self._update_row(it)
        self._pump()        # one bad video must not stop the rest

    def _finished(self):
        self.running = False
        self._only = set()
        self.btn_stop.setText("■  Stop")
        self.btn_stop.setToolTip("Stop after the current line")
        self._show_total()
        items = [i for i in self._run_items if i in self.items]
        done = sum(1 for i in items if i.status == batch.DONE)
        dubbed = sum(1 for i in items if i.status == batch.DUBBED)
        failed = sum(1 for i in items if i.status == batch.FAILED)
        took = format_time(time.time() - self._started, False)
        parts = [f"{done} exported"]
        if dubbed:
            parts.append(f"{dubbed} dubbed (check, then Export)")
        if failed:
            parts.append(f"{failed} failed")
        msg = (("Queue stopped" if self._stop_all else "Queue finished") +
               f" in {took}: " + ", ".join(parts))
        out_dir = getattr(self, "out_dir", self.ed_out.text())
        try:
            self.last_report = batch.write_report(
                items, os.path.join(out_dir, f"batch_report_{time.strftime('%Y%m%d_%H%M%S')}.csv"),
                self._base_lang())
            msg += f"\nReport: {self.last_report}"
        except Exception as e:
            self.win.log(f"Could not write the batch report: {e}")
        self.lb_total.setText(msg)
        self._idle_card("dub")
        self._idle_card("exp")
        self.cards["left"].setText("–")
        self.win.log(msg)
        self._refresh_table()
        if not self._stop_all:
            if self._after_queue(msg, failed):
                return              # QC / merge first; notify when they are done
            self._queue_end_notice(msg, failed)

    def _queue_end_notice(self, msg: str, failed: int):
        if self.chk_sound.isChecked():
            self._notify("SARIKA VOXDUB PRO – Batch finished", msg.splitlines()[0],
                         error=bool(failed))
        if self.chk_shutdown.isChecked():
            self._shutdown_pc()

    # ------------------------------------------------------------------ #
    # After the queue: quality check, one video per story, parts, upload kit
    # ------------------------------------------------------------------ #
    def _after_queue(self, msg: str, failed: int) -> bool:
        want_qc, want_merge = self.chk_qc.isChecked(), self.chk_merge.isChecked()
        if not (want_qc or want_merge):
            return False
        out_dir = getattr(self, "out_dir", self.ed_out.text())
        cfg = after_queue_config(self)
        snapshot = [copy.copy(i) for i in self.items]
        run_names = {i.key(self._base_lang()) for i in self._run_items}

        def job(progress, stop):
            return after_queue(snapshot, run_names, out_dir, self._base_lang(), cfg,
                               want_qc, want_merge, progress, stop)

        self.lb_total.setText(msg + "\nChecking the episodes / joining the stories…")
        w = TaskWorker(job, "After the queue", self)
        w.progress.connect(lambda p, m: (self.pb_total.setValue(p), self.lb_total.setText(m)))
        w.done.connect(lambda r: self._after_done(r, msg, failed))
        w.failed.connect(lambda e: (self.win.log(f"✖ After the queue: {e}"),
                                    self.lb_total.setText(f"{msg}\n✖ {e.splitlines()[0]}"),
                                    self._queue_end_notice(msg, failed)))
        self._after_worker = w
        w.start()
        return True

    def _after_done(self, res: dict, msg: str, failed: int):
        lines = [msg]
        for st in res.get("stories", []):
            name = st["story"] or "videos"
            if st.get("skipped"):
                lines.append(f"🎬 {name}: not joined – {st['skipped']}")
            else:
                how = "fast join" if st.get("fast") else "re-encoded"
                t = f"🎬 {name}: joined {st['count']} episodes ({how})"
                if st.get("parts"):
                    t += f" → {len(st['parts'])} parts"
                if st.get("kit"):
                    t += f" + titles / thumbnails ({st['kit_by']})"
                lines.append(t)
        rows = res.get("qc", [])
        if res.get("qc_done"):
            lines.append(f"✅ Quality check: {len(rows)} lines to look at"
                         + (f" – {res['qc_csv']}" if res.get("qc_csv") else ""))
        text = "\n".join(lines)
        self.lb_total.setText(text)
        self.pb_total.setValue(100)
        for ln in lines[1:]:
            self.win.log(ln)
        self._queue_end_notice(msg, failed)
        if rows and not self.chk_shutdown.isChecked():
            from ui.qc_dialog import QCDialog

            QCDialog(self.win, rows, res.get("qc_csv", ""), res.get("episodes", 0)).show()

    def _show_glossary(self):
        from ui.glossary_dialog import GlossaryDialog, lists_for

        sel = self._sel()
        it = sel[0] if sel else (self.items[0] if self.items else None)
        out_dir = self.ed_out.text().strip() or self.work_root
        cast = batch.series_path(out_dir, it.story) if it is not None else ""
        GlossaryDialog(self, lists_for(story_cast_path=cast)).exec()

    # ------------------------------------------------------------------ #
    # When finished
    # ------------------------------------------------------------------ #
    def _notify(self, title: str, text: str, error: bool = False):
        try:
            if sys.platform == "win32":
                import winsound
                winsound.MessageBeep(winsound.MB_ICONHAND if error else winsound.MB_OK)
            else:
                QApplication.beep()
        except Exception:
            pass
        try:
            if QSystemTrayIcon.isSystemTrayAvailable():
                if self._tray is None:
                    icon = self.win.windowIcon()
                    if icon.isNull():
                        icon = self.style().standardIcon(QStyle.StandardPixmap.SP_MediaPlay)
                    self._tray = QSystemTrayIcon(icon, self)
                    self._tray.messageClicked.connect(self.show)
                self._tray.show()
                self._tray.showMessage(
                    title, text, QSystemTrayIcon.MessageIcon.Warning if error
                    else QSystemTrayIcon.MessageIcon.Information, 15000)
        except Exception:
            pass

    def _shutdown_pc(self):
        if sys.platform != "win32":
            return
        try:
            subprocess.run(["shutdown", "/s", "/t", "120", "/c",
                            "SARIKA VOXDUB PRO: batch queue finished"], check=False,
                           creationflags=no_window())
        except OSError as e:
            self.win.log(f"Could not shut down: {e}")
            return
        self.win.log("PC shuts down in 2 minutes (batch finished)")
        box = QMessageBox(QMessageBox.Icon.Warning, "Shut down",
                          "The batch queue is finished.\nThe PC shuts down in 2 minutes.",
                          parent=self)
        b_cancel = box.addButton("Cancel shutdown", QMessageBox.ButtonRole.RejectRole)
        box.addButton("OK", QMessageBox.ButtonRole.AcceptRole)
        box.setModal(False)

        def clicked(b):
            if b is b_cancel:
                subprocess.run(["shutdown", "/a"], check=False,
                               creationflags=no_window())
                self.win.log("Shutdown cancelled")
        box.buttonClicked.connect(clicked)
        box.show()

    # ------------------------------------------------------------------ #
    # Export after checking (dub only mode)
    # ------------------------------------------------------------------ #
    def _queue_export(self, items):
        n = 0
        for it in items:
            if it.status in (batch.DUBBED, batch.DONE) and it.work_dir:
                it.status, it.message = batch.EXPORT_WAIT, ""
                n += 1
        if not n:
            return
        if self.running:
            self._run_items += [i for i in items if i not in self._run_items]
            self._refresh_table()
            self._pump()
        else:
            self.start()

    def _export_selected(self):
        self._queue_export(self._sel())

    def _export_all_dubbed(self):
        self._queue_export([i for i in self.items if i.status == batch.DUBBED])

    # ------------------------------------------------------------------ #
    def stop(self):
        if not self.running:
            return
        if self._stop_all:                  # 2nd click: do not wait at all
            self._stop_now()
            return
        self._stop_all = True
        for _it, w in list(self.dub_jobs.values()) + list(self.exp_jobs.values()):
            if w.isRunning():
                w.stop()
        self.lb_total.setText("Stopping… each video finishes the piece it is working on "
                              "(on the CPU this can take a minute) – click ⏹ Stop now to "
                              "stop at once")
        self.btn_stop.setText("⏹  Stop now")
        self.btn_stop.setToolTip("Stop at once. The videos being dubbed continue from where "
                                 "they were when you click Start again.")
        self._pump()

    def _stop_now(self):
        """Stop without waiting: the workers still finish their current piece
        in the background (nothing of theirs is used any more), the queue is
        free at once. Their finished work is kept on disk - Start continues."""
        for jobs in (self.dub_jobs, self.exp_jobs):
            for it, w in list(jobs.values()):
                w.stop()
                import warnings

                for sig in (w.progress, w.done, w.failed):
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", RuntimeWarning)
                        try:
                            sig.disconnect()
                        except (RuntimeError, TypeError):
                            pass
                if w.isRunning():
                    self._orphans.append(w)     # kept alive until its thread ends
                    w.finished.connect(lambda w=w: self._orphans.remove(w)
                                       if w in self._orphans else None)
                self._spent(it)
                it.status, it.message = batch.STOPPED, "Stopped – Start again to continue"
                self._update_row(it)
            jobs.clear()
        self._finished()

    def shutdown(self):
        """Main window is closing."""
        self._stop_all = True
        self.thumbs.stopped = True
        self.big_thumbs.stopped = True
        self.styled.stopped = True
        self.preview.stop()
        self._save_timer.stop()
        running = [w for _it, w in list(self.dub_jobs.values()) + list(self.exp_jobs.values())
                   if w.isRunning()]
        after = getattr(self, "_after_worker", None)
        if after is not None and after.isRunning():
            running.append(after)
        for w in running:
            w.stop()
        from ui.workers import wait_for_threads
        wait_for_threads(running, self.win, "Stopping the batch queue...")
        for it in self.items:
            if it.status in batch.ACTIVE:
                it.status, it.message = batch.STOPPED, "Stopped (app was closed)"
        self._save()
        if self._tray:
            self._tray.hide()

    def closeEvent(self, event):
        event.ignore()
        self.hide()         # keep the queue running in the background


# --------------------------------------------------------------------------- #
# After the queue (runs in a worker thread: no widgets here)
# --------------------------------------------------------------------------- #
def after_queue_config(dlg) -> dict:
    return {"parts": dlg.chk_parts.isChecked(), "minutes": dlg.spn_part_min.value(),
            "name": dlg.ed_part_name.text().strip() or "{story} ភាគ{n}",
            "start": dlg.spn_part_start.value(),
            "kit": dlg.chk_parts.isChecked() and dlg.chk_kit.isChecked(),
            "logo": (dlg.base or {}).get("logo_path", "") or ""}


def after_queue(items, run_keys, out_dir: str, base_lang: str, cfg: dict,
                want_qc: bool, want_merge: bool, progress=None, stop=None) -> dict:
    """Quality check of the episodes of this run, then every story whose
    episodes are all exported: joined, cut into parts, titles + thumbnails."""
    from core import joiner, qc, upload_kit
    from core.project import Project as _P

    res = {"qc": [], "qc_csv": "", "stories": [], "episodes": 0, "qc_done": False}
    stamp = time.strftime("%Y%m%d_%H%M%S")
    if want_qc:
        its = [i for i in items if i.key(base_lang) in run_keys
               and i.status in (batch.DONE, batch.DUBBED)
               and i.autosave() and os.path.isfile(i.autosave())]
        levels: Dict[str, Dict] = {}
        for k, it in enumerate(its):
            if stop and stop():
                raise InterruptedError("Cancelled")
            if progress:
                progress(int(30 * k / max(1, len(its))), f"Quality check {k + 1}/{len(its)}…")
            try:
                p = _P.load(it.autosave())
            except Exception:
                continue
            ep = os.path.splitext(os.path.basename(it.video_path))[0]
            rows = qc.check_project(p)
            # the sound of the exported video: clipping, too loud / quiet
            if it.status == batch.DONE and it.output and os.path.isfile(it.output):
                m = qc.measure_audio(it.output)
                rows += qc.check_audio(m, os.path.basename(it.output))
                if m:
                    levels.setdefault(it.story or "", {})[id(it)] = (m["lufs"], ep, it)
            for r in rows:
                r["episode"] = ep
                r["autosave"] = it.autosave()
                res["qc"].append(r)
        # one episode much louder / quieter than the rest of its story
        for story, eps in levels.items():
            off = qc.level_outliers({k: v[0] for k, v in eps.items()})
            for k, diff in off.items():
                lufs, ep, it = eps[k]
                res["qc"].append({"time": 0.0, "kind": "level", "episode": ep,
                                  "autosave": it.autosave(), "seg_id": "",
                                  "what": f"{qc.KINDS['level']} ({diff:+.1f} LU, "
                                          f"{lufs:.1f} LUFS)",
                                  "text": os.path.basename(it.output)})
        res["episodes"], res["qc_done"] = len(its), True
        if res["qc"]:
            res["qc_csv"] = qc.write_csv(res["qc"], os.path.join(out_dir,
                                                                  f"qc_report_{stamp}.csv"))
    if not want_merge:
        return res
    stories = [s for s in batch.finished_stories(items, base_lang)
               if any(i.key(base_lang) in run_keys and i.story == s["story"] for i in items)]
    for n, st in enumerate(stories):
        if stop and stop():
            raise InterruptedError("Cancelled")
        entry = {"story": st["story"], "lang": st["lang"]}
        res["stories"].append(entry)
        if st["missing"]:
            entry["skipped"] = (f"{len(st['missing'])} episode(s) not exported "
                                f"({', '.join(st['missing'][:3])}…)")
            continue
        if len(st["paths"]) < 2 and not cfg["parts"]:
            entry["skipped"] = "only one episode"
            continue
        lo, hi = 30 + 70 * n // len(stories), 30 + 70 * (n + 1) // len(stories)

        def prog(p, m, lo=lo, hi=hi):
            if progress:
                progress(lo + (hi - lo) * p // 100, f"{st['story'] or 'videos'}: {m}")
        r = batch.merge_story(st["paths"], out_dir, st["story"], st["lang"],
                              cfg["minutes"] if cfg["parts"] else 0, cfg["name"], cfg["start"],
                              lambda p, m: prog(p * 7 // 10, m), stop)
        entry.update({"count": r["count"], "fast": r["fast"], "video": r["video"],
                      "parts": r["parts"]})
        if cfg["kit"] and r["parts"]:
            episodes = []
            by_out = {os.path.normcase(i.output): i for i in items if i.output}
            for path in st["paths"]:
                it = by_out.get(os.path.normcase(path))
                lines = []
                try:
                    p = _P.load(it.autosave()) if it else None
                    lines = [(s.start, s.translation or s.text) for s in p.segments] if p else []
                except Exception:
                    pass
                episodes.append((get_media_info(path).duration, lines))
            total = r["duration"]
            edges = [0.0] + joiner.plan_split(total, cfg["minutes"] * 60, 30) + [total]
            texts = upload_kit_lines(episodes, edges)
            lang = LANGUAGES.get(st["lang"], (st["lang"] or "Khmer",))[0].split(" (")[0]
            title = os.path.basename(st["story"].rstrip("/")) if st["story"] else "videos"
            first = joiner.resolve_part_name(cfg["name"].replace("{story}", title),
                                             cfg["start"])[1]
            kit = upload_kit.make_kit(r["parts"], title, texts, cfg["logo"], True, lang, first,
                                      lambda p, m: prog(70 + p * 3 // 10, m), stop)
            entry["kit"] = len(kit)
            entry["kit_by"] = "Gemini" if any(k["by"] == "Gemini" for k in kit) else "template"
    return res


def upload_kit_lines(episodes, edges):
    from core import upload_kit

    return upload_kit.part_lines(episodes, edges)

