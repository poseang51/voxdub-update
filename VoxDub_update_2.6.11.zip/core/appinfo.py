"""
appinfo.py - who this program is: SARIKA VOXDUB PRO.

(The same sources also build a separate TESTING copy, SARIKA VOXDUB STUDIO,
with other values here - its own settings, output folder, taskbar id and
installer - so the two never touch each other on one PC.)
"""

APP_NAME = "SARIKA VOXDUB PRO"
# 2.6.11: the "Edit video" workspace (Filmora-style editor) is hidden - the
# app is for dubbing. The dub editor (timeline, check & fix) stays. True =
# shown again (nothing else to change).
EDIT_WORKSPACE = False
EDITION = ""
TITLE = APP_NAME
# folders under %APPDATA% / %LOCALAPPDATA%
DATA_FOLDER = "VoxDubPRO"
# folder under Videos
OUTPUT_FOLDER = "SARIKA VOXDUB PRO"
# Windows taskbar id
APP_USER_MODEL_ID = "VoxDub.PRO.1"
# (the testing copy reads a voice-clone engine installed here; PRO is it)
PRO_DATA_FOLDER = "VoxDubPRO"
