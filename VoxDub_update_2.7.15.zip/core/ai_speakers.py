"""
ai_speakers.py - 2.7.1: who says each line, asked to Gemini (voice + story).

The voice print groups (core/speakers.py) split one angry woman into 5
characters and gave a flight attendant the label of a passenger (3A号座位的代价
EP001, 12/11): an angry voice and a calm voice of the same person print far
apart. Gemini hears the episode AND reads the lines - who answers whom, who
says "my back is hurt" - and groups the lines by person.

2.7.2: long videos (a film of 2 hours) too. The sound goes in pieces of about
PIECE seconds (cut between two lines); every piece after the first gets the
people found so far (man / woman, role, two of their lines) and gives the
SAME number to a person seen before. The sound is sent as mp3 (a 10-minute
wav was more than Gemini takes in one request).

When Gemini cannot be asked, or an answer does not fit, the voice print
groups stay as they are (for the whole video).
"""

import base64
import os
import tempfile
import time as _time
from typing import Dict, List, Optional, Tuple

import numpy as np

MAX_SECONDS = 4 * 3600     # longer videos: the voice prints only
PIECE = 480.0              # seconds of sound per request
TIME_LIMIT = 180.0         # 18/11: one piece is given up after this (keys used up: no wait on and on)
# 26/11 (2.7.12): an answer comes in 10-15 s; twice it never came and each
# episode waited 3 minutes for nothing ("AI 187s ... not used"). A piece now
# waits ~1 minute per 3 minutes of sound, and after a piece that got nothing
# the voice prints alone are used for REST_S (the next episodes of a Batch).
PIECE_LIMIT_MIN = 60.0
REST_S = 15 * 60
_rest_until = 0.0
SR = 16000
AGES = ("child", "young", "adult", "elder")
LAST: Dict[str, int] = {}  # 26/11: the last ask - parts and requests, for the [cast] trace


def wanted(project) -> bool:
    from . import gemini, settings

    import time

    if time.time() < _rest_until:
        return False
    return bool(settings.get("ai_speakers", True)) and gemini.configured()


def piece_limit(seconds: float) -> float:
    return min(TIME_LIMIT, max(PIECE_LIMIT_MIN, seconds / 3.0))


SLOW_S = 30 * 60.0          # a model too slow for Characters is asked last for 30 minutes
_slow: Dict[str, float] = {}


def per_try(seconds: float) -> float:
    """2.7.13: the longest wait for one model - then the next model is asked.
    27/11: 80 s of sound timed out at 65 s on one model and nothing else was
    tried; answers that came took 10-45 s."""
    return min(90.0, 45.0 + seconds / 4.0)


def models_for_cast(models):
    """Characters always may go on to the next model (the Router's list, or
    the model of Settings + the fast models the keys have)."""
    from . import gemini

    ms = list(models) if models else None
    if not ms:
        try:
            ms = gemini.router_models()
        except Exception:
            return None
    now = _time.time()
    fast = [m for m in ms if _slow.get(m, 0) <= now]
    return fast + [m for m in ms if m not in fast]   # a slow one is asked last


def rest() -> None:
    global _rest_until
    import time

    _rest_until = time.time() + REST_S


def _audio(project) -> Optional[np.ndarray]:
    from .media import read_wav

    work = getattr(project, "work_dir", "") or ""
    for p in (os.path.join(work, "voice_only_16k.wav"), project.original_audio):
        if p and os.path.isfile(p):
            a, sr = read_wav(p)
            if a.ndim > 1:
                a = a.mean(axis=1)
            if sr != SR:
                n = int(len(a) * SR / sr)
                a = np.interp(np.linspace(0, len(a), n, endpoint=False),
                              np.arange(len(a)), a).astype(np.float32)
            return a
    return None


def _encode(audio: np.ndarray) -> dict:
    """The sound for the request: mp3 (small), wav when ffmpeg cannot."""
    from . import gemini
    from .media import run_ffmpeg, write_wav

    tmp = tempfile.mkdtemp(prefix="vx_who_")
    wav, mp3 = os.path.join(tmp, "a.wav"), os.path.join(tmp, "a.mp3")
    try:
        write_wav(wav, audio.astype(np.float32), SR)
        run_ffmpeg(["-i", wav, "-ac", "1", "-ar", str(SR), "-b:a", "48k", mp3])
        with open(mp3, "rb") as f:
            return {"mime_type": "audio/mp3", "data": base64.b64encode(f.read()).decode("ascii")}
    except Exception as e:
        print(f"[ai_speakers] mp3 not made ({str(e)[:120]}) - sending wav")
        return {"mime_type": "audio/wav", "data": gemini._wav_b64(audio)}
    finally:
        for p in (wav, mp3):
            try:
                os.remove(p)
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass


def pieces(segs, piece: float = PIECE) -> List[Tuple[int, int]]:
    """[(first, last+1)] line ranges whose sound lasts about `piece` seconds,
    cut in the longest silence of the last quarter of each piece."""
    out, a, n = [], 0, len(segs)
    while a < n:
        b = a + 1
        while b < n and segs[b].end - segs[a].start <= piece:
            b += 1
        if b < n:
            lo = max(a + 1, a + (b - a) * 3 // 4)
            cut = max(range(lo, b + 1), key=lambda k: segs[k].start - segs[k - 1].end)
            b = cut
        out.append((a, b))
        a = b
    return out


def _known_part(known: Dict[int, dict], next_id: int) -> str:
    if not known:
        return ""
    rows = "\n".join(
        f"- {s}: {k.get('gender') or '?'}, {k.get('role') or 'no role yet'}"
        + (f" ({k['age']})" if k.get("age") else "")
        + (f' - says e.g. "' + '" / "'.join(k.get("say", [])[:2]) + '"' if k.get("say") else "")
        for s, k in sorted(known.items()))
    return f"""
People found earlier in this video (their numbers):
{rows}
When a line is said by one of them, use THAT number. A new person gets a new number from {next_id} up.
"""


def _prompt(segs, hint: List[int], known: Dict[int, dict], next_id: int, t0: float) -> str:
    rows = "\n".join(
        f"{k + 1}. [{s.start - t0:.1f}-{s.end - t0:.1f}s] (voice group {hint[k] + 1}) {s.text.strip()}"
        for k, s in enumerate(segs))
    part = "a part of a drama" if known else "a drama episode"
    return f"""This is the sound of {part} and its {len(segs)} lines with their times (from the start of this sound).
Decide WHO says each line. Use the voices AND the story: who answers whom, what people say about themselves (an angry and a calm line can be the same person), how they address each other.
The "voice group" is a guess from voice prints only - it is often wrong (one person split in several groups, or two people in one group).
{_known_part(known, next_id)}
Lines:
{rows}

Answer ONLY with JSON:
{{"speakers": [{{"id": 1, "gender": "male|female", "age": "child|young|adult|elder", "role": "<2-4 words, e.g. woman passenger>"}}],
 "lines": [{{"i": 1, "s": 1}}, ...]}}
Give every line exactly one speaker id; the same person always has the same id."""


def _ask_piece(audio, segs, hint, known, next_id, models, should_stop
               ) -> Optional[Tuple[List[int], Dict[int, dict]]]:
    """(Gemini's id per line, {id: {gender, role}}) or None."""
    from . import gemini

    t0 = max(0.0, segs[0].start - 0.5)
    a, b = int(t0 * SR), min(len(audio), int((segs[-1].end + 1.0) * SR))
    parts = [{"inline_data": _encode(audio[a:b])},
             {"text": _prompt(segs, hint, known, next_id, t0)}]
    from . import gemini_stats

    with gemini_stats.work("Characters", len(segs)):
        text, _ = gemini.generate(parts, temperature=0.0, max_tokens=8192,
                                  should_stop=should_stop, models=models,
                                  time_limit=TIME_LIMIT, per_try=per_try((b - a) / SR))
    try:
        data = gemini._json(text)
    except ValueError:
        LAST["bad"] = "an answer that is not JSON"
        return None
    if not isinstance(data, dict):
        LAST["bad"] = "an answer that is not JSON"
        return None
    ids: Dict[int, int] = {}
    for it in data.get("lines") or []:
        try:
            ids[int(it["i"]) - 1] = int(it["s"])
        except (KeyError, TypeError, ValueError):
            continue
    ids = {k: v for k, v in ids.items() if 0 <= k < len(segs)}
    missing = [k for k in range(len(segs)) if k not in ids]
    if len(missing) > len(segs) * (1 - PLACED_MIN):
        LAST["bad"] = f"an answer that places {len(ids)} of {len(segs)} lines"
        return None
    if missing:
        # 2.7.15 (27/11): EP001 - an answer in 58 s was thrown away for a few
        # lines it left out, then 3 minutes of asking again gave nothing.
        fill_missing(ids, missing, hint)
        LAST["filled"] = LAST.get("filled", 0) + len(missing)
    if len(set(ids.values())) > max(2, len(segs) // 2 + 1):
        LAST["bad"] = "an answer with almost one person per line"
        return None                                 # nonsense: almost one person per line
    info: Dict[int, dict] = {}
    for sp in data.get("speakers") or []:
        try:
            s = int(sp.get("id"))
        except (TypeError, ValueError, AttributeError):
            continue
        g = str(sp.get("gender", "")).lower()
        a = str(sp.get("age", "")).lower()
        info[s] = {"gender": g if g in ("male", "female") else "",
                   "age": a if a in AGES else "",          # 2.7.2: for the voice
                   "role": str(sp.get("role", "") or "").strip()[:40]}
    return [ids[k] for k in range(len(segs))], info


PLACED_MIN = 0.8            # 2.7.15: an answer that places 80 % of the lines is used


def fill_missing(ids: Dict[int, int], missing: List[int], hint: List[int]) -> None:
    """A line the AI left out: the AI person most of the lines with the same
    voice print were given; else the line before (or after) it."""
    for k in missing:
        same = [ids[j] for j in ids if j < len(hint) and k < len(hint) and hint[j] == hint[k]]
        if same:
            ids[k] = max(set(same), key=same.count)
            continue
        near = sorted(ids, key=lambda j: (abs(j - k), j > k))
        ids[k] = ids[near[0]]


def _note_models():
    """Which model answered / was too slow - for the [cast] trace."""
    from . import gemini

    for m, what, sec in gemini.tried():
        LAST.setdefault("models", []).append(f"{m} {what} {sec:.0f}s")
        if what == "timeout":
            _slow[m] = _time.time() + SLOW_S
        elif what == "200":
            _slow.pop(m, None)


def ask(project, segs, hint: List[int], should_stop=None, progress=None
        ) -> Optional[Tuple[List[int], Dict[int, dict]]]:
    """(speaker index per line 0.., {index: {gender, role}}) or None."""
    from . import gemini

    if not segs:
        return None
    audio = _audio(project)
    if audio is None or len(audio) / SR > MAX_SECONDS:
        return None
    models = gemini.router_models() if project.translate_engine == "gemini-router" else None
    models = models_for_cast(models)
    known: Dict[int, dict] = {}                     # Gemini id -> gender, role, lines said
    line_ids: List[int] = []
    cuts = pieces(segs, PIECE)
    LAST.clear()
    LAST.update(pieces=len(cuts), tries=0)
    for n, (a, b) in enumerate(cuts):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        if progress and len(cuts) > 1:
            progress(86, f"AI: who says each line... part {n + 1}/{len(cuts)}")
        nxt = max(known) + 1 if known else 1
        got = None
        for _try in range(2):                       # a bad answer: once more
            LAST["tries"] += 1
            try:
                got = _ask_piece(audio, segs[a:b], hint[a:b], known, nxt, models, should_stop)
            except InterruptedError:
                raise
            except Exception as e:                  # no answer in time / no key left
                print(f"[ai_speakers] {str(e)[:120]}")
                LAST["why"] = f"{type(e).__name__}: {str(e)[:160]}"
                _note_models()
                rest()
                return None
            _note_models()
            if got:
                break
            LAST["why"] = LAST.pop("bad", "an answer that could not be used")
        if not got:
            return None
        ids, info = got
        for k, s in enumerate(ids):
            line_ids.append(s)
            p = known.setdefault(s, {"gender": "", "age": "", "role": "", "say": []})
            for f in ("gender", "age", "role"):
                if not p[f] and info.get(s, {}).get(f):
                    p[f] = info[s][f]
            t = segs[a + k].text.strip()
            if len(p["say"]) < 2 and len(t) >= 4:
                p["say"].append(t[:30])
    order = list(dict.fromkeys(line_ids))
    idx = {s: n for n, s in enumerate(order)}
    out_info = {idx[s]: {"gender": known[s]["gender"], "age": known[s]["age"],
                         "role": known[s]["role"]} for s in order}
    return [idx[s] for s in line_ids], out_info
