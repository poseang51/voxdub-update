"""
admin.py - The seller ("Admin") side of the licenses, used by the app itself.

The PC that holds the PRIVATE signing key (%USERPROFILE%\\.voxdub_admin\\
private_key.txt, made once by build_exe.bat / make_license.bat) is the
owner's PC:
  * it never needs a license key (no trial watermark, nothing locked);
  * Help › Admin – Customers & keys opens the customer list, where keys are
    made, renewed and copied.
A customer's PC does not have that file, so none of this applies there. The
check is real cryptography: the private key must sign a test message that the
app's built-in PUBLIC key accepts - a fake or copied-in file of another key
pair does not count.

Customers are kept in  %USERPROFILE%\\.voxdub_admin\\customers.json  (every key
also goes into issued_keys.csv, the same log the command-line tool writes).
Back up the whole .voxdub_admin folder.
"""

import csv
import datetime as dt
import json
import os
import uuid
from typing import Dict, List, Optional

from . import license as lic

ADMIN_DIR = os.environ.get("VOXDUB_ADMIN_DIR") or os.path.join(os.path.expanduser("~"),
                                                               ".voxdub_admin")
PRIVATE_FILE = os.path.join(ADMIN_DIR, "private_key.txt")
ISSUED_FILE = os.path.join(ADMIN_DIR, "issued_keys.csv")
CUSTOMERS_FILE = os.path.join(ADMIN_DIR, "customers.json")

_owner: Optional[bool] = None


def _private() -> Optional[bytes]:
    try:
        with open(PRIVATE_FILE, "r", encoding="ascii") as f:
            return lic._b64d(f.read().strip())
    except (OSError, ValueError):
        return None


def is_owner() -> bool:
    """This PC holds the private key that matches the app's public key."""
    global _owner
    if _owner is None:
        _owner = False
        priv, pub = _private(), lic.public_key()
        if priv and pub:
            try:
                from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                    Ed25519PrivateKey, Ed25519PublicKey)

                msg = uuid.uuid4().bytes
                sig = Ed25519PrivateKey.from_private_bytes(priv).sign(msg)
                Ed25519PublicKey.from_public_bytes(pub).verify(sig, msg)
                _owner = True
            except Exception:
                _owner = False
    return _owner


def reset_cache():
    global _owner
    _owner = None


# --------------------------------------------------------------------------- #
# customers
# --------------------------------------------------------------------------- #
def load() -> List[dict]:
    try:
        with open(CUSTOMERS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return [c for c in data if isinstance(c, dict)] if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def save(customers: List[dict]) -> None:
    os.makedirs(ADMIN_DIR, exist_ok=True)
    tmp = CUSTOMERS_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(customers, f, ensure_ascii=False, indent=1)
    os.replace(tmp, CUSTOMERS_FILE)


def new_customer(name: str, machine: str, contact: str = "", note: str = "") -> dict:
    return {"id": uuid.uuid4().hex[:10], "name": name.strip(), "contact": contact.strip(),
            "machine": normalize_machine(machine), "note": note.strip(), "plan": "pro",
            "order": "", "paid": False,
            "expires": "", "key": "", "issued": "", "history": []}


def normalize_machine(mid: str) -> str:
    raw = "".join(ch for ch in (mid or "").upper() if ch.isalnum())
    if len(raw) == 16:
        return "-".join(raw[i:i + 4] for i in range(0, 16, 4))
    return (mid or "").strip().upper()


def machine_ok(mid: str) -> bool:
    raw = "".join(ch for ch in (mid or "") if ch.isalnum())
    return len(raw) == 16 and all(c in "0123456789ABCDEF" for c in raw.upper())


def issue(customer: dict, until: dt.date, plan: str = "pro") -> str:
    """Make a key for the customer until that date; it is stored on the
    customer and logged in issued_keys.csv. Returns the key."""
    if not is_owner():
        raise PermissionError("Only the seller's PC can make keys")
    mid = normalize_machine(customer.get("machine", ""))
    if not machine_ok(mid):
        raise ValueError("The Machine ID looks wrong - it is 16 characters like "
                         "4F2A-9C1D-77B0-E3A5 (Help › License on the customer's PC)")
    today = dt.date.today()
    payload = {"v": 1, "name": customer.get("name", ""), "plan": plan, "mid": mid,
               "exp": until.isoformat(), "iss": today.isoformat()}
    key = lic.sign(payload, _private())
    check = lic.verify(key, mid=mid, today=today)
    if not check.valid and until >= today:
        raise RuntimeError(f"The new key does not check out: {check.reason}")
    customer.update(machine=mid, plan=plan, expires=until.isoformat(), key=key,
                    issued=today.isoformat())
    customer.setdefault("history", []).append(
        {"issued": today.isoformat(), "expires": until.isoformat(), "plan": plan})
    os.makedirs(ADMIN_DIR, exist_ok=True)
    new = not os.path.isfile(ISSUED_FILE)
    with open(ISSUED_FILE, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["issued", "name", "plan", "machine", "expires", "key"])
        w.writerow([today.isoformat(), customer.get("name", ""), plan, mid,
                    until.isoformat(), key])
    return key


def renew_date(customer: dict, days: int) -> dt.date:
    """A renewal adds the days to whatever is left (not lost when renewed early)."""
    today = dt.date.today()
    try:
        cur = dt.date.fromisoformat(customer.get("expires", ""))
    except ValueError:
        cur = today
    return max(cur, today) + dt.timedelta(days=days)


def status(customer: dict) -> Dict[str, object]:
    """{"text": "Active · 12 days", "days": 12, "state": active/soon/expired/none}"""
    try:
        exp = dt.date.fromisoformat(customer.get("expires", ""))
    except ValueError:
        return {"text": "No key yet", "days": None, "state": "none"}
    days = (exp - dt.date.today()).days
    if days < 0:
        return {"text": f"Expired {-days} days ago", "days": days, "state": "expired"}
    if days <= 5:
        return {"text": f"Ends in {days} days", "days": days, "state": "soon"}
    return {"text": f"Active · {days} days", "days": days, "state": "active"}


def import_issued_log(customers: List[dict]) -> int:
    """Customers from keys made earlier with make_license.bat (issued_keys.csv)
    that are not in the list yet. Returns how many were added."""
    if not os.path.isfile(ISSUED_FILE):
        return 0
    have = {(c.get("name", ""), c.get("machine", "")) for c in customers}
    latest: Dict[tuple, dict] = {}
    with open(ISSUED_FILE, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            k = (r.get("name", ""), normalize_machine(r.get("machine", "")))
            if k[1] == "*" or k in have:
                continue
            if k not in latest or r.get("expires", "") > latest[k].get("expires", ""):
                latest[k] = r
    for (name, mid), r in latest.items():
        c = new_customer(name, mid)
        c.update(plan=r.get("plan", "pro"), expires=r.get("expires", ""), key=r.get("key", ""),
                 issued=r.get("issued", ""))
        customers.append(c)
    return len(latest)
