"""
joiner.py - Merge many videos into one, or split one long video into parts.

Merge
  * Fast (no re-encoding): ffmpeg's concat demuxer copies the streams. Only
    possible when every video has the same format (codec, size, frame rate,
    audio) - true for videos exported by the batch queue with one setting.
  * Otherwise every video is re-encoded to the largest size in the list
    (others fitted with black bars), same frame rate and audio, and joined.

Split
  * Parts of N minutes (+ seconds). A very short last part can be added to
    the part before it.
  * Fast: stream copy, cuts land on the nearest keyframe (a part can be a
    few seconds longer / shorter). Exact: re-encodes with keyframes at the
    cut points, so every part is exactly N minutes.
"""

import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Callable, List, Optional, Tuple

from .export import ExportOptions, ExportFailed, _run_with_progress, _video_codec_args, pick_encoder
from .media import no_window, find_ffmpeg, get_media_info

Progress = Callable[[int, str], None]
Stop = Callable[[], bool]


def natural_key(path: str):
    """'EP2' sorts before 'EP10'."""
    name = os.path.basename(path).lower()
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", name)]


# --------------------------------------------------------------------------- #
# Stream format (to know whether a fast merge is safe)
# --------------------------------------------------------------------------- #
@dataclass
class StreamFormat:
    duration: float = 0.0
    video: str = ""        # "h264 high yuv420p 1080x1920 30"
    audio: str = ""        # "aac 44100 stereo"
    width: int = 0
    height: int = 0
    fps: float = 0.0


def stream_format(path: str) -> StreamFormat:
    info = get_media_info(path)
    proc = subprocess.run([find_ffmpeg(), "-hide_banner", "-i", path], stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, creationflags=no_window())
    text = proc.stderr.decode("utf-8", errors="replace")
    fmt = StreamFormat(info.duration, width=info.width, height=info.height, fps=info.fps)
    for line in text.splitlines():
        if "Stream #" not in line:
            continue
        if "Video:" in line and not fmt.video and "attached pic" not in line:
            m = re.search(r"Video:\s*(\w+)(?:\s*\(([^)]*)\))?", line)
            pix = re.search(r",\s*(yuv\w+|nv12|rgb\w*|gray\w*)", line)
            fmt.video = " ".join(str(x) for x in (
                m.group(1) if m else "?", (m.group(2) or "") if m else "",
                pix.group(1) if pix else "", f"{info.width}x{info.height}",
                round(info.fps, 2)))
        elif "Audio:" in line and not fmt.audio:
            m = re.search(r"Audio:\s*(\w+).*?(\d+)\s*Hz,\s*([\w.() ]+?)(?:,|$)", line)
            fmt.audio = " ".join(m.groups()) if m else "audio"
    return fmt


def can_merge_fast(formats: List[StreamFormat]) -> bool:
    if not formats:
        return False
    first = formats[0]
    return all(f.video == first.video and f.audio == first.audio and f.video for f in formats)


# --------------------------------------------------------------------------- #
# Merge
# --------------------------------------------------------------------------- #
def _concat_list(paths: List[str], folder: str) -> str:
    path = os.path.join(folder, "list.txt")
    with open(path, "w", encoding="utf-8") as f:
        for p in paths:
            f.write("file '" + os.path.abspath(p).replace("\\", "/").replace("'", r"'\''") + "'\n")
    return path


def merge_videos(paths: List[str], out_path: str, mode: str = "auto",
                 progress: Optional[Progress] = None,
                 should_stop: Optional[Stop] = None) -> dict:
    """Join `paths` (in this order) into out_path.
    mode: auto (fast when possible) / fast / reencode.
    Returns {"video", "fast", "duration", "count"}."""
    if len(paths) < 2:
        raise ValueError("Choose at least 2 videos to merge.")
    out_abs = os.path.normcase(os.path.abspath(out_path))
    if any(os.path.normcase(os.path.abspath(p)) == out_abs for p in paths):
        raise ValueError("The merged video cannot overwrite one of the videos being merged.")
    formats = []
    for k, p in enumerate(paths):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        if progress:
            progress(int(k * 8 / len(paths)), f"Checking video {k + 1}/{len(paths)}...")
        formats.append(stream_format(p))
    total = sum(f.duration for f in formats)
    fast = mode == "fast" or (mode == "auto" and can_merge_fast(formats))
    os.makedirs(os.path.dirname(os.path.abspath(out_path)) or ".", exist_ok=True)
    tmp = tempfile.mkdtemp(prefix="voxdub_merge_",
                           dir=os.path.dirname(os.path.abspath(out_path)))
    try:
        if fast:
            lst = _concat_list(paths, tmp)
            cmd = [find_ffmpeg(), "-hide_banner", "-y", "-f", "concat", "-safe", "0",
                   "-i", lst, "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy",
                   "-movflags", "+faststart", "-progress", "pipe:1", "-nostats",
                   os.path.abspath(out_path)]
            _run_with_progress(cmd, tmp, total, progress, should_stop, "Joining (no re-encode)")
        else:
            _merge_reencode(paths, formats, out_path, tmp, total, progress, should_stop)
    except ExportFailed as e:
        raise RuntimeError(str(e).replace("export failed", "merge failed")) from None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if progress:
        progress(100, "Merged")
    return {"video": os.path.abspath(out_path), "fast": fast, "duration": total,
            "count": len(paths)}


def merge_size(formats: List[StreamFormat]):
    """Size of a re-encoded merge: the largest video (nothing is shrunk)."""
    big = max(formats, key=lambda f: f.width * f.height)
    return max(2, big.width // 2 * 2), max(2, big.height // 2 * 2)


def _merge_reencode(paths, formats, out_path, tmp, total, progress, should_stop):
    W, H = merge_size(formats)
    fps = max((f.fps for f in formats), default=30)
    fps = fps if fps > 1 else 30
    cmd = [find_ffmpeg(), "-hide_banner", "-y"]
    parts, cat = [], ""
    for i, (p, f) in enumerate(zip(paths, formats)):
        cmd += ["-i", os.path.abspath(p)]
        parts.append(f"[{i}:v:0]scale={W}:{H}:force_original_aspect_ratio=decrease,"
                     f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,fps={fps:g},"
                     f"format=yuv420p[v{i}]")
        if f.audio:
            parts.append(f"[{i}:a:0]aformat=sample_fmts=fltp:sample_rates=44100:"
                         f"channel_layouts=stereo[a{i}]")
        else:           # silent video: add silence so the audio stays in sync
            parts.append(f"anullsrc=r=44100:cl=stereo,atrim=0:{f.duration:.3f}[a{i}]")
        cat += f"[v{i}][a{i}]"
    parts.append(f"{cat}concat=n={len(paths)}:v=1:a=1[vout][aout]")
    script = os.path.join(tmp, "graph.txt")
    with open(script, "w", encoding="utf-8") as fh:
        fh.write(";\n".join(parts))
    from .media import ffmpeg_major_version
    cmd += (["-/filter_complex", script] if ffmpeg_major_version() >= 7
            else ["-filter_complex_script", script])
    opts = ExportOptions(output_path=out_path, crf=20)
    enc = pick_encoder("auto")
    cmd += ["-map", "[vout]", "-map", "[aout]"] + _video_codec_args(enc, opts) + [
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
        "-progress", "pipe:1", "-nostats", os.path.abspath(out_path)]
    try:
        _run_with_progress(cmd, tmp, total, progress, should_stop, "Joining (re-encoding)")
    except ExportFailed:
        if enc != "nvenc":
            raise
        cmd = [c for c in cmd]      # NVIDIA failed: same on the CPU
        i = cmd.index("-c:v")
        j = cmd.index("-c:a")
        cmd[i:j] = _video_codec_args("x264", opts)
        _run_with_progress(cmd, tmp, total, progress, should_stop, "Joining (re-encoding)")


# --------------------------------------------------------------------------- #
# Split
# --------------------------------------------------------------------------- #
def plan_split(duration: float, part_seconds: float, min_last: float = 0.0) -> List[float]:
    """Cut times. A last part shorter than min_last seconds is added to the
    part before it."""
    if part_seconds <= 0 or duration <= part_seconds:
        return []
    cuts, t = [], part_seconds
    while t < duration - 0.5:
        cuts.append(t)
        t += part_seconds
    if cuts and min_last > 0 and duration - cuts[-1] < min_last:
        cuts.pop()
    return cuts


def part_lengths(duration: float, cuts: List[float]) -> List[float]:
    edges = [0.0] + cuts + [duration]
    return [b - a for a, b in zip(edges, edges[1:])]


_BAD_CHARS = '<>:"/\\|?*'


def part_template(name: str) -> str:
    """File name of every part, with {n} where the part number goes
    (no {n}: "<name>_part{n}" as before). Characters Windows does not allow
    in a file name are left out."""
    name = "".join(c for c in (name or "").strip() if c not in _BAD_CHARS and ord(c) >= 32)
    name = name.strip(" .") or "part"
    if "{n}" not in name:
        name += "_part{n}"
    return name


def resolve_part_name(name: str, start: int = 1) -> Tuple[str, int]:
    """(template, first number) of a Part name typed by the user.
    "រឿង ភាគ{n}" -> as typed. "រឿង ភាគ01" (a number at the end, no {n}) ->
    "រឿង ភាគ{n}" starting at 1: the typed number is the first part, so
    ភាគ06 gives ភាគ06, ភាគ07 ... and never "ភាគ01_part01"."""
    name = (name or "").strip()
    if "{n}" not in name:
        m = re.search(r"(\d+)\s*$", name)
        if m and m.start() > 0:
            return part_template(name[:m.start()] + "{n}"), int(m.group(1))
    return part_template(name), max(0, int(start or 1))


def part_name(template: str, number: int, digits: int = 2) -> str:
    return template.replace("{n}", f"{number:0{digits}d}")


def split_video(path: str, part_seconds: float, out_dir: str, exact: bool = False,
                min_last: float = 0.0, name: str = "",
                progress: Optional[Progress] = None,
                should_stop: Optional[Stop] = None, start: int = 1) -> dict:
    """Cut `path` into parts of part_seconds. Files: <name>_part01.mp4 ...
    `name` may hold {n} for the part number: "រឿង AI និយាយខ្មែរ ភាគ{n}" ->
    ...ភាគ01.mp4, ភាគ02.mp4 ...; `start` = the number of the first part.
    Returns {"parts": [paths], "exact": bool}."""
    info = get_media_info(path)
    cuts = plan_split(info.duration, part_seconds, min_last)
    if not cuts:
        raise ValueError(f"The video is {info.duration / 60:.1f} min long - nothing to split "
                         f"into {part_seconds / 60:g}-minute parts.")
    os.makedirs(out_dir, exist_ok=True)
    if name:
        template, start = resolve_part_name(name, start)
    else:
        start = max(0, int(start or 1))
        template = part_template(os.path.splitext(os.path.basename(path))[0])
    digits = max(2, len(str(start + len(cuts))))
    # ffmpeg's segment pattern: a "%" in a folder / file name must be doubled
    pattern = os.path.join(out_dir.replace("%", "%%"),
                           template.replace("%", "%%").replace("{n}", f"%0{digits}d") + ".mp4")
    times = ",".join(f"{c:.3f}" for c in cuts)
    tmp = tempfile.mkdtemp(prefix="voxdub_split_", dir=out_dir)

    def command(enc: str) -> list:
        cmd = [find_ffmpeg(), "-hide_banner", "-y", "-i", os.path.abspath(path),
               "-map", "0:v:0", "-map", "0:a:0?"]
        if exact:
            cmd += _video_codec_args(enc, ExportOptions(output_path="", crf=20)) + [
                "-force_key_frames", times, "-c:a", "aac", "-b:a", "192k"]
            if enc == "nvenc":      # NVENC only cuts at forced keyframes when they are IDR
                cmd += ["-forced-idr", "1"]
        else:
            cmd += ["-c", "copy"]
        return cmd + ["-f", "segment", "-segment_times", times, "-reset_timestamps", "1",
                      "-segment_start_number", str(start),
                      "-segment_format_options", "movflags=+faststart",
                      "-progress", "pipe:1", "-nostats", pattern]

    label = "Cutting (exact)" if exact else "Cutting (no re-encode)"
    encoders = [pick_encoder("auto")] if exact else ["copy"]
    if encoders[0] == "nvenc":
        encoders.append("x264")             # NVIDIA failed: same on the CPU
    try:
        for k, enc in enumerate(encoders):
            try:
                _run_with_progress(command(enc), tmp, info.duration, progress, should_stop, label)
                break
            except ExportFailed as e:
                if k == len(encoders) - 1:
                    raise RuntimeError(str(e).replace("export failed", "split failed")) from None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    parts = [os.path.join(out_dir, part_name(template, start + i, digits) + ".mp4")
             for i in range(len(cuts) + 1)]
    parts = [p for p in parts if os.path.isfile(p)]
    if progress:
        progress(100, f"Split into {len(parts)} parts")
    return {"parts": parts, "exact": exact}
