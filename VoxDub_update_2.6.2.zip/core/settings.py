"""
settings.py - Per-user app settings (NOT stored in project files).

Secrets like the Azure Speech key and the license key live here, in the
user's own profile folder, so a project .json can be shared without them:
    Windows : %APPDATA%\\VoxDubPRO\\settings.json
    other   : ~/.config/voxdubstudiotesting/settings.json
"""

import json
import os
import sys
from typing import Any

from .appinfo import DATA_FOLDER

_cache = None


def settings_dir() -> str:
    override = os.environ.get("VOXDUB_SETTINGS_DIR")      # used by tests
    if override:
        return override
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, DATA_FOLDER)
    return os.path.join(os.path.expanduser("~"), ".config", DATA_FOLDER.lower())


def _path() -> str:
    return os.path.join(settings_dir(), "settings.json")


def _load() -> dict:
    global _cache
    if _cache is None:
        try:
            with open(_path(), "r", encoding="utf-8") as f:
                _cache = json.load(f)
        except (OSError, ValueError):
            _cache = {}
        if not isinstance(_cache, dict):      # damaged file: start clean
            _cache = {}
    return _cache


def get(key: str, default: Any = None) -> Any:
    return _load().get(key, default)


def set(key: str, value: Any) -> None:          # noqa: A001 - simple API
    data = _load()
    data[key] = value
    os.makedirs(settings_dir(), exist_ok=True)
    tmp = _path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _path())


def reload() -> None:
    global _cache
    _cache = None


def mask(secret: str) -> str:
    """'••••••••wxyz' - shows that a secret is set without revealing it."""
    secret = secret or ""
    if len(secret) <= 8:
        return "•" * len(secret)
    return "•" * 8 + secret[-4:]
