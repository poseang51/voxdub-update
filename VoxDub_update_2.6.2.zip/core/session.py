"""
session.py - Crash recovery: was the app closed properly last time?

While the app runs, <data dir>/session.json says which project is open and
whether it has unsaved edits (kept in its autosave file every minute). A
normal exit removes the file. If it is still there at the next start, the
app did not close properly (crash, power cut, Task Manager) and offers to
open the unsaved work again.
"""

import json
import os
import time
from typing import Optional

from .media import data_dir

NAME = "session.json"


def _path(folder: Optional[str] = None) -> str:
    return os.path.join(folder or data_dir(), NAME)


def _write(info: dict, folder: Optional[str] = None) -> None:
    path = _path(folder)
    try:
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass


def start(folder: Optional[str] = None) -> Optional[dict]:
    """Begin a session. Returns what the last session left behind when it did
    not end properly (and had unsaved work worth opening), else None."""
    path = _path(folder)
    prev = None
    try:
        with open(path, encoding="utf-8") as f:
            prev = json.load(f)
    except (OSError, ValueError):
        prev = None
    _write({"pid": os.getpid(), "time": time.time(), "autosave": "", "project": "",
            "video": "", "dirty": False}, folder)
    return recoverable(prev)


def recoverable(prev: Optional[dict]) -> Optional[dict]:
    if not isinstance(prev, dict) or not prev.get("dirty"):
        return None
    auto = prev.get("autosave") or ""
    if not auto or not os.path.isfile(auto):
        return None
    proj = prev.get("project") or ""
    if proj and os.path.isfile(proj) and os.path.getmtime(proj) >= os.path.getmtime(auto):
        return None                 # saved after the last autosave: nothing lost
    return prev


def note(autosave: str, project: str = "", video: str = "", dirty: bool = True,
         folder: Optional[str] = None) -> None:
    """Remember the open project (called after each autosave / save)."""
    _write({"pid": os.getpid(), "time": time.time(), "autosave": autosave or "",
            "project": project or "", "video": video or "", "dirty": bool(dirty)}, folder)


def end(folder: Optional[str] = None) -> None:
    """A normal exit: nothing to recover next time."""
    try:
        os.remove(_path(folder))
    except OSError:
        pass
