"""
funasr_stt.py - Paraformer-zh / SenseVoice-Small speech-to-text (2.6.2, Test).

FunASR (Alibaba DAMO, MIT) reads Chinese much faster than Whisper and seldom
skips a line under music. It needs PyTorch, which the app itself does not
ship: core/funasr_worker.py runs with the VoxCPM Python (venv-voxcpm has
torch + funasr + modelscope already) - see core/voxcpm.python_path().

Engines (Speech-to-text › Engine):  "paraformer"  Chinese (Mandarin) only
                                    "sensevoice"  zh / yue / en / ja / ko
"""

import json
import os
import subprocess
import threading
from typing import Callable, List, Optional, Tuple

from . import settings
from .media import no_window
from .project import Segment, new_id

ENGINES = {"paraformer": "Paraformer-zh", "sensevoice": "SenseVoice-Small"}


class FunASRError(RuntimeError):
    pass


def _worker() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "funasr_worker.py")


def python_path() -> str:
    from . import voxcpm

    return voxcpm.python_path()


def ready() -> bool:
    p = python_path()
    return bool(p) and os.path.isfile(p)


def transcribe(audio_path: str, engine: str, report: Callable[[float, str], None],
               should_stop: Optional[Callable[[], bool]] = None, start_at: float = 0.0,
               on_segment: Optional[Callable[[Segment], None]] = None,
               language: str = "auto") -> Tuple[List[Segment], str, str]:
    """Returns (segments, language, device). Raises FunASRError."""
    from . import voxcpm

    py = python_path()
    if not py or not os.path.isfile(py):
        raise FunASRError(f"{ENGINES.get(engine, engine)} needs the VoxCPM environment "
                          "(setup_voxcpm.bat) – it was not found")
    req = {"wav": os.path.abspath(audio_path), "model": engine,
           "device": settings.get("funasr_device", "auto") or "auto",
           "start_at": float(start_at or 0.0),
           "language": language if language in ("zh", "yue", "en", "ja", "ko") else "auto"}
    proc = subprocess.Popen([py, "-u", _worker()], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                            encoding="utf-8", errors="replace", env=voxcpm._child_env(),
                            creationflags=no_window())
    err_tail: List[str] = []

    def read_err():                      # keep the last lines for the message / log
        for line in proc.stderr:
            err_tail.append(line.rstrip())
            del err_tail[:-20]

    threading.Thread(target=read_err, daemon=True).start()
    proc.stdin.write(json.dumps(req, ensure_ascii=False) + "\n")
    proc.stdin.flush()
    proc.stdin.close()

    segments: List[Segment] = []
    done = None
    last_end = 0.0
    try:
        for line in proc.stdout:
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            try:
                msg = json.loads(line)
            except ValueError:
                continue
            if "seg" in msg:
                s = msg["seg"]
                a = max(float(s["start"]), last_end)
                b = float(s["end"])
                if b - a < 0.15:
                    continue
                last_end = b
                seg = Segment(id=new_id(), start=round(a, 3), end=round(b, 3),
                              text=str(s["text"]).strip())
                segments.append(seg)
                if on_segment:
                    on_segment(seg)
            elif "p" in msg:
                report(min(99, int(msg["p"])), f"{msg.get('msg', '')} – {len(segments)} lines")
            elif "ok" in msg:
                done = msg
    finally:
        if proc.poll() is None:
            try:
                proc.kill()
            except Exception:
                pass
        proc.wait()
    if done is None or not done.get("ok"):
        why = (done or {}).get("error") or (err_tail[-1] if err_tail else "it stopped")
        if err_tail:
            print("[funasr] " + "\n[funasr] ".join(err_tail[-8:]))
        raise FunASRError(f"{ENGINES.get(engine, engine)} failed: {why}")
    dev = done.get("device", "")
    report(100, f"Transcription done: {len(segments)} lines [{ENGINES.get(engine)} · {dev}]")
    return segments, done.get("lang") or "zh", dev
