"""
batch.py - Dub many videos one after another (Batch queue).

Every queued video goes through two stages:
  1. dub     - load video -> (find original subtitles) -> Auto Dub
  2. export  - render the MP4 (+ .srt)
The UI runs the two stages in two threads, so video 1 can export while
video 2 is being transcribed. In "dub only" mode a video stops after
stage 1 so it can be checked in the editor first, then exported.

Settings (language, voice, volumes, Style tab) come from a base settings
dict taken from the main window; each item can override the language and
voice. The same video can be queued in several languages: the Whisper
transcription is done once and reused.

Every item has its own work folder with an autosave file, so a video that
failed or was stopped continues where it left off. The queue itself is
saved in the user settings folder and comes back after a restart.

Stories: a folder added to the queue may hold one story (its episodes) or
many story sub-folders. Each video remembers its story (the sub-folder it
came from) and is exported into the same sub-folder of the output folder,
so the stories never mix.
"""

import copy
import csv
import json
import os
import re
import time
from dataclasses import asdict, dataclass, fields
from typing import Callable, Dict, List, Optional, Tuple

from . import pipeline, settings
from .export import ExportOptions, export_video
from .hardsub import detect_black_bars, detect_subtitle_area
from .project import _LOOK_FIELDS, Project, Segment
from .sync import build_subtitles
from .tts import AUTO_VOICE, voices_for

Progress = Callable[[int, str], None]
Stop = Callable[[], bool]

from .media import VIDEO_EXT  # noqa: E402  (.ts, .flv ... too)

# Project fields that are settings (copied to every queued video).
# Everything else (segments, clips, video info) belongs to one video.
SETTING_FIELDS = (
    "source_lang", "target_lang", "tts_engine", "voice", "whisper_model", "max_speed",
    "stretch_video", "plain_voice", "voxcpm_two_voices", "ocr_check", "stt_engine", "translate_engine",
    "original_volume", "dub_volume", "mute_original_speech", "subtitle_scale",
    "sub_font", "sub_color", "sub_bold", "sub_outline", "sub_outline_color", "sub_shadow",
    "sub_box", "sub_box_color", "sub_box_opacity", "sub_bottom", "sub_x", "subs_hidden",
    "cover_enabled", "cover_rect", "cover_mode", "sub_position", "out_ratio", "ratio_fill",
    "out_width", "out_height", "out_fps", "audio_rate", "audio_channels",
    "crop_left", "crop_top", "crop_right", "crop_bottom", "zoom",
    "logo_path", "logo_corner", "logo_pos", "logo_motion", "logo_size", "logo_opacity",
    "extra_logos", "green_overlays", "brand_text", "brand_corner", "brand_pos", "brand_motion", "brand_size", "brand_color",
)
# Editor tools (Crop & Rotate, Color, Audio Properties, Equalizer, Noise
# Removal, Audio Effects, fades, Project settings) - the queue applies them to
# every video too.
TOOL_FIELDS = tuple(k for k in _LOOK_FIELDS if k not in SETTING_FIELDS)
SETTING_FIELDS = SETTING_FIELDS + TOOL_FIELDS

# item.status
WAITING = "waiting"            # to dub
RUNNING = "running"            # dubbing
DUBBED = "dubbed"              # dub only: ready to check, not exported
EXPORT_WAIT = "export_wait"    # dubbed, waiting for the export thread
EXPORTING = "exporting"
DONE = "done"
FAILED = "failed"
STOPPED = "stopped"
SKIPPED = "skipped"

ACTIVE = (RUNNING, EXPORTING)
PENDING = (WAITING, EXPORT_WAIT)


@dataclass
class BatchItem:
    video_path: str
    target_lang: str = ""       # "" = base settings
    voice: str = ""             # "" = base settings / automatic for the language
    status: str = WAITING
    message: str = ""
    output: str = ""
    work_dir: str = ""          # kept so a re-run continues
    duration: float = 0.0       # video seconds (for time left)
    seconds: float = 0.0        # time spent on this item
    cover: str = ""             # original subtitles: found / series / none ("" = not searched)
    bars: str = ""              # black bars: cropped / none ("" = not searched)
    story: str = ""             # story sub-folder, e.g. "Story A" ("" = single video)
    engine: str = ""            # voice engine for this row ("" = base settings), e.g. voxcpm

    def autosave(self) -> str:
        return os.path.join(self.work_dir, "autosave.voxdub.json") if self.work_dir else ""

    def key(self, base_lang: str = "") -> tuple:
        return (os.path.normcase(os.path.abspath(self.video_path)),
                self.target_lang or base_lang)


def odd_rows(items, base_lang: str) -> Dict[str, list]:
    """2.4 pre-start check: rows still to do whose own language is not the
    queue's Dub to language ({lang: [items]}) - e.g. a story added as Chinese.
    A video that ALSO has a row in the queue's language was given more
    languages on purpose (➕ Languages…) and is not asked about."""
    out: Dict[str, list] = {}
    if not base_lang:
        return out
    has_base = {os.path.normcase(os.path.abspath(i.video_path)) for i in items
                if (i.target_lang or base_lang) == base_lang}
    for it in items:
        if it.status in PENDING + (FAILED, STOPPED) and it.target_lang \
                and it.target_lang != base_lang \
                and os.path.normcase(os.path.abspath(it.video_path)) not in has_base:
            out.setdefault(it.target_lang, []).append(it)
    return out


# --------------------------------------------------------------------------- #
# Settings
# --------------------------------------------------------------------------- #
def settings_of(project: Project) -> dict:
    return {k: copy.deepcopy(getattr(project, k)) for k in SETTING_FIELDS}


def preview_project(base: dict, video_path: str) -> Project:
    """A light Project for one queued video with the queue's settings - enough
    to render a preview frame or play a few seconds (no audio extraction)."""
    from .media import get_media_info

    p = Project()
    for k, v in base.items():
        if k in SETTING_FIELDS:
            setattr(p, k, copy.deepcopy(v))
    info = get_media_info(video_path)
    p.video_path = os.path.abspath(video_path)
    p.video_duration = info.duration
    p.width, p.height = info.width, info.height
    p.fps = info.fps
    p.has_audio = info.has_audio
    p.reset_video_track()
    return p


def tools_summary(base: dict) -> List[str]:
    """Short names of the editor tools switched on in the queue's settings."""
    from . import effects

    p = Project()
    for k in SETTING_FIELDS:
        if k in base:
            setattr(p, k, copy.deepcopy(base[k]))
    out = []
    if p.out_ratio != "original":
        size = f"{p.out_width}x{p.out_height}" if p.out_width and p.out_height else p.out_ratio
        out.append(f"size {size}")
    if p.out_fps:
        out.append(f"{p.out_fps:g} FPS")
    if (p.audio_rate, p.audio_channels) != (44100, 2):
        out.append(f"{p.audio_rate} Hz {({1: 'mono', 6: '5.1'}).get(p.audio_channels, 'stereo')}")
    if any((p.crop_left, p.crop_top, p.crop_right, p.crop_bottom)):
        out.append("crop")
    if effects.has_rotation(p):
        out.append(f"rotate {p.rotate:g}°")
    if (p.zoom or 1.0) > 1.001:
        out.append(f"zoom {round(p.zoom * 100)}%")
    if p.flip_h or p.flip_v:
        out.append("flip " + " + ".join(n for n, on in (("horizontal", p.flip_h),
                                                         ("vertical", p.flip_v)) if on))
    if effects.has_color(p):
        out.append("color")
    if p.video_fade_in or p.video_fade_out:
        out.append("video fade")
    if getattr(p, "bg_mode", "original") == "music":
        out.append("music & effects only")
    if abs(p.speed() - 1.0) > 0.001:
        out.append(f"speed {round(p.speed() * 100)}%")
    for track, name in (("orig", "original sound"), ("voice", "AI voice")):
        on = [k for k, v in effects.track_active(p, track).items() if v]
        if on:
            out.append(f"{name}: " + "/".join({"eq": "EQ", "noise": "noise removal",
                                               "effects": "effect"}[k] for k in on))
    if p.orig_normalize or p.orig_fade_in or p.orig_fade_out:
        out.append("original sound: normalize/fade")
    return out


def settings_for(item: BatchItem, base: dict) -> dict:
    """Base settings with the item's language / voice engine / voice applied."""
    s = copy.deepcopy(base)
    changed = False
    if item.target_lang and item.target_lang != base.get("target_lang"):
        s["target_lang"] = item.target_lang
        changed = True
    if item.engine and item.engine != base.get("tts_engine"):
        s["tts_engine"] = item.engine
        changed = True
    if changed and not item.voice:  # the base voice is for another language / engine
        voices = voices_for(s.get("tts_engine", "edge"), s["target_lang"])
        s["voice"] = AUTO_VOICE if any(v == AUTO_VOICE for v, _ in voices) else (
            voices[0][0] if voices else "")
    if item.voice:
        s["voice"] = item.voice
    return s


# --------------------------------------------------------------------------- #
# Files / names
# --------------------------------------------------------------------------- #
def new_work_dir(root: str, video_path: str, lang: str = "") -> str:
    stem = os.path.splitext(os.path.basename(video_path))[0]
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in stem)[:40]
    tag = f"_{lang}" if lang else ""
    path = os.path.join(root, f"{safe}{tag}_{time.strftime('%Y%m%d_%H%M%S')}")
    n = 1
    while os.path.exists(path):        # two items started in the same second
        n += 1
        path = os.path.join(root, f"{safe}{tag}_{time.strftime('%Y%m%d_%H%M%S')}_{n}")
    return path


def safe_name(name: str) -> str:
    """A folder name Windows accepts."""
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip().rstrip(". ")
    return name or "_"


def story_dir(out_dir: str, story: str = "") -> str:
    """Output folder of a story: <out_dir>/<story sub-folders>."""
    parts = [safe_name(x) for x in re.split(r"[\\/]+", story or "") if x and x != "."]
    return os.path.join(out_dir, *parts) if parts else out_dir


def series_path(out_dir: str, story: str = "") -> str:
    """The cast file shared by the episodes of one story (series)."""
    from .series import FILE_NAME

    return os.path.join(story_dir(out_dir, story), FILE_NAME)


def output_path_for(video_path: str, out_dir: str, target_lang: str, story: str = "") -> str:
    """<out_dir>/<story>/<name>_dubbed_<lang>.mp4, never the source file itself."""
    stem = os.path.splitext(os.path.basename(video_path))[0]
    path = os.path.join(story_dir(out_dir, story), f"{stem}_dubbed_{target_lang}.mp4")
    if os.path.normcase(os.path.abspath(path)) == os.path.normcase(os.path.abspath(video_path)):
        path = os.path.join(os.path.dirname(path), f"{stem}_dubbed_{target_lang}_1.mp4")
    return path


def natural_key(path: str):
    """Sort key that puts episode 2 before episode 10."""
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", path.lower())]


def find_videos(folder: str) -> List[str]:
    """All videos in a folder and its sub-folders, in episode order."""
    out = []
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if not d.startswith(".")]
        out += [os.path.join(root, f) for f in files if f.lower().endswith(VIDEO_EXT)]
    return sorted(out, key=natural_key)


def find_stories(folder: str) -> List[Tuple[str, str]]:
    """(video, story) for every video in `folder`. A video in a sub-folder
    belongs to that sub-folder's story ("Story A", or "Story A/Season 1");
    a video directly in `folder` belongs to the story named like `folder`."""
    folder = os.path.abspath(folder)
    top = os.path.basename(folder.rstrip("\\/")) or "videos"
    out = []
    for v in find_videos(folder):
        rel = os.path.relpath(os.path.dirname(v), folder)
        out.append((v, top if rel in (".", "") else rel.replace("\\", "/")))
    return out


# --------------------------------------------------------------------------- #
# Stage 1: dub
# --------------------------------------------------------------------------- #
def _reuse_transcript(project: Project, donor_autosave: str) -> bool:
    """Copy a finished Whisper transcription of the same video (other language)."""
    try:
        donor = Project.load(donor_autosave)
    except Exception:
        return False
    if not (donor.transcribe_done and donor.segments):
        return False
    if (donor.source_lang or "auto") != (project.source_lang or "auto"):
        return False                # heard with another Speech language (maybe wrong)
    if donor.source_lang not in ("", "auto") and donor.source_lang == donor.target_lang:
        return False                # e.g. Speech = Khmer for a Chinese video: nonsense
    project.segments = [Segment(s.id, s.start, s.end, s.text, gender=s.gender,
                                speaker=s.speaker) for s in donor.segments]
    project.cast = {k: dict(v) for k, v in (donor.cast or {}).items()}
    project.detected_lang = donor.detected_lang
    project.transcribe_done = True
    project.transcribed_until = project.video_duration
    build_subtitles(project, use_translation=False)
    return True


def _find_cover(project: Project, item: BatchItem, cover_hint: Optional[List[float]],
                progress: Optional[Progress], should_stop: Optional[Stop]) -> None:
    """Hide the original burned-in subtitles of this video.
    Not found (few lines of dialogue) -> use the area found in another
    episode of the same series (cover_hint); otherwise keep the base settings."""
    if progress:
        progress(4, "Looking for the original subtitles...")
    # (project.video_path: the MP4 copy of a .ts / .flv source)
    rect = detect_subtitle_area(project.video_path or item.video_path, should_stop=should_stop)
    item.cover = "found"
    if rect is None and cover_hint:
        rect, item.cover = list(cover_hint), "series"
    if rect is None:
        item.cover = "none"
        return
    project.cover_enabled = True
    project.cover_rect = rect          # 2.4: our subtitles stay where they were put


def _remove_black_bars(project: Project, item: BatchItem,
                       progress: Optional[Progress], should_stop: Optional[Stop]) -> None:
    """Crop off this video's own black bars (replaces the base crop edges;
    zoom stays)."""
    if progress:
        progress(3, "Looking for black bars...")
    edges = detect_black_bars(project.video_path or item.video_path, should_stop=should_stop)
    item.bars = "cropped" if edges else "none"
    if edges:
        project.crop_left, project.crop_top, project.crop_right, project.crop_bottom = edges


def cover_of(autosave: str) -> Optional[List[float]]:
    """The hidden-subtitle area of a dubbed item (None when not hidden)."""
    try:
        with open(autosave, "r", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        return None
    return d.get("cover_rect") if d.get("cover_enabled") else None


def dub_item(item: BatchItem, base: dict, work_root: str, auto_cover: bool = False,
             donors: Optional[List[str]] = None, progress: Optional[Progress] = None,
             should_stop: Optional[Stop] = None,
             cover_hint: Optional[List[float]] = None, auto_crop: bool = False,
             series_cast: str = "") -> Project:
    """Stage 1. Continues from the item's autosave when there is one.
    donors: autosave files of the same video in other languages.
    cover_hint: original-subtitle area found in another episode (same folder).
    series_cast: the series' cast file (core/series.py): the same character
    gets the same voice in every episode."""
    def stopped():
        return bool(should_stop and should_stop())

    project = None
    if item.autosave() and os.path.isfile(item.autosave()):
        try:
            project = Project.load(item.autosave())      # continue an earlier attempt
        except Exception:
            project = None
    wanted = settings_for(item, base)
    if project is not None and wanted.get("source_lang") and \
            project.source_lang != wanted["source_lang"] and project.segments:
        # Speech (the language spoken in the video) was changed - e.g. it was
        # Khmer for a Chinese drama: the old transcript is wrong, start again
        # (nothing of the old attempt is reused)
        item.work_dir = ""
        project = None
        donors = []
    if project is not None and project.target_lang != wanted["target_lang"]:
        # the language was changed since the last attempt: a new work folder,
        # but the transcription of the old one is reused
        donors = [item.autosave()] + list(donors or [])
        item.work_dir = ""
        project = None
    if project is not None and project.target_lang == wanted["target_lang"]:
        # the voice / engine may have been changed since the last attempt:
        # lines made with the old voice are voiced again by Auto Dub
        project.voice = wanted["voice"]
        project.tts_engine = wanted.get("tts_engine", project.tts_engine)
    if project is None or not project.has_video():
        project = Project()
        for k, v in wanted.items():
            setattr(project, k, v)
        item.work_dir = item.work_dir or new_work_dir(work_root, item.video_path,
                                                      project.target_lang)
        pipeline.prepare_video(project, item.video_path, item.work_dir,
                               pipeline._scaled(progress, 0, 4))
        if auto_crop:
            _remove_black_bars(project, item, progress, should_stop)
        if auto_cover:
            _find_cover(project, item, cover_hint, progress, should_stop)
        for d in donors or []:
            if _reuse_transcript(project, d):
                if progress:
                    progress(6, "Reusing the transcription from another language")
                break
        project.save(item.autosave())
    else:
        changed = False
        if auto_crop and not item.bars:
            _remove_black_bars(project, item, progress, should_stop)
            changed = True
        if auto_cover and not project.cover_enabled:
            # an earlier attempt did not find the original subtitles: look again
            _find_cover(project, item, cover_hint, progress, should_stop)
            changed = True
        if changed:
            project.save(item.autosave())
    item.duration = project.video_duration
    if series_cast and project.series_cast != series_cast:
        project.series_cast = series_cast
        if project.cast:                     # characters found by an earlier attempt
            from . import series

            series.apply(project, series_cast)
    if stopped():
        raise InterruptedError("Stopped")
    project.engine_notes = []
    if project.has_audio:
        pipeline.auto_dub(project, pipeline._scaled(progress, 6, 100), should_stop)
    project.save(item.autosave())
    return project


# --------------------------------------------------------------------------- #
# Stage 2: export
# --------------------------------------------------------------------------- #
STD_FPS = 30.0
STD_SIZES = {"portrait": (1080, 1920), "landscape": (1920, 1080), "square": (1080, 1080)}


def same_format(project: Project) -> Tuple[int, int, float]:
    """Make an episode come out in ONE standard format, so all the episodes
    of a story are alike and Merge joins them in seconds (stream copy)
    instead of re-encoding for half an hour.

    Size: 1080x1920 (portrait), 1920x1080 (landscape) or 1080x1080 - the
    same for every episode, whatever its own size (1080x1934, 720x1280 ...).
    A picture within 3 % of that shape fills it (a few pixels are cut); a
    very different one keeps the project's fill (blur / black).
    Frame rate: 30 fps for every episode. Sound: 44.1 kHz stereo.
    A size / frame rate chosen in Project settings is kept (it is the same
    for every episode anyway). Export › Resolution still scales it all.
    Returns (W, H, fps)."""
    from .branding import output_size

    if project.out_ratio == "original" or not (project.out_width and project.out_height):
        w, h = output_size(project)
        aspect = w / max(1, h)
        kind = "portrait" if aspect < 0.8 else "landscape" if aspect > 1.25 else "square"
        tw, th = STD_SIZES[kind]
        project.out_ratio, project.out_width, project.out_height = "custom", tw, th
        if abs(aspect - tw / th) / (tw / th) <= 0.03:
            project.ratio_fill = "crop"
    if not project.out_fps:
        project.out_fps = STD_FPS
    project.audio_rate = 44100
    project.audio_channels = 2
    return int(project.out_width), int(project.out_height), float(project.out_fps)


def export_item(item: BatchItem, opts: ExportOptions, out_dir: str,
                progress: Optional[Progress] = None,
                should_stop: Optional[Stop] = None, uniform: bool = False) -> dict:
    """Stage 2: export the item's saved project (edits made in the editor
    are included). opts.output_path is ignored (made from out_dir).
    uniform: every episode in the same standard format (see same_format)."""
    if not item.autosave() or not os.path.isfile(item.autosave()):
        raise ValueError("This video was not dubbed yet.")
    project = Project.load(item.autosave())
    if uniform:
        same_format(project)            # (not saved: the editor keeps its own)
    opts = copy.copy(opts)
    opts.output_path = output_path_for(item.video_path, out_dir, project.target_lang,
                                       item.story)
    os.makedirs(os.path.dirname(opts.output_path), exist_ok=True)
    opts.original_volume = project.original_volume
    opts.dub_volume = project.dub_volume
    opts.burn_subtitles = opts.burn_subtitles and bool(project.shown_subtitles())
    if not opts.subtitle_font:
        opts.subtitle_font = project.sub_font or (
            "Noto Sans Khmer" if project.target_lang == "km" else "Arial")
    return export_video(project, opts, progress, should_stop)


def run_item(item: BatchItem, base: dict, opts: ExportOptions, out_dir: str, work_root: str,
             progress: Optional[Progress] = None, should_stop: Optional[Stop] = None,
             **kw) -> dict:
    """Both stages in one go."""
    dub_item(item, base, work_root, progress=pipeline._scaled(progress, 0, 80),
             should_stop=should_stop, **kw)
    return export_item(item, opts, out_dir, pipeline._scaled(progress, 80, 100), should_stop)


# --------------------------------------------------------------------------- #
# When the queue is finished: one video per story, cut into parts
# --------------------------------------------------------------------------- #
def finished_stories(items: List[BatchItem], base_lang: str = "") -> List[dict]:
    """The stories (+ language) whose episodes can be joined now:
    [{"story", "lang", "paths" (episode order), "missing" (episodes not exported)}].
    A story with an episode that is not exported is listed with "missing", so
    nothing is joined with a hole in it."""
    groups: Dict[tuple, List[BatchItem]] = {}
    for it in items:
        groups.setdefault((it.story, it.target_lang or base_lang), []).append(it)
    out = []
    for (story, lang), its in groups.items():
        its = sorted(its, key=lambda i: natural_key(i.video_path))
        missing = [os.path.basename(i.video_path) for i in its
                   if i.status != DONE or not i.output or not os.path.isfile(i.output)]
        out.append({"story": story, "lang": lang, "missing": missing,
                    "paths": [i.output for i in its if not missing]})
    return out


def merge_story(paths: List[str], out_dir: str, story: str, lang: str = "",
                split_minutes: float = 0.0, part_name: str = "", start: int = 1,
                progress: Optional[Progress] = None,
                should_stop: Optional[Stop] = None) -> dict:
    """Join a story's dubbed episodes (in order) into <story folder>/<story>_merged.mp4
    and, with split_minutes, cut it into parts in <story folder>/parts.
    part_name may hold {story} and {n} (see joiner.resolve_part_name).
    Episodes in the same format (Batch › Same format) are joined in seconds.
    Returns {"video", "fast", "duration", "count", "parts": [...]}."""
    from . import joiner

    if len(paths) < 2 and not split_minutes:
        raise ValueError("Only one episode - nothing to join.")
    folder = story_dir(out_dir, story)
    name = safe_name(os.path.basename(story.rstrip("/")) if story else "videos") or "videos"
    if lang:
        name += f"_{lang}"
    merged = os.path.join(folder, f"{name}_merged.mp4")
    share = 60 if split_minutes else 100
    if len(paths) >= 2:
        res = joiner.merge_videos(paths, merged, "auto",
                                  pipeline._scaled(progress, 0, share), should_stop)
    else:
        merged = paths[0]
        res = {"video": merged, "fast": True, "count": 1,
               "duration": joiner.stream_format(merged).duration}
    res["parts"] = []
    if split_minutes:
        info = joiner.stream_format(merged)
        if joiner.plan_split(info.duration, split_minutes * 60, 30):
            title = os.path.basename(story.rstrip("/")) if story else name
            template = (part_name or "{story} ភាគ{n}").replace("{story}", title)
            # stream copy: seconds, a cut lands on the nearest keyframe
            sp = joiner.split_video(merged, split_minutes * 60, os.path.join(folder, "parts"),
                                    exact=False, min_last=30, name=template,
                                    progress=pipeline._scaled(progress, share, 100),
                                    should_stop=should_stop, start=start)
            res["parts"] = sp["parts"]
    return res


# --------------------------------------------------------------------------- #
# Queue file + report
# --------------------------------------------------------------------------- #
def queue_path() -> str:
    return os.path.join(settings.settings_dir(), "batch_queue.json")


def save_queue(items: List[BatchItem], options: Dict, path: Optional[str] = None) -> None:
    path = path or queue_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"items": [asdict(i) for i in items], "options": options}, f,
                  ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def load_queue(path: Optional[str] = None):
    """Returns (items, options). Items that were busy when the app closed
    come back as Stopped."""
    try:
        with open(path or queue_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return [], {}
    if not isinstance(data, dict):
        return [], {}
    names = {f.name for f in fields(BatchItem)}
    items = []
    for d in data.get("items", []) or []:
        if not isinstance(d, dict):
            continue
        try:
            it = BatchItem(**{k: v for k, v in d.items() if k in names})
        except TypeError:
            continue
        if it.status in ACTIVE:
            it.status, it.message = STOPPED, "Stopped (app was closed)"
        items.append(it)
    return items, data.get("options", {}) or {}


def write_report(items: List[BatchItem], path: str, base_lang: str = "") -> str:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:     # BOM: opens in Excel
        w = csv.writer(f)
        w.writerow(["Story", "Video", "Language", "Status", "Minutes", "Time spent (min)",
                    "Output", "Message"])
        for i in items:
            w.writerow([i.story, i.video_path, i.target_lang or base_lang, i.status,
                        round(i.duration / 60, 1), round(i.seconds / 60, 1),
                        i.output, i.message])
    return path
