"""
rights.py - the Rights log: who owns a story and what we are allowed to do.

Nothing here can tell whether YouTube / Facebook will make a copyright claim
(their Content ID / Rights Manager databases are private). What it does: keep,
for every story (series) or single video, where the rights come from, until
when, and the contract - and warn before exporting a story that has none, or
whose licence has run out.

Stored in <settings dir>/rights.json (this program's own settings folder).
"""

import datetime as dt
import json
import os
from typing import Dict, Optional, Tuple

from . import settings

KINDS = [
    ("licensed", "Licensed – we bought / got the dubbing rights"),
    ("permission", "Written permission from the owner"),
    ("own", "Our own video"),
    ("public", "Public domain / free licence (CC)"),
    ("unknown", "Unknown – no rights yet"),
]
KIND_NAME = dict(KINDS)
SOON_DAYS = 30


def _path() -> str:
    return os.path.join(settings.settings_dir(), "rights.json")


def load_all() -> Dict[str, dict]:
    try:
        with open(_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
        return d.get("stories", {}) if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_all(stories: Dict[str, dict]) -> None:
    os.makedirs(settings.settings_dir(), exist_ok=True)
    tmp = _path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"version": 1, "stories": stories}, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _path())


def story_key(video_path: str, story: str = "") -> str:
    """The story a video belongs to: the batch story (folder of the series),
    else the folder the video is in, else the file name."""
    if story:
        return story.strip()
    folder = os.path.basename(os.path.dirname(os.path.abspath(video_path))) if video_path else ""
    return folder or os.path.splitext(os.path.basename(video_path or ""))[0]


def get(key: str) -> dict:
    return dict(load_all().get(key, {}))


def put(key: str, entry: dict) -> None:
    stories = load_all()
    clean = {k: entry.get(k, "") for k in ("kind", "owner", "source", "valid_until",
                                            "contract", "platforms", "notes")}
    clean["updated"] = dt.date.today().isoformat()
    stories[key] = clean
    _save_all(stories)


def _date(text: str) -> Optional[dt.date]:
    try:
        return dt.date.fromisoformat((text or "").strip())
    except ValueError:
        return None


def status(entry: dict, today: Optional[dt.date] = None) -> Tuple[str, str]:
    """("ok" / "soon" / "expired" / "missing", a sentence for the user)."""
    today = today or dt.date.today()
    kind = (entry or {}).get("kind", "")
    if not entry or kind in ("", "unknown"):
        if entry and entry.get("updated"):
            who = f" Owner: {entry['owner']}." if entry.get("owner") else ""
            return "missing", f"No rights yet (noted on {entry['updated']}).{who}"
        return "missing", "No rights recorded for this story."
    if kind in ("own", "public"):
        return "ok", KIND_NAME[kind].split(" – ")[0] + "."
    until = _date(entry.get("valid_until", ""))
    who = entry.get("owner") or "the owner"
    if until is None:
        return "ok", f"{KIND_NAME[kind].split(' – ')[0]} from {who} (no end date)."
    if until < today:
        return "expired", f"The licence from {who} ended on {until.isoformat()}."
    left = (until - today).days
    if left <= SOON_DAYS:
        return "soon", f"The licence from {who} ends in {left} days ({until.isoformat()})."
    return "ok", f"Licensed from {who} until {until.isoformat()}."


def check(video_path: str, story: str = "") -> Tuple[str, str, str]:
    """(key, state, text) for a video."""
    key = story_key(video_path, story)
    state, text = status(get(key))
    return key, state, text
