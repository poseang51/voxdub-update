"""
resources.py - GPU & AI resource monitor (2.3).

  gpu_stats()   NVIDIA GPU use, memory (VRAM) and temperature, from nvidia-smi
                (comes with the NVIDIA driver; [] when there is no NVIDIA GPU)
  ram_stats()   used / total memory of the PC (MB)
  whisper_plan(size, free_mb)
                which Whisper model / device to use when the GPU memory is
                short: a smaller model on the GPU, or the same model on the CPU
                (Settings: "low_vram" = "smaller" / "cpu")

Nothing here may slow the app down: the window asks every few seconds, in
a thread, and every call has a short timeout.
"""

import os
import shutil
import subprocess
import sys
from typing import Dict, List, Optional, Tuple

# GPU memory a Whisper model needs at least (MB): what int8_float16 - the
# GPU fallback of core/transcribe.py - uses, with a little room. (float16 is
# tried first and falls back by itself; a 4 GB card runs large-v3 that way.)
WHISPER_VRAM = {"tiny": 300, "base": 400, "small": 800, "medium": 1600, "large-v3": 2600}
ORDER = ["tiny", "base", "small", "medium", "large-v3"]
LOW_VRAM_CHOICES = [("smaller", "Use a smaller Whisper model on the GPU (faster)"),
                    ("cpu", "Use the same model on the CPU (slower, same quality)")]

_SMI_QUERY = "utilization.gpu,memory.used,memory.total,temperature.gpu,name"


def _smi_path() -> str:
    p = shutil.which("nvidia-smi")
    if p:
        return p
    if sys.platform == "win32":
        for c in (r"C:\Windows\System32\nvidia-smi.exe",
                  r"C:\Program Files\NVIDIA Corporation\NVSMI\nvidia-smi.exe"):
            if os.path.isfile(c):
                return c
    return ""


def parse_smi(text: str) -> List[Dict]:
    out = []
    for line in (text or "").strip().splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) < 5:
            continue
        try:
            util, used, total, temp = (float(parts[i]) for i in range(4))
        except ValueError:
            continue
        out.append({"util": util, "used_mb": used, "total_mb": total, "temp": temp,
                    "free_mb": max(0.0, total - used), "name": ",".join(parts[4:])})
    return out


def gpu_stats(timeout: float = 3.0) -> List[Dict]:
    """[{util %, used_mb, total_mb, free_mb, temp °C, name}] - [] without NVIDIA."""
    smi = _smi_path()
    if not smi:
        return []
    try:
        from .media import no_window

        r = subprocess.run([smi, f"--query-gpu={_SMI_QUERY}", "--format=csv,noheader,nounits"],
                           stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                           stderr=subprocess.DEVNULL, timeout=timeout, text=True,
                           creationflags=no_window())
    except (OSError, subprocess.SubprocessError):
        return []
    return parse_smi(r.stdout) if r.returncode == 0 else []


def ram_stats() -> Tuple[float, float]:
    """(used_mb, total_mb) of the PC's memory, (0, 0) when unknown."""
    try:
        import psutil

        vm = psutil.virtual_memory()
        return (vm.total - vm.available) / 2 ** 20, vm.total / 2 ** 20
    except Exception:
        pass
    if sys.platform == "win32":
        try:
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong),
                            ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong),
                            ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return (m.ullTotalPhys - m.ullAvailPhys) / 2 ** 20, m.ullTotalPhys / 2 ** 20
        except Exception:
            return 0.0, 0.0
    try:
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":", 1)
                info[k] = float(v.split()[0]) / 1024
        return info["MemTotal"] - info.get("MemAvailable", 0.0), info["MemTotal"]
    except (OSError, KeyError, ValueError):
        return 0.0, 0.0


def gb(mb: float) -> str:
    return f"{mb / 1024:.1f}"


def summary(gpus: List[Dict], ram: Tuple[float, float]) -> str:
    """'GPU 34% · VRAM 3.2/8.0 GB · 52°C · RAM 9.1/16.0 GB'."""
    parts = []
    if gpus:
        g = gpus[0]
        parts.append(f"GPU {g['util']:.0f}%")
        parts.append(f"VRAM {gb(g['used_mb'])}/{gb(g['total_mb'])} GB")
        if g["temp"] > 0:
            parts.append(f"{g['temp']:.0f}°C")
    else:
        parts.append("GPU –")
    if ram[1] > 0:
        parts.append(f"RAM {gb(ram[0])}/{gb(ram[1])} GB")
    return " · ".join(parts)


def level(gpus: List[Dict], ram: Tuple[float, float]) -> str:
    """'ok' / 'busy' (VRAM or RAM above 85 %) / 'full' (RAM above 95 %).
    A GPU memory that is almost full is at most 'busy' (orange): Whisper
    large-v3 takes nearly all of a 4 GB card and keeps it while it is loaded -
    that works; it only means there is no room for more at once."""
    vram = 0.0
    if gpus and gpus[0]["total_mb"] > 0:
        vram = gpus[0]["used_mb"] / gpus[0]["total_mb"]
    mem = ram[0] / ram[1] if ram[1] > 0 else 0.0
    if mem > 0.95:
        return "full"
    return "busy" if max(vram, mem) > 0.85 else "ok"


def whisper_plan(size: str, free_mb: Optional[float], mode: str = "smaller") -> Tuple[str, str, str]:
    """(model, device "cuda"/"cpu", why) for a Whisper `size` when `free_mb`
    of GPU memory is free (None = unknown: try as asked)."""
    need = WHISPER_VRAM.get(size, 0)
    if free_mb is None or not need or free_mb >= need:
        return size, "cuda", ""
    short = f"only {free_mb / 1024:.1f} GB GPU memory free ({size} needs " \
            f"{need / 1024:.1f} GB)"
    if mode == "cpu":
        return size, "cpu", f"{short} - {size} runs on the CPU (slower)"
    i = ORDER.index(size) if size in ORDER else len(ORDER)
    for smaller in reversed(ORDER[:i]):
        if WHISPER_VRAM[smaller] <= free_mb:
            return smaller, "cuda", f"{short} - {smaller} is used on the GPU instead"
    return size, "cpu", f"{short} - {size} runs on the CPU (slower)"


def free_vram_mb() -> Optional[float]:
    g = gpu_stats()
    return g[0]["free_mb"] if g else None
