"""
branding.py - The look of the exported video: crop / zoom, output ratio
(with blurred or black fill, or zoomed to fill), covering the original
burned-in subtitles, logo, brand text, and the .ass subtitle file libass
burns in.

Coordinates
  * cover_rect is stored as fractions (x, y, w, h) of the SOURCE frame.
  * The VISIBLE part of the source is the frame minus the crop edges,
    zoomed into its centre (visible_rect(), fractions of the source).
  * The output canvas is W x H; the visible picture is fitted inside it at
    content_rect() (the rest is the blurred / black fill). With
    ratio_fill "crop" it is scaled to cover the whole canvas instead.
  * The .ass file uses PlayResY = 288 (the subtitle sizes in subfit.py are
    calibrated for it) and PlayResX = 288 * W / H, so positions map linearly.
"""

import os
from typing import List, Optional, Tuple

from .effects import picture_filters
from .project import Project, SubtitleClip
from .subfit import SCRIPT_HEIGHT, font_size, text_width, wrap_text

FILLS = {
    "blur": "Blurred video",
    "black": "Black",
    "crop": "Zoom & crop to fill (no bars)",
    "stretch": "Stretch to fill",
}
MAX_CROP = 0.45             # per edge
MAX_ZOOM = 3.0

RATIOS = {
    "original": None,
    "9:16": (9, 16),
    "16:9": (16, 9),
    "1:1": (1, 1),
    "4:5": (4, 5),
    "3:4": (3, 4),
    "4:3": (4, 3),
    "21:9": (21, 9),
}
RATIO_LABELS = {
    "original": "Original",
    "9:16": "9:16  TikTok / Reels / Shorts",
    "16:9": "16:9  YouTube",
    "1:1": "1:1  Square",
    "4:5": "4:5  Facebook / Instagram",
    "3:4": "3:4  Portrait",
    "4:3": "4:3  Classic TV",
    "21:9": "21:9  Cinema",
}


def ratio_size(key: str, short: int = 1080) -> Tuple[int, int]:
    """(width, height) of a ratio with the short side `short` (even numbers):
    9:16 -> 1080x1920, 21:9 -> 2520x1080. (0, 0) for 'original'."""
    r = RATIOS.get(key)
    if not r:
        return 0, 0
    a, b = r
    if a >= b:
        return _even(short * a / b), _even(short)
    return _even(short), _even(short * b / a)

# Project settings > Resolution (Movavi list + the vertical sizes for phones)
RESOLUTION_PRESETS = [
    (320, 240), (640, 480), (1280, 720), (1280, 960), (1920, 1080), (1920, 1440),
    (3840, 2160), (4096, 2160),
    (720, 1280), (1080, 1920), (1080, 1080), (1080, 1350),
]


def ratio_key(w: int, h: int) -> str:
    """'16:9' for 1920x1080, 'custom' when it is not one of RATIOS."""
    for key, r in RATIOS.items():
        if r and h and abs(w / h - r[0] / r[1]) < 0.01:
            return key
    return "custom"


def ratio_text(w: int, h: int) -> str:
    """'16:9', '256:135' ... as Movavi writes it."""
    import math

    if not w or not h:
        return ""
    g = math.gcd(int(w), int(h))
    return f"{int(w) // g}:{int(h) // g}"
CORNERS = ["top-left", "top-center", "top-right", "center", "bottom-left", "bottom-center",
           "bottom-right", "custom"]
CORNER_MARGIN = 0.03        # fraction of the canvas short side

# Moving logo / brand text: it drifts across the picture and bounces off the
# edges (makes re-uploads harder to crop). Seconds to cross the frame once.
MOTIONS = {"none": 0.0, "slow": 14.0, "medium": 7.0, "fast": 3.5}
MOTION_LABELS = {"none": "Fixed", "slow": "Moving – slow", "medium": "Moving – medium",
                 "fast": "Moving – fast"}
MOTION_Y = 0.73             # the vertical bounce is a bit faster so it wanders

Rect = Tuple[float, float, float, float]


def _even(v: float) -> int:
    return max(2, int(round(v / 2.0)) * 2)


def visible_rect(project: Project) -> Rect:
    """The part of the source frame that is shown (fractions x, y, w, h):
    the frame minus the crop edges, then zoomed into its centre."""
    def clamp(v):
        return max(0.0, min(MAX_CROP, float(v or 0.0)))
    l, t = clamp(project.crop_left), clamp(project.crop_top)
    r, b = clamp(project.crop_right), clamp(project.crop_bottom)
    w, h = max(0.1, 1.0 - l - r), max(0.1, 1.0 - t - b)
    z = max(1.0, min(MAX_ZOOM, float(project.zoom or 1.0)))
    zw, zh = w / z, h / z
    # Position: where the zoomed window sits (-1 .. 1, 0 = the centre)
    px = max(-1.0, min(1.0, float(getattr(project, "pan_x", 0.0) or 0.0)))
    py = max(-1.0, min(1.0, float(getattr(project, "pan_y", 0.0) or 0.0)))
    return l + (w - zw) / 2 * (1 + px), t + (h - zh) / 2 * (1 + py), zw, zh


def flip_filters(project: Project) -> List[str]:
    out = []
    if getattr(project, "flip_h", False):
        out.append("hflip")
    if getattr(project, "flip_v", False):
        out.append("vflip")
    return out


def is_cropped(project: Project) -> bool:
    _x, _y, w, h = visible_rect(project)
    return w < 0.999 or h < 0.999


def visible_px(project: Project) -> Tuple[int, int, int, int]:
    """visible_rect in source pixels (even numbers, inside the frame)."""
    sw, sh = max(2, project.width), max(2, project.height)
    fx, fy, fw, fh = visible_rect(project)
    w = min(_even(fw * sw), sw // 2 * 2)
    h = min(_even(fh * sh), sh // 2 * 2)
    x = max(0, min(sw - w, int(round(fx * sw)) // 2 * 2))
    y = max(0, min(sh - h, int(round(fy * sh)) // 2 * 2))
    return x, y, w, h


def visible_size(project: Project) -> Tuple[float, float]:
    """Size of the visible picture in source pixels."""
    sw, sh = max(1, project.width), max(1, project.height)
    _x, _y, fw, fh = visible_rect(project)
    return sw * fw, sh * fh


def output_size(project: Project, short_side: int = 0) -> Tuple[int, int]:
    """Size of the exported canvas. short_side 0 = keep the source resolution
    (or the exact size chosen in Project settings)."""
    ow, oh = int(getattr(project, "out_width", 0) or 0), int(getattr(project, "out_height", 0) or 0)
    if ow > 0 and oh > 0 and project.out_ratio != "original":
        if short_side <= 0:
            return _even(ow), _even(oh)
        if ow >= oh:
            return _even(short_side * ow / oh), _even(short_side)
        return _even(short_side), _even(short_side * oh / ow)
    sw, sh = visible_size(project)
    ratio = RATIOS.get(project.out_ratio)
    aspect = sw / sh if ratio is None else ratio[0] / ratio[1]
    if short_side <= 0:
        if ratio is None:
            return _even(sw), _even(sh)
        short_side = min(sw, sh)
    if aspect >= 1:
        return _even(short_side * aspect), _even(short_side)
    return _even(short_side), _even(short_side / aspect)


def content_rect(project: Project, W: float, H: float) -> Rect:
    """Where the visible picture sits inside a W x H canvas (centred; fitted,
    or covering the whole canvas with ratio_fill "crop")."""
    sw, sh = visible_size(project)
    if project.ratio_fill == "stretch":
        return 0.0, 0.0, float(W), float(H)
    if project.ratio_fill == "crop":
        s = max(W / sw, H / sh)
    else:
        s = min(W / sw, H / sh)
    w, h = sw * s, sh * s
    return (W - w) / 2, (H - h) / 2, w, h


def source_on_canvas(project: Project, W: float, H: float) -> Rect:
    """Where the WHOLE source frame sits on the canvas (the parts outside the
    visible rect / canvas are cut off). Used to map source fractions."""
    cx, cy, cw, ch = content_rect(project, W, H)
    fx, fy, fw, fh = visible_rect(project)
    sw, sh = cw / fw, ch / fh
    return cx - fx * sw, cy - fy * sh, sw, sh


def cover_px(project: Project) -> Optional[Tuple[int, int, int, int]]:
    """cover_rect in source pixels (even numbers, inside the frame)."""
    if not project.cover_enabled or project.width <= 0 or project.height <= 0:
        return None
    fx, fy, fw, fh = project.cover_rect
    x = max(0, min(project.width - 4, int(fx * project.width) // 2 * 2))
    y = max(0, min(project.height - 4, int(fy * project.height) // 2 * 2))
    w = max(4, min(project.width - x, _even(fw * project.width)))
    h = max(4, min(project.height - y, _even(fh * project.height)))
    return x, y, w, h


def cover_on_canvas(project: Project, W: float, H: float) -> Optional[Rect]:
    """cover_rect mapped onto a W x H canvas (only the part that is still
    visible; None when it was cropped away completely)."""
    if not project.cover_enabled:
        return None
    sx, sy, sw, sh = source_on_canvas(project, W, H)
    cx, cy, cw, ch = content_rect(project, W, H)
    fx, fy, fw, fh = project.cover_rect
    x0 = max(0.0, cx, sx + fx * sw)
    y0 = max(0.0, cy, sy + fy * sh)
    x1 = min(float(W), cx + cw, sx + (fx + fw) * sw)
    y1 = min(float(H), cy + ch, sy + (fy + fh) * sh)
    if x1 - x0 < 1 or y1 - y0 < 1:
        return None
    return x0, y0, x1 - x0, y1 - y0


def place_fraction(corner: str, pos=None) -> Tuple[float, float]:
    """Where an item sits as fractions (0..1) of the free room inside the
    margins: 0 = left / top edge, 1 = right / bottom edge. A "custom"
    corner uses `pos` (set by dragging the item in the preview)."""
    if corner == "custom" and pos and len(pos) == 2:
        # (a little below 0 / above 1: dragged into the edge margin, right up
        # to the edge of the picture - see pos_from_xy)
        return max(-0.5, min(1.5, float(pos[0]))), max(-0.5, min(1.5, float(pos[1])))
    if corner == "center":
        return 0.5, 0.5
    if corner not in CORNERS or corner == "custom":
        corner = "top-left"
    fx = {"left": 0.0, "center": 0.5, "right": 1.0}[corner.split("-")[1]]
    return fx, 0.0 if corner.startswith("top") else 1.0


def _bounce(u: float) -> float:
    """Triangle wave 0 -> 1 -> 0 with period 2 (equals u for u in 0..1)."""
    return 1.0 - abs(u % 2.0 - 1.0)


def motion_fraction(fx: float, fy: float, motion: str, t: float) -> Tuple[float, float]:
    """Position fractions at time t: starts at (fx, fy) and bounces around."""
    T = MOTIONS.get(motion or "none", 0.0)
    if T <= 0:
        return fx, fy
    return _bounce(fx + t / T), _bounce(fy + t / (T * MOTION_Y))


def item_xy(corner: str, pos, motion: str, t: float, W: float, H: float,
            w: float, h: float) -> Tuple[float, float]:
    """Top-left position of a w x h item on a W x H canvas at time t."""
    m = CORNER_MARGIN * min(W, H)
    fx, fy = motion_fraction(*place_fraction(corner, pos), motion, t)
    return m + fx * max(0.0, W - w - 2 * m), m + fy * max(0.0, H - h - 2 * m)


def pos_from_xy(x: float, y: float, W: float, H: float, w: float, h: float) -> List[float]:
    """Inverse of item_xy: fractions for an item dragged to top-left (x, y)."""
    m = CORNER_MARGIN * min(W, H)
    fw, fh = W - w - 2 * m, H - h - 2 * m
    fx = (x - m) / fw if fw > 1 else 0.5
    fy = (y - m) / fh if fh > 1 else 0.5
    # 2.4: an item may be dragged into the edge margin (right up to the edge
    # of the picture) and stays exactly there - it used to jump back inside
    # the margin when the video played / was exported
    lx, ly = (m / fw if fw > 1 else 0.0), (m / fh if fh > 1 else 0.0)
    return [round(max(-lx, min(1.0 + lx, fx)), 4), round(max(-ly, min(1.0 + ly, fy)), 4)]


def corner_xy(corner: str, W: float, H: float, w: float, h: float) -> Tuple[float, float]:
    """Top-left position of a w x h item placed in `corner` of a W x H canvas."""
    return item_xy(corner, None, "none", 0.0, W, H, w, h)


def subtitle_size(project: Project, W: int, H: int) -> float:
    return font_size(W, H, project.subtitle_scale)


def brand_size(project: Project, W: int, H: int) -> float:
    return round(font_size(W, H) * 0.75 * project.brand_size, 1)


# --------------------------------------------------------------------------- #
# .ass subtitle file (subtitles + brand text)
# --------------------------------------------------------------------------- #
def _ass_time(t: float) -> str:
    cs = int(round(max(0.0, t) * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def _ass_color(hex_rgb: str, alpha: float = 1.0) -> str:
    h = (hex_rgb or "#FFFFFF").lstrip("#")
    if len(h) != 6:
        h = "FFFFFF"
    a = int(round((1.0 - max(0.0, min(1.0, alpha))) * 255))
    return f"&H{a:02X}{h[4:6]}{h[2:4]}{h[0:2]}".upper()


def _ass_text(text: str) -> str:
    text = text.replace("\\", "/").replace("{", "(").replace("}", ")")
    return "\\N".join(line.strip() for line in text.split("\n"))


# Style tab > Subtitles > Look
SUB_PRESETS = {
    "classic": ("Classic – white, thin black outline",
                dict(sub_color="#FFFFFF", sub_outline=2.0, sub_outline_color="#000000",
                     sub_shadow=0.0, sub_box=False, sub_bold=False)),
    "bold": ("Bold – white, thick outline",
             dict(sub_color="#FFFFFF", sub_outline=3.0, sub_outline_color="#000000",
                  sub_shadow=0.0, sub_box=False, sub_bold=True)),
    "yellow": ("Yellow – movie style",
               dict(sub_color="#FFE14D", sub_outline=2.0, sub_outline_color="#000000",
                    sub_shadow=0.0, sub_box=False, sub_bold=False)),
    "shadow": ("Soft shadow – no outline",
               dict(sub_color="#FFFFFF", sub_outline=0.6, sub_outline_color="#000000",
                    sub_shadow=1.5, sub_box=False, sub_bold=False)),
    "box": ("Box – white on a dark box",
            dict(sub_color="#FFFFFF", sub_box=True, sub_box_color="#000000",
                 sub_box_opacity=0.6, sub_bold=False, sub_shadow=0.0)),
}


def sub_margin_v(project: Project) -> int:
    pct = float(getattr(project, "sub_bottom", 9.7) or 0.0)
    return int(round(max(0.0, min(95.0, pct)) / 100.0 * SCRIPT_HEIGHT))


def sub_x(project: Project) -> float:
    """Centre of the subtitles, % of the width (50 = middle)."""
    return max(3.0, min(97.0, float(getattr(project, "sub_x", 50.0) or 50.0)))


def sub_style_line(project: Project, font: str, size: float) -> str:
    """The ASS 'Sub' style from the Style tab settings."""
    p = project
    font = (font or getattr(p, "sub_font", "") or "Arial").replace(",", " ")
    primary = _ass_color(getattr(p, "sub_color", "#FFFFFF"))
    bold = -1 if getattr(p, "sub_bold", False) else 0
    if getattr(p, "sub_box", False):
        # BorderStyle 3: an opaque box drawn in the OutlineColour, padded by Outline
        box = _ass_color(p.sub_box_color, float(p.sub_box_opacity))
        return (f"Style: Sub,{font},{size},{primary},&H00FFFFFF,{box},&H00000000,"
                f"{bold},0,0,0,100,100,0,0,3,3,0,2,10,10,{sub_margin_v(p)},1")
    outline = max(0.0, min(8.0, float(getattr(p, "sub_outline", 2.0))))
    shadow = max(0.0, min(6.0, float(getattr(p, "sub_shadow", 0.0))))
    oc = _ass_color(getattr(p, "sub_outline_color", "#000000"))
    return (f"Style: Sub,{font},{size},{primary},&H00FFFFFF,{oc},&H80000000,"
            f"{bold},0,0,0,100,100,0,0,1,{outline:g},{shadow:g},2,10,10,{sub_margin_v(p)},1")


def write_ass(project: Project, subs: List[SubtitleClip], path: str, W: int, H: int,
              font: str = "Noto Sans Khmer", limit: Optional[float] = None,
              burn_subs: bool = True, watermark: str = "", brand: bool = True) -> str:
    """Write the subtitles (wrapped to fit) and the brand text as an .ass file."""
    px = round(SCRIPT_HEIGHT * W / H)
    size = subtitle_size(project, W, H)
    bsize = brand_size(project, W, H)
    lines = [
        "[Script Info]",
        "ScriptType: v4.00+",
        f"PlayResX: {px}",
        f"PlayResY: {SCRIPT_HEIGHT}",
        "WrapStyle: 2",
        "ScaledBorderAndShadow: yes",
        "",
        "[V4+ Styles]",
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
        "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
        "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
        sub_style_line(project, font, size),
        f"Style: Brand,{font},{bsize},{_ass_color(project.brand_color)},&H00FFFFFF,"
        f"&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,1.5,0,7,0,0,0,1",
        f"Style: Mark,{font},{round(SCRIPT_HEIGHT * 0.09)},&H60FFFFFF,&H00FFFFFF,"
        f"&H90000000,&H00000000,1,0,0,0,100,100,0,0,1,1,0,5,0,0,0,1",
        "",
        "[Events]",
        "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
    ]
    pos = ""
    cover = cover_on_canvas(project, W, H)
    if project.sub_position == "cover" and cover is not None:
        x, y, w, h = cover
        pos = f"{{\\an5\\pos({(x + w / 2) * px / W:.1f},{(y + h / 2) * SCRIPT_HEIGHT / H:.1f})}}"
    elif abs(sub_x(project) - 50.0) > 0.05:
        # moved left / right in the preview: bottom-centre anchored at that point
        pos = (f"{{\\an2\\pos({sub_x(project) / 100 * px:.1f},"
               f"{SCRIPT_HEIGHT - sub_margin_v(project)})}}")
    if burn_subs:
        for c in sorted(subs, key=lambda s: s.start):
            start, end = c.start, c.end
            if limit is not None:
                if start >= limit:
                    continue
                end = min(end, limit)
            if end - start < 0.05 or not c.text.strip():
                continue
            text = wrap_text(c.text.strip(), W, H, size)
            lines.append(f"Dialogue: 0,{_ass_time(start)},{_ass_time(end)},Sub,,0,0,0,,"
                         f"{pos}{_ass_text(text)}")
    if project.brand_text.strip() and brand:
        end = limit if limit is not None else max(1.0, project.sequence_duration())
        lines += _brand_events(project, px, bsize, end)
    if watermark:           # unlicensed copy: semi-transparent text in the middle
        end = limit if limit is not None else 24 * 3600
        lines.append(f"Dialogue: 2,{_ass_time(0)},{_ass_time(end)},Mark,,0,0,0,,"
                     f"{{\\an5\\pos({px / 2:.1f},{SCRIPT_HEIGHT * 0.42:.1f})}}"
                     f"{_ass_text(watermark)}")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    return path


def _brand_events(project: Project, px: float, size: float, end: float) -> List[str]:
    """Dialogue lines for the brand text: fixed in a corner, at a dragged
    position, or bouncing around (one ASS move tag per straight stretch)."""
    text = _ass_text(project.brand_text)
    corner, motion = project.brand_corner, project.brand_motion
    if corner != "custom" and MOTIONS.get(motion, 0.0) <= 0:
        an = {"top-left": 7, "top-center": 8, "top-right": 9, "center": 5,
              "bottom-left": 1, "bottom-center": 2, "bottom-right": 3}.get(corner, 7)
        m = CORNER_MARGIN * min(px, SCRIPT_HEIGHT)
        bx = {7: m, 1: m, 8: px / 2, 5: px / 2, 2: px / 2, 9: px - m, 3: px - m}[an]
        by = m if an in (7, 8, 9) else (SCRIPT_HEIGHT / 2 if an == 5 else SCRIPT_HEIGHT - m)
        return [f"Dialogue: 1,{_ass_time(0)},{_ass_time(end)},Brand,,0,0,0,,"
                f"{{\\an{an}\\pos({bx:.1f},{by:.1f})}}{text}"]

    # free placement: anchor the centre; the text size is estimated (libass
    # metrics of Noto Sans Khmer, bold) and the centre keeps the error small
    tlines = project.brand_text.strip().split("\n")
    w = min(px * 0.94, max(text_width(l) for l in tlines) * size * 1.08)
    h = len(tlines) * size * 1.25

    def centre(t):
        x, y = item_xy(corner, project.brand_pos, motion, t, px, SCRIPT_HEIGHT, w, h)
        return x + w / 2, y + h / 2

    def event(t0, t1, move):
        (x0, y0), (x1, y1) = centre(t0), centre(t1)
        tag = (f"\\move({x0:.1f},{y0:.1f},{x1:.1f},{y1:.1f})" if move
               else f"\\pos({x0:.1f},{y0:.1f})")
        return (f"Dialogue: 1,{_ass_time(t0)},{_ass_time(t1)},Brand,,0,0,0,,"
                f"{{\\an5{tag}}}{text}")

    T = MOTIONS.get(motion, 0.0)
    if T <= 0:
        return [event(0.0, end, False)]
    # the path is straight between bounces: split at every edge hit
    fx, fy = place_fraction(corner, project.brand_pos)
    times = set()
    for f0, period in ((fx, T), (fy, T * MOTION_Y)):
        k = 1
        while (k - f0) * period < end:
            times.add((k - f0) * period)
            k += 1
    cuts = [0.0] + sorted(x for x in times if 0.0 < x < end) + [end]
    return [event(a, b, True) for a, b in zip(cuts, cuts[1:]) if b - a >= 0.01]


# --------------------------------------------------------------------------- #
# ffmpeg video filter chain
# --------------------------------------------------------------------------- #
def video_chain(project: Project, W: int, H: int, src: str, logo: Optional[str],
                ass_name: Optional[str], subs: Optional[str] = None,
                brand: Optional[str] = None,
                extras: Optional[List[str]] = None) -> Tuple[List[str], str]:
    """Filter graph parts taking video label `src` to the final picture.

    logo = label of the logo image input (e.g. "2:v") or None.
    Returns (parts, output label)."""
    parts: List[str] = []
    cur = src

    look = picture_filters(project)         # Tools: rotate + color adjustments
    if look:
        parts.append(f"[{cur}]{','.join(look)}[look]")
        cur = "look"

    cov = cover_px(project)
    if cov is not None:
        x, y, w, h = cov
        if project.cover_mode == "box":
            parts.append(f"[{cur}]drawbox=x={x}:y={y}:w={w}:h={h}:color=black:t=fill[cov]")
        else:
            sigma = max(8.0, h * 0.3)
            parts.append(f"[{cur}]split[cov0][cov1]")
            parts.append(f"[cov1]crop={w}:{h}:{x}:{y},gblur=sigma={sigma:.1f}[covb]")
            parts.append(f"[cov0][covb]overlay={x}:{y}[cov]")
        cur = "cov"

    if is_cropped(project):
        x, y, w, h = visible_px(project)
        parts.append(f"[{cur}]crop={w}:{h}:{x}:{y}[vis]")
        cur = "vis"
    flips = flip_filters(project)           # Transform › Flip (after crop: its edges stay)
    if flips:
        parts.append(f"[{cur}]{','.join(flips)}[flip]")
        cur = "flip"

    cx, cy, cw, ch = content_rect(project, W, H)
    if cw > W + 1 or ch > H + 1:            # zoom & crop to fill the canvas
        cw, ch = max(_even(cw), W), max(_even(ch), H)
        ox, oy = (cw - W) // 2, (ch - H) // 2
        parts.append(f"[{cur}]scale={cw}:{ch},setsar=1,crop={W}:{H}:{ox}:{oy}[canv]")
        return _finish(project, parts, "canv", W, H, logo, ass_name, subs, brand, extras)
    cx, cy, cw, ch = int(round(cx)), int(round(cy)), _even(cw), _even(ch)
    cw, ch = min(cw, W), min(ch, H)
    if cw >= W - 1 and ch >= H - 1:
        parts.append(f"[{cur}]scale={W}:{H},setsar=1[canv]")
    elif project.ratio_fill == "black":
        parts.append(f"[{cur}]scale={cw}:{ch},setsar=1,pad={W}:{H}:{cx}:{cy}:black[canv]")
    else:
        parts.append(f"[{cur}]split[bg0][fg0]")
        parts.append(f"[bg0]scale={_even(W / 8)}:{_even(H / 8)}:force_original_aspect_ratio=increase,"
                     f"crop={_even(W / 8)}:{_even(H / 8)},gblur=sigma=6,"
                     f"scale={W}:{H},eq=brightness=-0.08,setsar=1[bg]")
        parts.append(f"[fg0]scale={cw}:{ch},setsar=1[fg]")
        parts.append(f"[bg][fg]overlay={cx}:{cy}[canv]")
    return _finish(project, parts, "canv", W, H, logo, ass_name, subs, brand, extras)


def _finish(project: Project, parts: List[str], cur: str, W: int, H: int,
            logo: Optional[str], ass_name: Optional[str],
            subs: Optional[str] = None, brand: Optional[str] = None,
            extras: Optional[List[str]] = None) -> Tuple[List[str], str]:
    """Logo, burned subtitles, pixel format. subs = label of the subtitle
    pictures drawn by Qt (core/subrender.py) - laid over like the logo.
    extras = input labels of the extra logos (extra_logos(project), in order)."""
    if logo:
        lw = _even(W * project.logo_size)
        lx, ly = logo_xy_expr(project, W, H)
        parts.append(f"[{logo}]scale={lw}:-2,format=rgba,"
                     f"colorchannelmixer=aa={project.logo_opacity:.2f}[logo]")
        parts.append(f"[{cur}][logo]overlay=x='{lx}':y='{ly}':shortest=1[lg]")
        cur = "lg"

    for k, (label, d) in enumerate(zip(extras or [], extra_logos(project))):
        lw = _even(W * float(d["size"]))
        lx, ly = xy_expr(d["corner"], d["pos"], d["motion"], W, H)
        parts.append(f"[{label}]scale={lw}:-2,format=rgba,"
                     f"colorchannelmixer=aa={float(d['opacity']):.2f}[xl{k}]")
        parts.append(f"[{cur}][xl{k}]overlay=x='{lx}':y='{ly}':shortest=1[xlo{k}]")
        cur = f"xlo{k}"

    if brand:               # the brand text drawn by Qt (Khmer shaping), placed like the logo
        bx, by = xy_expr(project.brand_corner, project.brand_pos, project.brand_motion, W, H)
        parts.append(f"[{brand}]format=rgba[brandpic]")
        parts.append(f"[{cur}][brandpic]overlay=x='{bx}':y='{by}':shortest=1[br]")
        cur = "br"
    if subs:
        parts.append(f"[{subs}]format=rgba[subpic]")
        parts.append(f"[{cur}][subpic]overlay=0:0:eof_action=pass[subov]")
        cur = "subov"
    if ass_name:
        parts.append(f"[{cur}]subtitles={ass_name}:fontsdir=fonts[subs]")
        cur = "subs"
    parts.append(f"[{cur}]format=yuv420p[vout]")
    return parts, "vout"


def logo_xy_expr(project: Project, W: int, H: int) -> Tuple[str, str]:
    """ffmpeg overlay x / y expressions for the logo (same path as item_xy)."""
    return xy_expr(project.logo_corner, project.logo_pos, project.logo_motion, W, H)


def xy_expr(corner: str, pos, motion: str, W: int, H: int) -> Tuple[str, str]:
    """ffmpeg overlay x / y expressions for an item placed like item_xy."""
    m = int(CORNER_MARGIN * min(W, H))
    fx, fy = place_fraction(corner, pos)
    T = MOTIONS.get(motion or "none", 0.0)

    def axis(f, period, main, over):
        room = f"({main}-{over}-{2 * m})"
        if period <= 0:
            return f"{m}+{room}*{f:.4f}"
        return f"{m}+{room}*(1-abs(mod({f:.4f}+t/{period:.3f},2)-1))"

    return (axis(fx, T, "main_w", "overlay_w"),
            axis(fy, T * MOTION_Y, "main_h", "overlay_h"))


def has_logo(project: Project) -> bool:
    return bool(project.logo_path) and os.path.isfile(project.logo_path)


EXTRA_LOGO = {"path": "", "corner": "center", "pos": [], "motion": "none", "size": 0.25,
              "opacity": 1.0}


def new_extra_logo(path: str = "") -> dict:
    d = dict(EXTRA_LOGO)
    d["path"], d["pos"] = path, []
    return d


def extra_logos(project: Project) -> List[dict]:
    """The extra logos (sponsor / customer) whose picture exists, with every
    setting filled in."""
    out = []
    for i, d in enumerate(getattr(project, "extra_logos", None) or []):
        if isinstance(d, dict) and d.get("path") and os.path.isfile(d["path"]):
            out.append({**EXTRA_LOGO, **d, "index": i})    # index in project.extra_logos
    return out


def set_extra_logo(project: Project, index: int, **kw) -> None:
    """Change one extra logo (dragged / resized in a preview)."""
    logos = list(getattr(project, "extra_logos", None) or [])
    if 0 <= index < len(logos):
        logos[index] = {**logos[index], **kw}
        project.extra_logos = logos
