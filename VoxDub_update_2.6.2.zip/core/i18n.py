"""
i18n.py - The language of the app: English (default) or ខ្មែរ (Khmer).

The program is written in English. tr(text) gives the Khmer text when Khmer
is chosen (setting "ui_language": "en" / "km"). The Khmer texts are in
core/i18n_km.py, one English text -> one Khmer text. A text made with
numbers / names inside (f"{n} days left") is matched by a template with {}:

    "{} days left": "នៅសល់ {} ថ្ងៃ"

Unknown text stays English (nothing breaks when a text is new). The window
side (ui/appearance.py) calls tr() for every label, button, menu, tab, tooltip
and message, so the screens do not need changes for a new text: only an
entry in i18n_km.py.
"""

import re
from functools import lru_cache
from typing import Dict, List, Optional, Tuple

from . import settings

LANGUAGES = {"en": "English", "km": "ខ្មែរ"}
SETTING = "ui_language"


def language() -> str:
    lang = settings.get(SETTING, "en") or "en"
    return lang if lang in LANGUAGES else "en"


def set_language(lang: str) -> None:
    settings.set(SETTING, lang if lang in LANGUAGES else "en")
    _table.cache_clear()


@lru_cache(maxsize=1)
def _table() -> Tuple[Dict[str, str], List[Tuple["re.Pattern", str, int]]]:
    try:
        from .i18n_km import KM
    except Exception:
        KM = {}
    exact, templates = {}, []
    for en, km in KM.items():
        if not en or not km:
            continue
        if "{}" in en:
            en, km = _norm(en.replace("&&", "&")), km.replace("&&", "&")
            parts = [re.escape(p) for p in en.split("{}")]
            pat = re.compile("^" + "(.+?)".join(parts) + "$", re.S)
            templates.append((pat, km, en.count("{}")))
        exact[_norm(en.replace("&&", "&"))] = km.replace("&&", "&")
    templates.sort(key=lambda t: -len(t[0].pattern))      # the most specific first
    return exact, templates


def _norm(s: str) -> str:
    return re.sub(r"[ \t]+", " ", s.strip())


def _fill(km: str, values) -> str:
    out = km
    for v in values:
        out = out.replace("{}", tr(v, True), 1)
    return out


def tr(text: str, force: bool = False) -> str:
    """The text in the chosen language (English: unchanged)."""
    if not text or not isinstance(text, str):
        return text
    if not force and language() != "km":
        return text
    if "&&" in text:                                   # Qt button text: && is one &
        return tr(text.replace("&&", "&"), force).replace("&", "&&")
    exact, templates = _table()
    lead = text[:len(text) - len(text.lstrip())]
    tail = text[len(text.rstrip()):]
    key = _norm(text)
    hit = exact.get(key)
    if hit is None:
        hit = _icon_split(key, exact)
    if hit is None:
        for pat, km, _n in templates:
            m = pat.match(key)
            if m:
                hit = _fill(km, m.groups())
                break
    if hit is None and "\n" in text:                   # several lines: one by one
        lines = text.split("\n")
        done = [tr(ln, True) for ln in lines]
        if done != lines:
            return "\n".join(done)
    return text if hit is None else lead + hit + tail


_ICON = re.compile(r"^([^\w\s<(\"“'\[]{1,6})\s+(.+)$", re.S)


def _icon_split(key: str, exact: Dict[str, str]) -> Optional[str]:
    """"🏠   Home" when only "Home" is in the table: the icon stays."""
    m = _ICON.match(key)
    if not m or not m.group(1).strip():
        return None
    rest = exact.get(_norm(m.group(2)))
    if rest is None:
        return None
    return m.group(1).strip() + "   " + rest if "   " in key else \
        m.group(1).strip() + " " + rest
