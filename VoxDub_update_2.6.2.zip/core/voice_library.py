"""
voice_library.py - Voice Library for VoxCPM2 voice cloning (2.4).

One list of ready voices to clone, shown as cards (name, category, man /
woman / child, picture, ▶ preview):

  * VoxDub's own library - voices added with "+ Add voice" (a 5-30 s clean
    recording). Kept in the settings folder:  voice_library/<id>/voice.wav
    + index.json. Every customer has this one.
  * SARIKA VOICE's library (the seller's own app, D:\\sarika_voice) - read
    directly from its data/voices.json, on the owner's PC only. Its files are
    never changed.

A voice is used as the default man / woman voice (Settings › AI engines ›
Voice clone) or for one character (👥 Characters › Clone from: library).
What is said in a recording ("said") makes the clone better; it is typed in,
or heard by Whisper once and kept (texts.json).
"""

import json
import os
import shutil
import time
import uuid
from dataclasses import asdict, dataclass, field
from typing import Callable, Dict, List, Optional

from . import settings

GENDERS = {"male": "♂ Man", "female": "♀ Woman", "child": "Child"}
CATEGORIES = ["Male Lead", "Female Lead", "Storytelling", "Character Voice", "Elder Voice",
              "Child", "News & Documentary", "Anime & Gaming", "Other"]
AUDIO_EXT = (".wav", ".mp3", ".m4a", ".flac", ".ogg", ".aac", ".mp4", ".mkv", ".webm")


@dataclass
class Voice:
    id: str
    name: str
    file: str                       # the recording to clone (any audio format)
    gender: str = "male"            # male / female / child
    category: str = "Other"
    text: str = ""                  # what is said in the recording
    avatar: str = ""                # picture (optional)
    source: str = "voxdub"          # voxdub / sarika
    seconds: float = 0.0
    tags: List[str] = field(default_factory=list)

    @property
    def editable(self) -> bool:
        return self.source == "voxdub"


# --------------------------------------------------------------------------- #
# storage
# --------------------------------------------------------------------------- #
def root() -> str:
    return os.path.join(settings.settings_dir(), "voice_library")


def _index_path() -> str:
    return os.path.join(root(), "index.json")


def _texts_path() -> str:
    return os.path.join(root(), "texts.json")


def _read(path: str, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, type(default)) else default
    except (OSError, ValueError):
        return default


def _write(path: str, data) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(path + ".tmp", path)


def _key(path: str) -> str:
    return os.path.normcase(os.path.abspath(path or ""))


def text_for(path: str) -> str:
    """What is said in this recording (typed in or heard once), "" = unknown."""
    if not path:
        return ""
    t = _read(_texts_path(), {}).get(_key(path), "")
    if t:
        return t
    for v in own_voices():
        if _key(v.file) == _key(path):
            return v.text
    return ""


def set_text(path: str, text: str) -> None:
    data = _read(_texts_path(), {})
    data[_key(path)] = (text or "").strip()
    _write(_texts_path(), data)
    own = _read(_index_path(), [])
    changed = False
    for d in own:
        if _key(d.get("file", "")) == _key(path):
            d["text"], changed = (text or "").strip(), True
    if changed:
        _write(_index_path(), own)


# --------------------------------------------------------------------------- #
# the voices
# --------------------------------------------------------------------------- #
def own_voices() -> List[Voice]:
    out = []
    for d in _read(_index_path(), []):
        if not isinstance(d, dict) or not d.get("file"):
            continue
        try:
            v = Voice(**{k: d[k] for k in d if k in Voice.__dataclass_fields__})
        except TypeError:
            continue
        if os.path.isfile(v.file):
            out.append(v)
    return out


def sarika_dir() -> str:
    return settings.get("sarika_voice_dir") or r"D:\sarika_voice"


def sarika_allowed() -> bool:
    """SARIKA VOICE belongs to the seller: its voices show on the owner's PC."""
    try:
        from . import admin

        return admin.is_owner()
    except Exception:
        return False


def sarika_voices(folder: Optional[str] = None) -> List[Voice]:
    """The SARIKA VOICE library (read only). Design voices have no recording
    of their own: their generated preview is cloned instead."""
    folder = folder or sarika_dir()
    data = _read(os.path.join(folder, "data", "voices.json"), [])
    texts = _read(_texts_path(), {})
    out = []
    for d in data:
        if not isinstance(d, dict):
            continue
        audio = ""
        for k in ("sampleFile", "previewFile"):
            p = d.get(k) or ""
            if p and not os.path.isfile(p):        # stored for another drive letter
                alt = os.path.join(folder, "data", "voices", str(d.get("id", "")),
                                   os.path.basename(p))
                p = alt if os.path.isfile(alt) else ""
            if p:
                audio = p
                break
        if not audio:
            continue
        gender = str(d.get("gender") or "male").lower()
        avatar = d.get("avatarFile") or ""
        out.append(Voice(
            id="sv:" + str(d.get("id", "")), name=str(d.get("name") or d.get("id")),
            file=audio, gender=gender if gender in GENDERS else "male",
            category=str(d.get("category") or "Other"),
            text=texts.get(_key(audio), ""),
            avatar=avatar if avatar and os.path.isfile(avatar) else "",
            source="sarika", seconds=float(d.get("durationSec") or 0),
            tags=[str(d.get("kind") or "")]))
    return out


def all_voices() -> List[Voice]:
    voices = own_voices()
    if sarika_allowed():
        voices += sarika_voices()
    return voices


def find(path_or_id: str) -> Optional[Voice]:
    for v in all_voices():
        if v.id == path_or_id or _key(v.file) == _key(path_or_id):
            return v
    return None


def add_voice(src: str, name: str, gender: str = "male", category: str = "Other",
              text: str = "", avatar: str = "") -> Voice:
    """Copy a recording into VoxDub's own library (as 16 kHz-ok WAV)."""
    if not os.path.isfile(src):
        raise FileNotFoundError(src)
    vid = "v_" + uuid.uuid4().hex[:10]
    folder = os.path.join(root(), vid)
    os.makedirs(folder, exist_ok=True)
    dest = os.path.join(folder, "voice.wav")
    if src.lower().endswith(".wav"):
        shutil.copyfile(src, dest)
    else:
        from .media import run_ffmpeg

        run_ffmpeg(["-i", os.path.abspath(src), "-vn", "-ac", "1", "-ar", "24000",
                    "-t", "30", dest])
    pic = ""
    if avatar and os.path.isfile(avatar):
        pic = os.path.join(folder, "avatar" + os.path.splitext(avatar)[1].lower())
        shutil.copyfile(avatar, pic)
    seconds = 0.0
    try:
        from .media import get_media_info

        seconds = round(get_media_info(dest).duration, 1)
    except Exception:
        pass
    v = Voice(id=vid, name=(name or os.path.splitext(os.path.basename(src))[0]).strip(),
              file=dest, gender=gender if gender in GENDERS else "male",
              category=category or "Other", text=(text or "").strip(), avatar=pic,
              seconds=seconds)
    own = _read(_index_path(), [])
    own.append(asdict(v))
    _write(_index_path(), own)
    return v


def update_voice(vid: str, **kw) -> None:
    own = _read(_index_path(), [])
    for d in own:
        if d.get("id") == vid:
            for k, val in kw.items():
                if k in ("name", "gender", "category", "text", "avatar"):
                    d[k] = val
    _write(_index_path(), own)


def delete_voice(vid: str) -> bool:
    own = _read(_index_path(), [])
    keep = [d for d in own if d.get("id") != vid]
    if len(keep) == len(own):
        return False
    _write(_index_path(), keep)
    shutil.rmtree(os.path.join(root(), vid), ignore_errors=True)
    return True


# --------------------------------------------------------------------------- #
# using a voice
# --------------------------------------------------------------------------- #
def use_as_default(v: Voice, slot: str) -> None:
    """slot: male / female / child / elder_male / elder_female (Settings ›
    AI engines › Voice clone)."""
    settings.set(f"voxcpm_ref_{slot}", v.file)
    settings.set(f"voxcpm_ref_{slot}_text", v.text or text_for(v.file))


class NotKhmer(ValueError):
    """What was heard is not Khmer (Whisper took the recording for Thai ...)."""


def hear_text(v: Voice, progress: Optional[Callable] = None) -> str:
    """Listen to the recording once (in KHMER - the voices are for Khmer
    dubbing) and keep the words. Gemini (API key set) hears Khmer much better
    than Whisper, so it goes first. Words that are not Khmer are not kept."""
    import tempfile

    from .media import run_ffmpeg
    from .transcribe import transcribe_audio
    from .voxcpm import is_khmer

    lang = settings.get("voice_text_lang", "km") or "km"
    wav = os.path.join(tempfile.gettempdir(), f"voxdub_said_{int(time.time() * 1000)}.wav")
    run_ffmpeg(["-i", os.path.abspath(v.file), "-vn", "-ac", "1", "-ar", "16000",
                "-t", "30", wav])
    text = ""
    try:
        engines = []
        try:
            from . import gemini

            if gemini.keys():
                engines.append("gemini")
        except Exception:
            pass
        engines.append("whisper")
        model = settings.get("whisper_model_said", "") or settings.get("whisper_model", "") \
            or "small"
        for engine in engines:
            try:
                segs, _lang = transcribe_audio(wav, model, lang, progress,
                                               **({"engine": engine}
                                                  if engine != "whisper" else {}))
            except Exception as e:
                if engine == engines[-1]:
                    raise
                print(f"[voice library] {engine} could not hear it: {e}")
                continue
            text = " ".join(s.text.strip() for s in segs if s.text.strip()).strip()
            if text and (lang != "km" or is_khmer(text)):
                break
    finally:
        try:
            os.remove(wav)
        except OSError:
            pass
    if text and lang == "km" and not is_khmer(text):
        raise NotKhmer(text)
    if text:
        set_text(v.file, text)
        v.text = text
    return text
