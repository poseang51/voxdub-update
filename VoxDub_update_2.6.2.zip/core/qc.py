"""
qc.py - Quality check of a dubbed video: the lines worth a look.

After a Batch of hundreds of episodes nobody can watch everything. This
lists, per episode, only the lines where something may be wrong:

  no_voice     the line has text but no AI voice on the timeline
  untranslated the line was never translated (the voice would read the original)
  fast         the voice had to be sped up more than the chosen Voice speed
  cut          the end of the voice was cut off (it did not fit before the next line)
  gender       Find characters was not sure if a character is a man or a woman
  overlap      a voice runs into the next line

Translation QA (2.3):
  garbled      the original line looks like nonsense (heard in a wrong language)
  chinese      Chinese characters left in the translation
  long         the translation is much longer than the time of the line
  short        the translation is a word or two for a long line
  few_lines    very few lines for the length of the video (Speech language?)

Sound (check_audio, on the exported video):
  clip / loud / quiet   peaks at 0 dB, too loud, too quiet (LUFS)
  level        much louder / quieter than the other episodes of the story

Nothing is changed - it is a list to check (and a CSV in the output folder).
"""

import csv
import os
import re
import subprocess
from typing import Dict, List, Optional

from .project import Project

KINDS = {
    "no_voice": "No AI voice",
    "untranslated": "Not translated",
    "fast": "Voice sped up a lot",
    "cut": "End of the voice cut off",
    "gender": "Man / woman not sure",
    "overlap": "Voice runs into the next line",
    "garbled": "Heard wrong – nonsense text (Speech language?)",
    "chinese": "Chinese left in the translation",
    "long": "Translation too long for the line",
    "short": "Translation very short",
    "few_lines": "Very few lines heard (Speech language?)",
    "clip": "Sound clips (peaks at 0 dB)",
    "loud": "Sound too loud",
    "quiet": "Sound too quiet",
    "level": "Loudness differs from the other episodes",
    "slowed": "Video slowed a lot for long lines",
    "check_nosub": "To check – no subtitle on the video shows these words",
    "check_unsure": "To check – Whisper is not sure of the words",
    "noise": "Taken out as noise (not voiced)",
}
SLOWED_MAX = 1.2            # the dubbed video this much longer than the original
_CJK = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff]")
LONG_CPS = 22.0             # characters per second a voice can still say (Khmer, Edge)
SHORT_LINE = 3.0            # s: a line this long translated as 1-2 characters
FEW_PER_MIN = 5.0           # lines per minute below this: suspicious for a drama
OVERLAP_SECONDS = 0.05
FAST_MARGIN = 0.05          # above the project's Voice speed
CUT_SECONDS = 0.25          # this much of the voice missing at the end


def check_project(project: Project) -> List[Dict]:
    """[{"time", "kind", "what", "text", "seg_id"}] in time order."""
    out: List[Dict] = []
    clips = {}
    for c in project.audio_clips:
        if c.seg_id:
            clips.setdefault(c.seg_id, c)
    limit = float(getattr(project, "max_speed", 1.1) or 1.1)
    src = getattr(project, "detected_lang", "") or getattr(project, "source_lang", "")
    same_lang = bool(src) and src != "auto" and src == getattr(project, "target_lang", "")
    # voices that run into the next one on the timeline (two voices at once)
    voiced = sorted((c for c in project.audio_clips if c.seg_id), key=lambda c: c.start)
    runs_into = {a.seg_id: b.start for a, b in zip(voiced, voiced[1:])
                 if a.end > b.start + OVERLAP_SECONDS}
    for s in sorted(project.segments, key=lambda s: s.start):
        text = s.voice_text()
        if not text:
            continue
        say = (s.translation or s.text).strip()

        c = clips.get(s.id)
        at = c.start if c is not None else s.start      # where it is on the timeline

        def add(kind, extra=""):
            out.append({"time": round(at, 2), "kind": kind,
                        "what": KINDS[kind] + (f" ({extra})" if extra else ""),
                        "text": say, "seg_id": s.id})

        if s.text.strip() and not s.translation.strip() and same_lang is False:
            add("untranslated")
        # ---- Smart Review: lines worth a look (🔍 Lines to check in the editor)
        why = getattr(s, "check", "")
        if why in ("nosub", "unsure", "nosub_unsure"):
            add("check_" + why.split("_")[0])
        # ---- translation QA
        heard = getattr(project, "detected_lang", "") or src
        if s.text.strip() and garbled(s.text, heard):
            add("garbled")
        tr = s.translation.strip()
        tgt = getattr(project, "target_lang", "")
        if tr and tgt not in ("zh", "ja", "ko", "zh-CN", "zh-TW") and _CJK.search(tr):
            add("chinese")
        dur = max(0.3, s.end - s.start)
        n = _letters(tr)
        # (a voiced line too long shows as "sped up" / "cut off" / the video
        # slowed - only a line without its voice yet is judged by its text)
        if tr and c is None and n >= 20 and n / dur > LONG_CPS:
            add("long", f"{n} letters in {dur:.1f} s")
        elif tr and dur >= SHORT_LINE and n <= 2 and len(s.text.strip()) >= 4:
            add("short")
        if c is None:
            add("no_voice")
            continue
        if c.speed > limit + FAST_MARGIN:
            add("fast", f"{c.speed:.2f} ×")
        missing = c.file_duration - c.src_out
        if missing > CUT_SECONDS:
            add("cut", f"{missing:.1f} s")
        if s.id in runs_into:
            add("overlap", f"{c.end - runs_into[s.id]:.1f} s")
    for n in getattr(project, "noise_lines", []) or []:
        at = project.source_to_timeline(float(n.get("start", 0.0)))
        out.append({"time": round(at if at is not None else float(n.get("start", 0.0)), 2),
                    "kind": "noise", "what": KINDS["noise"],
                    "text": str(n.get("text", "")), "seg_id": ""})
    # ---- the whole episode: the video slowed a lot for long Khmer lines
    if dur_src_ok(project):
        src_len = float(project.video_duration)
        out_len = project.output_duration()
        if out_len > src_len * SLOWED_MAX:
            out.append({"time": 0.0, "kind": "slowed",
                        "what": f"{KINDS['slowed']} – {int(src_len)} s → {int(out_len)} s "
                                f"(+{(out_len / src_len - 1) * 100:.0f} %)",
                        "text": "Voice style Natural slows the video where a Khmer line is "
                                "longer; Gemini translates shorter",
                        "seg_id": ""})
    # ---- the whole episode: very few lines heard
    dur = float(getattr(project, "video_duration", 0.0) or 0.0)
    lines = [s for s in project.segments if s.text.strip()]
    if dur >= 60 and len(lines) / (dur / 60.0) < FEW_PER_MIN:
        out.append({"time": 0.0, "kind": "few_lines",
                    "what": f"{KINDS['few_lines']} – {len(lines)} lines in "
                            f"{int(dur // 60)}:{int(dur % 60):02d}",
                    "text": "Speech: " + (getattr(project, "source_lang", "") or "auto")
                            + " · heard as: " + (getattr(project, "detected_lang", "") or "?"),
                    "seg_id": ""})
    try:
        from . import gender_ai

        sure = int(gender_ai.CONFIDENT * 100)
    except ImportError:                     # (no AI man / woman in this edition)
        sure = 70
    for lab, c in (getattr(project, "cast", {}) or {}).items():
        if c.get("auto", True) and str(c.get("gender_src", "")).startswith("ai") \
                and 0 < int(c.get("gender_conf") or 0) < sure:
            first = min((s for s in project.segments if s.speaker == lab),
                        key=lambda s: s.start, default=None)
            if first is not None:
                out.append({"time": round(first.start, 2), "kind": "gender",
                            "what": f"{KINDS['gender']} – character {lab}, "
                                    f"{c.get('gender_conf')}%",
                            "text": (first.translation or first.text).strip(),
                            "seg_id": first.id})
    return sorted(out, key=lambda r: r["time"])


_SCRIPTS = {"km": r"[\u1780-\u17ff]", "zh": r"[\u3400-\u9fff]", "ja": r"[\u3040-\u30ff\u4e00-\u9fff]",
            "ko": r"[\uac00-\ud7af]", "th": r"[\u0e00-\u0e7f]", "vi": r"[A-Za-zÀ-ỹ]",
            "en": r"[A-Za-z]", "lo": r"[\u0e80-\u0eff]", "ru": r"[\u0400-\u04ff]"}


def dur_src_ok(project) -> bool:
    try:
        return float(project.video_duration or 0) > 5 and bool(project.video_clips)
    except (TypeError, ValueError):
        return False


def _letters(text: str) -> int:
    """Letters a voice says - no spaces, zero-width spaces or vowel signs
    (Khmer: ក្រោម​ការ counts the consonants, not every code point)."""
    import unicodedata

    return sum(1 for ch in text if unicodedata.category(ch)[0] in "LN")


def _script(ch: str) -> str:
    o = ord(ch)
    for name, a, b in (("latin", 0x41, 0x24F), ("cyrillic", 0x400, 0x4FF), ("khmer", 0x1780, 0x17FF),
                       ("thai", 0xE00, 0xE7F), ("cjk", 0x3040, 0x9FFF), ("hangul", 0xAC00, 0xD7AF),
                       ("sinhala", 0xD80, 0xDFF), ("arabic", 0x600, 0x6FF)):
        if a <= o <= b:
            return name
    return "other" if ch.isalpha() else ""


def garbled(text: str, lang: str = "") -> bool:
    """Does a transcribed line look like nonsense? (Whisper told the wrong
    language writes Chinese sound as broken Khmer letters, Sinhala, Cyrillic …)"""
    t = (text or "").strip()
    if not t:
        return False
    if "\ufffd" in t:
        return True
    letters = [ch for ch in t if ch.isalpha()]
    if not letters:
        return False
    scripts = {_script(ch) for ch in letters} - {""}
    if len(scripts) >= 3:
        return True
    pat = _SCRIPTS.get((lang or "").split("-")[0])
    if pat and len(letters) >= 3:
        mine = sum(1 for ch in letters if re.match(pat, ch))
        if mine / len(letters) < 0.5:   # heard as Khmer, but written in another script
            return True
    tokens = t.split()
    if len(tokens) >= 4 and sum(1 for w in tokens if len(w) == 1) / len(tokens) >= 0.5:
        return True                     # "ច ឤ ផ ប ្ ត" - single letters
    return False


def summary(issues: List[Dict]) -> str:
    if not issues:
        return "✓ nothing to check"
    counts: Dict[str, int] = {}
    for r in issues:
        counts[r["kind"]] = counts.get(r["kind"], 0) + 1
    return ", ".join(f"{n} {KINDS[k].lower()}" for k, n in counts.items())


def write_csv(rows: List[Dict], path: str) -> str:
    """rows: issues with an "episode" key. Opens in Excel (BOM)."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Episode", "Time", "Problem", "Line"])
        for r in rows:
            t = r["time"]
            w.writerow([r.get("episode", ""), f"{int(t // 60):02d}:{t % 60:05.2f}",
                        r["what"], r["text"]])
    return path


# --------------------------------------------------------------------------- #
# Sound (2.3): loudness and peaks of an exported video
# --------------------------------------------------------------------------- #
LOUD_LUFS = -9.0            # above: too loud (YouTube / Facebook turn it down, it can distort)
QUIET_LUFS = -26.0          # below: too quiet next to other videos
CLIP_DB = -0.1              # true peak above: clipping
LEVEL_LU = 4.0              # an episode this far from the story's usual loudness


def measure_audio(path: str, timeout: float = 300.0) -> Optional[Dict]:
    """{"lufs", "peak"} of a video's sound (EBU R128 integrated loudness and
    true peak, from ffmpeg), or None when it cannot be measured."""
    from .media import find_ffmpeg, no_window

    if not path or not os.path.isfile(path):
        return None
    try:
        r = subprocess.run([find_ffmpeg(), "-hide_banner", "-nostats", "-i", path, "-vn",
                            "-af", "ebur128=peak=true", "-f", "null", "-"],
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                           stderr=subprocess.PIPE, timeout=timeout, creationflags=no_window())
    except (OSError, subprocess.SubprocessError):
        return None
    text = r.stderr.decode("utf-8", "replace")
    summary = text[text.rfind("Summary:"):] if "Summary:" in text else ""
    m_i = re.search(r"I:\s+(-?[\d.]+|-inf)\s+LUFS", summary)
    m_p = re.search(r"Peak:\s+(-?[\d.]+|-inf)\s+dBFS", summary)
    if not m_i:
        return None

    def num(m, default):
        try:
            return float(m.group(1)) if m else default
        except ValueError:
            return default

    return {"lufs": num(m_i, -70.0), "peak": num(m_p, -70.0)}


def check_audio(m: Optional[Dict], text: str = "") -> List[Dict]:
    """Rows for check_project's list from measure_audio() of the exported video."""
    if not m:
        return []
    out = []

    def add(kind, extra):
        out.append({"time": 0.0, "kind": kind, "what": f"{KINDS[kind]} ({extra})",
                    "text": text, "seg_id": ""})

    if m["peak"] > CLIP_DB:
        add("clip", f"peak {m['peak']:+.1f} dB")
    if m["lufs"] > LOUD_LUFS:
        add("loud", f"{m['lufs']:.1f} LUFS")
    elif m["lufs"] < QUIET_LUFS:
        add("quiet", f"{m['lufs']:.1f} LUFS")
    return out


def level_outliers(levels: Dict[str, float]) -> Dict[str, float]:
    """{episode: LUFS} -> the episodes LEVEL_LU louder / quieter than the
    middle of the story (difference in LU)."""
    vals = sorted(v for v in levels.values() if v > -60)
    if len(vals) < 3:
        return {}
    mid = vals[len(vals) // 2]
    return {k: round(v - mid, 1) for k, v in levels.items()
            if v > -60 and abs(v - mid) >= LEVEL_LU}
