"""
gender.py - Guess if a line is spoken by a man or a woman (for Voice "Auto").

Method: the pitch (fundamental frequency, F0) of the original speech.
Typical speaking pitch: men ~85-155 Hz, women ~165-255 Hz. For every line
we take 40 ms frames of the 16 kHz original audio, find the pitch of each
voiced frame with autocorrelation, and compare the median with ~160 Hz.

It is a best guess - background music, shouting or children can fool it.
The Translation tab shows ♂ / ♀ per line, and a double-click switches it.
"""

from typing import List, Optional

import numpy as np

from .media import read_wav_range

SR = 16000
SPLIT_HZ = 160.0
FMIN, FMAX = 70.0, 400.0


def estimate_pitch(x: np.ndarray, sr: int = SR) -> Optional[float]:
    """Median F0 in Hz of the voiced frames of x, or None if no voice."""
    win, hop = int(0.04 * sr), int(0.02 * sr)
    if len(x) < win:
        return None
    n = 1 + (len(x) - win) // hop
    idx = np.arange(win)[None, :] + hop * np.arange(n)[:, None]
    frames = x[idx].astype(np.float32)
    frames -= frames.mean(axis=1, keepdims=True)
    rms = np.sqrt((frames ** 2).mean(axis=1))
    loud = rms > max(0.01, 0.25 * float(np.percentile(rms, 90)))
    frames = frames[loud]
    if len(frames) == 0:
        return None
    frames *= np.hanning(win)[None, :].astype(np.float32)
    spec = np.fft.rfft(frames, n=2 * win, axis=1)
    ac = np.fft.irfft(np.abs(spec) ** 2, axis=1)[:, :win]
    ac /= np.maximum(ac[:, :1], 1e-9)
    lo, hi = int(sr / FMAX), int(sr / FMIN)
    seg = ac[:, lo:hi]
    lag = np.argmax(seg, axis=1)
    peak = seg[np.arange(len(seg)), lag]
    voiced = peak > 0.45
    if voiced.sum() < 3:
        return None
    f0 = sr / (lag[voiced] + lo)
    return float(np.median(f0))


def gender_from_pitch(f0: Optional[float]) -> str:
    if f0 is None:
        return ""
    return "female" if f0 >= SPLIT_HZ else "male"


def detect_genders(project, segments: Optional[List] = None, overwrite: bool = False) -> int:
    """Fill seg.gender ("male" / "female") from the original audio.

    Lines with no clear voice take the gender of the line before them.
    Returns how many lines were set."""
    path = project.original_audio
    segs = sorted(segments if segments is not None else project.segments,
                  key=lambda s: s.start)
    if not path:
        return 0
    from . import gender_ai

    ai = gender_ai.enabled() and gender_ai.model_ready() and gender_ai.available()
    done, prev = 0, "male"
    for seg in segs:
        if seg.gender and not overwrite:
            prev = seg.gender
            continue
        try:
            x = read_wav_range(path, int(seg.start * SR), int((seg.end - seg.start) * SR), SR)
            f0 = estimate_pitch(x)
            g = gender_from_pitch(f0)
            if ai:
                p = gender_ai.p_female(x)
                if p is not None:
                    g = gender_ai.decide(p, f0 or 0.0, SPLIT_HZ)[0]
        except Exception:
            g = ""
        seg.gender = g or prev
        prev = seg.gender
        done += 1
    return done
