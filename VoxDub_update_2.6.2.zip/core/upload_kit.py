"""
upload_kit.py - Ready to upload: a title, a description and a thumbnail for
every part of a story (Batch › Finish › Merge + split).

For "រឿង… ភាគ03.mp4" it writes next to the video:
  រឿង… ភាគ03.txt   title, description and hashtags (Khmer), to copy into
                    YouTube / Facebook
  រឿង… ភាគ03.jpg   1280x720 (or 720x1280) thumbnail: a clear frame of the
                    part, the title written on it, the logo in the corner

The description is written by Gemini from what is said in that part (the
dubbed lines), when a Gemini API key is set; without one a simple template
is used (title + story + hashtags). Nothing is uploaded.
"""

import os
import subprocess
import tempfile
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from .media import find_ffmpeg, get_media_info, no_window

Progress = Callable[[int, str], None]


# --------------------------------------------------------------------------- #
# what is said in each part
# --------------------------------------------------------------------------- #
def part_lines(episodes: Sequence[Tuple[float, List[Tuple[float, str]]]],
               edges: Sequence[float]) -> List[List[str]]:
    """episodes: [(episode length, [(time in episode, line), ...]), ...] in order;
    edges: the part borders on the joined video [0, cut1, cut2, ..., end].
    Returns the lines of every part."""
    parts: List[List[str]] = [[] for _ in range(max(1, len(edges) - 1))]
    offset = 0.0
    for length, lines in episodes:
        for t, text in lines:
            at = offset + t
            k = 0
            while k + 1 < len(edges) - 1 and at >= edges[k + 1]:
                k += 1
            if text.strip():
                parts[k].append(text.strip())
        offset += length
    return parts


# --------------------------------------------------------------------------- #
# title + description
# --------------------------------------------------------------------------- #
def template_text(title: str, story: str, number: int) -> Dict[str, str]:
    tag = "".join(c for c in story if not c.isspace())[:30]
    return {"title": title,
            "description": f"{title}\n\nរឿង {story} ភាគទី {number} និយាយភាសាខ្មែរ។\n"
                           "ចុច Subscribe ដើម្បីមើលភាគបន្ទាប់។",
            "hashtags": f"#{tag} #រឿងចិននិយាយខ្មែរ #និយាយខ្មែរ"}


def gemini_text(title: str, story: str, number: int, lines: List[str],
                lang_name: str = "Khmer") -> Dict[str, str]:
    """A catchy title, a short description and hashtags from the part's lines."""
    from . import gemini

    said = "\n".join(lines[:160])[:6000]
    prompt = f"""You write YouTube texts for a drama series dubbed into {lang_name}.
Series: {story}
This video: part {number} (file name: {title})

What is said in this part:
{said or "(no dialogue)"}

Write in {lang_name}:
- "title": the file name above plus a short catchy hook about this part (max 90 characters, no clickbait lies)
- "description": 2-4 sentences about what happens in this part, without the ending; then one line asking to subscribe
- "hashtags": 5 hashtags separated by spaces

Answer ONLY with JSON: {{"title": "...", "description": "...", "hashtags": "..."}}"""
    text, _finish = gemini.generate([{"text": prompt}], temperature=0.7)
    data = gemini._json(text)
    if not isinstance(data, dict) or not data.get("title"):
        raise ValueError("Gemini gave no title")
    return {k: str(data.get(k, "")).strip() for k in ("title", "description", "hashtags")}


def write_text(path: str, info: Dict[str, str]) -> str:
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write(f"TITLE\n{info['title']}\n\nDESCRIPTION\n{info['description']}\n\n"
                f"{info['hashtags']}\n")
    return path


# --------------------------------------------------------------------------- #
# thumbnail
# --------------------------------------------------------------------------- #
def _frame(video: str, t: float, w: int, h: int) -> Optional[np.ndarray]:
    try:
        r = subprocess.run([find_ffmpeg(), "-hide_banner", "-loglevel", "error",
                            "-ss", f"{t:.2f}", "-i", video, "-frames:v", "1",
                            "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           creationflags=no_window(), timeout=60)
    except (OSError, subprocess.SubprocessError):
        return None
    if len(r.stdout) < w * h * 3:
        return None
    return np.frombuffer(r.stdout[:w * h * 3], np.uint8).reshape(h, w, 3)


def best_frame_time(video: str, samples: int = 9) -> float:
    """A clear, bright, busy frame (not black, not a blurry cut)."""
    dur = get_media_info(video).duration
    best, best_t = -1.0, dur * 0.3
    for k in range(samples):
        t = dur * (0.12 + 0.76 * k / max(1, samples - 1))
        f = _frame(video, t, 96, 96)
        if f is None:
            continue
        g = f.mean(axis=2)
        light = g.mean()
        if light < 35 or light > 225:           # black / white flash
            continue
        sharp = np.abs(np.diff(g, axis=0)).mean() + np.abs(np.diff(g, axis=1)).mean()
        score = sharp * 2 + g.std() - abs(light - 120) * 0.2
        if score > best:
            best, best_t = score, t
    return best_t


def make_thumbnail(video: str, out_jpg: str, title: str, logo: str = "",
                   at: Optional[float] = None) -> str:
    """The thumbnail: a frame of the video, the title in big outlined letters
    at the bottom, the logo top-left. Same shape as the video
    (1280x720 landscape / 720x1280 portrait)."""
    from PySide6.QtCore import QPointF, QRectF, Qt
    from PySide6.QtGui import (QColor, QFont, QFontMetricsF, QImage, QLinearGradient,
                               QPainter, QPainterPath, QPen)

    info = get_media_info(video)
    portrait = info.height > info.width
    W, H = (720, 1280) if portrait else (1280, 720)
    t = best_frame_time(video) if at is None else at
    tmp = tempfile.mkdtemp(prefix="voxdub_thumb_")
    try:
        frame = os.path.join(tmp, "f.png")
        subprocess.run([find_ffmpeg(), "-hide_banner", "-loglevel", "error", "-y",
                        "-ss", f"{t:.2f}", "-i", video, "-frames:v", "1",
                        "-vf", f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}",
                        frame], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       creationflags=no_window(), timeout=60)
        img = QImage(frame)
        if img.isNull():
            img = QImage(W, H, QImage.Format.Format_RGB32)
            img.fill(QColor("#101418"))
        img = img.convertToFormat(QImage.Format.Format_RGB32)
        qp = QPainter(img)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        # dark band at the bottom so the title can be read on any picture
        grad = QLinearGradient(0, H * 0.55, 0, H)
        grad.setColorAt(0, QColor(0, 0, 0, 0))
        grad.setColorAt(1, QColor(0, 0, 0, 200))
        qp.fillRect(QRectF(0, H * 0.55, W, H * 0.45), grad)
        font = QFont("Noto Sans Khmer")
        font.setBold(True)
        size = int(W * (0.085 if portrait else 0.06))
        lines = _wrap(title, font, size, W * 0.9)
        font.setPixelSize(size)
        fm = QFontMetricsF(font)
        y = H - H * 0.05 - fm.height() * len(lines)
        path = QPainterPath()
        for i, ln in enumerate(lines):
            x = (W - fm.horizontalAdvance(ln)) / 2
            path.addText(QPointF(x, y + i * fm.height() + fm.ascent()), font, ln)
        pen = QPen(QColor(0, 0, 0), max(4.0, size * 0.16))
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        qp.strokePath(path, pen)
        qp.fillPath(path, QColor("#FFD84D"))
        if logo and os.path.isfile(logo):
            lg = QImage(logo)
            if not lg.isNull():
                lw = int(W * 0.18)
                lg = lg.scaledToWidth(lw, Qt.TransformationMode.SmoothTransformation)
                qp.drawImage(int(W * 0.03), int(H * 0.03), lg)
        qp.end()
        if not img.save(out_jpg, "JPG", 90):
            raise RuntimeError(f"Could not write {out_jpg}")
    finally:
        for f in os.listdir(tmp):
            try:
                os.remove(os.path.join(tmp, f))
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass
    return out_jpg


def _wrap(text: str, font, size: int, width: float) -> List[str]:
    """Up to 2 lines that fit (the font gets smaller when they do not)."""
    from PySide6.QtGui import QFontMetricsF

    for px in (size, int(size * 0.85), int(size * 0.72), int(size * 0.6)):
        font.setPixelSize(px)
        fm = QFontMetricsF(font)
        if fm.horizontalAdvance(text) <= width:
            return [text]
        words = text.split(" ")
        if len(words) > 1:
            for cut in range(len(words) - 1, 0, -1):
                a, b = " ".join(words[:cut]), " ".join(words[cut:])
                if fm.horizontalAdvance(a) <= width and fm.horizontalAdvance(b) <= width:
                    return [a, b]
    font.setPixelSize(int(size * 0.6))
    return [text]


# --------------------------------------------------------------------------- #
# all parts of a story
# --------------------------------------------------------------------------- #
def make_kit(parts: List[str], story: str, part_texts: List[List[str]], logo: str = "",
             use_gemini: bool = True, lang_name: str = "Khmer", first_number: int = 1,
             progress: Optional[Progress] = None,
             should_stop: Optional[Callable[[], bool]] = None) -> List[Dict]:
    """A .txt and a .jpg next to every part. Returns [{"video", "txt", "jpg", "title", "by"}]."""
    from . import gemini

    ai = use_gemini and gemini.configured()
    out = []
    for k, video in enumerate(parts):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        if progress:
            progress(int(100 * k / max(1, len(parts))),
                     f"Title + thumbnail {k + 1}/{len(parts)}...")
        stem = os.path.splitext(os.path.basename(video))[0]
        n = first_number + k
        info, by = template_text(stem, story, n), "template"
        if ai:
            try:
                info = gemini_text(stem, story, n, part_texts[k] if k < len(part_texts) else [],
                                   lang_name)
                by = "Gemini"
            except InterruptedError:
                raise
            except Exception as e:
                print(f"[upload kit] Gemini: {e} - template used")
        base = os.path.splitext(video)[0]
        txt = write_text(base + ".txt", info)
        jpg = make_thumbnail(video, base + ".jpg", stem, logo)
        out.append({"video": video, "txt": txt, "jpg": jpg, "title": info["title"], "by": by})
    if progress:
        progress(100, f"{len(out)} titles + thumbnails")
    return out
