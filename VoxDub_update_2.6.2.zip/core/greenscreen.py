"""
greenscreen.py - Green screen branding on the exported video: intro, outro,
Like & Subscribe, a moving logo ... (a video with a green / blue background).

The background colour is cut out (ffmpeg chromakey) and the clip is laid over
the video:

    mode "loop"   the whole video (the clip plays again and again)
    mode "start"  once, from `start_sec` (an intro)
    mode "end"    once, ending with the video (an outro)
    mode "every"  every `every_min` minutes from `start_sec` (Like & Subscribe)

Its own sound (a "click", a whoosh) can be mixed in. Everything is in the
project (project.green_overlays: a list of dicts), so presets / Batch keep it.
The times are those of the FINISHED video (after Speed), so an outro really
ends with the video.
"""

import math
import os
from typing import Dict, List, Optional, Tuple

from .media import get_media_info

KINDS = {"intro": "Intro", "outro": "Outro", "subscribe": "Like & Subscribe",
         "logo": "Moving logo", "other": "Other"}
MODES = {"loop": "Whole video (again and again)", "start": "Once at the start",
         "end": "Once at the end", "every": "Every few minutes"}
KEYS = {"#00FF00": "Green", "#0000FF": "Blue", "#000000": "Black"}
CORNERS = ["full", "top-left", "top-center", "top-right", "center", "bottom-left",
           "bottom-center", "bottom-right"]
CORNER_LABELS = {"full": "Full screen", "top-left": "Top left", "top-center": "Top centre",
                 "top-right": "Top right", "center": "Centre", "bottom-left": "Bottom left",
                 "bottom-center": "Bottom centre", "bottom-right": "Bottom right"}
MARGIN = 0.03                   # of the picture's short side

DEFAULT = {"path": "", "kind": "subscribe", "mode": "every", "every_min": 3.0,
           "start_sec": 10.0, "corner": "bottom-center", "size": 0.35, "key": "#00FF00",
           "similarity": 0.30, "blend": 0.08, "sound": True, "volume": 1.0, "on": True}

# what a kind usually is (chosen in the window, every value can be changed)
KIND_DEFAULTS = {
    "intro": {"mode": "start", "start_sec": 0.0, "corner": "full", "size": 1.0},
    "outro": {"mode": "end", "corner": "full", "size": 1.0},
    "subscribe": {"mode": "every", "every_min": 3.0, "start_sec": 10.0,
                  "corner": "bottom-center", "size": 0.35},
    "logo": {"mode": "loop", "corner": "top-right", "size": 0.18, "sound": False},
    "other": {"mode": "start", "start_sec": 0.0, "corner": "center", "size": 0.5},
}

_info: Dict[str, Tuple[float, float, bool]] = {}     # path -> (mtime, duration, has_audio)


def new_overlay(path: str, kind: str = "subscribe") -> dict:
    d = dict(DEFAULT, **KIND_DEFAULTS.get(kind, {}))
    d.update(path=path, kind=kind)
    return d


def clip_info(path: str) -> Tuple[float, bool]:
    """(seconds, has sound) of a clip (cached)."""
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return 0.0, False
    hit = _info.get(path)
    if hit and hit[0] == mt:
        return hit[1], hit[2]
    try:
        info = get_media_info(path)
        dur, snd = float(info.duration or 0.0), bool(info.has_audio)
    except Exception:
        dur, snd = 0.0, False
    _info[path] = (mt, dur, snd)
    return dur, snd


def items(project) -> List[dict]:
    """The overlays that are switched on and whose clip exists, filled in."""
    out = []
    for i, d in enumerate(getattr(project, "green_overlays", None) or []):
        if not isinstance(d, dict) or not d.get("on", True):
            continue
        path = d.get("path") or ""
        if not path or not os.path.isfile(path):
            continue
        dur, snd = clip_info(path)
        if dur <= 0.05:
            continue
        out.append({**DEFAULT, **d, "index": i, "duration": dur, "has_sound": snd})
    return out


def period(it: dict) -> float:
    """'every' mode: the gap between two showings, a whole number of clip
    lengths (so every showing starts at the clip's first frame)."""
    d = it["duration"]
    p = max(float(it.get("every_min") or 3.0) * 60.0, d + 1.0)
    return math.ceil(p / d) * d


def start_of(it: dict, total: float) -> float:
    if it["mode"] == "end":
        return max(0.0, total - it["duration"])
    if it["mode"] == "loop":
        return 0.0
    return max(0.0, float(it.get("start_sec") or 0.0))


def visible_at(it: dict, t: float, total: float) -> Optional[float]:
    """The clip's own time shown at video time t (None = not on screen)."""
    t0, d = start_of(it, total), it["duration"]
    if it["mode"] == "loop":
        return t % d
    if t < t0:
        return None
    if it["mode"] == "every":
        k = (t - t0) % period(it)
        return k if k < d else None
    return (t - t0) if t - t0 < d else None


def input_args(it: dict) -> List[str]:
    """ffmpeg input options for the clip."""
    loop = it["mode"] in ("loop", "every")
    return (["-stream_loop", "-1"] if loop else []) + ["-i", os.path.abspath(it["path"])]


def _hex(c: str) -> str:
    c = (c or "#00FF00").strip().lstrip("#")
    return "0x" + (c if len(c) == 6 else "00FF00").upper()


def _xy(corner: str, m: int) -> Tuple[str, str]:
    x = {"left": f"{m}", "center": "(main_w-overlay_w)/2",
         "right": f"main_w-overlay_w-{m}"}
    y = {"top": f"{m}", "center": "(main_h-overlay_h)/2",
         "bottom": f"main_h-overlay_h-{m}"}
    if corner in ("full", "center"):
        return x["center"], y["center"]
    v, h = corner.split("-")
    return x[h], y[v]


def video_filters(its: List[dict], first_input: int, vin: str, W: int, H: int,
                  total: float, fixed_t: Optional[float] = None) -> Tuple[List[str], str]:
    """Filter-graph parts that lay the clips over [vin]. Returns (parts, label).
    fixed_t: one picture at this time (preview): the inputs are single frames."""
    parts, cur = [], vin
    m = int(min(W, H) * MARGIN)
    for k, it in enumerate(its):
        n = first_input + k
        key = (f"chromakey={_hex(it['key'])}:{float(it['similarity']):.3f}:"
               f"{float(it['blend']):.3f}")
        if it["corner"] == "full":
            size = f"scale={W}:{H}:force_original_aspect_ratio=decrease"
        else:
            w = max(16, int(W * max(0.03, min(1.0, float(it["size"])))) // 2 * 2)
            size = f"scale={w}:-2"
        t0 = start_of(it, total)
        if fixed_t is not None:
            pts, enable, eof = "PTS-STARTPTS", "", "repeat"
        elif it["mode"] == "every":
            p = period(it)
            pts = f"PTS-STARTPTS+{t0:.3f}/TB"
            enable = f":enable='gte(t,{t0:.3f})*lt(mod(t-{t0:.3f},{p:.3f}),{it['duration']:.3f})'"
            eof = "pass"
        elif it["mode"] == "loop":
            pts, enable, eof = "PTS-STARTPTS", "", "repeat"
        else:
            pts, enable, eof = f"PTS-STARTPTS+{t0:.3f}/TB", "", "pass"
        parts.append(f"[{n}:v]{key},{size},format=yuva420p,setpts={pts}[gs{k}]")
        x, y = _xy(it["corner"], m)
        parts.append(f"[{cur}][gs{k}]overlay=x={x}:y={y}:eof_action={eof}"
                     f":format=auto{enable}[gv{k}]")
        cur = f"gv{k}"
    return parts, cur


def audio_filters(its: List[dict], first_input: int, total: float) -> Tuple[List[str], List[str]]:
    """The clips' own sound, in time with their pictures. (parts, labels)."""
    parts, labels = [], []
    fmt = "aresample=44100,aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo"
    for k, it in enumerate(its):
        if not (it.get("sound") and it.get("has_sound")):
            continue
        n = first_input + k
        vol = max(0.0, min(2.0, float(it.get("volume", 1.0))))
        t0 = start_of(it, total)
        delay = f",adelay={int(t0 * 1000)}:all=1" if t0 > 0 else ""
        mute = ""
        if it["mode"] == "every":
            p = period(it)
            mute = (f",volume=0:enable='lt(t,{t0:.3f})+gte(mod(t-{t0:.3f},{p:.3f}),"
                    f"{it['duration']:.3f})'")
        parts.append(f"[{n}:a]{fmt},asetpts=PTS-STARTPTS{delay},volume={vol:.2f}{mute}[ga{k}]")
        labels.append(f"ga{k}")
    return parts, labels
