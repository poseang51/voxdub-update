"""
recent.py - the projects shown under "Recent projects" on the Home page.

Each entry: kind (edit / dub / batch), title, the file to open again (a saved
project or the autosave next to the work files), the video, its length and a
short state ("Voices ready", "Exported" ...). Newest first, at most 12.
"""

import os
import time
from typing import Dict, List

from . import settings

MAX = 12
KEY = "recent_projects"


def items(existing_only: bool = True) -> List[Dict]:
    out = []
    for d in settings.get(KEY, []) or []:
        if not isinstance(d, dict) or not d.get("path"):
            continue
        if existing_only and not os.path.isfile(d["path"]):
            continue
        out.append(d)
    return out


def add(path: str, kind: str = "dub", title: str = "", video: str = "",
        length: float = 0.0, state: str = "") -> None:
    if not path:
        return
    key = os.path.normcase(os.path.abspath(path))
    old = [d for d in items(existing_only=False)
           if os.path.normcase(os.path.abspath(d["path"])) != key]
    prev = next((d for d in items(existing_only=False)
                 if os.path.normcase(os.path.abspath(d["path"])) == key), {})
    entry = {"path": os.path.abspath(path), "kind": kind or prev.get("kind", "dub"),
             "title": title or prev.get("title") or os.path.basename(video or path),
             "video": video or prev.get("video", ""),
             "length": float(length or prev.get("length") or 0.0),
             "state": state or prev.get("state", ""), "time": time.time()}
    try:
        settings.set(KEY, ([entry] + old)[:MAX])
    except OSError:
        pass


def remove(path: str) -> None:
    key = os.path.normcase(os.path.abspath(path))
    try:
        settings.set(KEY, [d for d in items(existing_only=False)
                           if os.path.normcase(os.path.abspath(d["path"])) != key])
    except OSError:
        pass


def when(t: float) -> str:
    """'today 21:40', 'yesterday', '05 Oct'."""
    if not t:
        return ""
    lt, now = time.localtime(t), time.localtime()
    if lt.tm_yday == now.tm_yday and lt.tm_year == now.tm_year:
        return time.strftime("today %H:%M", lt)
    if (time.mktime(now) - t) < 2 * 86400 and (now.tm_yday - lt.tm_yday) in (1, -364, -365):
        return "yesterday"
    return time.strftime("%d %b", lt)
