"""
effects.py - Movavi-style "Tools": Crop & Rotate, Color Adjustments and
Audio Properties, turned into ffmpeg filters.

* Crop uses the project's crop_left/top/right/bottom (also in the Style tab).
* Rotate (angle in degrees) and color adjustments apply to the whole video.
* Original-audio properties apply to the video's own sound; AI voice clips
  have their own volume / normalize / fade / speed (see sync.render_dub_mix).
"""

import math
from typing import List

from .project import _LOOK_FIELDS, Project

# Slider ranges used by the UI (and checked here)
COLOR_FIELDS = ("color_brightness", "color_contrast", "color_saturation",
                "color_hue", "color_temperature", "color_highlights", "color_shadows",
                "color_tint")
AUTO_FIELDS = ("color_auto_saturation", "color_auto_contrast", "color_magic",
               "color_auto_wb")
ORIG_AUDIO_FIELDS = ("orig_normalize", "orig_denoise", "orig_fade_in", "orig_fade_out")
CROP_FIELDS = ("crop_left", "crop_top", "crop_right", "crop_bottom", "zoom", "rotate")
LOOK_FIELDS = _LOOK_FIELDS

SMOOTH = 24         # frames: auto adjustments change slowly (no flicker)


def _num(v: float) -> str:
    return f"{v:.4f}".rstrip("0").rstrip(".") or "0"


def has_color(p: Project) -> bool:
    return any(abs(float(getattr(p, f, 0) or 0)) > 1e-6 for f in COLOR_FIELDS) or \
        any(bool(getattr(p, f, False)) for f in AUTO_FIELDS) or \
        abs(float(getattr(p, "color_gamma", 1.0) or 1.0) - 1.0) > 1e-3


def has_rotation(p: Project) -> bool:
    return abs(float(getattr(p, "rotate", 0.0) or 0.0)) > 0.01


def rotate_filter(p: Project) -> List[str]:
    """Straighten / rotate by any angle; the frame size stays, corners are black
    (crop them away with Crop, like in Movavi)."""
    if not has_rotation(p):
        return []
    return [f"rotate={_num(float(p.rotate))}*PI/180:ow=iw:oh=ih:c=black"]


def kelvin_rgb(kelvin: float) -> tuple:
    """RGB multipliers of a colour temperature (the formula ffmpeg's
    colortemperature filter uses; 6500 K is about neutral)."""
    k = kelvin / 100.0
    if k <= 66.0:
        r = 1.0
        g = min(1.0, max(0.0, 0.39008157876901960784 * math.log(k) - 0.63184144378862745098))
    else:
        t = max(k - 60.0, 0.0)
        r = min(1.0, max(0.0, 1.29293618606274509804 * t ** -0.1332047592))
        g = min(1.0, max(0.0, 1.12989086089529411765 * t ** -0.0755148492))
    if k >= 66.0:
        b = 1.0
    elif k <= 19.0:
        b = 0.0
    else:
        b = min(1.0, max(0.0, 0.54320678911019607843 * math.log(k - 10.0) - 1.19625408914))
    return r, g, b


def rgb_gains(p: Project):
    """(r, g, b) multipliers for Temperature and Tint, or None."""
    temp = float(p.color_temperature or 0) / 100.0      # + = warmer
    tint = float(getattr(p, "color_tint", 0) or 0) / 100.0      # + = magenta
    if abs(temp) <= 1e-3 and abs(tint) <= 1e-3:
        return None
    r = g = b = 1.0
    if abs(temp) > 1e-3:
        kelvin = 6500 - 3500 * temp if temp > 0 else 6500 - 5000 * temp
        r, g, b = kelvin_rgb(kelvin)
    if abs(tint) > 1e-3:
        g *= 1.0 - 0.15 * tint
        r *= 1.0 + 0.04 * tint
        b *= 1.0 + 0.04 * tint
    return r, g, b


def color_filters(p: Project) -> List[str]:
    """Color Adjustments -> ffmpeg filters (empty list = untouched)."""
    out: List[str] = []
    wb, auto_c, magic = p.color_auto_wb, p.color_auto_contrast, p.color_magic
    if wb or auto_c or magic:
        # normalize stretches the darkest/brightest pixels to full range;
        # independence 1 = per colour channel (= white balance), 0 = keep hue
        indep = 1.0 if wb and not (auto_c or magic) else (0.5 if wb else 0.0)
        strength = 0.6 if magic and not (wb or auto_c) else 1.0
        out.append(f"normalize=independence={_num(indep)}:strength={_num(strength)}"
                   f":smoothing={SMOOTH}")
    b = float(p.color_brightness or 0) / 100.0          # -1 .. 1
    c = float(p.color_contrast or 0) / 100.0
    s = float(p.color_saturation or 0) / 100.0
    brightness = 0.3 * b
    contrast = 1.0 + 0.6 * c
    saturation = max(0.0, 1.0 + s)
    if p.color_auto_saturation:
        saturation *= 1.35
    if magic:
        saturation *= 1.15
    gamma = max(0.1, float(getattr(p, "color_gamma", 1.0) or 1.0))
    if abs(brightness) > 1e-4 or abs(contrast - 1) > 1e-4 or abs(saturation - 1) > 1e-4 \
            or abs(gamma - 1) > 1e-3:
        eq = (f"eq=brightness={_num(brightness)}:contrast={_num(contrast)}"
              f":saturation={_num(saturation)}")
        if abs(gamma - 1) > 1e-3:
            eq += f":gamma={_num(gamma)}"
        out.append(eq)
    sh = float(getattr(p, "color_shadows", 0) or 0) / 100.0
    hi = float(getattr(p, "color_highlights", 0) or 0) / 100.0
    if abs(sh) > 1e-3 or abs(hi) > 1e-3:
        # lift / lower the dark and the bright tones with a tone curve
        y1, y2 = 0.25 + 0.15 * sh, 0.75 + 0.15 * hi
        out.append(f"curves=all='0/0 0.25/{_num(y1)} 0.75/{_num(y2)} 1/1'")
    hue = float(p.color_hue or 0)
    if abs(hue) > 0.05:
        out.append(f"hue=h={_num(hue)}")
    # Temperature + Tint: ONE per-channel lookup table (lutrgb). The same colour
    # as ffmpeg's colortemperature (its Kelvin -> RGB), but ~5x faster - and
    # colorbalance (the old tint) was ~15x slower than the whole export picture.
    gains = rgb_gains(p)
    if gains is not None:
        r, g, b = gains
        out.append(f"lutrgb=r='clipval*{_num(r)}':g='clipval*{_num(g)}':b='clipval*{_num(b)}'")
    if magic:
        out.append("unsharp=5:5:0.5")
    return out


def picture_filters(p: Project) -> List[str]:
    """Everything applied to the SOURCE picture before crop / ratio / logo."""
    return rotate_filter(p) + color_filters(p)


# --------------------------------------------------------------------------- #
# Audio: Equalizer, Noise Removal, Audio Effects (Movavi lists)
# --------------------------------------------------------------------------- #
EQ_BANDS = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000]
EQ_LABELS = ["32 Hz", "64 Hz", "125 Hz", "250 Hz", "500 Hz",
             "1 kHz", "2 kHz", "4 kHz", "8 kHz", "16 kHz"]
EQ_PRESETS = {                                     # dB per band, -20 .. +20
    "custom": None,
    "flat": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "voice": [-6, -5, -3, -1, 1, 3, 5, 4, 2, 0],
    "music": [4, 3, 2, 0, -1, -1, 0, 2, 3, 4],
    "volume": [6, 6, 6, 6, 6, 6, 6, 6, 6, 6],
    "hum": [-14, -10, -3, 0, 0, 0, 0, 0, 0, 0],
    "bass_boost": [8, 7, 5, 3, 1, 0, 0, 0, 0, 0],
    "bass_cut": [-8, -7, -5, -3, -1, 0, 0, 0, 0, 0],
    "treble_boost": [0, 0, 0, 0, 0, 1, 3, 5, 7, 8],
    "treble_cut": [0, 0, 0, 0, 0, -1, -3, -5, -7, -8],
}
EQ_PRESET_LABELS = {
    "custom": "Custom", "flat": "Flat", "voice": "Voice enhancement",
    "music": "Music enhancement", "volume": "Volume boost", "hum": "Hum reduction",
    "bass_boost": "Bass boost", "bass_cut": "Bass reduction",
    "treble_boost": "Treble boost", "treble_cut": "Treble reduction",
}


def _pitch(ratio: float) -> str:
    """Change the pitch, keep the speed."""
    return (f"asetrate=44100*{_num(ratio)},aresample=44100,"
            f"atempo={_num(1.0 / ratio)}")


AUDIO_EFFECTS = {
    "none": ("None", []),
    "radio": ("Radio", ["highpass=f=300", "lowpass=f=4000",
                        "acompressor=threshold=0.1:ratio=6:attack=5:release=60",
                        "volume=1.6"]),
    "echo": ("Echo", ["aecho=0.8:0.75:280:0.35"]),
    "muffled": ("Muffled", ["lowpass=f=650", "volume=1.3"]),
    "telephone": ("Telephone", ["highpass=f=400", "lowpass=f=3000", "volume=1.4"]),
    "pitch_vh": ("Very high pitch", [_pitch(1.5)]),
    "pitch_h": ("High pitch", [_pitch(1.22)]),
    "pitch_l": ("Low pitch", [_pitch(0.84)]),
    "pitch_vl": ("Very low pitch", [_pitch(0.7)]),
    "robot": ("Robot", ["afftfilt=real='hypot(re,im)*sin(0)':imag='hypot(re,im)*cos(0)'"
                        ":win_size=512:overlap=0.75", "volume=2.2"]),
}


def eq_filters(gains) -> List[str]:
    gains = list(gains or [])[:len(EQ_BANDS)]
    out = [f"equalizer=f={f}:t=o:w=1:g={_num(g)}"
           for f, g in zip(EQ_BANDS, gains) if abs(float(g)) > 0.05]
    if any(float(g) > 0.05 for g in gains):
        out.append("alimiter=limit=0.95")          # boosts must not clip
    return out


def denoise_filter(strength: float) -> str:
    nr = 5 + 0.35 * max(0.0, min(100.0, float(strength)))   # 5 .. 40 dB
    return f"afftdn=nr={_num(nr)}:nf=-25"


def effect_filters(name: str) -> List[str]:
    return list(AUDIO_EFFECTS.get(name or "none", AUDIO_EFFECTS["none"])[1])


def voice_track_filters(p: Project) -> List[str]:
    """Equalizer / Noise Removal / Audio Effects of the AI voice track."""
    out: List[str] = []
    if getattr(p, "voice_denoise", False):
        out.append(denoise_filter(p.voice_denoise_strength))
    out += eq_filters(getattr(p, "voice_eq", None))
    out += effect_filters(getattr(p, "voice_effect", "none"))
    return out


def track_active(p: Project, track: str) -> dict:
    """Which of Equalizer / Noise Removal / Effects are on (for the round marks)."""
    pre = "orig" if track == "orig" else "voice"
    eq = getattr(p, f"{pre}_eq", None) or []
    return {"eq": any(abs(float(g)) > 0.05 for g in eq),
            "noise": bool(getattr(p, f"{pre}_denoise", False)),
            "effects": (getattr(p, f"{pre}_effect", "none") or "none") != "none"}


def video_fade_filters(p: Project, total: float, speed: float = 1.0) -> List[str]:
    """Fades on the timeline; `speed`: the video is played faster afterwards,
    so the fades are made longer to last the seconds set in the exported video."""
    out = []
    fi = max(0.0, float(getattr(p, "video_fade_in", 0) or 0)) * speed
    fo = max(0.0, float(getattr(p, "video_fade_out", 0) or 0)) * speed
    if fi > 0:
        out.append(f"fade=t=in:st=0:d={_num(min(fi, total))}")
    if fo > 0 and total > 0:
        fo = min(fo, total)
        out.append(f"fade=t=out:st={_num(max(0.0, total - fo))}:d={_num(fo)}")
    return out


def render_audio_preview(p: Project, track: str, out_wav: str, src_t: float = 0.0,
                         clip=None, seconds: float = 8.0) -> str:
    """A few seconds of the original sound (at src_t) or of an AI voice clip,
    with the track's Equalizer / Noise Removal / Effects, to listen to."""
    import os

    from .media import run_ffmpeg

    if track == "voice":
        if clip is None:
            raise ValueError("Select an AI voice clip to preview")
        src, start = clip.path, clip.src_in
        filters = voice_track_filters(p)
    else:
        src, start = p.video_path, src_t
        filters = []
        if p.orig_denoise:
            filters.append(denoise_filter(p.orig_denoise_strength))
        if p.orig_normalize:
            filters.append("dynaudnorm=f=250:g=15")
        filters += eq_filters(p.orig_eq) + effect_filters(p.orig_effect)
    args = ["-ss", f"{max(0.0, start):.3f}", "-t", f"{seconds:.2f}",
            "-i", os.path.abspath(src), "-vn", "-ac", "2", "-ar", "44100"]
    if filters:
        args += ["-af", ",".join(filters)]
    run_ffmpeg(args + [os.path.abspath(out_wav)])
    return out_wav


def original_audio_filters(p: Project, total: float, speed: float = 1.0) -> List[str]:
    """Audio Properties of the video's own sound (before its volume)."""
    out: List[str] = []
    if p.orig_denoise:
        out.append(denoise_filter(getattr(p, "orig_denoise_strength", 50.0)))
    if p.orig_normalize:
        out.append("dynaudnorm=f=250:g=15")
    out += eq_filters(getattr(p, "orig_eq", None))
    out += effect_filters(getattr(p, "orig_effect", "none"))
    # (speed: the export plays the video faster afterwards - keep the seconds set)
    fi = max(0.0, float(p.orig_fade_in or 0)) * speed
    fo = max(0.0, float(p.orig_fade_out or 0)) * speed
    if fi > 0:
        out.append(f"afade=t=in:st=0:d={_num(min(fi, total))}")
    if fo > 0 and total > 0:
        fo = min(fo, total)
        out.append(f"afade=t=out:st={_num(max(0.0, total - fo))}:d={_num(fo)}")
    return out


def reset_color(p: Project, manual: bool = True, auto: bool = True):
    if manual:
        for f in COLOR_FIELDS:
            setattr(p, f, 0.0)
        p.color_gamma = 1.0
    if auto:
        for f in AUTO_FIELDS:
            setattr(p, f, False)


def look_snapshot(p: Project) -> dict:
    return {f: getattr(p, f) for f in LOOK_FIELDS if hasattr(p, f)}


def render_color_still(p: Project, src_t: float, out_png: str, width: int = 960) -> str:
    """One frame of the SOURCE (no crop / rotate) with the color adjustments,
    for the paused preview. Qt cannot apply these filters to live video."""
    import os

    from .media import run_ffmpeg

    filters = color_filters(p) + [f"scale={width}:-2"]
    run_ffmpeg(["-ss", f"{max(0.0, src_t):.3f}", "-i", os.path.abspath(p.video_path),
                "-vf", ",".join(filters), "-frames:v", "1", os.path.abspath(out_png)])
    return out_png
