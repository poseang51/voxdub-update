"""
presets.py - Named settings profiles shared by the Editor and Batch (2.4).

A preset holds everything a dub is made with - languages, voice, speech
engines, subtitle style, logo / brand text, blur box, output size and the
video / audio tools - so "Chinese drama -> Khmer (F2 Movie)" or "TikTok 9:16"
is one click in either window.

Stored in the user's settings folder as presets.json (not in projects, so a
preset made in the Editor shows in Batch and the other way round).
"""

import copy
import json
import os
from typing import Dict, List, Optional

from . import settings
from .batch import SETTING_FIELDS

FILE = "presets.json"
NAME_MAX = 60

# Built-in starting points (only the fields they change; the rest is kept).
BUILTIN: Dict[str, dict] = {
    "Chinese → Khmer (drama)": {"source_lang": "zh", "target_lang": "km"},
    "TikTok 9:16": {"out_ratio": "9:16", "out_width": 1080, "out_height": 1920},
    "YouTube 1080p 16:9": {"out_ratio": "16:9", "out_width": 1920, "out_height": 1080},
}


def _path() -> str:
    return os.path.join(settings.settings_dir(), FILE)


def _load() -> Dict[str, dict]:
    try:
        with open(_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): v for k, v in data.items() if isinstance(v, dict)}


def _store(data: Dict[str, dict]) -> None:
    os.makedirs(settings.settings_dir(), exist_ok=True)
    tmp = _path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _path())


def clean_name(name: str) -> str:
    return " ".join((name or "").split())[:NAME_MAX]


def clean(values: dict) -> dict:
    """Only the fields a preset may carry (no paths of one video, no secrets)."""
    return {k: copy.deepcopy(v) for k, v in (values or {}).items() if k in SETTING_FIELDS}


def list_presets() -> List[str]:
    """The user's presets first (A-Z), then the built-in ones not overridden."""
    own = sorted(_load(), key=str.lower)
    return own + [n for n in BUILTIN if n not in own]


def is_builtin(name: str) -> bool:
    return name in BUILTIN and name not in _load()


def get(name: str) -> Optional[dict]:
    own = _load()
    if name in own:
        return clean(own[name])
    if name in BUILTIN:
        return clean(BUILTIN[name])
    return None


def save(name: str, values: dict) -> str:
    name = clean_name(name)
    if not name:
        raise ValueError("A preset needs a name.")
    data = _load()
    data[name] = clean(values)
    _store(data)
    return name


def delete(name: str) -> bool:
    data = _load()
    if name not in data:
        return False
    del data[name]
    _store(data)
    return True


def from_project(project) -> dict:
    return {k: copy.deepcopy(getattr(project, k)) for k in SETTING_FIELDS if hasattr(project, k)}


def apply(project, values: dict) -> List[str]:
    """Put a preset's values on a project / object; returns the changed fields."""
    changed = []
    for k, v in clean(values).items():
        if hasattr(project, k) and getattr(project, k) != v:
            setattr(project, k, copy.deepcopy(v))
            changed.append(k)
    return changed


def apply_dict(base: dict, values: dict) -> dict:
    """A settings dict (Batch base) with the preset on top."""
    out = copy.deepcopy(base or {})
    out.update(clean(values))
    return out


LANG_SHORT = {"zh": "中文", "km": "ខ្មែរ", "en": "EN", "th": "ไทย", "vi": "VI", "ko": "한국어",
              "ja": "日本語", "auto": "Auto"}


def summary(values: dict) -> str:
    """One line for the Batch bar: '中文 → ខ្មែរ · Piseth · Logo · Blur · 9:16'."""
    v = values or {}
    src, dst = v.get("source_lang", ""), v.get("target_lang", "")
    parts = [f"{LANG_SHORT.get(src, src or '?')} → {LANG_SHORT.get(dst, dst or '?')}"]
    voice = str(v.get("voice") or "")
    if voice == "auto":
        parts.append("Auto ♂/♀")
    elif voice:
        names = [x.split("-")[-1].replace("Neural", "") or x for x in voice.split("|")]
        parts.append("/".join(names))
    if v.get("logo_path") or v.get("extra_logos"):
        parts.append("Logo")
    if v.get("brand_text"):
        parts.append("Text")
    if v.get("cover_enabled"):
        parts.append("Blur")
    if v.get("subs_hidden"):
        parts.append("No subs")
    ratio = v.get("out_ratio")
    if ratio and ratio not in ("source", "original", ""):
        parts.append(str(ratio))
    return " · ".join(parts)
