"""
emotion.py - how is each line said? (the Delivery column, automatically)

The AI voice can say a line normal / excited / angry / shout / sad / gentle
/ question (tts.DELIVERY: a little higher or lower, faster or slower). Here
every line of the original speech is measured and compared with how THAT
character usually speaks (its other lines):

  * loudness (dB) - much louder than usual = excited / angry / shouting,
    much quieter = gentle / sad;
  * pitch (semitones above / below the character's usual pitch);
  * pitch movement - a lively voice goes up and down a lot;
  * the text - a question mark (Chinese ？ too) = question.

Only clear differences change a line; everything else stays "normal". Lines
whose Delivery the user chose by hand are never changed.
"""

from typing import Dict, List, Optional, Tuple

import numpy as np

from .media import read_wav

SR = 16000
FMIN, FMAX = 70.0, 500.0
QUESTION = ("?", "？", "吗", "嗎", "呢", "吧")


def measure(x: np.ndarray, sr: int = SR) -> Optional[Tuple[float, float, float]]:
    """(loudness dB, median pitch Hz, pitch movement in semitones) of the
    voiced part of a line, or None when no voice is heard."""
    win, hop = int(0.04 * sr), int(0.02 * sr)
    if len(x) < win * 3:
        return None
    n = 1 + (len(x) - win) // hop
    idx = np.arange(win)[None, :] + hop * np.arange(n)[:, None]
    frames = x[idx].astype(np.float32)
    frames -= frames.mean(axis=1, keepdims=True)
    rms = np.sqrt((frames ** 2).mean(axis=1))
    loud = rms > max(0.005, 0.25 * float(np.percentile(rms, 90)))
    if loud.sum() < 3:
        return None
    db = float(20 * np.log10(np.mean(rms[loud]) + 1e-9))
    f = frames[loud] * np.hanning(win)[None, :].astype(np.float32)
    spec = np.fft.rfft(f, n=2 * win, axis=1)
    ac = np.fft.irfft(np.abs(spec) ** 2, axis=1)[:, :win]
    ac /= np.maximum(ac[:, :1], 1e-9)
    lo, hi = int(sr / FMAX), int(sr / FMIN)
    seg = ac[:, lo:hi]
    lag = np.argmax(seg, axis=1)
    voiced = seg[np.arange(len(seg)), lag] > 0.45
    if voiced.sum() < 3:
        return db, 0.0, 0.0
    f0 = sr / (lag[voiced] + lo)
    med = float(np.median(f0))
    st = 12 * np.log2(f0 / med)
    move = float(np.percentile(st, 90) - np.percentile(st, 10))
    return db, med, move


def classify(d_db: float, d_st: float, move: float, base_move: float, text: str) -> str:
    """The delivery from the differences to the character's usual voice."""
    lively = move - base_move
    if d_db >= 8 and d_st >= 3:
        return "shout"
    if d_db >= 5 and d_st >= 2:
        return "excited"
    if d_db >= 5:
        return "angry"                       # loud but not higher: hard, angry
    if d_st >= 3 and lively >= 2:
        return "happy"
    if d_db <= -6 and d_st <= -1.5:
        return "sad"
    if d_db <= -6:
        return "gentle"
    t = (text or "").strip()
    if t.endswith(QUESTION) or t.rstrip("。.!！").endswith(("?", "？")):
        return "question"
    if d_db <= -4 and lively <= -1.5:
        return "calm"
    return "normal"


def detect(project, overwrite: bool = False) -> int:
    """Set seg.delivery of every line from the original speech. Lines the user
    set by hand (delivery_auto False) keep theirs. Returns lines changed."""
    path = getattr(project, "original_audio", "")
    segs = [s for s in project.segments if (s.text or "").strip()]
    if not path or not segs:
        return 0
    try:
        audio, sr = read_wav(path)
    except Exception as e:
        print(f"[emotion] skipped: {e}")
        return 0
    m: Dict[str, Tuple[float, float, float]] = {}
    for s in segs:
        r = measure(audio[int(s.start * sr):int(s.end * sr)], sr)
        if r is not None:
            m[s.id] = r
    # the usual voice of every character (its median line); lines without a
    # character are compared with all lines of the same man / woman
    groups: Dict[str, List[Tuple[float, float, float]]] = {}
    for s in segs:
        if s.id in m:
            groups.setdefault(s.speaker or ("?" + (s.gender or "")), []).append(m[s.id])
    everyone = list(m.values())

    def base(rows):
        if len(rows) < 4:
            rows = everyone
        db = float(np.median([r[0] for r in rows]))
        ps = [r[1] for r in rows if r[1]]
        mv = [r[2] for r in rows if r[1]]
        return db, (float(np.median(ps)) if ps else 0.0), (float(np.median(mv)) if mv else 0.0)

    bases = {k: base(v) for k, v in groups.items()}
    changed = 0
    for s in segs:
        if not getattr(s, "delivery_auto", True) and not overwrite:
            continue
        want = "normal"
        if s.id in m:
            db, f0, move = m[s.id]
            b_db, b_f0, b_move = bases[s.speaker or ("?" + (s.gender or ""))]
            d_st = 12 * np.log2(f0 / b_f0) if f0 and b_f0 else 0.0
            want = classify(db - b_db, float(d_st), move, b_move, s.text)
        elif (s.text or "").strip().endswith(QUESTION):
            want = "question"
        if s.delivery != want:
            s.delivery = want
            changed += 1
        s.delivery_auto = True
    return changed


def counts(project) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for s in project.segments:
        out[s.delivery or "normal"] = out.get(s.delivery or "normal", 0) + 1
    return out
