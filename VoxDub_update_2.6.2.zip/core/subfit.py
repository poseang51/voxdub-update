"""
subfit.py - Make subtitles fit inside the video frame.

libass (ffmpeg's subtitle renderer) sizes fonts relative to the video
HEIGHT and wraps long lines only at spaces. Khmer and Chinese rarely use
spaces, so a long line runs off both edges of the frame - worst on
portrait (9:16) phone videos. These helpers pick a font size for the frame
shape and insert the line breaks ourselves, so the export and the preview
show the same lines.
"""

import math
import unicodedata
from typing import List

SCRIPT_HEIGHT = 288         # libass script height used for SRT input
BASE_FONT_SIZE = 24         # font size for a 16:9 video (script units)
SIDE_MARGIN = 0.05          # free space left/right, fraction of frame width
BOTTOM_MARGIN = 28          # script units (MarginV)

# characters that must not start a line (Khmer khan, CJK punctuation ...)
_NO_LINE_START = set("។៕៖,.!?;:)]}，。！？；：、）」』》")


def font_size(width: int, height: int, scale: float = 1.0) -> float:
    """Font size (script units) for a frame: full size on 16:9, smaller on
    square / portrait videos where the frame is narrow."""
    ratio = 1.0
    if width > 0 and height > 0:     # 9:16 -> 0.56, 1:1 -> 0.75, 16:9 -> 1.0
        ratio = max(0.5, min(1.0, math.sqrt((width / height) / (16 / 9))))
    return round(BASE_FONT_SIZE * ratio * scale, 1)


def _clusters(text: str) -> List[str]:
    """Split text into clusters that must stay together: a base letter plus
    its vowel signs / marks, and Khmer coeng (U+17D2) + subscript consonant."""
    out: List[str] = []
    for ch in text:
        if out and (unicodedata.category(ch) in ("Mn", "Mc", "Me")
                    or out[-1].endswith(("្", "‍"))):
            out[-1] += ch
        else:
            out.append(ch)
    return out


def _is_khmer_or_cjk(cluster: str) -> bool:
    c = cluster[0]
    return "ក" <= c <= "៿" or unicodedata.east_asian_width(c) in ("W", "F")


def _cluster_width(cluster: str) -> float:
    """Advance in units of the libass font size (measured from libass renders
    of Noto Sans Khmer: Khmer 0.51, CJK 0.79, Latin 0.23 - plus a margin)."""
    c = cluster[0]
    if c.isspace():
        return 0.2
    if "ក" <= c <= "៿":
        return 0.55
    if unicodedata.east_asian_width(c) in ("W", "F"):
        return 0.82
    return 0.27


def text_width(text: str) -> float:
    """Estimated width of one line, in units of the libass font size."""
    return sum(_cluster_width(c) for c in _clusters(text.strip()))


def _wrap_paragraph(text: str, max_width: float) -> List[str]:
    cl = _clusters(text.strip())
    widths = [_cluster_width(c) for c in cl]
    total = sum(widths)
    if total <= max_width or len(cl) < 2:
        return ["".join(cl)]
    n_lines = math.ceil(total / max_width)
    lines: List[str] = []
    start = 0
    while start < len(cl):
        rest = sum(widths[start:])
        if rest <= max_width:
            lines.append("".join(cl[start:]).strip())
            break
        target = rest / max(1, n_lines - len(lines))
        # candidate break positions i (line = cl[start:i]) that fit
        best, best_score, w = None, None, 0.0
        for i in range(start + 1, len(cl)):
            w += widths[i - 1]
            if w > max_width:
                break
            prev, cur = cl[i - 1], cl[i]
            if cur[0] in _NO_LINE_START:
                continue
            space = cur.isspace() or prev.isspace()
            if not space and not (_is_khmer_or_cjk(prev) and _is_khmer_or_cjk(cur)):
                continue        # never split a Latin word
            score = abs(w - target) - (0.25 * target if space else 0.0)
            if best_score is None or score < best_score:
                best, best_score = i, score
        if best is None:        # one very long word: hard break where it fills the line
            best, w = start + 1, widths[start]
            while best < len(cl) and w + widths[best] <= max_width:
                w += widths[best]
                best += 1
        lines.append("".join(cl[start:best]).strip())
        start = best
        while start < len(cl) and cl[start].isspace():
            start += 1
    return [l for l in lines if l]


def wrap_text(text: str, width: int, height: int, size: float) -> str:
    """Insert line breaks so `text` fits a width x height frame at font `size`."""
    if width <= 0 or height <= 0 or size <= 0:
        return text
    max_width = SCRIPT_HEIGHT * (width / height) * (1 - 2 * SIDE_MARGIN) / size
    lines: List[str] = []
    for par in text.split("\n"):
        lines += _wrap_paragraph(par, max_width)
    return "\n".join(lines)
