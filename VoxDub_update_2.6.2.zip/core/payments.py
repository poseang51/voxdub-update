"""
payments.py - Payment requests and the Admin audit log (2.6, seller's PC only).

There is no bank / ABA / KHQR connection: the customer pays by the usual
channel and sends the buy message (Machine ID + Order ID). The seller checks
the payment HIMSELF, then approves the request here, then makes the key.

    pending  -> approved -> issued        (one key per order, never two)
             -> rejected
             -> cancelled

Every step goes into the audit log  %USERPROFILE%\\.voxdub_admin\\audit.jsonl:
one JSON line per event, each with the SHA-256 of the line before it, so a
line changed or removed later is found by verify_audit(). No keys, prices of
other people or secrets are written there - only what happened and to which
order / customer.

Only the PC that holds the signing key may change anything (admin.is_owner):
the check is in these functions, not only in the window.
"""

import datetime as dt
import hashlib
import json
import os
import threading
from typing import Dict, List, Optional

from . import admin

STATES = {"pending": "⏳ Waiting for payment", "approved": "✅ Paid – checked",
          "rejected": "❌ Rejected", "cancelled": "✖ Cancelled", "issued": "🔑 Key made"}
_lock = threading.Lock()


def _orders_file() -> str:
    return os.path.join(admin.ADMIN_DIR, "orders.json")


def _audit_file() -> str:
    return os.path.join(admin.ADMIN_DIR, "audit.jsonl")


def _need_admin():
    if not admin.is_owner():
        raise PermissionError("Only the seller's PC (with the signing key) can do this.")


def _now() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------- #
# audit log (tamper-evident: every line carries the hash of the line before)
# --------------------------------------------------------------------------- #
def _last_hash() -> str:
    try:
        with open(_audit_file(), "rb") as f:
            lines = f.read().splitlines()
        return hashlib.sha256(lines[-1]).hexdigest() if lines else ""
    except OSError:
        return ""


def audit(action: str, **info) -> None:
    """Write one event (seller's PC). Secrets are never passed in here."""
    _need_admin()
    info = {k: v for k, v in info.items() if k not in ("key", "private", "secret")}
    with _lock:
        rec = {"time": _now(), "action": action, **info, "prev": _last_hash()}
        os.makedirs(admin.ADMIN_DIR, exist_ok=True)
        with open(_audit_file(), "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")


def read_audit(limit: int = 200) -> List[dict]:
    try:
        with open(_audit_file(), encoding="utf-8") as f:
            rows = [json.loads(x) for x in f if x.strip()]
    except (OSError, ValueError):
        return []
    return rows[-limit:][::-1]


def verify_audit() -> Optional[int]:
    """None when the log is whole; else the number (1..) of the first bad line."""
    try:
        with open(_audit_file(), "rb") as f:
            lines = f.read().splitlines()
    except OSError:
        return None
    prev = ""
    for n, line in enumerate(lines, 1):
        try:
            rec = json.loads(line)
        except ValueError:
            return n
        if rec.get("prev", "") != prev:
            return n
        prev = hashlib.sha256(line).hexdigest()
    return None


# --------------------------------------------------------------------------- #
# payment requests
# --------------------------------------------------------------------------- #
def load() -> List[dict]:
    try:
        with open(_orders_file(), encoding="utf-8") as f:
            data = json.load(f)
        return [o for o in data if isinstance(o, dict)] if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save(orders: List[dict]) -> None:
    os.makedirs(admin.ADMIN_DIR, exist_ok=True)
    tmp = _orders_file() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(orders, f, ensure_ascii=False, indent=1)
    os.replace(tmp, _orders_file())


def find(order: str) -> Optional[dict]:
    order = (order or "").strip().upper()
    return next((o for o in load() if o.get("order") == order), None)


def add(order: str, customer_id: str, machine: str, days: int = 0, label: str = "",
        price: str = "", method: str = "") -> dict:
    """A new request (from the customer's message). The same Order ID twice is
    refused - the first one is returned."""
    _need_admin()
    order = (order or "").strip().upper()
    if not order:
        raise ValueError("No Order ID")
    with _lock:
        orders = load()
        old = next((o for o in orders if o.get("order") == order), None)
        if old is not None:
            return old
        rec = {"order": order, "customer": customer_id, "machine": machine, "days": int(days),
               "label": label, "price": price, "method": method, "status": "pending",
               "created": _now(), "reviewer": "", "reviewed": "", "issued": "",
               "expires": ""}
        orders.insert(0, rec)
        _save(orders)
    audit("request_added", order=order, customer=customer_id, plan=label, price=price)
    return rec


def set_status(order: str, status: str, reviewer: str = "Admin", note: str = "") -> dict:
    """approve / reject / cancel after the seller checked the payment himself."""
    _need_admin()
    if status not in ("approved", "rejected", "cancelled", "pending"):
        raise ValueError(f"Unknown status {status}")
    with _lock:
        orders = load()
        rec = next((o for o in orders if o.get("order") == (order or "").upper()), None)
        if rec is None:
            raise KeyError(f"No request {order}")
        if rec["status"] == "issued":
            raise RuntimeError(f"{order}: the key is already made – it cannot change now.")
        if rec["status"] == status:
            return rec
        rec.update(status=status, reviewer=reviewer, reviewed=_now(), note=note)
        _save(orders)
    audit("request_" + status, order=rec["order"], customer=rec.get("customer", ""),
          reviewer=reviewer, note=note)
    return rec


def can_issue(order: str) -> str:
    """"" when a key may be made for this order, else why not."""
    rec = find(order)
    if rec is None:
        return "no request"
    if rec["status"] == "issued":
        return f"a key was already made for {rec['order']} on {rec['issued'][:10]}"
    if rec["status"] != "approved":
        return f"the payment of {rec['order']} is not approved ({STATES[rec['status']]})"
    return ""


def mark_issued(order: str, expires: str) -> dict:
    """After the key is made: the order is closed (a second key is refused)."""
    _need_admin()
    with _lock:
        orders = load()
        rec = next((o for o in orders if o.get("order") == (order or "").upper()), None)
        if rec is None:
            raise KeyError(f"No request {order}")
        why = "" if rec["status"] == "approved" else can_issue(order)
        if why:
            raise RuntimeError(why)
        rec.update(status="issued", issued=_now(), expires=expires)
        _save(orders)
    audit("key_issued", order=rec["order"], customer=rec.get("customer", ""), expires=expires)
    return rec


def for_customer(customer_id: str) -> List[dict]:
    return [o for o in load() if o.get("customer") == customer_id]


def summary() -> Dict[str, int]:
    out = {k: 0 for k in STATES}
    for o in load():
        out[o.get("status", "pending")] = out.get(o.get("status", "pending"), 0) + 1
    return out
