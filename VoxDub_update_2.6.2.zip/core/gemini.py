"""
gemini.py - Google Gemini with YOUR OWN API key(s) (Google AI Studio).

Used for
  * Translation that follows the story: the model sees the lines around each
    batch, keeps names and forms of address the same all through the video
    and writes natural spoken dialogue for dubbing.
  * Speech-to-text (optional, instead of Whisper): the audio is sent in
    short pieces and the model writes down what is said.

Keys are kept in the user's settings on this computer only (never in a
project file). Several keys can be added (one per Google account / Cloud
project = one quota each): the requests go round-robin, and a key that hits
its quota (HTTP 429 / RESOURCE_EXHAUSTED) rests for a minute while the others
carry on.

Gemini 3 models are sent thinkingLevel "low", Gemini 2.5 thinkingBudget 0
(translation needs no long thinking and it costs time + output tokens); a
model that refuses the field is asked again without it.
"""

import base64
import io
import json
import re
import threading
import time
import wave
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from . import settings

API = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_MODEL = "gemini-2.5-flash"
SUGGESTED_MODELS = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro",
                    "gemini-3.6-flash"]
BATCH_LINES = 30
CONTEXT_LINES = 8
AFTER_LINES = 4                 # the lines that come next (understand, do not translate)
TIMEOUT = 120

Progress = Callable[[int, str], None]


class GeminiError(RuntimeError):
    pass


class QuotaError(GeminiError):
    pass


# --------------------------------------------------------------------------- #
# keys + model (settings)
# --------------------------------------------------------------------------- #
def keys() -> List[str]:
    ks = settings.get("gemini_keys", []) or []
    return [k.strip() for k in ks if isinstance(k, str) and k.strip()]


def set_keys(ks: Sequence[str]):
    settings.set("gemini_keys", list(dict.fromkeys(k.strip() for k in ks if k.strip())))


def model() -> str:
    return (settings.get("gemini_model", "") or DEFAULT_MODEL).strip()


def configured() -> bool:
    return bool(keys())


# --------------------------------------------------------------------------- #
# HTTP with key rotation
# --------------------------------------------------------------------------- #
_lock = threading.Lock()
_turn = {"i": 0}
_rest: Dict[str, float] = {}            # key -> time it may be used again
_dead: Dict[str, str] = {}             # key -> why it was refused (this session)


def _thinking(m: str) -> Optional[dict]:
    m = m.lower()
    if m.startswith("gemini-3"):
        return {"thinkingLevel": "low"}
    if m.startswith("gemini-2.5") and "pro" not in m:
        return {"thinkingBudget": 0}
    return None


def _http(url: str, body: Optional[dict], timeout: float = TIMEOUT) -> Tuple[int, dict]:
    import requests

    if body is None:
        r = requests.get(url, timeout=timeout)
    else:
        r = requests.post(url, json=body, timeout=timeout)
    try:
        data = r.json()
    except ValueError:
        data = {"error": {"message": r.text[:300]}}
    return r.status_code, data


def _err_text(data: dict) -> str:
    e = data.get("error") if isinstance(data, dict) else None
    if isinstance(e, dict):
        return f"{e.get('status', '')} {e.get('message', '')}".strip()
    return str(data)[:300]


def _next_key(pool: List[str]) -> Optional[str]:
    with _lock:
        now = time.time()
        for _ in range(len(pool)):
            k = pool[_turn["i"] % len(pool)]
            _turn["i"] += 1
            if _rest.get(k, 0) <= now:
                return k
    return None


def generate(parts: List[dict], want_json: bool = True, max_tokens: int = 16384,
             temperature: float = 0.3, key_list: Optional[List[str]] = None,
             model_name: str = "", should_stop: Optional[Callable[[], bool]] = None
             ) -> Tuple[str, str]:
    """One generateContent call. Returns (text, finishReason)."""
    pool = key_list if key_list is not None else keys()
    if not pool:
        raise GeminiError("No Gemini API key – add one in Settings › AI engines & API keys")
    m = model_name or model()
    cfg = {"temperature": temperature, "maxOutputTokens": max_tokens}
    if want_json:
        cfg["responseMimeType"] = "application/json"
    think = _thinking(m)
    if think:
        cfg["thinkingConfig"] = think
    body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": cfg}
    last = ""
    deadline = time.time() + 300
    while time.time() < deadline:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        key = _next_key(pool)
        if key is None and pool and all(k in _dead for k in pool):
            raise GeminiError(f"Gemini key refused: {_dead[pool[0]]} – all {len(pool)} keys")
        if key is None:                         # every key is resting
            wait = max(1.0, min(_rest.get(k, 0) for k in pool) - time.time())
            if wait > 90:
                raise QuotaError(f"All Gemini keys are over their quota: {last}")
            time.sleep(min(wait, 5.0))
            continue
        try:
            code, data = _http(f"{API}/models/{m}:generateContent?key={key}", body)
        except Exception as e:                  # network
            last = str(e)[:200]
            time.sleep(3)
            continue
        if code == 200:
            cands = data.get("candidates") or []
            if not cands:
                fb = data.get("promptFeedback", {})
                raise GeminiError(f"Gemini returned nothing ({fb.get('blockReason', 'blocked')})")
            c = cands[0]
            text = "".join(p.get("text", "") for p in (c.get("content") or {}).get("parts", [])
                           if not p.get("thought"))
            return text, c.get("finishReason", "")
        last = _err_text(data)
        if code == 400 and "thinking" in last.lower() and "thinkingConfig" in cfg:
            cfg.pop("thinkingConfig")           # this model does not take the field
            continue
        if code in (429, 503) or "RESOURCE_EXHAUSTED" in last:
            with _lock:
                _rest[key] = time.time() + (60 if code == 429 else 10)
            continue
        bad_key = (code in (401, 403) and "quota" not in last.lower()) or (
            code == 400 and ("api key not valid" in last.lower()
                             or "api_key_invalid" in last.lower()))
        if bad_key:
            # 2.5: one dead key (deleted / disabled project) must not stop the
            # work while other keys are fine: skip it for this session
            with _lock:
                _dead[key] = last
                _rest[key] = float("inf")
            if all(k in _dead for k in pool):
                raise GeminiError(f"Gemini key refused ({code}): {last}"
                                  + (f" – all {len(pool)} keys" if len(pool) > 1 else ""))
            print(f"[gemini] a key was refused ({code}) – skipped, "
                  f"{len(pool) - sum(k in _dead for k in pool)} keys left")
            continue
        if code == 404:
            raise GeminiError(f"Model '{m}' not found – choose another model ({last})")
        if code >= 500:
            time.sleep(3)
            continue
        raise GeminiError(f"Gemini error {code}: {last}")
    raise GeminiError(f"Gemini did not answer: {last}")


def test_key(key: str, model_name: str = "") -> str:
    """'' when the key + model work, else the reason."""
    try:
        text, _ = generate([{"text": "Reply with the single word OK."}], want_json=False,
                           max_tokens=256, key_list=[key], model_name=model_name)
        return "" if text.strip() else "empty answer"
    except Exception as e:
        return str(e)


def list_models(key: str) -> List[str]:
    code, data = _http(f"{API}/models?key={key}&pageSize=200", None, timeout=30)
    if code != 200:
        raise GeminiError(_err_text(data))
    out = []
    for m in data.get("models", []):
        if "generateContent" in (m.get("supportedGenerationMethods") or []):
            out.append(m.get("name", "").replace("models/", ""))
    return sorted((m for m in out if m.startswith("gemini")), reverse=True)


def _json(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except ValueError:
        m = re.search(r"[\[{].*[\]}]", text, re.S)
        if m:
            return json.loads(m.group(0))
        raise


# --------------------------------------------------------------------------- #
# translation
# --------------------------------------------------------------------------- #
_SCRIPT = {"km": r"[ក-៿]", "th": r"[฀-๿]", "lo": r"[຀-໿]",
           "my": r"[က-႟]", "zh": r"[一-鿿]", "ja": r"[぀-ヿ一-鿿]",
           "ko": r"[가-힯]", "vi": r"[A-Za-zÀ-ỹ]", "en": r"[A-Za-z]"}


def right_script(text: str, lang: str) -> bool:
    """A Khmer voice cannot read Chinese: a 'translation' still in the wrong
    script is treated as missing."""
    pat = _SCRIPT.get(lang)
    return bool(text.strip()) and (pat is None or re.search(pat, text) is not None)


def _prompt(lines: List[Tuple[int, str]], src: str, tgt: str, title: str,
            context: List[Tuple[str, str]], names: Dict[str, str],
            after: Optional[List[str]] = None) -> str:
    from .translate import LANGUAGES

    tname = LANGUAGES.get(tgt, (tgt, ""))[0]
    sname = LANGUAGES.get(src, (src, ""))[0] if src and src != "auto" else "the original language"
    ctx = "\n".join(f"- {s}  =>  {t}" for s, t in context) or "(start of the video)"
    nxt = "\n".join(f"- {s}" for s in (after or [])) or "(end of the video)"
    gl = "\n".join(f"- {a} = {b}" for a, b in list(names.items())[:60]) or "(none yet)"
    numbered = "\n".join(f"{i}: {t}" for i, t in lines)
    return f"""You translate the dialogue of a video{f' titled "{title}"' if title else ''} from {sname} into {tname} for DUBBING (an AI voice will speak your lines over the picture).

Rules:
- Natural, spoken {tname} as people really talk in a TV drama - not word-for-word, not formal writing.
- Follow the story: use the earlier lines to understand who speaks to whom; choose kinship terms, pronouns and politeness that fit the relationship.
- Keep every person's name the SAME all through the video (use the name list); write names the way {tname} viewers read them.
- Keep each line about as short as the original so it fits the same time. Do not add explanations.
- Translate every line, one output per input number. Never leave a line in {sname}.

Names so far (ALWAYS use exactly these translations):
{gl}

Earlier lines (original => translation):
{ctx}

The lines that come right after the ones to translate (only to understand the meaning - do NOT translate them):
{nxt}

Translate these lines:
{numbered}

Answer ONLY with JSON: {{"lines": [{{"i": <number>, "t": "<translation>"}}, ...], "names": {{"<original name>": "<name in {tname}>"}}}}"""


def translate_lines(lines: List[str], source: str, target: str,
                    progress: Optional[Progress] = None,
                    should_stop: Optional[Callable[[], bool]] = None,
                    on_result: Optional[Callable[[int, str], None]] = None,
                    title: str = "", batch: int = BATCH_LINES,
                    names: Optional[Dict[str, str]] = None) -> List[str]:
    """Same contract as translate.translate_lines (1:1, on_result as batches
    finish). Lines Gemini leaves out or answers in the wrong script are
    translated by Google Translate at the end (and counted in the report).
    names: the glossary (kept as given); the names Gemini chooses are added
    to this same dict, so the caller can keep them for the next episodes."""
    from .translate import translate_lines as google_lines

    out = [(t or "").strip() for t in lines]
    todo = [i for i, t in enumerate(out) if t]
    result: Dict[int, str] = {}
    names = names if names is not None else {}
    context: List[Tuple[str, str]] = []
    queue: List[List[int]] = [todo[k:k + batch] for k in range(0, len(todo), batch)]
    n = max(1, len(todo))
    while queue:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        ids = queue.pop(0)
        last = todo.index(ids[-1])
        after = [out[i] for i in todo[last + 1:last + 1 + AFTER_LINES]]
        prompt = _prompt([(i + 1, out[i]) for i in ids], source, target, title,
                         context[-CONTEXT_LINES:], names, after)
        text, finish = generate([{"text": prompt}], should_stop=should_stop)
        if finish == "MAX_TOKENS" and len(ids) > 1:     # cut off: halve and ask again
            h = len(ids) // 2
            queue[:0] = [ids[:h], ids[h:]]
            continue
        try:
            data = _json(text)
        except ValueError:
            data = {}
        items = data.get("lines", data) if isinstance(data, dict) else data
        got = {}
        for it in items if isinstance(items, list) else []:
            try:
                i = int(it.get("i")) - 1
            except (TypeError, ValueError, AttributeError):
                continue
            t = str(it.get("t", "")).strip()
            if i in ids and right_script(t, target):
                got[i] = t
        if isinstance(data, dict) and isinstance(data.get("names"), dict):
            for a, b in data["names"].items():
                if isinstance(a, str) and isinstance(b, str) and a.strip() and b.strip():
                    names.setdefault(a.strip(), b.strip())
        missing = [i for i in ids if i not in got]
        if missing and len(missing) < len(ids) and len(ids) > 1:
            queue.insert(0, missing)                    # ask once more for the gaps
        for i, t in got.items():
            result[i] = t
            if on_result:
                on_result(i, t)
        context += [(out[i], got[i]) for i in ids if i in got]
        if progress:
            progress(int(95 * len(result) / n), f"Gemini translated {len(result)}/{len(todo)} lines")
        if missing and (len(missing) == len(ids) or len(ids) == 1):
            result.update({i: "" for i in missing if i not in result})
    rest = [i for i in todo if not result.get(i)]
    if rest:
        if progress:
            progress(96, f"{len(rest)} lines left - Google Translate fills them")
        g = google_lines([out[i] for i in rest], source, target, should_stop=should_stop)
        for i, t in zip(rest, g):
            result[i] = t
            if on_result:
                on_result(i, t)
    final = [result.get(i, out[i]) if out[i] else "" for i in range(len(out))]
    if progress:
        progress(100, f"Translated {len(todo)} lines with Gemini"
                      + (f" ({len(rest)} by Google Translate)" if rest else ""))
    return final


# --------------------------------------------------------------------------- #
# speech-to-text
# --------------------------------------------------------------------------- #
def _wav_b64(audio: np.ndarray, sr: int = 16000) -> str:
    pcm = (np.clip(audio, -1, 1) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _secs(v) -> float:
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    parts = [float(p) for p in s.replace(",", ".").split(":") if p]
    t = 0.0
    for p in parts:
        t = t * 60 + p
    return t


def transcribe_piece(audio: np.ndarray, lang: Optional[str],
                     should_stop: Optional[Callable[[], bool]] = None
                     ) -> Tuple[List[Tuple[float, float, str]], str]:
    """Lines (start, end, text) in seconds from the start of `audio` (16 kHz)
    and the language code Gemini heard."""
    from .translate import LANGUAGES

    dur = len(audio) / 16000.0
    lname = LANGUAGES.get(lang, (lang, ""))[0] if lang else ""
    prompt = (f"Transcribe the speech in this {dur:.1f}-second audio clip from a video "
              f"{'in ' + lname + ' ' if lname else ''}exactly as spoken, in the ORIGINAL "
              "language (do not translate). One item per sentence / subtitle line, with its "
              "start and end time in seconds from the beginning of the clip. Leave out music, "
              "sound effects and noises. If nobody speaks, return an empty list.\n"
              'Answer ONLY with JSON: {"language": "<ISO 639-1 code>", '
              '"lines": [{"start": 0.0, "end": 1.5, "text": "..."}]}')
    text, _ = generate([{"inline_data": {"mime_type": "audio/wav", "data": _wav_b64(audio)}},
                        {"text": prompt}], temperature=0.0, should_stop=should_stop)
    try:
        data = _json(text)
    except ValueError:
        return [], ""
    items = data.get("lines", []) if isinstance(data, dict) else data
    out = []
    for it in items if isinstance(items, list) else []:
        try:
            a, b = _secs(it.get("start", 0)), _secs(it.get("end", 0))
            t = str(it.get("text", "")).strip()
        except (TypeError, ValueError, AttributeError):
            continue
        a, b = max(0.0, min(a, dur)), max(0.0, min(b, dur))
        if t and b > a:
            out.append((a, b, t))
    return out, (data.get("language", "") if isinstance(data, dict) else "")
