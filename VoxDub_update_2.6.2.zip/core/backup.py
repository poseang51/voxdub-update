"""
backup.py - Older copies of a project file (2.1).

Before a project is saved over, the file that was there is copied to a
"backups" folder next to it:  <folder>/backups/<name>_20261019_0712.json.
The newest KEEP copies stay, older ones are removed. The autosave (every
minute) makes a copy at most every AUTOSAVE_EVERY seconds, so the folder
does not fill up with nearly identical files.

File › Open a backup… opens one of them (as unsaved work: Save puts it back).
"""

import glob
import os
import shutil
import time
from typing import List

KEEP = 5
AUTOSAVE_EVERY = 600            # s between two backups of the autosave
FOLDER = "backups"


def folder_for(path: str) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(path)), FOLDER)


def _stem(path: str) -> str:
    name = os.path.basename(path)
    for ext in (".voxdub.json", ".json"):
        if name.lower().endswith(ext):
            return name[:-len(ext)]
    return os.path.splitext(name)[0]


def backups_of(path: str) -> List[str]:
    """The backups of this project, newest first."""
    pat = os.path.join(glob.escape(folder_for(path)), glob.escape(_stem(path)) + "_*.json")
    return sorted(glob.glob(pat), key=os.path.getmtime, reverse=True)


def keep(path: str, min_age: float = 0.0, limit: int = KEEP) -> str:
    """Copy the project file that is about to be overwritten. Returns the
    copy ("" when there was nothing to copy, or the last copy is younger
    than min_age seconds). Never raises: a backup must not stop a save."""
    try:
        if not os.path.isfile(path) or os.path.getsize(path) == 0:
            return ""
        old = backups_of(path)
        if min_age and old and time.time() - os.path.getmtime(old[0]) < min_age:
            return ""
        os.makedirs(folder_for(path), exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S", time.localtime(os.path.getmtime(path)))
        out = os.path.join(folder_for(path), f"{_stem(path)}_{stamp}.json")
        if os.path.exists(out):
            return ""                   # this version is backed up already
        shutil.copy2(path, out)
        for extra in backups_of(path)[limit:]:
            try:
                os.remove(extra)
            except OSError:
                pass
        return out
    except OSError:
        return ""
