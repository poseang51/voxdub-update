"""
voxcpm_worker.py - runs VoxCPM (openbmb, Apache-2.0) for SARIKA VOXDUB PRO.

VoxCPM needs Python 3.10-3.12 + PyTorch + CUDA, so it lives in its OWN
environment (e.g. venv-voxcpm). The app starts this script with that Python
and talks to it with one JSON object per line:

  -> {"cmd": "load", "model": "openbmb/VoxCPM2"}
  <- {"ok": true, "model": "...", "sample_rate": 48000, "device": "cuda"}
  -> {"cmd": "tts", "text": "...", "out": "C:/.../line.wav",
      "ref_wav": "C:/.../male.wav", "ref_text": "...", "steps": 10, "cfg": 2.0}
  <- {"ok": true, "out": "...", "seconds": 2.4}

The model is loaded once and kept for the whole session. The package API has
changed between versions, so every call only passes the arguments that the
installed version accepts.
"""

import inspect
import json
import os
import sys
import time
import traceback

# this file sits in the app's core/ folder (so an update brings it too), next to
# core/voxcpm.py: that folder must not be on the path, or "import voxcpm" would
# load the app's file instead of the VoxCPM package
_HERE = os.path.normcase(os.path.dirname(os.path.abspath(__file__)))
sys.path[:] = [p for p in sys.path
               if os.path.normcase(os.path.abspath(p or os.curdir)) != _HERE]

MODELS = ["openbmb/VoxCPM2", "openbmb/VoxCPM1.5", "openbmb/VoxCPM-0.5B"]
# numpy + voxcpm (+ torch) are all it needs - no soundfile

_model = None
_name = ""
# replies go to the real stdout; anything the libraries print goes to stderr
# so it can never break the one-JSON-per-line protocol
_OUT = sys.stdout
sys.stdout = sys.stderr


def _reply(obj):
    _OUT.write(json.dumps(obj, ensure_ascii=False) + "\n")
    _OUT.flush()


def _sample_rate(m) -> int:
    for obj in (m, getattr(m, "tts_model", None)):
        for attr in ("sample_rate", "sr", "sampling_rate"):
            v = getattr(obj, attr, None) if obj is not None else None
            if isinstance(v, int) and v > 0:
                return v
    return 24000


def _card():
    """(device, card name, (major, minor)) of the GPU torch will use."""
    try:
        import torch

        if torch.cuda.is_available():
            i = torch.cuda.current_device()
            return "cuda", torch.cuda.get_device_name(i), torch.cuda.get_device_capability(i)
    except Exception:
        pass
    return "cpu", "", (0, 0)


def _force_dtype(dtype: str):
    """VoxCPM2 always asks for bfloat16 on CUDA. Cards older than compute
    capability 8.0 (Quadro RTX 4000, RTX 20xx, T4) have no bfloat16 hardware:
    it runs very slowly or fails. Those cards get float16 (the same fix
    Sarika Studio uses)."""
    forced = lambda device, configured: dtype          # noqa: E731
    for name in ("voxcpm.model.utils", "voxcpm.model.voxcpm2", "voxcpm.model.voxcpm"):
        try:
            __import__(name)
            mod = sys.modules[name]
            if hasattr(mod, "pick_runtime_dtype"):
                setattr(mod, "pick_runtime_dtype", forced)
        except Exception:
            pass


def load(name: str = ""):
    global _model, _name
    device, card, cap = _card()
    dtype = ""
    if device == "cuda" and tuple(cap) < (8, 0):
        dtype = "float16"
        _force_dtype(dtype)
    from voxcpm import VoxCPM

    names = [name] if name else MODELS
    last = None
    for n in names:
        try:
            kw = {}
            params = inspect.signature(VoxCPM.from_pretrained).parameters
            if "load_denoiser" in params:
                kw["load_denoiser"] = False
            _model = VoxCPM.from_pretrained(n, **kw)
            _name = n
            break
        except Exception as e:          # try the next (older) model
            last = e
    if _model is None:
        raise RuntimeError(f"could not load VoxCPM: {last}")
    where = f"{card} ({cap[0]}.{cap[1]})" if card else device
    return {"ok": True, "model": _name, "sample_rate": _sample_rate(_model),
            "device": where + (f", {dtype}" if dtype else "")}


def _write_wav(path: str, data, rate: int):
    """16-bit WAV with the standard library (no soundfile needed)."""
    import wave

    import numpy as np

    flat = np.clip(np.asarray(data, dtype=np.float32).reshape(-1), -1.0, 1.0)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(rate))
        w.writeframes((flat * 32767).astype(np.int16).tobytes())


def _seed(n: int):
    """The same random start for every line: the same reference gives the same
    voice, not a new person each time."""
    import random

    random.seed(n)
    try:
        import numpy as np

        np.random.seed(n)
    except Exception:
        pass
    try:
        import torch

        torch.manual_seed(n)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(n)
    except Exception:
        pass


def tts(req: dict):
    import numpy as np

    if _model is None:
        load(req.get("model", ""))
    text = str(req.get("text") or "").strip()
    if not text:
        raise ValueError("there is no text to speak")
    params = inspect.signature(_model.generate).parameters
    kw = {"text": text}
    ref, ref_text = req.get("ref_wav") or "", (req.get("ref_text") or "").strip()
    if ref and os.path.isfile(ref):
        if "reference_wav_path" in params:          # VoxCPM2: the recording alone
            kw["reference_wav_path"] = ref
            if ref_text and req.get("continue") and "prompt_wav_path" in params \
                    and "prompt_text" in params:
                # + the recording with its exact words: the voice stays the
                # same in every line (the recording alone drifts - one line
                # low, the next high like another person)
                kw["prompt_wav_path"], kw["prompt_text"] = ref, ref_text
        else:                                       # VoxCPM 1.x: recording + its words
            for k in ("prompt_wav_path", "ref_wav_path", "prompt_audio"):
                if k in params:
                    kw[k] = ref
                    break
            for k in ("prompt_text", "reference_text", "ref_text"):
                if k in params and ref_text:
                    kw[k] = ref_text
                    break
    for k, v in (("cfg_value", float(req.get("cfg", 2.0))),
                 ("inference_timesteps", int(req.get("steps", 10)))):
        if k in params:
            kw[k] = v
    _seed(int(req.get("seed", 1234)))
    t0 = time.time()
    wav = _model.generate(**kw)
    sr = _sample_rate(_model)
    if isinstance(wav, (tuple, list)) and len(wav) == 2 and isinstance(wav[1], int):
        wav, sr = wav
    if hasattr(wav, "detach"):
        wav = wav.detach().float().cpu().numpy()
    data = np.asarray(wav, dtype="float32").reshape(-1)
    if data.size == 0:
        raise RuntimeError("VoxCPM produced no audio")
    _write_wav(req["out"], data, sr)
    return {"ok": True, "out": req["out"], "seconds": round(time.time() - t0, 2)}


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            cmd = req.get("cmd", "tts")
            if cmd == "load":
                _reply(load(req.get("model", "")))
            elif cmd == "ping":
                _reply({"ok": True})
            elif cmd == "quit":
                _reply({"ok": True})
                break
            else:
                _reply(tts(req))
        except Exception as e:
            _reply({"ok": False, "error": f"{type(e).__name__}: {e}",
                    "trace": traceback.format_exc()[-1500:]})


if __name__ == "__main__":
    main()
