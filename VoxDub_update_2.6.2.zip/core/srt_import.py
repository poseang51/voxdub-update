"""
srt_import.py - Import SRT: lines from a subtitle file become the lines of the
project (no transcription needed).

Khmer subtitles are the Khmer text of the lines (ready for the AI voice);
subtitles in another language are the original text (then Translate).
"""

import re
from typing import List, Tuple

from .project import Project, Segment, new_id

_TIME = re.compile(r"(\d+):(\d{1,2}):(\d{1,2})[,.](\d{1,3})")


def _sec(m) -> float:
    h, mi, s, ms = m.groups()
    return int(h) * 3600 + int(mi) * 60 + int(s) + int(ms.ljust(3, "0")) / 1000.0


def read_srt(path: str) -> List[Tuple[float, float, str]]:
    """[(start, end, text)] of an .srt file (UTF-8 / UTF-8 BOM / UTF-16 / cp1252)."""
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-16", "cp1252"):
        try:
            text = raw.decode(enc)
            if enc == "utf-16" and "-->" not in text:
                continue
            break
        except UnicodeError:
            continue
    else:
        text = raw.decode("utf-8", "replace")
    out = []
    for block in re.split(r"\r?\n\s*\r?\n", text.replace("\r\n", "\n").strip()):
        lines = [x for x in block.split("\n") if x.strip()]
        for i, ln in enumerate(lines):
            if "-->" in ln:
                a, b = ln.split("-->", 1)
                ma, mb = _TIME.search(a), _TIME.search(b)
                if not ma or not mb:
                    break
                body = " ".join(x.strip() for x in lines[i + 1:])
                body = re.sub(r"<[^>]+>|\{[^}]*\}", "", body).strip()   # <i>, {\an8}
                start, end = _sec(ma), _sec(mb)
                if body and end > start:
                    out.append((start, end, body))
                break
    out.sort(key=lambda x: x[0])
    return out


def import_into(project: Project, path: str) -> int:
    """Replace the project's lines with the file's. Returns how many."""
    from .sync import build_subtitles
    from .voxcpm import is_khmer

    rows = read_srt(path)
    if not rows:
        raise ValueError("No subtitles were found in this file.")
    khmer = sum(is_khmer(t) for _a, _b, t in rows) > len(rows) / 2
    segs = []
    for a, b, t in rows:
        s = Segment(id=new_id(), start=round(a, 3), end=round(b, 3), text=t)
        if khmer:
            s.translation = t
        segs.append(s)
    project.segments = segs
    project.audio_clips = [c for c in project.audio_clips if not c.seg_id]
    if khmer:
        project.target_lang = "km"
    dur = project.video_duration or rows[-1][1]
    project.transcribe_done = True
    project.transcribed_until = dur
    build_subtitles(project, use_translation=khmer)
    return len(segs)
