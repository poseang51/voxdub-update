"""
gender_ai.py - "Is this voice a man or a woman?" with an AI model.

Pitch alone (core/gender.py) is fooled by a woman with a low voice, a young
man with a high one, shouting, crying and loud music. This listens to the
whole sound of the voice instead:

  Model   prithivMLmods/Common-Voice-Gender-Detection (Hugging Face,
          Apache-2.0) - wav2vec2-base fine-tuned on Mozilla Common Voice,
          98.5 % on its test set (clean speech; drama with music is lower).
          The int8 ONNX export (~95 MB) runs on onnxruntime, which the app
          already ships for OCR - no PyTorch needed. Downloaded once, the
          first time it is needed, into <data dir>/models/.
  Input   16 kHz mono, normalised to zero mean / unit variance (the model's
          Wav2Vec2FeatureExtractor, do_normalize=true).
  Output  logits for [female, male].

Used per CHARACTER (core/speakers.py): the longest lines of a character are
judged together, so one shouted line cannot turn a man into a woman. The
answer comes with a confidence; below CONFIDENT the pitch helps decide.
Setting "gender_ai" = False goes back to pitch only.
"""

import os
from typing import Callable, List, Optional, Sequence, Tuple

import numpy as np

from . import settings
from .media import data_dir

SR = 16000
REPO = "prithivMLmods/Common-Voice-Gender-Detection-ONNX"
MODEL_NAME = "gender_wav2vec2_int8.onnx"
MODEL_URL = f"https://huggingface.co/{REPO}/resolve/main/onnx/model_int8.onnx"
MODEL_MIN_BYTES = 80_000_000
SETTING = "gender_ai"
MAX_SECONDS = 8.0          # longer lines are cut (enough to hear a voice, keeps it fast)
MIN_SECONDS = 0.6          # shorter lines say too little
LINES_PER_CHARACTER = 6    # the longest lines of a character that are judged
CONFIDENT = 0.70           # below: the pitch decides together with the model

_session = None


def enabled() -> bool:
    return bool(settings.get(SETTING, True))


def model_path() -> str:
    return os.path.join(data_dir(), "models", MODEL_NAME)


def model_ready() -> bool:
    p = model_path()
    return os.path.isfile(p) and os.path.getsize(p) >= MODEL_MIN_BYTES


def available() -> bool:
    try:
        import onnxruntime  # noqa: F401
    except ImportError:
        return False
    return True


def download_model(progress: Optional[Callable[[int, str], None]] = None,
                   should_stop: Optional[Callable[[], bool]] = None) -> str:
    """Download the model once (~95 MB)."""
    path = model_path()
    if model_ready():
        return path
    import requests

    os.makedirs(os.path.dirname(path), exist_ok=True)
    part = path + ".part"
    try:
        with requests.get(MODEL_URL, stream=True, timeout=60) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0)) or 100_000_000
            got = 0
            with open(part, "wb") as f:
                for block in r.iter_content(1 << 20):
                    if should_stop and should_stop():
                        raise InterruptedError("Cancelled")
                    f.write(block)
                    got += len(block)
                    if progress:
                        progress(min(99, got * 100 // total),
                                 f"Downloading the AI gender model {got >> 20}/{total >> 20} MB "
                                 "(first time only)...")
    except InterruptedError:
        raise
    except Exception as e:
        raise RuntimeError(f"Could not download the AI gender model ({e}).") from e
    finally:
        if os.path.isfile(part) and os.path.getsize(part) < MODEL_MIN_BYTES:
            try:
                os.remove(part)
            except OSError:
                pass
    os.replace(part, path)
    return path


def _get_session():
    global _session
    if _session is None:
        import onnxruntime as ort

        opts = ort.SessionOptions()
        opts.log_severity_level = 3
        _session = ort.InferenceSession(model_path(), opts, providers=["CPUExecutionProvider"])
    return _session


def prepare(x: np.ndarray) -> np.ndarray:
    """What the model's feature extractor does: mono float, zero mean, unit variance."""
    x = np.asarray(x, dtype=np.float32).reshape(-1)[:int(MAX_SECONDS * SR)]
    return ((x - x.mean()) / np.sqrt(x.var() + 1e-7)).astype(np.float32)


def p_female(x: np.ndarray) -> Optional[float]:
    """Probability (0..1) that the voice in x (16 kHz mono) is a woman's."""
    if x is None or len(x) < int(MIN_SECONDS * SR):
        return None
    sess = _get_session()
    name = sess.get_inputs()[0].name
    logits = np.asarray(sess.run(None, {name: prepare(x)[None, :]})[0], dtype=np.float64)
    logits = logits.reshape(-1)[:2]
    e = np.exp(logits - logits.max())
    return float(e[0] / e.sum())


def judge(audio: np.ndarray, spans: Sequence[Tuple[float, float]],
          should_stop: Optional[Callable[[], bool]] = None) -> Optional[float]:
    """Average p_female over the longest of these lines (a character)."""
    best = sorted(spans, key=lambda ab: -(ab[1] - ab[0]))[:LINES_PER_CHARACTER]
    ps: List[float] = []
    weights: List[float] = []
    for a, b in best:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        p = p_female(audio[int(a * SR):int(b * SR)])
        if p is not None:
            ps.append(p)
            weights.append(min(MAX_SECONDS, b - a))
    if not ps:
        return None
    return float(np.average(ps, weights=weights))


def decide(p: Optional[float], f0: float, split_hz: float = 165.0) -> Tuple[str, int, str]:
    """(gender, confidence %, source) from the model's p_female and the pitch.
    The model decides when it is sure; when it is not, the pitch has a say."""
    by_pitch = "female" if f0 >= split_hz else "male"
    if p is None:
        return by_pitch, 0, "pitch"
    g = "female" if p >= 0.5 else "male"
    conf = max(p, 1.0 - p)
    if conf < CONFIDENT and f0:
        # unsure: lean on the pitch when it is clear (far from the split)
        if abs(f0 - split_hz) >= 25:
            return by_pitch, int(round(conf * 100)), "ai+pitch"
    return g, int(round(conf * 100)), "ai"


def ensure(progress: Optional[Callable[[int, str], None]] = None,
           should_stop: Optional[Callable[[], bool]] = None) -> bool:
    """True when the model can be used now (downloads it the first time).
    Never raises for a missing model / no internet - pitch is used then."""
    if not enabled() or not available():
        return False
    try:
        download_model(progress, should_stop)
        _get_session()
        return True
    except InterruptedError:
        raise
    except Exception as e:
        print(f"[gender_ai] not used: {e}")
        return False
