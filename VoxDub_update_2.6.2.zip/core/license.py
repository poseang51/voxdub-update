"""
license.py - Offline license keys for selling SARIKA VOXDUB PRO by the month.

How it works
  * You (the seller) keep a PRIVATE key on your own PC (made once with
    `python tools/license_admin.py init`). It never ships with the app.
  * The app contains only the matching PUBLIC key (core/license_pub.py).
  * A customer sends you their Machine ID (shown in Help > License).
    You run `python tools/license_admin.py issue ...` and send back a key
    like  VXD1-eyJu....Qk3g . It is signed (Ed25519), so it cannot be edited
    or made up, it only works on that PC, and it stops on the expiry date.
  * To renew for another month, issue a new key with a later date.

Without a valid key the built .exe still works, but exported videos get a
"SARIKA VOXDUB PRO · Trial" watermark and the AI voice (.wav) / subtitle (.srt)
files cannot be saved on their own. Run from the source code (the seller's
own PC) there is no trial (TRIAL_ENABLED follows the build).

Keys for "any PC" (machine *) are refused by the built .exe, and turning the
Windows clock back does not make an expired key work again.

Note: a Python app can be modified by a determined person. The .exe makes
that harder, not impossible.
"""

import base64
import datetime as dt
import hashlib
import json
import sys
import uuid
from dataclasses import dataclass
from typing import Optional

from . import settings

KEY_PREFIX = "VXD1-"
TRIAL_WATERMARK = "SARIKA VOXDUB PRO · Trial"
# the built .exe has the trial (watermark until a key is entered); running the
# source code (the seller's own PC) does not
TRIAL_ENABLED = bool(getattr(sys, "frozen", False))
PLANS = {"basic": "Basic", "pro": "Pro", "owner": "Admin"}
OWNER_UNTIL = dt.date(2099, 12, 31)


def _b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def _b64d(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


# --------------------------------------------------------------------------- #
# Machine ID
# --------------------------------------------------------------------------- #
def _raw_machine_id() -> str:
    if sys.platform == "win32":
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                r"SOFTWARE\Microsoft\Cryptography",
                                0, winreg.KEY_READ | winreg.KEY_WOW64_64KEY) as k:
                return str(winreg.QueryValueEx(k, "MachineGuid")[0])
        except OSError:
            pass
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            with open(path, "r", encoding="ascii") as f:
                value = f.read().strip()
                if value:
                    return value
        except OSError:
            pass
    return str(uuid.getnode())


def machine_id() -> str:
    """Short, stable ID of this PC, e.g. '4F2A-9C1D-77B0-E3A5'."""
    h = hashlib.sha256(("voxdub-pro:" + _raw_machine_id()).encode()).hexdigest()[:16].upper()
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


# --------------------------------------------------------------------------- #
# Verify
# --------------------------------------------------------------------------- #
@dataclass
class LicenseInfo:
    valid: bool
    reason: str = ""
    name: str = ""
    plan: str = ""
    expires: Optional[dt.date] = None
    machine: str = ""
    issued: Optional[dt.date] = None

    @property
    def total_days(self) -> int:
        """Days from the key's start to its end (0 = unknown)."""
        if not (self.expires and self.issued):
            return 0
        return max(0, (self.expires - self.issued).days)

    @property
    def days_left(self) -> int:
        if not self.expires:
            return 0
        return (self.expires - dt.date.today()).days

    def summary(self) -> str:
        if self.valid and self.plan == "owner":
            return "Admin – this is the seller's PC (makes the keys), no license needed"
        if self.valid:
            return (f"{PLANS.get(self.plan, self.plan)} · {self.name} · "
                    f"until {self.expires.isoformat()} ({self.days_left} days left)")
        return self.reason


def public_key() -> Optional[bytes]:
    try:
        from .license_pub import PUBLIC_KEY_B64
    except ImportError:
        return None
    return _b64d(PUBLIC_KEY_B64) if PUBLIC_KEY_B64 else None


def verify(key: str, mid: Optional[str] = None, today: Optional[dt.date] = None,
           pub: Optional[bytes] = None) -> LicenseInfo:
    """Check a license key. Never raises."""
    key = (key or "").strip().replace("\n", "").replace(" ", "")
    if not key:
        return LicenseInfo(False, "No license key")
    if not key.startswith(KEY_PREFIX) or "." not in key:
        return LicenseInfo(False, "This is not a SARIKA VOXDUB PRO license key")
    pub = pub if pub is not None else public_key()
    if not pub:
        return LicenseInfo(False, "This copy of SARIKA VOXDUB PRO has no license public key "
                                  "(run tools/license_admin.py init)")
    body, sig = key[len(KEY_PREFIX):].split(".", 1)
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

        Ed25519PublicKey.from_public_bytes(pub).verify(_b64d(sig), body.encode())
        data = json.loads(_b64d(body))
    except Exception:
        return LicenseInfo(False, "Invalid license key (damaged or not issued by us)")
    try:
        expires = dt.date.fromisoformat(data["exp"])
    except (KeyError, ValueError):
        return LicenseInfo(False, "Invalid license key (no expiry date)")
    try:
        issued = dt.date.fromisoformat(data.get("iss", ""))
    except (TypeError, ValueError):
        issued = None
    info = LicenseInfo(True, "", data.get("name", ""), data.get("plan", "pro"),
                       expires, data.get("mid", ""), issued)
    mid = mid or machine_id()
    if info.machine == "*" and getattr(sys, "frozen", False):
        info.valid, info.reason = False, "This key is not for this computer - ask for a new key"
    elif info.machine not in ("*", mid):
        info.valid, info.reason = False, (f"This key is for another computer "
                                          f"({info.machine}); this PC is {mid}")
    elif (today or dt.date.today()) > expires:
        info.valid, info.reason = False, f"License expired on {expires.isoformat()} - renew it"
    return info


def sign(payload: dict, private_key_bytes: bytes) -> str:
    """Make a key (used by tools/license_admin.py)."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    body = _b64e(json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode())
    sig = Ed25519PrivateKey.from_private_bytes(private_key_bytes).sign(body.encode())
    return KEY_PREFIX + body + "." + _b64e(sig)


# --------------------------------------------------------------------------- #
# The key stored on this PC
# --------------------------------------------------------------------------- #
def stored_key() -> str:
    return settings.get("license_key", "") or ""


def _today() -> dt.date:
    """Today, but never earlier than the latest day this PC has seen (turning
    the clock back must not revive an expired key)."""
    today = dt.date.today()
    try:
        seen = dt.date.fromisoformat(settings.get("lic_seen", "") or "1970-01-01")
    except ValueError:
        seen = dt.date(1970, 1, 1)
    if today > seen:
        try:
            settings.set("lic_seen", today.isoformat())
        except OSError:
            pass
        return today
    return seen


def owner_info() -> Optional[LicenseInfo]:
    """The seller's own PC (it holds the signing key): always licensed."""
    try:
        from . import admin

        if admin.is_owner():
            return LicenseInfo(True, "", "Admin (seller's PC)", "owner", OWNER_UNTIL,
                               machine_id())
    except Exception:
        pass
    return None


def current() -> LicenseInfo:
    return owner_info() or verify(stored_key(), today=_today())


def restricted() -> bool:
    """Trial (no valid key): watermark + no separate voice / subtitle files."""
    return TRIAL_ENABLED and not current().valid


def activate(key: str) -> LicenseInfo:
    """Check and save a key. Returns the result (saved only when valid)."""
    before = current()
    info = verify(key, today=_today())
    if info.valid:
        settings.set("license_key", key.strip())
        renewed = before.valid and before.expires and info.expires and \
            info.expires > before.expires
        add_history("Licence renewed" if renewed else "Licence activated",
                    f"until {info.expires.isoformat()}" if info.expires else "")
    return info


def add_history(event: str, detail: str = "") -> None:
    """What happened to the licence on this PC (Plan & licence › Recent activity)."""
    lst = history()
    if lst and lst[0].get("event") == event and lst[0].get("detail") == detail:
        return
    lst.insert(0, {"event": event, "detail": detail,
                   "time": dt.datetime.now().strftime("%Y-%m-%d %H:%M")})
    settings.set("lic_history", lst[:30])


def history() -> list:
    return [h for h in (settings.get("lic_history", []) or []) if isinstance(h, dict)]


def reminder_due(info: Optional[LicenseInfo] = None) -> int:
    """7, 3 or 1 (the last day) when the "renew soon" message should show now
    (once each), else 0."""
    info = info or current()
    if not info.valid or info.plan == "owner" or not info.expires:
        return 0
    d = info.days_left
    if d > 7:
        return 0
    step = 1 if d <= 1 else 3 if d <= 3 else 7
    mark = f"{info.expires.isoformat()}:{step}"
    if settings.get("lic_reminded", "") == mark:
        return 0
    settings.set("lic_reminded", mark)
    return step


def watermark_text() -> str:
    """Text to burn into exports ("" when licensed)."""
    if not TRIAL_ENABLED:
        return ""
    return "" if current().valid else TRIAL_WATERMARK

