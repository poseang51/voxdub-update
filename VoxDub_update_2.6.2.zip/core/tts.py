"""
tts.py - Text-to-speech.

Engines
  * edge  : Microsoft Edge neural voices via the free "edge-tts" package
            (natural voices, includes Khmer Piseth / Sreymom). Needs internet.
  * gtts  : Google Text-to-Speech ("gTTS"). One voice per language. Needs internet.
  * azure : Microsoft Azure Speech with YOUR OWN key (official, paid API with a
            free tier). Same neural voices as Edge, but licensed for
            commercial use and not blocked. Set the key in the app
            (AI Voice -> Azure key); it is stored in the user's settings,
            never in a project file.

Voice "auto" picks the male or female voice of the language for each line,
from the speaker's pitch in the original audio (see core/gender.py).

Every generated voice is converted to a mono 44.1 kHz WAV so the timeline,
waveform and mixer can all work with one simple format.
"""

import asyncio
import os
from typing import Callable, Dict, List, Optional, Tuple

from .media import convert_to_wav

TTS_ENGINES = {
    "edge": "Edge Neural (free)",
    "azure": "Azure Speech (your key)",
    "gtts": "Google TTS (simple)",
    "voxcpm": "VoxCPM2 – voice clone (local GPU)",
}

AUTO_VOICE = "auto"

AZURE_REGIONS = [
    "southeastasia", "eastasia", "japaneast", "koreacentral", "centralindia",
    "australiaeast", "eastus", "westus2", "westeurope", "northeurope", "uksouth",
]

# set by the UI from the user's settings (never saved in a project)
_azure = {"key": "", "region": "southeastasia"}


class FatalTTSError(RuntimeError):
    """An error that will not go away by retrying (wrong key, no quota...)."""


def configure_azure(key: str, region: str):
    _azure["key"] = (key or "").strip()
    _azure["region"] = (region or "southeastasia").strip()


def azure_configured() -> bool:
    return bool(_azure["key"])

# language -> list of (voice id, label)
EDGE_VOICES: Dict[str, List[Tuple[str, str]]] = {
    "km": [("km-KH-PisethNeural", "Piseth (Male)"), ("km-KH-SreymomNeural", "Sreymom (Female)")],
    "en": [("en-US-GuyNeural", "Guy US (Male)"), ("en-US-JennyNeural", "Jenny US (Female)"),
           ("en-US-AriaNeural", "Aria US (Female)"), ("en-GB-RyanNeural", "Ryan UK (Male)"),
           ("en-GB-SoniaNeural", "Sonia UK (Female)")],
    "zh": [("zh-CN-YunxiNeural", "Yunxi (Male)"), ("zh-CN-XiaoxiaoNeural", "Xiaoxiao (Female)")],
    "ja": [("ja-JP-KeitaNeural", "Keita (Male)"), ("ja-JP-NanamiNeural", "Nanami (Female)")],
    "ko": [("ko-KR-InJoonNeural", "InJoon (Male)"), ("ko-KR-SunHiNeural", "SunHi (Female)")],
    "th": [("th-TH-NiwatNeural", "Niwat (Male)"), ("th-TH-PremwadeeNeural", "Premwadee (Female)")],
    "vi": [("vi-VN-NamMinhNeural", "NamMinh (Male)"), ("vi-VN-HoaiMyNeural", "HoaiMy (Female)")],
    "lo": [("lo-LA-ChanthavongNeural", "Chanthavong (Male)"), ("lo-LA-KeomanyNeural", "Keomany (Female)")],
    "my": [("my-MM-ThihaNeural", "Thiha (Male)"), ("my-MM-NilarNeural", "Nilar (Female)")],
    "ms": [("ms-MY-OsmanNeural", "Osman (Male)"), ("ms-MY-YasminNeural", "Yasmin (Female)")],
    "id": [("id-ID-ArdiNeural", "Ardi (Male)"), ("id-ID-GadisNeural", "Gadis (Female)")],
    "tl": [("fil-PH-AngeloNeural", "Angelo (Male)"), ("fil-PH-BlessicaNeural", "Blessica (Female)")],
    "hi": [("hi-IN-MadhurNeural", "Madhur (Male)"), ("hi-IN-SwaraNeural", "Swara (Female)")],
    "ar": [("ar-SA-HamedNeural", "Hamed (Male)"), ("ar-SA-ZariyahNeural", "Zariyah (Female)")],
    "fr": [("fr-FR-HenriNeural", "Henri (Male)"), ("fr-FR-DeniseNeural", "Denise (Female)")],
    "de": [("de-DE-ConradNeural", "Conrad (Male)"), ("de-DE-KatjaNeural", "Katja (Female)")],
    "es": [("es-ES-AlvaroNeural", "Alvaro (Male)"), ("es-ES-ElviraNeural", "Elvira (Female)")],
    "pt": [("pt-BR-AntonioNeural", "Antonio (Male)"), ("pt-BR-FranciscaNeural", "Francisca (Female)")],
    "it": [("it-IT-DiegoNeural", "Diego (Male)"), ("it-IT-ElsaNeural", "Elsa (Female)")],
    "ru": [("ru-RU-DmitryNeural", "Dmitry (Male)"), ("ru-RU-SvetlanaNeural", "Svetlana (Female)")],
    "tr": [("tr-TR-AhmetNeural", "Ahmet (Male)"), ("tr-TR-EmelNeural", "Emel (Female)")],
}

GTTS_LANG = {"zh": "zh-CN", "tl": "tl"}


def voices_for(engine: str, lang: str, with_auto: bool = True) -> List[Tuple[str, str]]:
    """Voices available for a language and engine (Edge and Azure share the
    same neural voice names). "auto" = male/female chosen per line."""
    if engine in ("edge", "azure"):
        voices = EDGE_VOICES.get(lang, EDGE_VOICES["en"])
        if with_auto:
            return [(AUTO_VOICE, "Auto (Male / Female per line)")] + voices
        return voices
    if engine == "voxcpm":
        from .voxcpm import VOICES

        return ([(AUTO_VOICE, "Auto (cloned Male / Female per line)")] if with_auto else []) \
            + list(VOICES)
    return [(f"gtts-{lang}", f"Google voice ({lang})")]


def voice_for_gender(engine: str, lang: str, gender: str) -> str:
    """The first male / female voice of a language ("" when none)."""
    want = "(Female)" if gender == "female" else "(Male)"
    voices = voices_for(engine, lang, with_auto=False)
    for vid, label in voices:
        if want in label:
            return vid
    return voices[0][0] if voices else ""


def _xml(text: str) -> str:
    return (text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&apos;"))


def _azure_save(text: str, voice: str, out_path: str, rate_percent: int, pitch: str = ""):
    """Azure Speech REST API -> 24 kHz mono WAV at out_path."""
    import requests

    if not _azure["key"]:
        raise FatalTTSError("No Azure Speech key set - open AI Voice > Azure key.")
    lang = "-".join(voice.split("-")[:2]) or "en-US"
    ssml = (f"<speak version='1.0' xml:lang='{lang}'><voice name='{voice}'>"
            f"<prosody rate='{rate_percent:+d}%'" + (f" pitch='{pitch}'" if pitch else "")
            + f">{_xml(text)}</prosody></voice></speak>")
    url = f"https://{_azure['region']}.tts.speech.microsoft.com/cognitiveservices/v1"
    r = requests.post(url, data=ssml.encode("utf-8"), timeout=60, headers={
        "Ocp-Apim-Subscription-Key": _azure["key"],
        "Content-Type": "application/ssml+xml",
        "X-Microsoft-OutputFormat": "riff-24khz-16bit-mono-pcm",
        "User-Agent": "VoxDubPRO",
    })
    if r.status_code in (401, 403):
        raise FatalTTSError("Azure rejected the key (401/403) - check the key and the "
                            "region it was created in.")
    if r.status_code == 429:
        import time
        wait = float(r.headers.get("Retry-After", "3") or 3)
        time.sleep(min(30.0, max(1.0, wait)))
        raise RuntimeError("Azure: too many requests (429) - the free F0 tier allows "
                           "about 20 requests per minute")
    if r.status_code == 400:
        raise RuntimeError(f"Azure: bad request (voice '{voice}' not in this region?)")
    r.raise_for_status()
    if len(r.content) < 200:
        raise RuntimeError("Azure returned no audio")
    with open(out_path, "wb") as f:
        f.write(r.content)


def test_azure(key: str, region: str, voice: str = "km-KH-PisethNeural") -> str:
    """Try a key: returns "" if it works, else a readable error."""
    import tempfile

    old = dict(_azure)
    configure_azure(key, region)
    out = os.path.join(tempfile.gettempdir(), "voxdub_azure_test.wav")
    try:
        _azure_save("សួស្តី", voice, out, 0)
        return ""
    except Exception as e:
        return str(e)
    finally:
        _azure.update(old)


# How a line is said (Translation table > Delivery). Edge / Azure Khmer voices
# have no speaking styles, so a delivery is a change of pitch (Hz) and speed (%).
DELIVERY = {
    "normal": (0, 0),
    "happy": (12, 5),
    "excited": (20, 12),
    "gentle": (-4, -8),
    "sad": (-12, -12),
    "angry": (6, 10),
    "question": (10, 0),
    "shout": (16, 6),
    "calm": (-6, -5),
}
PACE = {"normal": 0, "fast": 12, "slow": -10}


def with_delivery(voice: str, engine: str, delivery: str = "normal",
                  pace: str = "normal") -> str:
    """Add the line's delivery / speed to a voice spec (Edge / Azure only):
    'km-KH-SreymomNeural|pitch=+10Hz' + happy -> '...|pitch=+22Hz|rate=+5%'."""
    if engine not in ("edge", "azure") or not voice or voice.startswith("voxcpm-ref:"):
        return voice
    dp, dr = DELIVERY.get(delivery or "normal", (0, 0))
    dr += PACE.get(pace or "normal", 0)
    if not dp and not dr:
        return voice
    base, opts = split_voice(voice)
    try:
        pitch = int(opts.get("pitch", "0Hz").replace("Hz", "") or 0) + dp
        rate = int(opts.get("rate", "0%").replace("%", "") or 0) + dr
    except ValueError:
        return voice
    out = base
    if pitch:
        out += f"|pitch={pitch:+d}Hz"
    if rate:
        out += f"|rate={rate:+d}%"
    return out


def split_voice(voice: str) -> Tuple[str, Dict[str, str]]:
    """'km-KH-PisethNeural|pitch=-10Hz' -> ('km-KH-PisethNeural', {'pitch': '-10Hz'}).
    A character's voice carries its own pitch (see core/speakers.py)."""
    if voice.startswith("voxcpm-ref:") or "|" not in (voice or ""):
        return voice, {}
    base, *rest = voice.split("|")
    opts = {}
    for part in rest:
        k, _, v = part.partition("=")
        if k.strip():
            opts[k.strip()] = v.strip()
    return base, opts


def voice_label(voice: str) -> str:
    """Short readable name of a voice spec (for tables)."""
    base, opts = split_voice(voice or "")
    if base.startswith("voxcpm-ref:"):
        return "Clone: " + os.path.splitext(os.path.basename(base[11:]))[0]
    for vs in EDGE_VOICES.values():
        for vid, label in vs:
            if vid == base:
                base = label
    from .voxcpm import VOICES as VX
    base = dict(VX).get(base, base)
    return base + (f" {opts['pitch']}" if opts.get("pitch") else "")


async def _edge_save(text: str, voice: str, out_mp3: str, rate: str, pitch: str = "+0Hz"):
    import edge_tts

    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(out_mp3)


def _trim_silence(wav_path: str, threshold: float = 0.01, pad: float = 0.04) -> None:
    """Cut the silence TTS engines put before/after speech, so the voice
    fits its time slot without being sped up more than needed."""
    import numpy as np
    from .media import read_wav, write_wav

    data, sr = read_wav(wav_path)
    loud = np.flatnonzero(np.abs(data) > threshold)
    if len(loud) == 0:
        return
    a = max(0, loud[0] - int(pad * sr))
    b = min(len(data), loud[-1] + int(pad * sr))
    if a > 0 or b < len(data):
        write_wav(wav_path, data[a:b], sr)


def synthesize(
    text: str,
    out_wav: str,
    engine: str = "edge",
    voice: str = "km-KH-PisethNeural",
    lang: str = "km",
    rate_percent: int = 0,
    retries: int = 3,
) -> str:
    """Generate speech for `text` and save it as a WAV file."""
    text = (text or "").strip()
    if not text:
        raise ValueError("Empty text cannot be spoken")
    os.makedirs(os.path.dirname(out_wav) or ".", exist_ok=True)
    tmp_mp3 = os.path.splitext(out_wav)[0] + "_raw.mp3"

    voice, opts = split_voice(voice)
    pitch = opts.get("pitch", "")
    try:            # the line's delivery / speed (with_delivery)
        rate_percent += int(opts.get("rate", "0%").replace("%", "") or 0)
    except ValueError:
        pass
    last_err = None
    for attempt in range(retries):
        try:
            if engine == "edge":
                rate = f"{rate_percent:+d}%"
                asyncio.run(_edge_save(text, voice, tmp_mp3, rate, pitch or "+0Hz"))
            elif engine == "azure":
                _azure_save(text, voice, tmp_mp3, rate_percent, pitch)     # (it is a wav)
            elif engine == "voxcpm":
                from . import voxcpm

                tmp_mp3 = os.path.splitext(out_wav)[0] + "_raw.wav"
                try:
                    voxcpm.synthesize(text, tmp_mp3, voice)
                except voxcpm.VoxCPMError as e:
                    if "not set up" in str(e) or "not found" in str(e):
                        raise FatalTTSError(str(e))      # retrying cannot help
                    raise
            elif engine == "gtts":
                from gtts import gTTS

                gTTS(text=text, lang=GTTS_LANG.get(lang, lang)).save(tmp_mp3)
            else:
                raise ValueError(f"Unknown TTS engine: {engine}")
            if not os.path.isfile(tmp_mp3) or os.path.getsize(tmp_mp3) < 200:
                raise RuntimeError("TTS returned no audio")
            convert_to_wav(tmp_mp3, out_wav, 44100)
            _trim_silence(out_wav)
            try:
                os.remove(tmp_mp3)
            except OSError:
                pass
            return out_wav
        except FatalTTSError:
            raise
        except Exception as e:
            last_err = e
            import time
            time.sleep([1, 3, 6, 12][min(attempt, 3)])
    raise RuntimeError(f"Voice generation failed: {last_err}")


class TooManyFailures(RuntimeError):
    """Many lines in a row failed - the internet is down or the service is
    blocking us. Stop instead of failing every remaining line."""


def synthesize_many(
    items: List[Tuple[str, str]],
    engine: str,
    voice: str,
    lang: str,
    progress: Optional[Callable[[int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
    rates: Optional[List[int]] = None,
    max_failures_in_a_row: int = 12,
    on_result: Optional[Callable[[int, str], None]] = None,
    voices: Optional[List[str]] = None,
) -> List[str]:
    """items = [(text, out_wav), ...]. Returns list of wav paths (same order);
    rates = optional speaking-rate percent per item (Edge only);
    a line whose voice could not be generated gets "" so one bad line does
    not throw away the rest.

    Runs 4 requests in parallel to make long videos much faster.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed

    out: List[Optional[str]] = [None] * len(items)
    n = max(1, len(items))
    done = 0
    in_a_row = 0
    last_err = ""
    fatal: List[str] = []

    def one(i, text, path):
        # after a fatal error (wrong key...) the queued lines stop at once
        if fatal:
            raise FatalTTSError(fatal[0])
        try:
            return synthesize(text, path, engine, voices[i] if voices else voice, lang,
                              rates[i] if rates else 0)
        except FatalTTSError as e:
            fatal.append(str(e))
            raise

    # VoxCPM runs on the local GPU one line at a time (the sidecar is serial)
    with ThreadPoolExecutor(max_workers=1 if engine == "voxcpm" else 4) as pool:
        futures = {pool.submit(one, i, text, path): i for i, (text, path) in enumerate(items)}
        try:
            for fut in as_completed(futures):
                if should_stop and should_stop():
                    raise InterruptedError("Cancelled")
                i = futures[fut]
                try:
                    out[i] = fut.result()
                    in_a_row = 0
                except FatalTTSError:
                    raise
                except Exception as e:
                    print(f"[tts] line {i + 1} failed: {e}")
                    out[i] = ""
                    in_a_row += 1
                    last_err = str(e)
                    if in_a_row >= max_failures_in_a_row:
                        raise TooManyFailures(
                            f"{in_a_row} voice lines failed in a row ({last_err[:150]}). "
                            "Check the internet connection. Finished lines are kept - "
                            "run the step again to continue.")
                done += 1
                if progress:
                    progress(int(done * 100 / n), f"Voice {done}/{len(items)} generated")
                if on_result and out[i]:
                    on_result(i, out[i])
        except BaseException:
            for f in futures:
                f.cancel()
            raise
    return [p or "" for p in out]
