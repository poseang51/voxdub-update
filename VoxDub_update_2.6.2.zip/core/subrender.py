"""
subrender.py - burn the subtitles as pictures drawn by Qt.

libass (inside ffmpeg) needs HarfBuzz to put Khmer letters together; the
ffmpeg that ships with the app (imageio-ffmpeg) has no HarfBuzz, so Khmer
subtitles came out broken (ប្រ -> ប្‌រ ...). Qt shapes Khmer correctly - it is
what the preview uses - so the export now draws every subtitle exactly like
the preview, as a transparent PNG the size of the video, and ffmpeg only lays
those pictures over the video at the right times.

Without a running Qt application (command line tools, some tests) the
subtitles go through libass as before.
"""

import os
from typing import List, Optional, Tuple

from . import branding, subfit
from .project import Project, SubtitleClip


def available() -> bool:
    try:
        from PySide6.QtGui import QGuiApplication

        return QGuiApplication.instance() is not None
    except Exception:
        return False


def sub_style(p: Project) -> dict:
    return dict(color=getattr(p, "sub_color", "#FFFFFF"),
                outline=getattr(p, "sub_outline", 2.0),
                outline_color=getattr(p, "sub_outline_color", "#000000"),
                shadow=getattr(p, "sub_shadow", 0.0),
                box=getattr(p, "sub_box", False),
                box_color=getattr(p, "sub_box_color", "#000000"),
                box_opacity=getattr(p, "sub_box_opacity", 0.6))


def font_family(p: Project, override: str = "") -> str:
    return (override or getattr(p, "sub_font", "") or
            ("Noto Sans Khmer" if p.target_lang == "km" else "Arial"))


def layout(p: Project, text: str, W: float, H: float, out_w: int, out_h: int,
           family: str = ""):
    """Where and how big the subtitle is drawn on a W x H canvas showing an
    out_w x out_h video (the preview and the export use this together).
    Returns (lines, QFont, style, scale, cx, anchor_y, centered)."""
    from PySide6.QtGui import QFont

    size = subfit.font_size(out_w, out_h, p.subtitle_scale or 1.0)
    lines = subfit.wrap_text(text or "", out_w, out_h, size).split("\n")
    scale = H / subfit.SCRIPT_HEIGHT
    # libass drew Noto Sans Khmer at ~0.65x the em size Qt uses for the same
    # number - kept so the size setting means the same as before
    font = QFont(font_family(p, family))
    font.setBold(bool(getattr(p, "sub_bold", False)))
    font.setPixelSize(max(8, int(0.65 * size * scale)))
    cov = branding.cover_on_canvas(p, W, H)
    if p.sub_position == "cover" and cov is not None:
        return lines, font, sub_style(p), scale, cov[0] + cov[2] / 2, cov[1] + cov[3] / 2, True
    margin = branding.sub_margin_v(p)
    return lines, font, sub_style(p), scale, W * branding.sub_x(p) / 100, H - margin * scale, \
        False


def build_path(lines: List[str], font, cx: float, anchor_y: float, centered: bool):
    """(text path, text box) for the lines, centred on cx."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QFontMetricsF, QPainterPath

    fm = QFontMetricsF(font)
    lh = fm.height()
    total = lh * len(lines)
    top = anchor_y - total / 2 if centered else anchor_y - total
    path = QPainterPath()
    box = QRectF()
    for i, line in enumerate(lines):
        w = fm.horizontalAdvance(line)
        x = cx - w / 2
        path.addText(x, top + i * lh + fm.ascent(), font, line)
        box = box.united(QRectF(x, top + i * lh, w, lh))
    return path, box, top + total


def paint(painter, path, box, style: dict, scale: float):
    """Draw the subtitle: box behind it, or shadow + outline, then the text."""
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QColor, QPainter, QPen

    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    if style.get("box"):
        c = QColor(style.get("box_color", "#000000"))
        c.setAlphaF(max(0.0, min(1.0, float(style.get("box_opacity", 0.6)))))
        pad = 3.0 * scale
        painter.fillRect(box.adjusted(-pad, -pad * 0.4, pad, pad * 0.4), c)
    else:
        sh = float(style.get("shadow", 0.0)) * scale
        if sh > 0:
            painter.fillPath(path.translated(sh, sh), QColor(0, 0, 0, 128))
        ow = float(style.get("outline", 0.0)) * scale
        if ow > 0:
            pen = QPen(QColor(style.get("outline_color", "#000000")), 2 * ow)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            painter.strokePath(path, pen)
    painter.fillPath(path, QColor(style.get("color", "#FFFFFF")))


def render_png(p: Project, text: str, W: int, H: int, out_png: str, family: str = "") -> str:
    """One subtitle as a transparent W x H picture."""
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QImage, QPainter

    img = QImage(W, H, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    if text.strip():
        lines, font, style, scale, cx, ay, centered = layout(p, text, W, H, W, H, family)
        path, box, _ = build_path(lines, font, cx, ay, centered)
        qp = QPainter(img)
        paint(qp, path, box, style, scale)
        qp.end()
    if not img.save(out_png, "PNG", 80):
        raise RuntimeError(f"Could not write {out_png}")
    return out_png


def render_track(p: Project, subs: List[SubtitleClip], W: int, H: int, out_dir: str,
                 limit: Optional[float] = None, family: str = "") -> Optional[str]:
    """Every subtitle as a picture + an ffmpeg concat list that shows each one
    from its start to its end (an empty picture in between). Returns the
    list file, or None when there is nothing to show."""
    os.makedirs(out_dir, exist_ok=True)
    items: List[Tuple[float, float, str]] = []
    for c in sorted(subs, key=lambda s: s.start):
        a, b = c.start, c.end
        if limit is not None:
            if a >= limit:
                continue
            b = min(b, limit)
        if b - a >= 0.04 and c.text.strip():
            items.append((max(0.0, a), b, c.text))
    if not items:
        return None
    blank = render_png(p, "", W, H, os.path.join(out_dir, "blank.png"))
    entries = []
    t = 0.0
    for k, (a, b, text) in enumerate(items):
        a = max(a, t)                       # (overlapping lines: the next one wins)
        if b - a < 0.02:
            continue
        if a - t > 0.0005:
            entries.append((blank, a - t))
        png = render_png(p, text, W, H, os.path.join(out_dir, f"s{k:05d}.png"), family)
        entries.append((png, b - a))
        t = b
    entries.append((blank, 1.0))
    lst = os.path.join(out_dir, "subs.txt")
    with open(lst, "w", encoding="utf-8") as f:
        f.write("ffconcat version 1.0\n")
        for path, dur in entries:
            f.write(f"file '{_q(path)}'\nduration {dur:.4f}\n")
        f.write(f"file '{_q(blank)}'\n")         # (the last duration needs one more entry)
    return lst


def _q(path: str) -> str:
    return os.path.abspath(path).replace("\\", "/").replace("'", "'\\''")


def render_brand_png(p: Project, W: int, H: int, out_png: str) -> str:
    """The brand text (Style > Brand text) as a small transparent picture:
    bold, its colour, a thin dark outline - like the preview."""
    from PySide6.QtCore import QPointF, Qt
    from PySide6.QtGui import QColor, QFont, QFontMetricsF, QImage, QPainter, QPainterPath, QPen

    scale = H / subfit.SCRIPT_HEIGHT
    font = QFont("Noto Sans Khmer")
    font.setBold(True)
    font.setPixelSize(max(7, int(0.65 * branding.brand_size(p, W, H) * scale)))
    fm = QFontMetricsF(font)
    lines = p.brand_text.strip().split("\n")
    w = max(fm.horizontalAdvance(ln) for ln in lines)
    pad = max(2.0, 1.5 * scale) + 2
    img = QImage(int(w + 2 * pad) + 1, int(fm.height() * len(lines) + 2 * pad) + 1,
                 QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    path = QPainterPath()
    for i, ln in enumerate(lines):
        path.addText(QPointF(pad, pad + i * fm.height() + fm.ascent()), font, ln)
    qp = QPainter(img)
    qp.setRenderHint(QPainter.RenderHint.Antialiasing)
    pen = QPen(QColor(0, 0, 0), 2 * 1.5 * scale * 0.5)
    pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    qp.strokePath(path, pen)
    qp.fillPath(path, QColor(p.brand_color or "#FFFFFF"))
    qp.end()
    if not img.save(out_png, "PNG", 80):
        raise RuntimeError(f"Could not write {out_png}")
    return out_png


def text_at(subs: List[SubtitleClip], t: float) -> str:
    for c in subs:
        if c.start <= t < c.end and c.text.strip():
            return c.text
    return ""
