"""stretch.py - play audio faster / slower with the same pitch (WSOLA).
Used by the preview mixer and by the export of long films (core/export.py)."""

import numpy as np


def stretch(data: np.ndarray, speed: float, rate: int) -> np.ndarray:
    """Play `data` `speed` times faster, pitch kept (WSOLA: 30 ms pieces put
    back together where they match best). For the preview only - the export
    uses ffmpeg's atempo."""
    if abs(speed - 1.0) < 0.001 or len(data) < 64:
        return data.astype(np.float32, copy=False)
    n = max(64, int(0.03 * rate)) & ~1          # piece length
    hs = n // 2                                 # step in the output
    ha = hs * speed                             # step in the input
    tol = max(4, int(0.008 * rate))             # how far a piece may slide
    out_len = int(len(data) / speed)
    win = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(n) / n)).astype(np.float32)
    src = np.concatenate([np.zeros(tol, np.float32), data.astype(np.float32),
                          np.zeros(n + tol + int(ha) + 2, np.float32)])
    out = np.zeros(out_len + n, np.float32)
    dec = 4                                     # search on every 4th sample (fast)
    prev = tol                                  # where the last piece was taken
    for k in range(out_len // hs + 1):
        o = k * hs
        ideal = int(round(k * ha)) + tol
        if k == 0:
            pos = ideal
        else:
            # the piece that would follow the last one naturally ...
            want = src[prev + hs:prev + hs + n:dec]
            lo = max(0, ideal - tol)
            region = src[lo:lo + 2 * tol + n:dec]
            if len(region) >= len(want) > 0:
                # ... and the place near `ideal` that looks most like it
                c = np.correlate(region, want, "valid")
                pos = lo + int(np.argmax(c)) * dec
            else:
                pos = ideal
        piece = src[pos:pos + n]
        if len(piece) < n:
            break
        out[o:o + n] += piece * win
        prev = pos
    return out[:out_len]
