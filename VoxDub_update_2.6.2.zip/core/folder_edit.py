"""
folder_edit.py - 📂 Edit a whole folder: the edit made on ONE episode in the
editor (logo, brand text, speed, size / ratio, crop, colour, hidden original
subtitles, fades ...) is applied to every episode of a folder - no dubbing -
and the results can be cut into short parts.

    after = "each"   every episode exported on its own
            "cut"    every episode cut into parts of N minutes
            "join"   all episodes joined in order, then cut into parts of N
                     minutes (the part numbers run on: ភាគ01 … ភាគ120)
"""

import copy
import os
import shutil
import tempfile
from typing import Callable, Dict, List, Optional

from . import batch, joiner
from .export import ExportOptions, export_video
from .hardsub import detect_subtitle_area
from .media import get_media_info, needs_mp4, to_mp4
from .project import Project

Progress = Callable[[int, str], None]
Stop = Callable[[], bool]

AFTER = {"each": "Keep every episode whole",
         "cut": "Cut every episode into parts",
         "join": "Join all episodes, then cut into parts"}


def template_of(project: Project) -> dict:
    """The edit of the project in the editor (no dub: subtitles off)."""
    base = batch.settings_of(project)
    base["subs_hidden"] = True
    return base


def summary(base: dict) -> List[str]:
    """What will be applied, in short words."""
    out = []
    if base.get("logo_path"):
        out.append("logo")
    if base.get("extra_logos"):
        out.append(f"+{len(base['extra_logos'])} logo(s)")
    if (base.get("brand_text") or "").strip():
        out.append(f"text “{base['brand_text'].strip()[:24]}”")
    if base.get("cover_enabled"):
        out.append("hide original subtitles")
    out += batch.tools_summary(base)
    return out


def find_videos(folder: str) -> List[str]:
    return batch.find_videos(folder)


def project_for(video: str, base: dict, work: str) -> Project:
    """A project of one episode with the template's edit."""
    src = video
    if needs_mp4(video):
        os.makedirs(work, exist_ok=True)
        src = to_mp4(video, os.path.join(work, "source.mp4"))
    p = batch.preview_project(base, src)
    p.work_dir = work
    os.makedirs(work, exist_ok=True)
    p.segments, p.audio_clips, p.subtitle_clips = [], [], []
    return p


def edit_one(video: str, base: dict, out_path: str, opts: ExportOptions,
             auto_cover: bool = False, cover_hint: Optional[List[float]] = None,
             uniform: bool = False, progress: Optional[Progress] = None,
             should_stop: Optional[Stop] = None) -> Dict:
    """Export one episode with the template's edit.
    auto_cover: find this episode's original subtitles (else the template's /
    the area found in an earlier episode). Returns {"video", "cover"}."""
    work = tempfile.mkdtemp(prefix="vxd_folder_edit_")
    try:
        p = project_for(video, base, work)
        cover = None
        if auto_cover:
            if progress:
                progress(2, "Looking for the original subtitles…")
            cover = detect_subtitle_area(p.video_path, should_stop=should_stop) or cover_hint
            if cover:
                p.cover_enabled, p.cover_rect = True, list(cover)
        if uniform:
            batch.same_format(p)
        o = copy.copy(opts)
        o.output_path = out_path
        o.burn_subtitles = False
        o.export_srt = False
        o.original_volume = p.original_volume
        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        res = export_video(p, o, _scaled(progress, 5 if auto_cover else 0, 100), should_stop)
        return {"video": res["video"], "cover": cover}
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _scaled(progress: Optional[Progress], a: int, b: int) -> Optional[Progress]:
    if not progress:
        return None
    return lambda p, m: progress(a + int(p * (b - a) / 100), m)


def output_for(video: str, out_dir: str) -> str:
    stem = os.path.splitext(os.path.basename(video))[0]
    return os.path.join(out_dir, batch.safe_name(stem) + ".mp4")


def cut(path: str, minutes: float, out_dir: str, name: str, start: int = 1,
        progress: Optional[Progress] = None, should_stop: Optional[Stop] = None) -> List[str]:
    """Parts of `minutes` (a last part under a quarter of that, at most 1 min,
    joins the one before). [] when the video is shorter than one part."""
    sec = minutes * 60.0
    short = min(60.0, sec * 0.25)
    if not joiner.plan_split(get_media_info(path).duration, sec, short):
        return []
    res = joiner.split_video(os.path.abspath(path), sec, os.path.abspath(out_dir), exact=False,
                             min_last=short, name=name,
                             progress=progress, should_stop=should_stop, start=start)
    return res["parts"]
