"""
errors.py - Turn an error from an AI service, the network or the disk into a
short message that says what happened and what to do.

The technical text stays at the end (and in the log) for support.
"""

import errno

# What to tell the user (also used to decide on an automatic retry)
KEY = ("The API key was refused. Check the key in ⚙ Engines (copied in full, no spaces) "
       "and that the service is turned on for it.")
QUOTA = ("The AI service's limit was reached (quota / too many requests). Wait a few minutes, "
         "add another key in ⚙ Engines, or click the same button again later – "
         "finished work is kept.")
DISK = ("The disk is full. Free some space on the drive of the work / output folder, "
        "then try again.")
IN_USE = ("A file could not be written – it is open in another program, or the folder is "
          "read-only. Close the other program (player, Explorer preview) and try again.")
GPU_MEMORY = ("The graphics card (GPU) ran out of memory. Close other programs that use the "
              "GPU, run fewer videos at once, or choose a smaller Whisper model / the CPU.")
GPU_FILES = ("The NVIDIA GPU could not be used (its CUDA / cuDNN files are missing or do not "
             "match the driver). Install the NVIDIA GPU pack again, update the NVIDIA "
             "driver, or choose the CPU.")
BUSY = ("The AI service is busy or down right now. Click the same button again in a minute – "
        "finished work is kept.")
NETWORK = ("No connection to the internet / the AI service. Check the internet (or VPN / "
           "firewall), then click the same button again – finished work is kept.")
SLOW = ("The AI service took too long to answer. Click the same button again – "
        "finished work is kept.")
FFMPEG = ("The video tool (FFmpeg) failed on this file. The video may be damaged or in an "
          "unusual format – try converting it to MP4 first.")

# (words found in the error text, advice) - first match wins, so the specific
# ones (a file in use, the GPU) come before the general ones (FFmpeg, busy)
_RULES = [
    (("api key not valid", "invalid api key", "api_key_invalid", "unauthorized", " 401",
      "(401", "permission_denied", "incorrect api key"), KEY),
    (("resource_exhausted", "quota", "rate limit", "too many requests", " 429", "(429"), QUOTA),
    (("no space left", "disk full", "winerror 112", "errno 28"), DISK),
    (("permission denied", "access is denied", "winerror 5]", "winerror 32",
      "being used by another process"), IN_USE),
    (("cuda out of memory", "out of memory", "cudaerrormemoryallocation"), GPU_MEMORY),
    (("cublas", "cudnn", "cuda", "nvcuda"), GPU_FILES),
    (("http 503", "http 502", "http 504", "status 503", "status 502", "status 504",
      " 503 ", " 502 ", " 504 ", "(503", "(502", "(504", "503 service", "service unavailable",
      "overloaded", "internal server error", "http 500", "status 500", "(500",
      "unavailable"), BUSY),
    (("getaddrinfo", "name resolution", "nodename nor servname", "no address associated",
      "connection refused", "connection reset", "connection aborted", "network is unreachable",
      "failed to establish", "max retries exceeded", "cannot connect", "clientconnectorerror",
      "ssl", "winerror 10060", "winerror 10054", "winerror 11001"), NETWORK),
    (("timed out", "timeout", "read operation timed out"), SLOW),
    (("ffmpeg", "ffprobe"), FFMPEG),
]

# internet / busy / quota / timeout: worth trying again by itself a little later
TRANSIENT = {QUOTA, BUSY, NETWORK, SLOW}


def transient(error) -> bool:
    """An error that often goes away by itself (no internet for a moment, the
    service busy, a quota that refills) - the batch queue tries again."""
    return advice(error) in TRANSIENT


def advice(error) -> str:
    """What to tell the user about this error ("" when there is nothing better
    than the error itself)."""
    if isinstance(error, OSError) and getattr(error, "errno", None) == errno.ENOSPC:
        return DISK
    text = f" {type(error).__name__}: {error}" if isinstance(error, BaseException) \
        else f" {error}"
    low = text.lower()
    for words, msg in _RULES:
        if any(w in low for w in words):
            return msg
    return ""


def friendly(error) -> str:
    """The message for the user: the advice first, the technical text after."""
    tech = f"{type(error).__name__}: {error}" if isinstance(error, BaseException) \
        else str(error)
    tip = advice(error)
    return f"{tip}\n\n({tech})" if tip else tech
