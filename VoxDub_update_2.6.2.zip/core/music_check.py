"""
music_check.py - which known songs are in a video's sound?

Background music is the most common reason for a copyright claim on a dubbed
video ("Music & ambience" keeps the original music). This sends short samples
of the sound to a music-recognition service and lists the songs it knows,
with the time they play, so they can be taken out or replaced before upload.

Service: AudD (https://audd.io) with the user's OWN API token (paid per
request; a small free allowance). The token is kept in this program's
settings and never shown again. A sample is 10 s of audio every 30 s by
default (a 2-minute episode = 4 requests).

This does NOT say whether a platform will claim the video: only songs the
service knows are found, and the picture is not checked.
"""

import os
import subprocess
import tempfile
from typing import Callable, Dict, List, Optional

from . import settings
from .media import find_ffmpeg, get_media_info, no_window

API_URL = "https://api.audd.io/"
KEY_SETTING = "audd_token"
MAX_SAMPLES = 120


def configured() -> bool:
    return bool((settings.get(KEY_SETTING, "") or "").strip())


def set_token(token: str) -> None:
    settings.set(KEY_SETTING, (token or "").strip())


def _sample(src: str, start: float, length: float, out: str) -> bool:
    try:
        subprocess.run([find_ffmpeg(), "-hide_banner", "-loglevel", "error", "-y",
                        "-ss", f"{start:.2f}", "-t", f"{length:.2f}", "-i", src, "-vn",
                        "-ac", "1", "-ar", "44100", "-b:a", "128k", out],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                       creationflags=no_window(), timeout=60, check=True)
    except (OSError, subprocess.SubprocessError):
        return False
    return os.path.isfile(out) and os.path.getsize(out) > 1000


def audd_recognize(mp3_path: str, token: str) -> Optional[Dict]:
    """One request to AudD. Returns {"artist", "title", "album", "link"} or None."""
    import requests

    with open(mp3_path, "rb") as f:
        r = requests.post(API_URL, data={"api_token": token, "return": "spotify"},
                          files={"file": f}, timeout=60)
    r.raise_for_status()
    d = r.json()
    if d.get("status") != "success":
        err = (d.get("error") or {}).get("error_message") or "unknown error"
        raise RuntimeError(f"AudD: {err}")
    res = d.get("result")
    if not res:
        return None
    return {"artist": res.get("artist", ""), "title": res.get("title", ""),
            "album": res.get("album", ""), "link": res.get("song_link", "")}


def scan(path: str, step: float = 30.0, length: float = 10.0,
         progress: Optional[Callable[[int, str], None]] = None,
         should_stop: Optional[Callable[[], bool]] = None,
         recognize: Optional[Callable[[str], Optional[Dict]]] = None) -> List[Dict]:
    """Songs found in the sound of `path` (a video or a wav).
    Returns [{"start", "end", "artist", "title", "album", "link"}], one per song
    stretch (the same song in neighbouring samples is joined)."""
    if recognize is None:
        token = (settings.get(KEY_SETTING, "") or "").strip()
        if not token:
            raise RuntimeError("No AudD API token yet – add yours first.")
        recognize = lambda p: audd_recognize(p, token)     # noqa: E731
    dur = get_media_info(path).duration
    starts = []
    t = 0.0
    while t < max(0.1, dur - 2.0) and len(starts) < MAX_SAMPLES:
        starts.append(t)
        t += step
    hits: List[Dict] = []
    tmp = tempfile.mkdtemp(prefix="voxdub_music_")
    try:
        for k, s in enumerate(starts):
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            if progress:
                progress(int(100 * k / max(1, len(starts))),
                         f"Listening for songs {k + 1}/{len(starts)}…")
            mp3 = os.path.join(tmp, f"s{k}.mp3")
            if not _sample(path, s, min(length, dur - s), mp3):
                continue
            res = recognize(mp3)
            if not res:
                continue
            end = min(dur, s + length)
            last = hits[-1] if hits else None
            if last and last["title"] == res["title"] and last["artist"] == res["artist"] \
                    and s - last["end"] <= step + 0.5:
                last["end"] = end
            else:
                hits.append({"start": s, "end": end, **res})
    finally:
        for f in os.listdir(tmp):
            try:
                os.remove(os.path.join(tmp, f))
            except OSError:
                pass
        try:
            os.rmdir(tmp)
        except OSError:
            pass
    if progress:
        progress(100, f"{len(hits)} song(s) found" if hits else "No known song found")
    return hits
