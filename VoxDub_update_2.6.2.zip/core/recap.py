"""
recap.py - 🎬 AI Recap (2.5 preview): a long drama (one video or a whole
story of episodes, 60 min+) told again in 5-10 minutes, in Khmer.

    1. Speech to text   Whisper reads every video (timed lines)
    2. Story + script   Gemini reads the whole story and writes a Khmer
                        narration in short "beats"; every beat names the
                        moments of the videos (video, start, end) that show it
    3. (you edit)       the script and the chosen moments can be changed
    4. Narration        each beat is spoken (Piseth / Sreymom, or a cloned
                        VoxCPM voice from the 📚 Voice Library)
    5. Edit + export    the chosen moments are cut to the length of their
                        narration, the original sound is turned down under the
                        voice, music / Khmer subtitles if wanted -> one MP4

Everything is kept in the recap folder (recap.json) so a step can be done
again without the others (e.g. new voice, same script).
"""

import json
import os
import re
import shutil
from dataclasses import asdict, dataclass, field
from typing import Callable, List, Optional, Tuple

from . import settings
from .media import APP_DIR, get_media_info, run_ffmpeg

Progress = Optional[Callable[[int, str], None]]
Stop = Optional[Callable[[], bool]]

CHARS_PER_SEC = 13.0        # Khmer narration speed (Edge Piseth / Sreymom, normal)
STYLES = {   # key: (label, Khmer note, how the narrator speaks)
    "normal": ("General Recap", "ទូទៅ · Recommended", "a calm, clear professional storyteller"),
    "comedy": ("Comedy Style", "កំប្លែង · Funny & Light",
               "a witty, playful storyteller with light jokes (never rude)"),
    "emotional": ("Emotional Style", "រំជួលចិត្ត · Touching & Deep",
                  "a warm, touching storyteller who makes people feel the characters"),
    "legend": ("Historical Style", "ប្រវត្តិសាស្ត្រ · Narrator Voice",
               "a solemn storyteller of old legends, kingdoms and history"),
    "exciting": ("Action / Thriller", "រំភើប · Fast & Tense",
                 "an exciting, fast, dramatic storyteller who builds suspense"),
}
PARTS = {"hook": "Intro & Hook", "setup": "Main Story", "conflict": "Conflict",
         "climax": "Climax", "ending": "Ending"}
EMOTIONS = {"auto": "Auto (by scene)", "calm": "Normal", "exciting": "Excited",
            "sad": "Sad", "tense": "Tense", "funny": "Funny"}
# mood of a beat -> narration speed (Edge %) and the pause after it (s)
MOODS = {"calm": (0, 0.30), "tense": (4, 0.40), "exciting": (8, 0.20),
         "sad": (-8, 0.60), "funny": (5, 0.25)}
ORIGINAL_MAX = 5.0          # s of the drama's own voice kept in one "original" beat
RATIOS = {"16:9": (1920, 1080), "9:16": (1080, 1920), "1:1": (1080, 1080)}
FPS = 30
PAD = 0.25                  # s of picture after each beat's narration


@dataclass
class Beat:
    text: str
    clips: List[List[float]] = field(default_factory=list)   # [video index, start, end]
    audio: str = ""
    seconds: float = 0.0
    kind: str = "narration"     # narration / hook / original (the drama's own voice)
    part: str = "setup"         # hook / setup / conflict / climax / ending (scene list)
    mood: str = "calm"          # calm / tense / exciting / sad / funny
    check: str = ""             # consistency check: "" (not checked) / "ok" / a warning

    def pause(self) -> float:
        return 0.15 if self.kind == "original" else MOODS.get(self.mood, (0, PAD))[1]

    def length(self) -> float:
        """Seconds this beat takes in the recap."""
        if self.kind == "original":
            return min(ORIGINAL_MAX, sum(e - s for _v, s, e in self.clips) or 2.0) + 0.15
        return (self.seconds or len(self.text) / CHARS_PER_SEC) + self.pause()


@dataclass
class Recap:
    videos: List[str] = field(default_factory=list)
    work_dir: str = ""
    minutes: float = 8.0
    ratio: str = "16:9"
    engine: str = "edge"
    voice: str = "km-KH-PisethNeural"
    original_volume: float = 0.15
    music: str = ""
    music_volume: float = 0.12
    subtitles: bool = True
    title: str = ""
    language: str = "km"
    style: str = "normal"
    emotion: str = "auto"           # auto = the mood of each beat; else for every beat
    speed: int = 0                  # narration speed, % (Edge)
    pitch: int = 0                  # narration pitch, Hz (Edge)
    source_language: str = "auto"
    hook: bool = True
    keep_original: bool = True      # a few key lines in the drama's own voice
    visual: bool = False            # Gemini also looks at frames of the videos
    resolution: int = 1080          # 720 / 1080 / 2160 (the short side of the picture)
    watermark: str = ""             # a logo in the top-right corner ("" = none)
    story: str = ""                 # 🧠 Story Brain (editable): summary, characters, timeline
    beats: List[Beat] = field(default_factory=list)

    # ---- files
    def path(self) -> str:
        return os.path.join(self.work_dir, "recap.json")

    def save(self) -> None:
        os.makedirs(self.work_dir, exist_ok=True)
        with open(self.path() + ".tmp", "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, ensure_ascii=False, indent=1)
        os.replace(self.path() + ".tmp", self.path())

    @staticmethod
    def load(work_dir: str) -> "Recap":
        with open(os.path.join(work_dir, "recap.json"), encoding="utf-8") as f:
            d = json.load(f)
        beats = [Beat(**b) for b in d.pop("beats", [])]
        r = Recap(**{k: v for k, v in d.items() if k in Recap.__dataclass_fields__})
        r.beats, r.work_dir = beats, work_dir
        return r

    def narration_seconds(self) -> float:
        return sum(b.length() for b in self.beats)


def new_work_dir(root: str, videos: List[str]) -> str:
    import time

    stem = re.sub(r"[^\w\-]+", "_", os.path.splitext(os.path.basename(videos[0]))[0])[:40]
    d = os.path.join(root, f"recap_{stem}_{time.strftime('%Y%m%d_%H%M%S')}")
    os.makedirs(d, exist_ok=True)
    return d


def _mmss(t: float) -> str:
    t = max(0, int(t))
    return f"{t // 3600}:{t % 3600 // 60:02d}:{t % 60:02d}" if t >= 3600 else \
        f"{t // 60:02d}:{t % 60:02d}"


def _secs(v) -> float:
    if isinstance(v, (int, float)):
        return float(v)
    parts = [float(x) for x in str(v).strip().split(":")]
    total = 0.0
    for p in parts:
        total = total * 60 + p
    return total


# --------------------------------------------------------------------------- #
# 1. speech to text
# --------------------------------------------------------------------------- #
def transcripts(r: Recap, progress: Progress = None, stop: Stop = None
                ) -> List[List[Tuple[float, float, str]]]:
    """Timed lines of every video (kept in t<N>.json: done once)."""
    from .media import extract_audio
    from .transcribe import transcribe_audio

    out = []
    n = len(r.videos)
    for i, video in enumerate(r.videos):
        cache = os.path.join(r.work_dir, f"t{i}.json")
        if os.path.isfile(cache):
            with open(cache, encoding="utf-8") as f:
                out.append([tuple(x) for x in json.load(f)])
            continue
        if stop and stop():
            raise InterruptedError("Cancelled")
        lo, hi = int(100 * i / n), int(100 * (i + 1) / n)

        def prog(p, msg, lo=lo, hi=hi, i=i):
            if progress:
                progress(lo + (hi - lo) * p // 100, f"Video {i + 1}/{n}: {msg}")

        wav = os.path.join(r.work_dir, f"a{i}.wav")
        if not os.path.isfile(wav):
            prog(1, "reading the sound…")
            extract_audio(video, wav, 16000)
        segs, _lang = transcribe_audio(
            wav, settings.get("whisper_model", "small") or "small",
            r.source_language or "auto", prog, stop,
            engine=settings.get("stt_engine", "whisper") or "whisper")
        lines = [(round(s.start, 2), round(s.end, 2), s.text.strip()) for s in segs
                 if s.text.strip()]
        with open(cache, "w", encoding="utf-8") as f:
            json.dump(lines, f, ensure_ascii=False)
        try:
            os.remove(wav)
        except OSError:
            pass
        out.append(lines)
    return out


# --------------------------------------------------------------------------- #
# 2a. 🧠 Story Brain: who is who, what happens (Gemini) - editable
# --------------------------------------------------------------------------- #
def _story_lines(lines: List[List[Tuple[float, float, str]]], durations: List[float]) -> str:
    story = []
    for i, ls in enumerate(lines):
        story.append(f"=== VIDEO {i} ({_mmss(durations[i])}) ===")
        story += [f"v{i} [{s:.1f}-{e:.1f}] {t}" for s, e, t in ls]
    return "\n".join(story)


def _lang(r: Recap) -> str:
    return {"km": "Khmer (ភាសាខ្មែរ)", "en": "English", "th": "Thai"}.get(r.language, r.language)


def known_names() -> dict:
    """Character memory: names already fixed in the Glossary (every story)."""
    try:
        from . import glossary

        return glossary.load(glossary.my_path())
    except Exception:
        return {}


def understand(r: Recap, lines: List[List[Tuple[float, float, str]]],
               progress: Progress = None, stop: Stop = None) -> str:
    """Gemini reads the whole story once: summary, characters (with the Khmer
    name used everywhere), and the turning points with their times."""
    from . import gemini

    durations = [get_media_info(v).duration for v in r.videos]
    names = known_names()
    memo = "\n".join(f"{a} = {b}" for a, b in list(names.items())[:200])
    if progress:
        progress(10, "🧠 Gemini is understanding the story…")
    ask = f"""Read the whole drama below (what is said, with times in seconds,
v<video> [start-end] words). Understand it like a film critic:
who the main characters are (hero, villain, love interest, family ...), what each
wants, the conflict, why things happen, the turning points and the ending.

Answer only JSON, everything written in {_lang(r)} except the original names:
{{"summary": "<5-8 sentences: the whole story>",
  "characters": [{{"original": "<name as said in the video>", "name": "<{_lang(r)} name>",
                  "role": "<hero / villain / ...>", "about": "<who they are, relations>"}}],
  "timeline": [{{"at": "v<video> <mm:ss>", "event": "<what happens>"}}]}}
Keep these names exactly as they are (character memory):
{memo or "(none yet)"}

{_story_lines(lines, durations)}
"""
    text, _ = gemini.generate([{"text": ask}], want_json=True, max_tokens=16384,
                              temperature=0.3, should_stop=stop)
    data = gemini._json(text) or {}
    out = ["SUMMARY", str(data.get("summary") or "").strip(), "", "CHARACTERS"]
    for c in data.get("characters") or []:
        out.append(f"{c.get('original', '')} = {c.get('name', '')} — {c.get('role', '')}: "
                   f"{c.get('about', '')}")
    out += ["", "TIMELINE"]
    for t in data.get("timeline") or []:
        out.append(f"{t.get('at', '')} · {t.get('event', '')}")
    r.story = "\n".join(out).strip()
    r.save()
    remember_names(r.story)
    if progress:
        progress(100, "🧠 Story understood")
    return r.story


def story_names(story: str) -> dict:
    """'李云 = លី យុន — hero: …' lines of the CHARACTERS part."""
    names, on = {}, False
    for line in (story or "").splitlines():
        if line.strip().upper() in ("CHARACTERS", "TIMELINE", "SUMMARY"):
            on = line.strip().upper() == "CHARACTERS"
            continue
        m = re.match(r"\s*([^=]+?)\s*=\s*([^—–\-:]+)", line) if on else None
        if m and m.group(1).strip() and m.group(2).strip():
            names[m.group(1).strip()] = m.group(2).strip()
    return names


def remember_names(story: str) -> int:
    """New character names go into the Glossary: the next episodes, dubs and
    recaps use the same Khmer names (character memory)."""
    try:
        from . import glossary

        path = glossary.my_path()
        terms = glossary.load(path)
        new = {a: b for a, b in story_names(story).items() if a not in terms}
        if new:
            terms.update(new)
            glossary.save(path, terms)
        return len(new)
    except Exception:
        return 0


# --------------------------------------------------------------------------- #
# 2b. frames for Gemini to look at (optional)
# --------------------------------------------------------------------------- #
MAX_FRAMES = 120


def frames(r: Recap, stop: Stop = None) -> List[Tuple[int, float, str]]:
    """Small pictures of the videos (v, second, jpg) - at most MAX_FRAMES."""
    folder = os.path.join(r.work_dir, "frames")
    os.makedirs(folder, exist_ok=True)
    durations = [get_media_info(v).duration for v in r.videos]
    every = max(10.0, sum(durations) / MAX_FRAMES)
    out = []
    for i, v in enumerate(r.videos):
        if stop and stop():
            raise InterruptedError("Cancelled")
        pattern = os.path.join(folder, f"v{i}_%04d.jpg")
        if not os.path.isfile(pattern % 1):
            run_ffmpeg(["-y", "-i", v, "-vf", f"fps=1/{every:.2f},scale=320:-2", "-q:v", "6",
                        pattern])
        k = 1
        while os.path.isfile(pattern % k):
            out.append((i, round((k - 1) * every + every / 2, 1), pattern % k))
            k += 1
    return out[:MAX_FRAMES * 2]


def _frame_parts(fr: List[Tuple[int, float, str]]) -> List[dict]:
    import base64

    parts = []
    for v, t, path in fr:
        with open(path, "rb") as f:
            data = base64.b64encode(f.read()).decode("ascii")
        parts.append({"text": f"[picture v{v} at {t:.0f} s]"})
        parts.append({"inline_data": {"mime_type": "image/jpeg", "data": data}})
    return parts


# --------------------------------------------------------------------------- #
# 2c. the Khmer script (Gemini)
# --------------------------------------------------------------------------- #
def prompt(r: Recap, lines: List[List[Tuple[float, float, str]]],
           durations: List[float]) -> str:
    secs = r.minutes * 60
    chars = int(secs * CHARS_PER_SEC * 0.85)
    beats = max(8, int(secs / 14))
    style = STYLES.get(r.style, STYLES["normal"])[2]
    hook = ("The FIRST beat is a hook (kind \"hook\", 5-15 s spoken): a question or the most "
            "shocking moment of the story that makes people keep watching - then start the "
            "story.\n") if r.hook else ""
    orig = ("Add 2-5 beats of kind \"original\": the strongest lines of the drama heard in "
            "the actors' own voices (a shout, a confession, the last words) - its clips are "
            f"exactly that line (at most {ORIGINAL_MAX:g} s) and its text is the line in "
            f"{_lang(r)} (shown as a subtitle, not spoken by the narrator).\n") \
        if r.keep_original else ""
    names = known_names()
    names.update(story_names(r.story))
    memo = "\n".join(f"{a} = {b}" for a, b in list(names.items())[:200])
    look = ("Pictures of the videos follow the text (\"[picture v<video> at <s> s]\"): use "
            "them to choose moments that SHOW the beat - faces, action, places - also where "
            "nobody speaks.\n") if r.visual else ""
    return f"""You make a "movie recap" video: a long drama retold in {r.minutes:g} minutes.
Below is everything that is said in the videos, with times in seconds
(v<video> [start-end] words), and what we know about the story.

STORY (understood before, follow it):
{r.story or "(not written - understand it yourself)"}

CHARACTER NAMES (always exactly these):
{memo or "(none)"}

Write the recap narration in {_lang(r)} as {style}: natural spoken {_lang(r)}
like an experienced Khmer recap channel (not a translation, not a summary list),
past tense, short sentences, the names always the same. Tell the story, do not read
the dialogue. About {chars} characters of narration in about {beats} beats of 1-3
sentences.
{hook}{orig}Give every beat a mood: calm / tense / exciting / sad / funny, and the part of
the story it belongs to: hook / setup / conflict / climax / ending (in this order).
For EVERY beat choose the moments of the videos that show it best - 1 to 4 clips,
together at least as long as the beat is spoken (about {CHARS_PER_SEC:g} characters a
second), in time order, at most 12 s each, never past the end of a video. Only tell
what really happens in the videos (every sentence must be shown by its clips).
{look}
Answer only JSON:
{{"title": "<a short catchy {_lang(r)} title>",
  "beats": [{{"kind": "narration|hook|original", "mood": "calm", "part": "setup",
             "text": "<{_lang(r)} text>", "clips": [[<video>, <start s>, <end s>], ...]}}, ...]}}

{_story_lines(lines, durations)}
"""


def write_script(r: Recap, lines: List[List[Tuple[float, float, str]]],
                 progress: Progress = None, stop: Stop = None) -> Recap:
    from . import gemini

    durations = [get_media_info(v).duration for v in r.videos]
    parts = [{"text": prompt(r, lines, durations)}]
    if r.visual:
        if progress:
            progress(5, "Taking pictures of the videos for Gemini…")
        parts += _frame_parts(frames(r, stop))
    if progress:
        progress(15, "✍ Gemini is writing the Khmer script…")
    text, finish = gemini.generate(parts, want_json=True, max_tokens=32768,
                                   temperature=0.6, should_stop=stop)
    data = gemini._json(text)
    if isinstance(data, list):
        data = {"beats": data}
    beats = []
    for b in data.get("beats") or []:
        t = str((b or {}).get("text") or "").strip()
        if not t:
            continue
        clips = []
        for c in b.get("clips") or []:
            try:
                v, s, e = int(c[0]), _secs(c[1]), _secs(c[2])
            except (TypeError, ValueError, IndexError):
                continue
            if 0 <= v < len(durations):
                s = max(0.0, min(s, durations[v] - 0.5))
                e = max(s + 0.5, min(e, durations[v]))
                clips.append([v, round(s, 2), round(e, 2)])
        kind = str(b.get("kind") or "narration").lower()
        kind = kind if kind in ("narration", "hook", "original") else "narration"
        if kind == "original" and not clips:
            kind = "narration"
        mood = str(b.get("mood") or "calm").lower()
        part = str(b.get("part") or ("hook" if kind == "hook" else "setup")).lower()
        beats.append(Beat(t, clips, kind=kind, mood=mood if mood in MOODS else "calm",
                          part=part if part in PARTS else "setup"))
    if not beats:
        raise ValueError(f"Gemini wrote no recap ({finish}) – try again")
    r.title = str(data.get("title") or r.title or "").strip()
    r.beats = beats
    r.save()
    if progress:
        progress(100, f"Script: {len(beats)} beats")
    return r


# --------------------------------------------------------------------------- #
# 2d. ✔ consistency check: is every beat shown / said in its moments?
# --------------------------------------------------------------------------- #
def evidence(b: Beat, lines: List[List[Tuple[float, float, str]]]) -> List[str]:
    """What is said during a beat's clips (the proof of the beat)."""
    out = []
    for v, s, e in b.clips:
        if 0 <= int(v) < len(lines):
            out += [t for (ls, le, t) in lines[int(v)] if le > s - 1 and ls < e + 1]
    return out


def check(r: Recap, lines: List[List[Tuple[float, float, str]]],
          progress: Progress = None, stop: Stop = None) -> Recap:
    from . import gemini

    if progress:
        progress(10, "✔ Checking every beat against the drama…")
    rows = []
    for i, b in enumerate(r.beats):
        ev = " / ".join(evidence(b, lines))[:600] or "(nobody speaks in these moments)"
        rows.append(f"{i}. [{b.kind}] {b.text}\n   said in its moments: {ev}")
    ask = f"""A recap script and, for each beat, what is said in the video moments it
shows. Story: {r.story[:3000] or "(unknown)"}

For each beat say whether it is TRUE to the drama (the events and names exist) and
whether its moments fit it. Mark only real problems: invented events, wrong names,
wrong person, moments that show something else. Answer only JSON:
[{{"i": <beat number>, "ok": true|false, "note": "<short {_lang(r)} reason when not ok>"}}]

{chr(10).join(rows)}
"""
    text, _ = gemini.generate([{"text": ask}], want_json=True, max_tokens=8192,
                              temperature=0.1, should_stop=stop)
    data = gemini._json(text)
    if isinstance(data, dict):
        data = data.get("beats") or data.get("results") or []
    for d in data or []:
        try:
            i = int(d.get("i"))
        except (TypeError, ValueError, AttributeError):
            continue
        if 0 <= i < len(r.beats):
            r.beats[i].check = "ok" if d.get("ok") else (str(d.get("note") or "").strip()
                                                         or "check this beat")
    for b in r.beats:                    # moments where nobody speaks: no proof at all
        if not b.check and not evidence(b, lines):
            b.check = "no dialogue in its moments – check the picture"
    r.save()
    if progress:
        progress(100, "✔ Checked")
    return r


def score(r: Recap, lines: Optional[List[List[Tuple[float, float, str]]]] = None) -> dict:
    """⭐ Recap quality (what can really be measured)."""
    if not r.beats:
        return {"total": 0}
    want = r.minutes * 60
    got = r.narration_seconds()
    length = max(0.0, 100 - abs(got - want) / max(1.0, want) * 100)
    with_clips = 100 * sum(1 for b in r.beats if b.clips) / len(r.beats)
    checked = [b for b in r.beats if b.check]
    truth = 100 * sum(1 for b in checked if b.check == "ok") / len(checked) if checked else 0
    proof = 100 * sum(1 for b in r.beats if lines and evidence(b, lines)) / len(r.beats) \
        if lines else with_clips
    voiced = 100 * sum(1 for b in r.beats if b.kind == "original" or b.audio) / len(r.beats)
    hook = 100 if r.beats[0].kind == "hook" else 60
    parts = {"length": length, "moments": proof, "true": truth, "voice": voiced,
             "hook": hook}
    w = {"length": 0.2, "moments": 0.25, "true": 0.3 if checked else 0.0, "voice": 0.15,
         "hook": 0.1}
    tw = sum(w.values())
    parts["total"] = round(sum(parts[k] * w[k] for k in w) / tw)
    parts["seconds"] = round(got)
    return {k: round(v) if isinstance(v, float) else v for k, v in parts.items()}


# --------------------------------------------------------------------------- #
# 3. narration (the mood sets the speed)
# --------------------------------------------------------------------------- #
def narrate(r: Recap, progress: Progress = None, stop: Stop = None,
            only: Optional[List[int]] = None) -> Recap:
    from . import tts

    folder = os.path.join(r.work_dir, "voice")
    os.makedirs(folder, exist_ok=True)
    todo = [i for i in range(len(r.beats)) if (only is None or i in only)
            and r.beats[i].kind != "original"]
    for n, i in enumerate(todo):
        if stop and stop():
            raise InterruptedError("Cancelled")
        b = r.beats[i]
        if progress:
            progress(int(100 * n / max(1, len(todo))), f"Narration {n + 1}/{len(todo)}")
        wav = os.path.join(folder, f"b{i:03d}.wav")
        edge = r.engine in ("edge", "azure")
        mood = b.mood if r.emotion == "auto" else r.emotion
        rate = (MOODS.get(mood, (0, PAD))[0] + (3 if b.kind == "hook" else 0)
                + int(r.speed)) if edge else 0
        voice = r.voice
        if edge and int(r.pitch):
            voice = f"{voice}|pitch={int(r.pitch):+d}Hz"
        try:
            tts.synthesize(b.text, wav, r.engine, voice, r.language, rate_percent=rate)
        except TypeError:                # (older signature)
            tts.synthesize(b.text, wav, r.engine, voice, r.language)
        b.audio, b.seconds = wav, round(get_media_info(wav).duration, 2)
    r.save()
    return r


# --------------------------------------------------------------------------- #
# 4. edit + export
# --------------------------------------------------------------------------- #
def plan(beat: Beat, need: float, durations: List[float]) -> List[Tuple[int, float, float]]:
    """The pieces of video shown during a beat, `need` seconds long in all:
    its clips in order, the last one longer (or the clips again) if short."""
    clips = [(int(v), float(s), float(e)) for v, s, e in beat.clips if e > s] or \
        [(0, 0.0, min(durations[0], need))]
    out, total = [], 0.0
    k = 0
    while total < need - 0.01 and k < 50:
        v, s, e = clips[k % len(clips)]
        take = min(e - s, need - total)
        if k == len(clips) - 1 and total + (e - s) < need:     # stretch the last clip
            take = min(durations[v] - s, need - total)
        if take <= 0.05:
            k += 1
            if k >= len(clips) and total == 0:
                break
            continue
        out.append((v, s, s + take))
        total += take
        k += 1
    return out


def _video_filter(i: int, W: int, H: int, fit: str) -> str:
    if fit == "blur":                     # 9:16 from a 16:9 drama: blurred background
        return (f"[{i}:v]split[b{i}][f{i}];"
                f"[b{i}]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
                f"boxblur=20:2[bb{i}];"
                f"[f{i}]scale={W}:{H}:force_original_aspect_ratio=decrease[ff{i}];"
                f"[bb{i}][ff{i}]overlay=(W-w)/2:(H-h)/2,setsar=1,fps={FPS},format=yuv420p[v{i}]")
    return (f"[{i}:v]scale={W}:{H}:force_original_aspect_ratio=decrease,"
            f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={FPS},format=yuv420p[v{i}]")


def render_beat(r: Recap, i: int, out: str, W: int, H: int, fit: str,
                durations: List[float], has_audio: List[bool]) -> str:
    b = r.beats[i]
    need = b.length()
    pieces = plan(b, need, durations)
    args, parts = [], []
    for k, (v, s, e) in enumerate(pieces):
        args += ["-ss", f"{s:.3f}", "-t", f"{e - s:.3f}", "-i", r.videos[v]]
        parts.append(_video_filter(k, W, H, fit))
        if has_audio[v]:
            parts.append(f"[{k}:a]aresample=48000,aformat=channel_layouts=stereo,"
                         f"apad=whole_dur={e - s:.3f}[a{k}]")
        else:
            parts.append(f"anullsrc=r=48000:cl=stereo,atrim=0:{e - s:.3f}[a{k}]")
    n = len(pieces)
    parts.append("".join(f"[v{k}][a{k}]" for k in range(n)) + f"concat=n={n}:v=1:a=1[cv][ca]")
    parts.append(f"[cv]trim=0:{need:.3f},setpts=PTS-STARTPTS[vout]")
    vol = max(0.0, float(r.original_volume))
    if b.kind == "original":                    # the actors' own voice, full
        parts.append(f"[ca]atrim=0:{need:.3f},afade=t=in:d=0.08,"
                     f"afade=t=out:st={max(0.0, need - 0.15):.3f}:d=0.15[aout]")
    elif b.audio and os.path.isfile(b.audio):
        args += ["-i", b.audio]
        parts.append(f"[ca]atrim=0:{need:.3f},volume={vol:.3f}[orig]")
        parts.append(f"[{n}:a]aresample=48000,aformat=channel_layouts=stereo,"
                     f"apad=whole_dur={need:.3f}[nar]")
        parts.append("[orig][nar]amix=inputs=2:normalize=0:duration=first,"
                     "alimiter=limit=0.891[aout]")
    else:
        parts.append(f"[ca]atrim=0:{need:.3f}[aout]")
    run_ffmpeg(["-y", *args, "-filter_complex", ";".join(parts), "-map", "[vout]",
                "-map", "[aout]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                "-r", str(FPS), "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                "-t", f"{need:.3f}", out])
    return out


def _ass_time(t: float) -> str:
    cs = int(round(t * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def write_ass(r: Recap, path: str, W: int, H: int) -> None:
    from .subfit import wrap_text

    size = int(H * (0.042 if H > W else 0.055))
    lines = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {W}", f"PlayResY: {H}",
             "WrapStyle: 2", "", "[V4+ Styles]",
             "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
             "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, "
             "BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
             f"Style: Default,Noto Sans Khmer,{size},&H00FFFFFF,&H00FFFFFF,&H00000000,"
             f"&H80000000,0,0,0,0,100,100,0,0,1,{max(2, size // 14)},1,2,40,40,"
             f"{int(H * 0.07)},1", "", "[Events]",
             "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"]
    t = 0.0
    for b in r.beats:
        d = b.length()
        try:
            text = wrap_text(b.text, W, H, size).replace("\n", "\\N")
        except Exception:
            text = b.text
        if b.kind == "original":                # the line said by the actor: in italics
            text = "{\\i1}" + text + "{\\i0}"
        lines.append(f"Dialogue: 0,{_ass_time(t)},{_ass_time(t + d - b.pause())},Default,,"
                     f"0,0,0,,{text}")
        t += d
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(lines) + "\n")


def _qt_subtitles(r: Recap, tmp: str, W: int, H: int) -> Optional[str]:
    """The narration as subtitle pictures drawn by Qt (Khmer shaped right on
    every PC). None when Qt is not running: libass draws them instead."""
    try:
        from . import subrender
        from .project import Project, SubtitleClip

        if not subrender.available():
            return None
        p = Project()
        p.target_lang = r.language or "km"
        subs, t = [], 0.0
        for i, b in enumerate(r.beats):
            d = b.length()
            if b.text.strip():
                subs.append(SubtitleClip(f"r{i}", round(t, 3), round(t + d - b.pause(), 3),
                                         b.text))
            t += d
        return subrender.render_track(p, subs, W, H, os.path.join(tmp, "subpics"))
    except Exception as e:                       # never lose the recap for the subtitles
        print(f"[recap] Qt subtitles: {e}")
        return None


def write_srt(r: Recap, path: str) -> str:
    def ts(t):
        ms = int(round(t * 1000))
        return f"{ms // 3600000:02d}:{ms // 60000 % 60:02d}:{ms // 1000 % 60:02d},{ms % 1000:03d}"
    out, t = [], 0.0
    for n, b in enumerate(r.beats, 1):
        d = b.length()
        out.append(f"{n}\n{ts(t)} --> {ts(t + d - b.pause())}\n{b.text}\n")
        t += d
    with open(path, "w", encoding="utf-8-sig") as f:
        f.write("\n".join(out))
    return path


def export(r: Recap, out_path: str, progress: Progress = None, stop: Stop = None) -> str:
    if not r.beats:
        raise ValueError("No script yet")
    write_srt(r, os.path.splitext(out_path)[0] + ".srt")      # subtitles as a file too
    infos = [get_media_info(v) for v in r.videos]
    durations = [x.duration for x in infos]
    has_audio = [x.has_audio for x in infos]
    if r.ratio in RATIOS:
        W, H = RATIOS[r.ratio]
        k = (int(r.resolution or 1080)) / 1080.0
        W, H = int(W * k) // 2 * 2, int(H * k) // 2 * 2
    else:
        W, H = max(2, infos[0].width // 2 * 2), max(2, infos[0].height // 2 * 2)
    src_portrait = infos[0].height > infos[0].width
    fit = "blur" if (H > W) != src_portrait else "pad"
    tmp = os.path.join(r.work_dir, "render")
    os.makedirs(tmp, exist_ok=True)
    parts = []
    for i in range(len(r.beats)):
        if stop and stop():
            raise InterruptedError("Cancelled")
        if progress:
            progress(int(85 * i / len(r.beats)), f"Cutting the scenes {i + 1}/{len(r.beats)}")
        parts.append(render_beat(r, i, os.path.join(tmp, f"p{i:03d}.mp4"), W, H, fit,
                                 durations, has_audio))
    lst = os.path.join(tmp, "list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in parts:
            f.write(f"file '{os.path.basename(p)}'\n")
    joined = os.path.join(tmp, "joined.mp4")
    if progress:
        progress(88, "Joining…")
    run_ffmpeg(["-y", "-f", "concat", "-safe", "0", "-i", "list.txt", "-c", "copy",
                "joined.mp4"], cwd=tmp)
    music = r.music if r.music and os.path.isfile(r.music) else ""
    logo = r.watermark if r.watermark and os.path.isfile(r.watermark) else ""
    if not music and not r.subtitles and not logo:
        shutil.copyfile(joined, out_path)
        _even_loudness(out_path, progress)
        return out_path
    if progress:
        progress(92, "Music / subtitles…")
    args = ["-y", "-i", "joined.mp4"]
    vf = "[0:v]null[v]"
    nxt = 1                                     # the next ffmpeg input number
    sub_list = _qt_subtitles(r, tmp, W, H) if r.subtitles else None
    if sub_list:
        # Khmer drawn by Qt (like Export): libass in some ffmpeg builds cannot
        # shape Khmer, so letters came out broken on customers' PCs
        args += ["-f", "concat", "-safe", "0", "-i", os.path.abspath(sub_list)]
        vf = f"[0:v][{nxt}:v]overlay=0:0:eof_action=pass:format=auto[v]"
        nxt += 1
    elif r.subtitles:
        fonts = os.path.join(tmp, "fonts")
        if not os.path.isdir(fonts):
            src = os.path.join(APP_DIR, "assets", "fonts")
            if os.path.isdir(src):
                shutil.copytree(src, fonts)
            else:
                os.makedirs(fonts, exist_ok=True)
        write_ass(r, os.path.join(tmp, "recap.ass"), W, H)
        vf = "[0:v]subtitles=recap.ass:fontsdir=fonts[v]"
    af = "[0:a]anull[a]"
    if logo:
        args += ["-i", os.path.abspath(logo)]
        lw = max(32, int(min(W, H) * 0.14)) // 2 * 2
        vf = (vf[:-3] + "[s];" + f"[{nxt}:v]scale={lw}:-2,format=rgba,"
              "colorchannelmixer=aa=0.85[wm];"
              f"[s][wm]overlay=W-w-{int(W * 0.025)}:{int(H * 0.025)}[v]")
        nxt += 1
    if music:
        args += ["-stream_loop", "-1", "-i", music]
        af = (f"[{nxt}:a]aresample=48000,aformat=channel_layouts=stereo,"
              f"volume={float(r.music_volume):.3f}[m];"
              "[0:a][m]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.891[a]")
    run_ffmpeg([*args, "-filter_complex", f"{vf};{af}", "-map", "[v]", "-map", "[a]",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac",
                "-b:a", "192k", "-shortest", "final.mp4"], cwd=tmp)
    shutil.move(os.path.join(tmp, "final.mp4"), out_path)
    _even_loudness(out_path, progress)
    if progress:
        progress(100, "Recap ready")
    return out_path


def _even_loudness(path: str, progress: Progress = None) -> None:
    """As loud as YouTube / TikTok play it (Export › Even loudness, on by default)."""
    from . import settings
    from .export import LOUDNESS, match_loudness
    from .project import Project

    if not settings.get("export_loudness", True):
        return
    if progress:
        progress(98, "Even loudness…")
    p = Project()
    p.audio_rate, p.audio_channels = 48000, 2
    try:
        match_loudness(p, path, LOUDNESS)
    except Exception as e:                      # never lose the finished recap
        print(f"[recap] loudness skipped: {e}")


def export_audio(video: str, fmt: str) -> str:
    """Audio only (MP3 / WAV) next to the exported video."""
    out = os.path.splitext(video)[0] + "." + fmt
    codec = ["-c:a", "libmp3lame", "-b:a", "192k"] if fmt == "mp3" else \
        ["-c:a", "pcm_s16le", "-ar", "48000"]
    run_ffmpeg(["-y", "-i", os.path.abspath(video), "-vn", *codec, os.path.abspath(out)])
    return out


# --------------------------------------------------------------------------- #
# 📚 Recap Library + pictures
# --------------------------------------------------------------------------- #
def remember(r: Recap) -> None:
    """Recent recaps (Recap Library), newest first."""
    r.save()
    lst = [p for p in (settings.get("recap_recent", []) or []) if p != r.work_dir]
    settings.set("recap_recent", ([r.work_dir] + lst)[:40])


def library() -> List[Recap]:
    out = []
    for d in settings.get("recap_recent", []) or []:
        try:
            out.append(Recap.load(d))
        except (OSError, ValueError, TypeError):
            continue
    return out


def thumb(video: str, t: float, out: str, width: int = 320) -> str:
    """One picture of a video at t seconds (made once)."""
    if not os.path.isfile(out):
        os.makedirs(os.path.dirname(out), exist_ok=True)
        try:
            run_ffmpeg(["-y", "-ss", f"{max(0.0, t):.2f}", "-i", video, "-frames:v", "1",
                        "-vf", f"scale={width}:-2", "-q:v", "5", out])
        except Exception:
            return ""
    return out if os.path.isfile(out) else ""


def beat_thumbs(r: Recap) -> List[str]:
    folder = os.path.join(r.work_dir, "thumbs")
    out = []
    for i, b in enumerate(r.beats):
        if b.clips and 0 <= int(b.clips[0][0]) < len(r.videos):
            v, s, e = b.clips[0]
            out.append(thumb(r.videos[int(v)], (s + e) / 2,
                             os.path.join(folder, f"b{i:03d}_{int(v)}_{int(s * 10)}.jpg")))
        else:
            out.append("")
    return out


def chapters(r: Recap) -> List[Tuple[str, float, float]]:
    """(part label, start, length) of the recap, for the scene list."""
    out, t = [], 0.0
    for b in r.beats:
        label = PARTS.get(b.part, "Main Story")
        if out and out[-1][0] == label:
            out[-1] = (label, out[-1][1], out[-1][2] + b.length())
        else:
            out.append((label, t, b.length()))
        t += b.length()
    return out


def _js_runtimes() -> dict:
    """YouTube needs a JavaScript runtime now (yt-dlp): deno, else Node.js (the
    one SARIKA VOICE uses), wherever it is installed."""
    import shutil

    rt = {"deno": {}}
    node = shutil.which("node") or next(
        (p for p in (r"C:\Program Files\nodejs\node.exe",
                     os.path.expandvars(r"%LOCALAPPDATA%\Programs\nodejs\node.exe"))
         if os.path.isfile(p)), "")
    if node:
        rt["node"] = {"path": node}
    return rt


def _clean(err) -> str:
    text = re.sub(r"\x1b\[[0-9;]*m", "", str(err)).replace("ERROR:", "").strip()
    low = text.lower()
    if "not available" in low or "unavailable" in low:
        text += ("\n\nThe video may be private, members-only, age-restricted, blocked in "
                 "this country, or YouTube asked for a check this PC could not answer. "
                 "Try another link, or download it in the browser and use From Local File.")
    elif "sign in" in low or "confirm you" in low or "bot" in low:
        text += "\n\nYouTube wants a signed-in browser for this video – download it in the " \
                "browser and use From Local File."
    return text


def download(url: str, folder: str, progress: Progress = None, stop: Stop = None) -> str:
    """From YouTube / a link (yt-dlp)."""
    try:
        import yt_dlp
    except ImportError:
        raise RuntimeError("Downloading from YouTube / a link needs yt-dlp "
                           "(pip install yt-dlp) – it comes with the next installer.")
    os.makedirs(folder, exist_ok=True)

    def hook(d):
        if stop and stop():
            raise InterruptedError("Cancelled")
        if progress and d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                progress(int(95 * d.get("downloaded_bytes", 0) / total), "Downloading…")
    from .media import find_ffmpeg

    base = {"outtmpl": os.path.join(folder, "%(title).80s.%(ext)s"),
            "merge_output_format": "mp4", "progress_hooks": [hook], "quiet": True,
            "no_warnings": True, "noplaylist": True, "no_color": True,
            "ffmpeg_location": os.path.dirname(find_ffmpeg()),
            "js_runtimes": _js_runtimes()}
    try:
        import yt_dlp_ejs  # noqa: F401
    except ImportError:
        base["remote_components"] = ["ejs:github"]
    # a few ways, the next one when YouTube refuses the one before
    tries = [{"format": "bv*[height<=1080]+ba/b[height<=1080]/b"},
             {"format": "b", "extractor_args": {"youtube": {"player_client": ["tv", "web_safari"]}}},
             {"format": "b", "extractor_args": {"youtube": {"player_client": ["android_vr"]}}}]
    last = None
    for extra in tries:
        if stop and stop():
            raise InterruptedError("Cancelled")
        try:
            with yt_dlp.YoutubeDL({**base, **extra}) as ydl:
                info = ydl.extract_info(url, download=True)
                path = ydl.prepare_filename(info)
            stem = os.path.splitext(path)[0]
            for ext in (".mp4", ".mkv", ".webm"):
                if os.path.isfile(stem + ext):
                    return stem + ext
            return path
        except InterruptedError:
            raise
        except Exception as e:
            last = e
            if "unsupported url" in str(e).lower():
                break
    raise RuntimeError(_clean(last))
