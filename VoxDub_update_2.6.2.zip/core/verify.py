"""
verify.py - AI second opinion on the Smart Review lines (2.6.2).

After Transcribe (+ the OCR double-check) a few lines are flagged: no
subtitle on the video shows them ("nosub") or Whisper was not sure
("unsure"). Nobody looks at them in a Batch of 100 episodes, so Gemini
listens to just those 2-3 second pieces (a few per episode, ten pieces per
request - very little quota) and decides:

  * it hears the same words    -> the line is right (flag removed)
  * the same line, a letter or two different -> Gemini's spelling
  * it hears other words       -> the flag stays (shown in Quality check)
  * it hears nobody speaking   -> noise: taken out (kept in noise_lines)
  * no key / no quota / error  -> nothing changes (the flags stay)
"""

import json
from difflib import SequenceMatcher
from typing import Callable, Dict, List, Optional

import numpy as np

from .project import Project

FLAGS = ("nosub", "unsure", "nosub_unsure")
PER_REQUEST = 10
PAD = 0.6                   # s of sound around a line (the subtitle time can be early / late)
MAX_PIECE = 15.0            # s
SAME = 0.6                  # similarity: "the same words"

Progress = Callable[[int, str], None]


def _norm(t: str) -> str:
    return "".join(ch for ch in (t or "") if ch.isalnum()).lower()


def same_words(a: str, b: str) -> bool:
    x, y = _norm(a), _norm(b)
    if not x or not y:
        return False
    return x == y or SequenceMatcher(None, x, y).ratio() >= SAME


def _ask(pieces: List[np.ndarray], lang: str, should_stop=None) -> List[dict]:
    """Gemini: for every piece {"speech": bool, "text": str}."""
    from . import gemini
    from .translate import LANGUAGES

    lname = LANGUAGES.get(lang, (lang, ""))[0] if lang else ""
    parts: List[dict] = []
    for k, a in enumerate(pieces):
        parts.append({"text": f"Clip {k + 1}:"})
        parts.append({"inline_data": {"mime_type": "audio/wav", "data": gemini._wav_b64(a)}})
    parts.append({"text": (
        f"These are {len(pieces)} short clips from a "
        f"{lname + ' ' if lname else ''}video. For EACH clip write exactly what is said, "
        "in the original language (do not translate). If a clip has no speech - only "
        "music, noise, a breath or a grunt - set speech to false.\n"
        'Answer ONLY with JSON: {"clips": [{"clip": 1, "speech": true, "text": "..."}]}')})
    text, _ = gemini.generate(parts, temperature=0.0, max_tokens=4096,
                              should_stop=should_stop)
    try:
        data = gemini._json(text)
    except ValueError:
        return []
    items = data.get("clips", []) if isinstance(data, dict) else data
    out: Dict[int, dict] = {}
    for it in items if isinstance(items, list) else []:
        try:
            k = int(it.get("clip", 0)) - 1
        except (TypeError, ValueError, AttributeError):
            continue
        if 0 <= k < len(pieces):
            out[k] = {"speech": bool(it.get("speech", True)),
                      "text": str(it.get("text", "") or "").strip()}
    return [out.get(k, {}) for k in range(len(pieces))]


def verify_flagged(project: Project, progress: Optional[Progress] = None,
                   should_stop: Optional[Callable[[], bool]] = None) -> Dict[str, int]:
    """Let Gemini settle the flagged lines. Returns the counts
    {"checked", "right", "differs", "noise", "unclear"} (0 when Gemini is not set up)."""
    stats = {"checked": 0, "right": 0, "noise": 0}
    from . import gemini, settings

    if not settings.get("ai_verify_lines", True) or not gemini.configured():
        return stats
    try:
        from . import plans
        if not plans.allows("gemini"):          # Gemini is a Pro feature
            return stats
    except Exception:
        pass
    todo = [s for s in project.segments
            if getattr(s, "check", "") in FLAGS and not s.tts_path]
    if not todo or not project.original_audio:
        return stats
    from .media import read_wav

    try:
        audio, sr = read_wav(project.original_audio)
    except Exception as e:
        print(f"[verify] cannot read the sound: {e}")
        return stats
    if sr != 16000:
        n = int(len(audio) * 16000 / sr)
        audio = np.interp(np.linspace(0, len(audio), n, endpoint=False),
                          np.arange(len(audio)), audio).astype(np.float32)
    lang = project.detected_lang or (project.source_lang
                                     if project.source_lang != "auto" else "")
    noise = []
    log: List[str] = []
    for g in range(0, len(todo), PER_REQUEST):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        group = todo[g:g + PER_REQUEST]
        if progress:
            progress(int(100 * g / len(todo)),
                     f"AI checks {len(todo)} unsure lines ({g + 1}-{g + len(group)})...")
        pieces = []
        for s in group:
            a = max(0.0, s.start - PAD)
            b = min(len(audio) / 16000.0, max(s.end + PAD, a + 0.5), a + MAX_PIECE)
            pieces.append(audio[int(a * 16000):int(b * 16000)])
        try:
            answers = _ask(pieces, lang, should_stop)
        except InterruptedError:
            raise
        except Exception as e:                  # no quota / network: flags stay
            print(f"[verify] Gemini not used: {e}")
            note = f"⚠ AI check of unsure lines stopped ({str(e)[:100]}) - see Quality check"
            if note not in project.engine_notes:
                project.engine_notes.append(note)
            break
        for s, ans in zip(group, answers):
            if not ans:
                continue                        # no answer for this one: keep the flag
            stats["checked"] += 1
            heard = ans.get("text", "")
            log.append(f"{s.start:.1f}s {s.text} -> "
                       + (heard if ans.get("speech", True) and heard else "(no speech)"))
            if not ans.get("speech", True) or not _norm(heard):
                # Gemini misses speech under loud music / action (a real line of
                # 8 letters was taken out): only a grunt or a short unsure scrap
                # goes; anything longer keeps its flag for the Quality check
                from .pipeline import NOISE_CHARS, NOISE_MAX_LETTERS
                short = len(_norm(s.text)) <= NOISE_MAX_LETTERS
                if any(c in NOISE_CHARS for c in s.text) or \
                        (short and s.check == "nosub_unsure"):
                    noise.append(s)
                    stats["noise"] += 1
                else:
                    stats["unclear"] = stats.get("unclear", 0) + 1
            elif _norm(s.text) in _norm(heard):
                # (the piece also holds a bit of the lines around it: Gemini
                # hearing MORE than the line still confirms it)
                s.check = ""
                stats["right"] += 1
            elif same_words(s.text, heard) and abs(len(_norm(s.text)) - len(_norm(heard))) <= 1:
                # the same line with a letter or two read wrongly ("爷希" / "爷爷"):
                # Gemini's spelling
                s.text = heard.strip()
                s.translation, s.tts_text = "", ""
                s.check = ""
                stats["fixed"] = stats.get("fixed", 0) + 1
            else:
                # other words: the flag stays (Gemini also hears the lines next
                # to it - "对" came back as "山 对 就是 这 细 框 山 80万" - so its
                # words are never put in by themselves)
                stats["differs"] = stats.get("differs", 0) + 1
    if noise:
        from .pipeline import take_out_lines

        take_out_lines(project, noise)
    if stats["checked"]:
        msg = (f"[verify] AI checked {stats['checked']} lines: {stats['right']} right, "
               f"{stats.get('fixed', 0)} spelling fixed, "
               f"{stats.get('differs', 0)} heard differently (kept), {stats['noise']} noise, "
               f"{stats.get('unclear', 0)} not heard (kept): " + " · ".join(log[:20]))
        print(msg)
        try:
            from . import crashlog
            crashlog.note(msg)                  # (the Test copy has no log file)
        except Exception:
            pass
    return stats
