"""
voxcpm.py - VoxCPM voice engine (voice cloning, runs on this computer).

VoxCPM2 (openbmb, Apache-2.0) speaks 30 languages including Khmer and clones
a voice from a short reference recording (zero-shot). It needs its own
Python 3.10-3.12 with PyTorch + CUDA, so it is NOT installed into the app's
environment: the app starts core/voxcpm_worker.py with that Python (a
"sidecar") and keeps it running, so the model loads only once.

Settings (Settings › AI engines & API keys › Voice clone):
  voxcpm_python      python.exe of the VoxCPM environment (found automatically
                     in the usual places when empty)
  voxcpm_model       "" = newest available (VoxCPM2, then 1.5, then 0.5B)
  voxcpm_ref_male / voxcpm_ref_female       reference recordings (any format)
  voxcpm_ref_male_text / ..._female_text    what is said in them (better clone)
  voxcpm_steps       5 fast · 10 normal · 16 best
"""

import json
import os
import subprocess
import sys
import threading
from typing import Dict, List, Optional

from . import settings
from .media import APP_DIR, no_window, EXE_DIR, FROZEN, data_dir, run_ffmpeg

def _worker_file() -> str:
    """core/voxcpm_worker.py next to this file (an installed update brings its
    own copy); an older installer only has tools/voxcpm_worker.py."""
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), "voxcpm_worker.py")
    for p in (here, os.path.join(APP_DIR, "core", "voxcpm_worker.py"),
              os.path.join(APP_DIR, "tools", "voxcpm_worker.py")):
        if os.path.isfile(p):
            return p
    return here


WORKER = _worker_file()
VOICES = [("voxcpm-male", "Cloned voice (Male)"), ("voxcpm-female", "Cloned voice (Female)"),
          ("voxcpm-plain", "VoxCPM own voice (no clone)")]
# default voices by age (Characters tab): their own reference if one is set,
# else the male / female reference
AGE_VOICES = [("voxcpm-child", "Child"), ("voxcpm-elder-male", "Elder man"),
              ("voxcpm-elder-female", "Elder woman")]
STEPS = {5: "Fast", 10: "Normal", 16: "Best"}


class VoxCPMError(RuntimeError):
    pass


def candidates() -> List[str]:
    """Usual places of a VoxCPM Python (Sarika Lite's venv-voxcpm too)."""
    out = []
    # installed app: setup_voxcpm.bat puts it in %LOCALAPPDATA%\\VoxDubPRO (or next
    # to the .exe when that folder is writable)
    bases = [data_dir(), EXE_DIR, APP_DIR, os.path.dirname(EXE_DIR)]
    if os.environ.get("LOCALAPPDATA"):
        bases.append(os.path.join(os.environ["LOCALAPPDATA"], "VoxDubPRO"))
    if not FROZEN:      # the owner's PC: older installs of the other apps
        bases += [os.path.join(APP_DIR, "dist"), "D:\\Projects\\sarika-engine\\dist",
                  "D:\\Projects\\sarika-engine", "D:\\sarikalite", "C:\\sarikalite"]
    bases.append(os.path.expanduser("~"))
    for base in bases:
        for venv in ("venv-voxcpm", ".venv-voxcpm", "voxcpm-venv"):
            for exe in (os.path.join(base, venv, "Scripts", "python.exe"),
                        os.path.join(base, venv, "bin", "python")):
                out.append(exe)
    return out


def find_pythons() -> List[str]:
    """Every usual-place Python that really has VoxCPM installed."""
    return [c for c in dict.fromkeys(candidates()) if os.path.isfile(c) and has_voxcpm(c)]


_found: Dict[str, bool] = {}


def has_voxcpm(python: str) -> bool:
    if python in _found:
        return _found[python]
    ok = False
    if python and os.path.isfile(python):
        try:
            r = subprocess.run([python, "-c", "import voxcpm"], capture_output=True,
                               timeout=180, creationflags=no_window(), env=_child_env())
            ok = r.returncode == 0
        except Exception:
            ok = False
    _found[python] = ok
    return ok


def python_path() -> str:
    """The VoxCPM python: the saved one, else the first usual place that works."""
    p = (settings.get("voxcpm_python", "") or "").strip().strip('"')
    if p and not _same_as_app(p):          # the app's own 3.14 can never run VoxCPM
        return p
    for c in candidates():
        if os.path.isfile(c) and has_voxcpm(c):
            return c
    return ""


def ready() -> bool:
    p = python_path()
    return bool(p) and os.path.isfile(p)


# --------------------------------------------------------------------------- #
# reference voices
# --------------------------------------------------------------------------- #
def _setting_ref(voice: str) -> tuple:
    """(file, transcript) from Settings for a default voice id."""
    keys = {"voxcpm-child": ["child", "female"], "voxcpm-elder-male": ["elder_male", "male"],
            "voxcpm-elder-female": ["elder_female", "female"],
            "voxcpm-female": ["female"], "voxcpm-male": ["male"]}.get(voice, ["male"])
    for k in keys:
        src = (settings.get(f"voxcpm_ref_{k}", "") or "").strip().strip('"')
        if src:
            return src, settings.get(f"voxcpm_ref_{k}_text", "") or ""
    return "", ""


def reference(voice: str) -> tuple:
    """(wav path, transcript) of the reference recording of a voice:
    voxcpm-male / -female / -child / -elder-*, or 'voxcpm-ref:<file>' (a
    character's own recording; its transcript may be in <file>.txt).
    Any format is converted once to 16 kHz mono WAV (the model's reader does
    not open .m4a / .mp3)."""
    if voice == "voxcpm-plain":
        return "", ""
    if voice.startswith("voxcpm-ref:"):
        src = voice[len("voxcpm-ref:"):]
        txt = os.path.splitext(src)[0] + ".txt"
        text = ""
        if os.path.isfile(txt):
            with open(txt, encoding="utf-8", errors="replace") as f:
                text = f.read().strip()
        gender = "ref"
    else:
        src, text = _setting_ref(voice)
        gender = voice.replace("voxcpm-", "")
    if not src:
        return "", ""
    if not os.path.isfile(src):
        raise VoxCPMError(f"Reference voice not found: {src}")
    if not text:            # 2.4: what is said in it, typed / heard in the Voice Library
        try:
            from .voice_library import text_for

            text = text_for(src)
        except Exception:
            text = ""
    cache = os.path.join(settings.settings_dir(), "voxcpm_refs")
    os.makedirs(cache, exist_ok=True)
    import hashlib

    st = os.stat(src)
    tag = hashlib.md5(os.path.abspath(src).encode("utf-8")).hexdigest()[:8]
    out = os.path.join(cache, f"{gender}_{tag}_{int(st.st_mtime)}_{st.st_size}.wav")
    if not os.path.isfile(out):
        run_ffmpeg(["-i", os.path.abspath(src), "-vn", "-ac", "1", "-ar", "16000",
                    "-t", "30", out])
    typed = gender != "ref" or not os.path.isfile(os.path.splitext(src)[0] + ".txt")
    if text and typed and not text_fits(text, _seconds(out)):
        # the words do not belong to this recording (too few / too many for its
        # length): wrong words make the voice worse - the recording alone
        print(f"[voxcpm] the words typed for {os.path.basename(src)} do not fit the "
              f"recording - not used")
        text = ""
    return out, text


def _seconds(wav: str) -> float:
    """Seconds of speech in a 16-bit WAV (pauses not counted; 0 = unknown)."""
    import wave

    import numpy as np

    try:
        with wave.open(wav, "rb") as w:
            rate = w.getframerate() or 16000
            a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32)
    except Exception:
        return 0.0
    hop = int(rate * 0.02)
    if hop <= 0 or len(a) < hop:
        return 0.0
    frames = a[:len(a) // hop * hop].reshape(-1, hop) / 32768.0
    rms = np.sqrt((frames ** 2).mean(axis=1))
    return float((rms > 0.01).sum()) * 0.02


def text_fits(text: str, seconds: float) -> bool:
    """Could these words be what is said in a recording this long?
    (Khmer / English speech: about 5 - 30 letters a second; a Chinese /
    Japanese character counts as 3.) An unknown length: yes."""
    letters = sum(3 if "\u3000" <= c <= "\u9fff" else 1 for c in text
                  if not c.isspace() and c not in ".,!?。，！？។៕-–\"'")
    if letters == 0:
        return False
    if seconds <= 0:
        return True
    return 4.0 <= letters / seconds <= 30.0


def _child_env() -> dict:
    """The other Python must not inherit this app's environment (its venv)."""
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    for k in ("PYTHONHOME", "PYTHONPATH", "VIRTUAL_ENV", "__PYVENV_LAUNCHER__"):
        env.pop(k, None)
    return env


def _same_as_app(python: str) -> bool:
    try:
        return os.path.normcase(os.path.realpath(os.path.dirname(python))) == \
            os.path.normcase(os.path.realpath(os.path.dirname(sys.executable)))
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# the sidecar
# --------------------------------------------------------------------------- #
class _Worker:
    def __init__(self):
        self.proc: Optional[subprocess.Popen] = None
        self.python = ""
        self.lock = threading.Lock()
        self.info: dict = {}

    def _start(self):
        py = python_path()
        if not py or not os.path.isfile(py):
            raise VoxCPMError("VoxCPM is not set up – choose its python.exe in "
                              "Settings › AI engines & API keys › Voice clone")
        if not has_voxcpm(py):
            found = [c for c in find_pythons() if c != py]
            why = ("this is the app's own Python (3.14) – VoxCPM needs its own 3.10–3.12 "
                   "environment" if _same_as_app(py) else "VoxCPM is not installed in it")
            hint = (f" Found one that works: {found[0]}" if found else
                    " Pick python.exe inside a venv-voxcpm folder.")
            raise VoxCPMError(f"VoxCPM is not set up – {py}: {why}.{hint}")
        env = _child_env()
        self.proc = subprocess.Popen(
            [py, "-u", WORKER], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, text=True, encoding="utf-8", env=env,
            creationflags=no_window())
        self.python = py
        self.info = self._ask({"cmd": "load", "model": settings.get("voxcpm_model", "") or ""})

    def _ask(self, req: dict) -> dict:
        assert self.proc and self.proc.stdin and self.proc.stdout
        self.proc.stdin.write(json.dumps(req, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()
        line = self.proc.stdout.readline()
        if not line:
            self.stop()
            raise VoxCPMError("VoxCPM stopped (out of GPU memory? wrong Python?)")
        res = json.loads(line)
        if not res.get("ok"):
            raise VoxCPMError(res.get("error", "VoxCPM failed"))
        return res

    def request(self, req: dict) -> dict:
        with self.lock:
            if self.proc is None or self.proc.poll() is not None or self.python != python_path():
                self.stop()
                self._start()
            return self._ask(req)

    def stop(self):
        p, self.proc = self.proc, None
        if p is not None:
            try:
                p.stdin.write('{"cmd": "quit"}\n')
                p.stdin.flush()
                p.wait(5)
            except Exception:
                p.kill()


_worker = _Worker()


def synthesize(text: str, out_wav: str, voice: str = "voxcpm-male") -> str:
    ref, ref_text = reference(voice)
    steps = int(settings.get("voxcpm_steps", 10) or 10)
    # a recording cut from the video speaks the ORIGINAL language: VoxCPM2 takes
    # only its voice. A recording you set up yourself (Voice clone settings /
    # Voice Library) with its words: voice + words = the steadiest clone.
    own = bool(ref_text) and not voice.startswith("voxcpm-ref:") or _library_text(voice)
    # words heard by a machine (Thai / Latin letters for a Khmer recording) are
    # worse than none: only Khmer words typed for the recording are used
    own = own and is_khmer(ref_text)
    req = {"cmd": "tts", "text": text, "ref_wav": ref, "ref_text": ref_text,
           "steps": steps, "cfg": 2.0, "continue": bool(own and ref_text)}
    # VoxCPM2 drifts: with the same recording one line can come out low and the
    # next high like another person. Steady voice: a line far from the
    # recording (pitch, voice print) is made again with another start (up to
    # 3 tries) and the closest one is kept.
    steady = bool(ref) and bool(settings.get("voxcpm_steady", True))
    tries = max(1, min(5, int(settings.get("voxcpm_tries", 3) or 1))) if steady else 1
    prof = _profile(ref) if steady else None
    if prof is None:
        tries = 1
    best, best_score, made = None, -9.0, []
    for k in range(tries):
        path = out_wav if k == 0 else f"{os.path.splitext(out_wav)[0]}_try{k}.wav"
        _worker.request(dict(req, out=os.path.abspath(path), seed=1234 + 7919 * k))
        if not os.path.isfile(path) or os.path.getsize(path) < 200:
            continue
        made.append(path)
        if prof is None:
            best = path
            break
        ok, score = _judge(prof, path)
        if score > best_score:
            best, best_score = path, score
        if ok:
            break
    if best is None:
        raise VoxCPMError("VoxCPM returned no audio")
    if best != out_wav:
        os.replace(best, out_wav)
    for p in made:
        if p != best and p != out_wav and os.path.isfile(p):
            try:
                os.remove(p)
            except OSError:
                pass
    return out_wav


# --------------------------------------------------------------------------- #
# steady voice: how close a line is to the recording
# --------------------------------------------------------------------------- #
STEADY_PITCH = 1.25         # within x1.25 of the recording's pitch (about 4 semitones)
STEADY_SIM = 0.60           # voice print likeness (same person ~0.65 - 0.8)
_profiles: Dict[str, tuple] = {}


def _load16k(path: str):
    import numpy as np

    from .media import read_wav

    data, sr = read_wav(path)
    if sr != 16000 and len(data):
        n = int(len(data) * 16000 / sr)
        data = np.interp(np.linspace(0, len(data) - 1, n), np.arange(len(data)),
                         data).astype(np.float32)
    return data


def _measure(path: str) -> tuple:
    """(median pitch Hz or 0, voice print or None) of a wav."""
    from . import speakers
    from .gender import estimate_pitch

    a = _load16k(path)
    if len(a) < 16000 * 0.3:
        return 0.0, None
    try:
        emb = speakers.embed_lines(a, [(0.0, len(a) / 16000.0)])[0]
    except Exception:
        emb = None
    return float(estimate_pitch(a) or 0.0), emb


def _profile(ref: str) -> Optional[tuple]:
    if not ref or not os.path.isfile(ref):
        return None
    if ref not in _profiles:
        try:
            p, e = _measure(ref)
        except Exception as ex:
            print(f"[voxcpm] steady voice off: {ex}")
            p, e = 0.0, None
        _profiles[ref] = (p, e) if p > 0 else None
    return _profiles[ref]


def _judge(prof: tuple, path: str) -> tuple:
    """(close enough?, score) of a made line against the recording."""
    import math

    rp, re_ = prof
    try:
        p, e = _measure(path)
    except Exception:
        return True, 0.0
    if p <= 0:
        return True, 0.0                         # (too short to tell)
    dev = abs(math.log2(p / rp))
    sim = float(e @ re_) if e is not None and re_ is not None else STEADY_SIM
    ok = dev <= math.log2(STEADY_PITCH) and sim >= STEADY_SIM
    return ok, 0.3 * sim - dev                  # the pitch tells "another person" best


def is_khmer(text: str) -> bool:
    """Khmer words (at least 30 % Khmer letters - names in English are fine)?"""
    letters = [c for c in text or "" if c.isalpha() or "\u1780" <= c <= "\u17ff"]
    if not letters:
        return False
    khmer = sum("\u1780" <= c <= "\u17ff" for c in letters)
    # letters of other scripts (Thai, Telugu, Greek ...): words heard wrongly
    other = sum(not ("\u1780" <= c <= "\u17ff" or c.isascii()) for c in letters)
    return khmer / len(letters) >= 0.3 and other / len(letters) <= 0.05


def _library_text(voice: str) -> bool:
    """A character's recording from the Voice Library with its words typed."""
    if not voice.startswith("voxcpm-ref:"):
        return False
    src = voice[len("voxcpm-ref:"):]
    if os.path.isfile(os.path.splitext(src)[0] + ".txt"):
        return False                            # cut from the video by the app
    try:
        from .voice_library import text_for

        return bool(text_for(src))
    except Exception:
        return False


def info() -> dict:
    return dict(_worker.info)


def shutdown():
    _worker.stop()


def test(text: str = "សួស្តី! នេះជាសំឡេងសាកល្បង។") -> str:
    """Generate one sample line. Returns the WAV path (raises on failure)."""
    import tempfile

    out = os.path.join(tempfile.gettempdir(), "voxdub_voxcpm_test.wav")
    voice = "voxcpm-male" if _setting_ref("voxcpm-male")[0] else "voxcpm-plain"
    return synthesize(text, out, voice)


if __name__ == "__main__":        # quick check: python -m core.voxcpm
    print(python_path() or "no VoxCPM python found", file=sys.stderr)
