"""
export.py - Render the final dubbed MP4 with ffmpeg.

Steps
  1. Mix all AI voice clips into one WAV (timeline length).
  2. Write the subtitles (+ brand text) as an .ass file, and a plain .srt.
  3. One ffmpeg run that: cuts/joins the kept video clips, covers the
     original burned-in subtitles, fits the picture into the output ratio
     (blurred or black fill), adds the logo, burns the subtitles, mixes the
     original audio (quiet, as background) with the AI voice and encodes
     H.264 + AAC.
Progress is read live from "ffmpeg -progress".
"""

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Callable, Optional

from .effects import original_audio_filters, video_fade_filters, voice_track_filters
from .branding import extra_logos, has_logo, output_size, video_chain, write_ass
from .media import _atempo_chain
from .media import (
    APP_DIR, no_window, FFmpegError, ffmpeg_major_version, find_ffmpeg, nvenc_available,
    run_ffmpeg,
)
from . import subrender
from .project import Project
from .sync import render_dub_mix, render_speech_mask, write_srt

RESOLUTIONS = {"original": 0, "720p": 720, "1080p": 1080, "1440p": 1440, "2160p": 2160}
AUDIO_KBPS = [128, 192, 256, 320]
LIMIT = 0.891                           # -1 dBFS: the exported sound never peaks above       # Export › Audio quality (0 = by channels)

# 2.2 Export Center: ready-made settings (size, quality, audio kbps)
PRESETS = [
    ("custom", "Custom", None),
    ("youtube", "YouTube – 1080p, high quality", ("1080p", 18, 256)),
    ("social", "Facebook / TikTok – 1080p, normal", ("1080p", 20, 192)),
    ("telegram", "Telegram / phone – 720p, small file", ("720p", 24, 128)),
    ("master", "4K master – 2160p, high quality", ("2160p", 18, 320)),
]


@dataclass
class ExportOptions:
    output_path: str
    resolution: str = "1080p"          # original / 720p / 1080p (short side)
    burn_subtitles: bool = True
    export_srt: bool = True
    export_mp3: bool = False           # the finished sound as an .mp3 next to the video
    original_volume: float = 0.15
    dub_volume: float = 1.0
    crf: int = 20
    preset: str = "medium"
    subtitle_font: str = "Noto Sans Khmer"
    encoder: str = "auto"              # auto (NVIDIA if available) / nvenc / x264
    watermark: str = ""                # burned in when the app is not licensed
    title: str = ""                    # the video's title (MP4 metadata)
    audio_kbps: int = 0                # AAC bitrate (0 = 128 / 192 / 384 by channels)
    # the finished sound brought to this loudness (LUFS, like YouTube / TikTok /
    # Facebook play it); 0 = as mixed
    loudness: float = 0.0


ENCODERS = {
    "auto": "Auto (NVIDIA GPU if available)",
    "nvenc": "NVIDIA GPU (NVENC) - fast",
    "x264": "CPU (x264) - best compatibility",
}


def _video_codec_args(encoder: str, opts: "ExportOptions") -> list:
    if encoder == "nvenc":
        # constant-quality VBR; cq ~ crf + 2 gives a similar size/quality
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-tune", "hq", "-rc", "vbr",
                "-cq", str(opts.crf + 2), "-b:v", "0", "-spatial-aq", "1"]
    return ["-c:v", "libx264", "-preset", opts.preset, "-crf", str(opts.crf)]


def pick_encoder(choice: str) -> str:
    if choice == "x264":
        return "x264"
    if choice in ("auto", "nvenc") and nvenc_available():
        return "nvenc"
    return "x264"


AUDIO_RATES = [8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000]
FPS_CHOICES = [8, 10, 12, 15, 20, 23.976, 24, 25, 29.97, 30, 50, 59.94, 60]


def output_format_args(project: Project, kbps: int = 0) -> list:
    """Project settings: frame rate (0 = same as the video), sample rate, channels."""
    args = []
    fps = float(getattr(project, "out_fps", 0.0) or 0.0)
    if fps > 0:
        exact = {23.976: "24000/1001", 29.97: "30000/1001", 59.94: "60000/1001"}
        args += ["-r", exact.get(round(fps, 3), f"{fps:g}")]
    rate = int(getattr(project, "audio_rate", 44100) or 44100)
    if rate not in AUDIO_RATES:
        rate = 44100
    ch = int(getattr(project, "audio_channels", 2) or 2)
    if ch not in (1, 2, 6):
        ch = 2
    kbps = int(kbps or 0) or {1: 128, 2: 192, 6: 384}[ch]
    return args + ["-ar", str(rate), "-ac", str(ch), "-b:a", f"{kbps}k"]


def early_fps(project: Project) -> float:
    """Frame rate (in timeline time) to keep right after the video is cut
    together, or 0 when every frame is needed. The finished video then has
    the Project settings frame rate - or the video's own - also when sped up
    (before: a 25 fps film at 128 % came out at 32 fps)."""
    src = float(getattr(project, "fps", 0.0) or 0.0)
    if src <= 0:
        return 0.0
    want = float(getattr(project, "out_fps", 0.0) or 0.0) or src
    rate = want / max(0.01, project.speed())
    return rate if rate < src - 0.05 else 0.0


def estimate_size(project: Project, opts: ExportOptions) -> int:
    """About how big the exported mp4 will be (bytes) - a guide for the
    Export window, measured on real exports (CRF 20 ~ 0.105 bit per pixel at
    1080x1350 / 30 fps; every +6 CRF halves it; bigger pictures need a little
    less per pixel)."""
    w, h = canvas_size(project, opts)
    fps = float(getattr(project, "out_fps", 0.0) or 0.0) or float(project.fps or 0.0) or 30.0
    dur = max(0.0, project.output_duration())
    pixels = max(1, w * h)
    bpp = 0.105 * 2 ** ((20 - int(opts.crf)) / 6.0) * (pixels / (1080 * 1350)) ** -0.25
    video = bpp * pixels * min(fps, 60.0)
    ch = int(getattr(project, "audio_channels", 2) or 2)
    audio = (int(getattr(opts, "audio_kbps", 0) or 0) or {1: 128, 2: 192, 6: 384}.get(ch, 192)) \
        * 1000
    return int((video + audio) * dur / 8 * 1.02)


def size_text(n: int) -> str:
    if n >= 1024 ** 3:
        return f"{n / 1024 ** 3:.1f} GB"
    return f"{max(1, round(n / 1024 ** 2))} MB"


def canvas_size(project: Project, opts: ExportOptions):
    return output_size(project, RESOLUTIONS.get(opts.resolution, 0))


def _prepare_overlays(project: Project, opts: ExportOptions, tmp: str, limit: float,
                      burn: bool) -> Optional[str]:
    """Copy the bundled fonts and write the .ass file into `tmp`.
    Returns the .ass name, or None when there is nothing to burn."""
    fonts_src = os.path.join(APP_DIR, "assets", "fonts")
    fonts_dst = os.path.join(tmp, "fonts")
    os.makedirs(fonts_dst, exist_ok=True)
    if os.path.isdir(fonts_src):    # Noto Sans Khmer so Khmer renders everywhere
        for name in os.listdir(fonts_src):
            if name.lower().endswith((".ttf", ".otf")):
                shutil.copyfile(os.path.join(fonts_src, name), os.path.join(fonts_dst, name))
    subs = project.shown_subtitles()
    qt = subrender.available()
    if burn and subs and qt:
        burn = False            # drawn by Qt instead (Khmer shaping) - see _sub_track
    brand = bool(project.brand_text.strip()) and not qt     # (Qt draws it: _brand_png)
    if not (burn and subs) and not brand and not opts.watermark:
        return None
    W, H = canvas_size(project, opts)
    ass_name = "subs.ass"   # relative name: avoids Windows path escaping in filters
    write_ass(project, subs, os.path.join(tmp, ass_name), W, H, opts.subtitle_font,
              limit=limit, burn_subs=burn, watermark=opts.watermark, brand=brand)
    return ass_name


def _brand_png(project: Project, opts: ExportOptions, tmp: str) -> Optional[str]:
    """The brand text as a picture drawn by Qt (None: no text / no Qt)."""
    if not project.brand_text.strip() or not subrender.available():
        return None
    W, H = canvas_size(project, opts)
    return subrender.render_brand_png(project, W, H, os.path.join(tmp, "brand.png"))


def _sub_track(project: Project, opts: ExportOptions, tmp: str, limit: Optional[float],
               burn: bool) -> Optional[str]:
    """The subtitles as pictures drawn by Qt (core/subrender.py): an ffmpeg
    concat list, or None (no subtitles / no Qt: libass draws them)."""
    subs = project.shown_subtitles()
    if not (burn and subs and subrender.available()):
        return None
    W, H = canvas_size(project, opts)
    return subrender.render_track(project, subs, W, H, os.path.join(tmp, "subpics"), limit,
                                  _qt_font(opts))


# --------------------------------------------------------------------------- #
# Long films with many video pieces (cuts, parts slowed for long lines)
# --------------------------------------------------------------------------- #
# One ffmpeg graph with a trim filter per piece makes every frame of the film
# pass through every trim: with thousands of pieces the export crawls / seems
# stuck. Then the timeline is first put together in small groups of pieces
# (each read straight from its place in the file), and the normal export runs
# on that one, already laid-out video.
GROUP_PIECES = 24


def needs_timeline_pass(project: Project) -> bool:
    return len([c for c in project.video_clips if c.length > 0.01]) > GROUP_PIECES


def _fps_text(fps: float) -> str:
    exact = {23.976: "24000/1001", 29.97: "30000/1001", 59.94: "60000/1001"}
    return exact.get(round(fps, 3), f"{fps:.4f}")


def _timeline_video(project: Project, opts: ExportOptions, tmp: str, report,
                    should_stop) -> str:
    """The picture laid out on the timeline (no sound), made group by group;
    every group gets exactly the frames its timeline length needs, so the
    picture never drifts from the sound."""
    clips = [c for c in project.video_clips if c.length > 0.01]
    fps = float(project.fps or 0) or 30.0
    if pick_encoder(opts.encoder) == "nvenc":
        enc = ["-c:v", "h264_nvenc", "-preset", "p4", "-rc", "vbr", "-cq", "17", "-b:v", "0"]
    else:
        enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "16"]
    groups = [clips[i:i + GROUP_PIECES] for i in range(0, len(clips), GROUP_PIECES)]
    files, done, t_end = [], 0, 0.0
    for gi, g in enumerate(groups):
        if should_stop and should_stop():
            raise InterruptedError("Export cancelled")
        a = min(c.src_in for c in g)
        b = max(c.src_out for c in g)
        t_end += sum(c.length for c in g)
        frames = int(round(t_end * fps)) - done
        done += frames
        parts, ins = [], ""
        for i, c in enumerate(g):
            pts = (f"(PTS-STARTPTS)/{c.rate:.4f}" if abs(c.rate - 1.0) > 0.001
                   else "PTS-STARTPTS")
            parts.append(f"[0:v]trim=start={c.src_in - a:.4f}:end={c.src_out - a:.4f},"
                         f"setpts={pts}[v{i}]")
            ins += f"[v{i}]"
        parts.append(f"{ins}concat=n={len(g)}:v=1:a=0,fps={_fps_text(fps)},"
                     f"tpad=stop_mode=clone:stop_duration=2,format=yuv420p[vo]")
        out = os.path.join(tmp, f"tl_{gi:04d}.mp4")
        try:
            run_ffmpeg(["-y", "-ss", f"{a:.3f}", "-to", f"{b + 0.5:.3f}",
                        "-i", os.path.abspath(project.video_path),
                        "-filter_complex", ";".join(parts), "-map", "[vo]", "-an",
                        "-frames:v", str(max(1, frames))] + enc + [out])
        except FFmpegError:
            if enc[1] != "h264_nvenc":
                raise
            enc = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "16"]
            run_ffmpeg(["-y", "-ss", f"{a:.3f}", "-to", f"{b + 0.5:.3f}",
                        "-i", os.path.abspath(project.video_path),
                        "-filter_complex", ";".join(parts), "-map", "[vo]", "-an",
                        "-frames:v", str(max(1, frames))] + enc + [out])
        files.append(out)
        report(8 + 30 * (gi + 1) // len(groups),
               f"Preparing the video {gi + 1}/{len(groups)} (slowed / cut parts)...")
    lst = os.path.join(tmp, "tl_list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for p in files:
            f.write(f"file '{os.path.abspath(p).replace(chr(92), '/')}'\n")
    video = os.path.join(tmp, "timeline.mp4")
    run_ffmpeg(["-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", video])
    for p in files:
        try:
            os.remove(p)
        except OSError:
            pass
    return video


def _timeline_audio(project: Project, src_wav: str, out_wav: str, should_stop=None) -> str:
    """The background sound laid out on the timeline, sample-exact: every
    piece read from its place, slowed pieces stretched (pitch kept)."""
    import wave

    import numpy as np

    from .stretch import stretch

    clips = [c for c in project.video_clips if c.length > 0.01]
    with wave.open(src_wav, "rb") as rf, wave.open(out_wav, "wb") as wf:
        sr, ch, n_src = rf.getframerate(), rf.getnchannels(), rf.getnframes()
        wf.setnchannels(ch)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        written = 0
        block = sr * 30
        for c in clips:
            if should_stop and should_stop():
                raise InterruptedError("Export cancelled")
            want = int(round(c.end * sr)) - written
            a = max(0, min(n_src, int(round(c.src_in * sr))))
            b = max(a, min(n_src, int(round(c.src_out * sr))))
            if abs(c.rate - 1.0) <= 0.001:
                left, pos = want, a
                while left > 0:                 # long pieces: copy in blocks
                    take = min(block, left, max(0, b - pos))
                    rf.setpos(pos) if take else None
                    raw = rf.readframes(take) if take else b""
                    got = len(raw) // (2 * ch)
                    if got < min(block, left):
                        raw += b"\x00" * (2 * ch * (min(block, left) - got))
                        got = min(block, left)
                    wf.writeframes(raw)
                    left -= got
                    pos += got
            else:
                rf.setpos(a)
                data = np.frombuffer(rf.readframes(b - a), "<i2").astype(np.float32)
                data = data.reshape(-1, ch).T / 32768.0
                outs = []
                for k in range(ch):
                    y = stretch(data[k], c.rate, sr)
                    y = y[:want] if len(y) >= want else np.pad(y, (0, want - len(y)))
                    outs.append(y)
                pcm = np.clip(np.stack(outs, 1), -1, 1)
                wf.writeframes((pcm * 32767).astype("<i2").tobytes())
            written += want
    return out_wav


def _timeline_pass(project: Project, opts: ExportOptions, tmp: str, music_wav, report,
                   should_stop):
    """(project laid out as one plain video, its background sound wav or None)."""
    import copy

    from .project import VideoClip, new_id

    video = _timeline_video(project, opts, tmp, report, should_stop)
    sound = None
    if project.has_audio and opts.original_volume > 0.001:
        report(39, "Preparing the background sound...")
        src = music_wav
        if not src:
            src = os.path.join(tmp, "orig_sound.wav")
            run_ffmpeg(["-y", "-i", os.path.abspath(project.video_path), "-vn", "-ac", "2",
                        "-ar", "44100", "-c:a", "pcm_s16le", src])
        sound = _timeline_audio(project, src, os.path.join(tmp, "timeline_sound.wav"),
                                should_stop)
    flat = copy.copy(project)
    flat.video_path = video
    flat.video_clips = [VideoClip(new_id(), 0.0, project.sequence_duration())]
    flat.layout_video()
    return flat, sound


def _qt_font(opts: ExportOptions) -> str:
    f = (opts.subtitle_font or "").strip()
    return "" if f.lower() in ("", "arial", "noto sans khmer") else f


def _build_command(project, opts, dub_wav, ass_name, encoder="x264", mask_wav=None,
                   tmp=None, music_wav=None, sub_list=None, brand_png=None,
                   audio_wav=None):
    """music_wav: Background = music & effects only - this track (the video's
    sound without voices) is used instead of the video's own sound.
    audio_wav: the background sound already laid out on the timeline (a long
    film made in two passes, see _timeline_pass) - used instead of [0:a]."""
    clips = [c for c in project.video_clips if c.length > 0.01]
    use_orig = project.has_audio and opts.original_volume > 0.001
    logo = has_logo(project)
    bg_wav = music_wav or audio_wav
    src_a = (3 if logo else 2) if bg_wav else 0
    parts = []
    concat_inputs = ""
    for i, c in enumerate(clips):
        # a piece slowed for a long line (sync.stretch_video_for_voices)
        slow = abs(c.rate - 1.0) > 0.001
        pts = f"(PTS-STARTPTS)/{c.rate:.4f}" if slow else "PTS-STARTPTS"
        parts.append(
            f"[0:v]trim=start={c.src_in:.3f}:end={c.src_out:.3f},setpts={pts}[v{i}]"
        )
        concat_inputs += f"[v{i}]"
        if use_orig:
            tempo = f",{_atempo_chain(c.rate)}" if slow else ""
            parts.append(
                f"[{src_a}:a]atrim=start={c.src_in:.3f}:end={c.src_out:.3f},"
                f"asetpts=PTS-STARTPTS{tempo},aresample=44100[a{i}]"
            )
            concat_inputs += f"[a{i}]"
    n = len(clips)
    if use_orig:
        parts.append(f"{concat_inputs}concat=n={n}:v=1:a=1[vcat][acat]")
    else:
        parts.append(f"{concat_inputs}concat=n={n}:v=1:a=0[vcat]")

    W, H = canvas_size(project, opts)
    vsrc = "vcat"
    speed = project.speed()
    early = early_fps(project)
    if early:
        # Speed / a lower frame rate: drop the frames that would never be seen
        # BEFORE the picture work (colour, blur, logos ...), not after it -
        # Speed 128 % on a 25 fps film: ~22 % less to filter and to encode
        parts.append(f"[vcat]fps={early:.5f}[vfps]")
        vsrc = "vfps"
    fades = video_fade_filters(project, project.sequence_duration(), speed)
    if fades:                       # Clip Properties > Video: fade in / out (black)
        parts.append(f"[{vsrc}]{','.join(fades)}[vfade]")
        vsrc = "vfade"
    # inputs: video, AI voice, [logo], [music / timeline sound], [speech mask],
    # [subtitles], [brand]
    mask_input = 2 + int(logo) + int(bool(bg_wav))
    n_in = mask_input + int(bool(use_orig and mask_wav))
    sub_in = f"{n_in}:v" if sub_list else None
    brand_in = f"{n_in + int(bool(sub_list))}:v" if brand_png else None
    # the extra logos (sponsor / customer) are the last inputs
    extras = extra_logos(project)
    first_extra = n_in + int(bool(sub_list)) + int(bool(brand_png))
    vparts, vout = video_chain(project, W, H, vsrc, "2:v" if logo else None, ass_name, sub_in,
                               brand_in, [f"{first_extra + k}:v" for k in range(len(extras))])
    parts += vparts
    if abs(speed - 1.0) > 0.001:
        # Clip Properties > Video > Speed: last, so the burned subtitles, logo
        # and fades are sped up with the picture
        # (after frames were dropped early, say the frame rate again: FFmpeg 7.1
        # on Windows kept the early rate - 25 fps at 150 % came out at 17 fps)
        back = f",fps={early * speed:.5f}" if early else ""
        parts.append(f"[{vout}]setpts=PTS/{speed:.4f}{back}[vspeed]")
        vout = "vspeed"

    fmt = "aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo"
    # AI voice track: Equalizer / Noise Removal / Audio Effects
    voice = "".join(f + "," for f in voice_track_filters(project))
    if use_orig:
        extra = original_audio_filters(project, project.sequence_duration(), speed)
        bg = f"[acat]{fmt}," + "".join(f + "," for f in extra) + \
            f"volume={opts.original_volume:.3f}"
        if mask_wav:   # mute the original speech where the AI voice talks
            parts.append(bg + "[bgv]")
            parts.append(f"[{mask_input}:a]aresample=44100,{fmt}[mask]")
            parts.append("[bgv][mask]amultiply[bg]")
        else:
            parts.append(bg + "[bg]")
        parts.append(f"[1:a]{fmt},{voice}volume={opts.dub_volume:.3f}[dub]")
        parts.append("[bg][dub]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]")
    else:
        parts.append(f"[1:a]{fmt},{voice}volume={opts.dub_volume:.3f}[aout]")
    aout = "aout"
    if abs(speed - 1.0) > 0.001:
        parts.append(f"[aout]{_atempo_chain(speed)}[aspeed]")     # (pitch kept)
        aout = "aspeed"
    # green screen branding (intro / outro / Like & Subscribe ...): last, in
    # the finished video's time; they are the last inputs
    from . import greenscreen

    gs_items = greenscreen.items(project)
    if gs_items:
        gs_first = first_extra + len(extras)
        total_out = project.output_duration()
        gparts, vout = greenscreen.video_filters(gs_items, gs_first, vout, W, H, total_out)
        parts += gparts
        aparts, alabels = greenscreen.audio_filters(gs_items, gs_first, total_out)
        if alabels:
            parts += aparts
            parts.append("".join(f"[{x}]" for x in [aout] + alabels)
                         + f"amix=inputs={1 + len(alabels)}:duration=first:"
                           "dropout_transition=0:normalize=0[agreen]")
            aout = "agreen"
    # never above -1 dB: the AI voice + music + original sound added up could
    # peak over 0 dB (a crackle on phones / a "clips" in the quality check).
    # A limiter only touches those peaks (level=0: no loudness change).
    parts.append(f"[{aout}]alimiter=limit={LIMIT:.3f}:level=0:attack=5:release=60[alim]")
    aout = "alim"

    cmd = [
        find_ffmpeg(), "-hide_banner", "-y",
        "-i", os.path.abspath(project.video_path),
        "-i", os.path.abspath(dub_wav),
    ]
    if logo:
        cmd += ["-loop", "1", "-i", os.path.abspath(project.logo_path)]
    if bg_wav:
        cmd += ["-i", os.path.abspath(bg_wav)]
    if use_orig and mask_wav:
        cmd += ["-i", os.path.abspath(mask_wav)]
    if sub_list:
        cmd += ["-f", "concat", "-safe", "0", "-i", os.path.abspath(sub_list)]
    if brand_png:
        cmd += ["-loop", "1", "-i", os.path.abspath(brand_png)]
    for d in extras:
        cmd += ["-loop", "1", "-i", os.path.abspath(d["path"])]
    for it in gs_items:
        cmd += greenscreen.input_args(it)

    graph = ";".join(parts)
    if len(graph) > 6000 and tmp:
        # Windows limits a command line to 32 767 characters; a video with
        # many cuts makes a long filter graph, so pass it in a file instead.
        script = os.path.join(tmp, "graph.txt")
        with open(script, "w", encoding="utf-8") as f:
            f.write(graph)
        if ffmpeg_major_version() >= 7:
            cmd += ["-/filter_complex", script]
        else:
            cmd += ["-filter_complex_script", script]
    else:
        cmd += ["-filter_complex", graph]
    cmd += ["-map", f"[{vout}]", "-map", f"[{aout}]"]
    cmd += _video_codec_args(encoder, opts)
    cmd += output_format_args(project, getattr(opts, "audio_kbps", 0))
    if (opts.title or "").strip():
        cmd += ["-metadata", f"title={opts.title.strip()}"]
    cmd += [
        "-c:a", "aac",
        "-movflags", "+faststart",
        "-t", f"{project.output_duration():.3f}",
        "-progress", "pipe:1", "-nostats",
        os.path.abspath(opts.output_path),
    ]
    return cmd


def render_frame(project: Project, opts: ExportOptions, t: float, out_png: str) -> str:
    """Render the exported picture at timeline time `t` as a PNG (for preview)."""
    if not project.has_video() or not project.video_clips:
        raise ValueError("No video loaded")
    _idx, src = project.timeline_to_source(t)
    tmp = tempfile.mkdtemp(prefix="voxdub_frame_")
    try:
        ass_name = _prepare_overlays(project, opts, tmp, None, opts.burn_subtitles)
        logo = has_logo(project)
        W, H = canvas_size(project, opts)
        sub_png = None
        if opts.burn_subtitles and subrender.available():
            text = subrender.text_at(project.shown_subtitles(), t)
            if text:
                sub_png = subrender.render_png(project, text, W, H,
                                               os.path.join(tmp, "sub.png"), _qt_font(opts))
        brand_png = _brand_png(project, opts, tmp)
        extras = extra_logos(project)
        first_extra = 1 + int(logo) + int(bool(sub_png)) + int(bool(brand_png))
        vparts, vout = video_chain(project, W, H, "src", "1:v" if logo else None, ass_name,
                                   f"{1 + int(logo)}:v" if sub_png else None,
                                   f"{1 + int(logo) + int(bool(sub_png))}:v" if brand_png
                                   else None,
                                   [f"{first_extra + k}:v" for k in range(len(extras))])
        # green screen clips on screen at this time (the right frame of each)
        from . import greenscreen

        total_out = project.output_duration()
        gs_now = []
        for it in greenscreen.items(project):
            at = greenscreen.visible_at(it, t, total_out)
            if at is not None:
                gs_now.append((it, at))
        if gs_now:
            gparts, vout = greenscreen.video_filters(
                [it for it, _a in gs_now], first_extra + len(extras), vout, W, H, total_out,
                fixed_t=t)
            vparts += gparts
        # shift timestamps so subtitles see the timeline time
        graph = ";".join([f"[0:v]setpts=PTS-STARTPTS+{t:.3f}/TB[src]"] + vparts)
        args = ["-ss", f"{max(0.0, src):.3f}", "-i", os.path.abspath(project.video_path)]
        if logo:
            args += ["-loop", "1", "-i", os.path.abspath(project.logo_path)]
        if sub_png:
            args += ["-loop", "1", "-i", sub_png]
        if brand_png:
            args += ["-loop", "1", "-i", brand_png]
        for d in extras:
            args += ["-loop", "1", "-i", os.path.abspath(d["path"])]
        for it, at in gs_now:
            args += ["-ss", f"{max(0.0, at):.3f}", "-i", os.path.abspath(it["path"])]
        args += ["-filter_complex", graph, "-map", f"[{vout}]", "-frames:v", "1",
                 os.path.abspath(out_png)]
        run_ffmpeg(args, cwd=tmp)
        return out_png
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


class ExportFailed(FFmpegError):
    def __init__(self, msg, progressed: float):
        super().__init__(msg)
        self.progressed = progressed     # fraction of the video already encoded


def _run_with_progress(cmd, cwd, total, progress, should_stop, label="Encoding", base=10):
    log_path = os.path.join(cwd, "ffmpeg_log.txt")
    reached = 0.0
    with open(log_path, "w", encoding="utf-8", errors="replace") as log:
        proc = subprocess.Popen(
            cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=log,
            creationflags=no_window(), text=True, encoding="utf-8", errors="replace",
        )
        for line in proc.stdout:
            if should_stop and should_stop():
                proc.terminate()
                proc.wait()
                raise InterruptedError("Export cancelled")
            line = line.strip()
            if line.startswith("out_time_us=") or line.startswith("out_time_ms="):
                try:
                    us = int(line.split("=", 1)[1])
                except ValueError:
                    continue
                reached = us / 1e6 / max(total, 0.01)
                pct = min(99, int(reached * 100))
                if progress:
                    progress(base + int(pct * (100 - base) / 100),
                             f"{label}... {_hms(us / 1e6)} / {_hms(total)}")
        proc.wait()
    if proc.returncode != 0:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            tail = "\n".join(f.read().strip().splitlines()[-12:])
        raise ExportFailed(f"ffmpeg export failed (code {proc.returncode}):\n{tail}", reached)


def _hms(t: float) -> str:
    t = int(t)
    return f"{t // 3600}:{t % 3600 // 60:02d}:{t % 60:02d}" if t >= 3600 else f"{t // 60}:{t % 60:02d}"


LOUDNESS = -15.0                        # LUFS: YouTube -14, TikTok / Facebook about -14..-16
LOUD_KEEP = 1.0                         # closer than this: left as it is


def match_loudness(project: Project, path: str, target: float = LOUDNESS,
                   kbps: int = 0) -> str:
    """Bring the sound of a finished video to `target` LUFS (one even gain for
    the whole video, then the -1 dB limiter): the picture is copied, only the
    sound is made again. Returns a warning ("" = done or not needed)."""
    from .qc import measure_audio

    m = measure_audio(path)
    if not m or m["lufs"] <= -60:               # no sound / cannot be measured
        return ""
    gain = max(-12.0, min(15.0, target - m["lufs"]))
    if abs(gain) < LOUD_KEEP:
        return ""
    tmp = os.path.splitext(path)[0] + ".loud.mp4"
    args = output_format_args(project, kbps)
    if "-r" in args:                            # (the picture is copied)
        i = args.index("-r")
        del args[i:i + 2]
    try:
        run_ffmpeg(["-y", "-i", os.path.abspath(path), "-map", "0", "-c", "copy",
                    "-af", f"volume={gain:.2f}dB,"
                           f"alimiter=limit={LIMIT:.3f}:level=0:attack=5:release=60",
                    "-c:a", "aac"] + args + ["-movflags", "+faststart", tmp])
        os.replace(tmp, path)
    except Exception as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        return f"The sound level could not be evened out ({str(e)[:80]}).\n"
    print(f"[export] loudness {m['lufs']:.1f} -> {target:.1f} LUFS ({gain:+.1f} dB)")
    return ""


def export_video(
    project: Project,
    opts: ExportOptions,
    progress: Optional[Callable[[int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> dict:
    """Render the final video. Returns {"video": path, "srt": path|None, "warning": str}."""
    if not project.has_video() or not project.video_clips:
        raise ValueError("No video loaded")

    def report(p, m):
        if progress:
            progress(p, m)

    out_dir = os.path.dirname(os.path.abspath(opts.output_path))
    os.makedirs(out_dir, exist_ok=True)
    # temp files (AI voice mix ~600 MB for 2 h) go next to the output video,
    # not on C:, which is often the fullest drive
    try:
        tmp = tempfile.mkdtemp(prefix="voxdub_export_", dir=out_dir)
    except OSError:
        tmp = tempfile.mkdtemp(prefix="voxdub_export_")
    total = project.sequence_duration()
    warning = ""
    used = "x264"
    try:
        report(2, "Mixing AI voice track...")
        dub_wav = render_dub_mix(project, os.path.join(tmp, "dub_mix.wav"), total,
                                 should_stop=should_stop)
        mask_wav = music_wav = None
        if project.has_audio and opts.original_volume > 0.001:
            if getattr(project, "bg_mode", "original") == "music":
                # Background: music & effects only (made once, then reused)
                from .separate import make_music_track

                music_wav = make_music_track(
                    project, lambda p, m: report(3 + p * 5 // 100, m), should_stop)
                # duck the music & effects under the AI voice (clear voice, and
                # what is left of the original voices is not heard under it)
                from .sync import MUSIC_DUCK

                mask_wav = render_speech_mask(project, os.path.join(tmp, "music_duck.wav"),
                                              total, floor=MUSIC_DUCK)
            else:
                report(5, "Preparing original audio...")
                mask_wav = render_speech_mask(project, os.path.join(tmp, "speech_mask.wav"),
                                              total)

        # the .srt keeps every line not hidden one by one (even with "Hide subtitles")
        subs = [c for c in project.subtitles_sorted() if not c.hidden and c.text.strip()]
        srt_name = "subs.srt"
        write_srt(subs, os.path.join(tmp, srt_name), limit=total, speed=project.speed())
        sub_list = _sub_track(project, opts, tmp, total, opts.burn_subtitles)
        brand_png = _brand_png(project, opts, tmp)
        ass_name = _prepare_overlays(project, opts, tmp, total, opts.burn_subtitles)

        # a long film cut / slowed in many places: lay the timeline out first
        build, timeline_sound = project, None
        if needs_timeline_pass(project):
            build, timeline_sound = _timeline_pass(project, opts, tmp, music_wav, report,
                                                   should_stop)
            music_wav = None            # (already in timeline_sound)

        # Try the best combination first, then fall back:
        #   NVENC -> x264 (GPU encoder missing / driver too old)
        #   burned text -> no burned text (ffmpeg build without libass)
        encoder = pick_encoder(opts.encoder)
        attempts = [(encoder, ass_name)]
        if encoder == "nvenc":
            attempts.append(("x264", ass_name))
        if ass_name and not opts.watermark:     # (the trial watermark is never dropped)
            attempts.append(("x264", None))
        # written under a temporary name: a cancelled / failed export never
        # leaves a broken video that looks finished
        final = os.path.abspath(opts.output_path)
        partial = os.path.splitext(final)[0] + ".part.mp4"
        import dataclasses
        opts = dataclasses.replace(opts, output_path=partial)
        last_err = None
        for k, (enc, ass) in enumerate(attempts):
            label = "Encoding on NVIDIA GPU" if enc == "nvenc" else "Encoding on CPU"
            report(8, f"Starting ffmpeg ({'NVENC' if enc == 'nvenc' else 'x264'})...")
            cmd = _build_command(build, opts, dub_wav, ass, enc, mask_wav, tmp, music_wav,
                                 sub_list, brand_png, timeline_sound)
            try:
                _run_with_progress(cmd, tmp, project.output_duration(), progress,
                                   should_stop, label, 40 if build is not project else 10)
                used = enc
                break
            except ExportFailed as e:
                last_err = e
                if e.progressed > 0.03 or k == len(attempts) - 1:
                    raise           # failed part-way (disk full ...): do not start over
                if enc == "nvenc":
                    warning += ("NVIDIA encoder failed, used the CPU instead "
                                "(update the NVIDIA driver or install the full ffmpeg build).\n")
                elif ass and not attempts[k + 1][1]:
                    warning += ("Subtitles / brand text could not be burned into the video "
                                "(this ffmpeg build may lack libass). Exported without them; "
                                "the .srt file was saved next to the video.\n")
        else:
            raise last_err
        os.replace(partial, final)
        opts = dataclasses.replace(opts, output_path=final)
        if opts.loudness and not (should_stop and should_stop()):
            report(98, "Making the sound as loud as YouTube / TikTok expect...")
            warning += match_loudness(project, final, opts.loudness, opts.audio_kbps)

        srt_out = None
        # (trial = watermark: no separate subtitle file)
        if opts.export_srt and subs and not opts.watermark:
            srt_out = os.path.splitext(os.path.abspath(opts.output_path))[0] + ".srt"
            shutil.copyfile(os.path.join(tmp, srt_name), srt_out)

        mp3_out = None
        if opts.export_mp3 and not opts.watermark:
            report(99, "Saving the MP3...")
            mp3_out = os.path.splitext(os.path.abspath(opts.output_path))[0] + ".mp3"
            run_ffmpeg(["-y", "-i", os.path.abspath(opts.output_path), "-vn",
                        "-c:a", "libmp3lame", "-q:a", "2", mp3_out])

        report(100, "Export finished")
        return {"video": os.path.abspath(opts.output_path), "srt": srt_out, "mp3": mp3_out,
                "warning": warning.strip(), "encoder": used}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
        part = locals().get("partial")
        if part and os.path.isfile(part):
            try:
                os.remove(part)
            except OSError:
                pass
