"""
hardsub.py - Find the original subtitles burned into the video picture
(e.g. Chinese drama subtitles), so they can be blurred / covered and our
subtitles put in the same place.

Burned-in subtitles are bright text with a dark outline that sits in the
SAME rows in most frames, while the picture behind changes. We sample frames
across the video, mark bright pixels that have a dark pixel right next to
them, and keep the rows that are "text-like" in many frames.
"""

import subprocess
from typing import Callable, List, Optional

import numpy as np

from .media import no_window, find_ffmpeg, get_media_info

SAMPLE_WIDTH = 360


def _grab_gray(path: str, t: float, width: int = SAMPLE_WIDTH) -> Optional[np.ndarray]:
    """One frame at time t as a grayscale array `width` px wide."""
    cmd = [find_ffmpeg(), "-hide_banner", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", path,
           "-frames:v", "1", "-vf", f"scale={width}:-2,format=gray",
           "-f", "rawvideo", "pipe:1"]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          creationflags=no_window())
    data = np.frombuffer(proc.stdout, dtype=np.uint8)
    if proc.returncode != 0 or len(data) < width * 8 or len(data) % width:
        return None
    return data.reshape(-1, width)


def picture_area(frames: List[np.ndarray]) -> tuple:
    """(top, bottom, left, right) rows / columns of the SHARP picture: a video
    reframed with a blurred background (or black bars) has flat bands around
    it, where there is no detail in any frame."""
    h, w = frames[0].shape
    gx = np.zeros((h, w))
    for g in frames:
        f = g.astype(np.float32)
        d = np.zeros_like(f)
        d[:, 1:] += np.abs(f[:, 1:] - f[:, :-1])
        d[1:] += np.abs(f[1:] - f[:-1])
        gx += d
    gx /= len(frames)

    def span(profile):
        """The bands at both ends with almost no detail - only when they
        are about the same size (Reframe / letterbox put the picture in
        the middle), else the whole frame."""
        n = len(profile)
        ref = np.percentile(profile, 90)
        on = np.flatnonzero(profile > max(1.5, ref * 0.1))
        if len(on) == 0:
            return 0, n
        a, b = int(on[0]), int(on[-1]) + 1
        if b - a < n * 0.25 or abs(a - (n - b)) > n * 0.04 or min(a, n - b) < n * 0.03:
            return 0, n
        return a, b

    top, bottom = span(gx.mean(axis=1))
    left, right = span(gx.mean(axis=0))
    return top, bottom, left, right


def text_mask(gray: np.ndarray) -> np.ndarray:
    """Bright pixels with a dark pixel within 2 px (outlined subtitle text)."""
    bright = gray > 185
    dark = gray < 80
    near = np.zeros_like(dark)
    for d in (1, 2):
        near[d:] |= dark[:-d]
        near[:-d] |= dark[d:]
        near[:, d:] |= dark[:, :-d]
        near[:, :-d] |= dark[:, d:]
    return bright & near


def _bands(profile: np.ndarray, thr: float, gap: int) -> List[tuple]:
    """Contiguous row ranges where profile > thr (gaps up to `gap` rows bridged)."""
    rows = np.flatnonzero(profile > thr)
    if len(rows) == 0:
        return []
    bands, a, b = [], rows[0], rows[0]
    for r in rows[1:]:
        if r - b <= gap:
            b = r
        else:
            bands.append((a, b))
            a = b = r
    bands.append((a, b))
    return bands


OCR_FRAMES = 20


def _ocr_line(frames: List[np.ndarray], area: tuple, progress=None, should_stop=None
              ) -> Optional[tuple]:
    """(y0, y1, x0, x1) in frame px of the subtitle line, found by READING the
    text (RapidOCR): only real Chinese text near the middle counts - faces,
    jewels or costumes never do, and a channel name that never changes (a
    logo) is skipped. None when OCR is not installed or finds no line."""
    try:
        from . import ocr_subs

        if not ocr_subs.available():
            return None
        engine = ocr_subs._ocr()
    except Exception:
        return None
    top, bottom, left, right = area
    ph, pw = bottom - top, right - left
    cx = (left + right) / 2.0
    pick = [frames[int(i)] for i in np.linspace(0, len(frames) - 1,
                                                 min(OCR_FRAMES, len(frames)))]
    hits = []                                   # (frame, y0, y1, x0, x1, text)
    for k, g in enumerate(pick):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        if progress:
            progress(90 + int(9 * k / len(pick)), f"Reading the text {k + 1}/{len(pick)}...")
        img = np.ascontiguousarray(np.repeat(g[top:bottom, left:right, None], 3, axis=2))
        try:
            try:
                res, _ = engine(img, use_cls=False)
            except TypeError:
                res, _ = engine(img)
        except Exception:
            res = None
        for box, text, score in res or []:
            text = (text or "").strip()
            if float(score) < 0.6 or sum(1 for ch in text if ocr_subs._cjk(ch)) < 2:
                continue
            ys = [p[1] + top for p in box]
            xs = [p[0] + left for p in box]
            y0, y1, x0, x1 = min(ys), max(ys), min(xs), max(xs)
            if y1 - y0 > ph * 0.15 or abs((x0 + x1) / 2.0 - cx) > pw * 0.2:
                continue                        # big title / text at the side
            if (y0 + y1) / 2.0 < top + ph * 0.1:
                continue                        # the very top (channel names, titles)
            hits.append((k, y0, y1, x0, x1, text))
    if not hits:
        return None
    # a text that never changes is a logo / channel name, not a subtitle
    counts = {}
    for h in hits:
        counts[h[5]] = counts.get(h[5], 0) + 1
    hits = [h for h in hits if counts[h[5]] <= max(2, len(pick) * 0.4)]
    if not hits:
        return None
    lh = float(np.median([h[2] - h[1] for h in hits]))
    best = None
    for ref in hits:                            # the row with text in the most frames
        yc = (ref[1] + ref[2]) / 2.0
        near = [h for h in hits if abs((h[1] + h[2]) / 2.0 - yc) <= lh * 0.6]
        n = len({h[0] for h in near})
        if best is None or n > best[0]:
            best = (n, near)
    n, line = best
    if n < max(2, int(len(pick) * 0.1)):
        return None
    return (float(np.percentile([h[1] for h in line], 10)),
            float(np.percentile([h[2] for h in line], 90)),
            float(min(h[3] for h in line)), float(max(h[4] for h in line)))


def detect_subtitle_area(
    video_path: str,
    samples: int = 40,
    progress: Optional[Callable[[int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> Optional[List[float]]:
    """Return [x, y, w, h] (fractions of the frame) of the burned-in
    subtitles, or None if none were found.

    Frames are read sharp enough for small subtitles (720 px wide; a tall
    9:16 / 4:5 video is read wider so its picture keeps that detail), only
    the sharp picture counts (not a blurred background / black bars), and
    text in the lower part of the picture, near the middle, counts more -
    where drama subtitles are - than bright details in the scene."""
    info = get_media_info(video_path)
    dur = info.duration
    width = SAMPLE_WIDTH * 2
    if info.width and info.height and info.height > info.width:
        width = min(1080, int(width * info.height / info.width / 1.2) // 2 * 2)
    if info.width:
        width = min(width, max(SAMPLE_WIDTH, info.width // 2 * 2))
    frames = []
    for k, t in enumerate(np.linspace(dur * 0.05, dur * 0.95, samples)):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        g = _grab_gray(video_path, float(t), width)
        if g is not None:
            frames.append(g)
        if progress:
            progress(int((k + 1) * 90 / samples), f"Scanning frame {k + 1}/{samples}...")
    if len(frames) < 4:
        return None
    h, w = frames[0].shape
    frames = [f for f in frames if f.shape == (h, w)]
    top, bottom, left, right = picture_area(frames)
    ph, pw = bottom - top, right - left
    cx = (left + right) / 2.0
    # 1. read the text (OCR): the surest way
    line = _ocr_line(frames, (top, bottom, left, right), progress, should_stop)
    if line is not None:
        y0, y1, x0, x1 = line
        lh = y1 - y0
        pad = max(3.0, lh * 0.35)
        y0, y1 = max(top, y0 - pad), min(bottom, y1 + pad)
        half = max(cx - x0, x1 - cx) + pw * 0.04
        half = min(pw / 2.0, max(half, pw * 0.2))
        if progress:
            progress(100, "Original subtitles found")
        return [round(float(v), 4) for v in
                ((cx - half) / w, y0 / h, 2 * half / w, (y1 - y0) / h)]
    # 2. no OCR: outlined bright text that stays in the same rows
    masks = [text_mask(f) for f in frames]
    # columns: subtitles are centred - the middle of the picture counts most
    xs = np.arange(w)
    colw = np.clip(1.0 - np.abs(xs - cx) / (pw * 0.5), 0.0, 1.0) ** 0.7
    colw[:left] = 0
    colw[right:] = 0
    colw /= max(colw.sum(), 1e-6)
    rows = np.array([(m * colw).sum(axis=1) for m in masks])          # frames x rows
    # subtitles are present in many (not necessarily all) frames; episodes
    # with little dialogue show text in only ~20-25 % of the sampled frames
    profile = np.percentile(rows, 80, axis=0)
    k = max(3, h // 120)
    profile = np.convolve(profile, np.ones(k) / k, mode="same")
    profile[:top + int(ph * 0.06)] = 0                                # ignore the very top
    profile[bottom:] = 0
    # where in the picture: the lower part is where subtitles are
    rel = (np.arange(h) - top) / max(ph, 1)
    prior = np.where(rel >= 0.55, 1.0, np.where(rel >= 0.4, 0.6, 0.3))
    weighted = profile * prior
    peak = weighted.max()
    if profile.max() < 0.006:
        return None
    bands = _bands(weighted, max(0.002, peak * 0.3), gap=max(2, h // 120))
    # a subtitle is a THIN, dense line of text (one or two lines); bright
    # details of the scene (faces, jewels, costumes) spread over a tall area
    thin = [ab for ab in bands if 3 <= ab[1] - ab[0] + 1 <= ph * 0.2] or bands
    a, b = max(thin, key=lambda ab: weighted[ab[0]:ab[1] + 1].mean())
    # it must stand out from the rest of the picture (a pattern everywhere is
    # not a subtitle)
    base = float(np.median(profile[top + int(ph * 0.06):bottom]))
    if profile[a:b + 1].mean() < max(0.006, base * 2.5):
        return None
    band_h = b - a + 1
    if band_h < 3 or band_h > ph * 0.3:
        return None
    pad = max(3, int(band_h * 0.35))
    y0, y1 = max(top, a - pad), min(bottom, b + 1 + pad)

    # horizontal extent: union of where text appears in this band
    cols = np.percentile(np.array([m[a:b + 1].mean(axis=0) for m in masks]), 85, axis=0)
    cols[:left] = 0
    cols[right:] = 0
    hit = np.flatnonzero(cols > max(0.01, cols.max() * 0.08))
    if len(hit) == 0:
        return None
    half = max(cx - hit[0], hit[-1] + 1 - cx) + pw * 0.04
    half = min(pw / 2.0, max(half, pw * 0.2))
    if progress:
        progress(100, "Original subtitles found")
    return [round(float(v), 4) for v in
            ((cx - half) / w, y0 / h, 2 * half / w, (y1 - y0) / h)]


# --------------------------------------------------------------------------- #
# Black bars (letterbox / pillarbox)
# --------------------------------------------------------------------------- #
def detect_black_bars(
    video_path: str,
    samples: int = 6,
    progress: Optional[Callable[[int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
) -> Optional[List[float]]:
    """Black borders around the picture as crop edges [left, top, right, bottom]
    (fractions of the frame), or None when there are none.

    ffmpeg's cropdetect runs on a few short pieces of the video; the union of
    the picture areas is kept, so a dark scene does not count as a border."""
    import re

    info = get_media_info(video_path)
    W, H, dur = info.width, info.height, info.duration
    if W <= 0 or H <= 0:
        return None
    box = None                          # x0, y0, x1, y1 of the real picture
    for k, t in enumerate(np.linspace(dur * 0.1, dur * 0.9, samples)):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        cmd = [find_ffmpeg(), "-hide_banner", "-ss", f"{t:.2f}", "-i", video_path,
               "-t", "1.5", "-an", "-vf", "cropdetect=limit=24:round=2:reset=0",
               "-f", "null", "-"]
        proc = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                              creationflags=no_window())
        found = re.findall(rb"crop=(\d+):(\d+):(\d+):(\d+)", proc.stderr)
        if found:
            w, h, x, y = (int(v) for v in found[-1])
            if w > 0 and h > 0:
                b = (x, y, x + w, y + h)
                box = b if box is None else (min(box[0], b[0]), min(box[1], b[1]),
                                             max(box[2], b[2]), max(box[3], b[3]))
        if progress:
            progress(int((k + 1) * 100 / samples), f"Looking for black bars {k + 1}/{samples}...")
    if box is None:
        return None
    x0, y0, x1, y1 = box
    edges = [x0 / W, y0 / H, (W - x1) / W, (H - y1) / H]
    edges = [round(e, 4) if e >= 0.01 else 0.0 for e in edges]       # ignore 1 % noise
    if not any(edges) or (1 - edges[0] - edges[2]) < 0.4 or (1 - edges[1] - edges[3]) < 0.4:
        return None                     # nothing, or a nearly black video
    return [min(0.45, e) for e in edges]
