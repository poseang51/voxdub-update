"""
speakers.py - Who is speaking? (characters / "cast" for the AI voices)

Every line gets a speaker label (A, B, C ...) so one character keeps ONE
voice all through the video, instead of each line being judged on its own
(a man shouting can sound "female", a woman whispering "male").

How
  1. A voice embedding for every line: the GE2E speaker encoder of
     Resemblyzer (Apache-2.0; 3-layer LSTM on 40 mel bands). Its weights are
     shipped in assets/models/voice_encoder.npz and run here in plain numpy -
     no PyTorch needed, all lines are processed together in one batch.
  2. Lines are clustered by voice (agglomerative, cosine similarity): each
     cluster = one character. Very short lines (< 0.8 s) join the character
     whose voice they are closest to.
  3. Per character: the median pitch of ALL its lines (far steadier than one
     line) gives male / female, and a very high pitch a child. Age "elder"
     cannot be heard reliably, so it is a choice in the Characters tab.

The result is only a starting point: the Characters tab shows every
character with a sample to listen to, and name, gender, age and voice can be
changed by hand (and a line moved to another character).
"""

import os
from typing import Dict, List, Optional, Tuple

import numpy as np

from .media import APP_DIR, read_wav

SR = 16000
N_FFT, HOP, N_MELS = 400, 160, 40
PARTIAL = 160                   # frames = 1.6 s
RATE = 1.3                      # partials per second
MIN_LINE = 0.8                  # s of speech for an own embedding
SIMILAR = 0.10                  # average similarity (after centering) = same person
CHILD_HZ = 350.0                # median pitch of a child (adult women in drama reach ~330)
MALE_MAX, FEMALE_MIN = 150.0, 200.0     # never merge a clearly male with a clearly female voice
MODEL = os.path.join(APP_DIR, "assets", "models", "voice_encoder.npz")
LABELS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

_weights: Optional[dict] = None
_mel_fb: Optional[np.ndarray] = None


# --------------------------------------------------------------------------- #
# features
# --------------------------------------------------------------------------- #
def _hz_to_mel(f):
    f = np.asanyarray(f, dtype=np.float64)
    f_sp = 200.0 / 3
    mels = f / f_sp
    min_log_hz, logstep = 1000.0, np.log(6.4) / 27.0
    min_log_mel = min_log_hz / f_sp
    return np.where(f >= min_log_hz, min_log_mel + np.log(np.maximum(f, 1e-10) / min_log_hz)
                    / logstep, mels)


def _mel_to_hz(m):
    m = np.asanyarray(m, dtype=np.float64)
    f_sp = 200.0 / 3
    freqs = f_sp * m
    min_log_hz, logstep = 1000.0, np.log(6.4) / 27.0
    min_log_mel = min_log_hz / f_sp
    return np.where(m >= min_log_mel, min_log_hz * np.exp(logstep * (m - min_log_mel)), freqs)


def mel_filters() -> np.ndarray:
    """Same as librosa.filters.mel(sr=16000, n_fft=400, n_mels=40) (Slaney)."""
    global _mel_fb
    if _mel_fb is None:
        fft_freqs = np.linspace(0, SR / 2, 1 + N_FFT // 2)
        mel_f = _mel_to_hz(np.linspace(_hz_to_mel(0.0), _hz_to_mel(SR / 2.0), N_MELS + 2))
        fdiff = np.diff(mel_f)
        ramps = mel_f[:, None] - fft_freqs[None, :]
        lower = -ramps[:-2] / fdiff[:-1, None]
        upper = ramps[2:] / fdiff[1:, None]
        w = np.maximum(0, np.minimum(lower, upper))
        w *= (2.0 / (mel_f[2:N_MELS + 2] - mel_f[:N_MELS]))[:, None]
        _mel_fb = w.astype(np.float32)
    return _mel_fb


def mel_spectrogram(wav: np.ndarray) -> np.ndarray:
    """(frames, 40) power mel spectrogram as Resemblyzer computes it."""
    x = np.pad(wav.astype(np.float32), (N_FFT // 2, N_FFT // 2))
    n = 1 + (len(x) - N_FFT) // HOP
    if n <= 0:
        return np.zeros((0, N_MELS), np.float32)
    idx = np.arange(N_FFT)[None, :] + HOP * np.arange(n)[:, None]
    win = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(N_FFT) / N_FFT)).astype(np.float32)
    spec = np.abs(np.fft.rfft(x[idx] * win, axis=1)) ** 2
    return (spec.astype(np.float32) @ mel_filters().T).astype(np.float32)


def _normalize_volume(wav: np.ndarray, target_dbfs: float = -30.0) -> np.ndarray:
    rms = float(np.sqrt(np.mean(wav.astype(np.float64) ** 2))) + 1e-9
    change = target_dbfs - 20 * np.log10(rms)
    return wav if change < 0 else wav * (10 ** (change / 20))


def _partials(n_samples: int) -> List[Tuple[int, int]]:
    """Mel-frame ranges of the 1.6 s partial utterances (Resemblyzer's rule)."""
    n_frames = int(np.ceil((n_samples + 1) / HOP))
    step = max(1, int(np.round((SR / RATE) / HOP)))
    out = [(i, i + PARTIAL) for i in range(0, max(1, n_frames - PARTIAL + step + 1), step)]
    last = out[-1]
    cover = (n_frames - last[0]) / PARTIAL
    if cover < 0.75 and len(out) > 1:
        out = out[:-1]
    return out


# --------------------------------------------------------------------------- #
# the encoder (numpy LSTM)
# --------------------------------------------------------------------------- #
def _model() -> dict:
    global _weights
    if _weights is None:
        with np.load(MODEL) as z:
            _weights = {k: z[k] for k in z.files}
    return _weights


def _sigmoid(x):
    return 0.5 * (1.0 + np.tanh(0.5 * x))      # = 1/(1+e^-x) without overflow


def encode(mels: np.ndarray) -> np.ndarray:
    """(B, 160, 40) mel partials -> (B, 256) L2-normed embeddings."""
    w = _model()
    x = mels.astype(np.float32)
    B, T, _ = x.shape
    for layer in range(3):
        wih, whh, b = w[f"w_ih{layer}"], w[f"w_hh{layer}"], w[f"b{layer}"]
        H = whh.shape[1]
        pre = x @ wih.T + b                 # (B, T, 4H) input part for all steps at once
        h = np.zeros((B, H), np.float32)
        c = np.zeros((B, H), np.float32)
        outs = np.empty((B, T, H), np.float32) if layer < 2 else None
        for t in range(T):
            g = pre[:, t] + h @ whh.T
            i, f, gg, o = g[:, :H], g[:, H:2 * H], g[:, 2 * H:3 * H], g[:, 3 * H:]
            c = _sigmoid(f) * c + _sigmoid(i) * np.tanh(gg)
            h = _sigmoid(o) * np.tanh(c)
            if outs is not None:
                outs[:, t] = h
        if outs is not None:
            x = outs
    e = np.maximum(0.0, h @ w["lin_w"].T + w["lin_b"])
    return e / (np.linalg.norm(e, axis=1, keepdims=True) + 1e-9)


def embed_lines(audio: np.ndarray, spans: List[Tuple[float, float]],
                progress=None, should_stop=None) -> List[Optional[np.ndarray]]:
    """One embedding per (start, end) span of 16 kHz audio (None if too short)."""
    parts, owner = [], []
    for k, (a, b) in enumerate(spans):
        if b - a < MIN_LINE:
            continue
        wav = _normalize_volume(audio[int(a * SR):int(b * SR)])
        mel = mel_spectrogram(wav)
        for s, e in _partials(len(wav)):
            m = mel[s:e]
            if len(m) < PARTIAL:
                m = np.pad(m, ((0, PARTIAL - len(m)), (0, 0)))
            parts.append(m)
            owner.append(k)
    out: List[Optional[np.ndarray]] = [None] * len(spans)
    if not parts:
        return out
    embs = []
    batch = 256
    for i in range(0, len(parts), batch):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        embs.append(encode(np.stack(parts[i:i + batch])))
        if progress:
            progress(int(80 * min(1.0, (i + batch) / len(parts))),
                     f"Listening to the voices ({min(len(parts), i + batch)}/{len(parts)})")
    embs = np.concatenate(embs)
    owner = np.array(owner)
    for k in set(owner.tolist()):
        e = embs[owner == k].mean(axis=0)
        out[k] = e / (np.linalg.norm(e) + 1e-9)
    return out


# --------------------------------------------------------------------------- #
# clustering
# --------------------------------------------------------------------------- #
def center(embs: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Remove what all lines of a video share (music, room, microphone) so
    what is left is mostly the person. Returns (centered + normed, mean)."""
    mean = embs.mean(axis=0) if len(embs) >= 8 else np.zeros(embs.shape[1], np.float32)
    x = embs - mean
    return x / (np.linalg.norm(x, axis=1, keepdims=True) + 1e-9), mean


def cluster(embs: np.ndarray, pitches: Optional[List[float]] = None,
            similar: float = SIMILAR) -> List[int]:
    """Average-linkage clustering on cosine similarity of (centered) line
    embeddings. Two groups whose median pitch is clearly male vs clearly
    female are never merged. Returns a group id per line."""
    n = len(embs)
    if n == 0:
        return []
    S = (embs @ embs.T).astype(np.float64)
    np.fill_diagonal(S, -np.inf)
    size = np.ones(n)
    alive = np.ones(n, bool)
    members = [[i] for i in range(n)]
    f0 = [[p] if p else [] for p in (pitches or [0.0] * n)]

    def side(i):
        if not f0[i]:
            return 0
        m = float(np.median(f0[i]))
        return -1 if m < MALE_MAX else (1 if m > FEMALE_MIN else 0)

    while alive.sum() > 1:
        k = int(np.argmax(S))
        a, b = divmod(k, n)
        if not np.isfinite(S[a, b]) or S[a, b] < similar:
            break
        if side(a) * side(b) < 0:           # man + woman: not the same person
            S[a, b] = S[b, a] = -np.inf      # (stays banned after later merges)
            continue
        # Lance-Williams update for average linkage
        row = (size[a] * S[a] + size[b] * S[b]) / (size[a] + size[b])
        row[~alive] = -np.inf
        S[a], S[:, a] = row, row
        S[a, a] = -np.inf
        S[b], S[:, b] = -np.inf, -np.inf
        alive[b] = False
        size[a] += size[b]
        members[a] += members[b]
        f0[a] += f0[b]
    label = [0] * n
    for g, i in enumerate(np.flatnonzero(alive)):
        for j in members[i]:
            label[j] = g
    return label


AGES = [("child", "Child"), ("young", "Young"), ("adult", "Adult"), ("elder", "Elder")]
GENDERS = [("male", "Male"), ("female", "Female")]
CLONE_FROM = [("auto", "Auto (from the video)"), ("video", "This video"),
              ("file", "My recording"), ("library", "Default Male / Female voice")]
MIN_CLONE = 3.0                 # s of clear lines needed to clone a voice from the video


def _pitch_of(audio, a, b):
    from .gender import estimate_pitch

    return estimate_pitch(audio[int(a * SR):int(b * SR)]) or 0.0


def find_speakers(project, progress=None, should_stop=None, similar: float = SIMILAR) -> int:
    """Give every line a character label (A, B, ...) and fill project.cast.
    Returns the number of characters found. What the user set for a
    character (name, gender, age, voice) is kept when it is found again."""
    segs = sorted((s for s in project.segments if s.text.strip()), key=lambda s: s.start)
    if not segs or not project.original_audio or not os.path.isfile(project.original_audio):
        return 0
    audio, sr = read_wav(project.original_audio)
    if sr != SR:
        n_new = int(len(audio) * SR / sr)
        audio = np.interp(np.linspace(0, len(audio), n_new, endpoint=False),
                          np.arange(len(audio)), audio).astype(np.float32)
    spans = [(max(0.0, s.start - 0.05), s.end + 0.05) for s in segs]
    embs = embed_lines(audio, spans, progress, should_stop)
    pitch = [_pitch_of(audio, s.start, s.end) for s in segs]
    have = [k for k, e in enumerate(embs) if e is not None]
    if not have:
        return 0
    if progress:
        progress(85, "Grouping the voices into characters...")
    X, mean = center(np.stack([embs[k] for k in have]))
    labels = cluster(X, [pitch[k] for k in have], similar)
    n_cl = max(labels) + 1
    cents = np.zeros((n_cl, X.shape[1]))
    for x, l in zip(X, labels):
        cents[l] += x
    cents /= np.linalg.norm(cents, axis=1, keepdims=True) + 1e-9
    seg_cl: Dict[int, int] = {k: l for k, l in zip(have, labels)}
    # short lines: the closest character; too short to hear: like the line before
    for k in range(len(segs)):
        if k in seg_cl:
            continue
        a, b = spans[k]
        if b - a > 0.3:
            # (+0.01: a+0.8-a can be 0.79999 in floating point)
            e = embed_lines(audio, [(a, a + max(MIN_LINE + 0.01, b - a))])[0]
            if e is not None:
                x = e - mean
                seg_cl[k] = int(np.argmax(cents @ (x / (np.linalg.norm(x) + 1e-9))))
                continue
        near = min(seg_cl, key=lambda j: abs(spans[j][0] - a))
        seg_cl[k] = seg_cl[near]
    # A = the character who speaks the most
    talk = np.zeros(n_cl)
    for k, l in seg_cl.items():
        talk[l] += segs[k].end - segs[k].start
    order = [int(c) for c in np.argsort(-talk) if talk[c] > 0]
    name_of = {cl: (LABELS[r] if r < len(LABELS) else f"S{r + 1}") for r, cl in enumerate(order)}
    old = dict(getattr(project, "cast", {}) or {})
    # what the user set for a character goes to the group that has most of
    # its lines now (labels are given again by speaking time)
    kept: Dict[int, dict] = {}
    old_lines: Dict[str, set] = {}
    for s in segs:
        if s.speaker in old and not old[s.speaker].get("auto", True):
            old_lines.setdefault(s.speaker, set()).add(id(s))
    for lab, ids in sorted(old_lines.items(), key=lambda kv: -len(kv[1])):
        best, share = None, 0.0
        for cl in order:
            if cl in kept:
                continue
            n = sum(1 for k, l in seg_cl.items() if l == cl and id(segs[k]) in ids)
            if n / len(ids) > share:
                best, share = cl, n / len(ids)
        if best is not None and share >= 0.3:
            kept[best] = old[lab]
    # man / woman: the AI model (core/gender_ai.py) when it can be used, else pitch
    from . import gender_ai

    use_ai = gender_ai.ensure(
        (lambda p, m: progress(86, m)) if progress else None, should_stop)
    cast = {}
    for r, cl in enumerate(order):
        lab = name_of[cl]
        members = [k for k, l in seg_cl.items() if l == cl]
        ps = [pitch[k] for k in members if pitch[k]]
        f0 = float(np.median(ps)) if ps else 0.0
        p_f = None
        if use_ai:
            if progress:
                progress(88 + 11 * r // max(1, len(order)),
                         f"AI: man or woman? character {r + 1}/{len(order)}...")
            try:
                p_f = gender_ai.judge(audio, [(segs[k].start, segs[k].end) for k in members],
                                      should_stop)
            except InterruptedError:
                raise
            except Exception as e:
                print(f"[gender_ai] {lab}: {e}")
        gender, conf, src = gender_ai.decide(p_f, f0)
        # (a pitch at the top of the range is shouting / a failed estimate, not a child)
        entry = new_character(lab, gender, "child" if CHILD_HZ <= f0 < 395 else "adult")
        entry.update({"gender_conf": conf, "gender_src": src})
        entry.update({"pitch": round(f0), "lines": len(members),
                      "seconds": round(float(talk[cl]), 1),
                      # voice print (core/series.py: the same actor in other episodes)
                      "emb": [round(float(x), 4) for x in cents[cl]]})
        if cl in kept:
            entry.update({k: kept[cl][k] for k in USER_KEYS if k in kept[cl]})
            entry["auto"] = False
        cast[lab] = entry
        for k in members:
            segs[k].speaker = lab
            segs[k].gender = entry["gender"]
    project.cast = cast
    if progress:
        progress(100, f"{len(cast)} characters found")
    return len(cast)


USER_KEYS = ("name", "gender", "age", "voice", "clone", "ref", "ref_text", "shift",
             "auto_name", "shift_hand", "delivery", "pace")


def new_character(label: str, gender: str = "male", age: str = "adult") -> dict:
    return {"name": "", "gender": gender, "age": age, "pitch": 0,
            "lines": 0, "seconds": 0.0, "voice": "", "clone": "auto", "ref": "",
            "ref_text": "", "shift": None, "auto": True}


def recount(project):
    """Update the line count / speaking time of every character (after the
    user moved lines) and drop characters nobody speaks any more."""
    cast = getattr(project, "cast", {}) or {}
    stats: Dict[str, list] = {}
    for s in project.segments:
        if s.speaker:
            st = stats.setdefault(s.speaker, [0, 0.0])
            st[0] += 1
            st[1] += s.end - s.start
    for lab in list(cast):
        if lab not in stats and cast[lab].get("auto", True):
            del cast[lab]
            continue
        n, sec = stats.get(lab, (0, 0.0))
        cast[lab]["lines"], cast[lab]["seconds"] = n, round(sec, 1)


def next_label(project) -> str:
    used = set(getattr(project, "cast", {}) or {})
    for i in range(500):
        lab = LABELS[i] if i < len(LABELS) else f"S{i + 1}"
        if lab not in used:
            return lab
    return f"S{len(used) + 1}"


# --------------------------------------------------------------------------- #
# how a character is shown (easy to read: "Woman 1", a colour, "Sreymom ↑")
# --------------------------------------------------------------------------- #
COLORS = ["#4ea8ff", "#ff7aa8", "#ffb347", "#5fd68a", "#b18cff", "#ff6b6b",
          "#3dd6d0", "#e6d35a", "#ff9ff3", "#9ccc65", "#7f9cff", "#ff8a65"]
KIND = {("male", "child"): "Boy", ("female", "child"): "Girl",
        ("male", "young"): "Young man", ("female", "young"): "Young woman",
        ("male", "elder"): "Old man", ("female", "elder"): "Old woman",
        ("male", "adult"): "Man", ("female", "adult"): "Woman"}
SHIFT_STEPS = [(-20, "Much lower"), (-10, "Lower"), (0, "Normal"), (10, "Higher"),
               (20, "Much higher")]


def _order(label: str) -> int:
    if label in LABELS:
        return LABELS.index(label)
    try:
        return int(label.lstrip("S")) - 1
    except ValueError:
        return sum(map(ord, label))


def color_of(label: str) -> str:
    """One colour per character (the same everywhere: list, table, timeline)."""
    return COLORS[_order(label) % len(COLORS)] if label else "#8b93a3"


def kind_of(c: dict) -> str:
    """'Woman', 'Old man', 'Boy' ..."""
    return KIND.get((c.get("gender") or "male", c.get("age") or "adult"), "Person")


def is_auto_name(name: str) -> bool:
    import re

    return not name or bool(re.fullmatch(r"Character [A-Z0-9]+", name.strip()))


def display(project, label: str) -> str:
    """The name the user sees: their own name, or 'Woman 1', 'Man 2', 'Girl' ...
    (numbered when the video has more than one of the kind)."""
    cast = getattr(project, "cast", {}) or {}
    c = cast.get(label)
    if not c:
        return label
    if not is_auto_name(c.get("name") or ""):
        return c["name"].strip()
    if c.get("auto_name"):                  # the name it has in the whole series
        return c["auto_name"]
    kind = kind_of(c)
    same = sorted((l for l, o in cast.items()
                   if is_auto_name(o.get("name") or "") and kind_of(o) == kind), key=_order)
    if len(same) <= 1:
        return kind
    return f"{kind} {same.index(label) + 1}"


def shift_of(project, label: str) -> int:
    """The character's pitch change in Hz (its own or the automatic one)."""
    c = (getattr(project, "cast", {}) or {}).get(label) or {}
    if getattr(project, "plain_voice", False) and project.tts_engine in ("edge", "azure"):
        # plain voice: no automatic pitch - only one chosen by hand
        return int(c.get("shift") or 0) if c.get("shift_hand") else 0
    if c.get("shift") is not None:
        return int(c["shift"])
    return _auto_shifts(project).get(label, 0)


def shift_arrow(shift: int) -> str:
    if shift >= 15:
        return "⇈"
    if shift >= 3:
        return "↑"
    if shift <= -15:
        return "⇊"
    if shift <= -3:
        return "↓"
    return ""


def shift_word(shift: int) -> str:
    """'a little higher', 'much lower', 'normal' ..."""
    if abs(shift) < 3:
        return "normal"
    word = "higher" if shift > 0 else "lower"
    if abs(shift) >= 15:
        return "much " + word
    return ("a little " if abs(shift) < 8 else "") + word


# --------------------------------------------------------------------------- #
# the voice of a character
# --------------------------------------------------------------------------- #
def _auto_shifts(project) -> Dict[str, int]:
    """Edge / Azure have one male and one female voice per language: give
    characters of the same kind a slightly different pitch so A and B do not
    sound like the same person, and children / elders their own colour."""
    cast = project.cast or {}
    out, used = {}, {}
    steps = [0, -10, 10, -18, 18, -5, 5, -14, 14]
    # pitches set by hand (or kept for a series) are not given again
    fixed = {(c.get("gender"), c.get("age", "adult"), int(c["shift"]))
             for c in cast.values() if c.get("shift") is not None}
    for lab in sorted(cast, key=lambda l: -(cast[l].get("seconds") or 0)):
        c = cast[lab]
        age = c.get("age", "adult")
        base = {"child": 30, "young": 6, "elder": -14}.get(age, 0)
        kind = (c.get("gender"), age)
        n = used.get(kind, 0)
        for _ in range(len(steps)):
            v = max(-40, min(50, base + steps[n % len(steps)]))
            if (kind[0], kind[1], v) not in fixed:
                break
            n += 1
        used[kind] = n + 1
        out[lab] = v
    return out


def voice_of(project, seg) -> str:
    """The voice spec for a line spoken by a known character ("" = none).
    Edge / Azure: '<voice>|pitch=+10Hz'; VoxCPM: 'voxcpm-ref:<wav>' to clone
    the character, or a default voice by gender / age."""
    from .tts import AUTO_VOICE, voice_for_gender

    cast = getattr(project, "cast", {}) or {}
    c = cast.get(getattr(seg, "speaker", ""))
    if not c:
        return ""
    engine = project.tts_engine
    gender = c.get("gender") or "male"
    age = c.get("age") or "adult"
    chosen = c.get("voice") or ""
    if chosen and not _fits(engine, project.target_lang, chosen):
        chosen = ""                     # a voice of another engine: not usable here
    if engine == "voxcpm":
        if chosen:
            return chosen
        how = c.get("clone") or "auto"
        if how == "auto" and project.voice and project.voice != AUTO_VOICE:
            return project.voice        # one VoxCPM voice chosen for the whole video
        if how == "auto" and getattr(project, "voxcpm_two_voices", False):
            # only the Male / Female recordings (as Piseth / Sreymom): every
            # man - child or old too - the Male voice, every woman the Female
            from .voxcpm import _setting_ref

            v = f"voxcpm-{'female' if gender == 'female' else 'male'}"
            if _setting_ref(v)[0]:
                return v
        if how == "file" and c.get("ref"):
            return "voxcpm-ref:" + c["ref"]
        if how == "video" or (how == "auto" and _clonable(project, seg.speaker)):
            return "voxcpm-ref:" + video_ref_path(project, seg.speaker)
        if age == "child":
            v = "voxcpm-child"
        elif age == "elder":
            v = f"voxcpm-elder-{gender}"
        else:
            v = f"voxcpm-{gender}"
        from .voxcpm import _setting_ref

        if how == "auto" and not _setting_ref(v)[0] and _ref_lines(project, seg.speaker):
            # no default recording set up: VoxCPM would invent a NEW voice for
            # every line - a short clip of the actor keeps the character steady
            return "voxcpm-ref:" + video_ref_path(project, seg.speaker)
        return v
    plain = getattr(project, "plain_voice", False) and engine in ("edge", "azure")
    if chosen:
        base = chosen
    elif project.voice and project.voice != AUTO_VOICE:
        base = project.voice
    elif plain:
        # plain voice (as the first VoxDub): every man = Piseth, every woman =
        # Sreymom - a high-pitched man (taken for a child) is still a man
        base = voice_for_gender(engine, project.target_lang, gender)
    else:
        # a child sounds closer to the female voice raised a little
        base = voice_for_gender(engine, project.target_lang,
                                "female" if age == "child" else gender)
    if engine not in ("edge", "azure") or not base:
        return base
    if plain:
        # the voice as it is: no automatic pitch - only one chosen by hand in
        # 👥 Characters for this character (the same in every line / episode)
        hand = int(c.get("shift") or 0) if c.get("shift_hand") else 0
        base = base.split("|")[0]
        return f"{base}|pitch={hand:+d}Hz" if hand else base
    shift = c.get("shift")
    if shift is None:
        # plain voice: Piseth / Sreymom as they are (no automatic pitch)
        shift = 0 if getattr(project, "plain_voice", False) \
            else _auto_shifts(project).get(seg.speaker, 0)
    return f"{base}|pitch={int(shift):+d}Hz" if shift else base


def _fits(engine: str, lang: str, voice: str) -> bool:
    if engine == "voxcpm":
        return voice.startswith("voxcpm-")
    from .tts import voices_for

    return voice in {v for v, _ in voices_for(engine, lang, with_auto=False)}


def _clonable(project, speaker: str) -> bool:
    return sum(s.end - s.start for s in project.segments
               if s.speaker == speaker and s.end - s.start >= 1.0) >= MIN_CLONE


def _ref_lines(project, speaker: str, seconds: float = 12.0) -> list:
    """The character's longest clear lines (up to ~12 s), in time order."""
    lines = sorted((s for s in project.segments if s.speaker == speaker and s.text.strip()),
                   key=lambda s: s.end - s.start, reverse=True)
    picked, total = [], 0.0
    for s in lines:
        if s.end - s.start < 1.0:
            continue
        picked.append(s)
        total += s.end - s.start
        if total >= seconds:
            break
    return sorted(picked, key=lambda s: s.start)


def video_ref_path(project, speaker: str) -> str:
    """cast/<label>_<lines>.wav - the name changes when other lines are used,
    so a character that changed (found again, lines moved) is cut again."""
    import hashlib

    base = project.work_dir or os.path.dirname(project.original_audio or "") or "."
    key = "|".join(f"{s.start:.2f}-{s.end:.2f}" for s in _ref_lines(project, speaker))
    tag = hashlib.md5(key.encode("utf-8")).hexdigest()[:6]
    return os.path.join(base, "cast", f"{speaker}_{tag}.wav")


def ensure_refs(project, voices: List[str]) -> List[str]:
    """Cut the reference recordings that the voices need from the video.
    Returns the characters whose recording could not be made."""
    failed = []
    for v in dict.fromkeys(voices):
        if not v.startswith("voxcpm-ref:"):
            continue
        path = v[len("voxcpm-ref:"):]
        if os.path.isfile(path):
            continue
        for lab in (project.cast or {}):
            if os.path.normcase(video_ref_path(project, lab)) == os.path.normcase(path):
                try:
                    reference_from_video(project, lab, path)
                except Exception as e:
                    print(f"[speakers] voice of {lab} not cut from the video: {e}")
                    failed.append(lab)
                break
    return failed


def reference_from_video(project, speaker: str, out_wav: str, seconds: float = 12.0) -> str:
    """A reference recording of a character cut from the video itself (its
    longest clear lines, up to ~12 s) - so VoxCPM2 speaks Khmer in that
    actor's voice. Loud background music makes it worse: a clean recording
    (Characters tab › My recording) is better."""
    from .media import run_ffmpeg

    picked = _ref_lines(project, speaker, seconds)
    if not picked:
        raise ValueError(f"No line of {speaker} is long enough to clone the voice")
    parts = "".join(f"[0:a]atrim={s.start:.3f}:{s.end:.3f},asetpts=PTS-STARTPTS[p{i}];"
                    for i, s in enumerate(picked))
    concat = "".join(f"[p{i}]" for i in range(len(picked)))
    os.makedirs(os.path.dirname(out_wav) or ".", exist_ok=True)
    run_ffmpeg(["-i", os.path.abspath(project.original_audio), "-filter_complex",
                f"{parts}{concat}concat=n={len(picked)}:v=0:a=1[out]", "-map", "[out]",
                "-ac", "1", "-ar", "16000", os.path.abspath(out_wav)])
    with open(os.path.splitext(out_wav)[0] + ".txt", "w", encoding="utf-8") as f:
        f.write(" ".join(s.text.strip() for s in picked))
    return out_wav


def voice_name(voice: str) -> str:
    """'km-KH-SreymomNeural|pitch=+10Hz' -> 'Sreymom'; a clone -> 'Clone: <name>'."""
    from .tts import split_voice, voice_label

    base = split_voice(voice or "")[0]
    if not base:
        return ""
    try:
        return voice_label(base).split(" (")[0].strip()
    except Exception:
        return base


def voice_summary(project, label: str) -> str:
    """'Sreymom ↑' - the voice a character speaks with, pitch as an arrow."""
    seg = next((s for s in project.segments if s.speaker == label), None)
    if seg is None:
        class _S:                                   # a character without lines yet
            speaker, voice, gender = label, "", ""
        seg = _S()
    try:
        v = voice_of(project, seg) or project.base_voice_for(seg)
    except Exception:
        return ""
    name = voice_name(v)
    if project.tts_engine in ("edge", "azure"):
        arrow = shift_arrow(shift_of(project, label))
        return f"{name} {arrow}".strip()
    return name
