"""
plans.py - the rental plans (Basic / Pro / Studio) and what each one may use.

TESTING: the plan is chosen by hand on the Plan page ("Preview plan"), so
every level can be tried on one PC. Later the plan comes from the licence key
(the key then carries its level) - only `current()` changes for that.
"""

from typing import Dict, List, Tuple

from . import settings

PLANS = ["basic", "pro", "studio"]
PLAN_NAMES = {"basic": "Basic", "pro": "Pro", "studio": "Studio"}
PLAN_WHO = {"basic": "Try it, or dub a few videos a month.",
            "pro": "Dub and edit every day for your page.",
            "studio": "Teams and channels that dub whole series."}

# feature -> lowest plan that has it
FEATURES: Dict[str, str] = {
    "edit": "basic",              # Edit video workspace
    "dub": "basic",               # Dub workspace
    "hd_1080p": "pro",            # export above 720p
    "no_watermark": "pro",
    "gemini": "pro",              # Gemini translation
    "hide_subs": "pro",           # hide the original subtitles (+ auto detect)
    "music_only": "pro",          # take the original voices out
    "extra_logos": "pro",         # more than one logo
    "green_screen": "pro",        # green screen intro / outro / subscribe / logo
    "batch": "studio",            # Batch queue + series cast
    "voice_clone": "studio",      # VoxCPM + Voice Library
    "recap": "pro",               # 🎬 AI Recap (Gemini writes the story)
}
FEATURE_NAMES = {
    "edit": "Edit video (cut, text, music, logos)",
    "dub": "Dub to Khmer + Khmer subtitles",
    "hd_1080p": "Export in 1080p",
    "no_watermark": "No watermark",
    "gemini": "Gemini translation (follows the story)",
    "hide_subs": "Hide old subtitles",
    "music_only": "Music only (original voices taken out)",
    "extra_logos": "More than one logo",
    "green_screen": "Green screen intro / outro / Like & Subscribe",
    "batch": "Batch queue + series cast",
    "voice_clone": "Voice clone (VoxCPM) + Voice Library",
    "recap": "AI Recap (story summary video)",
}
# numbers per plan (shown on the Plan page and in "This month")
LIMITS: Dict[str, Dict[str, str]] = {
    "basic": {"Dubbing per month": "5 hours", "Videos at the same time": "1",
              "Computers per licence": "1", "Export quality": "720p"},
    "pro": {"Dubbing per month": "30 hours", "Videos at the same time": "1",
            "Computers per licence": "1", "Export quality": "1080p"},
    "studio": {"Dubbing per month": "No limit", "Videos at the same time": "up to 4",
               "Computers per licence": "2", "Export quality": "1080p"},
}
DUB_HOURS = {"basic": 5.0, "pro": 30.0, "studio": 0.0}      # 0 = no limit


def is_admin() -> bool:
    """The seller's PC (core/admin.py): everything is open, always."""
    try:
        from . import admin

        return admin.is_owner()
    except Exception:
        return False


def previewing() -> bool:
    """Admin chose "Preview as Basic / Pro / Studio" to see what a customer sees."""
    return bool(settings.get("plan_preview", False))


def locked_plans() -> bool:
    """Plans lock features only in the testing copy (or when the Admin
    previews a plan). SARIKA VOXDUB PRO: every customer has everything."""
    from .appinfo import EDITION

    return bool(EDITION) or (is_admin() and previewing())


def current() -> str:
    if is_admin() and not previewing():
        return "studio"                     # Admin: the biggest plan, nothing locked
    if not locked_plans():
        return "studio"                     # PRO: everything open
    p = settings.get("test_plan", "studio")
    return p if p in PLANS else "studio"


def label() -> str:
    """What the badge says: ADMIN, or the plan (Admin previewing: "PRO · PREVIEW")."""
    if is_admin():
        return f"{PLAN_NAMES[current()]} · preview" if previewing() else "Admin"
    if not locked_plans():
        from .appinfo import EDITION

        return EDITION or "PRO"
    return PLAN_NAMES[current()]


def set_current(plan: str) -> None:
    """Choose a plan to try. On the Admin's PC it is a preview (end_preview
    goes back to everything)."""
    if plan in PLANS:
        settings.set("test_plan", plan)
        settings.set("plan_preview", is_admin())


def end_preview() -> None:
    settings.set("plan_preview", False)


def level(plan: str) -> int:
    return PLANS.index(plan) if plan in PLANS else len(PLANS) - 1


def allows(feature: str, plan: str = "") -> bool:
    need = FEATURES.get(feature, "basic")
    return level(plan or current()) >= level(need)


def needed(feature: str) -> str:
    """Name of the lowest plan that has the feature ("Pro")."""
    return PLAN_NAMES[FEATURES.get(feature, "basic")]


def table() -> List[Tuple[str, List[bool]]]:
    """(feature name, [basic, pro, studio]) for the Plan page."""
    return [(FEATURE_NAMES[f], [allows(f, p) for p in PLANS]) for f in FEATURES]
