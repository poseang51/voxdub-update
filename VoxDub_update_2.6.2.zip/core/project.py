"""
project.py - The project data model (everything the timeline shows) and
save / load to a .json project file.

Time model
----------
* "source time"   = time inside the original video file.
* "timeline time" = time in the edited sequence.

Video clips are laid out back-to-back on the timeline (ripple editing), so a
video clip is described by the part of the source it uses (src_in..src_out).
Audio and subtitle clips are free: they have their own timeline start.
"""

import bisect
import copy
import json
import os
import uuid
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional

PROJECT_VERSION = 2


MIN_SPEED, MAX_SPEED = 0.5, 2.0       # Clip Properties > Video > Speed


def new_id() -> str:
    return uuid.uuid4().hex[:10]


# project-level settings that Undo / Redo also restores (Tools: crop, color, audio)
_LOOK_FIELDS = (
    "crop_left", "crop_top", "crop_right", "crop_bottom", "zoom", "rotate",
    "pan_x", "pan_y", "flip_h", "flip_v",
    "color_auto_saturation", "color_auto_contrast", "color_magic", "color_auto_wb",
    "color_brightness", "color_contrast", "color_saturation", "color_hue", "color_temperature",
    "orig_normalize", "orig_denoise", "orig_fade_in", "orig_fade_out", "original_volume",
    "bg_mode",
    "color_highlights", "color_shadows", "color_tint", "color_gamma",
    "video_fade_in", "video_fade_out", "video_speed", "out_ratio", "ratio_fill",
    "out_width", "out_height", "out_fps", "audio_rate", "audio_channels",
    "orig_denoise_strength", "orig_eq", "orig_eq_preset", "orig_effect",
    "voice_eq", "voice_eq_preset", "voice_effect", "voice_denoise", "voice_denoise_strength",
    "green_overlays",
)
# subtitles / logo dragged in the preview, subtitles hidden: in an undo step
# only when the change was made there (the Style tab spin boxes have no undo,
# so a later Ctrl+Z must not reset them)
_OVERLAY_FIELDS = (
    "subs_hidden", "sub_position", "sub_x", "sub_bottom", "subtitle_scale",
    "logo_corner", "logo_pos", "logo_size", "brand_corner", "brand_pos", "brand_size",
    "extra_logos",
)


def _known(cls, d: dict) -> dict:
    """Keep only the fields `cls` knows (projects saved by newer/older versions)."""
    return {k: v for k, v in d.items() if k in cls.__dataclass_fields__}


@dataclass
class Segment:
    """One transcribed sentence (times are SOURCE times)."""
    id: str
    start: float
    end: float
    text: str
    translation: str = ""
    tts_path: str = ""          # raw generated voice (wav)
    tts_text: str = ""          # the text tts_path was generated from (stale if it differs)
    tts_voice: str = ""         # the voice tts_path was generated with
    gender: str = ""            # "male" / "female" speaker (Voice "Auto"), "" = unknown
    speaker: str = ""           # character label (A, B, ...) – see core/speakers.py
    # Translation table (Sarika Studio style): this line's own voice ("" = the
    # character's / Auto), how it is said and how fast (Edge / Azure)
    voice: str = ""
    delivery: str = "normal"    # see tts.DELIVERY
    pace: str = "normal"        # normal / fast / slow
    delivery_auto: bool = True  # delivery found from the original speech (core/emotion.py);
                                # False = chosen by hand, never changed automatically
    check: str = ""             # Smart Review (2.6.2): why to look at this line -
                                # "nosub" (no subtitle on the video confirms it) /
                                # "unsure" (Whisper is not sure); "" = fine

    def voice_text(self) -> str:
        """What the AI voice should say for this line."""
        return (self.translation or self.text).strip()

    def voice_is_current(self) -> bool:
        return (bool(self.tts_path) and os.path.isfile(self.tts_path)
                and self.tts_text == self.voice_text())


@dataclass
class VideoClip:
    id: str
    src_in: float
    src_out: float
    start: float = 0.0          # computed by Project.layout_video()
    # < 1.0: this piece plays slower, so a long translated line can be spoken
    # at a natural speed (see sync.stretch_video_for_voices)
    speed: float = 1.0
    stretched: bool = False     # made by the automatic slow-down (redone each dub)

    @property
    def rate(self) -> float:
        return max(0.1, float(self.speed or 1.0))

    @property
    def length(self) -> float:
        """Length on the timeline (slowed pieces are longer than in the file)."""
        return max(0.0, self.src_out - self.src_in) / self.rate

    def to_source(self, t: float) -> float:
        """Timeline time inside this clip -> time in the video file."""
        return self.src_in + (t - self.start) * self.rate

    def to_timeline(self, src_t: float) -> float:
        return self.start + (src_t - self.src_in) / self.rate

    @property
    def end(self) -> float:
        return self.start + self.length


@dataclass
class AudioClip:
    id: str
    path: str                   # wav file
    start: float                # timeline position
    src_in: float               # trim inside the wav
    src_out: float
    file_duration: float
    seg_id: str = ""
    volume: float = 1.0
    label: str = ""
    # Audio Properties (Movavi-style)
    normalize: bool = False     # make the line as loud as the others
    fade_in: float = 0.0        # seconds
    fade_out: float = 0.0
    speed: float = 1.0          # 1.0 = as generated; the wav at `path` is already sped up
    base_path: str = ""         # the un-sped wav (speed is always applied to this one)

    @property
    def length(self) -> float:
        return max(0.0, self.src_out - self.src_in)

    @property
    def end(self) -> float:
        return self.start + self.length


@dataclass
class SubtitleClip:
    id: str
    start: float
    end: float
    text: str
    seg_id: str = ""
    hidden: bool = False        # kept, but not shown / burned (e.g. a song, a sign)

    @property
    def length(self) -> float:
        return max(0.0, self.end - self.start)


@dataclass
class Project:
    video_path: str = ""
    work_dir: str = ""
    video_duration: float = 0.0
    width: int = 0
    height: int = 0
    fps: float = 0.0
    has_audio: bool = False
    original_audio: str = ""            # 16 kHz mono wav (whisper + waveform)

    source_lang: str = "auto"
    target_lang: str = "km"
    detected_lang: str = ""
    tts_engine: str = "edge"
    voice: str = "auto"                 # Auto = male / female voice per line
    whisper_model: str = "small"
    stt_engine: str = "whisper"         # whisper (offline) / gemini (API key)
    translate_engine: str = "google"    # google (free) / gemini (API key, follows the story)
    engine_notes: List[str] = field(default_factory=list)   # automatic engine fallbacks
    # Auto Dub / Batch (2.6.2): lines taken out as noise - no subtitle on the
    # video shows them and they are a grunt or a scrap of 1-4 letters.
    # Kept here ({"start", "end", "text"}) so nothing heard is lost.
    noise_lines: List[dict] = field(default_factory=list)
    cast: Dict[str, dict] = field(default_factory=dict)     # characters: label -> settings
    # one cast for a whole series (core/series.py): the file every episode
    # takes its characters from and teaches its new ones to ("" = not used)
    series_cast: str = ""
    face_swap_from: str = ""          # 🎭 Face swap: the original video (video_path = swapped)
    ocr_check: bool = True              # double-check Whisper with the burned-in subtitles
    # 2.6.2: "Original VoxDub" by default - a long line is spoken faster, the
    # video keeps its speed (slowing the video looked like slow motion)
    max_speed: float = 1.5              # the AI voice is sped up at most this much ...
    stretch_video: bool = False         # ... then (if on) the video is slowed where a line is long
    # Edge / Azure: Piseth / Sreymom exactly as they are (the first VoxDub PRO) -
    # no automatic pitch per character, no automatic delivery (happy, sad ...).
    # What was chosen by hand (a character's pitch, a line's delivery) still counts.
    plain_voice: bool = True
    # VoxCPM + Auto: every character speaks with the Male or the Female
    # recording of Voice clone settings (by the character's gender / age) - one
    # character = one voice, never a clip cut from the video
    voxcpm_two_voices: bool = False

    original_volume: float = 0.15       # background original audio in export
    # background of the dubbed video: "original" = the video's own sound (its
    # speech muted where the AI voice talks) / "music" = music & effects only,
    # every original voice removed (core/separate.py)
    bg_mode: str = "original"
    dub_volume: float = 1.0
    mute_original_speech: bool = True   # silence original audio where a line is dubbed
    subtitle_scale: float = 1.0         # burned subtitle size (1.0 = auto for the frame)
    # how the burned subtitles look (Style tab > Subtitles); the preview draws the same
    sub_font: str = ""                  # "" = Noto Sans Khmer for Khmer, else Arial
    sub_color: str = "#FFFFFF"
    sub_bold: bool = False
    sub_outline: float = 2.0            # px of a 288-line frame (0 = none)
    sub_outline_color: str = "#000000"
    sub_shadow: float = 0.0
    sub_box: bool = False               # a box behind the text instead of the outline
    sub_box_color: str = "#000000"
    sub_box_opacity: float = 0.6
    sub_bottom: float = 9.7             # % of the height between the text and the bottom
    subs_hidden: bool = False           # no subtitles in the preview and the export
    sub_x: float = 50.0                 # % of the width: centre of the text (drag in preview)

    # ---- look of the exported video (see core/branding.py)
    cover_enabled: bool = False         # hide the original burned-in subtitles
    cover_rect: List[float] = field(default_factory=lambda: [0.1, 0.78, 0.8, 0.1])  # x,y,w,h (0..1)
    cover_mode: str = "blur"            # blur / box
    sub_position: str = "bottom"        # bottom / cover (put our subtitles over the old ones)
    out_ratio: str = "original"         # original / 9:16 / 16:9 / 1:1 / 4:5 / 4:3 / custom
    ratio_fill: str = "blur"            # blur / black / crop (zoom to fill) / stretch
    # Project settings (Movavi): exact output size (0 = from the ratio / the
    # video), frame rate (0 = same as the video) and audio format
    out_width: int = 0
    out_height: int = 0
    out_fps: float = 0.0
    audio_rate: int = 44100
    audio_channels: int = 2             # 1 mono / 2 stereo / 6 surround 5.1
    crop_left: float = 0.0              # cut off the edges of the picture (0..0.45 of the frame)
    crop_top: float = 0.0
    crop_right: float = 0.0
    crop_bottom: float = 0.0
    zoom: float = 1.0                   # 1.0 .. 3.0 - Scale: zoom into the picture
    rotate: float = 0.0                 # Crop & Rotate: angle in degrees (corners black)
    pan_x: float = 0.0                  # Position of a zoomed picture: -1 (left) .. 1 (right)
    pan_y: float = 0.0                  # -1 (top) .. 1 (bottom)
    flip_h: bool = False                # mirror left <-> right
    flip_v: bool = False                # upside down

    # ---- Color Adjustments (Tools, see core/effects.py)
    color_auto_saturation: bool = False
    color_auto_contrast: bool = False
    color_magic: bool = False           # Magic Enhance
    color_auto_wb: bool = False         # auto white balance
    color_brightness: float = 0.0       # -100 .. 100
    color_contrast: float = 0.0         # -100 .. 100
    color_saturation: float = 0.0       # -100 .. 100
    color_hue: float = 0.0              # -180 .. 180 degrees
    color_temperature: float = 0.0      # -100 (cool) .. 100 (warm)
    color_highlights: float = 0.0       # -100 .. 100
    color_shadows: float = 0.0          # -100 .. 100
    color_tint: float = 0.0             # -100 (green) .. 100 (magenta)
    color_gamma: float = 1.0            # 0.2 .. 3.0

    # ---- Clip Properties > Video: fade the picture in from / out to black
    video_fade_in: float = 0.0
    video_fade_out: float = 0.0
    # Clip Properties > Video: Speed of the whole finished video (picture, original
    # sound, AI voice and subtitles together; the voice keeps its pitch). The
    # timeline stays in the video's own time - the export plays it faster.
    video_speed: float = 1.0

    # ---- Audio Properties of the video's own sound
    orig_normalize: bool = False
    orig_denoise: bool = False          # noise removal
    orig_fade_in: float = 0.0
    orig_fade_out: float = 0.0
    orig_denoise_strength: float = 50.0     # 0 .. 100
    orig_eq: List[float] = field(default_factory=lambda: [0.0] * 10)   # dB per band
    orig_eq_preset: str = "flat"
    orig_effect: str = "none"           # Audio Effects (radio, echo, robot ...)

    # ---- the AI voice track as a whole (Equalizer / Noise Removal / Effects)
    voice_eq: List[float] = field(default_factory=lambda: [0.0] * 10)
    voice_eq_preset: str = "flat"
    voice_effect: str = "none"
    voice_denoise: bool = False
    voice_denoise_strength: float = 50.0
    logo_path: str = ""
    logo_corner: str = "top-right"     # a corner, or "custom" (dragged to logo_pos)
    logo_pos: List[float] = field(default_factory=list)   # [x, y] 0..1 of the free room
    logo_motion: str = "none"           # none / slow / medium / fast (bounces around)
    logo_size: float = 0.18             # fraction of the output width
    logo_opacity: float = 0.9
    # more logos (a sponsor / customer advert next to ours): each a dict with
    # path, corner, pos, motion, size, opacity - placed like the logo above
    extra_logos: List[dict] = field(default_factory=list)
    # green screen clips laid over the export (core/greenscreen.py)
    green_overlays: List[dict] = field(default_factory=list)
    brand_text: str = ""
    brand_corner: str = "top-left"
    brand_pos: List[float] = field(default_factory=list)
    brand_motion: str = "none"
    brand_size: float = 1.0
    brand_color: str = "#FFFFFF"

    # ---- resume support for long videos
    transcribe_done: bool = False       # Whisper finished the whole video
    transcribed_until: float = 0.0      # source seconds already transcribed

    segments: List[Segment] = field(default_factory=list)
    video_clips: List[VideoClip] = field(default_factory=list)
    audio_clips: List[AudioClip] = field(default_factory=list)
    music_clips: List[AudioClip] = field(default_factory=list)     # 🎵 Music track (Edit)
    subtitle_clips: List[SubtitleClip] = field(default_factory=list)

    # ------------------------------------------------------------------ #
    # Timeline helpers
    # ------------------------------------------------------------------ #
    def has_video(self) -> bool:
        return bool(self.video_path) and self.video_duration > 0

    def reset_video_track(self):
        self.video_clips = [VideoClip(new_id(), 0.0, self.video_duration)]
        self.layout_video()

    def layout_video(self):
        """Ripple: put video clips back to back starting at 0."""
        t = 0.0
        for clip in self.video_clips:
            clip.start = t
            t += clip.length
        self._vc_index = None

    def sequence_duration(self) -> float:
        if not self.video_clips:
            return 0.0
        return self.video_clips[-1].end

    def speed(self) -> float:
        """Clip Properties > Video > Speed (0.5 .. 2.0)."""
        try:
            s = float(self.video_speed or 1.0)
        except (TypeError, ValueError):
            return 1.0
        return max(MIN_SPEED, min(MAX_SPEED, s))

    def output_duration(self) -> float:
        """Length of the exported video (the timeline played at speed())."""
        return self.sequence_duration() / self.speed()

    def timeline_length(self) -> float:
        """Visible length of the timeline (video + any audio sticking out)."""
        ends = [self.sequence_duration()]
        ends += [c.end for c in self.audio_clips]
        ends += [c.end for c in self.music_clips]
        ends += [c.end for c in self.subtitle_clips]
        return max(ends) if ends else 0.0

    # A long film slowed for its long lines has thousands of video pieces:
    # look them up by bisection (an index rebuilt when it no longer fits)
    def _clip_index(self, rebuild: bool = False):
        clips = self.video_clips
        idx = getattr(self, "_vc_index", None)
        if rebuild or idx is None or idx[0] is not clips or idx[1] != len(clips):
            srcs = [c.src_in for c in clips]
            mono = all(a <= b for a, b in zip(srcs, srcs[1:]))
            idx = (clips, len(clips), [c.start for c in clips], srcs, mono)
            self._vc_index = idx
        return idx

    def _find_src(self, src_t: float) -> Optional[int]:
        clips = self.video_clips
        for attempt in (0, 1):
            _, _, _, srcs, mono = self._clip_index(rebuild=attempt == 1)
            if not mono:
                break
            i = bisect.bisect_right(srcs, src_t + 1e-6) - 1
            for k in (i, i - 1):        # (the end of the clip before counts too)
                if 0 <= k < len(clips) and \
                        clips[k].src_in - 1e-6 <= src_t <= clips[k].src_out + 1e-6:
                    return k
        for k, clip in enumerate(clips):          # cut away, or clips out of order
            if clip.src_in - 1e-6 <= src_t <= clip.src_out + 1e-6:
                return k
        return None

    def source_to_timeline(self, src_t: float) -> Optional[float]:
        """Map a source time to timeline time (None if that part was cut)."""
        if src_t is None:
            return None
        k = self._find_src(src_t)
        return self.video_clips[k].to_timeline(src_t) if k is not None else None

    def timeline_to_source(self, t: float):
        """Return (clip_index, source_time) for a timeline time."""
        clips = self.video_clips
        for attempt in (0, 1):
            starts = self._clip_index(rebuild=attempt == 1)[2]
            i = bisect.bisect_right(starts, t + 1e-6) - 1
            if 0 <= i < len(clips) and clips[i].start - 1e-6 <= t < clips[i].end:
                return i, clips[i].to_source(t)
        for i, clip in enumerate(clips):
            if clip.start - 1e-6 <= t < clip.end:
                return i, clip.to_source(t)
        if self.video_clips:
            last = self.video_clips[-1]
            return len(self.video_clips) - 1, last.src_out
        return -1, 0.0

    def dubbed_ranges(self, pad: float = 0.15) -> List[tuple]:
        """Timeline (start, end) ranges where the original speech should be
        muted: each dubbed line's original speech plus its AI voice clip.
        Overlapping ranges are merged."""
        if not self.mute_original_speech:
            return []
        ranges = []
        by_id = {s.id: s for s in self.segments}
        for clip in self.audio_clips:
            seg = by_id.get(clip.seg_id) if clip.seg_id else None
            if seg is None:
                continue
            a, b = clip.start, clip.end
            s = self.source_to_timeline(seg.start)
            e = self.source_to_timeline(seg.end)
            if s is not None:
                a = min(a, s)
                b = max(b, e if e is not None else s + (seg.end - seg.start))
            ranges.append((max(0.0, a - pad), b + pad))
        ranges.sort()
        merged = []
        for a, b in ranges:
            if merged and a <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], b))
            else:
                merged.append((a, b))
        return merged

    def segment_by_id(self, seg_id: str) -> Optional[Segment]:
        for s in self.segments:
            if s.id == seg_id:
                return s
        return None

    # ------------------------------------------------------------------ #
    # Progress of the AI steps (used to resume an interrupted Auto Dub)
    # ------------------------------------------------------------------ #
    def autosave_path(self) -> str:
        return os.path.join(self.work_dir, "autosave.voxdub.json") if self.work_dir else ""

    def untranslated(self) -> List[Segment]:
        return [s for s in self.segments if s.text.strip() and not s.translation.strip()]

    def voice_for(self, seg: Segment) -> str:
        """The voice this line should be spoken with (resolves "auto"), with
        the line's delivery / speed (Edge / Azure)."""
        from .tts import with_delivery

        delivery = getattr(seg, "delivery", "normal") or "normal"
        pace = getattr(seg, "pace", "normal") or "normal"
        # 2.2: the character's own delivery / speed (👥 Characters, chosen by hand)
        c = (self.cast or {}).get(seg.speaker or "") or {}
        c_delivery, c_pace = c.get("delivery") or "", c.get("pace") or ""
        voice = self.base_voice_for(seg)
        if getattr(self, "plain_voice", False) and self.tts_engine in ("edge", "azure"):
            # plain voice (as the first VoxDub): Piseth / Sreymom always sound
            # the same - no automatic pitch or delivery; only what was chosen
            # for the whole character in 👥 Characters
            delivery = c_delivery or "normal"
            own = getattr(seg, "voice", "")
            if own and voice == own and not voice.startswith("voxcpm-ref:"):
                voice = voice.split("|")[0]
        elif c_delivery and getattr(seg, "delivery_auto", True):
            delivery = c_delivery           # (a line's own delivery by hand still wins)
        if c_pace and pace == "normal":
            pace = c_pace
        return with_delivery(voice, self.tts_engine, delivery, pace)

    def base_voice_for(self, seg: Segment) -> str:
        """The voice of the line: its own choice, its character's, or Auto."""
        from .tts import AUTO_VOICE, voice_for_gender, voices_for

        own = getattr(seg, "voice", "")
        if own and any(v == own.split("|")[0]
                       for v, _ in voices_for(self.tts_engine, self.target_lang,
                                              with_auto=False)):
            return own
        if seg.speaker and seg.speaker in self.cast:
            from .speakers import voice_of

            v = voice_of(self, seg)        # one character = one voice all through
            if v:
                return v
        if self.voice == AUTO_VOICE:
            return voice_for_gender(self.tts_engine, self.target_lang, seg.gender or "male")
        if self.voice:
            return self.voice
        voices = voices_for(self.tts_engine, self.target_lang, with_auto=False)
        return voices[0][0] if voices else ""

    def voice_current(self, seg: Segment) -> bool:
        """Voice exists, matches the text, and was made with the wanted voice
        (lines voiced before the voice was recorded count as current)."""
        return seg.voice_is_current() and (not seg.tts_voice
                                           or seg.tts_voice == self.voice_for(seg))

    def stale_voices(self) -> List[Segment]:
        """Lines whose AI voice is missing, was made from older text, or with
        another voice than the one chosen now."""
        return [s for s in self.segments if s.voice_text() and not self.voice_current(s)]

    def progress_summary(self) -> dict:
        n = len(self.segments)
        return {
            "lines": n,
            "transcribed": self.transcribe_done,
            "transcribed_until": self.transcribed_until,
            "translated": n - len(self.untranslated()),
            "voiced": n - len(self.stale_voices()),
        }

    def is_complete(self) -> bool:
        return (self.transcribe_done and bool(self.segments)
                and not self.untranslated() and not self.stale_voices())

    def has_progress(self) -> bool:
        return bool(self.segments) or self.transcribed_until > 0

    def subtitles_sorted(self) -> List[SubtitleClip]:
        return sorted(self.subtitle_clips, key=lambda c: c.start)

    def shown_subtitles(self) -> List[SubtitleClip]:
        """The subtitles that are shown / burned: none when subtitles are
        hidden, else all but the lines hidden one by one."""
        if self.subs_hidden:
            return []
        return [c for c in self.subtitles_sorted() if not c.hidden and c.text.strip()]

    # ------------------------------------------------------------------ #
    # Undo snapshots (only the editable parts)
    # ------------------------------------------------------------------ #
    def snapshot(self, overlay: bool = False) -> dict:
        snap = self._snapshot()
        if overlay:
            snap["overlay"] = {f: copy.deepcopy(getattr(self, f)) for f in _OVERLAY_FIELDS}
        return snap

    def _snapshot(self) -> dict:
        return {
            "segments": [asdict(s) for s in self.segments],
            "video_clips": [asdict(c) for c in self.video_clips],
            "audio_clips": [asdict(c) for c in self.audio_clips],
            "music_clips": [asdict(c) for c in self.music_clips],
            "subtitle_clips": [asdict(c) for c in self.subtitle_clips],
            "look": {f: copy.deepcopy(getattr(self, f)) for f in _LOOK_FIELDS},
            "cast": copy.deepcopy(self.cast),
        }

    def restore(self, snap: dict):
        snap = copy.deepcopy(snap)
        self.segments = [Segment(**d) for d in snap["segments"]]
        self.video_clips = [VideoClip(**d) for d in snap["video_clips"]]
        self.audio_clips = [AudioClip(**d) for d in snap["audio_clips"]]
        self.music_clips = [AudioClip(**d) for d in snap.get("music_clips", [])]
        self.subtitle_clips = [SubtitleClip(**d) for d in snap["subtitle_clips"]]
        if "cast" in snap:
            self.cast = snap["cast"]
        for k, v in snap.get("overlay", {}).items():
            if k in _OVERLAY_FIELDS:
                setattr(self, k, v)
        for k, v in snap.get("look", {}).items():
            if k in _LOOK_FIELDS:
                setattr(self, k, v)
        self.layout_video()

    # ------------------------------------------------------------------ #
    # Save / Load
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict:
        d = asdict(self)
        d["version"] = PROJECT_VERSION
        d["voice_rule"] = 2
        d["app"] = "SARIKA VOXDUB PRO"
        return d

    def save(self, path: str, backup: float = -1):
        """Write the project. Goes through a temp file so a crash or power cut
        while saving never leaves a half-written (unreadable) project.
        backup >= 0: keep the file that was there in backups/ (core/backup.py),
        if the last backup is older than `backup` seconds."""
        if backup >= 0:
            from .backup import keep

            keep(path, min_age=backup)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)

    @classmethod
    def from_dict(cls, d: dict) -> "Project":
        d = dict(d)
        version = d.pop("version", 1)
        d.pop("app", None)
        old_format = version < 2
        raw_segs = d.pop("segments", [])
        segs = [Segment(**_known(Segment, s)) for s in raw_segs]
        for s, r in zip(segs, raw_segs):
            if "delivery_auto" not in r and s.delivery != "normal":
                s.delivery_auto = False             # (older projects: chosen by hand)
        vcs = [VideoClip(**_known(VideoClip, c)) for c in d.pop("video_clips", [])]
        acs = [AudioClip(**_known(AudioClip, c)) for c in d.pop("audio_clips", [])]
        mcs = [AudioClip(**_known(AudioClip, c)) for c in d.pop("music_clips", [])]
        scs = [SubtitleClip(**_known(SubtitleClip, c)) for c in d.pop("subtitle_clips", [])]
        known = {f for f in cls.__dataclass_fields__}
        p = cls(**{k: v for k, v in d.items() if k in known})
        p.segments, p.video_clips, p.audio_clips, p.subtitle_clips = segs, vcs, acs, scs
        p.music_clips = mcs
        if "voice_rule" not in d:
            # saved before the "plain voice as the first VoxDub" rule: Piseth /
            # Sreymom with no pitch changes (re-voice to hear it)
            p.plain_voice = True
        if "stretch_video" not in d:
            # saved before the natural-voice change: a long line was sped up to
            # 1.5 x (and Edge to +40 %) - too fast to follow. A new dub of this
            # project slows the video instead.
            p.max_speed = min(p.max_speed, 1.1)
            p.stretch_video = True          # as they were dubbed (the old default)
        if old_format:
            # projects from before resume support: what exists is finished work
            if segs and "transcribe_done" not in d:
                p.transcribe_done = True
                p.transcribed_until = p.video_duration
            for seg in segs:
                if seg.tts_path and not seg.tts_text:
                    seg.tts_text = seg.voice_text()
        p.layout_video()
        return p

    @classmethod
    def load(cls, path: str) -> "Project":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        p = cls.from_dict(data)
        p.load_warnings = p._relocate(os.path.dirname(os.path.abspath(path)))
        if p.video_path and not os.path.isfile(p.video_path):
            raise FileNotFoundError(
                f"The video of this project is missing:\n{p.video_path}\n\n"
                "Put it back in that place (or next to the project file) and open again.")
        return p

    def _relocate(self, here: str) -> List[str]:
        """The project folder was moved / copied to another drive or PC: find
        its files in the new place. Voice files that are really gone are
        dropped (those lines are voiced again). Returns what is missing."""
        old = self.work_dir

        def moved(path: str) -> str:
            if not path or os.path.isfile(path):
                return path
            if old and os.path.normcase(path).startswith(os.path.normcase(old)):
                cand = os.path.join(here, os.path.relpath(path, old))
                if os.path.isfile(cand):
                    return cand
            for folder in (here, os.path.dirname(here)):
                cand = os.path.join(folder, os.path.basename(path.replace("\\", "/")))
                if os.path.isfile(cand):
                    return cand
            return path

        if old and not os.path.isdir(old) and os.path.isdir(here):
            self.work_dir = here
        self.video_path = moved(self.video_path)
        self.original_audio = moved(self.original_audio)
        lost = []
        for s in self.segments:
            if s.tts_path:
                s.tts_path = moved(s.tts_path)
                if not os.path.isfile(s.tts_path):
                    s.tts_path = ""
        keep = []
        for c in self.audio_clips:
            c.path = moved(c.path)
            if os.path.isfile(c.path):
                keep.append(c)
            else:
                lost.append(c.path)
        self.audio_clips = keep
        if lost:
            return [f"{len(lost)} AI voice file(s) were missing - click 3 · Voice to make them "
                    "again"]
        return []
