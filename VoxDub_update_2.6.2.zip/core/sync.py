"""
sync.py - Fit generated voices into the original speech timing, build the
timeline clips, mix the dub track and write SRT subtitles.
"""

import dataclasses
import os
from typing import Callable, Dict, List, Optional

import numpy as np

from .media import (
    WavWriter, change_speed, format_time, read_wav, read_wav_range, wav_duration, write_wav,
)
from .project import AudioClip, Project, Segment, SubtitleClip, new_id

MIX_RATE = 44100
MIN_VIDEO_SPEED = 0.75      # slowed at most to 3/4 speed (half speed looked like slow motion)
LAST_RESORT_SPEED = 1.25    # a line still too long after that: a bit faster, then cut
# Smart sync (2.1): a line that is a little too long starts up to this much
# earlier, in the silence before it, instead of being sped up / the video slowed
MAX_LEAD = 0.35
LEAD_GAP = 0.08             # silence kept after the previous voice


def lead_room(prev_end: Optional[float], start: float, need: float) -> float:
    """Seconds a voice may start before its line (0 when there is no silence).
    prev_end: where the previous voice ends (None = nothing before it)."""
    free = start - (prev_end if prev_end is not None else 0.0) - LEAD_GAP
    return round(max(0.0, min(MAX_LEAD, free, need)), 3)


def voice_slot(seg: Segment, next_start: Optional[float], limit: Optional[float] = None) -> float:
    """Seconds the voice of `seg` may last: the segment itself, extended into
    the silence before the next line (or to `limit`, the video end)."""
    slot = seg.end - seg.start
    if next_start is not None:
        slot = max(slot, next_start - seg.start - 0.05)
    elif limit is not None:
        slot = max(slot, limit - seg.start)
    else:
        slot = float("inf")    # last line: no neighbour to collide with
    return max(slot, 0.2)


def _fade_trim(path: str, length: float, fade: float = 0.08) -> None:
    """Cut a wav to `length` seconds with a short fade-out (no click)."""
    data, sr = read_wav(path)
    n = int(length * sr)
    if n >= len(data):
        return
    data = data[:n].copy()
    f = min(n, int(fade * sr))
    if f > 0:
        data[-f:] *= np.linspace(1.0, 0.0, f, dtype=np.float32)
    write_wav(path, data, sr)


def fit_voice(seg: Segment, next_start: Optional[float], max_speed: float,
              limit: Optional[float] = None, slot: Optional[float] = None) -> str:
    """Make the voice of `seg` fit its time slot.

    Speeds it up (max `max_speed`) and, if it is still too long, cuts the
    end so it never runs over the next line. Returns the wav to use.
    slot: seconds on the timeline (the video may be slowed there) - else
    measured in the video from next_start / limit.
    """
    raw = seg.tts_path
    dur = wav_duration(raw)
    if slot is None:
        slot = voice_slot(seg, next_start, limit)
    if dur <= slot * 1.02:
        return raw
    fitted = os.path.splitext(raw)[0] + "_fit.wav"
    factor = min(dur / slot, max_speed)
    if factor > 1.02:
        change_speed(raw, fitted, factor, MIX_RATE)
    else:
        write_wav(fitted, *read_wav(raw))
    if wav_duration(fitted) > slot:
        _fade_trim(fitted, slot)
    return fitted


# --------------------------------------------------------------------------- #
# Natural voice: slow the video where a translated line is longer
# --------------------------------------------------------------------------- #
def _reset_stretch(project: Project) -> None:
    """Undo the automatic slow-down of the last dub (pieces join up again)."""
    out = []
    for c in project.video_clips:
        if c.stretched:
            c.speed = 1.0
            prev = out[-1] if out else None
            if prev is not None and prev.stretched and abs(prev.src_out - c.src_in) < 1e-3:
                prev.src_out = c.src_out
                continue
        out.append(c)
    for c in out:
        c.stretched = False
    project.video_clips = out


def _slow_ranges(project: Project, regions: List[tuple]) -> None:
    """Play the video between source times a and b at `speed` (< 1), for every
    (a, b, speed) region - in one pass over the clips (a 2-hour film has
    thousands of regions)."""
    import bisect

    regions = sorted(regions)
    starts = [r[0] for r in regions]
    out = []
    for c in project.video_clips:
        if c.rate != 1.0:
            out.append(c)
            continue
        i = max(0, bisect.bisect_right(starts, c.src_in) - 1)
        pieces = []                        # (x, y, speed) inside this clip
        x = c.src_in
        while i < len(regions) and regions[i][0] < c.src_out - 1e-3:
            a, b, speed = regions[i]
            i += 1
            if b <= x + 1e-3:
                continue
            a = max(a, x)
            if a > x + 1e-3:
                pieces.append((x, a, 1.0))
            y = min(b, c.src_out)
            pieces.append((a, y, speed))
            x = y
        if not pieces:
            out.append(c)
            continue
        if x < c.src_out - 1e-3:
            pieces.append((x, c.src_out, 1.0))
        for x, y, speed in pieces:
            out.append(dataclasses.replace(c, id=new_id(), src_in=round(x, 4),
                                           src_out=round(y, 4), stretched=True,
                                           speed=round(speed, 4)))
    project.video_clips = out


def _to_source(project: Project, t: float) -> Optional[float]:
    if not project.video_clips or t > project.sequence_duration() + 1e-6:
        return None
    return project.timeline_to_source(t)[1]


def stretch_video_for_voices(project: Project) -> int:
    """Where a voice (sped up at most project.max_speed) is longer than the
    time until the next line, play that part of the video slower so the line
    is spoken at a natural speed and stays on the lips. Returns how many
    places were slowed. Tools › Video › Speed makes the whole video faster.

    Clips already on the timeline (voices moved by hand, music, subtitles)
    stay on the same picture: they are moved with the video."""
    pinned = []
    for c in list(project.audio_clips) + list(project.subtitle_clips):
        a = _to_source(project, c.start)
        b = _to_source(project, c.end) if isinstance(c, SubtitleClip) else None
        pinned.append((c, a, b))
    _reset_stretch(project)
    regions = []
    if project.stretch_video:
        segs = sorted(project.segments, key=lambda s: s.start)
        prev_end = None                 # where the voice before ends (source time)
        for i, seg in enumerate(segs[:-1]):
            if not seg.tts_path or not os.path.isfile(seg.tts_path):
                continue
            mine = prev_end
            nxt = segs[i + 1].start
            prev_end = min(nxt, seg.start + wav_duration(seg.tts_path)
                           / max(1.0, project.max_speed))
            if nxt < seg.end:           # two people speak at once: leave it
                continue
            end = nxt                   # (up to the next line: no tiny pieces between)
            slot = end - seg.start
            if slot < 0.2:
                continue
            # (+0.05 s: the voice ends a moment before the next line starts)
            need = wav_duration(seg.tts_path) / max(1.0, project.max_speed) + 0.05
            # the silence before the line is used first (no slow-down for a little)
            need -= lead_room(mine, seg.start, max(0.0, need - slot))
            if need > slot * 1.02:
                regions.append((seg.start, end, max(MIN_VIDEO_SPEED, slot / need)))
        _slow_ranges(project, regions)
    project.layout_video()
    for c, a, b in pinned:
        ta = project.source_to_timeline(a) if a is not None else None
        if ta is None:
            continue
        if b is not None:
            tb = project.source_to_timeline(b)
            c.end = round(tb if tb is not None and tb > ta else ta + (c.end - c.start), 3)
        c.start = round(ta, 3)
    return len(regions)


def build_audio_clips(
    project: Project,
    progress: Optional[Callable[[int, str], None]] = None,
    only_ids: Optional[List[str]] = None,
) -> None:
    """Create / refresh AI voice clips on the timeline from segment voices.

    only_ids: refresh just these segments (keeps other clips untouched and
    keeps the timeline position of an existing clip for that segment).
    """
    segs = sorted(project.segments, key=lambda s: s.start)
    existing: Dict[str, AudioClip] = {c.seg_id: c for c in project.audio_clips if c.seg_id}
    if only_ids is None:
        project.audio_clips = [c for c in project.audio_clips if not c.seg_id]

    # (also for a few re-voiced lines: a slow-down depends on every line's
    # voice, and the clips already placed move with the video)
    stretch_video_for_voices(project)
    # after slowing the video, a line still too long may be a bit faster
    cap = max(project.max_speed, LAST_RESORT_SPEED) if project.stretch_video \
        else project.max_speed
    n = max(1, len(segs))
    prev_end = None                     # timeline end of the voice before
    for i, seg in enumerate(segs):
        if only_ids is not None and seg.id not in only_ids:
            kept = existing.get(seg.id)
            if kept is not None:
                prev_end = kept.end
            continue
        if not seg.tts_path or not os.path.isfile(seg.tts_path):
            continue
        next_start = segs[i + 1].start if i + 1 < len(segs) else None
        slot = None
        a = project.source_to_timeline(seg.start)
        b = project.source_to_timeline(next_start) if next_start is not None else None
        if a is not None and b is not None and b > a:
            slot = max(0.2, b - a - 0.05)       # timeline seconds (slowed parts longer)
            e = project.source_to_timeline(seg.end)
            if e is not None and e > a:         # (the next line may start inside this one)
                slot = max(slot, e - a)
        old = existing.get(seg.id)
        keep_place = old is not None and only_ids is not None
        lead = 0.0
        if not keep_place and a is not None:
            room = slot if slot is not None else voice_slot(
                seg, next_start, project.video_duration or None)
            raw = wav_duration(seg.tts_path)
            if raw > room * 1.02 and room != float("inf"):
                # a little too long: start a moment earlier, in the silence before
                lead = lead_room(prev_end, a, raw - room)
                if lead:
                    slot = room + lead
        path = fit_voice(seg, next_start, cap, project.video_duration or None, slot)
        dur = wav_duration(path)

        if keep_place:
            start = old.start
            project.audio_clips.remove(old)
        else:
            start = project.source_to_timeline(seg.start)
            if start is None:          # this part of the video was cut away
                continue
            start = max(0.0, start - lead)
        prev_end = start + dur
        project.audio_clips.append(AudioClip(
            id=new_id(), path=path, start=round(start, 3), src_in=0.0,
            src_out=dur, file_duration=dur, seg_id=seg.id,
            label=(seg.translation or seg.text)[:40],
        ))
        if progress:
            progress(int((i + 1) * 100 / n), f"Synced {i + 1}/{len(segs)}")
    project.audio_clips.sort(key=lambda c: c.start)


def build_subtitles(project: Project, use_translation: bool = True) -> None:
    """Create subtitle clips from the segments (timeline times)."""
    subs = []
    voice_by_seg = {c.seg_id: c for c in project.audio_clips if c.seg_id}
    # lines the user hid stay hidden when the subtitles are made again
    hidden = {c.seg_id for c in project.subtitle_clips if c.seg_id and c.hidden}
    for seg in sorted(project.segments, key=lambda s: s.start):
        text = (seg.translation if use_translation and seg.translation else seg.text).strip()
        if not text:
            continue
        start = project.source_to_timeline(seg.start)
        if start is None:
            continue
        end = project.source_to_timeline(seg.end)
        if end is None:
            end = start + (seg.end - seg.start)
        # Keep the subtitle on the speech in the video. Only if the user
        # dragged the voice clip somewhere else, move the subtitle with it.
        clip = voice_by_seg.get(seg.id)
        if clip is not None and abs(clip.start - start) > 0.05:
            end, start = clip.start + (end - start), clip.start
        if clip is not None and clip.end > end:
            end = clip.end          # shown while the (longer) Khmer line is spoken
        end = max(end, start + 0.5)
        subs.append(SubtitleClip(new_id(), round(start, 3), round(end, 3), text, seg.id,
                                 hidden=seg.id in hidden))

    # remove overlaps so subtitles never stack
    subs.sort(key=lambda c: c.start)
    for a, b in zip(subs, subs[1:]):
        if a.end > b.start:
            a.end = max(a.start + 0.2, b.start - 0.02)
    project.subtitle_clips = subs


# --------------------------------------------------------------------------- #
# Mixing  (streamed in chunks: a 2-hour video never needs GBs of RAM)
# --------------------------------------------------------------------------- #
MIX_CHUNK_SECONDS = 30


_norm_cache: Dict[tuple, float] = {}


def clip_normalize_gain(clip, sample_rate: int = MIX_RATE, target: float = 0.89) -> float:
    """Gain that brings the clip's loudest sample to -1 dBFS (Normalize)."""
    key = (clip.path, round(clip.src_in, 3), round(clip.src_out, 3),
           os.path.getmtime(clip.path) if os.path.isfile(clip.path) else 0)
    if key not in _norm_cache:
        a = int(round(clip.src_in * sample_rate))
        data = read_wav_range(clip.path, a, int(round(clip.length * sample_rate)), sample_rate)
        peak = float(np.max(np.abs(data))) if len(data) else 0.0
        _norm_cache[key] = min(8.0, target / peak) if peak > 1e-4 else 1.0
        if len(_norm_cache) > 5000:
            _norm_cache.clear()
    return _norm_cache[key]


def render_dub_mix(project: Project, out_wav: str, length: Optional[float] = None,
                   sample_rate: int = MIX_RATE,
                   should_stop: Optional[Callable[[], bool]] = None) -> str:
    """Mix every AI voice clip at its timeline position into one WAV.

    Works chunk by chunk and reads only the needed part of each voice file,
    so memory use stays small (~10 MB) whatever the video length."""
    total = length if length is not None else project.sequence_duration()
    n_total = max(1, int(round(total * sample_rate)))
    chunk = int(MIX_CHUNK_SECONDS * sample_rate)

    clips = []
    # the AI voice + the 🎵 Music track (music never mutes the original speech)
    for c in list(project.audio_clips) + list(getattr(project, "music_clips", []) or []):
        if c.length <= 0 or not os.path.isfile(c.path):
            continue
        pos = int(round(c.start * sample_rate))
        n = int(round(c.length * sample_rate))
        if n <= 0 or pos >= n_total or pos + n <= 0:
            continue
        vol = float(c.volume)
        if getattr(c, "normalize", False):
            vol *= clip_normalize_gain(c, sample_rate)
        fi = int(max(0.0, float(getattr(c, "fade_in", 0.0) or 0.0)) * sample_rate)
        fo = int(max(0.0, float(getattr(c, "fade_out", 0.0) or 0.0)) * sample_rate)
        clips.append((pos, n, int(round(c.src_in * sample_rate)), c.path, vol, fi, fo))
    clips.sort()
    # prefix_end[i] = latest end of clips[0..i]; lets us skip finished clips
    prefix_end, latest = [], 0
    for pos, n, *_ in clips:
        latest = max(latest, pos + n)
        prefix_end.append(latest)

    first = 0                       # clips before this index end before the chunk
    with WavWriter(out_wav, sample_rate) as out:
        for c0 in range(0, n_total, chunk):
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            c1 = min(n_total, c0 + chunk)
            buf = np.zeros(c1 - c0, dtype=np.float32)
            while first < len(clips) and prefix_end[first] <= c0:
                first += 1
            for pos, n, src0, path, vol, fi, fo in clips[first:]:
                if pos >= c1:
                    break
                a, b = max(c0, pos), min(c1, pos + n)
                if a >= b:
                    continue
                data = read_wav_range(path, src0 + (a - pos), b - a, sample_rate)
                if len(data):
                    piece = data * vol
                    if fi or fo:            # fade in / out (Audio Properties)
                        rel = np.arange(a - pos, a - pos + len(piece), dtype=np.float32)
                        env = np.ones(len(piece), dtype=np.float32)
                        if fi:
                            env = np.minimum(env, rel / fi)
                        if fo:
                            env = np.minimum(env, (n - rel) / fo)
                        piece = piece * np.clip(env, 0.0, 1.0)
                    buf[a - c0:a - c0 + len(piece)] += piece
            out.write(buf)
    return out_wav


# "Remove the original dialogue": the music & effects go this low while the AI
# voice speaks (-10 dB) - the AI voice stays clear, and what is left of the
# original voices in the separated music is not heard under it
MUSIC_DUCK = 0.32


def render_speech_mask(project: Project, out_wav: str, length: Optional[float] = None,
                       sample_rate: int = 8000, ramp: float = 0.06,
                       floor: float = 0.0) -> Optional[str]:
    """Gain envelope for the ORIGINAL audio: 0 where a dubbed line is spoken
    (so the original voice does not talk under the AI voice), 1 elsewhere,
    with short fades. Returns None when nothing has to be muted.

    ffmpeg multiplies the original audio by this track (amultiply) - much
    faster and safer for long videos than a volume expression with thousands
    of time ranges.
    floor > 0: lowered to this, not silenced (ducking the music & effects)."""
    ranges = project.dubbed_ranges()
    if not ranges:
        return None
    total = length if length is not None else project.sequence_duration()
    n_total = max(1, int(round(total * sample_rate)))
    chunk = int(MIX_CHUNK_SECONDS * 4 * sample_rate)
    r = max(1, int(ramp * sample_rate))
    with WavWriter(out_wav, sample_rate) as out:
        k = 0
        for c0 in range(0, n_total, chunk):
            c1 = min(n_total, c0 + chunk)
            gain = np.ones(c1 - c0, dtype=np.float32)
            while k < len(ranges) and ranges[k][1] * sample_rate + r < c0:
                k += 1
            j = k
            while j < len(ranges) and ranges[j][0] * sample_rate - r < c1:
                a, b = ranges[j][0] * sample_rate, ranges[j][1] * sample_rate
                # only touch the samples around this range: fade out, 0, fade in
                lo, hi = max(c0, int(a - r)), min(c1, int(b + r) + 1)
                idx = np.arange(lo, hi, dtype=np.float64)
                g = np.clip(np.maximum((a - idx) / r, (idx - b) / r), 0.0, 1.0)
                seg = gain[lo - c0:hi - c0]
                np.minimum(seg, g.astype(np.float32), out=seg)
                j += 1
            if floor > 0:
                gain = floor + (1.0 - floor) * gain
            out.write(gain * 0.999)
    return out_wav


# --------------------------------------------------------------------------- #
# SRT
# --------------------------------------------------------------------------- #
def write_srt(subs: List[SubtitleClip], path: str, limit: Optional[float] = None,
              wrap: Optional[Callable[[str], str]] = None, speed: float = 1.0) -> str:
    """Write subtitle clips to an .srt file (UTF-8). wrap(text) may insert line breaks.
    speed: the video is exported faster / slower (Clip Properties > Video > Speed)."""
    def ts(t):
        return format_time(t / speed).replace(".", ",")

    lines = []
    idx = 1
    for c in sorted(subs, key=lambda s: s.start):
        start, end = c.start, c.end
        if limit is not None:
            if start >= limit:
                continue
            end = min(end, limit)
        if end - start < 0.05 or not c.text.strip():
            continue
        text = wrap(c.text.strip()) if wrap else c.text.strip()
        lines += [str(idx), f"{ts(start)} --> {ts(end)}", text, ""]
        idx += 1
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return path


# --------------------------------------------------------------------------- #
# Audio Properties: speed of an AI voice clip
# --------------------------------------------------------------------------- #
def set_clip_speed(clip: AudioClip, speed: float) -> AudioClip:
    """Make an AI voice clip faster / slower (pitch kept). The speed is always
    applied to the original wav (base_path), so changing it many times does
    not lose quality. Trims are scaled with the new length."""
    speed = max(0.5, min(2.0, float(speed)))
    if not clip.base_path:
        clip.base_path = clip.path
    base = clip.base_path
    old = float(clip.speed or 1.0)
    if abs(speed - 1.0) < 0.005:
        new_path = base
    else:
        new_path = f"{os.path.splitext(base)[0]}_x{int(round(speed * 100))}.wav"
        if not os.path.isfile(new_path):
            change_speed(base, new_path, speed, MIX_RATE)
    dur = wav_duration(new_path)
    untrimmed = clip.src_in < 0.01 and clip.src_out >= clip.file_duration - 0.01
    scale = old / speed
    clip.src_in = round(min(dur, clip.src_in * scale), 3)
    clip.src_out = round(dur if untrimmed else min(dur, clip.src_out * scale), 3)
    clip.path, clip.file_duration, clip.speed = new_path, dur, speed
    return clip


# --------------------------------------------------------------------------- #
# Voice style presets (Voice speed + Slow the video) - Editor and Batch
# --------------------------------------------------------------------------- #
VOICE_STYLES = [
    # key, label, max_speed, stretch_video
    ("natural", "Natural – slow the video for long lines", 1.1, True),
    # how the first SARIKA VOXDUB PRO spoke (before 5 Oct 2026): Edge / Azure
    # speak up to +40 % faster on their own, then up to 1.5 x, video unchanged
    ("original", "Original VoxDub – fast voice, video not slowed", 1.5, False),
]


def voice_style_of(max_speed: float, stretch_video: bool) -> str:
    for key, _label, speed, stretch in VOICE_STYLES:
        if abs(float(max_speed or 0) - speed) < 0.01 and bool(stretch_video) == stretch:
            return key
    return "custom"


def voice_style_values(key: str):
    """(max_speed, stretch_video) of a style."""
    for k, _label, speed, stretch in VOICE_STYLES:
        if k == key:
            return speed, stretch
    raise KeyError(key)
