"""
appinfo.py - who this program is: SARIKA VOXDUB PRO.

(The same sources also build a separate TESTING copy, SARIKA VOXDUB STUDIO,
with other values here - its own settings, output folder, taskbar id and
installer - so the two never touch each other on one PC.)
"""

APP_NAME = "SARIKA VOXDUB PRO"
EDITION = ""
TITLE = APP_NAME
# folders under %APPDATA% / %LOCALAPPDATA%
DATA_FOLDER = "VoxDubPRO"
# folder under Videos
OUTPUT_FOLDER = "SARIKA VOXDUB PRO"
# Windows taskbar id
APP_USER_MODEL_ID = "VoxDub.PRO.1"
# (the testing copy reads a voice-clone engine installed here; PRO is it)
PRO_DATA_FOLDER = "VoxDubPRO"
