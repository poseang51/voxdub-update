"""
translate.py - Text translation (Google Translate via deep-translator)
plus the language table used by the whole app.
"""

import time
from typing import Callable, List, Optional

# code -> (display name, google translate code)
LANGUAGES = {
    "km": ("Khmer (ខ្មែរ)", "km"),
    "en": ("English", "en"),
    "zh": ("Chinese (Simplified)", "zh-CN"),
    "ja": ("Japanese", "ja"),
    "ko": ("Korean", "ko"),
    "th": ("Thai", "th"),
    "vi": ("Vietnamese", "vi"),
    "lo": ("Lao", "lo"),
    "my": ("Burmese", "my"),
    "ms": ("Malay", "ms"),
    "id": ("Indonesian", "id"),
    "tl": ("Filipino", "tl"),
    "hi": ("Hindi", "hi"),
    "ar": ("Arabic", "ar"),
    "fr": ("French", "fr"),
    "de": ("German", "de"),
    "es": ("Spanish", "es"),
    "pt": ("Portuguese", "pt"),
    "it": ("Italian", "it"),
    "ru": ("Russian", "ru"),
    "tr": ("Turkish", "tr"),
}

# Source languages for Whisper ("auto" = detect)
SOURCE_LANGUAGES = {"auto": "Auto detect"}
SOURCE_LANGUAGES.update({k: v[0] for k, v in LANGUAGES.items()})


def google_code(lang: str) -> str:
    """Convert our/Whisper language code to the code Google expects."""
    if not lang or lang == "auto":
        return "auto"
    special = {"zh": "zh-CN", "he": "iw", "jw": "jw", "fil": "tl"}
    if lang in special:
        return special[lang]
    if lang in LANGUAGES:
        return LANGUAGES[lang][1]
    return lang


# Google endpoint used by the Chrome dictionary extension. It accepts many
# lines in one POST, so a whole video needs only a few requests (the
# translate.google.com/m page used by deep-translator gets rate-limited / 429).
_GOOGLE_BATCH_URL = "https://clients5.google.com/translate_a/t"
_BATCH_LINES = 40
_BATCH_CHARS = 3000


def _google_batch(texts: List[str], src: str, tgt: str) -> List[str]:
    """Translate several strings in one request. Returns a list of the same length."""
    import requests

    r = requests.post(
        _GOOGLE_BATCH_URL,
        params={"client": "dict-chrome-ex", "sl": src, "tl": tgt},
        data={"q": texts},
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=30,
    )
    r.raise_for_status()
    data = r.json()
    if isinstance(data, str):
        data = [data]
    out = []
    for item in data:
        # sl=auto returns [text, detected_lang] pairs, otherwise plain strings
        if isinstance(item, list):
            item = item[0] if item else ""
        out.append((item or "").strip())
    if len(out) != len(texts):
        raise RuntimeError(f"Google returned {len(out)} lines for {len(texts)}")
    return out


def _fallback_one(text: str, src: str, tgt: str) -> str:
    """Single-line translation through deep-translator (Google, then MyMemory)."""
    from deep_translator import GoogleTranslator, MyMemoryTranslator

    errors = []
    try:
        return (GoogleTranslator(source=src, target=tgt).translate(text) or "").strip()
    except Exception as e:
        errors.append(f"Google: {e}")
    try:
        if src == "auto":
            raise RuntimeError("MyMemory needs a source language")
        return (MyMemoryTranslator(source=src, target=tgt).translate(text) or "").strip()
    except Exception as e:
        errors.append(f"MyMemory: {e}")
    raise RuntimeError("; ".join(errors))


# waits between retries: long videos send many requests, so back off more
# each time when Google says "too many requests" or the network drops
_BACKOFF = [2, 5, 10, 20, 40]


def _translate_chunk(texts: List[str], src: str, tgt: str, retries: int = 5,
                     should_stop: Optional[Callable[[], bool]] = None) -> List[str]:
    last_err = None
    for attempt in range(retries):
        try:
            return _google_batch(texts, src, tgt)
        except Exception as e:  # network errors, rate limits...
            last_err = e
            wait = _BACKOFF[min(attempt, len(_BACKOFF) - 1)]
            for _ in range(int(wait * 10)):
                if should_stop and should_stop():
                    raise InterruptedError("Cancelled")
                time.sleep(0.1)
    # batch endpoint unavailable -> fall back line by line
    try:
        out = []
        for t in texts:
            out.append(_fallback_one(t, src, tgt))
            time.sleep(0.3)
        return out
    except Exception as e:
        raise RuntimeError(
            f"Translation failed. Google batch: {last_err}. Fallback: {e}. "
            "Check your internet connection, or wait a few minutes if Google is rate-limiting you."
        )


def translate_text(text: str, source: str, target: str, retries: int = 3) -> str:
    """Translate one string. Retries on network hiccups."""
    text = (text or "").strip()
    if not text:
        return ""
    src, tgt = google_code(source), google_code(target)
    if src == tgt:
        return text
    return _translate_chunk([text], src, tgt, retries)[0]


def translate_lines(
    lines: List[str],
    source: str,
    target: str,
    progress: Optional[Callable[[int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
    on_result: Optional[Callable[[int, str], None]] = None,
) -> List[str]:
    """Translate a list of lines, keeping a 1:1 order. Sends lines in batches.

    on_result(index, translation) is called as soon as each batch is done, so
    the caller can keep what is finished if a later batch fails."""
    src, tgt = google_code(source), google_code(target)
    out = [(l or "").strip() for l in lines]
    if src == tgt:
        return out
    todo = [i for i, t in enumerate(out) if t]

    # group non-empty lines into chunks limited by count and characters
    chunks, cur, size = [], [], 0
    for i in todo:
        if cur and (len(cur) >= _BATCH_LINES or size + len(out[i]) > _BATCH_CHARS):
            chunks.append(cur)
            cur, size = [], 0
        cur.append(i)
        size += len(out[i])
    if cur:
        chunks.append(cur)

    done, n = 0, max(1, len(todo))
    for chunk in chunks:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        for i, tr in zip(chunk, _translate_chunk([out[i] for i in chunk], src, tgt,
                                                 should_stop=should_stop)):
            out[i] = tr
            if on_result:
                on_result(i, tr)
        done += len(chunk)
        time.sleep(0.15)          # be gentle with Google on long videos
        if progress:
            progress(int(done * 100 / n), f"Translated {done}/{len(todo)}")
    return out
