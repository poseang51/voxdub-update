"""
crashlog.py - write WHERE the app was when it closes by itself.

A Python error is caught by main.py (message box + log). A hard crash inside
a native library (Qt, the video player, onnxruntime, ffmpeg bindings...)
closes the app without any Python error and without a word in the log.
faulthandler writes the Python stack of every thread into the log at that
moment, so the next look at voxdub.log shows what was running.

Lives in core/ (not main.py) so an update package can bring it.
"""

import os
import sys
import time

_FILE = None                    # logs/crash_trace.log (kept open for faulthandler)


def trace_path() -> str:
    from .media import data_dir
    return os.path.join(data_dir(), "logs", "crash_trace.log")


def _open_trace():
    """A file that survives the console window closing (the Test copy and
    run.bat print to a console: what was written there is gone after a crash)."""
    global _FILE
    if _FILE is None:
        path = trace_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.isfile(path) and os.path.getsize(path) > 2 * 1024 * 1024:
            os.replace(path, path + ".old")
        _FILE = open(path, "a", encoding="utf-8", buffering=1, errors="replace")
    return _FILE


def note(text: str) -> None:
    """One line into crash_trace.log (Qt warnings, thread errors, start / end)."""
    try:
        f = _open_trace()
        f.write(f"{time.strftime('%H:%M:%S')} {text}\n")
        f.flush()
    except Exception:
        pass


def enable(stream=None) -> bool:
    """Turn the crash trace on. True when it is on.
    No stream: the log file when the app writes one (built .exe), else
    logs/crash_trace.log. Every run is marked there with its start and its
    normal end - a start without an end = the app was closed by a crash."""
    try:
        import atexit
        import faulthandler
        import threading

        if faulthandler.is_enabled() and stream is None and _FILE is not None:
            return True
        f = stream
        if f is None:
            err = sys.stderr
            real_file = err is not None and hasattr(err, "fileno") and \
                not (hasattr(err, "isatty") and err.isatty())
            try:
                if real_file:
                    err.fileno()
            except Exception:
                real_file = False
            f = err if real_file and getattr(err, "name", "").endswith(".log") \
                else _open_trace()
            if f is _FILE:
                note(f"===== start pid {os.getpid()} =====")
                atexit.register(lambda: note(f"===== normal end pid {os.getpid()} ====="))

                def thread_error(args):
                    import traceback
                    note("thread error: " + "".join(traceback.format_exception(
                        args.exc_type, args.exc_value, args.exc_traceback)))
                threading.excepthook = thread_error
        if f is None or not hasattr(f, "fileno"):
            return False
        f.fileno()                       # a real file, not StringIO
        faulthandler.enable(file=f, all_threads=True)
        return True
    except Exception:
        return False


def safe_video_decoding() -> None:
    """2.6.2: the video preview decodes with D3D11 only, never DXVA2. On some
    NVIDIA drivers DXVA2 (Direct3D 9) crashed the whole app after a while
    (nvd3dumx.dll, 0xc0000005). video_hw_decode = True: Qt's own choice again;
    video_hw_types = "," : CPU only. Must run before Qt Multimedia starts."""
    import os
    try:
        from . import settings
        if settings.get("video_hw_decode", False):
            return
    except Exception:
        pass
    # The crash was in nvd3dumx.dll = NVIDIA's Direct3D 9 driver, used by the
    # DXVA2 decoder. D3D11 decoding (another driver part) keeps 1080p smooth;
    # CPU-only decoding made playback stutter.
    os.environ.setdefault("QT_FFMPEG_DECODING_HW_DEVICE_TYPES",
                          settings_value("video_hw_types", "d3d11va"))


def settings_value(key: str, default: str) -> str:
    try:
        from . import settings
        v = settings.get(key, default)
        return v if isinstance(v, str) and v else default
    except Exception:
        return default
