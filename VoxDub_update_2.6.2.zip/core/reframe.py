"""
reframe.py - 🔄 Reframe: turn, mirror and change the shape of a video.

For videos that come the wrong way round:
  turn      0 / 90 / 180 / 270 degrees clockwise (a sideways phone video)
  mirror    left <-> right (re-uploads are often mirrored), upside down
  shape     keep / 16:9 (YouTube, Facebook) / 9:16 (TikTok, Reels) / 1:1 / 4:5
  fill      how the picture fits the new shape:
              blur   the picture whole, the empty parts a blurred copy of it
              black  the picture whole, black bars
              crop   fill the frame, the edges cut off
The result is a new MP4 (the original is not changed), ready to Edit / Dub.
"""

import os
import tempfile
from typing import Callable, List, Optional, Tuple

from .export import ExportFailed, ExportOptions, _run_with_progress, _video_codec_args, pick_encoder
from .media import find_ffmpeg, get_media_info, no_window

Progress = Callable[[int, str], None]
Stop = Callable[[], bool]

TURNS = [0, 90, 180, 270]
SHAPES = {                    # key -> (name, width, height) of the full-size frame
    "keep": ("Keep the shape", 0, 0),
    "16:9": ("16:9  landscape – YouTube, Facebook", 1920, 1080),
    "9:16": ("9:16  vertical – TikTok, Reels, Shorts", 1080, 1920),
    "1:1": ("1:1  square", 1080, 1080),
    "4:5": ("4:5  Facebook / Instagram post", 1080, 1350),
}
FILLS = {"blur": "Blurred background", "black": "Black bars", "crop": "Fill (cut the edges)"}


def _even(v: float) -> int:
    return max(2, int(round(v / 2.0)) * 2)


def turned_size(w: int, h: int, turn: int) -> Tuple[int, int]:
    return (h, w) if turn % 180 == 90 else (w, h)


def out_size(w: int, h: int, turn: int = 0, shape: str = "keep") -> Tuple[int, int]:
    """Size of the result. A new shape is never bigger than the source's long
    side (a 720p video stays sharp-sized, 1080p and up become 1080p)."""
    w, h = turned_size(w, h, turn)
    name, tw, th = SHAPES.get(shape, SHAPES["keep"])
    if not tw:
        return _even(w), _even(h)
    k = min(1.0, max(w, h) / float(max(tw, th)))
    return _even(tw * k), _even(th * k)


def is_identity(turn: int = 0, flip_h: bool = False, flip_v: bool = False,
                shape: str = "keep") -> bool:
    return not (turn % 360 or flip_h or flip_v or shape != "keep")


def filter_graph(w: int, h: int, turn: int = 0, flip_h: bool = False, flip_v: bool = False,
                 shape: str = "keep", fill: str = "blur", scale: float = 1.0) -> str:
    """ffmpeg -filter_complex for [0:v] -> [v]. scale < 1: a small preview."""
    steps: List[str] = []
    turn %= 360
    if turn == 90:
        steps.append("transpose=1")
    elif turn == 270:
        steps.append("transpose=2")
    elif turn == 180:                   # = mirror left-right + upside down
        flip_h, flip_v = not flip_h, not flip_v
    if flip_h:
        steps.append("hflip")
    if flip_v:
        steps.append("vflip")
    W, H = out_size(w, h, turn, shape)
    W, H = _even(W * scale), _even(H * scale)
    head = "[0:v]" + ",".join(steps + ["setsar=1"])
    if fill == "crop":
        return (f"{head},scale={W}:{H}:force_original_aspect_ratio=increase,"
                f"crop={W}:{H},setsar=1,format=yuv420p[v]")
    if fill == "black" or shape == "keep":
        return (f"{head},scale={W}:{H}:force_original_aspect_ratio=decrease,"
                f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1,format=yuv420p[v]")
    blur = max(4, int(min(W, H) / 22))
    return (f"{head},split[a][b];"
            f"[a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
            f"boxblur={blur}:2,eq=brightness=-0.08[bg];"
            f"[b]scale={W}:{H}:force_original_aspect_ratio=decrease[fg];"
            f"[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[v]")


def _graph_args(graph: str, folder: str) -> List[str]:
    from .media import ffmpeg_major_version

    script = os.path.join(folder, "reframe_graph.txt")
    with open(script, "w", encoding="utf-8") as fh:
        fh.write(graph)
    return (["-/filter_complex", script] if ffmpeg_major_version() >= 7
            else ["-filter_complex_script", script])


def preview_frame(src: str, at: float, out_png: str, turn: int = 0, flip_h: bool = False,
                  flip_v: bool = False, shape: str = "keep", fill: str = "blur",
                  size: int = 480) -> str:
    """One frame of the result (long side about `size` px) as a PNG."""
    import subprocess

    info = get_media_info(src)
    W, H = out_size(info.width, info.height, turn, shape)
    graph = filter_graph(info.width, info.height, turn, flip_h, flip_v, shape, fill,
                         scale=min(1.0, size / float(max(W, H))))
    tmp = tempfile.mkdtemp(prefix="vxd_reframe_")
    cmd = [find_ffmpeg(), "-hide_banner", "-y", "-ss", f"{max(0.0, at):.2f}",
           "-i", os.path.abspath(src)] + _graph_args(graph, tmp) + [
        "-map", "[v]", "-frames:v", "1", os.path.abspath(out_png)]
    subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                   creationflags=no_window())
    return out_png if os.path.isfile(out_png) else ""


def output_name(src: str, folder: str = "") -> str:
    base = os.path.splitext(os.path.basename(src))[0]
    folder = folder or os.path.dirname(os.path.abspath(src))
    out = os.path.join(folder, f"{base}_reframe.mp4")
    n = 2
    while os.path.exists(out):
        out = os.path.join(folder, f"{base}_reframe ({n}).mp4")
        n += 1
    return out


def reframe(src: str, out: str, turn: int = 0, flip_h: bool = False, flip_v: bool = False,
            shape: str = "keep", fill: str = "blur", progress: Optional[Progress] = None,
            should_stop: Optional[Stop] = None) -> str:
    """Make the reframed MP4. Sound is kept (AAC)."""
    info = get_media_info(src)
    if not info.has_video or not info.width:
        raise ValueError(f"No picture in {os.path.basename(src)}")
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    tmp = tempfile.mkdtemp(prefix="vxd_reframe_")
    graph = filter_graph(info.width, info.height, turn, flip_h, flip_v, shape, fill)
    opts = ExportOptions(output_path=out, crf=19)
    enc = pick_encoder("auto")

    def cmd_for(encoder: str) -> List[str]:
        return ([find_ffmpeg(), "-hide_banner", "-y", "-i", os.path.abspath(src)]
                + _graph_args(graph, tmp)
                + ["-map", "[v]", "-map", "0:a:0?"] + _video_codec_args(encoder, opts)
                + ["-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
                   "-progress", "pipe:1", "-nostats", os.path.abspath(out)])
    try:
        _run_with_progress(cmd_for(enc), tmp, info.duration, progress, should_stop,
                           "Reframing", base=0)
    except ExportFailed:
        if enc != "nvenc":
            raise
        _run_with_progress(cmd_for("x264"), tmp, info.duration, progress, should_stop,
                           "Reframing", base=0)
    if progress:
        progress(100, "Done")
    return out
