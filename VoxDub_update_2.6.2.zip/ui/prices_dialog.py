"""
prices_dialog.py - Admin: the licence prices customers see (core/pricing.py).
"""

import json

from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QDoubleSpinBox, QFormLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMessageBox, QPushButton, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from core import pricing

COLS = ["Name customers see", "Days", "Price"]


class PricesDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Admin – licence prices")
        self.resize(620, 520)
        data = pricing.load()

        self.ed_cur = QLineEdit(data["currency"])
        self.ed_cur.setMaximumWidth(90)
        self.ed_cur.setPlaceholderText("$ or ៛")
        self.ed_contact = QLineEdit(data["contact"])
        self.ed_contact.setPlaceholderText("Telegram 0xx xxx xxx  ·  Facebook page …")
        self.ed_pay = QLineEdit(data["pay"])
        self.ed_pay.setPlaceholderText("ABA / KHQR / Wing …")
        self.ed_note = QLineEdit(data["note"])
        self.ed_note.setPlaceholderText("e.g. Opening price until 31 Dec")
        form = QFormLayout()
        form.addRow("Currency", self.ed_cur)
        form.addRow("Contact (to buy)", self.ed_contact)
        form.addRow("Payment", self.ed_pay)
        form.addRow("Note", self.ed_note)

        self.tbl = QTableWidget(0, len(COLS))
        self.tbl.setHorizontalHeaderLabels(COLS)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        h = self.tbl.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for it in data["items"]:
            self._add_row(it)

        b_add = QPushButton("＋ Add a duration")
        b_add.clicked.connect(lambda: self._add_row({"days": 30, "label": "", "price": 0}))
        b_del = QPushButton("− Remove")
        b_del.clicked.connect(self._remove)
        b_json = QPushButton("📋 Copy for version.json")
        b_json.setToolTip('Paste as "prices": … in version.json: every customer gets the new '
                          "prices at the next update check – no new build needed.")
        b_json.clicked.connect(self._copy_json)
        row = QHBoxLayout()
        for b in (b_add, b_del):
            row.addWidget(b)
        row.addStretch(1)
        row.addWidget(b_json)

        self.lb_hint = QLabel()
        self.lb_hint.setObjectName("MutedLabel")
        self.lb_hint.setWordWrap(True)
        self.lb_hint.setText(
            "Customers see these prices on Plan & licence. Saved on this PC and in the program's "
            "assets\\prices.json, so the next build_exe.bat ships them. To change them for "
            "customers who already installed, use “Copy for version.json”.")

        b_save = QPushButton("Save")
        b_save.setObjectName("AccentButton")
        b_save.clicked.connect(self._save)
        b_cancel = QPushButton("Cancel")
        b_cancel.clicked.connect(self.reject)
        bottom = QHBoxLayout()
        bottom.addStretch(1)
        bottom.addWidget(b_cancel)
        bottom.addWidget(b_save)

        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(self.tbl, 1)
        lay.addLayout(row)
        lay.addWidget(self.lb_hint)
        lay.addLayout(bottom)

    # ------------------------------------------------------------------ #
    def _add_row(self, it: dict):
        r = self.tbl.rowCount()
        self.tbl.insertRow(r)
        self.tbl.setItem(r, 0, QTableWidgetItem(str(it.get("label", ""))))
        sp_days = QSpinBox()
        sp_days.setRange(1, 3650)
        sp_days.setValue(int(it.get("days", 30)))
        sp_days.setSuffix(" days")
        sp_price = QDoubleSpinBox()
        sp_price.setRange(0, 1_000_000)
        sp_price.setDecimals(2)
        sp_price.setValue(float(it.get("price", 0)))
        self.tbl.setCellWidget(r, 1, sp_days)
        self.tbl.setCellWidget(r, 2, sp_price)

    def _remove(self):
        r = self.tbl.currentRow()
        if r >= 0:
            self.tbl.removeRow(r)

    def data(self) -> dict:
        items = []
        for r in range(self.tbl.rowCount()):
            label = self.tbl.item(r, 0).text() if self.tbl.item(r, 0) else ""
            items.append({"label": label, "days": self.tbl.cellWidget(r, 1).value(),
                          "price": self.tbl.cellWidget(r, 2).value()})
        return {"currency": self.ed_cur.text(), "contact": self.ed_contact.text(),
                "pay": self.ed_pay.text(), "note": self.ed_note.text(), "items": items}

    def _copy_json(self):
        data = pricing.clean(self.data())
        if data:
            QGuiApplication.clipboard().setText(
                '"prices": ' + json.dumps(data, ensure_ascii=False, indent=2))

    def _save(self):
        try:
            pricing.save(self.data())
        except (ValueError, OSError) as e:
            QMessageBox.warning(self, "Prices", str(e))
            return
        self.accept()
