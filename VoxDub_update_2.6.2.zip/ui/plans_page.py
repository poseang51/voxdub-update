"""
plans_page.py - 💳 Plan & Licence (2.6), laid out like the SARIKA design:

  ┌ Plan & Licence banner (AI Dubbing · AI Recap · Batch · Voice Library) ┐
  ┌ Your Licence (Active, expiry, Machine ID ••••, devices, plan) ┐ ┌ Current Plan Details ┐
  ┌ Choose Your Plan – All features included (price cards)        ┐ │ days left, dates,    │
  ┌ How to Buy or Renew (3 steps) ┐ ┌ Payment Methods ┐            │ Renew Now            │
  ┌ Features Included in Every Licence (grid) ┐ ┌ Licence Policy ┐ ┌ Recent Activity      ┐
  └ Admin: preview a plan as a customer (Basic / Pro / Studio) ┘

"Get Started" copies a buy message with the Machine ID and an Order ID (the
seller matches the payment to it). The key is made by the seller after the
payment is checked - never automatically.
"""

from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import (
    QFrame, QGridLayout, QHBoxLayout, QLabel, QMessageBox, QProgressBar, QPushButton,
    QScrollArea, QSizePolicy, QVBoxLayout, QWidget,
)

from core import plans, pricing

NAMES = {1: "Monthly", 3: "Quarterly", 6: "Half-Yearly", 12: "Annual"}
FEATURES = [("🎙", "AI Dubbing", "Many voices & emotions"),
            ("🎬", "AI Recap", "Smart story summary"),
            ("✂", "Edit video", "Cut, text, music, logos"),
            ("📚", "Batch a series", "Whole series + series cast"),
            ("🗣", "Voice Library", "Voice clone (VoxCPM)"),
            ("💬", "Khmer subtitles", "Hide the old subtitles"),
            ("🛡", "Copyright & quality", "Checked before export"),
            ("⬆", "Updates", "Inside the app, no reinstall")]
POLICY = ["1 licence = 1 computer (its Machine ID)",
          "New computer? Send its Machine ID to the seller for a new key",
          "Renewing adds the time to what is left – settings and projects stay",
          "Gemini / Azure API fees are not included (your own keys)",
          "Several computers or a business: ask the seller for a price"]
BANNER = [("🎙", "AI Dubbing", "Multi-voice & emotion"),
          ("🎬", "AI Recap", "Smart story summary"),
          ("📚", "Batch a series", "Whole series at once"),
          ("🗣", "Voice Library", "Voice clone")]

QSS = """
QWidget#PBody { background: #0a0e27; }
QWidget#PBody QLabel { color: #e8eaff; }
QFrame#PCard { background: #10163a; border: 1px solid #262d6b; border-radius: 14px; }
QFrame#PInner { background: #0c1131; border: 1px solid #232a63; border-radius: 12px; }
QFrame#PBanner { border-radius: 16px; border: 1px solid #3a3fa0;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1b2a8a, stop:0.55 #3a2aa8,
                                stop:1 #6a2fc8); }
QFrame#PLicence { border-radius: 14px; border: 1px solid #1f8f6a;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #0f6b55, stop:0.45 #0d3a43,
                                stop:1 #10163a); }
QFrame#PLicence[state="soon"] { border-color: #c98a1d;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6b4a0f, stop:0.45 #3a2a12,
                                stop:1 #10163a); }
QFrame#PLicence[state="bad"] { border-color: #b33a3a;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6b1f1f, stop:0.45 #3a1520,
                                stop:1 #10163a); }
QFrame#PLicence[state="admin"] { border-color: #7c5cff;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3b2a9a, stop:0.45 #221a5a,
                                stop:1 #10163a); }
QFrame#PPrice { background: #10163a; border: 1px solid #262d6b; border-radius: 14px; }
QFrame#PPrice[best="true"] { border: 2px solid #b06bff;
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1b1a55, stop:1 #10163a); }
QLabel#PH1 { font-size: 26px; font-weight: 800; }
QLabel#PH2 { font-size: 18px; font-weight: 800; }
QLabel#PH3 { font-size: 14px; font-weight: 700; }
QLabel#PSub { color: #d6dcff; font-size: 14px; }
QLabel#PMuted { color: #9aa3cf; font-size: 12px; }
QLabel#PSmall { color: #c3c8ee; font-size: 12px; }
QLabel#PPriceBig { font-size: 30px; font-weight: 800; }
QLabel#PIcon { font-size: 18px; background: rgba(124,92,255,0.18); border: 1px solid #3d3a9a;
    border-radius: 10px; min-width: 36px; max-width: 36px; min-height: 36px; max-height: 36px; }
QLabel#PBigIcon { font-size: 26px; background: rgba(255,255,255,0.10);
    border: 1px solid rgba(255,255,255,0.30); border-radius: 26px; min-width: 52px;
    max-width: 52px; min-height: 52px; max-height: 52px; }
QLabel#PBadge { background: #22c38a; color: #062b1f; border-radius: 10px; padding: 2px 12px;
    font-weight: 800; font-size: 12px; }
QLabel#PBadge[state="soon"] { background: #f5b942; color: #3a2600; }
QLabel#PBadge[state="bad"] { background: #ef5350; color: white; }
QLabel#PBadge[state="admin"] { background: #9b7bff; color: white; }
QLabel#PSave { background: #1f9e6e; color: white; border-radius: 9px; padding: 1px 9px;
    font-size: 11px; font-weight: 700; }
QLabel#PBest { background: #2ee6a6; color: #06261b; border-radius: 9px; padding: 2px 10px;
    font-size: 11px; font-weight: 800; }
QLabel#PAll { background: #2f3bd8; color: white; border-radius: 10px; padding: 2px 12px;
    font-size: 12px; font-weight: 700; }
QLabel#PStepNum { background: #3d5bff; color: white; border-radius: 15px; font-weight: 800;
    min-width: 30px; max-width: 30px; min-height: 30px; max-height: 30px; }
QLabel#PYes { color: #e8eaff; }
QLabel#PNo { color: #6b7199; }
QPushButton#PGhost { background: transparent; border: 1px solid #3a4590; border-radius: 9px;
    padding: 8px 14px; color: #e8eaff; }
QPushButton#PGhost:hover { border-color: #9b7bff; background: #161d4f; }
QPushButton#PCta { color: white; border: none; border-radius: 10px; padding: 9px 16px;
    font-weight: 800;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #5b4dff, stop:1 #b06bff); }
QPushButton#PCta:hover { background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
    stop:0 #6d60ff, stop:1 #c080ff); }
QPushButton#PIconBtn { background: transparent; border: none; color: #c3c8ee; font-size: 14px;
    padding: 2px 4px; }
QPushButton#PIconBtn:hover { color: white; }
QProgressBar { background: #232a63; border: none; border-radius: 4px; max-height: 8px; }
QProgressBar::chunk { border-radius: 4px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #22c38a, stop:1 #2ee6a6); }
"""


def _l(text: str, name: str = "", wrap: bool = False) -> QLabel:
    lb = QLabel(text)
    if name:
        lb.setObjectName(name)
    lb.setWordWrap(wrap)
    return lb


def _card(name: str = "PCard", margins=(18, 16, 18, 16), spacing: int = 10):
    fr = QFrame()
    fr.setObjectName(name)
    lay = QVBoxLayout(fr)
    lay.setContentsMargins(*margins)
    lay.setSpacing(spacing)
    return fr, lay


def _polish(w, **props):
    for k, v in props.items():
        w.setProperty(k, v)
    w.style().unpolish(w)
    w.style().polish(w)


def plan_name(item: Dict) -> str:
    return NAMES.get(pricing.months(item), item["label"])


def mask(mid: str) -> str:
    """Machine ID shown as ••••-••••-••••-F2C4 (safe in screenshots)."""
    parts = (mid or "").split("-")
    if len(parts) < 2:
        return mid
    return "-".join(["••••"] * (len(parts) - 1) + [parts[-1]])


class PlansPage(QScrollArea):
    """Plan & licence: the licence of this PC, the prices (set by the Admin),
    how to buy / renew, what is included. The Admin can also preview a plan."""
    planChosen = Signal(str)
    backRequested = Signal()
    licenseRequested = Signal()

    def __init__(self):
        super().__init__()
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        inner = QWidget()
        inner.setObjectName("PBody")
        inner.setStyleSheet(QSS)
        outer = QVBoxLayout(inner)
        outer.setContentsMargins(24, 18, 24, 24)
        outer.setSpacing(16)
        self._mid = ""
        self._show_mid = False

        # ---- the seller's PC (top bar)
        self.admin_box = QFrame()
        self.admin_box.setObjectName("PInner")
        ah = QHBoxLayout(self.admin_box)
        ah.setContentsMargins(16, 10, 16, 10)
        self.lb_admin = _l("", "PSmall", wrap=True)
        b_prices = QPushButton("💲 Edit prices")
        b_prices.setObjectName("PGhost")
        b_prices.clicked.connect(self._edit_prices)
        self.btn_admin = QPushButton("↩ Back to Admin – everything open")
        self.btn_admin.setObjectName("PCta")
        self.btn_admin.clicked.connect(lambda: self.planChosen.emit("admin"))
        ah.addWidget(self.lb_admin, 1)
        ah.addWidget(b_prices)
        ah.addWidget(self.btn_admin)
        outer.addWidget(self.admin_box)

        outer.addWidget(self._banner())

        body = QHBoxLayout()
        body.setSpacing(16)
        left = QVBoxLayout()
        left.setSpacing(16)
        left.addWidget(self._licence_card())
        left.addWidget(self._prices())
        row = QHBoxLayout()
        row.setSpacing(16)
        row.addWidget(self._how_to_buy(), 3)
        row.addWidget(self._payment(), 1)
        left.addLayout(row)
        row = QHBoxLayout()
        row.setSpacing(16)
        row.addWidget(self._features(), 3)
        row.addWidget(self._policy(), 2)
        left.addLayout(row)
        body.addLayout(left, 3)
        right = QVBoxLayout()
        right.setSpacing(16)
        right.addWidget(self._details())
        right.addWidget(self._activity())
        right.addStretch(1)
        rw = QWidget()
        rw.setLayout(right)
        rw.setMinimumWidth(320)
        rw.setMaximumWidth(380)
        body.addWidget(rw, 1)
        outer.addLayout(body)

        # ---- Admin: preview what a customer of a plan sees
        self.lb_preview = _l("Admin · preview a plan as a customer", "PH2")
        outer.addWidget(self.lb_preview)
        self.grid = QGridLayout()
        self.grid.setSpacing(16)
        outer.addLayout(self.grid)
        outer.addStretch(1)
        self.lic = QFrame()                     # (kept for older code)
        self.lb_lic = self.lb_state
        self.setWidget(inner)

    # ================================================================== #
    # parts
    # ================================================================== #
    def _banner(self) -> QFrame:
        fr = QFrame()
        fr.setObjectName("PBanner")
        h = QHBoxLayout(fr)
        h.setContentsMargins(26, 18, 26, 18)
        h.setSpacing(18)
        col = QVBoxLayout()
        back = QPushButton("← Home")
        back.setObjectName("PIconBtn")
        back.clicked.connect(self.backRequested.emit)
        col.addWidget(back, 0, Qt.AlignmentFlag.AlignLeft)
        col.addWidget(_l("Plan & Licence", "PH1"))
        col.addWidget(_l("Every feature is included in every licence. Choose how long you "
                         "want it – longer is cheaper per month.", "PSub", wrap=True))
        col.addStretch(1)
        h.addLayout(col, 2)
        for icon, title, sub in BANNER:
            c = QVBoxLayout()
            c.setSpacing(4)
            ic = _l(icon, "PBigIcon")
            ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
            c.addWidget(ic, 0, Qt.AlignmentFlag.AlignHCenter)
            t = _l(title, "PH3")
            t.setAlignment(Qt.AlignmentFlag.AlignCenter)
            s = _l(sub, "PMuted")
            s.setAlignment(Qt.AlignmentFlag.AlignCenter)
            c.addWidget(t)
            c.addWidget(s)
            h.addLayout(c, 1)
        return fr

    def _licence_card(self) -> QFrame:
        fr = QFrame()
        fr.setObjectName("PLicence")
        self.lic_card = fr
        h = QHBoxLayout(fr)
        h.setContentsMargins(20, 18, 20, 18)
        h.setSpacing(18)
        ic = _l("🛡", "PBigIcon")
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        h.addWidget(ic, 0, Qt.AlignmentFlag.AlignTop)
        col = QVBoxLayout()
        col.setSpacing(4)
        top = QHBoxLayout()
        top.addWidget(_l("Your Licence", "PH2"))
        self.lb_badge = _l("", "PBadge")
        top.addWidget(self.lb_badge)
        top.addStretch(1)
        col.addLayout(top)
        self.lb_state = _l("", "PSub")
        self.lb_state_detail = _l("", "PSmall", wrap=True)
        col.addWidget(self.lb_state)
        col.addWidget(self.lb_state_detail)
        col.addStretch(1)
        h.addLayout(col, 2)

        box = QFrame()
        box.setObjectName("PInner")
        bh = QHBoxLayout(box)
        bh.setContentsMargins(14, 10, 14, 10)
        bh.setSpacing(16)
        mid = QVBoxLayout()
        mid.addWidget(_l("💻 Machine ID", "PMuted"))
        mrow = QHBoxLayout()
        mrow.setSpacing(2)
        self.lb_mid = _l("", "PH3")
        self.lb_mid.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.btn_eye = QPushButton("👁")
        self.btn_eye.setObjectName("PIconBtn")
        self.btn_eye.setToolTip("Show / hide the whole Machine ID")
        self.btn_eye.clicked.connect(self._toggle_mid)
        self.btn_mid = QPushButton("⧉ Copy")
        self.btn_mid.setObjectName("PIconBtn")
        self.btn_mid.setToolTip("Copy the Machine ID (send it to buy or renew)")
        self.btn_mid.clicked.connect(self._copy_mid)
        mrow.addWidget(self.lb_mid)
        mrow.addWidget(self.btn_eye)
        mrow.addWidget(self.btn_mid)
        mid.addLayout(mrow)
        bh.addLayout(mid)
        for attr, cap in (("lb_devices", "🖥 Devices"), ("lb_type", "👑 Plan Type")):
            c = QVBoxLayout()
            c.addWidget(_l(cap, "PMuted"))
            lb = _l("", "PH3")
            setattr(self, attr, lb)
            c.addWidget(lb)
            bh.addLayout(c)
        bcol = QVBoxLayout()
        self.btn_key = QPushButton("🔑  Enter licence key")
        self.btn_key.setObjectName("PCta")
        self.btn_key.clicked.connect(self.licenseRequested.emit)
        bcol.addWidget(self.btn_key)
        bh.addLayout(bcol)
        h.addWidget(box, 3)
        return fr

    def _prices(self) -> QFrame:
        fr, lay = _card()
        head = QHBoxLayout()
        head.addWidget(_l("Choose Your Plan", "PH2"))
        head.addWidget(_l("All features included", "PAll"))
        head.addStretch(1)
        lay.addLayout(head)
        self.lb_note = _l("", "PMuted", wrap=True)
        lay.addWidget(self.lb_note)
        self.prices_row = QHBoxLayout()
        self.prices_row.setSpacing(14)
        lay.addLayout(self.prices_row)
        return fr

    def _how_to_buy(self) -> QFrame:
        fr, lay = _card()
        lay.addWidget(_l("How to Buy or Renew", "PH2"))
        lay.addWidget(_l("Simple and safe – the key is made after your payment is checked.",
                         "PMuted"))
        row = QHBoxLayout()
        row.setSpacing(10)
        self.lb_steps: List[QLabel] = []
        for n, icon in enumerate(("👑", "💳", "🔑")):
            box = QFrame()
            box.setObjectName("PInner")
            h = QHBoxLayout(box)
            h.setContentsMargins(12, 10, 12, 10)
            num = _l(str(n + 1), "PStepNum")
            num.setAlignment(Qt.AlignmentFlag.AlignCenter)
            h.addWidget(num, 0, Qt.AlignmentFlag.AlignTop)
            txt = _l("", "PSmall", wrap=True)
            self.lb_steps.append(txt)
            h.addWidget(txt, 1)
            h.addWidget(_l(icon, "PH2"), 0, Qt.AlignmentFlag.AlignBottom)
            row.addWidget(box, 1)
        lay.addLayout(row)
        return fr

    def _payment(self) -> QFrame:
        fr, lay = _card()
        lay.addWidget(_l("Payment Methods", "PH3"))
        self.pay_row = QHBoxLayout()
        self.pay_row.setSpacing(8)
        lay.addLayout(self.pay_row)
        self.btn_contact = QPushButton("💬  Contact seller")
        self.btn_contact.setObjectName("PGhost")
        self.btn_contact.clicked.connect(self._contact)
        lay.addWidget(self.btn_contact)
        lay.addStretch(1)
        return fr

    def _features(self) -> QFrame:
        fr, lay = _card()
        lay.addWidget(_l("Features Included in Every Licence", "PH2"))
        g = QGridLayout()
        g.setSpacing(8)
        for i, (icon, title, sub) in enumerate(FEATURES):
            box = QFrame()
            box.setObjectName("PInner")
            h = QHBoxLayout(box)
            h.setContentsMargins(10, 8, 10, 8)
            h.setSpacing(10)
            ic = _l(icon, "PIcon")
            ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
            h.addWidget(ic)
            c = QVBoxLayout()
            c.setSpacing(0)
            c.addWidget(_l(title, "PH3"))
            c.addWidget(_l(sub, "PMuted"))
            h.addLayout(c, 1)
            g.addWidget(box, i // 4, i % 4)
        lay.addLayout(g)
        self.lb_keys = _l("", "PMuted", wrap=True)
        lay.addWidget(self.lb_keys)
        lay.addStretch(1)
        return fr

    def _policy(self) -> QFrame:
        fr, lay = _card()
        lay.addWidget(_l("📜  Licence Policy", "PH3"))
        for t in POLICY:
            lay.addWidget(_l("✅  " + t, "PSmall", wrap=True))
        lay.addStretch(1)
        return fr

    def _details(self) -> QFrame:
        fr, lay = _card()
        lay.addWidget(_l("Current Plan Details", "PH3"))
        top = QFrame()
        top.setObjectName("PInner")
        tl = QVBoxLayout(top)
        tl.setContentsMargins(12, 10, 12, 10)
        row = QHBoxLayout()
        crown = _l("👑", "PIcon")
        crown.setAlignment(Qt.AlignmentFlag.AlignCenter)
        row.addWidget(crown)
        c = QVBoxLayout()
        c.setSpacing(0)
        self.lb_plan = _l("", "PH3")
        self.lb_plan_price = _l("", "PSmall", wrap=True)
        c.addWidget(self.lb_plan)
        c.addWidget(self.lb_plan_price)
        row.addLayout(c, 1)
        self.lb_badge2 = _l("", "PBadge")
        row.addWidget(self.lb_badge2, 0, Qt.AlignmentFlag.AlignTop)
        tl.addLayout(row)
        self.lb_left = _l("", "PMuted")
        self.lb_left.setAlignment(Qt.AlignmentFlag.AlignRight)
        tl.addWidget(self.lb_left)
        self.pb_left = QProgressBar()
        self.pb_left.setTextVisible(False)
        tl.addWidget(self.pb_left)
        lay.addWidget(top)
        self.detail_rows = {}
        for key, cap in (("start", "📅  Start Date"), ("end", "📅  Expiry Date"),
                         ("devices", "🖥  Device Limit")):
            r = QHBoxLayout()
            r.addWidget(_l(cap, "PSmall"))
            r.addStretch(1)
            v = _l("", "PSmall")
            r.addWidget(v)
            self.detail_rows[key] = v
            lay.addLayout(r)
        brow = QHBoxLayout()
        self.btn_keys2 = QPushButton("🔑 Key")
        self.btn_keys2.setObjectName("PGhost")
        self.btn_keys2.clicked.connect(self.licenseRequested.emit)
        self.btn_renew = QPushButton("🔄  Renew Now")
        self.btn_renew.setObjectName("PCta")
        self.btn_renew.setToolTip("Copies the buy message for the same length – the new time "
                                  "is added to what is left")
        self.btn_renew.clicked.connect(self._renew)
        brow.addWidget(self.btn_keys2)
        brow.addWidget(self.btn_renew, 1)
        lay.addLayout(brow)
        return fr

    def _activity(self) -> QFrame:
        fr, lay = _card()
        lay.addWidget(_l("Recent Activity", "PH3"))
        self.act_box = QVBoxLayout()
        self.act_box.setSpacing(10)
        lay.addLayout(self.act_box)
        return fr

    # ================================================================== #
    # actions
    # ================================================================== #
    def _machine(self) -> str:
        if not self._mid:
            from core import license as lic

            try:
                self._mid = lic.machine_id()
            except Exception:
                self._mid = "?"
        return self._mid

    def _show_machine(self):
        self.lb_mid.setText(self._machine() if self._show_mid else mask(self._machine()))
        self.btn_eye.setText("🙈" if self._show_mid else "👁")

    def _toggle_mid(self):
        self._show_mid = not self._show_mid
        self._show_machine()

    def _copy_mid(self):
        QGuiApplication.clipboard().setText(self._machine())
        self.btn_mid.setText("✓ Copied")
        QTimer.singleShot(1800, lambda: self.btn_mid.setText("⧉ Copy"))

    def _contact_url(self, contact: str) -> str:
        c = (contact or "").strip()
        for part in c.replace(",", " ").split():
            if part.startswith(("http://", "https://")):
                return part
            if part.startswith("t.me/"):
                return "https://" + part
            if part.startswith("@") and len(part) > 2:
                return "https://t.me/" + part[1:]
        return ""

    def _contact(self):
        data = pricing.load()
        url = self._contact_url(data["contact"])
        if url:
            QDesktopServices.openUrl(QUrl(url))
        elif data["contact"]:
            QGuiApplication.clipboard().setText(data["contact"])
            self.btn_contact.setText("✓ Contact copied")
            QTimer.singleShot(2000, lambda: self.btn_contact.setText("💬  Contact seller"))

    def buy(self, item: Dict, ask: bool = True) -> str:
        """Get Started / Renew Now: copy the buy message (Machine ID + Order ID)."""
        data = pricing.load()
        order = pricing.new_order_id()
        msg = pricing.request_message(item, self._machine(), data, order)
        QGuiApplication.clipboard().setText(msg)
        pricing.remember_order(order, item, data["currency"])
        self._fill_activity()
        if ask:
            contact = data["contact"] or "the seller"
            box = QMessageBox(self)
            box.setWindowTitle("Buy / renew")
            box.setIcon(QMessageBox.Icon.Information)
            box.setText(f"<b>The message is copied ✓</b><br>Order ID: <b>{order}</b><br><br>"
                        f"Paste it to {contact}"
                        + (f" and pay ({data['pay']})" if data["pay"] else "") +
                        ". You get your key after the payment is checked; paste it in "
                        "<b>Enter licence key</b>.")
            box.setDetailedText(msg)
            url = self._contact_url(data["contact"])
            open_btn = box.addButton("💬 Open chat", QMessageBox.ButtonRole.AcceptRole) \
                if url else None
            box.addButton(QMessageBox.StandardButton.Ok)
            box.exec()
            if open_btn is not None and box.clickedButton() is open_btn:
                QDesktopServices.openUrl(QUrl(url))
        return msg

    def _renew(self):
        data = pricing.load()
        item = self._same_length(data["items"]) or pricing.best(data["items"]) or \
            data["items"][-1]
        self.buy(item)

    def _same_length(self, items: List[Dict]) -> Optional[Dict]:
        from core import license as lic

        info = lic.current()
        if not info.total_days:
            return None
        return min(items, key=lambda i: abs(i["days"] - info.total_days))

    def _edit_prices(self):
        from ui.prices_dialog import PricesDialog

        if PricesDialog(self).exec():
            self.refresh()

    @staticmethod
    def _clear(layout):
        while layout.count():
            it = layout.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                PlansPage._clear(it.layout())

    # ================================================================== #
    # refresh
    # ================================================================== #
    def refresh(self):
        from core import license as lic
        from ui.home_page import licence_state

        admin, preview = plans.is_admin(), plans.previewing()
        self.admin_box.setVisible(admin)
        if admin:
            self.lb_admin.setText(
                f"👑 <b>Previewing the {plans.PLAN_NAMES[plans.current()]} plan</b> – you see "
                "what that customer sees." if preview else
                "👑 <b>Admin</b> (seller's PC): everything is open. Set the prices customers "
                "see with <b>Edit prices</b>; make keys in <b>Customers &amp; keys</b>.")
            self.btn_admin.setVisible(preview)

        data = pricing.load()
        items = data["items"]
        cur = data["currency"]
        info = lic.current()
        kind, text, detail = licence_state()
        same = self._same_length(items) if info.valid and not admin else None

        # ---- licence card
        badge = {"ok": "Active", "soon": "Renew soon", "bad": "Not active",
                 "admin": "Admin"}.get(kind, "")
        if kind == "bad" and "Trial" in text:
            badge = "Trial"
        for lb in (self.lb_badge, self.lb_badge2):
            lb.setText(badge)
            _polish(lb, state=kind)
        _polish(self.lic_card, state=kind)
        if admin:
            self.lb_state.setText("SARIKA VOXDUB PRO · Admin")
            self.lb_state_detail.setText(detail)
            ptype = "Admin"
        elif info.valid:
            ptype = plan_name(same) if same else "Licence"
            self.lb_state.setText(f"SARIKA VOXDUB PRO · {same['label'] if same else 'Licence'}")
            self.lb_state_detail.setText(
                f"📅 Expires on <b>{info.expires.isoformat()}</b>  "
                f"<span style='color:#2ee6a6'>({max(0, info.days_left)} days remaining)</span>")
        else:
            ptype = "—"
            self.lb_state.setText(text)
            self.lb_state_detail.setText(detail)
        self.lb_devices.setText("1 / 1")
        self.lb_type.setText(ptype)
        self._show_machine()
        self.btn_key.setText("👥  Customers && keys" if admin and not preview
                             else "🔑  Enter licence key")

        # ---- prices
        self.lb_note.setText(data["note"])
        self.lb_note.setVisible(bool(data["note"]))
        self._clear(self.prices_row)
        top = pricing.best(items)
        for it in items:
            self.prices_row.addWidget(self._price_card(it, items, cur, it is top), 1)

        # ---- how to buy, payment
        contact = data["contact"] or "the seller"
        self.lb_steps[0].setText("<b>Choose your plan</b><br>Press <b>Get Started</b> – a "
                                 "message with your Machine ID and an Order ID is copied.")
        self.lb_steps[1].setText(f"<b>Make the payment</b><br>Send the message to {contact}"
                                 + (f" and pay ({data['pay']})." if data["pay"] else "."))
        self.lb_steps[2].setText("<b>Get your licence</b><br>Paste the key you receive in "
                                 "<b>Enter licence key</b>.")
        self._clear(self.pay_row)
        methods = [m.strip() for m in (data["pay"] or "").replace(",", "/").split("/")
                   if m.strip()]
        for m in methods or ["ABA", "KHQR"]:
            icon = {"aba": "🏦", "khqr": "▦", "wing": "🪽", "acleda": "🏦"}.get(m.lower(), "💳")
            chip = _l(f"{icon}\n{m}", "PSmall")
            chip.setAlignment(Qt.AlignmentFlag.AlignCenter)
            chip.setStyleSheet("background:#0c1131; border:1px solid #2c3580; "
                               "border-radius:10px; padding:8px 10px; font-weight:700;")
            self.pay_row.addWidget(chip, 1)
        self.btn_contact.setVisible(bool(data["contact"]))
        self.btn_contact.setToolTip(data["contact"])

        # ---- current plan details
        if admin:
            self.lb_plan.setText("Admin – seller's PC")
            self.lb_plan_price.setText("Everything open, no key needed")
            self.lb_left.setText("")
            self.pb_left.setVisible(False)
            dates = ("—", "—")
        elif info.valid:
            self.lb_plan.setText(f"{ptype} licence")
            self.lb_plan_price.setText(
                f"{pricing.money(same['price'], cur)} / {same['label']}" if same else "")
            total = info.total_days or max(1, info.days_left)
            self.lb_left.setText(f"{max(0, info.days_left)} days remaining")
            self.pb_left.setVisible(True)
            self.pb_left.setRange(0, max(1, total))
            self.pb_left.setValue(max(0, min(total, info.days_left)))
            dates = (info.issued.isoformat() if info.issued else "—", info.expires.isoformat())
        else:
            self.lb_plan.setText("No licence yet" if "Trial" in text else "Licence not active")
            self.lb_plan_price.setText("Choose a plan below")
            self.lb_left.setText("")
            self.pb_left.setVisible(False)
            dates = ("—", "—")
        self.detail_rows["start"].setText(dates[0])
        self.detail_rows["end"].setText(dates[1])
        self.detail_rows["devices"].setText("1 / 1")
        self.btn_renew.setText("🔄  Renew Now" if info.valid and not admin else "🛒  Buy Now")
        self.btn_renew.setVisible(not (admin and not preview))
        self.btn_keys2.setVisible(not (admin and not preview))
        self._fill_activity()

        # ---- Admin preview of the plans (customers of PRO have everything)
        self._clear(self.grid)
        show_plans = admin or plans.locked_plans()
        self.lb_preview.setVisible(show_plans)
        cur_plan = plans.current() if (preview or not admin) else ""
        for col, p in enumerate(plans.PLANS if show_plans else []):
            self.grid.addWidget(self._plan_card(p, p == cur_plan, admin), 0, col)

        try:
            from core import gemini
            from core.tts import azure_configured

            g = "saved" if gemini.keys() else "not set"
            a = "saved" if azure_configured() else "not set"
        except Exception:
            g = a = "?"
        self.lb_keys.setText(f"Your own API keys – Gemini: {g} · Azure Speech: {a} "
                             "(Settings; a saved key is never shown again).")

    def _fill_activity(self):
        from core import license as lic

        self._clear(self.act_box)
        rows = []
        for h in lic.history():
            icon = "🔄" if "renew" in h.get("event", "").lower() else "✅"
            rows.append((h.get("time", ""), icon, h.get("event", ""), h.get("detail", "")))
        for o in pricing.orders():
            rows.append((o.get("time", ""), "🧾", "Buy message copied",
                         f"{o.get('order', '')} · {o.get('label', '')} · {o.get('price', '')}"))
        rows.sort(key=lambda r: r[0], reverse=True)
        if not rows:
            self.act_box.addWidget(_l("Nothing yet – your keys and buy messages show here.",
                                      "PMuted", wrap=True))
            return
        for time, icon, event, detail in rows[:5]:
            r = QHBoxLayout()
            ic = _l(icon, "PIcon")
            ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
            r.addWidget(ic, 0, Qt.AlignmentFlag.AlignTop)
            c = QVBoxLayout()
            c.setSpacing(0)
            c.addWidget(_l(event, "PH3"))
            c.addWidget(_l(time, "PMuted"))
            if detail:
                c.addWidget(_l(detail, "PMuted", wrap=True))
            r.addLayout(c, 1)
            self.act_box.addLayout(r)

    def _price_card(self, it: dict, items: List[dict], cur: str, top: bool) -> QFrame:
        card = QFrame()
        card.setObjectName("PPrice")
        card.setProperty("best", top)
        card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        v = QVBoxLayout(card)
        v.setContentsMargins(16, 14, 16, 14)
        v.setSpacing(6)
        head = QHBoxLayout()
        ic = _l("📅", "PIcon")
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.addWidget(ic)
        head.addWidget(_l(plan_name(it), "PH3"), 1)
        save = pricing.saving(it, items)
        mid = Qt.AlignmentFlag.AlignVCenter
        if top:
            head.addWidget(_l("Best Value", "PBest"), 0, mid)
        elif save:
            head.addWidget(_l(f"Save {save}%", "PSave"), 0, mid)
        v.addLayout(head)
        prow = QHBoxLayout()
        prow.addWidget(_l(pricing.money(it["price"], cur), "PPriceBig"))
        m = pricing.months(it)
        prow.addWidget(_l("/ month" if m == 1 and it["days"] <= 31 else f"/ {it['label']}",
                          "PMuted"), 0, Qt.AlignmentFlag.AlignBottom)
        prow.addStretch(1)
        v.addLayout(prow)
        pm = pricing.money(round(pricing.per_month(it), 2), cur)
        v.addWidget(_l(f"{pm} / month" + (f" · save {save}%" if save and top else ""),
                       "PSmall" if m > 1 else "PMuted"))
        v.addSpacing(4)
        for t in ("All features – AI Dubbing, AI Recap…", "1 computer (Machine ID)",
                  "Updates while active"):
            v.addWidget(_l("✅  " + t, "PSmall", wrap=True))
        v.addStretch(1)
        b = QPushButton("Get Started  →" if top else "Get Started")
        b.setObjectName("PCta" if top else "PGhost")
        b.setMinimumHeight(38)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.setToolTip("Copies a message with this price, your Machine ID and an Order ID – "
                     "paste it in Telegram / Messenger to the seller")
        b.clicked.connect(lambda _=False, it=it: self.buy(it))
        v.addWidget(b)
        return card

    def _plan_card(self, p: str, in_use: bool, admin: bool) -> QFrame:
        card, v = _card(spacing=6)
        head = QHBoxLayout()
        head.addWidget(_l(plans.PLAN_NAMES[p], "PH3"), 1)
        if in_use:
            head.addWidget(_l("IN USE", "PBest"))
        v.addLayout(head)
        v.addWidget(_l(plans.PLAN_WHO[p], "PMuted", wrap=True))
        verb = "Preview" if admin else "Use"
        b = QPushButton("In use" if in_use else f"{verb} {plans.PLAN_NAMES[p]}")
        b.setObjectName("PCta" if in_use else "PGhost")
        b.setMinimumHeight(34)
        b.setEnabled(not in_use)
        b.clicked.connect(lambda _=False, p=p: self.planChosen.emit(p))
        v.addWidget(b)
        for name, value in plans.LIMITS[p].items():
            v.addWidget(_l(f"•  {name}: {value}", "PSmall"))
        for f in plans.FEATURES:
            on = plans.allows(f, p)
            v.addWidget(_l(("✓  " if on else "–  ") + plans.FEATURE_NAMES[f],
                           "PYes" if on else "PNo"))
        v.addStretch(1)
        return card
