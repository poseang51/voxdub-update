"""
home_page.py - the Home dashboard of SARIKA VOXDUB PRO.

    ┌ sidebar ┐┌──────────── Home ────────────────────────────┐┌ right ───────┐
    │ Home    ││ ╭ Good morning · What do you want to make? ╮ ││ Your licence │
    │ Edit    ││ ① Drop a video  ② Check  ③ Export            ││ Batch        │
    │ Dub     ││ [Edit video] [Dub a video] [Batch a series]  ││ What's new   │
    │ Batch   ││ Quick tools (3 × 3)                          ││  in 1.2.0    │
    │ …       ││ Recent projects (thumbnails)                 ││              │
    │ licence │└──────────────────────────────────────────────┘└──────────────┘
    └─────────┘   or the Plan & licence page (prices, days left, Machine ID)

Every card takes a dropped video (a folder for Batch). The page only asks
the main window to do things through its signals; it never edits a project.
"""

import datetime as dt
import os
import threading
from typing import Dict, List, Tuple

from PySide6.QtCore import QObject, QSize, Qt, Signal
from PySide6.QtGui import QColor, QPixmap
from PySide6.QtWidgets import (
    QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel, QProgressBar, QPushButton, QScrollArea,
    QSizePolicy, QStackedWidget, QTextBrowser, QVBoxLayout, QWidget,
)

from core import __version__, changelog, plans, recent
from core.i18n import tr as _tr
from ui.plans_page import PlansPage  # noqa: E402,F401  (Plan & licence page)
from core.appinfo import APP_NAME, EDITION
from core.batch import VIDEO_EXT

SPACES = [
    # key, icon, title, small line, text, drop text, button, colour
    ("edit", "✂️", "Edit video", "cut · speed · text · music",
     "Cut and join clips, add titles, music, logos and an intro. "
     "Export for Facebook, TikTok or YouTube.",
     "Drop a video here", "New edit", "#5AA9FF"),
    ("dub", "🎙️", "Dub a video", "Chinese → Khmer voice",
     "Listens, translates and speaks Khmer with one voice per character. "
     "Khmer subtitles, old subtitles hidden.",
     "Drop a video here", "New dub", "#22C3A6"),
    ("batch", "📚", "Batch a series", "many episodes · runs alone",
     "Add a folder of episodes and start. The same voice for every character in "
     "every episode. Merge them at the end.",
     "Drop a folder here", "New batch", "#F5B942"),
    ("recap", "🎬", "AI Recap", "a whole story · 5–10 min",
     "A long drama told again in Khmer: AI understands the story, writes the "
     "narration and cuts the scenes to it.",
     "Drop the videos here", "New recap", "#B06BFF"),
]
TOOLS = [
    # key, label, feature needed
    ("merge", "Merge episodes", "edit"),
    ("split", "Split a long video", "edit"),
    ("hide_subs", "Hide old subtitles", "hide_subs"),
    ("black_bars", "Remove black bars", "edit"),
    ("srt", "Khmer subtitles only (SRT)", "dub"),
    ("music_only", "Music only (no voices)", "music_only"),
    ("reframe", "Reframe – turn, mirror, 9:16", "edit"),
    ("folder_edit", "Edit a whole folder", "edit"),
    ("copyright", "Copyright check", "edit"),
]
TOOL_ICONS = {"merge": "🔗", "split": "✂️", "hide_subs": "🙈", "black_bars": "⬛", "srt": "💬",
              "music_only": "🎵", "reframe": "🔄", "folder_edit": "📂", "copyright": "©️"}
# 2.6: the SARIKA design (deep navy + blue / purple), Home and its pages only
HOME_QSS = """
QWidget#HomePage, QWidget#HomeBody { background-color: #0a0e27; }
QWidget#HomePage QLabel { color: #e8eaff; }
QFrame#HomeTop { background: #0b1030; border-bottom: 1px solid #1f2660; }
QLabel#HomeLogo { font-size: 20px; color: white; border-radius: 12px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #3d5bff, stop:1 #b06bff); }
QLabel#HomeBrand { font-size: 21px; font-weight: 900; color: #ffffff; letter-spacing: 1px; }
QLabel#HomeBrandPro { font-size: 13px; font-weight: 900; color: white; border-radius: 8px;
    padding: 1px 9px; background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6d4dff,
    stop:1 #b06bff); }
QLabel#HomeBrandLine { color: #b9c0f0; font-size: 12px; }
QLabel#TestingBadge { font-size: 10px; font-weight: 800; color: #241a02; background: #f5b942;
    border-radius: 5px; padding: 1px 6px; }
QLineEdit#HomeSearch { background: #0f1540; border: 1px solid #2c3580; border-radius: 18px;
    padding: 8px 16px; color: #e8eaff; min-width: 300px; }
QLineEdit#HomeSearch:focus { border-color: #8a6bff; }
QPushButton#HomeTopIcon { background: transparent; border: none; font-size: 18px;
    color: #c9cff5; padding: 4px 8px; border-radius: 8px; }
QPushButton#HomeTopIcon:hover { background: #18205a; }
QPushButton#HomeUser { background: transparent; border: none; text-align: left; padding: 2px 6px;
    border-radius: 10px; }
QPushButton#HomeUser:hover { background: #18205a; }
QLabel#HomeAvatar { color: white; font-weight: 800; font-size: 15px; border-radius: 19px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #3d5bff, stop:1 #b06bff); }
QLabel#HomeUserName { font-weight: 700; color: white; }
QLabel#HomeUserPlan { color: #8f9bff; font-size: 11px; }
QFrame#HomeSide { background-color: #0b1030; border-right: 1px solid #1f2660; }
QLabel#HomeCap { color: #7a82b8; font-size: 11px; font-weight: 800; letter-spacing: 1px;
    padding: 16px 12px 4px 12px; }
QPushButton#HomeNav { text-align: left; padding: 0 14px; border: none; border-radius: 10px;
    background: transparent; color: #c9cff5; font-size: 14px; }
QPushButton#HomeNav:hover { background: #151c50; color: #ffffff; }
QPushButton#HomeNav:checked { color: white; font-weight: 700; border: 1px solid #5c6bff;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3346d8, stop:1 #5b3fd0); }
QFrame#HomeUserCard { background: #10163a; border: 1px solid #262d6b; border-radius: 12px; }
QPushButton#HomePlanBox { border: 1px solid #4a3aa8; border-radius: 14px; text-align: left;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2a1f7a, stop:1 #4b2a9a); }
QPushButton#HomePlanBox:hover { border-color: #b06bff; }
QLabel#HomePlanBoxTitle { font-size: 15px; font-weight: 800; color: white; }
QLabel#HomeSideState { color: #d6d0ff; font-size: 12px; }
QLabel#HomeSideBtn { color: white; font-weight: 800; border-radius: 9px; padding: 7px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7c3aed, stop:1 #b06bff); }
QLabel#HomeVersion { color: #7a82b8; font-size: 11px; }
QLabel#HomeBadge { font-size: 11px; font-weight: 800; border-radius: 8px; padding: 2px 9px;
    background: #3b2a9a; color: #e2d8ff; }
QLabel#HomeBadge[plan="basic"] { background: #2a3168; color: #c9cff5; }
QLabel#HomeBadge[plan="pro"] { background: #1f3f8a; color: #b9d0ff; }
QFrame#HomeHero { border-radius: 16px; border: 1px solid #3a3fa0;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1b2a8a, stop:0.55 #3a2aa8,
    stop:1 #6a2fc8); }
QLabel#HomeHello { color: #c9bfff; font-size: 13px; font-weight: 700; }
QLabel#HomeHeroText { color: #d6dcff; font-size: 14px; }
QLabel#HomeSlogan { color: #e6dcff; font-size: 26px; font-style: italic; font-weight: 700; }
QLabel#HomePlay { color: white; font-size: 20px; border-radius: 22px;
    background: rgba(255,255,255,0.18); border: 1px solid rgba(255,255,255,0.4); }
QPushButton#HomeChip { background: rgba(10,14,39,0.55); border: 1px solid rgba(255,255,255,0.25);
    border-radius: 14px; padding: 6px 14px; color: #ffffff; font-weight: 700; }
QPushButton#HomeChip:hover { border-color: #c9bfff; }
QFrame#HomeStep { background: #10163a; border: 1px solid #262d6b; border-radius: 12px; }
QLabel#HomeStepNum { background: #3d5bff; color: white; font-weight: 800; border-radius: 14px; }
QLabel#HomeStepTitle { color: #ffffff; font-weight: 700; }
QLabel#HomeArrow { color: #4a529a; font-size: 20px; }
QLabel#HomeH1 { font-size: 26px; font-weight: 800; color: #ffffff; }
QLabel#HomeH2 { font-size: 17px; font-weight: 800; color: #ffffff; }
QLabel#HomeText { color: #c3c8ee; }
QLabel#MutedLabel { color: #9aa3cf; }
QLabel#HomeBig { font-size: 20px; font-weight: 800; color: #ffffff; }
QLabel#HomeEmpty { color: #9aa3cf; border: 1.5px dashed #2c3580; border-radius: 12px; }
QFrame#HomeCard { background: #10163a; border: 1px solid #262d6b; border-radius: 16px; }
QFrame#HomeCard:hover { border-color: #5c6bff; background: #121a45; }
QFrame#HomeCard[locked="true"] { background: #0d1233; }
QLabel#HomeCardTitle { font-size: 17px; font-weight: 800; color: #ffffff; }
QLabel#HomeCardText { color: #b9c0e8; }
QLabel#HomeDrop { color: #9aa3cf; border: 1.5px dashed #2f3a8a; border-radius: 10px;
    background: #0c1131; }
QFrame#HomeBox { background: #10163a; border: 1px solid #262d6b; border-radius: 14px; }
QFrame#HomeUpsell { border: 1px solid #4a3aa8; border-radius: 14px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #2a1f7a, stop:1 #4b2a9a); }
QLabel#HomeBoxTitle { font-size: 15px; font-weight: 800; color: #ffffff; }
QLabel#HomeVerChip { font-size: 11px; font-weight: 800; color: #e2d8ff; background: #3b2a9a;
    border-radius: 8px; padding: 2px 8px; }
QLabel#HomeState { font-size: 18px; font-weight: 800; color: #e8eaff; }
QLabel#HomeState[state="ok"], QLabel#HomeSideState[state="ok"] { color: #2ee6a6; }
QLabel#HomeState[state="soon"], QLabel#HomeSideState[state="soon"] { color: #f5b942; }
QLabel#HomeState[state="bad"], QLabel#HomeSideState[state="bad"] { color: #ff7a7a; }
QLabel#HomeState[state="admin"], QLabel#HomeSideState[state="admin"] { color: #c9b4ff; }
QProgressBar#HomeBar { background: #232a63; border: none; border-radius: 4px; }
QProgressBar#HomeBar::chunk { border-radius: 4px; background: qlineargradient(x1:0, y1:0, x2:1,
    y2:0, stop:0 #5b4dff, stop:1 #c35cff); }
QPushButton#HomeLink { background: transparent; border: none; color: #8f9bff; padding: 2px 0;
    font-weight: 700; }
QPushButton#HomeLink:hover { color: #c9bfff; }
QPushButton#HomeAmber { color: white; border: none; border-radius: 10px; font-weight: 800;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #7c3aed, stop:1 #b06bff); }
QPushButton#HomeTool { text-align: left; padding: 0 14px; background: #10163a;
    border: 1px solid #262d6b; border-radius: 12px; color: #dfe3ff; font-size: 13px; }
QPushButton#HomeTool:hover { border-color: #8a6bff; background: #151c50; color: #ffffff; }
QPushButton#HomeRecent { background: #10163a; border: 1px solid #262d6b; border-radius: 12px;
    text-align: left; }
QPushButton#HomeRecent:hover { border-color: #8a6bff; }
QLabel#HomeThumb { background: #0c1131; border-radius: 8px; color: #4a529a; font-size: 20pt; }
QLabel#HomeRecentTitle { color: #ffffff; font-weight: 600; }
QPushButton#HomeCta { color: white; border: none; border-radius: 10px; font-weight: 800;
    padding: 0 16px; background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #5b4dff,
    stop:1 #b06bff); }
QPushButton#HomeCta:hover { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6d60ff,
    stop:1 #c080ff); }
QPushButton#HomeGhost { background: transparent; color: #e8eaff; border: 1px solid #3a4590;
    border-radius: 10px; font-weight: 700; padding: 0 14px; min-height: 30px; }
QPushButton#HomeGhost:hover { border-color: #9b7bff; }
"""

STEPS = [("1", "Drop a video", "on Edit, Dub or Batch below"),
         ("2", "Check & fix", "the voices, Khmer text and subtitles"),
         ("3", "Export", "for Facebook, TikTok or YouTube")]
KIND_COLOUR = {"edit": "#5AA9FF", "dub": "#22C3A6", "batch": "#F5B942"}
KIND_NAME = {"edit": "Edit", "dub": "Dub", "batch": "Batch"}
INCLUDED = ["Edit video – cut, text, music, logos", "Dub Chinese → Khmer, one voice per character",
            "Khmer subtitles, hide old subtitles", "Batch a whole series + series cast",
            "🎬 AI Recap – a whole story in a few minutes", "📚 Voice Library – voice clone",
            "Export 1080p, no watermark", "Copyright check, quality check, updates"]
STATE_COLOUR = {"ok": "#22C3A6", "soon": "#F5B942", "bad": "#EF5350", "admin": "#B48CFF"}

# 2.0: the card / tag / state colours on the design tokens (ui/theme.py)
from ui import theme as _theme  # noqa: E402

SPACES = [s[:-1] + (_theme.legacy(s[-1]),) for s in SPACES]
KIND_COLOUR = {k: _theme.legacy(v) for k, v in KIND_COLOUR.items()}
STATE_COLOUR = {k: _theme.legacy(v) for k, v in STATE_COLOUR.items()}


def _label(text: str, name: str = "", wrap: bool = False) -> QLabel:
    lb = QLabel(text)
    if name:
        lb.setObjectName(name)
    lb.setWordWrap(wrap)
    return lb


def _is_video(path: str) -> bool:
    return os.path.isfile(path) and path.lower().endswith(VIDEO_EXT)


def greeting(hour: int = -1) -> str:
    hour = dt.datetime.now().hour if hour < 0 else hour
    return "Good morning" if hour < 12 else "Good afternoon" if hour < 18 else "Good evening"


def _owner() -> bool:
    """The seller's own PC (it holds the signing key) - SARIKA VOICE is shown
    only there."""
    try:
        from core import admin

        return bool(admin.is_owner())
    except Exception:
        return False


def licence_state() -> Tuple[str, str, str]:
    """(kind, short text, detail): kind is ok / soon / bad / admin."""
    if plans.is_admin():
        return "admin", "Admin", "The seller's PC – everything open, no key needed."
    from core import license as lic

    info = lic.current()
    if info.valid:
        d = info.days_left
        until = info.expires.strftime("%d %b %Y") if info.expires else "—"
        if d <= 7:
            return "soon", f"{d} days left – renew soon", f"Until {until}"
        return "ok", f"Active · {d} days left", f"Until {until}"
    if not lic.stored_key():
        return "bad", "Trial – no licence key", (
            "Everything works; exported videos show a watermark." if lic.TRIAL_ENABLED
            else "Enter a key to use it without limits.")
    if "expired" in info.reason.lower():
        return "bad", "Licence expired", info.reason
    return "bad", "Licence not valid", info.reason


def _paint_state(lb: QLabel, kind: str):
    lb.setProperty("state", kind)
    lb.style().polish(lb)


class _Thumbs(QObject):
    """Makes the missing thumbnails of the recent projects in a thread."""
    ready = Signal()

    def make(self, videos: List[str]):
        from ui.batch_dialog import make_thumb, thumb_path

        todo = [v for v in videos if v and os.path.isfile(v)
                and not os.path.isfile(thumb_path(v))]
        if not todo:
            return

        def run():
            for v in todo:
                make_thumb(v, thumb_path(v))
            self.ready.emit()

        threading.Thread(target=run, daemon=True).start()


class ChangelogDialog(QDialog):
    """Every version and what it brought (core/changelog.py)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{APP_NAME} – what's new")
        self.resize(560, 480)
        view = QTextBrowser()
        html = []
        for v, date, items in changelog.CHANGES:
            now = "  <span style='color:#22C3A6'>(you have this)</span>" if v == __version__ else ""
            html.append(f"<h3>Version {v} <span style='color:#8b949e; font-weight:400'>"
                        f"· {date}</span>{now}</h3><ul>"
                        + "".join(f"<li>{_tr(t)}</li>" for t in items) + "</ul>")
        view.setHtml("".join(html))
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        lay = QVBoxLayout(self)
        lay.addWidget(view, 1)
        lay.addWidget(b, 0, Qt.AlignmentFlag.AlignRight)


# --------------------------------------------------------------------------- #
class WorkspaceCard(QFrame):
    """One of the three big cards. Takes dropped videos / folders."""
    chosen = Signal(str, list)          # key, dropped paths ([] = button)

    def __init__(self, key, icon, title, small, text, drop, button, colour):
        super().__init__()
        self.key, self.colour = key, colour
        self.setObjectName("HomeCard")
        self.setAcceptDrops(True)
        self.setStyleSheet(f"QFrame#HomeCard[drag=\"true\"] {{ border: 2px solid {colour}; }}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 18, 18, 18)
        lay.setSpacing(12)
        head = QHBoxLayout()
        head.setSpacing(12)
        ic = _label(icon, "HomeCardIcon")
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ic.setFixedSize(48, 48)
        r, g, b = (int(colour[i:i + 2], 16) for i in (1, 3, 5))
        ic.setStyleSheet(f"background: rgba({r},{g},{b},40); border-radius: 14px;")
        names = QVBoxLayout()
        names.setSpacing(1)
        names.addWidget(_label(title, "HomeCardTitle"))
        sm = _label(small, "HomeCardSmall")
        sm.setStyleSheet(f"color: {colour};")
        names.addWidget(sm)
        self.lock = _label("Studio", "HomeLock")
        head.addWidget(ic)
        head.addLayout(names, 1)
        head.addWidget(self.lock, 0, Qt.AlignmentFlag.AlignTop)
        lay.addLayout(head)
        desc = _label(text, "HomeCardText", wrap=True)
        desc.setMinimumHeight(54)
        desc.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(desc, 1)
        self.drop = _label(f"⤓  {drop}", "HomeDrop")
        self.drop.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.drop.setMinimumHeight(56)
        lay.addWidget(self.drop)
        self.btn = QPushButton(button)
        self.btn.setObjectName("HomeCta")
        self.btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn.setMinimumHeight(42)
        self.btn.clicked.connect(lambda: self.chosen.emit(self.key, []))
        lay.addWidget(self.btn)
        self._button_text = button
        self.set_locked(False)

    def set_locked(self, locked: bool, plan_name: str = "Studio"):
        self.locked = locked
        self.lock.setText("🔒 " + plan_name)
        self.lock.setVisible(locked)
        self.btn.setText(f"Unlock with {plan_name}" if locked else f"＋  {self._button_text}")
        self.btn.setStyleSheet("" if locked else self._cta_qss())
        self.setProperty("locked", locked)
        self.style().polish(self)

    def _cta_qss(self) -> str:
        """2.0: Dub (the main job) is the one solid button; Edit / Batch keep
        their colour as a tint, so the three cards do not shout together."""
        if self.key == "dub":
            return ""                   # 2.6: the page's purple gradient (the main job)
        if _theme.LEGACY:
            return (f"QPushButton#HomeCta {{ background: {self.colour}; "
                    "color: #0D1014; border: none; }"
                    "QPushButton#HomeCta:hover { background: #ffffff; }")
        if self.colour == _theme.ACCENT:
            return (f"QPushButton#HomeCta {{ background: {self.colour}; color: {_theme.BG}; "
                    "border: none; font-weight: 700; }"
                    "QPushButton#HomeCta:hover { background: #2DD4BF; }")
        c = QColor(self.colour)
        r, g, b = c.red(), c.green(), c.blue()
        return (f"QPushButton#HomeCta {{ background: rgba({r},{g},{b},36); color: {self.colour}; "
                f"border: 1px solid rgba({r},{g},{b},110); font-weight: 700; }}"
                f"QPushButton#HomeCta:hover {{ background: rgba({r},{g},{b},64); }}")

    def _paths(self, ev) -> List[str]:
        if not ev.mimeData().hasUrls():
            return []
        return [os.path.normpath(u.toLocalFile()) for u in ev.mimeData().urls() if u.isLocalFile()]

    def _fits(self, paths: List[str]) -> bool:
        if self.key in ("batch", "recap"):
            return any(os.path.isdir(p) or _is_video(p) for p in paths)
        return any(_is_video(p) for p in paths)

    def dragEnterEvent(self, ev):
        if self._fits(self._paths(ev)):
            self.setProperty("drag", True)
            self.style().polish(self)
            ev.acceptProposedAction()

    def dragLeaveEvent(self, ev):
        self.setProperty("drag", False)
        self.style().polish(self)

    def dropEvent(self, ev):
        self.setProperty("drag", False)
        self.style().polish(self)
        paths = [p for p in self._paths(ev) if os.path.isdir(p) or _is_video(p)]
        if paths:
            ev.acceptProposedAction()
            self.chosen.emit(self.key, paths)


class RecentTile(QPushButton):
    def __init__(self, entry: Dict):
        super().__init__()
        self.entry = entry
        self.setObjectName("HomeRecent")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(176)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 8, 8, 8)
        lay.setSpacing(4)
        self.pic = QLabel()
        self.pic.setObjectName("HomeThumb")
        self.pic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pic.setFixedHeight(110)
        self.pic.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        kind = entry.get("kind", "dub")
        tag = _label(KIND_NAME.get(kind, kind), "HomeTag")
        tag.setStyleSheet(f"background: {KIND_COLOUR.get(kind, '#9AA5B4')};")
        top = QHBoxLayout(self.pic)
        top.setContentsMargins(6, 6, 6, 6)
        top.addWidget(tag, 0, Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        top.addStretch(1)
        length = float(entry.get("length") or 0)
        if length:
            m, s = divmod(int(length), 60)
            h, m = divmod(m, 60)
            ln = _label(f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}", "HomeLen")
            top.addWidget(ln, 0, Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignRight)
        title = _label(entry.get("title") or os.path.basename(entry["path"]), "HomeRecentTitle")
        title.setToolTip(entry["path"])
        title.setMaximumWidth(260)
        sub = _label(" · ".join(x for x in (entry.get("state", ""),
                                             recent.when(entry.get("time", 0))) if x),
                     "MutedLabel")
        for w in (title, sub):
            w.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        lay.addWidget(self.pic)
        lay.addWidget(title)
        lay.addWidget(sub)
        self.load_thumb()

    def load_thumb(self):
        from ui.batch_dialog import thumb_path

        v = self.entry.get("video", "")
        pm = QPixmap(thumb_path(v)) if v else QPixmap()
        if pm.isNull():
            self.pic.setText("🎬")
            return
        self.pic.setPixmap(pm.scaled(QSize(260, 110), Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation))


# --------------------------------------------------------------------------- #
# --------------------------------------------------------------------------- #
class HomePage(QWidget):
    workspaceRequested = Signal(str, str)     # "edit" / "dub", video path ("" = none)
    batchRequested = Signal(list)             # videos / folders ([] = just open)
    quickRequested = Signal(str)              # TOOLS key
    recentRequested = Signal(dict)            # a recent.items() entry
    planChanged = Signal(str)
    settingsRequested = Signal()
    libraryRequested = Signal(str)
    licenseRequested = Signal()
    sarikaVoiceRequested = Signal()           # 🎙 SARIKA VOICE (owner's PC only)
    recapRequested = Signal()                 # 🎬 AI Recap (2.5 preview)
    recapVideosRequested = Signal(list)       # 🎬 videos dropped on the AI Recap card
    voiceLibraryRequested = Signal()          # 🗣 Voice Library (2.6 sidebar)
    projectsRequested = Signal()              # 📂 My Projects: open a saved project
    appearanceRequested = Signal()            # 🎨 language, colour, light / dark

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("HomePage")
        if not _theme.LEGACY:
            self.setStyleSheet(HOME_QSS)
        self.batch_status = None              # callable -> (done, total, now text) or None
        self._thumbs = _Thumbs()
        self._thumbs.ready.connect(self._reload_thumbs)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._topbar())
        root = QHBoxLayout()
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._sidebar())
        self.pages = QStackedWidget()
        self.pages.addWidget(self._home())
        self.plans_page = PlansPage()
        self.plans_page.planChosen.connect(self._plan_chosen)
        self.plans_page.backRequested.connect(lambda: self.show_page("home"))
        self.plans_page.licenseRequested.connect(self.licenseRequested.emit)
        self.pages.addWidget(self.plans_page)
        root.addWidget(self.pages, 1)
        outer.addLayout(root, 1)
        self._navs["home"].setChecked(True)
        self.refresh()

    # ------------------------------------------------------------------ #
    def _topbar(self) -> QWidget:
        """Logo · what the app does · 🔍 search · 🔔 · ⚙ · the user."""
        bar = QFrame()
        bar.setObjectName("HomeTop")
        h = QHBoxLayout(bar)
        h.setContentsMargins(18, 10, 18, 10)
        h.setSpacing(12)
        logo = _label("▶", "HomeLogo")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setFixedSize(46, 46)
        h.addWidget(logo)
        names = QVBoxLayout()
        names.setSpacing(0)
        top = QHBoxLayout()
        top.setSpacing(8)
        base = APP_NAME.rsplit(" ", 1)[0]
        top.addWidget(_label(base.replace("VOXDUB", "<span style='color:#8f7bff'>VOXDUB</span>"),
                             "HomeBrand"))
        top.addWidget(_label(APP_NAME.rsplit(" ", 1)[-1], "HomeBrandPro"), 0,
                      Qt.AlignmentFlag.AlignVCenter)
        from core import appinfo as _ai
        _badge = EDITION.upper() or getattr(_ai, "BUILD_LABEL", "")
        if _badge:
            top.addWidget(_label(_badge, "TestingBadge"), 0, Qt.AlignmentFlag.AlignVCenter)
        top.addStretch(1)
        names.addLayout(top)
        names.addWidget(_label("AI Dubbing  •  AI Recap  •  Batch a series  •  Voice Library",
                               "HomeBrandLine"))
        h.addLayout(names)
        h.addStretch(1)
        from PySide6.QtWidgets import QLineEdit

        self.ed_search = QLineEdit()
        self.ed_search.setObjectName("HomeSearch")
        self.ed_search.setPlaceholderText("🔍  Search projects or tools…")
        self.ed_search.setClearButtonEnabled(True)
        self.ed_search.textChanged.connect(self._search)
        self.ed_search.returnPressed.connect(self._search_go)
        h.addWidget(self.ed_search)
        self.btn_bell = QPushButton("🔔")
        self.btn_bell.setObjectName("HomeTopIcon")
        self.btn_bell.setToolTip("Notifications")
        self.btn_bell.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_bell.clicked.connect(self._notifications)
        self.btn_lang = QPushButton("🌐 EN")
        self.btn_lang.setObjectName("HomeTopIcon")
        self.btn_lang.setToolTip("Language: English / ខ្មែរ")
        self.btn_lang.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_lang.clicked.connect(self._toggle_language)
        b_look = QPushButton("🎨")
        b_look.setObjectName("HomeTopIcon")
        b_look.setToolTip("Appearance: colour, light / dark, language")
        b_look.setCursor(Qt.CursorShape.PointingHandCursor)
        b_look.clicked.connect(self.appearanceRequested.emit)
        h.addWidget(self.btn_lang)
        h.addWidget(b_look)
        gear = QPushButton("⚙")
        gear.setObjectName("HomeTopIcon")
        gear.setToolTip("Settings & API keys")
        gear.setCursor(Qt.CursorShape.PointingHandCursor)
        gear.clicked.connect(self.settingsRequested.emit)
        h.addWidget(self.btn_bell)
        h.addWidget(gear)
        self.btn_user = QPushButton()
        self.btn_user.setObjectName("HomeUser")
        self.btn_user.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_user.setMinimumSize(170, 46)
        self.btn_user.clicked.connect(lambda: self.show_page("plans"))
        ul = QHBoxLayout(self.btn_user)
        ul.setContentsMargins(6, 2, 6, 2)
        self.lb_avatar = _label("", "HomeAvatar")
        self.lb_avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lb_avatar.setFixedSize(38, 38)
        uc = QVBoxLayout()
        uc.setSpacing(0)
        self.lb_user = _label("", "HomeUserName")
        self.lb_user_plan = _label("", "HomeUserPlan")
        uc.addWidget(self.lb_user)
        uc.addWidget(self.lb_user_plan)
        for w in (self.lb_avatar, self.lb_user, self.lb_user_plan):
            w.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        ul.addWidget(self.lb_avatar)
        ul.addLayout(uc, 1)
        h.addWidget(self.btn_user)
        return bar

    def _nav(self, text: str, slot, key: str = "") -> QPushButton:
        b = QPushButton(text.replace("&", "&&"))      # (a single & would be a shortcut key)
        b.setObjectName("HomeNav")
        b.setCheckable(bool(key))
        b.setMinimumHeight(42)
        b.setCursor(Qt.CursorShape.PointingHandCursor)
        b.clicked.connect(slot)
        if key:
            self._navs[key] = b
        return b

    def _sidebar(self) -> QWidget:
        self._navs: Dict[str, QPushButton] = {}
        side = QFrame()
        side.setObjectName("HomeSide")
        side.setFixedWidth(236)
        v = QVBoxLayout(side)
        v.setContentsMargins(12, 16, 12, 14)
        v.setSpacing(3)
        v.addWidget(self._nav("🏠   Home", lambda: self.show_page("home"), "home"))
        v.addWidget(_label("CREATE", "HomeCap"))
        v.addWidget(self._nav("🎙️   AI Dubbing", lambda: self.workspaceRequested.emit("dub", "")))
        v.addWidget(self._nav("✂️   Edit video", lambda: self.workspaceRequested.emit("edit", "")))
        self.nav_batch = self._nav("📚   Batch a series", lambda: self.batchRequested.emit([]))
        v.addWidget(self.nav_batch)
        self.nav_recap = self._nav("🎬   AI Recap", self.recapRequested.emit)
        self.nav_recap.setToolTip("A long drama (60 min+) told again in 5–10 minutes in Khmer: "
                                  "story summary, narration, scenes cut by themselves")
        v.addWidget(self.nav_recap)
        nav_lib = self._nav("🗣️   Voice Library", self.voiceLibraryRequested.emit)
        nav_lib.setToolTip("Voices to clone with VoxCPM2 – as the man / woman voice or for "
                           "one character")
        v.addWidget(nav_lib)
        v.addWidget(self._nav("📂   My Projects", self.projectsRequested.emit))
        # SARIKA VOICE: only on the owner's PC (Admin) - customers never see it
        self.nav_voice = self._nav("🎤   SARIKA VOICE   · Admin", self.sarikaVoiceRequested.emit)
        self.nav_voice.setToolTip("SARIKA VOICE – Voice library, Text-to-Speech, Story Studio, "
                                  "BGM & SFX (D:\\sarika_voice).\nOnly on this PC (Admin).")
        self.nav_voice.setVisible(_owner())
        v.addWidget(self.nav_voice)
        v.addWidget(_label("ACCOUNT", "HomeCap"))
        v.addWidget(self._nav("💳   Plan & Licence", lambda: self.show_page("plans"), "plans"))
        v.addWidget(self._nav("⚙️   Settings & API Keys", self.settingsRequested.emit))
        v.addWidget(self._nav("✨   What's New", self.show_changelog))
        v.addStretch(1)
        # the licence box (like "Upgrade to Pro" in the design)
        box = QPushButton()
        box.setObjectName("HomePlanBox")
        box.setCursor(Qt.CursorShape.PointingHandCursor)
        box.clicked.connect(lambda: self.show_page("plans"))
        bl = QVBoxLayout(box)
        bl.setContentsMargins(14, 12, 14, 12)
        bl.setSpacing(6)
        top = QHBoxLayout()
        self.lb_side_icon = _label("👑", "HomeBoxTitle")
        self.lb_side_title = _label("", "HomePlanBoxTitle")
        top.addWidget(self.lb_side_icon)
        top.addWidget(self.lb_side_title, 1)
        bl.addLayout(top)
        self.lb_side_plan = _label("", "HomeBadge")
        self.lb_side_lic = _label("", "HomeSideState", wrap=True)
        self.lb_side_btn = _label("", "HomeSideBtn")
        self.lb_side_btn.setAlignment(Qt.AlignmentFlag.AlignCenter)
        bl.addWidget(self.lb_side_plan, 0, Qt.AlignmentFlag.AlignLeft)
        bl.addWidget(self.lb_side_lic)
        bl.addWidget(self.lb_side_btn)
        for w in (self.lb_side_icon, self.lb_side_title, self.lb_side_plan, self.lb_side_lic,
                  self.lb_side_btn):
            w.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        box.setMinimumHeight(132)
        v.addSpacing(8)
        v.addWidget(box)
        ver = _label(f"Version {__version__}", "HomeVersion")
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        v.addSpacing(6)
        v.addWidget(ver)
        return side

    def _home(self) -> QWidget:
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.Shape.NoFrame)
        inner = QWidget()
        inner.setObjectName("HomeBody")
        row = QHBoxLayout(inner)
        row.setContentsMargins(28, 24, 28, 24)
        row.setSpacing(24)
        col = QVBoxLayout()
        col.setSpacing(18)

        # ---- hero
        hero = QFrame()
        hero.setObjectName("HomeHero")
        hl = QHBoxLayout(hero)
        hl.setContentsMargins(26, 22, 26, 22)
        ht = QVBoxLayout()
        ht.setSpacing(4)
        self.lb_hello = _label("", "HomeHello")
        ht.addWidget(self.lb_hello)
        ht.addWidget(_label("What do you want to make today?", "HomeH1"))
        ht.addWidget(_label("Drop a video on a card below – or click its button. A project moves "
                            "between Edit and Dub without exporting.", "HomeHeroText", wrap=True))
        hl.addLayout(ht, 1)
        slogan = _label("Create More,\n      Worry Less", "HomeSlogan")
        hl.addWidget(slogan, 0, Qt.AlignmentFlag.AlignVCenter)
        play = QPushButton("▶")
        play.setObjectName("HomeChip")
        play.setFixedSize(46, 46)
        play.setStyleSheet("border-radius: 23px; font-size: 18px;")
        play.setToolTip("Start a dub")
        play.setCursor(Qt.CursorShape.PointingHandCursor)
        play.clicked.connect(lambda: self.workspaceRequested.emit("dub", ""))
        hl.addSpacing(10)
        hl.addWidget(play, 0, Qt.AlignmentFlag.AlignVCenter)
        hl.addSpacing(16)
        chips = QVBoxLayout()
        chips.setSpacing(8)
        b_ver = QPushButton(f"✨ Version {__version__} · what's new")
        b_ver.setObjectName("HomeChip")
        b_ver.setCursor(Qt.CursorShape.PointingHandCursor)
        b_ver.clicked.connect(self.show_changelog)
        self.btn_hero_lic = QPushButton("")
        self.btn_hero_lic.setObjectName("HomeChip")
        self.btn_hero_lic.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_hero_lic.clicked.connect(lambda: self.show_page("plans"))
        chips.addWidget(b_ver, 0, Qt.AlignmentFlag.AlignRight)
        chips.addWidget(self.btn_hero_lic, 0, Qt.AlignmentFlag.AlignRight)
        chips.addStretch(1)
        hl.addLayout(chips)
        col.addWidget(hero)

        # ---- 3 steps
        steps = QHBoxLayout()
        steps.setSpacing(10)
        for i, (n, title, text) in enumerate(STEPS):
            f = QFrame()
            f.setObjectName("HomeStep")
            h = QHBoxLayout(f)
            h.setContentsMargins(12, 10, 12, 10)
            h.setSpacing(10)
            num = _label(n, "HomeStepNum")
            num.setAlignment(Qt.AlignmentFlag.AlignCenter)
            num.setFixedSize(28, 28)
            t = QVBoxLayout()
            t.setSpacing(0)
            t.addWidget(_label(title, "HomeStepTitle"))
            t.addWidget(_label(text, "MutedLabel", wrap=True))
            h.addWidget(num)
            h.addLayout(t, 1)
            steps.addWidget(f, 1)
            if i < len(STEPS) - 1:
                steps.addWidget(_label("›", "HomeArrow"))
        col.addLayout(steps)

        # ---- the three workspaces
        cards = QHBoxLayout()
        cards.setSpacing(16)
        self.cards: Dict[str, WorkspaceCard] = {}
        for spec in SPACES:
            c = WorkspaceCard(*spec)
            c.chosen.connect(self._card_chosen)
            self.cards[spec[0]] = c
            cards.addWidget(c, 1)
        col.addLayout(cards)

        # ---- quick tools
        hd = QHBoxLayout()
        hd.addWidget(_label("Quick tools", "HomeH2"))
        hd.addWidget(_label("  one step, no project needed", "MutedLabel"))
        hd.addStretch(1)
        col.addLayout(hd)
        tg = QGridLayout()
        tg.setSpacing(10)
        self.tool_buttons: Dict[str, QPushButton] = {}
        for i, (key, text, _need) in enumerate(TOOLS):
            b = QPushButton()
            b.setObjectName("HomeTool")
            b.setMinimumHeight(50)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.quickRequested.emit(k))
            tg.addWidget(b, i // 3, i % 3)
            self.tool_buttons[key] = b
        for i in range(3):
            tg.setColumnStretch(i, 1)
        col.addLayout(tg)

        # ---- recent
        col.addWidget(_label("Recent projects", "HomeH2"))
        self.recent_grid = QGridLayout()
        self.recent_grid.setSpacing(14)
        col.addLayout(self.recent_grid)
        self.lb_no_recent = _label("Nothing yet – the projects you open or dub show up here.",
                                   "HomeEmpty", wrap=True)
        self.lb_no_recent.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lb_no_recent.setMinimumHeight(70)
        col.addWidget(self.lb_no_recent)
        col.addStretch(1)
        row.addLayout(col, 1)

        # ---- right column
        right = QVBoxLayout()
        right.setSpacing(16)

        lic = QFrame()
        lic.setObjectName("HomeBox")
        lb = QVBoxLayout(lic)
        lb.setContentsMargins(18, 16, 18, 16)
        lb.setSpacing(6)
        lh = QHBoxLayout()
        lh.addWidget(_label("🔑  Your licence", "HomeBoxTitle"), 1)
        self.lb_plan_badge = _label("", "HomeBadge")
        lh.addWidget(self.lb_plan_badge)
        lb.addLayout(lh)
        self.lb_lic_state = _label("", "HomeState")
        self.lb_lic_detail = _label("", "MutedLabel", wrap=True)
        lb.addWidget(self.lb_lic_state)
        lb.addWidget(self.lb_lic_detail)
        lk = QPushButton("Plan, prices && renew  →")
        lk.setObjectName("HomeLink")
        lk.clicked.connect(lambda: self.show_page("plans"))
        lb.addWidget(lk, 0, Qt.AlignmentFlag.AlignLeft)
        right.addWidget(lic)

        self.box_batch = QFrame()
        self.box_batch.setObjectName("HomeBox")
        bb = QVBoxLayout(self.box_batch)
        bb.setContentsMargins(18, 16, 18, 16)
        bb.setSpacing(6)
        bh = QHBoxLayout()
        bh.addWidget(_label("📚  Batch", "HomeBoxTitle"), 1)
        self.btn_batch_open = QPushButton("Open  →")
        self.btn_batch_open.setObjectName("HomeLink")
        self.btn_batch_open.clicked.connect(lambda: self.batchRequested.emit([]))
        bh.addWidget(self.btn_batch_open)
        bb.addLayout(bh)
        self.lb_batch_big = _label("", "HomeBig")
        self.bar_batch = QProgressBar()
        self.bar_batch.setObjectName("HomeBar")
        self.bar_batch.setTextVisible(False)
        self.bar_batch.setFixedHeight(8)
        self.lb_batch_text = _label("", "MutedLabel", wrap=True)
        bb.addWidget(self.lb_batch_big)
        bb.addWidget(self.bar_batch)
        bb.addWidget(self.lb_batch_text)
        right.addWidget(self.box_batch)

        self.box_up = QFrame()
        self.box_up.setObjectName("HomeUpsell")
        ub = QVBoxLayout(self.box_up)
        ub.setContentsMargins(18, 16, 18, 16)
        ub.addWidget(_label("Dub a whole series by itself", "HomeBoxTitle"))
        ub.addWidget(_label("Batch dubs 40 episodes overnight with the same voice for every "
                            "character. In the Studio plan.", "HomeText", wrap=True))
        up = QPushButton("See Studio plan")
        up.setObjectName("HomeAmber")
        up.setMinimumHeight(38)
        up.clicked.connect(lambda: self.show_page("plans"))
        ub.addWidget(up)
        right.addWidget(self.box_up)

        news = QFrame()
        news.setObjectName("HomeBox")
        nb = QVBoxLayout(news)
        nb.setContentsMargins(18, 16, 18, 16)
        nb.setSpacing(8)
        nh = QHBoxLayout()
        nh.addWidget(_label("✨  What's new", "HomeBoxTitle"), 1)
        nh.addWidget(_label(f"v{__version__}", "HomeVerChip"))
        nb.addLayout(nh)
        for t in changelog.notes(__version__)[:4]:
            nb.addWidget(_label("•  " + t, "HomeText", wrap=True))
        al = QPushButton("All versions  →")
        al.setObjectName("HomeLink")
        al.clicked.connect(self.show_changelog)
        nb.addWidget(al, 0, Qt.AlignmentFlag.AlignLeft)
        right.addWidget(news)
        right.addStretch(1)
        rw = QWidget()
        rw.setLayout(right)
        rw.setFixedWidth(320)
        row.addWidget(rw)
        sc.setWidget(inner)
        return sc

    # ------------------------------------------------------------------ #
    def _search(self, text: str):
        """🔍 Shows only the quick tools and recent projects that match."""
        q = (text or "").strip().lower()
        if q and self.pages.currentIndex() != 0:
            self.show_page("home")
        for b in self.tool_buttons.values():
            b.setVisible(not q or q in b.text().lower())
        for t in getattr(self, "_tiles", []):
            hay = " ".join(str(v) for v in t.entry.values()).lower() \
                if isinstance(getattr(t, "entry", None), dict) else ""
            t.setVisible(not q or q in hay)
        for k, c in self.cards.items():
            c.setVisible(not q or any(q in w.text().lower() for w in c.findChildren(QLabel)))

    def _search_go(self):
        """Enter: opens the only match (a tool or a project)."""
        tools = [b for b in self.tool_buttons.values() if b.isVisible()]
        tiles = [t for t in getattr(self, "_tiles", []) if t.isVisible()]
        if len(tools) + len(tiles) == 1:
            (tools or tiles)[0].click()

    def _toggle_language(self):
        """🌐 EN ⇄ ខ្មែរ (live)."""
        from core import i18n

        new = "km" if i18n.language() == "en" else "en"
        try:
            from ui import appearance

            appearance.set_language(new)
        except Exception:
            i18n.set_language(new)
        self.refresh()

    def notifications(self) -> List[str]:
        out = []
        kind, text, detail = licence_state()
        if kind in ("soon", "bad"):
            out.append(f"🔑 {text} – {detail}")
        status = self.batch_status() if self.batch_status else None
        if status:
            out.append(f"📚 Batch: {status[0]} of {status[1]} done")
        notes = changelog.notes(__version__)
        if notes:
            out.append(f"✨ Version {__version__}: {notes[0][:80]}…")
        return out

    def _notifications(self):
        from PySide6.QtWidgets import QMenu

        m = QMenu(self)
        for t in self.notifications() or ["Nothing new"]:
            act = m.addAction(t)
            if t.startswith("🔑"):
                act.triggered.connect(lambda: self.show_page("plans"))
            elif t.startswith("📚"):
                act.triggered.connect(lambda: self.batchRequested.emit([]))
            elif t.startswith("✨"):
                act.triggered.connect(self.show_changelog)
        m.exec(self.btn_bell.mapToGlobal(self.btn_bell.rect().bottomLeft()))

    def show_changelog(self):
        ChangelogDialog(self).exec()

    def show_page(self, page: str):
        self.pages.setCurrentIndex(1 if page == "plans" else 0)
        if page == "plans":
            self.plans_page.refresh()
        for k, b in self._navs.items():
            b.setChecked(k == page)

    def refresh(self):
        """Plan, licence, locks, batch box, recent projects."""
        plan = plans.current()
        name = plans.label()
        for lb in (self.lb_side_plan, self.lb_plan_badge):
            lb.setText(name.upper())
            lb.setProperty("plan", plan)
            lb.style().polish(lb)
        self.lb_hello.setText(f"👋  {greeting()}")
        kind, text, detail = licence_state()
        for lb in (self.lb_lic_state, self.lb_side_lic):
            lb.setText(text)
            _paint_state(lb, kind)
        self.lb_lic_detail.setText(detail)
        # top bar user + the sidebar licence box
        from core import license as lic

        info = lic.current()
        who = "Admin" if kind == "admin" else (info.name or "SARIKA user") if info.valid \
            else "Guest"
        from core import i18n

        self.btn_lang.setText("🌐 ខ្មែរ" if i18n.language() == "km" else "🌐 EN")
        self.lb_user.setText(who)
        self.lb_avatar.setText((who[:1] or "?").upper())
        self.lb_user_plan.setText({"admin": "Seller's PC", "ok": f"{info.days_left} days left",
                                   "soon": "Renew soon"}.get(kind, "No licence"))
        self.lb_side_title.setText({"admin": "Admin", "ok": "Licence active",
                                    "soon": "Renew soon"}.get(kind, "Get your licence"))
        self.lb_side_icon.setText("👑" if kind in ("admin", "ok") else "⏳" if kind == "soon"
                                  else "🔑")
        self.lb_side_btn.setText({"admin": "Plan & prices", "ok": "Renew",
                                  "soon": "Renew now"}.get(kind, "See plans"))
        n = len([t for t in self.notifications() if not t.startswith("✨")])
        self.btn_bell.setText(f"🔔 {n}" if n else "🔔")
        self.btn_hero_lic.setText(("● " if kind != "admin" else "👑 ") + text)
        self.btn_hero_lic.setStyleSheet(f"color: {STATE_COLOUR[kind]};")

        batch_ok = plans.allows("batch")
        self.cards["batch"].set_locked(not batch_ok, plans.needed("batch"))
        self.nav_batch.setText("📚   Batch a series" + ("" if batch_ok else
                                                     f"   🔒 {plans.needed('batch')}"))
        for key, text, need in TOOLS:
            ok = plans.allows(need)
            self.tool_buttons[key].setText(f"{TOOL_ICONS.get(key, '•')}   {text}"
                                           + ("" if ok else f"   🔒 {plans.needed(need)}"))
        self.box_batch.setVisible(batch_ok)
        self.box_up.setVisible(not batch_ok)
        status = self.batch_status() if self.batch_status else None
        if status:
            done, total, now = status
            self.lb_batch_big.setText(f"{done} of {total} done")
            self.bar_batch.setRange(0, max(1, total))
            self.bar_batch.setValue(done)
            self.bar_batch.setVisible(True)
            self.lb_batch_text.setText(now)
        else:
            self.lb_batch_big.setText("Nothing queued")
            self.bar_batch.setVisible(False)
            self.lb_batch_text.setText("Drop a folder of episodes on “Batch a series”.")
        self._fill_recent()
        if self.pages.currentIndex() == 1:
            self.plans_page.refresh()

    def _fill_recent(self):
        while self.recent_grid.count():
            it = self.recent_grid.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        entries = recent.items()[:8]
        self.lb_no_recent.setVisible(not entries)
        self._tiles: List[RecentTile] = []
        for i, e in enumerate(entries):
            t = RecentTile(e)
            t.clicked.connect(lambda _=False, e=e: self.recentRequested.emit(e))
            self.recent_grid.addWidget(t, i // 4, i % 4)
            self._tiles.append(t)
        for i in range(4):                         # 4 equal columns even with few projects
            self.recent_grid.setColumnStretch(i, 1)
        self._thumbs.make([e.get("video", "") for e in entries])

    def _reload_thumbs(self):
        for t in getattr(self, "_tiles", []):
            try:
                t.load_thumb()
            except RuntimeError:
                pass

    def _card_chosen(self, key: str, paths: list):
        if key == "recap":
            vids = []
            for p in paths:
                if os.path.isdir(p):
                    vids += sorted(os.path.join(p, n) for n in os.listdir(p)
                                   if _is_video(os.path.join(p, n)))
                elif _is_video(p):
                    vids.append(p)
            if vids:
                self.recapVideosRequested.emit(vids)
            else:
                self.recapRequested.emit()
            return
        if key == "batch":
            self.batchRequested.emit(paths)
            return
        video = next((p for p in paths if _is_video(p)), "")
        self.workspaceRequested.emit(key, video)

    def _plan_chosen(self, plan: str):
        if plan == "admin":
            plans.end_preview()
            plan = plans.current()
        else:
            plans.set_current(plan)
        self.refresh()
        self.plans_page.refresh()
        self.planChanged.emit(plan)
