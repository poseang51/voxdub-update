"""
folder_edit_dialog.py - 📂 Edit a whole folder (core/folder_edit.py).

    The edit of the video in the editor:  speed 128% · logo · text “…” · size 1080x1350
    ┌ Episodes ───────────────────────────┐
    │ ✓ [CH-204] 01.mp4   done            │
    │ ⟳ [CH-204] 02.mp4   42%             │
    │   [CH-204] 03.mp4                   │
    └─────────────────────────────────────┘
    [✓] Find and hide the original subtitles in every episode
    After  (•) Keep every episode whole
           ( ) Cut every episode into parts       Every [10 min]
           ( ) Join all episodes, then cut        Part name [រឿង… ភាគ{n}]
    Save in [ D:\\…\\output\\<folder> ]
    [▶ Start 40 episodes]  ■ Stop          📂 Open folder
"""

import os
import shutil
import time
from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QProgressBar, QPushButton, QRadioButton, QSpinBox, QVBoxLayout,
)

from core import folder_edit, joiner, settings
from core.batch import natural_key
from core.export import ExportOptions
from core.media import VIDEO_EXT, VIDEO_FILTER, format_time
from ui.workers import TaskWorker

ROLE = Qt.ItemDataRole.UserRole


HOW = ("<b>Where to set it in Edit:</b> 🖼 Logo, brand text, subtitles → <b>Style</b> tab · "
       "⏩ Speed, fades → <b>Tools › Video</b> · 🎨 Colour → <b>Tools › Color Adjustments</b> · "
       "✂ Crop → <b>Tools › Crop and Rotate</b> · 📐 Size 9:16 / 4:5 → <b>Project settings ✎</b> "
       "(bottom right). Then click <b>📂 Apply to the folder</b> at the top.")


class FolderEditDialog(QDialog):
    setupRequested = Signal(dict)       # {"videos", "out_dir"}: open episode 1 in Edit

    def __init__(self, window, project, output_root: str):
        super().__init__(window)
        self.win = window
        self.base = folder_edit.template_of(project)
        self.output_root = output_root
        self.worker: Optional[TaskWorker] = None
        self.results: List[str] = []
        self.out_dir_used = ""
        self.setWindowTitle("SARIKA VOXDUB PRO – Edit a whole folder")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(860, 760)
        self.setStyleSheet(
            "QRadioButton { padding: 3px 0; }"
            "QRadioButton::indicator { width: 14px; height: 14px; border-radius: 8px; "
            "border: 2px solid #5d6876; background: #10141a; }"
            "QRadioButton::indicator:checked { border: 2px solid #22c3a6; "
            "background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, "
            "stop:0 #22c3a6, stop:0.55 #22c3a6, stop:0.6 #10141a); }"
            "QRadioButton:checked { color: #ffffff; font-weight: 600; }")
        self.setAcceptDrops(True)
        self._build(project)
        self._changed()

    # ------------------------------------------------------------------ #
    def _build(self, project):
        head = QLabel("📂  Edit a whole folder")
        head.setObjectName("HomeH2")
        what = folder_edit.summary(self.base)
        src = os.path.basename(project.video_path or "") or "the editor"
        box = QFrame()
        box.setObjectName("HomeBox")
        bl = QVBoxLayout(box)
        bl.setContentsMargins(14, 10, 14, 10)
        self.lb_template = QLabel(
            f"<b>The edit of “{src}”</b> is used for every episode (no dubbing):<br>"
            + ("  ·  ".join(what) if what else
               "<span style='color:#F5B942'>nothing is changed yet – click ✏️ below and set up "
               "episode 1 in Edit (logo, speed, colour, size …).</span>"))
        self.lb_template.setWordWrap(True)
        self.lb_template.setTextFormat(Qt.TextFormat.RichText)
        bl.addWidget(self.lb_template)
        self.lb_how = QLabel(HOW)
        self.lb_how.setObjectName("MutedLabel")
        self.lb_how.setWordWrap(True)
        self.lb_how.setTextFormat(Qt.TextFormat.RichText)
        bl.addWidget(self.lb_how)
        self.btn_setup = QPushButton("✏️  Set up the edit on episode 1 (opens it in Edit)")
        self.btn_setup.setObjectName("HomeGhost")
        self.btn_setup.setMinimumHeight(34)
        self.btn_setup.setToolTip("Opens the first episode in Edit. Set the logo, speed, colour "
                                  "…, then click “📂 Apply to the folder” at the top - this "
                                  "list comes back.")
        self.btn_setup.clicked.connect(self._setup)
        bl.addWidget(self.btn_setup, 0, Qt.AlignmentFlag.AlignLeft)
        self.empty = not what

        # ---- episodes
        self.lst = QListWidget()
        self.lst.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        b_dir = QPushButton("📁 Folder…")
        b_dir.clicked.connect(self._browse_folder)
        b_add = QPushButton("＋ Videos…")
        b_add.clicked.connect(self._browse)
        b_rm = QPushButton("− Remove")
        b_rm.clicked.connect(self._remove)
        self.lb_count = QLabel("")
        self.lb_count.setObjectName("MutedLabel")
        lrow = QHBoxLayout()
        for b in (b_dir, b_add, b_rm):
            lrow.addWidget(b)
        lrow.addStretch(1)
        lrow.addWidget(self.lb_count)

        # ---- options
        self.chk_cover = QCheckBox("Find and hide the original subtitles in every episode "
                                   "(reads the Chinese text)")
        self.chk_cover.setChecked(bool(settings.get("folder_edit_cover", True)))
        self.chk_same = QCheckBox("Same format for every episode (joining takes seconds)")
        self.chk_same.setChecked(True)
        self.after = QButtonGroup(self)
        g = QGridLayout()
        g.setHorizontalSpacing(14)
        g.addWidget(QLabel("<b>After</b>"), 0, 0, Qt.AlignmentFlag.AlignTop)
        keep = settings.get("folder_edit_after", "join") or "join"
        for i, (k, name) in enumerate(folder_edit.AFTER.items()):
            rb = QRadioButton(name)
            rb.setProperty("key", k)
            rb.setChecked(k == keep)
            self.after.addButton(rb, i)
            g.addWidget(rb, i, 1)
        self.after.buttonToggled.connect(lambda *_: self._changed())
        self.spn_min = QSpinBox()
        self.spn_min.setRange(1, 600)
        self.spn_min.setSuffix(" min")
        self.spn_min.setValue(int(settings.get("folder_edit_minutes", 10) or 10))
        self.spn_min.valueChanged.connect(lambda *_: self._changed())
        self.ed_name = QLineEdit(settings.get("folder_edit_name", "") or "")
        self.ed_name.setPlaceholderText("Part name, e.g. រឿងអធិរាជខាងស៊ី ភាគ{n}")
        self.ed_name.setToolTip("{n} = the part number. Empty: the episode's name + _part01 …\n"
                                "Join all: the numbers run on through the whole story.")
        self.spn_start = QSpinBox()
        self.spn_start.setRange(0, 9999)
        self.spn_start.setValue(1)
        self.spn_start.setPrefix("from ")
        mrow = QHBoxLayout()
        mrow.addWidget(QLabel("Every"))
        mrow.addWidget(self.spn_min)
        for m in (5, 10, 15, 20, 30):
            qb = QPushButton(str(m))
            qb.setFixedWidth(44)
            qb.clicked.connect(lambda _=False, m=m: self.spn_min.setValue(m))
            mrow.addWidget(qb)
        mrow.addStretch(1)
        nrow = QHBoxLayout()
        nrow.addWidget(self.ed_name, 1)
        nrow.addWidget(self.spn_start)
        g.addLayout(mrow, 3, 1)
        g.addLayout(nrow, 4, 1)
        self.lb_plan = QLabel("")
        self.lb_plan.setObjectName("MutedLabel")
        self.lb_plan.setWordWrap(True)
        g.addWidget(self.lb_plan, 5, 1)
        self.chk_keep = QCheckBox("Keep the whole episodes too (in a “whole episodes” folder)")
        self.chk_keep.setChecked(bool(settings.get("folder_edit_keep_whole", False)))
        g.addWidget(self.chk_keep, 6, 1)
        self.part_widgets = [self.spn_min, self.ed_name, self.spn_start]

        self.ed_out = QLineEdit("")
        self.ed_out.setPlaceholderText("output\\<folder name>")
        b_out = QPushButton("…")
        b_out.clicked.connect(self._choose_out)
        self.cmb_quality = QComboBox()
        self.cmb_quality.addItem("High (bigger file)", 18)
        self.cmb_quality.addItem("Normal", 20)
        self.cmb_quality.addItem("Small file", 24)
        self.cmb_quality.setCurrentIndex(1)
        orow = QHBoxLayout()
        orow.addWidget(QLabel("<b>Save in</b>"))
        orow.addWidget(self.ed_out, 1)
        orow.addWidget(b_out)
        orow.addWidget(QLabel("Quality"))
        orow.addWidget(self.cmb_quality)

        # ---- run
        self.bar = QProgressBar()
        self.bar.setVisible(False)
        self.lb_status = QLabel("")
        self.lb_status.setObjectName("MutedLabel")
        self.lb_status.setWordWrap(True)
        self.btn_go = QPushButton("▶  Start")
        self.btn_go.setObjectName("HomeCta")
        self.btn_go.setMinimumHeight(40)
        self.btn_go.clicked.connect(self._start)
        self.btn_stop = QPushButton("■ Stop")
        self.btn_stop.setObjectName("DangerButton")
        self.btn_stop.setVisible(False)
        self.btn_stop.clicked.connect(lambda: self.worker and self.worker.stop())
        self.btn_folder = QPushButton("📂 Open folder")
        self.btn_folder.setVisible(False)
        self.btn_folder.clicked.connect(self._open_folder)
        brow = QHBoxLayout()
        brow.addWidget(self.btn_go)
        brow.addWidget(self.btn_stop)
        brow.addWidget(self.bar, 1)
        brow.addWidget(self.btn_folder)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.addWidget(head)
        lay.addWidget(box)
        lay.addWidget(QLabel("Episodes (drop a folder or videos here – in episode order)"))
        lay.addWidget(self.lst, 1)
        lay.addLayout(lrow)
        lay.addWidget(self.chk_cover)
        lay.addWidget(self.chk_same)
        lay.addLayout(g)
        lay.addLayout(orow)
        lay.addLayout(brow)
        lay.addWidget(self.lb_status)

    # ------------------------------------------------------------------ #
    def after_key(self) -> str:
        b = self.after.checkedButton()
        return b.property("key") if b else "each"

    def videos(self) -> List[str]:
        return [self.lst.item(i).data(ROLE) for i in range(self.lst.count())]

    def add_videos(self, paths: List[str]):
        have = set(self.videos())
        found: List[str] = []
        for p in paths:
            if os.path.isdir(p):
                found += folder_edit.find_videos(p)
                if not self.ed_out.text().strip():
                    self.ed_out.setText(os.path.join(self.output_root,
                                                     os.path.basename(p.rstrip("\\/"))))
            elif p.lower().endswith(VIDEO_EXT) and os.path.isfile(p):
                found.append(p)
        for p in sorted(found, key=natural_key):
            if p in have:
                continue
            have.add(p)
            it = QListWidgetItem(os.path.basename(p))
            it.setData(ROLE, p)
            it.setToolTip(p)
            self.lst.addItem(it)
        self._changed()

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of episodes")
        if d:
            self.add_videos([d])

    def _browse(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Episodes", "", VIDEO_FILTER)
        self.add_videos(files)

    def _remove(self):
        for it in self.lst.selectedItems():
            self.lst.takeItem(self.lst.row(it))
        self._changed()

    def _choose_out(self):
        d = QFileDialog.getExistingDirectory(self, "Save the videos in")
        if d:
            self.ed_out.setText(d)

    def dragEnterEvent(self, ev):
        if ev.mimeData().hasUrls():
            ev.acceptProposedAction()

    def dropEvent(self, ev):
        self.add_videos([os.path.normpath(u.toLocalFile()) for u in ev.mimeData().urls() if u.isLocalFile()])

    def _changed(self):
        n = self.lst.count()
        k = self.after_key()
        for w in self.part_widgets:
            w.setEnabled(k != "each")
        self.spn_start.setEnabled(k == "join")
        self.chk_keep.setVisible(k == "join")
        self.lb_count.setText(f"{n} episode" + ("s" if n != 1 else ""))
        self.btn_go.setText(f"▶  Start {n} episode" + ("s" if n != 1 else ""))
        self.btn_go.setEnabled(n > 0 and self.worker is None)
        self.btn_setup.setEnabled(n > 0 and self.worker is None)
        sp = float(self.base.get("video_speed", 1.0) or 1.0)
        m = self.spn_min.value()
        if k == "each":
            self.lb_plan.setText("Every episode becomes one video with the edit.")
        elif k == "cut":
            self.lb_plan.setText(f"Every episode is cut into {m}-minute parts (in a “parts” "
                                 "folder, named after the episode or the Part name).")
        else:
            self.lb_plan.setText(f"Step 1: every episode gets the edit. Step 2 (after the last "
                                 f"episode): all {n} are joined in order and cut into {m}-minute "
                                 "parts – the parts appear in the Save in folder at the end; "
                                 "their numbers run on through the whole story."
                                 + (f" Speed {round(sp * 100)}% makes the story shorter."
                                    if abs(sp - 1) > 0.001 else ""))

    # ------------------------------------------------------------------ #
    def _setup(self):
        videos = self.videos()
        if not videos:
            QMessageBox.information(self, "Edit a whole folder",
                                    "Add the folder of episodes first (📁 Folder…).")
            return
        self.setupRequested.emit({"videos": videos, "out_dir": self.ed_out.text().strip()})
        self.close()

    def _start(self):
        videos = self.videos()
        if not videos:
            return
        if self.empty and QMessageBox.question(
                self, "Edit a whole folder",
                "Nothing is changed yet (no logo, speed, colour …) – the episodes would only "
                "be copied.\n\nSet up the edit on episode 1 first?") == \
                QMessageBox.StandardButton.Yes:
            self._setup()
            return
        out_dir = self.ed_out.text().strip() or os.path.join(self.output_root, "Folder edit")
        self.ed_out.setText(out_dir)
        k, minutes = self.after_key(), self.spn_min.value()
        name, start = self.ed_name.text().strip(), self.spn_start.value()
        auto_cover, uniform = self.chk_cover.isChecked(), self.chk_same.isChecked() or k == "join"
        settings.set("folder_edit_cover", auto_cover)
        settings.set("folder_edit_after", k)
        settings.set("folder_edit_minutes", minutes)
        settings.set("folder_edit_name", name)
        opts = ExportOptions(output_path="", resolution="original",
                             crf=int(self.cmb_quality.currentData()), burn_subtitles=False,
                             export_srt=False)
        try:
            from core import license as lic

            opts.watermark = lic.watermark_text()
        except Exception:
            pass
        base = dict(self.base)
        eps_dir = os.path.join(out_dir, "whole episodes")
        keep_whole = self.chk_keep.isChecked()
        settings.set("folder_edit_keep_whole", keep_whole)
        rows = list(range(len(videos)))
        self.out_dir_used = out_dir

        def job(progress, should_stop):
            done, hint = [], None
            share = 85 if k == "join" else 100
            total = len(videos)
            for i, v in zip(rows, videos):
                if should_stop():
                    raise InterruptedError("Cancelled")
                ep = os.path.basename(v)

                def prog(p, msg, i=i, ep=ep):
                    if k == "join":
                        msg = (f"Step 1 of 2 · episode {i + 1}/{total}  {ep}: {msg}   "
                               f"(the {minutes}-min parts are made after the last episode)")
                    else:
                        msg = f"{i + 1}/{total}  {ep}: {msg}"
                    progress((share * i + share * p // 100) // total, msg)
                    self._row_state(i, f"{p}%")
                # join: the whole episodes are only a step - kept apart from the parts
                out = folder_edit.output_for(v, eps_dir if k == "join" else out_dir)
                r = folder_edit.edit_one(v, base, out, opts, auto_cover, hint, uniform,
                                         prog, should_stop)
                hint = r["cover"] or hint
                if k == "cut":
                    stem = os.path.splitext(os.path.basename(out))[0]
                    parts = folder_edit.cut(out, minutes, os.path.join(out_dir, "parts", stem),
                                            name or "", should_stop=should_stop)
                    done += parts or [out]
                    if parts:
                        os.remove(out)
                else:
                    done.append(out)
                self._row_state(i, "✓ done")
            if k != "join":
                return done
            progress(86, "Step 2 of 2 · joining the episodes…")
            story = os.path.join(eps_dir, "story_joined.mp4")
            joiner.merge_videos(done, story, "auto",
                                lambda p, m: progress(86 + p * 7 // 100,
                                                      "Step 2 of 2 · joining… " + m),
                                should_stop)
            parts = folder_edit.cut(story, minutes, out_dir, name or "part{n}", start=start,
                                    progress=lambda p, m: progress(
                                        93 + p * 7 // 100,
                                        f"Step 2 of 2 · cutting into {minutes}-min parts… " + m),
                                    should_stop=should_stop)
            if not parts:                       # shorter than one part: the joined video
                final = os.path.join(out_dir, os.path.basename(story))
                shutil.move(story, final)
                parts = [final]
            if not keep_whole:                  # only the parts stay
                shutil.rmtree(eps_dir, ignore_errors=True)
            return parts

        for i in range(self.lst.count()):
            self.lst.item(i).setText(os.path.basename(videos[i]))
        self._t0 = time.time()
        self.worker = TaskWorker(job, "Edit a whole folder", self)
        self.worker.progress.connect(self._progress)
        self.worker.done.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.bar.setValue(0)
        self.bar.setVisible(True)
        self.btn_stop.setVisible(True)
        self.btn_folder.setVisible(False)
        self.worker.start()
        self._changed()

    def _row_state(self, row: int, text: str):
        """(called from the worker thread: only the text is stored, the list
        shows it on the next progress signal)"""
        self._pending = (row, text)

    def _progress(self, pct: int, msg: str):
        self.bar.setValue(pct)
        el = time.time() - self._t0
        if pct > 3 and el > 20:
            msg += f"   ·   ~{format_time(el * (100 - pct) / pct, False)} left"
        self.lb_status.setText(msg)
        row, text = getattr(self, "_pending", (-1, ""))
        if 0 <= row < self.lst.count():
            it = self.lst.item(row)
            it.setText(f"{os.path.basename(it.data(ROLE))}    {text}")

    def _finish(self):
        self.worker = None
        self.btn_stop.setVisible(False)
        self._changed()

    def _done(self, outs: list):
        row, text = getattr(self, "_pending", (-1, ""))
        if 0 <= row < self.lst.count():
            it = self.lst.item(row)
            it.setText(f"{os.path.basename(it.data(ROLE))}    {text}")
        self._finish()
        self.results = list(outs or [])
        self.bar.setValue(100)
        took = format_time(time.time() - self._t0, False)
        self.lb_status.setText(f"✓ Finished in {took}: {len(self.results)} video(s) in "
                               f"{self.out_dir_used}")
        self.btn_folder.setVisible(True)

    def _failed(self, msg: str):
        self._finish()
        self.lb_status.setText("Stopped." if "Cancelled" in msg else "❌ " + msg)
        if "Cancelled" not in msg:
            QMessageBox.warning(self, "Edit a whole folder", msg)

    def _open_folder(self):
        from ui.main_window import open_path

        target = os.path.dirname(self.results[0]) if self.results else self.out_dir_used
        open_path(target)

    def closeEvent(self, ev):
        if self.worker is not None:
            if QMessageBox.question(self, "Edit a whole folder",
                                    "It is still running. Stop it?") != \
                    QMessageBox.StandardButton.Yes:
                ev.ignore()
                return
            self.worker.stop()
            self.worker.wait(10000)
        super().closeEvent(ev)
