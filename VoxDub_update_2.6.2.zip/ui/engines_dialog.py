"""
engines_dialog.py - Settings › AI engines & API keys.

  * Gemini (Google AI Studio API keys): several keys (each shown only as
    ••••last4, never in full), model, Test, List models.
  * Voice clone (VoxCPM2): the Python of the VoxCPM environment, male /
    female reference recordings + what is said in them, quality, Test.

Everything is saved on this computer only (settings.json), never in a project.
"""

from PySide6.QtCore import Qt, QThread, QUrl, Signal
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QTabWidget, QVBoxLayout, QWidget,
)

from core import gemini, settings, voxcpm

_ALIVE = []         # tests still running when the dialog was closed


class _Job(QThread):
    finished_with = Signal(object)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn

    def run(self):
        try:
            self.finished_with.emit(("ok", self.fn()))
        except Exception as e:          # shown, never a crash
            self.finished_with.emit(("err", str(e)))


def _note(text: str) -> QLabel:
    lb = QLabel(text)
    lb.setWordWrap(True)
    lb.setObjectName("MutedLabel")
    lb.setTextFormat(Qt.TextFormat.RichText)
    lb.setOpenExternalLinks(True)
    return lb


class EnginesDialog(QDialog):
    def __init__(self, parent=None, tab: str = "gemini"):
        super().__init__(parent)
        self.setWindowTitle("AI engines & API keys")
        self.setMinimumSize(620, 520)
        self._jobs = []
        self.tabs = QTabWidget()
        self.tabs.addTab(self._gemini_tab(), "✨ Gemini (Google API key)")
        self.tabs.addTab(self._voxcpm_tab(), "🎙 Voice clone (VoxCPM2)")
        self.tabs.setCurrentIndex(1 if tab == "voxcpm" else 0)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row = QHBoxLayout()
        row.addWidget(_note("Saved only on this computer – never inside a project file."), 1)
        row.addWidget(close)
        lay = QVBoxLayout(self)
        lay.addWidget(self.tabs, 1)
        lay.addLayout(row)
        self.player = QMediaPlayer(self)
        self.player.setAudioOutput(QAudioOutput(self))

    # ------------------------------------------------------------------ #
    # Gemini
    # ------------------------------------------------------------------ #
    def _gemini_tab(self) -> QWidget:
        w = QWidget()
        self.key_list = QListWidget()
        self.key_list.setMaximumHeight(130)
        self.ed_key = QLineEdit()
        self.ed_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.ed_key.setPlaceholderText("paste a key from aistudio.google.com (AIza…)")
        b_add = QPushButton("＋ Add key")
        b_add.clicked.connect(self._add_key)
        b_del = QPushButton("－ Remove")
        b_del.clicked.connect(self._del_key)
        add_row = QHBoxLayout()
        add_row.addWidget(self.ed_key, 1)
        add_row.addWidget(b_add)
        add_row.addWidget(b_del)
        self.cmb_model = QComboBox()
        self.cmb_model.setEditable(True)
        for m in gemini.SUGGESTED_MODELS:
            self.cmb_model.addItem(m)
        self.cmb_model.setCurrentText(gemini.model())
        self.cmb_model.currentTextChanged.connect(
            lambda t: settings.set("gemini_model", t.strip()))
        b_list = QPushButton("List models")
        b_list.setToolTip("Ask Google which models your key can use")
        b_list.clicked.connect(self._list_models)
        model_row = QHBoxLayout()
        model_row.addWidget(self.cmb_model, 1)
        model_row.addWidget(b_list)
        self.b_test = QPushButton("Test keys")
        self.b_test.setObjectName("AccentButton")
        self.b_test.clicked.connect(self._test_keys)
        self.g_status = QLabel("")
        self.g_status.setWordWrap(True)
        form = QFormLayout()
        form.addRow("API keys", self.key_list)
        form.addRow("", add_row)
        form.addRow("Model", model_row)
        lay = QVBoxLayout(w)
        lay.addWidget(_note(
            "<b>Gemini</b> translates with the whole story in mind (names, who speaks to whom, "
            "natural spoken Khmer) and can also turn speech into text instead of Whisper.<br>"
            "1. Open <a href='https://aistudio.google.com/apikey'>aistudio.google.com/apikey</a>"
            " → <b>Create API key</b> → copy it.<br>"
            "2. Paste it here → <b>＋ Add key</b>. Several keys (one per Google account) = "
            "more free quota; they are used in turn.<br>"
            "3. Choose <b>Translate: Gemini</b> and/or <b>Speech engine: Gemini</b> on the left."))
        lay.addLayout(form)
        lay.addWidget(self.b_test, 0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(self.g_status)
        lay.addStretch(1)
        self._fill_keys()
        return w

    def _fill_keys(self):
        self.key_list.clear()
        for k in gemini.keys():
            it = QListWidgetItem(f"🔑  {settings.mask(k)}")
            it.setData(Qt.ItemDataRole.UserRole, k)
            self.key_list.addItem(it)
        if not gemini.keys():
            self.key_list.addItem("(no key yet)")

    def _add_key(self):
        k = self.ed_key.text().strip()
        if not k:
            self.g_status.setText("Paste a key first.")
            return
        gemini.set_keys(gemini.keys() + [k])
        self.ed_key.clear()
        self._fill_keys()
        self.g_status.setText("Key saved. Click “Test keys” to check it.")

    def _del_key(self):
        it = self.key_list.currentItem()
        k = it.data(Qt.ItemDataRole.UserRole) if it else None
        if not k:
            return
        gemini.set_keys([x for x in gemini.keys() if x != k])
        self._fill_keys()
        self.g_status.setText("Key removed from this computer.")

    def _run(self, fn, done):
        job = _Job(fn, self)
        job.finished_with.connect(done)
        self._jobs.append(job)
        job.start()

    def _test_keys(self):
        ks = gemini.keys()
        if not ks:
            self.g_status.setText("Add a key first.")
            return
        m = self.cmb_model.currentText().strip()
        self.g_status.setText(f"Testing {len(ks)} key(s) with {m}…")
        self.b_test.setEnabled(False)

        def work():
            return [(settings.mask(k), gemini.test_key(k, m)) for k in ks]

        def done(res):
            self.b_test.setEnabled(True)
            kind, val = res
            if kind == "err":
                self.g_status.setText(f"❌ {val}")
                return
            self.g_status.setText("\n".join(f"{'✅' if not err else '❌'} {mk}"
                                            + (f" – {err[:160]}" if err else " works")
                                            for mk, err in val))
        self._run(work, done)

    def _list_models(self):
        ks = gemini.keys()
        if not ks:
            self.g_status.setText("Add a key first.")
            return
        self.g_status.setText("Asking Google for the models…")

        def done(res):
            kind, val = res
            if kind == "err":
                self.g_status.setText(f"❌ {val}")
                return
            cur = self.cmb_model.currentText()
            self.cmb_model.blockSignals(True)
            self.cmb_model.clear()
            self.cmb_model.addItems(val or gemini.SUGGESTED_MODELS)
            self.cmb_model.setCurrentText(cur)
            self.cmb_model.blockSignals(False)
            self.g_status.setText(f"{len(val)} models available for your key.")
        self._run(lambda: gemini.list_models(ks[0]), done)

    # ------------------------------------------------------------------ #
    # VoxCPM
    # ------------------------------------------------------------------ #
    def _voxcpm_tab(self) -> QWidget:
        w = QWidget()
        self.ed_py = QLineEdit(settings.get("voxcpm_python", "") or "")
        self.ed_py.setPlaceholderText("empty = look in the usual places (venv-voxcpm …)")
        b_py = QPushButton("…")
        b_py.setFixedWidth(36)
        b_py.clicked.connect(self._pick_python)
        b_find = QPushButton("🔍 Find")
        b_find.setToolTip("Look for a Python that has VoxCPM (venv-voxcpm next to "
                          "this app, or an older install)")
        b_find.clicked.connect(self._find_python)
        py_row = QHBoxLayout()
        py_row.addWidget(self.ed_py, 1)
        py_row.addWidget(b_py)
        py_row.addWidget(b_find)
        self.ed_py.editingFinished.connect(
            lambda: settings.set("voxcpm_python", self.ed_py.text().strip().strip('"')))
        self.refs = {}
        rows = []
        for g, label in (("male", "Male voice"), ("female", "Female voice"),
                         ("child", "Child (optional)"), ("elder_male", "Elder man (optional)"),
                         ("elder_female", "Elder woman (optional)")):
            ed = QLineEdit(settings.get(f"voxcpm_ref_{g}", "") or "")
            ed.setPlaceholderText("a clean 5–15 s recording (wav / mp3 / m4a)" if g in
                                  ("male", "female") else "empty = the male / female voice")
            ed.editingFinished.connect(lambda g=g, ed=ed: settings.set(f"voxcpm_ref_{g}",
                                                                    ed.text().strip()))
            b = QPushButton("…")
            b.setFixedWidth(36)
            b.clicked.connect(lambda _=False, g=g, ed=ed: self._pick_ref(g, ed))
            txt = QLineEdit(settings.get(f"voxcpm_ref_{g}_text", "") or "")
            txt.setPlaceholderText("what is said in the recording (makes the clone better)")
            txt.editingFinished.connect(lambda g=g, t=txt: settings.set(
                f"voxcpm_ref_{g}_text", t.text().strip()))
            r = QHBoxLayout()
            r.addWidget(ed, 1)
            r.addWidget(b)
            extra = g not in ("male", "female")
            self.refs[g] = (ed, None if extra else txt)
            rows.append((label, r, None if extra else txt))
        self.cmb_steps = QComboBox()
        for n, name in voxcpm.STEPS.items():
            self.cmb_steps.addItem(f"{name} ({n} steps)", n)
        self.cmb_steps.setCurrentIndex(max(0, self.cmb_steps.findData(
            int(settings.get("voxcpm_steps", 10) or 10))))
        self.cmb_steps.currentIndexChanged.connect(
            lambda *_: settings.set("voxcpm_steps", self.cmb_steps.currentData()))
        self.b_vtest = QPushButton("▶ Test VoxCPM")
        self.b_vtest.setObjectName("AccentButton")
        self.b_vtest.clicked.connect(self._test_voxcpm)
        # 2.4: ready voices as cards (VoxDub's own + SARIKA VOICE on the owner's PC)
        self.b_library = QPushButton("📚  Voice Library…")
        self.b_library.setObjectName("AccentButton")
        self.b_library.setToolTip("Choose the man / woman / child / elder voices from the "
                                  "library – ▶ preview, + add your own recordings")
        self.b_library.clicked.connect(self.open_library)
        self.v_status = QLabel("")
        self.v_status.setWordWrap(True)
        form = QFormLayout()
        form.addRow("VoxCPM Python", py_row)
        form.addRow("", self.b_library)
        for label, r, txt in rows:
            form.addRow(label, r)
            if txt is not None:
                form.addRow("   said:", txt)
        form.addRow("Quality", self.cmb_steps)
        self.chk_steady = QCheckBox("Steady voice – make a line again when it sounds like "
                                    "another person (a little slower)")
        self.chk_steady.setChecked(bool(settings.get("voxcpm_steady", True)))
        self.chk_steady.toggled.connect(lambda on: settings.set("voxcpm_steady", on))
        form.addRow("", self.chk_steady)
        lay = QVBoxLayout(w)
        lay.addWidget(_note(
            "<b>VoxCPM2</b> (openbmb, free) speaks Khmer and copies a voice from a short "
            "recording. It runs on your NVIDIA card in its <b>own</b> Python 3.10–3.12 "
            "environment (it cannot run in the app's Python 3.14):<br>"
            "run <b>setup_voxcpm.bat</b> in the app folder once – it makes "
            "<code>venv-voxcpm</code> next to the app, found automatically.<br>"
            "Each <b>character</b> gets its own voice (👥 Characters tab): by default the "
            "actor's voice cut from the video; the recordings below are the default voices.<br>"
            "Then choose <b>Engine: VoxCPM2</b> under AI Voice. It is slower than Edge "
            "(seconds per line) – tip: Edge for the whole video, VoxCPM for chosen lines."))
        lay.addLayout(form)
        lay.addWidget(self.b_vtest, 0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(self.v_status)
        lay.addStretch(1)
        return w

    def _pick_python(self):
        path, _ = QFileDialog.getOpenFileName(self, "python.exe of the VoxCPM environment", "",
                                              "Python (python.exe python*)")
        if path:
            self.ed_py.setText(path)
            settings.set("voxcpm_python", path)

    def _find_python(self):
        self.v_status.setText("Looking for a Python with VoxCPM (each one is checked – "
                              "this can take a little while)…")

        def done(res):
            kind, val = res
            if kind == "err" or not val:
                self.v_status.setText("❌ No VoxCPM environment found. Create one (see above) "
                                      "or pick its python.exe with “…”.")
                return
            self.ed_py.setText(val[0])
            settings.set("voxcpm_python", val[0])
            self.v_status.setText(f"✅ Found: {val[0]}" + (f"  (+{len(val) - 1} more)"
                                                          if len(val) > 1 else ""))
        self._run(voxcpm.find_pythons, done)

    def open_library(self):
        from ui.voice_library import VoiceLibraryDialog

        dlg = VoiceLibraryDialog(self, mode="settings")
        dlg.defaultChanged.connect(self._refs_changed)
        dlg.exec()

    def _refs_changed(self, slot: str):
        ed, txt = self.refs.get(slot, (None, None))
        if ed is not None:
            ed.setText(settings.get(f"voxcpm_ref_{slot}", "") or "")
        if txt is not None:
            txt.setText(settings.get(f"voxcpm_ref_{slot}_text", "") or "")

    def _pick_ref(self, g: str, ed: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(
            self, f"{g.title()} reference voice", "",
            "Audio (*.wav *.mp3 *.m4a *.flac *.ogg *.aac)")
        if path:
            ed.setText(path)
            settings.set(f"voxcpm_ref_{g}", path)

    def _test_voxcpm(self):
        settings.set("voxcpm_python", self.ed_py.text().strip().strip('"'))
        for g, (ed, txt) in self.refs.items():
            settings.set(f"voxcpm_ref_{g}", ed.text().strip())
            if txt is not None:
                settings.set(f"voxcpm_ref_{g}_text", txt.text().strip())
        self.v_status.setText("Starting VoxCPM (the first time loads the model – can take "
                              "a minute)…")
        self.b_vtest.setEnabled(False)

        def done(res):
            self.b_vtest.setEnabled(True)
            kind, val = res
            if kind == "err":
                self.v_status.setText(f"❌ {val}")
                return
            i = voxcpm.info()
            self.v_status.setText(f"✅ {i.get('model', 'VoxCPM')} on {i.get('device', '?')} – "
                                  f"playing the sample")
            self.player.setSource(QUrl.fromLocalFile(val))
            self.player.play()
        self._run(voxcpm.test, done)

    def done(self, r):
        self.player.stop()
        for j in self._jobs:
            if j.isRunning():           # let it finish quietly in the background
                try:
                    j.finished_with.disconnect()
                except (RuntimeError, TypeError):
                    pass
                j.setParent(None)
                _ALIVE.append(j)
                j.finished.connect(lambda j=j: _ALIVE.remove(j) if j in _ALIVE else None)
        super().done(r)


def open_engines(parent, tab: str = "gemini"):
    dlg = EnginesDialog(parent, tab)
    dlg.exec()
    return dlg

