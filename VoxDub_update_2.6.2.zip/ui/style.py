"""style.py - Dark theme (Filmora / CapCut inspired) as a Qt style sheet."""

ACCENT = "#22c3a6"
ACCENT_2 = "#7c5cff"

DARK_QSS = f"""
* {{
    font-size: 10pt;
    color: #e6edf3;
}}
QMainWindow, QWidget {{ background-color: #0f1216; }}
QWidget#SidePanel {{ background-color: #14181d; }}
QLabel, QCheckBox {{ background: transparent; }}
QMenuBar {{ background-color: #0b0d10; border-bottom: 1px solid #222831; }}
QMenuBar::item {{ padding: 6px 12px; background: transparent; }}
QMenuBar::item:selected {{ background: #1f2630; border-radius: 6px; }}
QMenu {{ background-color: #181d24; border: 1px solid #2a313b; border-radius: 8px; padding: 4px; }}
QMenu::item {{ padding: 6px 22px; border-radius: 6px; }}
QMenu::item:selected {{ background-color: {ACCENT}; color: #04110e; }}
QMenu::separator {{ height: 1px; background: #2a313b; margin: 4px 8px; }}

QWidget#TopBar {{ background-color: #0b0d10; border-bottom: 1px solid #222831; }}
QLabel#AppTitle {{ font-size: 15pt; font-weight: 700; color: #ffffff; }}
QLabel#AppTitlePro {{ font-size: 9pt; font-weight: 700; color: #04110e;
    background: {ACCENT}; border-radius: 6px; padding: 2px 6px; }}
QLabel#ProjectName {{ color: #8b949e; }}

QGroupBox {{
    background-color: #1a1f26; border: 1px solid #262d36; border-radius: 10px;
    margin-top: 14px; padding: 10px 8px 8px 8px; font-weight: 600;
}}
QGroupBox::title {{ subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #c9d1d9; }}

QPushButton, QToolButton {{
    background-color: #232a33; border: 1px solid #2f3742; border-radius: 8px;
    padding: 6px 12px;
}}
QPushButton:hover, QToolButton:hover {{ background-color: #2c3540; border-color: #3d4756; }}
QPushButton:pressed, QToolButton:pressed {{ background-color: #1b2129; }}
QPushButton:disabled, QToolButton:disabled {{ color: #5a636e; background-color: #1a1f25; }}
QToolButton:checked {{ background-color: #1d4d45; border-color: {ACCENT}; }}
QPushButton#AccentButton {{ background-color: {ACCENT}; color: #04110e; font-weight: 700; border: none; }}
QPushButton#AccentButton:hover {{ background-color: #35d8bb; }}
QPushButton#AutoDubButton {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {ACCENT}, stop:1 {ACCENT_2});
    color: #ffffff; font-size: 12pt; font-weight: 800; border: none; border-radius: 12px;
}}
QPushButton#AutoDubButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #35d8bb, stop:1 #9179ff);
}}
QPushButton#AutoDubButton:disabled {{ background: #2a3038; color: #6e7681; }}
QPushButton#TopExport {{ background-color: {ACCENT_2}; color: white; font-weight: 700; border: none; padding: 7px 16px; }}
QPushButton#TopExport:hover {{ background-color: #9179ff; }}
QPushButton#LicenseBadge {{ background-color: #1d4d45; color: #7ff0da; font-weight: 700;
    border: 1px solid {ACCENT}; border-radius: 10px; padding: 4px 12px; }}
QPushButton#LicenseBadge[trial="true"] {{ background-color: #4a3410; color: #ffcf6b; border-color: #b8860b; }}
QPushButton#TopAuto {{ background-color: {ACCENT}; color: #04110e; font-weight: 700; border: none; padding: 7px 16px; }}
QPushButton#StepButton {{ padding: 6px 4px; font-size: 9pt; }}
QPushButton#PlayButton {{ background-color: {ACCENT}; color: #04110e; font-size: 13pt; border: none; border-radius: 17px; }}

QComboBox, QDoubleSpinBox, QSpinBox, QLineEdit {{
    background-color: #0f1318; border: 1px solid #2a313b; border-radius: 7px; padding: 5px 8px;
}}
QComboBox:hover, QLineEdit:focus, QDoubleSpinBox:focus {{ border-color: {ACCENT}; }}
QComboBox QAbstractItemView {{ background-color: #181d24; selection-background-color: {ACCENT};
    selection-color: #04110e; border: 1px solid #2a313b; }}

QFrame#DropZone {{ background-color: #12171d; border: 2px dashed #2f3a46; border-radius: 14px; }}
QFrame#DropZone[hover="true"] {{ border-color: {ACCENT}; background-color: #10201d; }}
QLabel#DropIcon {{ font-size: 26pt; background: transparent; }}
QLabel#DropText {{ color: #8b949e; background: transparent; }}
QLabel#MutedLabel {{ color: #8b949e; font-size: 9pt; }}
QLabel#TimeLabel {{ font-family: Consolas, monospace; color: #c9d1d9; }}

QProgressBar {{ background-color: #0f1318; border: 1px solid #2a313b; border-radius: 7px;
    text-align: center; height: 16px; }}
QProgressBar::chunk {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {ACCENT}, stop:1 {ACCENT_2});
    border-radius: 6px; }}
QPlainTextEdit#LogBox {{ background-color: #0b0e12; border: 1px solid #222831; border-radius: 8px;
    font-family: Consolas, monospace; font-size: 8.5pt; color: #9aa4b0; }}

QTabWidget::pane {{ border: 1px solid #222831; border-radius: 10px; background: #14181d; top: -1px; }}
QTabBar::tab {{ background: #14181d; padding: 8px 12px; margin-right: 2px;
    border-top-left-radius: 8px; border-top-right-radius: 8px; color: #8b949e; }}
QTabBar::tab:selected {{ background: #1f2630; color: #ffffff; border-bottom: 2px solid {ACCENT}; }}
QTableWidget {{ background-color: #12161b; alternate-background-color: #161b21; border: none;
    gridline-color: #222831; selection-background-color: #1d4d45; selection-color: #ffffff; }}
QHeaderView::section {{ background-color: #1a1f26; padding: 6px; border: none;
    border-right: 1px solid #222831; color: #9aa4b0; font-weight: 600; }}
QTableWidget QLineEdit {{ background-color: #0b0e12; }}
QListWidget {{ background-color: #12161b; alternate-background-color: #161b21; border: 1px solid #222831;
    border-radius: 8px; padding: 4px; }}
QListWidget::item {{ padding: 5px 4px; color: #e6edf3; }}
QListWidget::item:selected {{ background-color: #1d4d45; color: #ffffff; }}

QSplitter::handle {{ background-color: #0b0d10; }}
QSplitter::handle:horizontal {{ width: 4px; }}
QSplitter::handle:vertical {{ height: 4px; }}
QSplitter::handle:hover {{ background-color: {ACCENT}; }}

QScrollBar:horizontal {{ background: #0f1216; height: 12px; margin: 0; }}
QScrollBar:vertical {{ background: #0f1216; width: 12px; margin: 0; }}
QScrollBar::handle {{ background: #2f3742; border-radius: 5px; min-width: 30px; min-height: 30px; }}
QScrollBar::handle:hover {{ background: #3f4a57; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}

QSlider::groove:horizontal {{ height: 4px; background: #2a313b; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {ACCENT}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: #ffffff; width: 12px; height: 12px; margin: -5px 0; border-radius: 6px; }}

QWidget#PlayerBar, QWidget#TimelineToolbar {{ background-color: #14181d; border-top: 1px solid #222831; }}
QLabel#TimelineInfo {{ color: #8b949e; }}

/* ---- Timeline, Movavi Video Editor style ---- */
QWidget#TimelineEditor {{ background-color: #262a35; }}
QWidget#MvToolbar {{ background-color: #2b2f3b; border-bottom: 2px solid #2a9d6f; }}
QToolButton#MvTool {{ background-color: #1f222b; border: 1px solid #1a1c24; border-radius: 3px;
    padding: 5px; margin: 0px; min-width: 22px; min-height: 22px; }}
QToolButton#MvTool:hover {{ background-color: #343948; }}
QToolButton#MvTool:pressed {{ background-color: #15171d; }}
QToolButton#MvTool:checked {{ background-color: #1b3a30; border-color: #2a9d6f; }}
QToolButton#MvTool:disabled {{ background-color: #23262f; }}
QWidget#MvBottom {{ background-color: #2b2f3b; border-top: 1px solid #1d2029; }}
QWidget#MvBottom QToolButton#MvTool {{ background: transparent; border: none; padding: 2px; }}
QLabel#MvMuted {{ color: #9aa0ae; }}
QLabel#MvValue {{ color: #e8eaf0; font-size: 10.5pt; }}
QLabel#MvInfo {{ color: #b9bdc9; font-size: 9pt; }}
QScrollArea#MvTracks {{ background-color: #262a35; }}
QSlider#MvScale::groove:horizontal {{ height: 4px; background: #1d2029; border-radius: 2px; }}
QSlider#MvScale::sub-page:horizontal {{ background: #2a9d6f; border-radius: 2px; }}
QSlider#MvScale::handle:horizontal {{ background: #e8eaf0; width: 6px; height: 14px; margin: -5px 0;
    border-radius: 2px; }}
QToolButton#MvExport {{ background-color: #23855d; color: white; font-size: 14pt;
    border: none; border-radius: 2px; padding: 4px 28px; }}
QToolButton#MvExport:hover {{ background-color: #2a9d6f; }}
QToolButton#MvQuick {{ background-color: #1f222b; color: #c9cdd8; border: 1px solid #2d313d;
    border-radius: 6px; padding: 4px 12px; font-size: 9.5pt; }}
QToolButton#MvQuick:hover {{ background-color: #343948; color: white; }}
QToolButton#MvQuick:disabled {{ color: #5d6270; }}
QFrame#MvQuickSep {{ background-color: #3a3f4c; }}
QToolButton#MvExport:pressed {{ background-color: #1d6e4d; }}
QWidget#MvTools {{ background-color: #262a35; }}
QLabel#MvToolsHead {{ color: #e8eaf0; font-size: 17pt; padding: 14px 0 10px 0; }}
QWidget#MvToolBar {{ background-color: #1f222b; }}
QLabel#MvToolTitle {{ color: #e8eaf0; font-size: 12pt; padding-left: 4px; }}
QLabel#MvFormLabel {{ color: #c9cdd8; }}
QLabel#MvToolTarget {{ color: #9fe3c6; padding-bottom: 4px; }}
QSlider#MvSlider::groove:horizontal {{ height: 4px; background: #1d2029; border-radius: 2px; }}
QSlider#MvSlider::sub-page:horizontal {{ background: #e8553e; border-radius: 2px; }}
QSlider#MvSlider::handle:horizontal {{ background: #e8553e; width: 6px; height: 16px; margin: -6px 0;
    border-radius: 2px; }}
QDoubleSpinBox#MvSpin {{ background-color: #1d2029; border: 1px solid #343846; border-radius: 2px;
    padding: 3px 6px; }}
QPushButton#MvApply {{ background-color: #1f222b; border: 1px solid #2d313d; border-radius: 2px;
    padding: 7px 26px; }}
QPushButton#MvApply:hover {{ background-color: #343948; }}
QPushButton#MvApply:checked {{ background-color: #343948; border-color: #e8553e; }}
QPushButton#MvTab {{ background-color: #1f222b; border: none; border-bottom: 2px solid #1f222b;
    padding: 9px; font-size: 11pt; border-radius: 0; }}
QPushButton#MvTab:checked {{ background-color: #262a35; border-bottom-color: #e8553e; }}
QPushButton#MvFxRow {{ border: none; }}
QToolButton#MvRatio {{ background-color: #1f222b; border: 1px solid #2d313d; border-radius: 4px;
    padding: 6px; color: #c9cdd8; }}
QToolButton#MvRatio:hover {{ background-color: #343948; }}
QToolButton#MvRatio:checked {{ border: 2px solid #e8553e; background-color: #2b2f3b; color: white; }}
QSlider#MvEq::groove:vertical {{ width: 4px; background: #1d2029; border-radius: 2px; }}
QSlider#MvEq::add-page:vertical {{ background: #3b8fe0; border-radius: 2px; }}
QSlider#MvEq::handle:vertical {{ background: #e8eaf0; height: 6px; width: 18px; margin: 0 -7px;
    border-radius: 2px; }}
QToolButton#MvExport:disabled {{ background-color: #2f4a40; color: #8a9a92; }}
QToolButton#TimelineTool {{ padding: 4px 9px; }}
QStatusBar {{ background-color: #0b0d10; color: #8b949e; border-top: 1px solid #222831; }}
QCheckBox::indicator {{ width: 15px; height: 15px; border-radius: 4px; border: 1px solid #3a4350; background: #0f1318; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QDialog {{ background-color: #14181d; }}
QToolTip {{ background-color: #181d24; color: #e6edf3; border: 1px solid #2a313b; padding: 4px; }}
"""

# --------------------------------------------------------------------------- #
# Batch dashboard
# --------------------------------------------------------------------------- #
DARK_QSS += f"""
QPushButton#TopAuto:disabled, QPushButton#TopExport:disabled, QPushButton#AccentButton:disabled {{
    background-color: #1f252d; color: #5a636e; border: 1px solid #2a313b; }}
QLabel#DashSubtitle {{ color: #c9d1d9; font-size: 12pt; font-weight: 600; }}
QPushButton#DangerButton {{ background-color: #3a1d22; color: #ff9b9b; border: 1px solid #6b2a31;
    font-weight: 700; padding: 7px 14px; }}
QPushButton#DangerButton:hover {{ background-color: #4a2329; }}
QPushButton#DangerButton:disabled {{ background-color: #1a1f25; color: #5a636e; border-color: #2f3742; }}
QFrame#StatCard {{ background-color: #1a1f26; border: 1px solid #262d36; border-radius: 12px; }}
QLabel#StatValue {{ font-size: 20pt; font-weight: 800; color: #ffffff; }}
QLabel#StatCaption {{ color: #8b949e; font-size: 9pt; }}
QFrame#StatCard[tone="done"] {{ border-color: #1f5a3c; }}
QFrame#StatCard[tone="done"] QLabel#StatValue {{ color: #6ee7a8; }}
QFrame#StatCard[tone="work"] {{ border-color: #1d5c52; }}
QFrame#StatCard[tone="work"] QLabel#StatValue {{ color: {ACCENT}; }}
QFrame#StatCard[tone="fail"] QLabel#StatValue {{ color: #ff8a8a; }}
QFrame#StatCard[tone="time"] {{ background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
    stop:0 #1d2a3a, stop:1 #2a2350); border-color: #3a3270; }}
QFrame#StatCard[tone="time"] QLabel#StatValue {{ color: #d6ccff; }}
QProgressBar#BigBar {{ height: 22px; border-radius: 11px; font-weight: 700; }}
QProgressBar#BigBar::chunk {{ border-radius: 10px; }}
QFrame#NowCard {{ background-color: #161b21; border: 1px solid #262d36; border-radius: 12px; }}
QLabel#NowTitle {{ color: #8b949e; font-size: 8.5pt; font-weight: 700; }}
QLabel#NowName {{ color: #ffffff; font-weight: 700; font-size: 11pt; }}
QLabel#Thumb {{ background-color: #0b0e12; border: 1px solid #262d36; border-radius: 8px;
    color: #3a4350; font-size: 20pt; }}
QFrame#DashPanel {{ background-color: #14181d; border: 1px solid #222831; border-radius: 12px; }}
QLabel#SectionTitle {{ font-size: 12pt; font-weight: 700; color: #ffffff; }}
QPushButton#SideNavButton {{ background: #161b21; border: 1px solid #262e38; border-radius: 8px;
    color: #b8c0cc; font-weight: 600; padding: 6px 4px; }}
QPushButton#SideNavButton:hover {{ background: #1d242d; color: #ffffff; }}
QPushButton#SideNavButton:checked {{ background: #12352e; border-color: {ACCENT};
    color: #ffffff; }}
QPushButton#RailButton {{ background: #161b21; border: 1px solid #262e38; border-radius: 10px;
    color: #b8c0cc; font-weight: 600; font-size: 8.5pt; padding: 6px 2px; }}
QPushButton#RailButton:hover {{ background: #1d242d; color: #ffffff; }}
QPushButton#RailButton:checked {{ background: #12352e; border-color: {ACCENT}; color: #ffffff; }}
QPushButton#StudioButton {{ background: #161b21; border: 1px solid #262e38; border-radius: 8px;
    color: #c9d1d9; font-weight: 600; padding: 4px 10px; }}
QPushButton#StudioButton:hover {{ background: #1d242d; color: #ffffff; border-color: {ACCENT}; }}
QPushButton#StudioButton[on="true"] {{ background: #12352e; border-color: {ACCENT}; color: #ffffff; }}
QPushButton#BaseSummary {{ color: #c9d1d9; background-color: #0f1318; border: 1px solid #262d36;
    border-radius: 8px; }}
QPushButton#BaseSummary:hover {{ border-color: {ACCENT}; }}
QLabel#SideHead {{ color: {ACCENT}; font-size: 8.5pt; font-weight: 700; padding-top: 6px; }}
QLabel#BaseSummary {{ color: #c9d1d9; background-color: #0f1318; border: 1px solid #262d36;
    border-radius: 8px; padding: 8px; }}
"""

# ---- Home dashboard (SARIKA VOXDUB PRO)
DARK_QSS += f"""
QWidget#HomePage, QWidget#HomeBody {{ background-color: #0d1014; }}
QFrame#HomeSide {{ background-color: #10141a; border-right: 1px solid #1e252e; }}
QLabel#HomeLogo {{ font-size: 18pt; background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
    stop:0 #1f6f63, stop:1 #22C3A6); border-radius: 12px; }}
QLabel#HomeBrand {{ font-size: 12pt; font-weight: 700; color: #ffffff; }}
QLabel#HomeBrandSub {{ font-size: 8pt; font-weight: 800; color: {ACCENT}; letter-spacing: 3px; }}
QLabel#TestingBadge {{ font-size: 7.5pt; font-weight: 800; color: #241a02; background: #f5b942;
    border-radius: 5px; padding: 1px 6px; }}
QLabel#HomeCap {{ color: #6b7686; font-size: 7.5pt; font-weight: 800; letter-spacing: 1px;
    padding: 16px 12px 4px 12px; }}
QLabel#HomeCapInline {{ color: #7d8896; font-size: 7.5pt; font-weight: 800; letter-spacing: 1px; }}
QPushButton#HomeNav {{ text-align: left; padding: 0 12px; border: none; border-radius: 10px;
    background: transparent; color: #aeb7c3; font-weight: 500; }}
QPushButton#HomeNav:hover {{ background: #171c23; color: #ffffff; }}
QPushButton#HomeNav:checked {{ background: #15302b; color: #e8fff9; font-weight: 600;
    border-left: 3px solid {ACCENT}; }}
QPushButton#HomePlanBox {{ background: #141920; border: 1px solid #232b36; border-radius: 12px;
    text-align: left; }}
QPushButton#HomePlanBox:hover {{ border-color: {ACCENT}; }}
QLabel#HomeSideState {{ color: #aeb7c3; font-size: 8.5pt; }}
QLabel#HomeVersion {{ color: #5d6876; font-size: 8pt; }}
QLabel#HomeBadge {{ font-size: 8pt; font-weight: 800; border-radius: 8px; padding: 2px 9px;
    background: #2a2140; color: #cdb6ff; }}
QLabel#HomeBadge[plan="basic"] {{ background: #2a333f; color: #c9d1db; }}
QLabel#HomeBadge[plan="pro"] {{ background: #15302b; color: #6fe0c9; }}
QFrame#HomeHero {{ border-radius: 18px; border: 1px solid #1f3a36;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #133b35, stop:0.55 #12202a,
    stop:1 #1b1a2e); }}
QLabel#HomeHello {{ color: #8fe8d6; font-size: 10pt; font-weight: 600; }}
QLabel#HomeHeroText {{ color: #c3ccd6; }}
QPushButton#HomeChip {{ background: rgba(0,0,0,90); border: 1px solid rgba(255,255,255,30);
    border-radius: 14px; padding: 6px 14px; color: #e8ecf1; font-weight: 600; }}
QPushButton#HomeChip:hover {{ border-color: {ACCENT}; }}
QFrame#HomeStep {{ background: #12171d; border: 1px solid #1f2731; border-radius: 12px; }}
QLabel#HomeStepNum {{ background: {ACCENT}; color: #0d1014; font-weight: 800;
    border-radius: 14px; }}
QLabel#HomeStepTitle {{ color: #ffffff; font-weight: 600; }}
QLabel#HomeArrow {{ color: #3d4855; font-size: 16pt; }}
QLabel#HomeH1 {{ font-size: 18pt; font-weight: 700; color: #ffffff; }}
QLabel#HomeH2 {{ font-size: 12pt; font-weight: 700; color: #ffffff; }}
QLabel#HomeText {{ color: #b7c0cc; }}
QLabel#HomeBig {{ font-size: 16pt; font-weight: 700; color: #ffffff; }}
QLabel#HomeEmpty {{ color: #7d8896; border: 1.5px dashed #262f3a; border-radius: 12px; }}
QFrame#HomeCard {{ background: #141920; border: 1px solid #232b36; border-radius: 16px; }}
QFrame#HomeCard:hover {{ border-color: #34404e; background: #161c24; }}
QFrame#HomeCard[locked="true"] {{ background: #12161b; }}
QLabel#HomeCardIcon {{ font-size: 18pt; }}
QLabel#HomeCardTitle {{ font-size: 13pt; font-weight: 700; color: #ffffff; }}
QLabel#HomeCardSmall {{ font-size: 8.5pt; font-weight: 600; }}
QLabel#HomeCardText {{ color: #aeb7c3; }}
QLabel#HomeDrop {{ color: #8c97a6; border: 1.5px dashed #2f3946; border-radius: 10px;
    background: #10141a; }}
QLabel#HomeLock {{ font-size: 8pt; color: #f5cd7a; background: #2b2414; border-radius: 8px;
    padding: 2px 8px; }}
QPushButton#HomeCta {{ background: {ACCENT}; color: #0d1014; border: none; border-radius: 10px;
    font-weight: 700; padding: 0 16px; }}
QPushButton#HomeCta:hover {{ background: #6fe0c9; }}
QPushButton#HomeCta:disabled {{ background: #2a333f; color: #8a93a0; }}
QPushButton#HomeGhost {{ background: transparent; color: #e8ecf1; border: 1px solid #34404e;
    border-radius: 10px; font-weight: 600; padding: 0 14px; min-height: 30px; }}
QPushButton#HomeGhost:hover {{ border-color: {ACCENT}; color: #ffffff; }}
QPushButton#HomeGhost:disabled {{ color: #6f7a88; }}
QPushButton#HomeGhost:checked {{ background: #15302b; border-color: {ACCENT}; color: #ffffff; }}
QPushButton#HomeTool {{ text-align: left; padding: 0 14px; background: #141920;
    border: 1px solid #232b36; border-radius: 12px; color: #d5dce4; font-weight: 500; }}
QPushButton#HomeTool:hover {{ border-color: {ACCENT}; background: #171d25; color: #ffffff; }}
QPushButton#HomeRecent {{ background: #141920; border: 1px solid #232b36; border-radius: 12px;
    text-align: left; }}
QPushButton#HomeRecent:hover {{ border-color: {ACCENT}; }}
QLabel#HomeThumb {{ background: #1a2029; border-radius: 8px; color: #4f5b69; font-size: 20pt; }}
QLabel#HomeTag {{ color: #0d1014; font-size: 8pt; font-weight: 700; border-radius: 5px;
    padding: 1px 7px; }}
QLabel#HomeLen {{ color: #e8ecf1; background: rgba(0,0,0,170); font-size: 8pt;
    border-radius: 4px; padding: 1px 5px; }}
QLabel#HomeRecentTitle {{ color: #ffffff; font-weight: 500; }}
QFrame#HomeBox {{ background: #141920; border: 1px solid #232b36; border-radius: 16px; }}
QFrame#HomeAdminBox {{ background: #1b1830; border: 1px solid #3a3160; border-radius: 14px; }}
QFrame#HomeUpsell {{ background: #1a1810; border: 1px solid #4a3e1c; border-radius: 16px; }}
QLabel#HomeBoxTitle {{ font-size: 11pt; font-weight: 700; color: #ffffff; }}
QLabel#HomeVerChip {{ font-size: 8pt; font-weight: 800; color: #6fe0c9; background: #15302b;
    border-radius: 8px; padding: 2px 8px; }}
QLabel#HomeState {{ font-size: 13pt; font-weight: 700; color: #e8ecf1; }}
QLabel#HomeState[state="ok"], QLabel#HomeSideState[state="ok"] {{ color: #22C3A6; }}
QLabel#HomeState[state="soon"], QLabel#HomeSideState[state="soon"] {{ color: #F5B942; }}
QLabel#HomeState[state="bad"], QLabel#HomeSideState[state="bad"] {{ color: #EF6B6B; }}
QLabel#HomeState[state="admin"], QLabel#HomeSideState[state="admin"] {{ color: #B48CFF; }}
QProgressBar#HomeBar {{ background: #222a34; border: none; border-radius: 4px; }}
QProgressBar#HomeBar::chunk {{ background: #F5B942; border-radius: 4px; }}
QPushButton#HomeLink {{ background: transparent; border: none; color: {ACCENT}; padding: 2px 0;
    font-weight: 600; }}
QPushButton#HomeLink:hover {{ color: #6fe0c9; }}
QPushButton#HomeAmber {{ background: #f5b942; color: #241a02; border: none; border-radius: 9px;
    font-weight: 600; }}
QFrame#HomeLicCard {{ border-radius: 18px; border: 1px solid #1f3a36;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #11302b, stop:1 #141920); }}
QLabel#HomeMachine {{ font-family: Consolas, monospace; font-size: 12pt; font-weight: 700;
    color: #ffffff; background: #0d1014; border: 1px solid #2a333f; border-radius: 8px;
    padding: 6px 10px; }}
QLabel#HomeNote {{ color: #f5cd7a; background: #2b2414; border-radius: 10px; padding: 8px 12px; }}
QFrame#HomePriceCard {{ background: #141920; border: 1px solid #232b36; border-radius: 16px; }}
QFrame#HomePriceCard:hover {{ border-color: #34404e; }}
QFrame#HomePriceCard[best="true"] {{ border: 2px solid {ACCENT}; background: #12201e; }}
QLabel#HomeBest {{ font-size: 7.5pt; font-weight: 800; color: #0d1014; background: {ACCENT};
    border-radius: 8px; padding: 2px 8px; }}
QLabel#HomeSave {{ font-size: 8pt; font-weight: 800; color: #6fe0c9; background: #15302b;
    border-radius: 8px; padding: 2px 8px; }}
QFrame#HomePlan {{ background: #141920; border: 1px solid #232b36; border-radius: 16px; }}
QFrame#HomePlan[current="true"] {{ border: 2px solid {ACCENT}; }}
QLabel#HomeInUse {{ font-size: 8pt; font-weight: 800; color: #6fe0c9; background: #15302b;
    border-radius: 8px; padding: 2px 9px; }}
QLabel#HomePrice {{ font-size: 24pt; font-weight: 800; color: #ffffff; }}
QLabel#HomeYes {{ color: #d5dce4; }}
QLabel#HomeNo {{ color: #6f7a88; }}
QPushButton#WorkspaceTab {{ background: #161b21; border: 1px solid #262e38; padding: 5px 12px;
    color: #b8c0cc; font-weight: 600; }}
QPushButton#WorkspaceTab:checked {{ background: #12352e; border-color: {ACCENT}; color: #ffffff; }}
"""

# ---- Edit workspace: Filmora-style library (left) + inspector (right)
DARK_QSS += f"""
QFrame#LibPanel {{ background: #15191f; }}
QFrame#LibTop {{ background: #111419; border-bottom: 1px solid #222831; }}
QToolButton#LibCat {{ background: transparent; border: none; border-radius: 8px;
    color: #aeb7c3; font-size: 10pt; font-weight: 600; padding: 4px 8px; min-width: 64px;
    min-height: 50px; }}
QToolButton#LibCat:hover {{ background: #1b2129; color: #ffffff; }}
QToolButton#LibCat:checked {{ color: {ACCENT}; background: #12302b; }}
QListWidget#LibGrid {{ background: #15191f; border: none; color: #d5dce4; outline: 0; }}
QListWidget#LibGrid::item {{ border-radius: 8px; padding: 4px; }}
QListWidget#LibGrid::item:hover {{ background: #1d242d; }}
QListWidget#LibGrid::item:selected {{ background: #12302b; border: 1px solid {ACCENT};
    color: #ffffff; }}
QPushButton#LibImport {{ background: {ACCENT}; color: #0d1014; border: none; border-radius: 7px;
    font-weight: 700; padding: 6px 14px; }}
QPushButton#LibImport:hover {{ background: #6fe0c9; }}
QLabel#LibEmpty {{ color: #7d8896; border: 1.5px dashed #2f3946; border-radius: 12px;
    font-size: 11pt; }}
QPushButton#LibLook {{ border: 1px solid #2a333f; border-radius: 10px; padding: 6px;
    text-align: center; }}
QPushButton#LibLook:checked {{ border: 2px solid {ACCENT}; }}
QWidget#InsBody {{ background: #15191f; }}
QLabel#InsHead {{ color: #ffffff; font-weight: 700; font-size: 10pt; padding: 10px 0 4px 0;
    border-bottom: 1px solid #262e38; }}
QLabel#InsLabel {{ color: #aeb7c3; }}
QLabel#InsValue {{ color: #ffffff; font-weight: 600; padding: 4px 0; }}
QPushButton#InsToggle {{ background: #1b2129; border: 1px solid #2f3946; border-radius: 7px;
    color: #d5dce4; padding: 5px 12px; }}
QPushButton#InsToggle:hover {{ border-color: {ACCENT}; }}
QPushButton#InsToggle:checked {{ background: #12302b; border-color: {ACCENT}; color: #ffffff; }}
QPushButton#InsSmall {{ background: #1b2129; border: 1px solid #2a333f; border-radius: 7px;
    color: #d5dce4; padding: 4px 10px; }}
QPushButton#InsSmall:hover {{ border-color: {ACCENT}; color: #ffffff; }}
"""

# 2.0 redesign: the rules above stay as they are; their colours move onto the
# design tokens of ui/theme.py (VOXDUB_LEGACY_THEME=1 keeps the 1.7 colours)
from ui.theme import extra_qss as _extra_qss, remap as _remap  # noqa: E402

DARK_QSS = _remap(DARK_QSS) + _extra_qss()
