"""
dialogs.py - Azure Speech key, License and Project settings dialogs.
"""

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import (
    QComboBox, QDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
    QPlainTextEdit, QPushButton, QVBoxLayout,
)

from core import license as lic
from core import settings
from core.tts import AZURE_REGIONS, configure_azure, test_azure


class _Job(QThread):
    finished_with = Signal(object)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self.fn = fn

    def run(self):
        try:
            self.finished_with.emit(self.fn())
        except Exception as e:          # show, never crash
            self.finished_with.emit(str(e))


def apply_azure_settings():
    """Load the saved Azure key/region into the TTS engine."""
    configure_azure(settings.get("azure_key", ""), settings.get("azure_region", "southeastasia"))


class AzureKeyDialog(QDialog):
    """Enter / test / save the user's own Azure Speech key."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Azure Speech key")
        self.setMinimumWidth(500)
        self._job = None
        saved = settings.get("azure_key", "")

        self.ed_key = QLineEdit()
        self.ed_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.ed_key.setPlaceholderText(
            f"saved: {settings.mask(saved)}" if saved else "paste KEY 1 from the Azure portal")
        self.cmb_region = QComboBox()
        for r in AZURE_REGIONS:
            self.cmb_region.addItem(r, r)
        idx = self.cmb_region.findData(settings.get("azure_region", "southeastasia"))
        self.cmb_region.setCurrentIndex(max(0, idx))
        self.cmb_region.setEditable(True)

        help_text = QLabel(
            "1. portal.azure.com → Create a resource → <b>Speech</b><br>"
            "2. Pricing tier <b>F0</b> (free, ~0.5 M characters / month, slow) or "
            "<b>S0</b> (pay per use, fast)<br>"
            "3. Keys and Endpoint → copy <b>KEY 1</b> and the <b>Location/Region</b><br>"
            "The key is saved only on this computer (not in project files).")
        help_text.setWordWrap(True)
        help_text.setObjectName("MutedLabel")
        help_text.setTextFormat(Qt.TextFormat.RichText)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        b_test = QPushButton("Test")
        b_test.clicked.connect(self._test)
        b_save = QPushButton("Save")
        b_save.setObjectName("AccentButton")
        b_save.clicked.connect(self._save)
        b_clear = QPushButton("Remove key")
        b_clear.clicked.connect(self._clear)
        b_close = QPushButton("Close")
        b_close.clicked.connect(self.reject)
        self.b_test = b_test

        form = QFormLayout()
        form.addRow("Key", self.ed_key)
        form.addRow("Region", self.cmb_region)
        row = QHBoxLayout()
        row.addWidget(b_clear)
        row.addStretch(1)
        row.addWidget(b_close)
        row.addWidget(b_test)
        row.addWidget(b_save)
        lay = QVBoxLayout(self)
        lay.addWidget(help_text)
        lay.addLayout(form)
        lay.addWidget(self.status)
        lay.addLayout(row)

    def _key(self) -> str:
        return self.ed_key.text().strip() or settings.get("azure_key", "")

    def _region(self) -> str:
        return self.cmb_region.currentText().strip() or "southeastasia"

    def _test(self):
        key = self._key()
        if not key:
            self.status.setText("Paste a key first.")
            return
        self.status.setText("Testing...")
        self.b_test.setEnabled(False)
        region = self._region()
        self._job = _Job(lambda: test_azure(key, region), self)
        self._job.finished_with.connect(self._tested)
        self._job.start()

    def _tested(self, err):
        self.b_test.setEnabled(True)
        self.status.setText("✅ The key works (Khmer voice generated)." if not err
                            else f"❌ {err}")

    def _save(self):
        key = self._key()
        if not key:
            self.status.setText("Paste a key first.")
            return
        settings.set("azure_key", key)
        settings.set("azure_region", self._region())
        apply_azure_settings()
        self.accept()

    def _clear(self):
        settings.set("azure_key", "")
        apply_azure_settings()
        self.ed_key.clear()
        self.ed_key.setPlaceholderText("paste KEY 1 from the Azure portal")
        self.status.setText("Key removed from this computer.")

    def closeEvent(self, event):
        if self._job and self._job.isRunning():
            self._job.wait(15000)
        super().closeEvent(event)


class LicenseDialog(QDialog):
    """Show this PC's Machine ID, the license state, and activate a key."""

    licenseChanged = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("SARIKA VOXDUB PRO license")
        self.setMinimumWidth(560)
        self.mid = lic.machine_id()

        mid_box = QLineEdit(self.mid)
        mid_box.setReadOnly(True)
        mid_box.setObjectName("TimeLabel")
        b_copy = QPushButton("Copy")
        b_copy.clicked.connect(self._copy)
        mid_row = QHBoxLayout()
        mid_row.addWidget(mid_box, 1)
        mid_row.addWidget(b_copy)

        self.state = QLabel()
        self.state.setWordWrap(True)
        self.ed_key = QPlainTextEdit()
        self.ed_key.setPlaceholderText("Paste your license key here (VXD1-...)")
        self.ed_key.setFixedHeight(80)

        text = ("To buy or renew: send the Machine ID above to the seller. "
                "You receive a key — paste it here and click Activate.")
        if lic.TRIAL_ENABLED:
            text += ("\nWithout a license everything works, but exported videos "
                     f"show the watermark “{lic.TRIAL_WATERMARK}”.")
        how = QLabel(text)
        how.setWordWrap(True)
        how.setObjectName("MutedLabel")

        b_act = QPushButton("Activate")
        b_act.setObjectName("AccentButton")
        b_act.clicked.connect(self._activate)
        b_close = QPushButton("Close")
        b_close.clicked.connect(self.accept)
        row = QHBoxLayout()
        row.addStretch(1)
        row.addWidget(b_close)
        row.addWidget(b_act)

        form = QFormLayout()
        form.addRow("Machine ID", mid_row)
        form.addRow("Status", self.state)
        lay = QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(self.ed_key)
        lay.addWidget(how)
        lay.addLayout(row)
        self._show(lic.current())

    def _copy(self):
        QGuiApplication.clipboard().setText(self.mid)
        self.state.setText(self.state.text().split("\n")[0] + "\n(Machine ID copied)")

    def _show(self, info: lic.LicenseInfo):
        if info.valid:
            warn = " ⚠ renew soon" if info.days_left <= 5 else ""
            self.state.setText(f"✅ {info.summary()}{warn}")
        elif not lic.stored_key() and info.reason == "No license key":
            self.state.setText("Trial (no license key)" if lic.TRIAL_ENABLED
                               else "No license key (trial watermark is off)")
        else:
            self.state.setText(f"❌ {info.reason}")

    def _activate(self):
        key = self.ed_key.toPlainText().strip()
        if not key:
            self.state.setText("Paste the key first.")
            return
        info = lic.activate(key)
        self._show(info)
        if info.valid:
            self.ed_key.clear()
            self.licenseChanged.emit()


# --------------------------------------------------------------------------- #
# Project settings (Movavi: the pencil next to "Project settings" on the timeline)
# --------------------------------------------------------------------------- #
FRAMING_LABELS = {                      # Movavi names
    "black": "Letterbox",
    "blur": "Blur",
    "stretch": "Stretch",
    "crop": "Crop",
}
FRAMING_HELP = (
    "How the video fits a size with another shape:\n\n"
    "Letterbox - the whole picture, black bars fill the rest.\n"
    "Blur - the whole picture, a blurred copy of the video fills the rest.\n"
    "Stretch - the picture is stretched to fill the frame (people look wider / thinner).\n"
    "Crop - the picture is zoomed in until it fills the frame; the edges are cut off.")
PRESET_HINTS = {(1080, 1920): "TikTok / Reels / Shorts", (720, 1280): "TikTok / Reels / Shorts",
                (1080, 1350): "Facebook / Instagram", (1080, 1080): "Square"}
CHANNELS = [(1, "Mono"), (2, "Stereo"), (6, "Surround sound (5.1)")]


class ProjectSettingsDialog(QDialog):
    """Movavi's Project Settings: Resolution (+ width x height with a link),
    Framing, FPS, Sample rate, Channels."""

    def __init__(self, project, parent=None):
        import copy

        from PySide6.QtWidgets import QGridLayout, QSpinBox, QToolButton

        from core import branding
        from core.export import AUDIO_RATES, FPS_CHOICES

        super().__init__(parent)
        self.setWindowTitle("Project Settings")
        self.setMinimumWidth(500)
        self.project = project
        src = copy.copy(project)
        src.out_ratio, src.out_width, src.out_height = "original", 0, 0
        self._src_size = branding.output_size(src, 0) if project.width and project.height \
            else (1920, 1080)
        self._busy = False

        # --- resolution
        self.cmb_res = QComboBox()
        sw, sh = self._src_size
        same = (f"Same as the video – {sw}x{sh} ({branding.ratio_text(sw, sh)})"
                if project.width and project.height else "Same as the video")
        self.cmb_res.addItem(same, ("original", sw, sh))
        for w, h in branding.RESOLUTION_PRESETS:
            text = f"{w}x{h} ({branding.ratio_text(w, h)})"
            if (w, h) in PRESET_HINTS:
                text += f"  {PRESET_HINTS[(w, h)]}"
            self.cmb_res.addItem(text, ("preset", w, h))
        self.cmb_res.addItem("Custom", ("custom", 0, 0))
        self.sp_w, self.sp_h = QSpinBox(), QSpinBox()
        for sp in (self.sp_w, self.sp_h):
            sp.setRange(16, 8192)
            sp.setSingleStep(2)
            sp.setKeyboardTracking(False)
        self.btn_link = QToolButton()
        self.btn_link.setText("🔗")
        self.btn_link.setCheckable(True)
        self.btn_link.setChecked(True)
        self.btn_link.setToolTip("Keep the proportions when you change the width or height")
        size_row = QHBoxLayout()
        size_row.setSpacing(6)
        size_row.addWidget(self.sp_w, 1)
        size_row.addWidget(QLabel("x"))
        size_row.addWidget(self.sp_h, 1)
        size_row.addWidget(self.btn_link)

        # --- framing
        self.cmb_fill = QComboBox()
        for key, label in FRAMING_LABELS.items():
            self.cmb_fill.addItem(label, key)
        self.btn_help = QToolButton()
        self.btn_help.setText("?")
        self.btn_help.setToolTip(FRAMING_HELP)
        self.btn_help.clicked.connect(
            lambda: QMessageBox.information(self, "Framing", FRAMING_HELP))
        fill_row = QHBoxLayout()
        fill_row.setSpacing(6)
        fill_row.addWidget(self.cmb_fill, 1)
        fill_row.addWidget(self.btn_help)

        # --- fps / audio
        fps = float(getattr(project, "fps", 0.0) or 0.0)
        self.cmb_fps = QComboBox()
        same = f"{fps:.2f}".rstrip("0").rstrip(".") if fps else "?"
        self.cmb_fps.addItem(f"Same as the video ({same})", 0.0)
        for f in FPS_CHOICES:
            self.cmb_fps.addItem("23.98" if f == 23.976 else f"{f:g}", float(f))
        self.cmb_rate = QComboBox()
        for r in AUDIO_RATES:
            self.cmb_rate.addItem(str(r), r)
        self.cmb_ch = QComboBox()
        for n, label in CHANNELS:
            self.cmb_ch.addItem(label, n)

        def head(text):
            return QLabel(text)

        grid = QGridLayout()
        grid.setHorizontalSpacing(18)
        grid.setVerticalSpacing(6)
        grid.addWidget(head("Resolution:"), 0, 0)
        grid.addWidget(head("Framing:"), 0, 1)
        grid.addWidget(self.cmb_res, 1, 0)
        grid.addLayout(fill_row, 1, 1)
        grid.addLayout(size_row, 2, 0)
        grid.addWidget(head("FPS:"), 3, 0)
        grid.addWidget(self.cmb_fps, 4, 0)
        grid.addWidget(head("Sample rate:"), 5, 0)
        grid.addWidget(head("Channels:"), 5, 1)
        grid.addWidget(self.cmb_rate, 6, 0)
        grid.addWidget(self.cmb_ch, 6, 1)
        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 2)

        ok = QPushButton("OK")
        ok.setObjectName("AccentButton")
        ok.setDefault(True)
        ok.clicked.connect(self.accept)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        btns = QHBoxLayout()
        btns.addStretch(1)
        btns.addWidget(ok)
        btns.addWidget(cancel)
        lay = QVBoxLayout(self)
        lay.addLayout(grid)
        lay.addSpacing(10)
        lay.addLayout(btns)

        # --- current values
        self._load(project)
        self.cmb_res.currentIndexChanged.connect(self._res_chosen)
        self.sp_w.valueChanged.connect(lambda v: self._size_edited("w"))
        self.sp_h.valueChanged.connect(lambda v: self._size_edited("h"))

    # ------------------------------------------------------------------ #
    def _load(self, p):
        from core import branding

        self._busy = True
        if p.out_ratio == "original":
            idx = 0
            w, h = self._src_size
        else:
            w, h = branding.output_size(p, 0)
            idx = self._find(w, h)
        self.cmb_res.setCurrentIndex(idx)
        self.sp_w.setValue(w)
        self.sp_h.setValue(h)
        self._aspect = w / h
        self.cmb_fill.setCurrentIndex(max(0, self.cmb_fill.findData(p.ratio_fill or "blur")))
        fps = float(getattr(p, "out_fps", 0.0) or 0.0)
        k = next((i for i in range(self.cmb_fps.count())
                  if abs(self.cmb_fps.itemData(i) - fps) < 0.01), 0)
        self.cmb_fps.setCurrentIndex(k)
        self.cmb_rate.setCurrentIndex(max(0, self.cmb_rate.findData(int(p.audio_rate or 44100))))
        self.cmb_ch.setCurrentIndex(max(0, self.cmb_ch.findData(int(p.audio_channels or 2))))
        self._busy = False
        self._update()

    def _find(self, w, h) -> int:
        """Index of the preset w x h, else 'Custom'."""
        for i in range(1, self.cmb_res.count()):
            kind, pw, ph = self.cmb_res.itemData(i)
            if kind == "preset" and (pw, ph) == (w, h):
                return i
        return self.cmb_res.count() - 1

    def _res_chosen(self, _i):
        if self._busy:
            return
        kind, w, h = self.cmb_res.currentData()
        if kind != "custom":
            self._busy = True
            self.sp_w.setValue(w)
            self.sp_h.setValue(h)
            self._aspect = w / h
            self._busy = False
        self._update()

    def _size_edited(self, which):
        if self._busy:
            return
        self._busy = True
        w, h = self.sp_w.value(), self.sp_h.value()
        if self.btn_link.isChecked() and self._aspect > 0:
            if which == "w":
                h = max(16, int(round(w / self._aspect / 2)) * 2)
                self.sp_h.setValue(h)
            else:
                w = max(16, int(round(h * self._aspect / 2)) * 2)
                self.sp_w.setValue(w)
        else:
            self._aspect = w / h
        self.cmb_res.setCurrentIndex(self._find(w, h))
        self._busy = False
        self._update()

    def _update(self):
        original = self.cmb_res.currentData()[0] == "original"
        for w in (self.sp_w, self.sp_h, self.btn_link, self.cmb_fill):
            w.setEnabled(not original)

    def values(self) -> dict:
        from core import branding

        kind = self.cmb_res.currentData()[0]
        if kind == "original":
            ratio, w, h = "original", 0, 0
        else:
            w, h = self.sp_w.value() // 2 * 2, self.sp_h.value() // 2 * 2
            ratio = branding.ratio_key(w, h)
        return {"out_ratio": ratio, "out_width": w, "out_height": h,
                "ratio_fill": self.cmb_fill.currentData(),
                "out_fps": float(self.cmb_fps.currentData()),
                "audio_rate": int(self.cmb_rate.currentData()),
                "audio_channels": int(self.cmb_ch.currentData())}
