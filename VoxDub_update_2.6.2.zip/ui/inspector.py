"""
inspector.py - The Filmora-style properties panel of the Edit workspace
(right side, next to Subtitles / Style):

    Video   Transform (Scale, Position X / Y, Rotate, Flip) · Crop · Fades
    Audio   the video's own sound (or the selected AI voice): volume, keep
            music only, fades, Equalizer / Noise Removal / Effects
    Speed   the whole video 50 - 200 % (the AI voice keeps its pitch)
    Color   Auto + manual colour sliders

It edits the Project like the Tools panel does (same signals, so the window
wires both the same way); one Undo step per burst of changes.
"""

import time
from typing import Optional

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QStackedWidget, QVBoxLayout, QWidget,
)

from core.media import format_time
from core.project import AudioClip, Project
from ui.tools_panel import ClipPage, ColorPage, EffectsPage, EqPage, NoisePage, SliderRow

UNDO_GAP = 1.2          # s: changes closer together are one Undo step
_KEEP = object()        # load(): keep the sound clip shown in the Audio tab


def _head(text: str) -> QLabel:
    lb = QLabel(text)
    lb.setObjectName("InsHead")
    return lb


def _row_label(text: str) -> QLabel:
    lb = QLabel(text)
    lb.setObjectName("InsLabel")
    lb.setMinimumWidth(84)
    return lb


def _scroll(inner: QWidget) -> QScrollArea:
    sc = QScrollArea()
    sc.setWidgetResizable(True)
    sc.setFrameShape(QFrame.Shape.NoFrame)
    sc.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    inner.setObjectName("InsBody")
    sc.setWidget(inner)
    return sc


def _hide_bar(page):
    """The «  Title  ✓ bar of a Tools page (not needed in a tab)."""
    item = page.layout().itemAt(0)
    if item and item.widget():
        item.widget().setVisible(False)


# --------------------------------------------------------------------------- #
class VideoTab(QWidget):
    def __init__(self, ins: "Inspector"):
        super().__init__()
        self.ins = ins
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 14)
        lay.setSpacing(6)

        lay.addWidget(_head("Transform"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        g.setVerticalSpacing(8)
        self.scale = SliderRow(100, 300, 1, 0, " %")
        self.scale.setToolTip("Zoom into the picture (100 % = the whole picture)")
        self.scale.valueChanged.connect(
            lambda v: ins.edit("crop", lambda p: setattr(p, "zoom", round(v / 100.0, 3))))
        self.pos_x = SliderRow(-100, 100, 1, 0)
        self.pos_y = SliderRow(-100, 100, 1, 0)
        for s, f in ((self.pos_x, "pan_x"), (self.pos_y, "pan_y")):
            s.setToolTip("Which part of the zoomed picture is shown (needs Scale above 100 %)")
            s.valueChanged.connect(lambda v, f=f: ins.edit(
                "crop", lambda p: setattr(p, f, round(v / 100.0, 3))))
        self.rotate = SliderRow(-180, 180, 0.1, 1, "°")
        self.rotate.valueChanged.connect(
            lambda v: ins.edit("crop", lambda p: setattr(p, "rotate", round(v, 1))))
        self.flip_h = QPushButton("⇋  Horizontal")
        self.flip_v = QPushButton("⇵  Vertical")
        for b, f in ((self.flip_h, "flip_h"), (self.flip_v, "flip_v")):
            b.setCheckable(True)
            b.setObjectName("InsToggle")
            b.toggled.connect(lambda on, f=f: ins.edit("crop", lambda p: setattr(p, f, on)))
        flips = QHBoxLayout()
        flips.addWidget(self.flip_h)
        flips.addWidget(self.flip_v)
        flips.addStretch(1)
        for r, (name, w) in enumerate((("Scale", self.scale), ("Position X", self.pos_x),
                                       ("Position Y", self.pos_y), ("Rotate", self.rotate))):
            g.addWidget(_row_label(name), r, 0)
            g.addWidget(w, r, 1)
        g.addWidget(_row_label("Flip"), 4, 0)
        g.addLayout(flips, 4, 1)
        lay.addLayout(g)
        b_reset = QPushButton("Reset transform")
        b_reset.setObjectName("InsSmall")
        b_reset.clicked.connect(self._reset_transform)
        lay.addWidget(b_reset, 0, Qt.AlignmentFlag.AlignRight)

        lay.addWidget(_head("Crop"))
        self.crop_readout = QLabel("")
        self.crop_readout.setObjectName("MutedLabel")
        lay.addWidget(self.crop_readout)
        crow = QHBoxLayout()
        self.btn_crop = QPushButton("✂  Crop on the preview")
        self.btn_crop.setCheckable(True)
        self.btn_crop.setObjectName("InsToggle")
        self.btn_crop.toggled.connect(ins.cropModeRequested.emit)
        self.keep = QCheckBox("Keep proportions")
        self.keep.toggled.connect(ins.cropKeepAspect.emit)
        crow.addWidget(self.btn_crop)
        crow.addWidget(self.keep)
        crow.addStretch(1)
        lay.addLayout(crow)
        crow2 = QHBoxLayout()
        b_bars = QPushButton("Remove black bars")
        b_bars.setObjectName("InsSmall")
        b_bars.clicked.connect(ins.blackBarsRequested.emit)
        b_crop_reset = QPushButton("Reset crop")
        b_crop_reset.setObjectName("InsSmall")
        b_crop_reset.clicked.connect(self._reset_crop)
        crow2.addWidget(b_bars)
        crow2.addWidget(b_crop_reset)
        crow2.addStretch(1)
        lay.addLayout(crow2)

        lay.addWidget(_head("Fade"))
        fg = QGridLayout()
        fg.setHorizontalSpacing(10)
        self.fade_in = SliderRow(0, 10, 0.1, 1, " sec.")
        self.fade_out = SliderRow(0, 10, 0.1, 1, " sec.")
        self.fade_in.valueChanged.connect(
            lambda v: ins.edit("video", lambda p: setattr(p, "video_fade_in", v)))
        self.fade_out.valueChanged.connect(
            lambda v: ins.edit("video", lambda p: setattr(p, "video_fade_out", v)))
        fg.addWidget(_row_label("Fade in"), 0, 0)
        fg.addWidget(self.fade_in, 0, 1)
        fg.addWidget(_row_label("Fade out"), 1, 0)
        fg.addWidget(self.fade_out, 1, 1)
        lay.addLayout(fg)

        lay.addWidget(_head("Size & shape"))
        srow = QHBoxLayout()
        b_ratio = QPushButton("📐  Ratio / size…")
        b_ratio.setObjectName("InsSmall")
        b_ratio.setToolTip("16:9, 9:16, 4:5 … and the fill (blur / black) – Project settings")
        b_ratio.clicked.connect(lambda: ins.switch_tool("ratio"))
        b_reframe = QPushButton("🔄  Reframe…")
        b_reframe.setObjectName("InsSmall")
        b_reframe.setToolTip("Turn 90° / mirror a whole video file into a new MP4")
        b_reframe.clicked.connect(ins.reframeRequested.emit)
        srow.addWidget(b_ratio)
        srow.addWidget(b_reframe)
        srow.addStretch(1)
        lay.addLayout(srow)
        lay.addStretch(1)

    def load(self, p: Project):
        self.scale.set_value(round(float(p.zoom or 1.0) * 100))
        self.pos_x.set_value(round(float(getattr(p, "pan_x", 0) or 0) * 100))
        self.pos_y.set_value(round(float(getattr(p, "pan_y", 0) or 0) * 100))
        self.rotate.set_value(float(p.rotate or 0.0))
        for b, f in ((self.flip_h, "flip_h"), (self.flip_v, "flip_v")):
            b.blockSignals(True)
            b.setChecked(bool(getattr(p, f, False)))
            b.blockSignals(False)
        self.fade_in.set_value(float(p.video_fade_in or 0))
        self.fade_out.set_value(float(p.video_fade_out or 0))
        self.show_crop(p)

    def show_crop(self, p: Project):
        cut = [(n, float(getattr(p, f) or 0)) for n, f in
               (("left", "crop_left"), ("top", "crop_top"), ("right", "crop_right"),
                ("bottom", "crop_bottom"))]
        on = [f"{n} {v * 100:.0f}%" for n, v in cut if v > 0.0005]
        self.crop_readout.setText("Cut off: " + ", ".join(on) if on else
                                  "Nothing cut off. Click “Crop on the preview” and drag the "
                                  "box on the video.")

    def _reset_transform(self):
        def do(p):
            p.zoom, p.rotate, p.pan_x, p.pan_y = 1.0, 0.0, 0.0, 0.0
            p.flip_h = p.flip_v = False
        self.ins.edit("crop", do)
        self.load(self.ins.project)

    def _reset_crop(self):
        def do(p):
            p.crop_left = p.crop_top = p.crop_right = p.crop_bottom = 0.0
        self.ins.edit("crop", do)
        self.show_crop(self.ins.project)


class SpeedTab(QWidget):
    PRESETS = (0.75, 1.0, 1.1, 1.25, 1.5, 2.0)

    def __init__(self, ins: "Inspector"):
        super().__init__()
        self.ins = ins
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 14)
        lay.setSpacing(8)
        lay.addWidget(_head("Uniform speed"))
        g = QGridLayout()
        g.setHorizontalSpacing(10)
        self.speed = SliderRow(50, 200, 1, 0, " %")
        self.speed.valueChanged.connect(self._set)
        g.addWidget(_row_label("Speed"), 0, 0)
        g.addWidget(self.speed, 0, 1)
        lay.addLayout(g)
        row = QHBoxLayout()
        for v in self.PRESETS:
            b = QPushButton(f"{v:g}×")
            b.setObjectName("InsSmall")
            b.clicked.connect(lambda _=False, v=v: (self.speed.set_value(v * 100),
                                                    self._set(v * 100)))
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        self.duration = QLabel("")
        self.duration.setObjectName("InsValue")
        lay.addWidget(self.duration)
        note = QLabel("The whole video: picture, original sound, AI voice and subtitles "
                      "together. The voices keep their pitch.")
        note.setObjectName("MutedLabel")
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addStretch(1)

    def _set(self, v: float):
        self.ins.edit("video", lambda p: setattr(p, "video_speed", round(v / 100.0, 2)))
        if self.ins.project is not None:
            self.show_duration(self.ins.project)

    def load(self, p: Project):
        self.speed.set_value(round(float(p.video_speed or 1.0) * 100))
        self.show_duration(p)

    def show_duration(self, p: Project):
        out = format_time(p.output_duration(), False)
        if abs(p.speed() - 1.0) > 0.001:
            self.duration.setText(f"Duration:  {out}   (was "
                                  f"{format_time(p.sequence_duration(), False)})")
        else:
            self.duration.setText(f"Duration:  {out}")


class AudioTab(QWidget):
    def __init__(self, ins: "Inspector"):
        super().__init__()
        self.stack = QStackedWidget()
        self.clip = ClipPage(ins)
        self.clip.show_tab(1)
        self.clip.tab_video.setVisible(False)
        self.clip.tab_audio.setVisible(False)
        self.eq, self.noise, self.fx = EqPage(ins), NoisePage(ins), EffectsPage(ins)
        for page in (self.clip, self.eq, self.noise, self.fx):
            self.stack.addWidget(page)
        for page in (self.eq, self.noise, self.fx):
            page.backRequested.connect(ins._back_to_clip)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 4, 0, 0)
        lay.addWidget(self.stack)


# --------------------------------------------------------------------------- #
class Inspector(QObject):
    """Owns the four tab pages; same signals as the Tools panel."""
    changing = Signal(str)
    changed = Signal(str)
    cropKeepAspect = Signal(bool)
    cropModeRequested = Signal(bool)
    voiceSpeedRequested = Signal(list, float)
    previewRequested = Signal(str)
    toolSwitchRequested = Signal(str)
    blackBarsRequested = Signal()
    reframeRequested = Signal()

    TABS = ("video", "audio", "speed", "color")
    NAMES = {"video": "🎬 Video", "audio": "🔊 Audio", "speed": "⏩ Speed", "color": "🎨 Color"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.project: Optional[Project] = None
        self.tool = ""
        self._last = ("", 0.0)
        self.video = VideoTab(self)
        self.audio = AudioTab(self)
        self.speed = SpeedTab(self)
        self.color = ColorPage(self)
        _hide_bar(self.color)
        self.color.views.setCurrentIndex(1)            # the sliders, like Filmora
        color_box = QWidget()
        cl = QVBoxLayout(color_box)
        cl.setContentsMargins(0, 6, 0, 0)
        cl.addWidget(_head("   Color"))
        cl.addWidget(self.color)
        cl.addStretch(1)
        self.widgets = {"video": _scroll(self.video), "audio": _scroll(self.audio),
                        "speed": _scroll(self.speed), "color": _scroll(color_box)}

    # ---- the Tools panel API the pages use
    def edit(self, kind: str, fn):
        if self.project is None:
            return
        now = time.time()
        if kind != self._last[0] or now - self._last[1] > UNDO_GAP:
            self.changing.emit(kind)
        self._last = (kind, now)
        fn(self.project)
        self.changed.emit(kind)

    def open_sub(self, key: str):
        a = self.audio
        page = {"eq": a.eq, "noise": a.noise, "effects": a.fx}[key]
        page.load(self.project, a.clip.track())
        a.stack.setCurrentWidget(page)

    def _back_to_clip(self):
        self.audio.clip.refresh_rows(self.project)
        self.audio.stack.setCurrentWidget(self.audio.clip)

    def switch_tool(self, tool: str):
        self.toolSwitchRequested.emit(tool)

    def close_tool(self):
        pass

    def crop_from_preview(self, l, t, r, b):
        def do(p):
            p.crop_left, p.crop_top, p.crop_right, p.crop_bottom = l, t, r, b
        self.edit("crop", do)
        self.video.show_crop(self.project)

    # ---- show a project
    def load(self, project: Project, voice=_KEEP):
        if voice is _KEEP:              # still the same clip, when it still exists
            old = self.audio.clip.target
            voice = next((c for c in list(project.audio_clips)
                          + list(getattr(project, "music_clips", []))
                          if old is not None and c.id == old.id), None)
        self.project = project
        self.video.load(project)
        self.speed.load(project)
        self.color.load(project)
        self.audio.clip.load(project, voice)
        self.audio.clip.show_tab(1)
