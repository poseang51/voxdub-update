"""
waveform.py - Real waveform rendering from audio samples.

Audio is reduced once to "peaks" (max absolute amplitude for every 5 ms).
Drawing then only needs one peak per screen pixel, so even long videos zoom
and scroll smoothly.
"""

import os
from typing import Dict, Optional, Tuple

import numpy as np
from PySide6.QtCore import QLineF, QRectF
from PySide6.QtGui import QColor, QPainter, QPen

from core.media import compute_peaks

PEAK_RATE = 200  # peaks per second (5 ms resolution)


class WaveformCache:
    """Computes and caches peak arrays per audio file."""

    def __init__(self):
        self._cache: Dict[Tuple[str, float], np.ndarray] = {}

    def peaks(self, path: str) -> Optional[np.ndarray]:
        if not path or not os.path.isfile(path):
            return None
        key = (path, os.path.getmtime(path))
        if key in self._cache:
            return self._cache[key]
        try:
            arr = compute_peaks(path, PEAK_RATE)
        except Exception:
            return None
        self._cache[key] = arr.astype(np.float32)
        return self._cache[key]


def draw_waveform(
    painter: QPainter,
    rect: QRectF,
    peaks: Optional[np.ndarray],
    src_in: float,
    src_out: float,
    color: QColor,
    visible_left: float = None,
    visible_right: float = None,
):
    """Draw peaks for the audio range src_in..src_out stretched over rect.

    visible_left/right (pixels) limit drawing to what is on screen.
    """
    if peaks is None or len(peaks) == 0 or rect.width() < 2 or src_out <= src_in:
        return
    x0 = int(max(rect.left(), visible_left if visible_left is not None else rect.left()))
    x1 = int(min(rect.right(), visible_right if visible_right is not None else rect.right()))
    if x1 <= x0:
        return

    sec_per_px = (src_out - src_in) / rect.width()
    xs = np.arange(x0, x1 + 1)
    t0 = src_in + (xs - rect.left()) * sec_per_px
    i0 = np.clip((t0 * PEAK_RATE).astype(np.int64), 0, len(peaks) - 1)
    i1 = np.clip(((t0 + sec_per_px) * PEAK_RATE).astype(np.int64) + 1, 1, len(peaks))
    i1 = np.maximum(i1, i0 + 1)

    if sec_per_px * PEAK_RATE <= 1.5:      # zoomed in: one peak per pixel
        vals = peaks[i0]
    else:                                   # zoomed out: max of the range
        # max of peaks[i0[k]:i0[k+1]] for every pixel k
        vals = np.maximum.reduceat(peaks, i0)
        vals[-1] = peaks[i0[-1]:i1[-1]].max()   # last pixel: limit to its own range

    mid = rect.center().y()
    half = rect.height() / 2 - 2
    lines = [
        QLineF(float(x), mid - float(v) * half, float(x), mid + float(v) * half + 0.5)
        for x, v in zip(xs, vals)
    ]
    painter.save()
    painter.setPen(QPen(color, 1))
    painter.drawLines(lines)
    painter.restore()
