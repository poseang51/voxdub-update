"""
appearance.py - Language (English / ខ្មែរ), colour and Light / Dark / Auto for
the whole app, without changing the screens themselves.

install(app) (main.py) does three things:

1. Language: every label, button, check box, group title, tab, menu, tooltip,
   placeholder, window title and message goes through core.i18n.tr() - when it
   is set by the code (setText ...) and when a window opens (its texts made in
   the constructor). The English text is kept on the widget, so switching the
   language back and forth works live.

2. Colour: one accent colour for the app (Default = the SARIKA teal + purple).
   Every style sheet - the app's and each widget's own - goes through adapt(),
   which moves the accent colours onto the chosen hue.

3. Light / Dark / Auto: Light is made from the dark style sheets (surfaces and
   text swap their lightness, colours stay readable). Auto follows Windows
   (Settings › Personalization › Colors) and changes when Windows changes.

Video, timeline and waveform pictures are painted, not styled: they stay dark
(like other video editors).
"""

import colorsys
import re
from functools import lru_cache
from typing import Dict, Optional

from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtGui import QAction, QColor, QGuiApplication, QPalette
from PySide6.QtWidgets import (
    QAbstractButton, QApplication, QComboBox, QFileDialog, QGroupBox, QInputDialog, QLabel,
    QLineEdit, QMenu, QMenuBar, QMessageBox, QPlainTextEdit, QProgressDialog, QStatusBar,
    QTableWidget, QTabWidget, QTextEdit, QWidget,
)

from core import i18n, settings

THEME_SETTING = "ui_theme"          # auto / dark / light
ACCENT_SETTING = "ui_accent"        # a key of ACCENTS
THEMES = {"auto": "Auto (like Windows)", "dark": "Dark", "light": "Light"}
ACCENTS: Dict[str, tuple] = {       # key: (name, colour)  ("" = keep the design colours)
    "default": ("SARIKA (teal + purple)", ""),
    "purple": ("Purple", "#7C5CFF"),
    "blue": ("Blue", "#3B82F6"),
    "teal": ("Teal", "#14B8A6"),
    "green": ("Green", "#22C55E"),
    "orange": ("Orange", "#F97316"),
    "pink": ("Pink", "#EC4899"),
    "red": ("Red", "#EF4444"),
}

_orig: Dict[str, object] = {}
_app_qss = [""]
_installed = [False]


# =========================================================================== #
# settings
# =========================================================================== #
def theme_choice() -> str:
    t = settings.get(THEME_SETTING, "auto") or "auto"
    return t if t in THEMES else "auto"


def accent_choice() -> str:
    a = settings.get(ACCENT_SETTING, "default") or "default"
    return a if a in ACCENTS else "default"


def system_is_dark() -> bool:
    try:
        scheme = QGuiApplication.styleHints().colorScheme()
        if scheme == Qt.ColorScheme.Light:
            return False
        if scheme == Qt.ColorScheme.Dark:
            return True
    except Exception:
        pass
    return True                      # unknown: the app's own (dark) look


def mode() -> str:
    """dark / light now (Auto resolved)."""
    t = theme_choice()
    if t == "auto":
        return "dark" if system_is_dark() else "light"
    return t


# =========================================================================== #
# colours
# =========================================================================== #
_COLOR = re.compile(r"#(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b|rgba?\(\s*\d+\s*,\s*\d+\s*,\s*\d+"
                    r"(?:\s*,\s*[\d.]+)?\s*\)")


def _parse(c: str):
    if c.startswith("#"):
        h = c[1:]
        if len(h) == 3:
            h = "".join(x * 2 for x in h)
        return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)), None
    nums = re.findall(r"[\d.]+", c)
    rgb = tuple(int(n) / 255 for n in nums[:3])
    return rgb, (nums[3] if len(nums) > 3 else None)


def _fmt(rgb, alpha, was_hex: bool) -> str:
    r, g, b = (max(0, min(255, round(v * 255))) for v in rgb)
    if was_hex and alpha is None:
        return f"#{r:02X}{g:02X}{b:02X}"
    return f"rgba({r},{g},{b},{alpha})" if alpha is not None else f"rgb({r},{g},{b})"


def _accent_hue(key: str) -> Optional[float]:
    col = ACCENTS.get(key, ("", ""))[1]
    if not col:
        return None
    (r, g, b), _ = _parse(col)
    return colorsys.rgb_to_hls(r, g, b)[0]


def colour(rgb, light: bool, hue: Optional[float]):
    """One colour of a dark style sheet -> the chosen accent / light mode."""
    r, g, b = rgb
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    chroma = max(rgb) - min(rgb)
    deg = h * 360
    if hue is not None and chroma > 0.30 and (160 <= deg <= 190 or 215 <= deg <= 295):
        h = hue                                      # teal / blue / violet -> the accent
    if light:
        if chroma < 0.18 or l < 0.22:                # surfaces, borders, text
            l = min(0.975, max(0.10, (1 - l) * 1.04))
            s = s * (0.55 if chroma < 0.18 else 0.8)
        elif l < 0.45 and chroma < 0.55:             # dark coloured surface -> pastel
            l = 0.86                                 # (strong colours - buttons - stay)
        elif l > 0.6:                                # light coloured text -> deeper
            l = max(0.30, l - 0.36)
    return colorsys.hls_to_rgb(h, l, s)


@lru_cache(maxsize=4096)
def _adapt(qss: str, light: bool, accent: str) -> str:
    hue = _accent_hue(accent)
    if not light and hue is None:
        return qss

    def sub(m):
        c = m.group(0)
        rgb, alpha = _parse(c)
        return _fmt(colour(rgb, light, hue), alpha, c.startswith("#"))
    return _COLOR.sub(sub, qss)


def adapt(qss: str) -> str:
    """A (dark) style sheet in the chosen colour and light / dark."""
    if not qss:
        return qss
    return _adapt(qss, mode() == "light", accent_choice())


def qcolor(color: str) -> QColor:
    """For painting code that wants to follow the theme."""
    rgb, _ = _parse(color)
    return QColor(_fmt(colour(rgb, mode() == "light", _accent_hue(accent_choice())),
                       None, True))


def _palette(light: bool) -> QPalette:
    p = QPalette()
    base = {"window": "#0B1120", "base": "#111827", "text": "#F1F5F9", "button": "#1E293B",
            "hl": "#14B8A6"}
    if light:
        base = {"window": "#F4F6FB", "base": "#FFFFFF", "text": "#1A1F36",
                "button": "#E8ECF6", "hl": "#5B6BFF"}
    for role, key in ((QPalette.ColorRole.Window, "window"), (QPalette.ColorRole.Base, "base"),
                      (QPalette.ColorRole.AlternateBase, "button"),
                      (QPalette.ColorRole.Button, "button"),
                      (QPalette.ColorRole.Text, "text"), (QPalette.ColorRole.WindowText, "text"),
                      (QPalette.ColorRole.ButtonText, "text"),
                      (QPalette.ColorRole.ToolTipText, "text"),
                      (QPalette.ColorRole.ToolTipBase, "base"),
                      (QPalette.ColorRole.Highlight, "hl")):
        p.setColor(role, QColor(base[key]))
    return p


def apply_theme() -> None:
    """Set the colours again on every window (after a change)."""
    app = QApplication.instance()
    if app is None:
        return
    app.setPalette(_palette(mode() == "light"))
    if _app_qss[0]:
        _orig["app_qss"](app, adapt(_app_qss[0]))
    for w in app.allWidgets():
        src = w.property("_qss_src")
        if src:
            _orig["qss"](w, adapt(src))


# =========================================================================== #
# language
# =========================================================================== #
def _keep(obj, field: str, src: str, out: str):
    try:
        obj.setProperty("_en_" + field, src)
        obj.setProperty("_tr_" + field, out)
    except RuntimeError:
        pass


def _source(obj, field: str, cur: str) -> str:
    """The English text of a field (cur when the app changed it meanwhile)."""
    try:
        out = obj.property("_tr_" + field)
        src = obj.property("_en_" + field)
    except RuntimeError:
        return cur
    return src if (src is not None and out == cur) else cur


_FIELDS = [
    (QLabel, "text", "text", "setText"),
    (QAbstractButton, "text", "text", "setText"),
    (QGroupBox, "title", "title", "setTitle"),
    (QLineEdit, "placeholder", "placeholderText", "setPlaceholderText"),
    (QPlainTextEdit, "placeholder", "placeholderText", "setPlaceholderText"),
    (QTextEdit, "placeholder", "placeholderText", "setPlaceholderText"),
    (QMenu, "title", "title", "setTitle"),
    (QWidget, "tip", "toolTip", "setToolTip"),
    (QWidget, "wtitle", "windowTitle", "setWindowTitle"),
]


def _set_field(obj, field: str, getter: str, setter: str):
    cur = getattr(obj, getter)()
    if not cur:
        return
    src = _source(obj, field, cur)
    out = i18n.tr(src)
    if out != cur:
        fn = _orig.get(f"{type(obj).__name__}.{setter}") or _orig_for(obj, setter)
        fn(obj, out)
    _keep(obj, field, src, out)


def _orig_for(obj, setter: str):
    for cls in type(obj).__mro__:
        f = _orig.get(f"{cls.__name__}.{setter}")
        if f is not None:
            return f
    return getattr(type(obj), setter)


def translate(obj) -> None:
    """Translate one widget / action (its own texts, tabs, items, header)."""
    try:
        if isinstance(obj, QAction):
            for field, getter, setter in (("text", "text", "setText"),
                                          ("tip", "toolTip", "setToolTip")):
                cur = getattr(obj, getter)()
                if cur and not (field == "tip" and cur.replace("&", "") ==
                                obj.text().replace("&", "")):
                    _set_field(obj, field, getter, setter)
            return
        for cls, field, getter, setter in _FIELDS:
            if isinstance(obj, cls):
                if field == "wtitle" and not obj.isWindow():
                    continue
                _set_field(obj, field, getter, setter)
        if isinstance(obj, QTabWidget):
            _list(obj, "_tabs", obj.count(), obj.tabText,
                  lambda i, t: _orig["QTabWidget.setTabText"](obj, i, t))
        elif isinstance(obj, QComboBox):
            _list(obj, "_items", obj.count(), obj.itemText,
                  lambda i, t: _orig["QComboBox.setItemText"](obj, i, t))
        elif isinstance(obj, QTableWidget):
            n = obj.columnCount()
            _list(obj, "_heads", n,
                  lambda i: obj.horizontalHeaderItem(i).text() if obj.horizontalHeaderItem(i)
                  else "", lambda i, t: obj.horizontalHeaderItem(i).setText(t))
        if isinstance(obj, (QMenu, QMenuBar)):
            for a in obj.actions():
                translate(a)
                if a.menu() is not None:
                    translate(a.menu())
    except RuntimeError:
        pass                                          # the widget was just deleted


def _list(obj, name: str, n: int, get, put):
    """Tabs / combo items / table headers: the English texts kept as a list."""
    src = obj.property("_en" + name) or []
    out = obj.property("_tr" + name) or []
    new_src, new_out = [], []
    for i in range(n):
        cur = get(i)
        s = src[i] if i < len(src) and i < len(out) and out[i] == cur and src[i] is not None \
            else cur
        t = i18n.tr(s)
        if t != cur:
            put(i, t)
        new_src.append(s)
        new_out.append(t)
    obj.setProperty("_en" + name, new_src)
    obj.setProperty("_tr" + name, new_out)


def retranslate_all() -> None:
    app = QApplication.instance()
    if app is None:
        return
    for w in app.allWidgets():
        translate(w)
        for a in w.actions():
            translate(a)
        fn = getattr(w, "retranslate", None)        # widgets that draw their own text
        if callable(fn):
            try:
                fn()
            except Exception:
                pass


class _Watcher(QObject):
    """A widget shown for the first time: its texts are translated."""

    def eventFilter(self, obj, ev):
        if ev.type() == QEvent.Type.Show and isinstance(obj, QWidget):
            if i18n.language() != "en" or obj.property("_en_text") is not None:
                translate(obj)
                if isinstance(obj, QMenu):
                    for a in obj.actions():
                        translate(a)
        return False


# =========================================================================== #
# install: the Qt setters go through tr() / adapt()
# =========================================================================== #
def _wrap_text(cls, name: str, field: str):
    orig = getattr(cls, name)
    _orig[f"{cls.__name__}.{name}"] = orig

    def setter(self, text, *a):
        if isinstance(text, str):
            out = i18n.tr(text)
            orig(self, out, *a)
            _keep(self, field, text, out)
        else:
            orig(self, text, *a)
    setattr(cls, name, setter)


def english_tab(tabs, i: int) -> str:
    """The English text of a tab (whatever the language shown)."""
    src = tabs.property("_en_tabs") or []
    out = tabs.property("_tr_tabs") or []
    cur = tabs.tabText(i)
    return src[i] if i < len(src) and i < len(out) and out[i] == cur else cur


def _remember(obj, name: str, i: int, src: str, out: str, insert: bool):
    """Keep the English text of tab / item i (so the language can change back)."""
    if i is None or i < 0:
        return
    s = list(obj.property("_en" + name) or [])
    t = list(obj.property("_tr" + name) or [])
    n = obj.count()
    while len(s) < n - (1 if insert else 0):
        s.append(None)
        t.append(None)
    if insert:
        s.insert(i, src)
        t.insert(i, out)
    else:
        while len(s) <= i:
            s.append(None)
            t.append(None)
        s[i], t[i] = src, out
    obj.setProperty("_en" + name, s[:n])
    obj.setProperty("_tr" + name, t[:n])


def _wrap_index(cls, name: str, pos: int):
    """addTab(widget, text) / setTabText(i, text) / addItem(text, data) ..."""
    orig = getattr(cls, name)
    _orig[f"{cls.__name__}.{name}"] = orig
    kind = "_tabs" if cls is QTabWidget else "_items" if cls is QComboBox else ""

    def fn(self, *a, **k):
        a = list(a)
        src = out = None
        for p in (pos, pos + 1):                     # (icon, text) forms
            if p < len(a) and isinstance(a[p], str):
                src = a[p]
                out = a[p] = i18n.tr(a[p])
                break
        res = orig(self, *a, **k)
        if kind and src is not None:
            try:
                if name in ("addTab", "addItem"):
                    i = res if isinstance(res, int) else self.count() - 1
                    _remember(self, kind, i, src, out, True)
                elif name in ("insertTab", "insertItem"):
                    i = res if isinstance(res, int) else int(a[0])
                    _remember(self, kind, i, src, out, True)
                else:
                    _remember(self, kind, int(a[0]), src, out, False)
            except (RuntimeError, TypeError, ValueError):
                pass
        return res
    setattr(cls, name, fn)


def _wrap_static(cls, name: str, idx=(1, 2)):
    orig = getattr(cls, name)
    _orig[f"{cls.__name__}.{name}"] = orig

    def fn(*a, **k):
        a = list(a)
        for i in idx:
            if i < len(a) and isinstance(a[i], str):
                a[i] = i18n.tr(a[i])
        return orig(*a, **k)
    setattr(cls, name, staticmethod(fn))


def install(app: QApplication) -> None:
    if _installed[0]:
        return
    _installed[0] = True
    for cls, name, field in ((QLabel, "setText", "text"), (QAbstractButton, "setText", "text"),
                             (QGroupBox, "setTitle", "title"),
                             (QLineEdit, "setPlaceholderText", "placeholder"),
                             (QPlainTextEdit, "setPlaceholderText", "placeholder"),
                             (QTextEdit, "setPlaceholderText", "placeholder"),
                             (QWidget, "setToolTip", "tip"),
                             (QWidget, "setWindowTitle", "wtitle"),
                             (QMenu, "setTitle", "title"),
                             (QAction, "setText", "text"), (QAction, "setToolTip", "tip"),
                             (QProgressDialog, "setLabelText", "text"),
                             (QMessageBox, "setText", "text"),
                             (QMessageBox, "setInformativeText", "info")):
        _wrap_text(cls, name, field)
    _wrap_index(QTabWidget, "addTab", 1)
    _wrap_index(QTabWidget, "insertTab", 2)
    _wrap_index(QTabWidget, "setTabText", 1)
    _wrap_index(QComboBox, "addItem", 0)
    _wrap_index(QComboBox, "insertItem", 1)
    _wrap_index(QComboBox, "setItemText", 1)
    _wrap_index(QMenu, "addMenu", 0)
    _wrap_index(QMenu, "addAction", 0)
    _wrap_index(QMenuBar, "addMenu", 0)
    _wrap_index(QStatusBar, "showMessage", 0)
    for name in ("information", "warning", "question", "critical"):
        _wrap_static(QMessageBox, name)
    _wrap_static(QInputDialog, "getText")
    _wrap_static(QInputDialog, "getItem")
    for name in ("getOpenFileName", "getOpenFileNames", "getSaveFileName",
                 "getExistingDirectory"):
        _wrap_static(QFileDialog, name, (1,))

    # style sheets: the chosen colour / light-dark
    orig_qss = QWidget.setStyleSheet
    _orig["qss"] = orig_qss

    def set_qss(self, qss):
        try:
            self.setProperty("_qss_src", qss or "")
        except RuntimeError:
            pass
        orig_qss(self, adapt(qss) if qss else qss)
    QWidget.setStyleSheet = set_qss

    orig_app = QApplication.setStyleSheet
    _orig["app_qss"] = orig_app

    def set_app_qss(self, qss):
        _app_qss[0] = qss or ""
        orig_app(self, adapt(qss) if qss else qss)
    QApplication.setStyleSheet = set_app_qss

    app.setPalette(_palette(mode() == "light"))
    w = _Watcher(app)
    app.installEventFilter(w)
    app._voxdub_watcher = w
    try:
        QGuiApplication.styleHints().colorSchemeChanged.connect(
            lambda *_: theme_choice() == "auto" and apply_theme())
    except Exception:
        pass


def set_language(lang: str) -> None:
    i18n.set_language(lang)
    retranslate_all()


def set_theme(theme: str) -> None:
    settings.set(THEME_SETTING, theme if theme in THEMES else "auto")
    apply_theme()


def set_accent(key: str) -> None:
    settings.set(ACCENT_SETTING, key if key in ACCENTS else "default")
    apply_theme()
