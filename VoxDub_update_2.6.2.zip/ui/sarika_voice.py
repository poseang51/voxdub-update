"""
sarika_voice.py - Owner-only bridge to SARIKA VOICE (the separate web app in
D:\\sarika_voice: Voice Library, Text-To-Speech, Story Studio, BGM & SFX).

Shown only on the owner's PC (core.admin.is_owner()). Customers never see it,
and nothing here is imported by the rest of the app.

* Starts the SARIKA VOICE server (npm start) if it is not already running, and
  stops it again when VoxDub closes - only if VoxDub was the one that started it.
* Shows the app inside a VoxDub window when Qt WebEngine is available (running
  from source); otherwise opens it in the default browser.
* "Use in VoxDub" puts a SARIKA VOICE audio file on the timeline as a music
  track (main_window.add_music).

Qt WebEngine is imported by name at run time (importlib), so PyInstaller never
bundles it into the customer .exe.
"""

import glob
import importlib
import json
import os
import subprocess
import sys
import urllib.request

from PySide6.QtCore import QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QFileDialog, QHBoxLayout, QLabel, QMainWindow, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from core import settings

DEFAULT_DIR = r"D:\sarika_voice"
_server = None          # the npm process VoxDub started (None = not ours)


# --------------------------------------------------------------------------- #
# server helpers
# --------------------------------------------------------------------------- #
def app_dir() -> str:
    return settings.get("sarika_voice_dir") or DEFAULT_DIR


def is_app_dir(path: str) -> bool:
    return bool(path) and os.path.isfile(os.path.join(path, "package.json")) and \
        os.path.isdir(os.path.join(path, "server"))


def port(path: str) -> int:
    try:
        with open(os.path.join(path, ".env"), "r", encoding="utf-8") as f:
            for line in f:
                if line.startswith("PORT="):
                    return int(line.split("=", 1)[1].strip() or 5177)
    except (OSError, ValueError):
        pass
    return 5177


def base_url(path: str) -> str:
    return f"http://127.0.0.1:{port(path)}"


def health(path: str, timeout: float = 1.5):
    try:
        with urllib.request.urlopen(base_url(path) + "/api/health", timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception:
        return None


def start_server(path: str) -> str:
    """Start `npm start` in the SARIKA VOICE folder. Returns '' or an error."""
    global _server
    if _server and _server.poll() is None:
        return ""
    if not os.path.isdir(os.path.join(path, "node_modules")):
        return "SARIKA VOICE មិនទាន់ install — ចុច install.bat ក្នុង " + path
    log = open(os.path.join(path, "data", "server.log") if os.path.isdir(os.path.join(path, "data"))
               else os.path.join(path, "server.log"), "a", encoding="utf-8", errors="replace")
    flags = 0x08000000 if sys.platform == "win32" else 0      # CREATE_NO_WINDOW
    try:
        _server = subprocess.Popen("npm start", cwd=path, shell=True, stdout=log, stderr=log,
                                   stdin=subprocess.DEVNULL, creationflags=flags,
                                   start_new_session=sys.platform != "win32")
    except OSError as e:
        return f"Cannot start SARIKA VOICE: {e}"
    return ""


def stop_server():
    """Stop the server only if VoxDub started it (kills the whole npm → node tree)."""
    global _server
    p, _server = _server, None
    if not p or p.poll() is not None:
        return
    try:
        if sys.platform == "win32":
            subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10,
                           creationflags=0x08000000)
        else:
            import signal
            os.killpg(p.pid, signal.SIGTERM)
    except Exception:
        pass


def file_from_url(path: str, url: str) -> str:
    """'/files/outputs/x.wav' → D:\\sarika_voice\\data\\outputs\\x.wav"""
    rel = url.split("/files/", 1)[-1]
    return os.path.normpath(os.path.join(path, "data", *rel.split("/")))


def latest_audio(path: str) -> str:
    """Newest finished audio: TTS history, mixes or story audio."""
    files = []
    for pat in ("outputs/**/*.wav", "outputs/**/*.mp3", "stories/*/story_*.wav"):
        files += glob.glob(os.path.join(path, "data", pat), recursive=True)
    files = [f for f in files if not f.endswith("_raw.wav")]
    return max(files, key=os.path.getmtime) if files else ""


# --------------------------------------------------------------------------- #
# window
# --------------------------------------------------------------------------- #
class SarikaVoiceWindow(QMainWindow):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.path = app_dir()
        self.web = None
        self._tries = 0
        self.setWindowTitle("SARIKA VOICE — Voice · Story Studio")
        self.resize(1500, 950)

        top = QWidget()
        bar = QHBoxLayout(top)
        bar.setContentsMargins(10, 6, 10, 6)
        self.status = QLabel("…")
        bar.addWidget(self.status, 1)
        b_use = QPushButton("🎵  Use latest audio in VoxDub")
        b_use.setToolTip("ដាក់សំឡេងចុងក្រោយពី SARIKA VOICE ចូល Timeline ជា music track")
        b_use.clicked.connect(self.use_latest)
        b_pick = QPushButton("📂  Choose audio…")
        b_pick.clicked.connect(self.use_pick)
        b_browser = QPushButton("🌐  Open in browser")
        b_browser.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(base_url(self.path))))
        b_folder = QPushButton("⚙  Folder…")
        b_folder.clicked.connect(self.choose_folder)
        for b in (b_use, b_pick, b_browser, b_folder):
            bar.addWidget(b)

        self.body = QWidget()
        self.body_lay = QVBoxLayout(self.body)
        self.body_lay.setContentsMargins(0, 0, 0, 0)
        self.msg = QLabel("")
        self.msg.setWordWrap(True)
        self.msg.setStyleSheet("padding:40px;font-size:15px;")
        self.body_lay.addWidget(self.msg)

        root = QWidget()
        lay = QVBoxLayout(root)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(top)
        lay.addWidget(self.body, 1)
        self.setCentralWidget(root)

        self.timer = QTimer(self)
        self.timer.setInterval(1500)
        self.timer.timeout.connect(self._poll)
        QTimer.singleShot(0, self.connect_app)

    # -- start / connect ---------------------------------------------------- #
    def connect_app(self):
        if not is_app_dir(self.path):
            self._say(f"រកមិនឃើញ SARIKA VOICE នៅ {self.path} — ចុច ⚙ Folder… ដើម្បីជ្រើស")
            return
        if health(self.path):
            self._show_app()
            return
        err = start_server(self.path)
        if err:
            self._say(err)
            return
        self._tries = 0
        self._say("⏳ កំពុងបើក SARIKA VOICE server…")
        self.timer.start()

    def _poll(self):
        self._tries += 1
        if health(self.path):
            self.timer.stop()
            self._show_app()
        elif self._tries > 60:          # ~90 s
            self.timer.stop()
            self._say("SARIKA VOICE មិនឆ្លើយតប — មើល data\\server.log ក្នុង " + self.path)
        else:
            self._say(f"⏳ កំពុងបើក SARIKA VOICE server… {int(self._tries * 1.5)}s")

    def _show_app(self):
        h = health(self.path) or {}
        self.status.setText(f"● {base_url(self.path)}   ·   VoxCPM2: {h.get('voxcpm', '?')}"
                            f"   ·   Gemini keys: {h.get('geminiKeys', 0)}")
        url = QUrl(base_url(self.path))
        if self.web is None:
            try:
                mod = importlib.import_module("PySide6.QtWebEngineWidgets")
                self.web = mod.QWebEngineView(self)
                self.msg.hide()
                self.body_lay.addWidget(self.web)
            except Exception:
                self.web = False
        if self.web:
            self.web.setUrl(url)
        else:
            QDesktopServices.openUrl(url)
            self._say("បានបើក SARIKA VOICE ក្នុង browser ហើយ។\n"
                      "(ការបង្ហាញក្នុង VoxDub ត្រូវការ Qt WebEngine — មានពេលដំណើរការពី source)")

    def _say(self, text: str):
        self.status.setText(text.splitlines()[0])
        if not self.web:
            self.msg.setText(text)

    def choose_folder(self):
        d = QFileDialog.getExistingDirectory(self, "SARIKA VOICE folder", self.path)
        if not d:
            return
        if not is_app_dir(d):
            QMessageBox.warning(self, "SARIKA VOICE", "Folder នេះមិនមែន SARIKA VOICE ទេ (រកមិនឃើញ package.json / server)។")
            return
        settings.set("sarika_voice_dir", d)
        self.path = d
        self.connect_app()

    # -- bring audio into VoxDub ------------------------------------------- #
    def _use(self, f: str):
        if not f or not os.path.isfile(f):
            QMessageBox.information(self, "SARIKA VOICE", "មិនទាន់មានសំឡេងដែលបានបង្កើតទេ។")
            return
        if not self.main._require_video():
            return
        self.main.add_music(f)
        self.main.log(f"SARIKA VOICE audio → timeline: {f}")
        self.main.raise_()
        self.main.activateWindow()

    def use_latest(self):
        self._use(latest_audio(self.path))

    def use_pick(self):
        start = os.path.join(self.path, "data")
        f, _ = QFileDialog.getOpenFileName(self, "SARIKA VOICE audio", start, "Audio (*.wav *.mp3)")
        if f:
            self._use(f)
