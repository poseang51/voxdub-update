"""
recap_dialog.py - 🎬 AI Recap (2.5 preview), laid out like the SARIKA design:

  left                                         right
  ┌ AI Recap – សង្ខេបរឿងតាម AI (banner) ┐     ┌ ▣ Preview (video, subtitle, controls) ┐
  ① Upload & Analyze  (file / YouTube / link /  ├ Recap Script · Timestamps · AI Summary ┤
                       folder, info, ✨ Analyze) ├ Recap Quality Score (ring + checks)    ┤
  ② AI Story Intelligence (characters, plot,    └ Recap Library                          ┘
                       scenes, script)
  ③ Customize Recap Style (style, narrator, emotion, speed, music, ▶ Preview Recap)
  ④ Generate & Edit (Script · Timeline · Scenes · Subtitles · Story + Key Scenes)
  ⑤ Export (MP4 / MP3 / WAV, resolution, watermark)
"""

import os
import re
from typing import List, Optional

from PySide6.QtCore import QRectF, QSize, Qt, QUrl
from PySide6.QtGui import QColor, QConicalGradient, QFont, QIcon, QLinearGradient, QPainter, \
    QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame,
    QGridLayout, QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton, QScrollArea,
    QSlider, QSpinBox, QTableWidget, QTableWidgetItem, QTabWidget, QTextBrowser, QVBoxLayout,
    QWidget,
)

from core import recap, settings
from core.media import VIDEO_EXT
from ui.workers import TaskWorker

KIND_LABEL = {"narration": "🗣", "hook": "🎣", "original": "🎭"}
VOICES = [("edge", "km-KH-PisethNeural", "Piseth (Male)"),
          ("edge", "km-KH-SreymomNeural", "Sreymom (Female)")]
SOURCES = [("auto", "Auto detect"), ("zh", "Chinese (中文)"), ("en", "English"),
           ("ko", "Korean"), ("ja", "Japanese"), ("th", "Thai"), ("km", "Khmer")]
TARGETS = [("km", "Khmer (ខ្មែរ)"), ("en", "English"), ("th", "Thai")]
STYLE_ICON = {"normal": "🎬", "comedy": "😂", "emotional": "💧", "legend": "🏯",
              "exciting": "⚔"}
FORMATS = [("mp4", "🎞  MP4", "(Recommended)"), ("mp3", "🎵  MP3", "(Audio Only)"),
           ("wav", "🔊  WAV", "(High Quality)")]
RESOLUTIONS = [(720, "720p (HD)"), (1080, "1080p (Full HD)"), (2160, "2160p (4K)")]
RATES = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]

QSS = """
QDialog#Recap { background: #0a0e27; }
QDialog#Recap QWidget { color: #e8eaff; }
QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }
QFrame#RCard { background: #10163a; border: 1px solid #262d6b; border-radius: 14px; }
QFrame#RInner { background: #0c1131; border: 1px solid #232a63; border-radius: 10px; }
QFrame#RBanner { border-radius: 16px; border: 1px solid #3a3fa0;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #161a52, stop:0.6 #23207a,
                                stop:1 #3a1f86); }
QLabel#RTitle { font-size: 26px; font-weight: 800; color: white; }
QLabel#RNew { background: #7c5cff; color: white; border-radius: 8px; padding: 1px 9px;
    font-weight: 800; font-size: 11px; }
QLabel#RSub { color: #d6dcff; font-size: 14px; }
QLabel#RHead { font-size: 16px; font-weight: 700; color: white; }
QLabel#RNum { background: #6d4dff; color: white; border-radius: 15px; font-weight: 800;
    font-size: 15px; min-width: 30px; max-width: 30px; min-height: 30px; max-height: 30px; }
QLabel#RMuted { color: #9aa3cf; font-size: 12px; }
QLabel#RSmall { color: #c3c8ee; font-size: 12px; }
QLabel#RPill { background: #3b2a9a; color: white; border-radius: 10px; padding: 2px 12px;
    font-size: 11px; font-weight: 700; }
QLabel#RPillOn { background: #14805a; color: white; border-radius: 10px; padding: 2px 12px;
    font-size: 11px; font-weight: 700; }
QFrame#RDrop { border: 2px dashed #3d4a9a; border-radius: 12px; background: #0c1131; }
QPushButton { background: #18205a; border: 1px solid #2c3580; border-radius: 8px;
    padding: 6px 12px; }
QPushButton:hover { border-color: #8a6bff; }
QPushButton:disabled { color: #6b7199; }
QPushButton#RTab { padding: 6px 14px; background: #141b4c; }
QPushButton#RTab:checked { background: #3d5bff; border-color: #5c78ff; color: white; }
QPushButton#RFeature { text-align: left; padding: 12px 14px; background: #0c1131;
    border: 1px solid #262d6b; border-radius: 12px; font-size: 13px; }
QPushButton#RFeature:hover { border-color: #8a6bff; }
QPushButton#RFormat { padding: 8px 6px; background: #0c1131; border-radius: 10px; }
QPushButton#RFormat:checked { background: #2a1f7a; border: 2px solid #8a6bff; }
QPushButton#RStart, QPushButton#RAccent { color: white; border: none; border-radius: 10px;
    font-weight: 800; padding: 10px 18px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #5b4dff, stop:1 #9b5cff); }
QPushButton#RStart { font-size: 15px; padding: 12px 18px; }
QPushButton#RStart:disabled, QPushButton#RAccent:disabled { background: #2a3160;
    color: #8890aa; }
QPushButton#RIcon { background: transparent; border: none; font-size: 18px; padding: 2px 6px; }
QPushButton#RIcon:hover { color: #b9a6ff; }
QComboBox, QLineEdit, QSpinBox { background: #0c1131; border: 1px solid #2c3580;
    border-radius: 8px; padding: 6px 8px; }
QTabWidget::pane { border: 1px solid #262d6b; border-radius: 10px; background: #0c1131;
    top: -1px; }
QTabBar::tab { background: transparent; color: #aab2e0; padding: 7px 16px; border: none; }
QTabBar::tab:selected { background: #3d5bff; color: white; border-radius: 8px; }
QTableWidget, QListWidget, QPlainTextEdit, QTextBrowser { background: #0c1131;
    border: none; gridline-color: #1d2456; selection-background-color: #2f2a8a; }
QHeaderView::section { background: #10163a; color: #9aa3cf; border: none; padding: 4px; }
QProgressBar { background: #1a2050; border: none; border-radius: 3px; max-height: 6px; }
QProgressBar::chunk { border-radius: 3px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #5b4dff, stop:1 #c35cff); }
QSlider::groove:horizontal { height: 4px; background: #2a3168; border-radius: 2px; }
QSlider::sub-page:horizontal { background: #6d6bff; border-radius: 2px; }
QSlider::handle:horizontal { background: white; border: 3px solid #6d6bff; width: 10px;
    height: 10px; margin: -6px 0; border-radius: 8px; }
QCheckBox::indicator { width: 16px; height: 16px; border-radius: 4px;
    border: 1px solid #3a4590; background: #0c1131; }
QCheckBox::indicator:checked { background: #18b67a; border-color: #18b67a; }
QCheckBox#RSwitch::indicator { width: 34px; height: 18px; border-radius: 9px;
    background: #2a3168; }
QCheckBox#RSwitch::indicator:checked { background: #5b6bff; }
QLabel#RSubtitle { background: rgba(0,0,0,0.55); color: white; font-size: 16px;
    font-weight: 700; padding: 6px 10px; border-radius: 6px; }
"""


def _mmss(t: float) -> str:
    t = max(0.0, float(t))
    return f"{int(t // 60):02d}:{t % 60:04.1f}"


def _clock(t: float) -> str:
    t = max(0, int(t))
    return f"{t // 60:02d}:{t % 60:02d}"


def clips_text(clips) -> str:
    return "; ".join(f"v{int(v)} {_mmss(s)}-{_mmss(e)}" for v, s, e in clips)


def parse_clips(text: str) -> List[List[float]]:
    out = []
    for part in re.split(r"[;\n]+", text or ""):
        m = re.match(r"\s*v?(\d+)\s+([\d:.]+)\s*-\s*([\d:.]+)\s*$", part)
        if m:
            s, e = recap._secs(m.group(2)), recap._secs(m.group(3))
            if e > s:
                out.append([int(m.group(1)), round(s, 2), round(e, 2)])
    return out


def _speed_x(v: int) -> str:
    return f"{1 + v / 100:.2f}".rstrip("0").rstrip(".") + "x" if v else "1.0x"


def _grade(total: int) -> str:
    return "Excellent" if total >= 85 else "Good" if total >= 70 else \
        "Fair" if total >= 50 else "Needs work"


def card(title: str, num: str = ""):
    fr = QFrame()
    fr.setObjectName("RCard")
    lay = QVBoxLayout(fr)
    lay.setContentsMargins(16, 12, 16, 14)
    lay.setSpacing(10)
    head = QHBoxLayout()
    head.setSpacing(10)
    if num:
        n = QLabel(num)
        n.setObjectName("RNum")
        n.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.addWidget(n)
    t = QLabel(title)
    t.setObjectName("RHead")
    head.addWidget(t)
    head.addStretch(1)
    lay.addLayout(head)
    return fr, lay, head


def _label(text: str, name: str = "RMuted") -> QLabel:
    lb = QLabel(text)
    lb.setObjectName(name)
    return lb


def _hero_pixmap(pics: List[str], w: int = 420, h: int = 140) -> QPixmap:
    """The banner picture: frames of the story (or a gradient) + ▶."""
    pm = QPixmap(w, h)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    g = QLinearGradient(0, 0, w, h)
    g.setColorAt(0, QColor("#2b2380"))
    g.setColorAt(1, QColor("#7a3fd0"))
    p.setBrush(g)
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(0, 0, w, h, 14, 14)
    pics = [x for x in pics if x and os.path.isfile(x)][:3]
    if pics:
        cw = w // len(pics)
        for k, pic in enumerate(pics):
            img = QPixmap(pic).scaled(QSize(cw, h), Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                      Qt.TransformationMode.SmoothTransformation)
            p.drawPixmap(k * cw, 0, img, (img.width() - cw) // 2, (img.height() - h) // 2, cw, h)
        shade = QLinearGradient(0, 0, 0, h)
        shade.setColorAt(0, QColor(10, 14, 39, 40))
        shade.setColorAt(1, QColor(10, 14, 39, 190))
        p.setBrush(shade)
        p.drawRect(0, 0, w, h)
    p.setBrush(QColor(124, 92, 255, 230))
    p.drawEllipse(QRectF(w / 2 - 26, h / 2 - 30, 52, 52))
    p.setBrush(QColor("white"))
    from PySide6.QtGui import QPolygonF
    from PySide6.QtCore import QPointF
    cx, cy = w / 2 + 3, h / 2 - 4
    p.drawPolygon(QPolygonF([QPointF(cx - 8, cy - 12), QPointF(cx - 8, cy + 12),
                             QPointF(cx + 12, cy)]))
    f = QFont()
    f.setPixelSize(17)
    f.setBold(True)
    p.setFont(f)
    p.setPen(QColor("white"))
    p.drawText(QRectF(0, h - 34, w - 14, 26), Qt.AlignmentFlag.AlignRight, "សង្ខេបរឿងនេះ ▸")
    p.end()
    return pm


class ScoreRing(QWidget):
    """Recap Quality Score: a ring 0-100."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.value: Optional[int] = None
        self.setFixedSize(130, 130)

    def set_value(self, v: Optional[int]):
        self.value = v
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(10, 10, 110, 110)
        p.setPen(QPen(QColor("#222a63"), 11, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.drawArc(rect, 0, 360 * 16)
        if self.value is not None:
            g = QConicalGradient(rect.center(), 90)
            g.setColorAt(0, QColor("#26d0a0"))
            g.setColorAt(0.5, QColor("#5b6bff"))
            g.setColorAt(1, QColor("#b35cff"))
            p.setPen(QPen(g, 11, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawArc(rect, 90 * 16, -int(360 * 16 * max(0, min(100, self.value)) / 100))
        f = QFont()
        f.setPixelSize(34)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("white"))
        txt = "–" if self.value is None else str(self.value)
        p.drawText(QRectF(0, 30, 130, 50), Qt.AlignmentFlag.AlignCenter, txt)
        f.setPixelSize(12)
        f.setBold(False)
        p.setFont(f)
        p.setPen(QColor("#9aa3cf"))
        p.drawText(QRectF(0, 72, 130, 20), Qt.AlignmentFlag.AlignCenter,
                   "/100" if self.value is not None else "")
        p.end()


class RecapDialog(QDialog):
    def __init__(self, parent=None, videos: Optional[List[str]] = None):
        super().__init__(parent)
        self.setObjectName("Recap")
        self.setStyleSheet(QSS)
        self.setWindowTitle("SARIKA VOXDUB PRO – 🎬 AI Recap")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(1560, 980)
        self.r: Optional[recap.Recap] = None
        self.worker: Optional[TaskWorker] = None
        self.player = self.voice_player = self.video = None
        self._clip_end = 0.0
        self._chain = False                 # ▶ Preview Recap: beat after beat
        self._syncing = False
        self.output = ""
        self._lines = None
        self._infos = {}

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(12)
        lv.addWidget(self._banner())
        lv.addWidget(self._upload())
        lv.addWidget(self._intelligence())
        lv.addWidget(self._customize())
        row = QHBoxLayout()
        row.setSpacing(12)
        row.addWidget(self._generate(), 3)
        row.addWidget(self._export(), 2)
        lv.addLayout(row)
        lv.addStretch(1)

        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(12)
        rv.addWidget(self._preview())
        rv.addWidget(self._scene_list(), 1)
        rv.addWidget(self._quality())
        rv.addWidget(self._library())

        page = QWidget()
        h = QHBoxLayout(page)
        h.setContentsMargins(14, 14, 14, 14)
        h.setSpacing(14)
        h.addWidget(left, 5)
        h.addWidget(right, 3)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(page)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll)
        for v in videos or []:
            self._add(v)
        self.fill_library()
        self.fill()

    # ================================================================== #
    # banner
    # ================================================================== #
    def _banner(self) -> QFrame:
        fr = QFrame()
        fr.setObjectName("RBanner")
        h = QHBoxLayout(fr)
        h.setContentsMargins(22, 16, 16, 16)
        left = QVBoxLayout()
        row = QHBoxLayout()
        icon = QLabel("⌂")
        icon.setStyleSheet("font-size: 26px; color: #c9bfff; background: rgba(255,255,255,0.08);"
                           " border-radius: 22px; min-width: 44px; max-width: 44px;"
                           " min-height: 44px; max-height: 44px;")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        t = QLabel("AI Recap – សង្ខេបរឿងតាម AI")
        t.setObjectName("RTitle")
        new = QLabel("NEW")
        new.setObjectName("RNew")
        row.addWidget(icon)
        row.addWidget(t)
        row.addWidget(new)
        row.addStretch(1)
        left.addLayout(row)
        left.addSpacing(6)
        for text in ("Turn long videos into short, powerful stories with AI.",
                     "Smart summary, natural Khmer narration, and cinematic video editing."):
            s = QLabel(text)
            s.setObjectName("RSub")
            left.addWidget(s)
        left.addStretch(1)
        h.addLayout(left, 1)
        self.lb_hero = QLabel()
        self.lb_hero.setPixmap(_hero_pixmap([]))
        self.lb_hero.setCursor(Qt.CursorShape.PointingHandCursor)
        self.lb_hero.setToolTip("▶ Preview the recap")
        self.lb_hero.mousePressEvent = lambda e: self.preview_recap()
        h.addWidget(self.lb_hero)
        return fr

    # ================================================================== #
    # ① Upload & Analyze
    # ================================================================== #
    def _upload(self) -> QFrame:
        fr, lay, _head = card("Upload & Analyze", "1")
        body = QHBoxLayout()
        body.setSpacing(14)
        box = QFrame()
        box.setObjectName("RInner")
        bl = QVBoxLayout(box)
        bl.setContentsMargins(10, 10, 10, 10)
        tabs = QHBoxLayout()
        tabs.setSpacing(6)
        self.src_group = QButtonGroup(self)
        for k, (text, slot) in enumerate((
                ("🎞  Video File", self.add_videos),
                ("▶  YouTube Link", lambda: self.from_link("YouTube")),
                ("🔗  Link", lambda: self.from_link("link")),
                ("🗂  From PC (folder)", self.add_folder))):
            b = QPushButton(text)
            b.setObjectName("RTab")
            b.setCheckable(True)
            b.setChecked(k == 0)
            b.clicked.connect(slot)
            self.src_group.addButton(b)
            tabs.addWidget(b)
        tabs.addStretch(1)
        b_rm = QPushButton("✕")
        b_rm.setObjectName("RIcon")
        b_rm.setToolTip("Remove the selected video")
        b_rm.clicked.connect(self.remove_video)
        tabs.addWidget(b_rm)
        bl.addLayout(tabs)
        drop = QFrame()
        drop.setObjectName("RDrop")
        drop.setMinimumHeight(140)
        dl = QVBoxLayout(drop)
        self.lb_drop = QLabel("<div style='font-size:30px;color:#8a7bff'>☁</div>"
                              "<b>Drag &amp; drop your video here</b><br>or click to "
                              "<span style='color:#7c8cff'>browse</span><br><br>"
                              "<span style='color:#8f98c8;font-size:11px'>Supported: MP4, MKV, "
                              "AVI, MOV, WEBM, TS · one video or every episode</span>")
        self.lb_drop.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lst = QListWidget()
        self.lst.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.lst.setVisible(False)
        self.lst.currentRowChanged.connect(self._video_selected)
        dl.addWidget(self.lb_drop, 1)
        dl.addWidget(self.lst, 1)
        self.lb_drop.mousePressEvent = lambda e: self.add_videos()
        self.setAcceptDrops(True)
        bl.addWidget(drop, 1)
        body.addWidget(box, 3)

        info = QFrame()
        info.setObjectName("RInner")
        il = QHBoxLayout(info)
        il.setContentsMargins(10, 10, 10, 10)
        il.setSpacing(12)
        self.lb_thumb = QLabel("🎬")
        self.lb_thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lb_thumb.setFixedSize(200, 150)
        self.lb_thumb.setStyleSheet("background: #070a1f; border-radius: 10px; font-size: 40px;")
        il.addWidget(self.lb_thumb)
        col = QVBoxLayout()
        self.lb_file = QLabel("No video yet")
        self.lb_file.setStyleSheet("font-weight: 700; font-size: 13px;")
        self.lb_file.setWordWrap(True)
        col.addWidget(self.lb_file)
        col.addSpacing(4)
        self.lb_info = QLabel("")
        self.lb_info.setObjectName("RSmall")
        self.lb_info.setTextFormat(Qt.TextFormat.RichText)
        col.addWidget(self.lb_info)
        col.addStretch(1)
        self.btn_start = QPushButton("✨  Analyze with AI")
        self.btn_start.setObjectName("RStart")
        self.btn_start.setToolTip("Whisper reads the videos, AI understands the story and "
                                  "writes the recap script (then ③ ▶ Preview Recap, ⑤ Export)")
        self.btn_start.clicked.connect(lambda: self.run("analyze"))
        col.addWidget(self.btn_start)
        il.addLayout(col, 1)
        body.addWidget(info, 3)
        lay.addLayout(body)
        return fr

    # ================================================================== #
    # ② AI Story Intelligence
    # ================================================================== #
    def _intelligence(self) -> QFrame:
        fr, lay, head = card("AI Story Intelligence", "2")
        self.lb_pill = _label("Ready", "RPill")
        head.insertWidget(head.count() - 1, self.lb_pill)
        self.pb = QProgressBar()
        self.pb.setRange(0, 100)
        self.pb.setTextVisible(False)
        self.pb.setFixedWidth(220)
        head.insertWidget(head.count() - 1, self.pb)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self.cancel)
        head.addWidget(self.btn_cancel)
        row = QHBoxLayout()
        row.setSpacing(10)
        self.features = {}
        self.step_buttons = {}
        for key, icon, title, step, tip in (
                ("chars", "👥", "Character Recognition", "story",
                 "AI finds the characters and gives them Khmer names (kept in the Glossary)"),
                ("plot", "🧭", "Plot Analysis", "story",
                 "AI understands the story: summary, main conflict, timeline"),
                ("scenes", "🎬", "Scene Selection", "script",
                 "AI chooses the key moments for every sentence"),
                ("script", "📝", "Script Generation", "script",
                 "AI writes the Khmer narration script")):
            b = QPushButton(f"{icon}   {title}\n       –")
            b.setObjectName("RFeature")
            b.setToolTip(tip + "\n(click: do this step again)")
            b.setMinimumHeight(64)
            b.clicked.connect(lambda _=False, s=step: self.run(s))
            row.addWidget(b, 1)
            self.features[key] = (b, icon, title)
            self.step_buttons[key] = b
        lay.addLayout(row)
        srow = QHBoxLayout()
        self.lb_state = QLabel("Add the videos of a story, then ✨ Analyze with AI.")
        self.lb_state.setObjectName("RSmall")
        self.lb_state.setWordWrap(True)
        srow.addWidget(self.lb_state, 1)
        b_check = QPushButton("✔ Check the facts")
        b_check.setToolTip("AI compares every sentence with what is really said in the video")
        b_check.clicked.connect(lambda: self.run("check"))
        srow.addWidget(b_check)
        self.step_buttons["check"] = b_check
        lay.addLayout(srow)
        return fr

    # ================================================================== #
    # ③ Customize Recap Style
    # ================================================================== #
    def _customize(self) -> QFrame:
        fr, lay, head = card("Customize Recap Style", "3")
        self.btn_more = QPushButton("⚙  More ▾")
        self.btn_more.setCheckable(True)
        head.addWidget(self.btn_more)
        g = QGridLayout()
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(4)

        self.cmb_style = QComboBox()
        for key, (label, note, _how) in recap.STYLES.items():
            self.cmb_style.addItem(f"{STYLE_ICON.get(key, '🎬')}  {label}", key)
            self.cmb_style.setItemData(self.cmb_style.count() - 1, note,
                                       Qt.ItemDataRole.ToolTipRole)
        self.cmb_style.setCurrentIndex(max(0, self.cmb_style.findData(
            settings.get("recap_style", "normal"))))

        self.cmb_voice = QComboBox()
        for eng, vid, label in VOICES:
            self.cmb_voice.addItem("🧑  " + label, (eng, vid))
        b_play = QPushButton("▶")
        b_play.setFixedWidth(36)
        b_play.setToolTip("Preview the voice")
        b_play.clicked.connect(self.preview_voice)
        self.btn_lib = QPushButton("📚")
        self.btn_lib.setFixedWidth(36)
        self.btn_lib.setToolTip("A cloned voice from the Voice Library (VoxCPM2 – slower)")
        self.btn_lib.clicked.connect(self.pick_library)
        vrow = QHBoxLayout()
        vrow.setSpacing(4)
        vrow.addWidget(self.cmb_voice, 1)
        vrow.addWidget(b_play)
        vrow.addWidget(self.btn_lib)

        self.cmb_emotion = QComboBox()
        for k, t in recap.EMOTIONS.items():
            self.cmb_emotion.addItem(t, k)

        self.chk_speed = QCheckBox()
        self.chk_speed.setObjectName("RSwitch")
        self.chk_speed.setToolTip("On: your own speed. Off: normal speed (the mood of each "
                                  "beat still sets its pace)")
        self.sl_speed = QSlider(Qt.Orientation.Horizontal)
        self.sl_speed.setRange(-30, 30)
        sp = int(settings.get("recap_speed", 0) or 0)
        self.sl_speed.setValue(sp)
        self.chk_speed.setChecked(sp != 0)
        self.lb_speed = _label(_speed_x(sp), "RSmall")
        self.sl_speed.valueChanged.connect(lambda v: self.lb_speed.setText(_speed_x(v)))
        self.chk_speed.toggled.connect(self.sl_speed.setEnabled)
        self.sl_speed.setEnabled(self.chk_speed.isChecked())
        srow = QHBoxLayout()
        srow.addWidget(self.chk_speed)
        srow.addWidget(self.sl_speed, 1)
        srow.addWidget(self.lb_speed)

        self.cmb_music = QComboBox()
        self.cmb_music.addItem("No music", "")
        for p in (settings.get("recap_music_recent", []) or [])[:6]:
            if os.path.isfile(p):
                self.cmb_music.addItem("🎵  " + os.path.splitext(os.path.basename(p))[0], p)
        self.cmb_music.addItem("Choose a music file…", "*")
        self.cmb_music.activated.connect(self._music_chosen)

        for c, (label, w) in enumerate((("Recap Style", self.cmb_style),
                                        ("Narrator Voice", vrow), ("Emotion", self.cmb_emotion))):
            g.addWidget(_label(label), 0, c)
            if isinstance(w, QHBoxLayout):
                g.addLayout(w, 1, c)
            else:
                g.addWidget(w, 1, c)
        g.addWidget(_label("Narration Speed"), 0, 3)
        g.addLayout(srow, 1, 3)
        g.addWidget(_label("Music Background"), 2, 3)
        g.addWidget(self.cmb_music, 3, 3)
        g.setColumnStretch(0, 3)
        g.setColumnStretch(1, 4)
        g.setColumnStretch(2, 2)
        g.setColumnStretch(3, 3)

        checks = QVBoxLayout()
        self.chk_auto = QCheckBox("Auto Scene Sync")
        self.chk_auto.setChecked(True)
        self.chk_auto.setToolTip("AI chooses the moments that show every sentence.\n"
                                 "Off: the moments go in story order (edit them in ④ Scenes).")
        self.chk_subs = QCheckBox("Subtitle (Khmer)")
        self.chk_subs.setChecked(True)
        self.chk_hook = QCheckBox("Add Intro Hook (5–15 s)")
        self.chk_hook.setChecked(True)
        for w in (self.chk_auto, self.chk_subs, self.chk_hook):
            checks.addWidget(w)
        checks.addStretch(1)
        self.btn_preview = QPushButton("▶  Preview Recap")
        self.btn_preview.setObjectName("RAccent")
        self.btn_preview.setToolTip("Voice the script (only what is new) and play the recap "
                                    "beat after beat in ▣ Preview")
        self.btn_preview.clicked.connect(self.preview_recap)
        checks.addWidget(self.btn_preview)
        top = QHBoxLayout()
        top.addLayout(g, 1)
        top.addSpacing(10)
        top.addLayout(checks)
        lay.addLayout(top)

        # ---- ⚙ More
        self.more = QFrame()
        self.more.setObjectName("RInner")
        m = QGridLayout(self.more)
        m.setContentsMargins(12, 10, 12, 10)
        m.setHorizontalSpacing(14)
        self.cmb_src = QComboBox()
        for k, t in SOURCES:
            self.cmb_src.addItem(t, k)
        self.cmb_tgt = QComboBox()
        for k, t in TARGETS:
            self.cmb_tgt.addItem(t, k)
        self.spn_min = QSpinBox()
        self.spn_min.setRange(2, 20)
        self.spn_min.setValue(int(settings.get("recap_minutes", 8) or 8))
        self.spn_min.setSuffix(" min")
        self.cmb_ratio = QComboBox()
        for k, label in (("16:9", "16:9 YouTube"), ("9:16", "9:16 TikTok / Reels"),
                         ("1:1", "1:1 square"), ("original", "Like the video")):
            self.cmb_ratio.addItem(label, k)
        self.cmb_ratio.setCurrentIndex(max(0, self.cmb_ratio.findData(
            settings.get("recap_ratio", "16:9"))))
        self.sl_pitch = QSlider(Qt.Orientation.Horizontal)
        self.sl_pitch.setRange(-20, 20)
        self.sl_pitch.setValue(int(settings.get("recap_pitch", 0) or 0))
        self.lb_pitch = _label(f"{self.sl_pitch.value():+d} Hz", "RSmall")
        self.sl_pitch.valueChanged.connect(lambda v: self.lb_pitch.setText(f"{v:+d} Hz"))
        prow = QHBoxLayout()
        prow.addWidget(self.sl_pitch, 1)
        prow.addWidget(self.lb_pitch)
        self.sl_orig = QSlider(Qt.Orientation.Horizontal)
        self.sl_orig.setRange(0, 60)
        self.sl_orig.setValue(15)
        self.sl_orig.setToolTip("The sound of the drama under the narration")
        self.sl_orig.valueChanged.connect(
            lambda v: self.player is not None and self._beat() is not None
            and self._beat().kind != "original" and self.player.audioOutput().setVolume(v / 100))
        for c, (label, w) in enumerate((("Source Language", self.cmb_src),
                                        ("Recap Language", self.cmb_tgt),
                                        ("Recap length", self.spn_min),
                                        ("Picture", self.cmb_ratio),
                                        ("Voice pitch", prow), ("Drama sound", self.sl_orig))):
            m.addWidget(_label(label), 0, c)
            if isinstance(w, QHBoxLayout):
                m.addLayout(w, 1, c)
            else:
                m.addWidget(w, 1, c)
        self.chk_orig = QCheckBox("🎭 A few key lines in the actors' own voice")
        self.chk_orig.setChecked(True)
        self.chk_visual = QCheckBox("👁 AI also looks at the pictures (slower, more quota)")
        self.chk_visual.setToolTip("Small pictures of the videos are sent with the story: "
                                   "scenes without words (fights, places) can be chosen too.")
        self.chk_visual.setChecked(bool(settings.get("recap_visual", False)))
        m.addWidget(self.chk_orig, 2, 0, 1, 3)
        m.addWidget(self.chk_visual, 2, 3, 1, 3)
        lay.addWidget(self.more)
        open_more = bool(settings.get("recap_more", False))
        self.btn_more.setChecked(open_more)
        self.more.setVisible(open_more)
        self.btn_more.toggled.connect(self._toggle_more)
        return fr

    def _toggle_more(self, on: bool):
        self.more.setVisible(on)
        self.btn_more.setText("⚙  More ▴" if on else "⚙  More ▾")
        settings.set("recap_more", on)

    def style_key(self) -> str:
        return self.cmb_style.currentData() or "normal"

    def _music_chosen(self, _i=None):
        if self.cmb_music.currentData() == "*":
            self.pick_music()

    # ================================================================== #
    # ④ Generate & Edit
    # ================================================================== #
    def _generate(self) -> QFrame:
        fr, lay, head = card("Generate & Edit", "4")
        self.lb_title = _label("", "RSmall")
        head.insertWidget(head.count() - 1, self.lb_title)
        body = QHBoxLayout()
        body.setSpacing(10)
        left = QVBoxLayout()
        self.tabs = QTabWidget()
        self.tbl = QTableWidget(0, 3)
        self.tbl.setHorizontalHeaderLabels(["Time", "Script – edit freely", "✔"])
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setWordWrap(True)
        self.tbl.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.tbl.itemChanged.connect(self._edited)
        self.tbl.currentCellChanged.connect(lambda *_: self._select_beat())
        self.tabs.addTab(self.tbl, "Script")
        self.lst_timeline = QListWidget()
        self.tabs.addTab(self.lst_timeline, "Timeline")
        # Scenes: the moments of the selected beat
        sc = QWidget()
        sl = QVBoxLayout(sc)
        sl.addWidget(_label("Moments shown while the selected line is spoken "
                            "(video number, start-end):"))
        self.ed_clips = QLineEdit()
        self.ed_clips.setPlaceholderText("v0 01:02-01:08; v1 …")
        self.ed_clips.editingFinished.connect(self._clips_edited)
        sl.addWidget(self.ed_clips)
        krow = QHBoxLayout()
        self.cmb_kind = QComboBox()
        for k, t in (("narration", "🗣 Narration"), ("hook", "🎣 Hook"),
                     ("original", "🎭 Actor's voice")):
            self.cmb_kind.addItem(t, k)
        self.cmb_kind.activated.connect(
            lambda *_: self._set_beat("kind", self.cmb_kind.currentData()))
        self.cmb_mood = QComboBox()
        for k in recap.MOODS:
            self.cmb_mood.addItem(k, k)
        self.cmb_mood.activated.connect(
            lambda *_: self._set_beat("mood", self.cmb_mood.currentData()))
        b_auto = QPushButton("⚡ Auto Edit (AI again)")
        b_auto.clicked.connect(lambda: self.run("script"))
        krow.addWidget(_label("Kind"))
        krow.addWidget(self.cmb_kind)
        krow.addWidget(_label("Mood"))
        krow.addWidget(self.cmb_mood)
        krow.addStretch(1)
        krow.addWidget(b_auto)
        sl.addLayout(krow)
        sl.addStretch(1)
        self.tabs.addTab(sc, "Scenes")
        self.lst_subs = QListWidget()
        self.lst_subs.currentRowChanged.connect(
            lambda i: i >= 0 and not self._syncing and self.tbl.setCurrentCell(i, 1))
        self.tabs.addTab(self.lst_subs, "Subtitles")
        self.ed_story = QPlainTextEdit()
        self.ed_story.setPlaceholderText("🧠 Story Brain – summary, characters (原名 = ឈ្មោះខ្មែរ "
                                         "— role), timeline. Written by AI, edit freely: the "
                                         "script follows it.")
        self.ed_story.textChanged.connect(self._story_edited)
        self.tabs.addTab(self.ed_story, "🧠 Story")
        self.tabs.setMinimumHeight(250)
        left.addWidget(self.tabs, 1)
        brow = QHBoxLayout()
        b_edit = QPushButton("✎ Edit Script")
        b_edit.setObjectName("RIcon")
        b_edit.setStyleSheet("font-size: 12px; color: #9fb0ff;")
        b_edit.clicked.connect(self.edit_script)
        b_add = QPushButton("+")
        b_add.setToolTip("Add a line")
        b_add.clicked.connect(self.add_beat)
        b_del = QPushButton("🗑")
        b_del.setToolTip("Delete the line")
        b_del.clicked.connect(self.delete_beat)
        b_names = QPushButton("💾 Names → Glossary")
        b_names.setToolTip("The characters' Khmer names are kept for every episode, dub "
                           "and recap (character memory)")
        b_names.clicked.connect(self.save_names)
        self.lb_words = _label("")
        for w in (b_edit, b_add, b_del, b_names):
            brow.addWidget(w)
        brow.addStretch(1)
        brow.addWidget(self.lb_words)
        left.addLayout(brow)
        body.addLayout(left, 3)

        right = QFrame()
        right.setObjectName("RInner")
        right.setMinimumWidth(250)
        rl = QVBoxLayout(right)
        rl.setContentsMargins(8, 8, 8, 8)
        rl.addWidget(_label("Key Scenes", "RSmall"))
        self.strip = QListWidget()
        self.strip.setViewMode(QListWidget.ViewMode.IconMode)
        self.strip.setFlow(QListWidget.Flow.LeftToRight)
        self.strip.setWrapping(True)
        self.strip.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.strip.setIconSize(QSize(88, 50))
        self.strip.setGridSize(QSize(96, 74))
        self.strip.setMovement(QListWidget.Movement.Static)
        self.strip.currentRowChanged.connect(
            lambda i: i >= 0 and not self._syncing and self.tbl.setCurrentCell(i, 1))
        rl.addWidget(self.strip, 1)
        b_scenes = QPushButton("✎ Edit Scenes")
        b_scenes.clicked.connect(lambda: (self.tabs.setCurrentIndex(2), self.ed_clips.setFocus()))
        rl.addWidget(b_scenes, 0, Qt.AlignmentFlag.AlignRight)
        body.addWidget(right, 2)
        lay.addLayout(body, 1)
        return fr

    # ================================================================== #
    # ⑤ Export
    # ================================================================== #
    def _export(self) -> QFrame:
        fr, lay, _head = card("Export", "5")
        lay.addWidget(_label("Output Format"))
        frow = QHBoxLayout()
        self.fmt_group = QButtonGroup(self)
        self.fmt_buttons = {}
        cur = settings.get("recap_format", "mp4")
        for key, name, note in FORMATS:
            b = QPushButton(f"{name}\n{note}")
            b.setObjectName("RFormat")
            b.setCheckable(True)
            b.setChecked(key == cur)
            self.fmt_group.addButton(b)
            self.fmt_buttons[key] = b
            frow.addWidget(b)
        if not any(b.isChecked() for b in self.fmt_buttons.values()):
            self.fmt_buttons["mp4"].setChecked(True)
        lay.addLayout(frow)
        g = QGridLayout()
        g.addWidget(_label("Resolution"), 0, 0)
        self.cmb_res = QComboBox()
        for k, t in RESOLUTIONS:
            self.cmb_res.addItem(t, k)
        self.cmb_res.setCurrentIndex(max(0, self.cmb_res.findData(
            int(settings.get("recap_resolution", 1080) or 1080))))
        g.addWidget(self.cmb_res, 1, 0)
        self.chk_wm = QCheckBox("Add Watermark")
        self.chk_wm.setToolTip("Your logo in the top-right corner (click to choose the logo)")
        self.ed_wm = settings.get("recap_watermark", "") or ""
        self.chk_wm.setChecked(bool(settings.get("recap_watermark_on", False)) and
                               os.path.isfile(self.ed_wm))
        self.chk_wm.clicked.connect(self._watermark_clicked)
        g.addWidget(self.chk_wm, 1, 1)
        lay.addLayout(g)
        self.ed_folder = QLineEdit(settings.get("recap_dir", "") or "")
        self.ed_folder.setPlaceholderText("Save in: a Recap folder next to the videos")
        bf = QPushButton("…")
        bf.setFixedWidth(34)
        bf.clicked.connect(self.pick_folder)
        drow = QHBoxLayout()
        drow.addWidget(self.ed_folder, 1)
        drow.addWidget(bf)
        lay.addLayout(drow)
        lay.addStretch(1)
        row = QHBoxLayout()
        self.btn_open = QPushButton("📂")
        self.btn_open.setToolTip("Open the folder of the recap")
        self.btn_open.setEnabled(False)
        self.btn_open.clicked.connect(self.open_output)
        self.btn_export = QPushButton("Export")
        self.btn_export.setObjectName("RStart")
        self.btn_export.clicked.connect(lambda: self.run("export"))
        row.addWidget(self.btn_open)
        row.addWidget(self.btn_export, 1)
        lay.addLayout(row)
        return fr

    def fmt(self) -> str:
        return next((k for k, b in self.fmt_buttons.items() if b.isChecked()), "mp4")

    def _watermark_clicked(self, on: bool):
        if on and not os.path.isfile(self.ed_wm):
            path, _ = QFileDialog.getOpenFileName(self, "Watermark logo", "",
                                                  "Pictures (*.png *.jpg *.jpeg *.webp)")
            if not path:
                self.chk_wm.setChecked(False)
                return
            self.ed_wm = path
            settings.set("recap_watermark", path)
        self.chk_wm.setToolTip(f"Logo: {self.ed_wm}" if self.ed_wm else "")

    # ================================================================== #
    # right: ▣ Preview
    # ================================================================== #
    def _preview(self) -> QFrame:
        fr, lay, _head = card("▣  Preview")
        holder = QFrame()
        holder.setStyleSheet("background: black; border-radius: 10px;")
        hl = QVBoxLayout(holder)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(0)
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
            from PySide6.QtMultimediaWidgets import QVideoWidget

            self.video = QVideoWidget()
            self.video.setMinimumHeight(300)
            self.player = QMediaPlayer(self)
            self.player.setAudioOutput(QAudioOutput(self))
            self.player.setVideoOutput(self.video)
            self.player.positionChanged.connect(self._clip_pos)
            self.player.durationChanged.connect(lambda d: self.sl_seek.setRange(0, int(d)))
            self.player.playbackStateChanged.connect(self._play_state)
            self.voice_player = QMediaPlayer(self)
            self.voice_player.setAudioOutput(QAudioOutput(self))
            self.voice_player.mediaStatusChanged.connect(self._voice_status)
            hl.addWidget(self.video, 1)
        except ImportError:
            hl.addWidget(QLabel("(no video preview)"), 1)
        self.lb_sub = QLabel("")
        self.lb_sub.setObjectName("RSubtitle")
        self.lb_sub.setWordWrap(True)
        self.lb_sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lb_sub.setVisible(False)
        hl.addWidget(self.lb_sub)
        lay.addWidget(holder, 1)
        self.sl_seek = QSlider(Qt.Orientation.Horizontal)
        self.sl_seek.sliderMoved.connect(
            lambda v: self.player is not None and self.player.setPosition(v))
        lay.addWidget(self.sl_seek)
        row = QHBoxLayout()
        self.btn_play = QPushButton("▶")
        self.btn_play.setObjectName("RIcon")
        self.btn_play.setToolTip("Play / pause")
        self.btn_play.clicked.connect(self.toggle_play)
        b_prev = QPushButton("⏮")
        b_prev.setObjectName("RIcon")
        b_prev.setToolTip("Previous line")
        b_prev.clicked.connect(lambda: self._step_beat(-1))
        b_next = QPushButton("⏭")
        b_next.setObjectName("RIcon")
        b_next.setToolTip("Next line")
        b_next.clicked.connect(lambda: self._step_beat(1))
        self.lb_time = _label("00:00 / 00:00", "RSmall")
        self.cmb_rate = QComboBox()
        for x in RATES:
            self.cmb_rate.addItem(f"{x:g}x", x)
        self.cmb_rate.setCurrentIndex(RATES.index(1.0))
        self.cmb_rate.currentIndexChanged.connect(self._rate_changed)
        b_full = QPushButton("⛶")
        b_full.setObjectName("RIcon")
        b_full.setToolTip("Full screen (Esc to leave)")
        b_full.clicked.connect(self.full_screen)
        for w in (self.btn_play, b_prev, b_next, self.lb_time):
            row.addWidget(w)
        row.addStretch(1)
        row.addWidget(self.cmb_rate)
        row.addWidget(b_full)
        lay.addLayout(row)
        return fr

    def _scene_list(self) -> QFrame:
        fr, lay, _head = card("")
        lay.itemAt(0).layout().itemAt(0).widget().setVisible(False)
        self.side_tabs = QTabWidget()
        self.lst_scenes = QListWidget()
        self.lst_scenes.setIconSize(QSize(120, 68))
        self.lst_scenes.setWordWrap(True)
        self.lst_scenes.setSpacing(3)
        self.lst_scenes.currentRowChanged.connect(
            lambda i: i >= 0 and not self._syncing and self.tbl.setCurrentCell(i, 1))
        self.side_tabs.addTab(self.lst_scenes, "Recap Script")
        self.lst_chapters = QListWidget()
        self.lst_chapters.itemClicked.connect(self._chapter_clicked)
        self.side_tabs.addTab(self.lst_chapters, "Timestamps")
        self.txt_summary = QTextBrowser()
        self.side_tabs.addTab(self.txt_summary, "AI Summary")
        self.side_tabs.setMinimumHeight(330)
        lay.addWidget(self.side_tabs, 1)
        return fr

    def _quality(self) -> QFrame:
        fr, lay, _head = card("Recap Quality Score")
        row = QHBoxLayout()
        col = QVBoxLayout()
        self.ring = ScoreRing()
        col.addWidget(self.ring, 0, Qt.AlignmentFlag.AlignHCenter)
        self.lb_grade = _label("", "RSmall")
        self.lb_grade.setAlignment(Qt.AlignmentFlag.AlignCenter)
        col.addWidget(self.lb_grade)
        row.addLayout(col)
        checks = QVBoxLayout()
        self.quality_checks = {}
        for key, text in (("true", "សាច់រឿងត្រឹមត្រូវ"), ("voice", "សំឡេងធម្មជាតិ"),
                          ("moments", "ឈុតត្រូវនឹងការនិទាន"), ("length", "ប្រវែងល្អ · Hook ទាក់ចិត្ត")):
            lb = QLabel("○  " + text)
            lb.setObjectName("RSmall")
            checks.addWidget(lb)
            self.quality_checks[key] = (lb, text)
        checks.addStretch(1)
        row.addLayout(checks, 1)
        lay.addLayout(row)
        self.lb_score = _label("⭐ Quality: –")
        self.lb_score.setWordWrap(True)
        lay.addWidget(self.lb_score)
        return fr

    def _library(self) -> QFrame:
        fr, lay, _head = card("Recap Library")
        self.lst_lib = QListWidget()
        self.lst_lib.setIconSize(QSize(80, 45))
        self.lst_lib.setMaximumHeight(170)
        self.lst_lib.itemDoubleClicked.connect(self.open_recap)
        self.lst_lib.setToolTip("Double-click: open the recap again")
        lay.addWidget(self.lst_lib)
        return fr

    # ================================================================== #
    # preview player
    # ================================================================== #
    def toggle_play(self):
        if self.player is None:
            return
        from PySide6.QtMultimedia import QMediaPlayer

        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self._chain = False
            self.player.pause()
            if self.voice_player is not None:
                self.voice_player.pause()
        elif self.player.source().isEmpty():
            self.preview_recap()
        else:
            self.player.play()
            if self.voice_player is not None and \
                    self.voice_player.playbackState() == QMediaPlayer.PlaybackState.PausedState:
                self.voice_player.play()

    def _play_state(self, state):
        from PySide6.QtMultimedia import QMediaPlayer

        self.btn_play.setText("⏸" if state == QMediaPlayer.PlaybackState.PlayingState else "▶")

    def _rate_changed(self, _i):
        if self.player is not None:
            self.player.setPlaybackRate(float(self.cmb_rate.currentData() or 1.0))

    def full_screen(self):
        if self.video is not None:
            self.video.setFullScreen(not self.video.isFullScreen())

    def _step_beat(self, d: int):
        if self.r is None or not self.r.beats:
            return
        i = max(0, min(len(self.r.beats) - 1, self._row() + d))
        self.tbl.setCurrentCell(i, 1)

    def preview_recap(self):
        """▶ Preview Recap: voice what is new, then play beat after beat."""
        if self.r is None or not self.r.beats:
            QMessageBox.information(self, "AI Recap", "✨ Analyze with AI first – the script "
                                                      "is written there.")
            return
        try:
            self._apply_settings()
        except ValueError:
            return
        missing = [i for i, b in enumerate(self.r.beats) if not b.audio and b.kind != "original"]
        if missing:
            r = self.r

            def job(progress, stop):
                recap.narrate(r, progress, stop, missing)
                recap.remember(r)
                return ""
            self._start(job, lambda _x: (self._done(""), self._start_chain()))
        else:
            self._start_chain()

    def _start_chain(self):
        if self.r is None or not self.r.beats:
            return
        self._chain = True
        if self._row() == 0:
            self.play_beat()
        else:
            self.tbl.setCurrentCell(0, 1)       # -> _select_beat -> plays

    def _next_in_chain(self):
        if not self._chain or self.r is None:
            return
        i = self._row() + 1
        if i >= len(self.r.beats):
            self._chain = False
            if self.player is not None:
                self.player.pause()
            return
        self.tbl.setCurrentCell(i, 1)

    def _voice_status(self, status):
        from PySide6.QtMultimedia import QMediaPlayer

        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self._next_in_chain()

    # ================================================================== #
    # videos
    # ================================================================== #
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            p = u.toLocalFile()
            if os.path.isdir(p):
                self._add_folder(p)
            else:
                self._add(p)

    def _add(self, path: str):
        if os.path.isfile(path) and path.lower().endswith(tuple(VIDEO_EXT)):
            it = QListWidgetItem(f"🎞  {os.path.basename(path)}")
            it.setData(Qt.ItemDataRole.UserRole, path)
            it.setToolTip(path)
            self.lst.addItem(it)
            self.lst.setVisible(True)
            self.lb_drop.setVisible(False)
            if self.lst.count() == 1:
                self.lst.setCurrentRow(0)
            else:
                cur = self.lst.currentItem()
                self._show_info(cur.data(Qt.ItemDataRole.UserRole) if cur else path)
            self._hero()

    def _info(self, path: str) -> dict:
        """Duration, picture size, file size and a picture of one video (kept)."""
        if path in self._infos:
            return self._infos[path]
        import tempfile

        from core.media import get_media_info

        d = {"dur": 0.0, "w": 0, "h": 0, "size": 0, "pic": ""}
        try:
            m = get_media_info(path)
            d.update(dur=m.duration, w=m.width, h=m.height, size=os.path.getsize(path))
            out = os.path.join(tempfile.gettempdir(),
                               "voxdub_recap_thumb_%d.jpg" % abs(hash(path)))
            d["pic"] = recap.thumb(path, min(m.duration * 0.3, 60), out, 480)
        except Exception:
            pass
        self._infos[path] = d
        return d

    def _show_info(self, path: str):
        d = self._info(path)
        pm = QPixmap(d["pic"]) if d["pic"] else QPixmap()
        if not pm.isNull():
            self.lb_thumb.setPixmap(pm.scaled(self.lb_thumb.size(),
                                              Qt.AspectRatioMode.KeepAspectRatio,
                                              Qt.TransformationMode.SmoothTransformation))
        self.lb_file.setText(os.path.basename(path))
        n = self.lst.count()
        size = d["size"] / 1024 ** 3
        size = f"{size:.1f} GB" if size >= 1 else f"{d['size'] / 1024 ** 2:.0f} MB"
        total = sum(self._info(v)["dur"] for v in self.videos()) if n > 1 else d["dur"]
        rows = [("Duration", _clock(d["dur"])), ("Resolution", f"{d['w']} × {d['h']}"),
                ("Size", size)]
        if n > 1:
            rows.append(("Videos", f"{n} · {_clock(total)} in all"))
        self.lb_info.setText("<br>".join(
            f"<span style='color:#7c8cff'>●</span> {k}: <b>{v}</b>" for k, v in rows))

    def _video_selected(self, i: int):
        if i >= 0:
            self._show_info(self.lst.item(i).data(Qt.ItemDataRole.UserRole))

    def _hero(self):
        pics = []
        if self.r is not None and self.r.beats:
            pics = [p for p in recap.beat_thumbs(self.r) if p][:3]
        if not pics:
            pics = [self._info(v)["pic"] for v in self.videos()[:3]]
        self.lb_hero.setPixmap(_hero_pixmap(pics))

    def add_videos(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Videos of the story (in order)", "",
            "Videos (" + " ".join("*" + e for e in VIDEO_EXT) + ")")
        for p in paths:
            self._add(p)

    def _add_folder(self, folder: str):
        for name in sorted(os.listdir(folder), key=lambda n: [
                int(t) if t.isdigit() else t for t in re.split(r"(\d+)", n)]):
            self._add(os.path.join(folder, name))

    def add_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Folder of the story (episodes)")
        if folder:
            self._add_folder(folder)

    def remove_video(self):
        for it in self.lst.selectedItems():
            self.lst.takeItem(self.lst.row(it))
        if not self.lst.count():
            self.lst.setVisible(False)
            self.lb_drop.setVisible(True)
            self.lb_thumb.setText("🎬")
            self.lb_file.setText("No video yet")
            self.lb_info.setText("")
        self._hero()

    def videos(self) -> List[str]:
        return [self.lst.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.lst.count())]

    def from_link(self, what: str):
        url, ok = QInputDialog.getText(self, f"From {what}", "Link of the video:")
        if not ok or not url.strip():
            return
        folder = self.ed_folder.text().strip() or os.path.join(
            os.path.expanduser("~"), "Videos", "VoxDub Recap")

        def job(progress, stop):
            return recap.download(url.strip(), os.path.join(folder, "downloads"), progress, stop)
        self._start(job, lambda path: (self._add(path), self._idle(
            f"✓ Downloaded: {os.path.basename(path)}")))

    def pick_music(self):
        path, _ = QFileDialog.getOpenFileName(self, "Background music", "",
                                              "Audio (*.mp3 *.wav *.m4a *.aac *.ogg *.flac)")
        if path:
            self._set_music(path)
            recent = [path] + [p for p in (settings.get("recap_music_recent", []) or [])
                               if p != path]
            settings.set("recap_music_recent", recent[:6])
        else:
            self._set_music("")

    def _set_music(self, path: str):
        if not path:
            self.cmb_music.setCurrentIndex(0)
            return
        idx = self.cmb_music.findData(path)
        if idx < 0:
            self.cmb_music.insertItem(1, "🎵  " + os.path.splitext(os.path.basename(path))[0],
                                      path)
            idx = 1
        self.cmb_music.setCurrentIndex(idx)

    def pick_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Where the recaps are saved")
        if d:
            self.ed_folder.setText(d)
            settings.set("recap_dir", d)

    def pick_library(self):
        from ui.voice_library import VoiceLibraryDialog

        dlg = VoiceLibraryDialog(self, mode="pick", who="the narrator")
        if dlg.exec() and dlg.chosen is not None:
            v = dlg.chosen
            data = ("voxcpm", "voxcpm-ref:" + v.file)
            idx = self.cmb_voice.findData(data)
            if idx < 0:
                self.cmb_voice.addItem(f"📚 {v.name} (VoxCPM2 clone)", data)
                idx = self.cmb_voice.count() - 1
            self.cmb_voice.setCurrentIndex(idx)

    def preview_voice(self):
        import tempfile

        from core import tts

        eng, voice = self.cmb_voice.currentData()
        if self.sl_pitch.value() and eng == "edge":
            voice = f"{voice}|pitch={self.sl_pitch.value():+d}Hz"
        rate = self.speed() if eng == "edge" else 0
        lang = self.cmb_tgt.currentData()
        out = os.path.join(tempfile.gettempdir(), "voxdub_recap_voice.wav")
        text = ("សួស្តីអ្នកទាំងអស់គ្នា! ថ្ងៃនេះខ្ញុំនឹងនិទានរឿងមួយ ដែលអ្នកមិនគួររំលង។"
                if lang == "km" else "Hello! Today I will tell you a story you should not miss.")

        def job(progress, stop):
            tts.synthesize(text, out, eng, voice, lang, rate_percent=rate)
            return out
        self._start(job, lambda path: (self._idle("▶ Voice preview"), self._play_audio(path)))

    # ================================================================== #
    # settings -> Recap
    # ================================================================== #
    def _apply_settings(self) -> recap.Recap:
        vids = self.videos()
        if not vids:
            raise ValueError("Add the videos of the story first.")
        if self.r is None or self.r.videos != vids:
            root = self.ed_folder.text().strip() or settings.get("recap_dir", "") or \
                os.path.join(os.path.dirname(vids[0]), "Recap")
            self.r = recap.Recap(videos=vids, work_dir=recap.new_work_dir(root, vids))
            self._lines = None
        r = self.r
        r.minutes = float(self.spn_min.value())
        r.ratio = self.cmb_ratio.currentData()
        eng, voice = self.cmb_voice.currentData()
        changed = (eng, voice, self.speed(), self.sl_pitch.value(),
                   self.cmb_emotion.currentData()) != (r.engine, r.voice, r.speed, r.pitch,
                                                       r.emotion)
        if changed:
            for b in r.beats:
                b.audio, b.seconds = "", 0.0          # the narration is made again
        r.engine, r.voice = eng, voice
        r.speed, r.pitch = self.speed(), self.sl_pitch.value()
        r.emotion = self.cmb_emotion.currentData()
        r.source_language = self.cmb_src.currentData()
        r.language = self.cmb_tgt.currentData()
        r.original_volume = self.sl_orig.value() / 100.0
        music = self.cmb_music.currentData()
        r.music = music if music and music != "*" else ""
        r.resolution = int(self.cmb_res.currentData() or 1080)
        r.watermark = self.ed_wm if self.chk_wm.isChecked() else ""
        r.subtitles = self.chk_subs.isChecked()
        r.style = self.style_key()
        r.hook, r.keep_original = self.chk_hook.isChecked(), self.chk_orig.isChecked()
        r.visual = self.chk_visual.isChecked()
        for k, v in (("recap_minutes", self.spn_min.value()), ("recap_ratio", r.ratio),
                     ("recap_visual", r.visual), ("recap_speed", r.speed),
                     ("recap_pitch", r.pitch), ("recap_style", r.style),
                     ("recap_format", self.fmt()), ("recap_resolution", r.resolution),
                     ("recap_watermark_on", self.chk_wm.isChecked())):
            settings.set(k, v)
        return r

    def _load_into_ui(self, r: recap.Recap):
        self.lst.clear()
        for v in r.videos:
            self._add(v)
        self.r = r
        self._lines = None
        self.spn_min.setValue(int(r.minutes))
        self.cmb_ratio.setCurrentIndex(max(0, self.cmb_ratio.findData(r.ratio)))
        self.cmb_style.setCurrentIndex(max(0, self.cmb_style.findData(r.style)))
        self.cmb_res.setCurrentIndex(max(0, self.cmb_res.findData(int(r.resolution or 1080))))
        if r.watermark and os.path.isfile(r.watermark):
            self.ed_wm = r.watermark
        self.chk_wm.setChecked(bool(r.watermark))
        self.cmb_tgt.setCurrentIndex(max(0, self.cmb_tgt.findData(r.language)))
        self.cmb_src.setCurrentIndex(max(0, self.cmb_src.findData(r.source_language)))
        self.cmb_emotion.setCurrentIndex(max(0, self.cmb_emotion.findData(r.emotion)))
        idx = self.cmb_voice.findData((r.engine, r.voice))
        if idx < 0 and r.engine == "voxcpm":
            self.cmb_voice.addItem("📚 " + os.path.basename(r.voice.split(":", 1)[-1]),
                                   (r.engine, r.voice))
            idx = self.cmb_voice.count() - 1
        self.cmb_voice.setCurrentIndex(max(0, idx))
        self.sl_speed.setValue(int(r.speed))
        self.chk_speed.setChecked(bool(r.speed))
        self.sl_pitch.setValue(int(r.pitch))
        self.sl_orig.setValue(int(round(r.original_volume * 100)))
        self.chk_subs.setChecked(r.subtitles)
        self.chk_hook.setChecked(r.hook)
        self.chk_orig.setChecked(r.keep_original)
        self.chk_visual.setChecked(r.visual)
        self._set_music(r.music if r.music and os.path.isfile(r.music) else "")
        self.fill()
        self._hero()

    def lines(self):
        """The transcripts (when they were read already)."""
        r = self.r
        if r is None:
            return None
        if self._lines is None and all(os.path.isfile(os.path.join(r.work_dir, f"t{i}.json"))
                                       for i in range(len(r.videos))):
            try:
                self._lines = recap.transcripts(r)
            except Exception:
                self._lines = None
        return self._lines

    # ================================================================== #
    # running
    # ================================================================== #
    def _start(self, job, done=None) -> bool:
        if self.worker is not None and self.worker.isRunning():
            return False
        self._busy(True)
        w = TaskWorker(job, "Recap", self)
        w.progress.connect(self._progress)
        w.done.connect(done or self._done)
        w.failed.connect(self._failed)
        self.worker = w
        w.start()
        return True

    def speed(self) -> int:
        return self.sl_speed.value() if self.chk_speed.isChecked() else 0

    def _progress(self, p: int, msg: str):
        self.pb.setValue(int(p))
        self.lb_state.setText(msg)

    def _pill(self, text: str, on: bool = False):
        self.lb_pill.setText(text)
        self.lb_pill.setObjectName("RPillOn" if on else "RPill")
        self.lb_pill.style().polish(self.lb_pill)

    def _features(self):
        """② the four cards: what the AI found."""
        r = self.r
        story = r.story if r else ""
        beats = r.beats if r else []
        names = recap.story_names(story) if story.strip() else {}
        secs = sum(b.length() for b in beats)
        lang = dict(TARGETS).get(r.language if r else "km", "Khmer").split(" (")[0]
        found = {
            "chars": f"{len(names)} characters found" if names else "",
            "plot": "Main conflict && storyline" if story.strip() else "",
            "scenes": f"{len(beats)} key scenes selected" if beats else "",
            "script": f"{lang} narration · {_clock(secs)}" if beats else "",
        }
        for key, (b, icon, title) in self.features.items():
            text = found[key]
            b.setText(f"{icon}   {title}" + (f"  ✔\n       {text}" if text else "\n       –"))

    def run(self, step: str):
        try:
            r = self._apply_settings()
        except ValueError as e:
            QMessageBox.information(self, "AI Recap", str(e))
            return
        if step in ("all", "analyze", "story", "script", "check"):
            from core import gemini

            if not gemini.configured():
                QMessageBox.information(self, "AI Recap",
                                        "The story and the script are written by Gemini – add "
                                        "your API key in Settings › AI engines & API keys.")
                return
        if step in ("all", "export") and not self._rights_ok(r):
            return
        auto = self.chk_auto.isChecked()
        fmt = self.fmt()
        many = ("all", "analyze")

        def job(progress, stop):
            def part(lo, hi):
                if step == "analyze":           # no voice / export: the bar goes to 100
                    lo, hi = lo * 100 // 64, hi * 100 // 64
                return lambda p, m: progress(min(100, lo + (hi - lo) * p // 100), m)
            one = step not in many
            lines = None
            if step in ("all", "analyze", "read", "story", "script", "check"):
                lines = recap.transcripts(r, progress if one else part(0, 40), stop)
                self._lines = lines
            if step == "story" or (step in many and not r.story.strip()):
                recap.understand(r, lines, progress if one else part(40, 50), stop)
            if step in ("all", "analyze", "script"):
                recap.write_script(r, lines, progress if one else part(50, 60), stop)
                if not auto:
                    _story_order(r, lines)
            if step in ("all", "analyze", "check"):
                try:
                    recap.check(r, lines, progress if one else part(60, 64), stop)
                except Exception as e:          # the check is a help, not a must
                    progress(64, f"(check skipped: {e})")
            if step in ("all", "voice"):
                todo = None if step == "voice" else [i for i, b in enumerate(r.beats)
                                                     if not b.audio]
                recap.narrate(r, progress if one else part(64, 80), stop, todo)
            if step in ("all", "export"):
                missing = [i for i, b in enumerate(r.beats)
                           if not b.audio and b.kind != "original"]
                if missing:
                    recap.narrate(r, part(64, 80), stop, missing)
                folder = os.path.dirname(r.work_dir)
                out = os.path.join(folder, re.sub(r'[\\/:*?"<>|]+', "_",
                                                  r.title or "recap")[:60] + "_recap.mp4")
                out = recap.export(r, out, progress if one else part(80, 100), stop)
                if fmt in ("mp3", "wav"):
                    out = recap.export_audio(out, fmt)
                recap.remember(r)
                return out
            recap.remember(r)
            return ""
        self._start(job)

    def _rights_ok(self, r: recap.Recap) -> bool:
        try:
            from core import rights

            bad = {}
            for v in r.videos:
                key, state, text = rights.check(v)
                if state in ("missing", "expired"):
                    bad.setdefault(key, text)
        except Exception:
            return True
        if not bad:
            return True
        names = "\n".join(f"• {k}: {t}" for k, t in list(bad.items())[:6])
        return QMessageBox.question(
            self, "Rights",
            f"These stories have no rights recorded, or the licence has ended:\n\n{names}\n\n"
            "Tools › © Copyright check records them. Continue?") == \
            QMessageBox.StandardButton.Yes

    def _busy(self, on: bool):
        for b in [self.btn_start, self.btn_export, self.btn_preview] + \
                list(self.step_buttons.values()):
            b.setEnabled(not on)
        self.btn_cancel.setEnabled(on)
        if on:
            self._pill("Processing…")

    def _idle(self, text: str):
        self._busy(False)
        self._pill("Ready", True)
        self.lb_state.setText(text)

    def _done(self, result):
        self._busy(False)
        self._pill("Ready", True)
        self.pb.setValue(100)
        self.fill()
        self.fill_library()
        self._hero()
        if result:
            self.output = result
            self.btn_open.setEnabled(True)
            self.lb_state.setText(f"✅ Recap ready: {os.path.basename(result)}")
        else:
            self.lb_state.setText("✓ Done – check the script, then the next step")

    def _failed(self, err: str):
        self._busy(False)
        self._pill("Stopped")
        self.fill()
        self.lb_state.setText(f"⚠ {err}")

    def cancel(self):
        if self.worker is not None:
            self.worker.stop()
            self.lb_state.setText("Stopping…")

    # ================================================================== #
    # script / story / scenes
    # ================================================================== #
    def fill(self):
        r = self.r
        beats = r.beats if r else []
        self._features()
        self._syncing = True
        self.tbl.blockSignals(True)
        self.tbl.setRowCount(len(beats))
        starts, t = [], 0.0
        for b in beats:
            starts.append(t)
            t += b.length()
        for i, b in enumerate(beats):
            it = QTableWidgetItem(f"{_clock(starts[i])}  {KIND_LABEL.get(b.kind, '')}")
            it.setToolTip(f"{b.kind} · {b.mood}")
            it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.tbl.setItem(i, 0, it)
            self.tbl.setItem(i, 1, QTableWidgetItem(b.text))
            ck = QTableWidgetItem("✓" if b.check == "ok" else ("⚠" if b.check else ""))
            ck.setToolTip("" if b.check in ("", "ok") else b.check)
            ck.setFlags(ck.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.tbl.setItem(i, 2, ck)
        self.tbl.blockSignals(False)
        self.ed_story.blockSignals(True)
        self.ed_story.setPlainText(r.story if r else "")
        self.ed_story.blockSignals(False)
        self.lst_timeline.clear()
        summary, on = [], ""
        for line in (r.story if r else "").splitlines():
            if line.strip().upper() in ("SUMMARY", "CHARACTERS", "TIMELINE"):
                on = line.strip().upper()
                continue
            if on == "TIMELINE" and line.strip():
                self.lst_timeline.addItem(line.strip())
            elif on == "SUMMARY" and line.strip():
                summary.append(line.strip())
        names = recap.story_names(r.story) if r and r.story.strip() else {}
        html = ""
        if r and r.title:
            html += f"<h3>{r.title}</h3>"
        if summary:
            html += "<p>" + "<br>".join(summary) + "</p>"
        if names:
            html += "<p><b>Characters</b><br>" + "<br>".join(
                f"{k} = {v}" for k, v in names.items()) + "</p>"
        self.txt_summary.setHtml(html or "<p style='color:#8f98c8'>The AI summary of the story "
                                         "shows here after ✨ Analyze with AI.</p>")
        self.lb_title.setText(f"· {r.title}" if r and r.title else "")
        self.lb_words.setText(f"{len(beats)} lines · {sum(len(b.text) for b in beats):,} "
                              f"letters · {_clock(t)}" if beats else "")
        self.strip.clear()
        self.lst_scenes.clear()
        self.lst_subs.clear()
        self.lst_chapters.clear()
        if r and beats:
            pics = recap.beat_thumbs(r)
            parts = {}
            for label, start, _length in recap.chapters(r):
                parts[round(start, 2)] = label
            for i, b in enumerate(beats):
                icon = QIcon(pics[i]) if i < len(pics) and pics[i] else QIcon()
                self.strip.addItem(QListWidgetItem(icon, f"{i + 1}"))
                head = recap.PARTS.get(b.part, "") or parts.get(round(starts[i], 2), "")
                it = QListWidgetItem(icon, f"{_clock(starts[i])}   {head or 'Scene'}"
                                           f"   ·  Scene {i + 1}\n{b.text}")
                self.lst_scenes.addItem(it)
                self.lst_subs.addItem(f"{_clock(starts[i])} → {_clock(starts[i] + b.length())}"
                                      f"   {b.text}")
            for label, start, length in recap.chapters(r):
                it = QListWidgetItem(f"{_clock(start)}   {label}  ({_clock(length)})")
                it.setData(Qt.ItemDataRole.UserRole, start)
                self.lst_chapters.addItem(it)
        self._syncing = False
        self._score()

    def _score(self):
        r = self.r
        if r is None or not r.beats:
            self.lb_score.setText("⭐ Quality: –")
            self.ring.set_value(None)
            self.lb_grade.setText("")
            for lb, text in self.quality_checks.values():
                lb.setText("○  " + text)
            return
        s = recap.score(r, self.lines())
        self.ring.set_value(s["total"])
        self.lb_grade.setText(_grade(s["total"]))
        good = {"true": s["true"] >= 80, "voice": s["voice"] >= 99,
                "moments": s["moments"] >= 80, "length": s["length"] >= 75 and s["hook"] == 100}
        for key, (lb, text) in self.quality_checks.items():
            lb.setText(("✅  " if good[key] else "⚠️  ") + text)
        self.lb_score.setText(
            f"⭐ Quality {s['total']}/100 · length {_clock(s['seconds'])} / "
            f"{_clock(r.minutes * 60)} · moments {s['moments']}% · "
            f"true {s['true']}% · voice {s['voice']}% · hook {'✓' if s['hook'] == 100 else '–'}")

    def edit_script(self):
        """✎ Edit Script: the selected line opens for typing."""
        self.tabs.setCurrentIndex(0)
        row = max(0, self._row())
        if self.tbl.rowCount():
            self.tbl.setCurrentCell(row, 1)
            self.tbl.editItem(self.tbl.item(row, 1))

    def _row(self) -> int:
        return self.tbl.currentRow()

    def _beat(self) -> Optional[recap.Beat]:
        i = self._row()
        return self.r.beats[i] if self.r and 0 <= i < len(self.r.beats) else None

    def _select_beat(self):
        b = self._beat()
        if b is None:
            return
        self.ed_clips.setText(clips_text(b.clips))
        self.cmb_kind.setCurrentIndex(max(0, self.cmb_kind.findData(b.kind)))
        self.cmb_mood.setCurrentIndex(max(0, self.cmb_mood.findData(b.mood)))
        self.lb_sub.setText(b.text)
        self.lb_sub.setVisible(bool(b.text) and self.chk_subs.isChecked())
        row = self._row()
        self._syncing = True
        for w in (self.strip, self.lst_scenes, self.lst_subs):
            if w.currentRow() != row:
                w.setCurrentRow(row)
        self._syncing = False
        if self._chain:
            self.play_beat()
        else:
            self.preview_beat()

    def _edited(self, item: QTableWidgetItem):
        r = self.r
        if r is None or item.row() >= len(r.beats) or item.column() != 1:
            return
        b = r.beats[item.row()]
        if item.text().strip() != b.text:
            b.text, b.audio, b.seconds, b.check = item.text().strip(), "", 0.0, ""
            r.save()
            self._score()

    def _clips_edited(self):
        b = self._beat()
        clips = parse_clips(self.ed_clips.text())
        if b is not None and clips and clips != b.clips:
            row = self._row()
            b.clips = clips
            self.r.save()
            self.fill()
            self.tbl.setCurrentCell(row, 1)

    def _set_beat(self, name: str, value: str):
        b = self._beat()
        if b is None or getattr(b, name) == value:
            return
        setattr(b, name, value)
        b.audio, b.seconds = "", 0.0
        row = self._row()
        self.r.save()
        self.fill()
        self.tbl.setCurrentCell(row, 1)

    def _story_edited(self):
        if self.r is not None:
            self.r.story = self.ed_story.toPlainText()
            self.r.save()

    def save_names(self):
        if self.r is None:
            return
        n = recap.remember_names(self.r.story)
        self.lb_state.setText(f"💾 {n} new name(s) kept in the Glossary")

    def add_beat(self):
        if self.r is None:
            return
        i = self._row() + 1 if self._row() >= 0 else len(self.r.beats)
        self.r.beats.insert(i, recap.Beat("…", [[0, 0.0, 5.0]]))
        self.r.save()
        self.fill()
        self.tbl.setCurrentCell(i, 1)

    def delete_beat(self):
        i = self._row()
        if self.r is None or not (0 <= i < len(self.r.beats)):
            return
        del self.r.beats[i]
        self.r.save()
        self.fill()

    def _chapter_clicked(self, item: QListWidgetItem):
        start = float(item.data(Qt.ItemDataRole.UserRole) or 0)
        t = 0.0
        for i, b in enumerate(self.r.beats if self.r else []):
            if t >= start - 0.01:
                self.tbl.setCurrentCell(i, 1)
                return
            t += b.length()

    def revoice(self):
        i = self._row()
        if self.r is None or not (0 <= i < len(self.r.beats)):
            return
        self._apply_settings()
        r = self.r

        def job(progress, stop):
            recap.narrate(r, progress, stop, [i])
            return ""
        self._start(job, lambda _x: (self._done(""), self.tbl.setCurrentCell(i, 1),
                                     self.play_beat()))

    def _play_audio(self, path: str):
        if self.voice_player is not None and path and os.path.isfile(path):
            self.voice_player.setSource(QUrl.fromLocalFile(path))
            self.voice_player.play()

    def play_beat(self):
        b = self._beat()
        if b is None:
            return
        self._voice_on = b.kind != "original" and bool(b.audio) and os.path.isfile(b.audio)
        self.preview_beat()
        if self._voice_on:
            self._play_audio(b.audio)
        elif self.voice_player is not None:
            self.voice_player.stop()

    def preview_beat(self):
        """The moments of the selected beat play in the preview, one after another."""
        b = self._beat()
        if b is None or self.player is None:
            return
        self._queue = [c for c in b.clips if 0 <= int(c[0]) < len(self.r.videos)]
        vol = 1.0 if b.kind == "original" else self.sl_orig.value() / 100.0
        self.player.audioOutput().setVolume(vol)
        self._next_clip()

    def _next_clip(self) -> bool:
        if not getattr(self, "_queue", None):
            return False
        v, s, e = self._queue.pop(0)
        src = QUrl.fromLocalFile(self.r.videos[int(v)])
        if self.player.source() != src:
            self.player.setSource(src)
        self.player.setPosition(int(s * 1000))
        self._clip_end = e
        self.player.setPlaybackRate(float(self.cmb_rate.currentData() or 1.0))
        self.player.play()
        return True

    def _clip_pos(self, pos: int):
        if not self.sl_seek.isSliderDown():
            self.sl_seek.setValue(pos)
        self.lb_time.setText(f"{_clock(pos / 1000)} / {_clock(self.player.duration() / 1000)}")
        if self._clip_end and pos / 1000.0 >= self._clip_end:
            self._clip_end = 0.0
            if self._next_clip():
                return
            self.player.pause()
            if self._chain and not getattr(self, "_voice_on", False):
                self._next_in_chain()          # the actor's own line: the clip is the beat

    # ================================================================== #
    # library / output
    # ================================================================== #
    def fill_library(self):
        self.lst_lib.clear()
        for r in recap.library():
            pics = recap.beat_thumbs(r)[:1] if r.beats else []
            icon = QIcon(pics[0]) if pics and pics[0] else QIcon()
            stamp = os.path.basename(r.work_dir)[-15:-7]
            date = f"{stamp[:4]}-{stamp[4:6]}-{stamp[6:]}" if stamp.isdigit() else ""
            it = QListWidgetItem(icon, f"{r.title or os.path.basename(r.videos[0])}\n"
                                       f"{_clock(r.narration_seconds())} · {date} · "
                                       f"{recap.STYLES.get(r.style, ('',))[0]}")
            it.setData(Qt.ItemDataRole.UserRole, r.work_dir)
            self.lst_lib.addItem(it)

    def open_recap(self, item: QListWidgetItem):
        try:
            r = recap.Recap.load(item.data(Qt.ItemDataRole.UserRole))
        except Exception as e:
            QMessageBox.warning(self, "Recap Library", f"Could not open it:\n{e}")
            return
        self._load_into_ui(r)
        self.lb_state.setText(f"Opened: {r.title or r.work_dir}")

    def open_output(self):
        from ui.main_window import open_path

        if self.output:
            open_path(os.path.dirname(self.output))

    def done(self, r):
        if self.worker is not None and self.worker.isRunning():
            self.worker.stop()
            self.worker.wait(3000)
        for p in (self.player, self.voice_player):
            if p is not None:
                p.stop()
        super().done(r)


def _story_order(r: recap.Recap, lines) -> None:
    """Auto Scene Selection off: the moments simply go along the story."""
    if not lines:
        return
    flat = [(i, s, e) for i, ls in enumerate(lines) for s, e, _t in ls]
    if not flat:
        return
    step = max(1, len(flat) // max(1, len(r.beats)))
    for k, b in enumerate(r.beats):
        if b.kind == "original":
            continue
        chunk = flat[k * step:(k + 1) * step] or flat[-1:]
        b.clips = [[v, round(s, 2), round(e, 2)] for v, s, e in chunk[:4]]
    r.save()
