"""✅ Quality check: the lines worth a look after a Batch (core/qc.py).
Double-click a line → the episode opens in the editor at that moment."""

import os
from typing import Dict, List

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QBrush
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from core import qc

COLORS = {"no_voice": "#ff6b6b", "untranslated": "#ff6b6b", "cut": "#ffb84d",
          "fast": "#ffd84d", "gender": "#7fb2ff", "overlap": "#ffb84d",
          "garbled": "#ff6b6b", "chinese": "#ff6b6b", "few_lines": "#ff6b6b",
          "long": "#ffd84d", "short": "#ffd84d", "clip": "#ffb84d", "loud": "#ffb84d",
          "quiet": "#ffd84d", "level": "#7fb2ff", "slowed": "#ffd84d",
          "check_nosub": "#f59e0b", "check_unsure": "#f59e0b", "noise": "#9ca3af"}


def _t(t: float) -> str:
    return f"{int(t // 60):02d}:{t % 60:04.1f}"


class QCDialog(QDialog):
    """rows: issues with "episode" (name) and "autosave" (project file)."""

    def __init__(self, win, rows: List[Dict], csv_path: str = "", episodes: int = 0):
        super().__init__(win)
        self.win, self.rows, self.csv_path = win, rows, csv_path
        self.setWindowTitle("✅ Quality check – lines to look at")
        self.resize(980, 560)
        v = QVBoxLayout(self)
        eps = len({r.get("episode") for r in rows})
        head = QLabel(f"<b>{len(rows)}</b> lines to look at in <b>{eps}</b> of "
                      f"{episodes or eps} episodes. Double-click a line to open the episode "
                      "there (fix it, then ⬆ Export it again in the Batch).")
        head.setWordWrap(True)
        v.addWidget(head)
        top = QHBoxLayout()
        self.cmb = QComboBox()
        self.cmb.addItem("All problems", "")
        for k, name in qc.KINDS.items():
            n = sum(1 for r in rows if r["kind"] == k)
            if n:
                self.cmb.addItem(f"{name} ({n})", k)
        self.cmb.currentIndexChanged.connect(self._fill)
        top.addWidget(QLabel("Show"))
        top.addWidget(self.cmb, 1)
        v.addLayout(top)
        self.tbl = QTableWidget(0, 4)
        self.tbl.setHorizontalHeaderLabels(["Episode", "Time", "Problem", "Line"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        h = self.tbl.horizontalHeader()
        for c in (0, 1, 2):
            h.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.tbl.cellDoubleClicked.connect(self._open)
        v.addWidget(self.tbl, 1)
        row = QHBoxLayout()
        if csv_path:
            b_csv = QPushButton("📄 Open the CSV")
            b_csv.clicked.connect(lambda: _open_path(csv_path))
            row.addWidget(b_csv)
        row.addStretch(1)
        b_close = QPushButton("Close")
        b_close.clicked.connect(self.accept)
        row.addWidget(b_close)
        v.addLayout(row)
        self._fill()

    def _fill(self, *_):
        kind = self.cmb.currentData()
        shown = [r for r in self.rows if not kind or r["kind"] == kind]
        self.tbl.setRowCount(len(shown))
        for i, r in enumerate(shown):
            cells = [r.get("episode", ""), _t(r["time"]), r["what"], r["text"]]
            for c, text in enumerate(cells):
                it = QTableWidgetItem(text)
                if c == 0:
                    it.setData(Qt.ItemDataRole.UserRole, r)
                if c == 2:
                    it.setForeground(QBrush(QColor(COLORS.get(r["kind"], "#ffffff"))))
                self.tbl.setItem(i, c, it)

    def _open(self, row: int, _col: int):
        r = self.tbl.item(row, 0).data(Qt.ItemDataRole.UserRole)
        path = r.get("autosave", "")
        if not path or not os.path.isfile(path):
            return
        try:
            win = self.win
            if hasattr(win, "_maybe_save") and not win._maybe_save():
                return
            win._open_project_file(path, as_autosave=True)
            if hasattr(win, "set_workspace"):
                win.set_workspace("dub")
            if hasattr(win, "show_editor"):
                win.show_editor()
            win.seek(max(0.0, float(r["time"]) - 0.3))
            # the Batch window is owned by the editor and always stays on top of
            # it: put it down, or the opened episode is hidden behind it
            batch = getattr(win, "batch", None)
            if batch is not None and batch.isVisible():
                batch.showMinimized()
            if win.isMinimized():
                win.showNormal()
            win.raise_()
            win.activateWindow()
            self._select_line(r.get("seg_id", ""))
            # keep this list at hand, out of the way, for the next line
            self.move(win.geometry().right() - self.width() - 20,
                      win.geometry().bottom() - self.height() - 60)
        except Exception as e:
            print(f"[qc] could not open {path}: {e}")

    def _select_line(self, seg_id: str):
        """Show the line in 📝 Transcript (Smart Review) / 🌐 Translation."""
        right = getattr(self.win, "right", None)
        if right is None or not seg_id:
            return
        for tbl in (right.tbl_transcript, right.tbl_translation):
            for row in range(tbl.rowCount()):
                if right._row_id(tbl, row) == seg_id:
                    tbl.selectRow(row)
                    tbl.scrollToItem(tbl.item(row, 0))
                    break


def _open_path(path: str):
    try:
        from ui.main_window import open_path

        open_path(path)
    except Exception:
        pass
