"""
about_dialog.py - Help › About: the logo, the version with Check for updates,
the seller's pages (Facebook, Telegram, YouTube) and Contact admin.

The pages come with the prices (core/pricing.py: the Admin types them once,
they are shipped in assets/prices.json and can be changed for everyone through
version.json). A page that is not set is not shown.
"""

import datetime as dt
import os

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication, QPixmap
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout,
    QWidget,
)

from core import __version__, pricing
from core.appinfo import APP_NAME
from core.media import APP_DIR

QSS = """
QDialog#About { background: #11151d; }
QWidget#AbBody { background: transparent; }
QLabel#AbTitle { color: white; font-size: 20pt; font-weight: 800; }
QLabel#AbMuted { color: #8b93a3; }
QLabel#AbHead { color: #8b93a3; font-weight: 700; letter-spacing: 1px; padding-top: 8px; }
QPushButton#AbCheck { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #14B8A6,
    stop:1 #8B5CF6); color: white; font-weight: 700; border: none; border-radius: 6px;
    padding: 9px 18px; }
QPushButton#AbCheck:hover { background: #8B5CF6; }
QPushButton#AbLink { background: #1a1f2b; color: #e8eaf0; border: 1px solid #262d3b;
    border-radius: 6px; padding: 11px 14px; text-align: left; font-size: 10.5pt; }
QPushButton#AbLink:hover { background: #232a39; border-color: #8B5CF6; }
QPushButton#AbEdit { background: transparent; color: #8b93a3; border: none; }
QPushButton#AbEdit:hover { color: white; }
"""

LINKS = [  # key, badge colour, glyph, text
    ("facebook", "#1877F2", "f", "Official Facebook Page"),
    ("telegram_channel", "#229ED9", "✈", "Official Telegram Channel"),
    ("youtube", "#FF0000", "▶", "YouTube Channel"),
]


def badge(colour: str, glyph: str, size: int = 26):
    """A small coloured square with a white sign (like the apps' own icons)."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QColor, QFont, QIcon, QPainter

    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    qp = QPainter(pm)
    qp.setRenderHint(QPainter.RenderHint.Antialiasing)
    qp.setBrush(QColor(colour))
    qp.setPen(Qt.PenStyle.NoPen)
    qp.drawRoundedRect(QRectF(0, 0, size, size), 5, 5)
    f = QFont()
    f.setBold(True)
    f.setPixelSize(int(size * 0.6))
    qp.setFont(f)
    qp.setPen(QColor("white"))
    qp.drawText(QRectF(0, 0, size, size), Qt.AlignmentFlag.AlignCenter, glyph)
    qp.end()
    return QIcon(pm)


class AboutDialog(QDialog):
    def __init__(self, parent=None, on_check_updates=None):
        super().__init__(parent)
        self.setObjectName("About")
        self.setWindowTitle(f"About {APP_NAME}")
        self.setStyleSheet(QSS)
        self.setMinimumWidth(460)
        self._on_check = on_check_updates
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(36, 26, 36, 22)
        self.lay.setSpacing(10)
        self.body = QWidget()
        self.body.setObjectName("AbBody")
        self.lay.addWidget(self.body)
        self.fill()

    def fill(self):
        old = self.body
        self.body = QWidget()
        self.body.setObjectName("AbBody")
        self.lay.replaceWidget(old, self.body)
        old.deleteLater()
        lay = QVBoxLayout(self.body)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        data = pricing.load()

        logo = QLabel()
        pm = QPixmap(os.path.join(APP_DIR, "assets", "icon.png"))
        if not pm.isNull():
            logo.setPixmap(pm.scaled(96, 96, Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation))
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(logo)
        title = QLabel(APP_NAME)
        title.setObjectName("AbTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(title)
        sub = QLabel("AI Video Dubbing & Editor")
        sub.setObjectName("AbMuted")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(sub)
        self.btn_check = QPushButton(f"Check for Updates  v{__version__}")
        self.btn_check.setObjectName("AbCheck")
        self.btn_check.clicked.connect(self._check)
        lay.addWidget(self.btn_check, 0, Qt.AlignmentFlag.AlignCenter)
        lay.addSpacing(10)

        self.link_buttons = {}
        from PySide6.QtCore import QSize

        for key, colour, mark, text in LINKS:
            url = pricing.link_url(data.get(key, ""))
            if not url:
                continue
            b = QPushButton("   " + text)
            b.setIcon(badge(colour, mark))
            b.setIconSize(QSize(26, 26))
            b.setObjectName("AbLink")
            b.setToolTip(url)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, u=url: QDesktopServices.openUrl(QUrl(u)))
            lay.addWidget(b)
            self.link_buttons[key] = b

        contact = (data.get("contact") or "").strip()
        self.btn_contact = None
        if contact:
            head = QLabel("ADMIN CONTACTS")
            head.setObjectName("AbHead")
            lay.addWidget(head)
            self.btn_contact = QPushButton(f"   Contact Admin   ·   {contact}")
            self.btn_contact.setIcon(badge("#8B5CF6", "✉"))
            self.btn_contact.setIconSize(QSize(26, 26))
            self.btn_contact.setObjectName("AbLink")
            self.btn_contact.setCursor(Qt.CursorShape.PointingHandCursor)
            self.btn_contact.clicked.connect(lambda: self._contact(contact))
            lay.addWidget(self.btn_contact)

        lay.addSpacing(8)
        year = max(2026, dt.date.today().year)
        foot = QLabel(f"© {year} {APP_NAME}. All Rights Reserved.")
        foot.setObjectName("AbMuted")
        foot.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(foot)
        dev = (data.get("developer") or "").strip()
        if dev:
            d = QLabel(f"Developed with ❤ by {dev}")
            d.setObjectName("AbMuted")
            d.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(d)
        if self._is_owner():
            e = QPushButton("✏  Edit pages and contact (Admin)")
            e.setObjectName("AbEdit")
            e.clicked.connect(self.edit_links)
            lay.addWidget(e, 0, Qt.AlignmentFlag.AlignCenter)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        lay.addWidget(close, 0, Qt.AlignmentFlag.AlignRight)

    @staticmethod
    def _is_owner() -> bool:
        try:
            from core import admin

            return admin.is_owner()
        except Exception:
            return False

    def _check(self):
        if self._on_check:
            self.accept()
            self._on_check()

    def _contact(self, contact: str):
        url = pricing.link_url(contact)
        if url:
            QDesktopServices.openUrl(QUrl(url))
            return
        QGuiApplication.clipboard().setText(contact)
        if self.btn_contact is not None:
            self.btn_contact.setText(f"   ✓ Copied   ·   {contact}")

    def edit_links(self):
        """Admin: the pages customers see (saved with the prices)."""
        data = dict(pricing.load())
        dlg = QDialog(self)
        dlg.setWindowTitle("About – pages and contact")
        form = QFormLayout(dlg)
        eds = {}
        for key, label in (("facebook", "Facebook page"), ("telegram_channel", "Telegram channel"),
                           ("youtube", "YouTube channel"), ("contact", "Contact admin"),
                           ("developer", "Developed by")):
            ed = QLineEdit(data.get(key, ""))
            ed.setMinimumWidth(320)
            ed.setPlaceholderText({"facebook": "https://facebook.com/...",
                                   "telegram_channel": "t.me/... or @name",
                                   "youtube": "https://youtube.com/@...",
                                   "contact": "Telegram @name / 0xx xxx xxx",
                                   "developer": "your name"}[key])
            form.addRow(label, ed)
            eds[key] = ed
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save
                              | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        for key, ed in eds.items():
            data[key] = ed.text().strip()
        pricing.save(data)
        self.fill()
