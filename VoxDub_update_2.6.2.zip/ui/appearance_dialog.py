"""
appearance_dialog.py - 🎨 Appearance & language: English / ខ្មែរ, Auto / Light /
Dark, and the app colour. Every change shows at once (no restart).
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QButtonGroup, QDialog, QGridLayout, QHBoxLayout, QLabel, QPushButton, QRadioButton,
    QVBoxLayout,
)

from core import i18n
from ui import appearance


class AppearanceDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Appearance & language")
        self.setMinimumWidth(460)
        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        lay.addWidget(self._head("🌐  Language"))
        row = QHBoxLayout()
        self.lang_group = QButtonGroup(self)
        self.lang_buttons = {}
        for key, name in i18n.LANGUAGES.items():
            b = QRadioButton(name)
            b.setChecked(i18n.language() == key)
            b.toggled.connect(lambda on, k=key: on and self._lang(k))
            self.lang_group.addButton(b)
            self.lang_buttons[key] = b
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        lay.addWidget(self._head("🌓  Light / Dark"))
        row = QHBoxLayout()
        self.theme_group = QButtonGroup(self)
        self.theme_buttons = {}
        for key, name in appearance.THEMES.items():
            b = QRadioButton(name)
            b.setChecked(appearance.theme_choice() == key)
            b.toggled.connect(lambda on, k=key: on and appearance.set_theme(k))
            self.theme_group.addButton(b)
            self.theme_buttons[key] = b
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)

        lay.addWidget(self._head("🎨  Colour"))
        grid = QGridLayout()
        grid.setSpacing(8)
        self.colour_buttons = {}
        for i, (key, (name, col)) in enumerate(appearance.ACCENTS.items()):
            b = QPushButton(name)
            b.setCheckable(True)
            b.setChecked(appearance.accent_choice() == key)
            b.setMinimumHeight(38)
            fill = col or "qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #14B8A6, " \
                          "stop:1 #8B5CF6)"
            b.setStyleSheet(
                f"QPushButton {{ background: {fill}; color: white; font-weight: 700; "
                "border: 2px solid transparent; border-radius: 9px; padding: 4px 10px; }"
                "QPushButton:checked { border: 3px solid white; }")
            b.clicked.connect(lambda _=False, k=key: self._accent(k))
            grid.addWidget(b, i // 4, i % 4)
            self.colour_buttons[key] = b
        lay.addLayout(grid)
        note = QLabel("The video, the timeline and the waveforms stay dark, like other "
                      "video editors.")
        note.setObjectName("MutedLabel")
        note.setWordWrap(True)
        lay.addWidget(note)
        ok = QPushButton("Close")
        ok.clicked.connect(self.accept)
        lay.addWidget(ok, 0, Qt.AlignmentFlag.AlignRight)

    @staticmethod
    def _head(text: str) -> QLabel:
        lb = QLabel(text)
        lb.setStyleSheet("font-weight: 700; font-size: 11pt; padding-top: 6px;")
        return lb

    def _lang(self, key: str):
        appearance.set_language(key)

    def _accent(self, key: str):
        for k, b in self.colour_buttons.items():
            b.setChecked(k == key)
        appearance.set_accent(key)
