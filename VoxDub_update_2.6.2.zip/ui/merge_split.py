"""
merge_split.py - "Merge & Split" tool window.

  🔗 Merge   join many videos (e.g. all exported episodes) into one long
             video, in the order of the list; optionally cut the result
             into parts of N minutes right after.
  ✂ Split   cut one long video into parts of N minutes.

Opened from Tools > Merge & Split, the top bar, or the batch dashboard
("Merge finished videos" fills the list with the exported episodes).
"""

import os
import time
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QProgressBar,
    QPushButton, QSpinBox, QTabWidget, QVBoxLayout, QWidget,
)

from core import joiner
from core.media import format_time
from ui.workers import TaskWorker

from core.media import VIDEO_FILTER  # noqa: E402
from core.media import VIDEO_EXT  # noqa: E402


def _hms(sec: float) -> str:
    return format_time(sec, False)


class MergeSplitDialog(QDialog):
    def __init__(self, window, output_dir: str):
        super().__init__(window)
        self.win = window
        self.output_dir = output_dir
        self.worker: Optional[TaskWorker] = None
        self._formats: Dict[str, joiner.StreamFormat] = {}
        self._started = 0.0
        self._last_folder = ""
        self.setWindowTitle("SARIKA VOXDUB PRO – Merge & Split")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.setMinimumSize(820, 620)
        self.resize(980, 720)
        self.setAcceptDrops(True)
        self._build()
        self._probe = QTimer(self)          # read video info without freezing
        self._probe.setInterval(20)
        self._probe.timeout.connect(self._probe_next)

    # ------------------------------------------------------------------ #
    def _build(self):
        def btn(text, slot, tip="", name=""):
            b = QPushButton(text)
            b.clicked.connect(slot)
            if tip:
                b.setToolTip(tip)
            if name:
                b.setObjectName(name)
            return b

        top = QWidget()
        top.setObjectName("TopBar")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(16, 10, 16, 10)
        title = QLabel("🎙️ SARIKA VOXDUB")
        title.setObjectName("AppTitle")
        pro = QLabel("PRO")
        pro.setObjectName("AppTitlePro")
        sub = QLabel("Merge & Split videos")
        sub.setObjectName("DashSubtitle")
        tl.addWidget(title)
        tl.addWidget(pro)
        tl.addSpacing(14)
        tl.addWidget(sub)
        tl.addStretch(1)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._merge_page(btn), "🔗  Merge videos")
        self.tabs.addTab(self._split_page(btn), "✂  Split a video")

        # progress (shared)
        self.progress = QProgressBar()
        self.progress.setObjectName("BigBar")
        self.status = QLabel("")
        self.status.setObjectName("MutedLabel")
        self.status.setWordWrap(True)
        self.btn_open = btn("📂 Open folder", self._open_result)
        self.btn_open.setVisible(False)
        self.btn_cancel = btn("■ Cancel", self._cancel, "", "DangerButton")
        self.btn_cancel.setVisible(False)
        prow = QHBoxLayout()
        prow.addWidget(self.progress, 1)
        prow.addWidget(self.btn_cancel)
        prow.addWidget(self.btn_open)

        body = QWidget()
        bl = QVBoxLayout(body)
        bl.setContentsMargins(16, 12, 16, 14)
        bl.addWidget(self.tabs, 1)
        bl.addLayout(prow)
        bl.addWidget(self.status)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(top)
        lay.addWidget(body, 1)
        self._update_merge_info()
        self._update_split_info()

    def _merge_page(self, btn) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(12, 12, 12, 12)
        head = QHBoxLayout()
        t = QLabel("Videos to join (top to bottom)")
        t.setObjectName("SectionTitle")
        head.addWidget(t)
        head.addStretch(1)
        head.addWidget(btn("➕ Videos…", self._add_files, "", "AccentButton"))
        head.addWidget(btn("📁 Folder…", self._add_folder,
                           "Add every video in a folder (sorted EP1, EP2 … EP10)"))
        self.list = QListWidget()
        self.list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.list.setAlternatingRowColors(True)
        self.list.model().rowsMoved.connect(lambda *_: self._update_merge_info())
        tools = QHBoxLayout()
        for text, slot, tip in (("▲", lambda: self._move(-1), "Move up"),
                                ("▼", lambda: self._move(1), "Move down"),
                                ("🔤 Sort by name", self._sort, "EP1, EP2 … EP10 (natural order)"),
                                ("Remove", self._remove, ""),
                                ("Clear", self._clear, "")):
            b = btn(text, slot, tip)
            if text in ("▲", "▼"):
                b.setFixedWidth(34)
            tools.addWidget(b)
        tools.addStretch(1)
        hint = QLabel("Drag rows to change the order")
        hint.setObjectName("MutedLabel")
        tools.addWidget(hint)
        self.lb_merge = QLabel()
        self.lb_merge.setObjectName("BaseSummary")
        self.lb_merge.setWordWrap(True)

        self.ed_merge_out = QLineEdit(os.path.join(self.output_dir, "merged.mp4"))
        b_out = btn("…", self._browse_merge_out)
        b_out.setFixedWidth(36)
        out_row = QHBoxLayout()
        out_row.addWidget(self.ed_merge_out, 1)
        out_row.addWidget(b_out)
        self.cmb_merge_mode = QComboBox()
        self.cmb_merge_mode.addItem("Auto – fast join when all videos have the same format",
                                    "auto")
        self.cmb_merge_mode.addItem("Always re-encode (videos of different sizes / sources)",
                                    "reencode")
        self.chk_then_split = QCheckBox("Then split the merged video into parts of")
        self.spn_then_min = QSpinBox()
        self.spn_then_min.setRange(1, 600)
        self.spn_then_min.setValue(10)
        self.spn_then_min.setSuffix(" min")
        self.chk_then_split.toggled.connect(lambda *_: self._update_merge_info())
        self.spn_then_min.valueChanged.connect(lambda *_: self._update_merge_info())
        then_row = QHBoxLayout()
        then_row.addWidget(self.chk_then_split)
        then_row.addWidget(self.spn_then_min)
        then_row.addStretch(1)
        self.ed_part_name, self.spn_part_start, part_row = self._part_name_row()
        for w in (self.ed_part_name, self.spn_part_start):
            w.setEnabled(False)
            self.chk_then_split.toggled.connect(w.setEnabled)
        self.ed_part_name.textChanged.connect(lambda *_: self._update_merge_info())
        self.spn_part_start.valueChanged.connect(lambda *_: self._update_merge_info())
        form = QFormLayout()
        form.addRow("Save as", out_row)
        form.addRow("Join mode", self.cmb_merge_mode)
        form.addRow("", then_row)
        form.addRow("Part name", part_row)
        self.btn_merge = btn("🔗  Merge videos", self.start_merge, "", "TopAuto")
        go = QHBoxLayout()
        go.addStretch(1)
        go.addWidget(self.btn_merge)

        v.addLayout(head)
        v.addWidget(self.list, 1)
        v.addLayout(tools)
        v.addWidget(self.lb_merge)
        v.addLayout(form)
        v.addLayout(go)
        return page

    def _part_name_row(self):
        """Name of the parts (with {n} = part number) + the first number."""
        ed = QLineEdit()
        ed.setPlaceholderText("e.g.  រឿង AI និយាយខ្មែរ ភាគ{n}")
        ed.setToolTip("The name every part gets. {n} = the part number (01, 02 …).\n"
                      "e.g. «រឿង AI និយាយខ្មែរ ភាគ{n}» → រឿង AI និយាយខ្មែរ ភាគ01.mp4, ភាគ02.mp4 …\n"
                      "A number at the end (ភាគ01, ភាគ06) = the first part, counted up from there.\n"
                      "Without {n} or a number: …_part01, _part02 … at the end.\n"
                      "Empty = the name of the video.")
        spn = QSpinBox()
        spn.setRange(0, 9999)
        spn.setValue(1)
        spn.setPrefix("from ")
        spn.setToolTip("Number of the first part – e.g. 6 when ភាគ01–05 are already done")
        b = QPushButton("{n}")
        b.setFixedWidth(40)
        b.setToolTip("Put the part number here")
        b.clicked.connect(lambda: (ed.insert("{n}"), ed.setFocus()))
        row = QHBoxLayout()
        row.addWidget(ed, 1)
        row.addWidget(b)
        row.addWidget(spn)
        return ed, spn, row

    @staticmethod
    def _names_example(name: str, start: int, count: int, typed: bool = True) -> str:
        """File names of the parts; `typed` = a Part name the user wrote (a
        number at its end is the first part: see joiner.resolve_part_name)."""
        if typed:
            t, start = joiner.resolve_part_name(name, start)
        else:
            t = joiner.part_template(name)
        digits = max(2, len(str(start + count - 1)))
        first = joiner.part_name(t, start, digits) + ".mp4"
        if count < 2:
            return first
        return f"{first} … {joiner.part_name(t, start + count - 1, digits)}.mp4"

    def _split_page(self, btn) -> QWidget:
        page = QWidget()
        v = QVBoxLayout(page)
        v.setContentsMargins(12, 12, 12, 12)
        t = QLabel("Cut one long video into parts")
        t.setObjectName("SectionTitle")
        self.ed_split_in = QLineEdit()
        self.ed_split_in.setPlaceholderText("Choose a video (or drop it here)")
        self.ed_split_in.editingFinished.connect(self._split_input_changed)
        b_in = btn("…", self._browse_split_in)
        b_in.setFixedWidth(36)
        in_row = QHBoxLayout()
        in_row.addWidget(self.ed_split_in, 1)
        in_row.addWidget(b_in)
        self.spn_min = QSpinBox()
        self.spn_min.setRange(0, 600)
        self.spn_min.setValue(10)
        self.spn_min.setSuffix(" min")
        self.spn_sec = QSpinBox()
        self.spn_sec.setRange(0, 59)
        self.spn_sec.setSuffix(" s")
        len_row = QHBoxLayout()
        len_row.addWidget(self.spn_min)
        len_row.addWidget(self.spn_sec)
        for m in (1, 3, 5, 10, 15, 30, 60):
            b = QPushButton(f"{m}m")
            b.setMinimumWidth(52)
            b.setToolTip(f"Parts of {m} minutes")
            b.clicked.connect(lambda _=False, m=m: (self.spn_min.setValue(m),
                                                    self.spn_sec.setValue(0)))
            len_row.addWidget(b)
        len_row.addStretch(1)
        self.spn_min_last = QSpinBox()
        self.spn_min_last.setRange(0, 600)
        self.spn_min_last.setValue(30)
        self.spn_min_last.setSuffix(" s")
        self.spn_min_last.setToolTip("A last part shorter than this is added to the part "
                                     "before it (0 = always keep it)")
        self.cmb_split_mode = QComboBox()
        self.cmb_split_mode.addItem("Exact – every part exactly this long (re-encodes)", True)
        self.cmb_split_mode.addItem("Fast – no re-encode, cuts at the nearest keyframe "
                                    "(± a few seconds)", False)
        self.ed_split_out = QLineEdit(self.output_dir)
        b_out = btn("…", self._browse_split_out)
        b_out.setFixedWidth(36)
        out_row = QHBoxLayout()
        out_row.addWidget(self.ed_split_out, 1)
        out_row.addWidget(b_out)
        self.ed_split_name, self.spn_split_start, split_name_row = self._part_name_row()
        self.ed_split_name.textChanged.connect(lambda *_: self._update_split_info())
        self.spn_split_start.valueChanged.connect(lambda *_: self._update_split_info())
        for w in (self.spn_min, self.spn_sec, self.spn_min_last):
            w.valueChanged.connect(lambda *_: self._update_split_info())
        self.lb_split = QLabel()
        self.lb_split.setObjectName("BaseSummary")
        self.lb_split.setWordWrap(True)
        form = QFormLayout()
        form.setVerticalSpacing(10)
        form.addRow("Video", in_row)
        form.addRow("Part length", len_row)
        form.addRow("Short last part", self.spn_min_last)
        form.addRow("Cut mode", self.cmb_split_mode)
        form.addRow("Save to folder", out_row)
        form.addRow("Part name", split_name_row)
        self.btn_split = btn("✂  Split video", self.start_split, "", "TopAuto")
        go = QHBoxLayout()
        go.addStretch(1)
        go.addWidget(self.btn_split)
        v.addWidget(t)
        v.addLayout(form)
        v.addWidget(self.lb_split)
        v.addStretch(1)
        v.addLayout(go)
        self._split_duration = 0.0
        return page

    # ------------------------------------------------------------------ #
    # Merge list
    # ------------------------------------------------------------------ #
    def paths(self) -> List[str]:
        return [self.list.item(i).data(Qt.ItemDataRole.UserRole)
                for i in range(self.list.count())]

    def set_videos(self, paths: List[str], out_path: str = ""):
        """Fill the merge list (used by the batch dashboard)."""
        self.list.clear()
        self.add_videos(paths, sort=False)
        if out_path:
            self.ed_merge_out.setText(out_path)
        self.tabs.setCurrentIndex(0)

    def add_videos(self, paths: List[str], sort: bool = False):
        known = {os.path.normcase(p) for p in self.paths()}
        new = []
        for p in paths:
            if os.path.isdir(p):
                from core.batch import find_videos
                new += sorted(find_videos(p), key=joiner.natural_key)
            elif os.path.isfile(p) and p.lower().endswith(VIDEO_EXT):
                new.append(os.path.abspath(p))
        if sort:
            new.sort(key=joiner.natural_key)
        for p in new:
            if os.path.normcase(p) in known:
                continue
            known.add(os.path.normcase(p))
            it = QListWidgetItem(os.path.basename(p))
            it.setData(Qt.ItemDataRole.UserRole, p)
            it.setToolTip(p)
            self.list.addItem(it)
        if new and not self._last_folder:
            self._last_folder = os.path.dirname(new[0])
        self._update_merge_info()
        self._probe.start()

    def _add_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Videos to merge", self._last_folder,
                                                VIDEO_FILTER)
        self.add_videos(paths, sort=True)

    def _add_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Merge all videos in a folder",
                                             self._last_folder)
        if d:
            self.add_videos([d])
            name = os.path.basename(os.path.normpath(d)) or "merged"
            self.ed_merge_out.setText(os.path.join(self.output_dir, f"{name}_merged.mp4"))

    def _move(self, step: int):
        rows = sorted({self.list.row(i) for i in self.list.selectedItems()},
                      reverse=step > 0)
        for r in rows:
            j = r + step
            if 0 <= j < self.list.count():
                it = self.list.takeItem(r)
                self.list.insertItem(j, it)
                it.setSelected(True)
        self._update_merge_info()

    def _sort(self):
        paths = sorted(self.paths(), key=joiner.natural_key)
        self.list.clear()
        self.add_videos(paths)

    def _remove(self):
        for it in self.list.selectedItems():
            self.list.takeItem(self.list.row(it))
        self._update_merge_info()

    def _clear(self):
        self.list.clear()
        self._update_merge_info()

    def _browse_merge_out(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save merged video as",
                                              self.ed_merge_out.text(), "MP4 video (*.mp4)")
        if path:
            self.ed_merge_out.setText(path if path.lower().endswith(".mp4") else path + ".mp4")

    def _probe_next(self):
        """Read the format of one listed video per tick (fast join possible?)."""
        for p in self.paths() + ([self.ed_split_in.text().strip()]
                                 if self.ed_split_in.text().strip() else []):
            if p not in self._formats and os.path.isfile(p):
                try:
                    self._formats[p] = joiner.stream_format(p)
                except Exception:
                    self._formats[p] = joiner.StreamFormat()
                self._update_merge_info()
                self._update_split_info()
                return
        self._probe.stop()

    def _update_merge_info(self):
        paths = self.paths()
        for i, p in enumerate(paths):
            f = self._formats.get(p)
            it = self.list.item(i)
            text = f"{i + 1:>3}.  {os.path.basename(p)}"
            if f and f.duration:
                text += f"    ·  {_hms(f.duration)}  ·  {f.width}×{f.height}"
            if it.text() != text:
                it.setText(text)
        if len(paths) < 2:
            self.lb_merge.setText("Add 2 or more videos. They are joined from top to bottom.")
            self.btn_merge.setEnabled(False)
            return
        self.btn_merge.setEnabled(self.worker is None)
        known = [self._formats[p] for p in paths if p in self._formats]
        total = sum(f.duration for f in known)
        text = f"{len(paths)} videos  ·  total {_hms(total)}"
        if len(known) < len(paths):
            text += f"  (reading {len(known)}/{len(paths)}…)"
        elif joiner.can_merge_fast(known):
            text += "  ·  ⚡ same format – fast join (no quality loss, takes seconds)"
        else:
            w, h = joiner.merge_size(known)
            text += f"  ·  different formats – will be re-encoded to {w}×{h}"
        if self.chk_then_split.isChecked() and total:
            cuts = joiner.plan_split(total, self.spn_then_min.value() * 60, 30)
            text += f"\nThen split into {len(cuts) + 1} parts of {self.spn_then_min.value()} min"
            name = self.ed_part_name.text().strip() or os.path.splitext(
                os.path.basename(self.ed_merge_out.text().strip() or "merged"))[0]
            text += "  →  " + self._names_example(name, self.spn_part_start.value(),
                                                   len(cuts) + 1,
                                                   bool(self.ed_part_name.text().strip()))
        self.lb_merge.setText(text)

    # ------------------------------------------------------------------ #
    # Split
    # ------------------------------------------------------------------ #
    def set_split_video(self, path: str):
        self.ed_split_in.setText(path)
        self._split_input_changed()
        self.tabs.setCurrentIndex(1)

    def _browse_split_in(self):
        path, _ = QFileDialog.getOpenFileName(self, "Video to split", self._last_folder,
                                              VIDEO_FILTER)
        if path:
            self.set_split_video(path)

    def _split_name_typed(self) -> bool:
        """The Part name was written by the user (not the video's name filled in)."""
        text = self.ed_split_name.text().strip()
        return bool(text) and text != getattr(self, "_split_name_auto", None)

    def _browse_split_out(self):
        d = QFileDialog.getExistingDirectory(self, "Save parts to", self.ed_split_out.text())
        if d:
            self.ed_split_out.setText(d)

    def _split_input_changed(self):
        p = self.ed_split_in.text().strip()
        if p:
            self.ed_split_name.setText(os.path.splitext(os.path.basename(p))[0])
            self._split_name_auto = self.ed_split_name.text()
            self._probe.start()
        self._update_split_info()

    def _part_seconds(self) -> int:
        return self.spn_min.value() * 60 + self.spn_sec.value()

    def _update_split_info(self):
        p = self.ed_split_in.text().strip()
        f = self._formats.get(p)
        sec = self._part_seconds()
        if not p:
            self.lb_split.setText("Choose the video to cut.")
        elif f is None:
            self.lb_split.setText("Reading the video…")
        elif not f.duration:
            self.lb_split.setText("❌ This file could not be read.")
        elif sec < 5:
            self.lb_split.setText("Set a part length of at least 5 seconds.")
        else:
            cuts = joiner.plan_split(f.duration, sec, self.spn_min_last.value())
            if not cuts:
                self.lb_split.setText(f"The video is {_hms(f.duration)} – shorter than one "
                                      "part, nothing to split.")
            else:
                lens = joiner.part_lengths(f.duration, cuts)
                text = f"Video {_hms(f.duration)}  →  {len(lens)} parts:  "
                full = sum(1 for x in lens[:-1] if abs(x - sec) < 0.5)
                text += f"{full} × {_hms(sec)}"
                if abs(lens[-1] - sec) >= 0.5:
                    text += f"  +  last part {_hms(lens[-1])}"
                else:
                    text = text.replace(f"{full} ×", f"{full + 1} ×")
                name = self.ed_split_name.text().strip() or os.path.splitext(
                    os.path.basename(p))[0]
                text += "\n" + self._names_example(name, self.spn_split_start.value(), len(lens),
                                                    self._split_name_typed())
                self.lb_split.setText(text)
        self.btn_split.setEnabled(self.worker is None and bool(p))

    # ------------------------------------------------------------------ #
    # Running
    # ------------------------------------------------------------------ #
    def _busy(self, on: bool):
        self.btn_merge.setEnabled(not on and len(self.paths()) >= 2)
        self.btn_split.setEnabled(not on and bool(self.ed_split_in.text().strip()))
        self.btn_cancel.setVisible(on)
        if on:
            self.btn_open.setVisible(False)
            self.progress.setValue(0)
            self._started = time.time()

    def _run(self, title: str, fn, done):
        self.worker = TaskWorker(fn, title, self)
        self.worker.progress.connect(self._on_progress)
        self.worker.done.connect(lambda r: self._finish(title, r, done))
        self.worker.failed.connect(lambda e: self._failed(title, e))
        self._busy(True)
        self.win.log(f"▶ {title}")
        self.worker.start()

    def _on_progress(self, pct: int, msg: str):
        self.progress.setValue(pct)
        el = time.time() - self._started
        if 5 < pct < 100 and el > 10:
            msg += f"   ·   ~{_hms(el * (100 - pct) / pct)} left"
        self.status.setText(msg)

    def _finish(self, title, result, done):
        self.worker = None
        self._busy(False)
        self.progress.setValue(100)
        msg = done(result)
        took = _hms(time.time() - self._started)
        self.status.setText(f"✅ {msg}   ({took})")
        self.win.log(f"✔ {title}: {msg}")
        self.btn_open.setVisible(True)
        self._update_merge_info()
        self._update_split_info()

    def _failed(self, title, err: str):
        self.worker = None
        self._busy(False)
        self.status.setText("❌ " + err.splitlines()[0])
        self.win.log(f"✖ {title}: {err}")
        self._update_merge_info()
        self._update_split_info()
        if "Cancelled" not in err:
            QMessageBox.warning(self, title, err)

    def _cancel(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.status.setText("Cancelling…")

    def start_merge(self):
        paths = self.paths()
        out = self.ed_merge_out.text().strip()
        if len(paths) < 2 or not out or self.worker:
            return
        if not out.lower().endswith(".mp4"):
            out += ".mp4"
        if os.path.exists(out):
            ans = QMessageBox.question(self, "Merge", f"{os.path.basename(out)} already exists."
                                                      "\nReplace it?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        mode = self.cmb_merge_mode.currentData()
        split_sec = self.spn_then_min.value() * 60 if self.chk_then_split.isChecked() else 0
        part_name, part_start = self.ed_part_name.text().strip(), self.spn_part_start.value()
        out_dir = os.path.dirname(os.path.abspath(out))

        def job(progress, should_stop):
            scale = (lambda p, m: progress(int(p * 0.6), m)) if split_sec else progress
            res = joiner.merge_videos(paths, out, mode, scale, should_stop)
            if split_sec:
                info = joiner.stream_format(out)
                if joiner.plan_split(info.duration, split_sec, 30):
                    res["split"] = joiner.split_video(
                        out, split_sec, out_dir, exact=True, min_last=30, name=part_name,
                        progress=lambda p, m: progress(60 + int(p * 0.4), m),
                        should_stop=should_stop, start=part_start)
            return res

        def done(res):
            self._result_folder = os.path.dirname(res["video"])
            how = "fast join" if res["fast"] else "re-encoded"
            msg = f"Merged {res['count']} videos ({how}, {_hms(res['duration'])}): {res['video']}"
            if res.get("split"):
                msg += f"\nSplit into {len(res['split']['parts'])} parts in {out_dir}"
            return msg

        self._run("Merge videos", job, done)

    def start_split(self):
        p = self.ed_split_in.text().strip()
        sec = self._part_seconds()
        if not p or self.worker:
            return
        if not os.path.isfile(p):
            QMessageBox.warning(self, "Split", "The video file was not found.")
            return
        if sec < 5:
            QMessageBox.information(self, "Split", "Set a part length of at least 5 seconds.")
            return
        out_dir = self.ed_split_out.text().strip() or self.output_dir
        exact = bool(self.cmb_split_mode.currentData())
        min_last = self.spn_min_last.value()
        name = self.ed_split_name.text().strip()
        if name and not self._split_name_typed():
            name += "_part{n}"          # the video's own name: "EP1" is not part 1
        first = self.spn_split_start.value()

        def done(res):
            self._result_folder = out_dir
            return f"Split into {len(res['parts'])} parts in {out_dir}"

        self._run("Split video",
                  lambda prog, stop: joiner.split_video(p, sec, out_dir, exact, min_last, name,
                                                        prog, stop, start=first),
                  done)

    def _open_result(self):
        from ui.main_window import open_path
        open_path(getattr(self, "_result_folder", self.output_dir))

    # ------------------------------------------------------------------ #
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [os.path.normpath(u.toLocalFile()) for u in event.mimeData().urls()]
        if self.tabs.currentIndex() == 1 and paths and os.path.isfile(paths[0]):
            self.set_split_video(paths[0])
        else:
            self.add_videos(paths, sort=True)

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            ans = QMessageBox.question(self, "Merge & Split", "Still working. Cancel it?")
            if ans != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.worker.stop()
            self.worker.wait(5000)
        super().closeEvent(event)
