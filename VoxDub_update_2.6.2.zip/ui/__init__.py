"""SARIKA VOXDUB PRO user interface (PySide6)."""

try:                                     # before Qt Multimedia starts (see core/crashlog)
    from core.crashlog import safe_video_decoding as _svd
    _svd()
except Exception:
    pass
