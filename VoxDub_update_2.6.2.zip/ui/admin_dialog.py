"""
admin_dialog.py - Help › Admin – Customers & keys (only on the seller's PC).

A small customer book: who bought, their Machine ID, until when, and the key.
Make a key for a new customer, renew one (the days are added to what is
left), copy the key or a ready-to-send message, search, export to CSV.
Everything is saved in %USERPROFILE%\\.voxdub_admin (back that folder up).
"""

import csv
import datetime as dt
import os

from PySide6.QtCore import QDate, Qt
from PySide6.QtGui import QBrush, QColor, QGuiApplication
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDialog, QFileDialog, QFormLayout, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton,
    QSplitter, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from core import admin, payments
from core import license as lic

COLS = ["Customer", "Contact", "Machine ID", "Plan", "Until", "Status", "Order / payment",
        "Note"]
PAY = ["pending", "approved", "rejected", "cancelled"]
STATE_COLOR = {"active": "#22c3a6", "soon": "#f5b041", "expired": "#ef5350", "none": "#8a93a0"}
DURATIONS = [(30, "1 month"), (90, "3 months"), (180, "6 months"), (365, "1 year"),
             (0, "Until a date…")]


class AdminDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("SARIKA VOXDUB PRO – Admin: customers & keys")
        self.resize(1180, 720)
        self.customers = admin.load()
        self._loading = False

        # ---- top bar
        self.ed_search = QLineEdit()
        self.ed_search.setPlaceholderText("🔍 Search name, contact, Machine ID, note…")
        self.ed_search.textChanged.connect(self._fill)
        b_new = QPushButton("＋ New customer")
        b_new.setObjectName("AccentButton")
        b_new.clicked.connect(self._new)
        b_paste = QPushButton("📋 Paste request")
        b_paste.setToolTip("Copy the customer's buy message (Machine ID + Order ID), then "
                           "click: the customer is found or added, with the order")
        b_paste.clicked.connect(self.paste_request)
        b_csv = QPushButton("⬇ Export CSV")
        b_csv.clicked.connect(self._export)
        b_dir = QPushButton("📂 Backup folder")
        b_dir.setToolTip(admin.ADMIN_DIR + "\nBack up this folder (it holds your signing key)")
        b_dir.clicked.connect(lambda: _open(admin.ADMIN_DIR))
        b_pay = QPushButton("🧾 Payments && audit")
        b_pay.setToolTip("Every payment request, and the log of what was done (checked for "
                         "changes)")
        b_pay.clicked.connect(self.show_payments)
        b_prices = QPushButton("💲 Prices")
        b_prices.setToolTip("The licence prices customers see on Plan & licence")
        b_prices.clicked.connect(self._prices)
        top = QHBoxLayout()
        top.addWidget(self.ed_search, 1)
        top.addWidget(b_paste)
        top.addWidget(b_new)
        top.addWidget(b_pay)
        top.addWidget(b_prices)
        top.addWidget(b_csv)
        top.addWidget(b_dir)
        self.lb_stats = QLabel("")
        self.lb_stats.setObjectName("MutedLabel")

        # ---- table
        self.tbl = QTableWidget(0, len(COLS))
        self.tbl.setHorizontalHeaderLabels(COLS)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.tbl.setSortingEnabled(True)
        h = self.tbl.horizontalHeader()
        for i in range(len(COLS)):
            h.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(len(COLS) - 1, QHeaderView.ResizeMode.Stretch)
        self.tbl.itemSelectionChanged.connect(self._show_selected)

        # ---- one customer
        box = QGroupBox("Customer")
        f = QFormLayout(box)
        self.ed_name = QLineEdit()
        self.ed_name.setPlaceholderText("Name or Facebook page")
        self.ed_contact = QLineEdit()
        self.ed_contact.setPlaceholderText("Phone / Telegram / Facebook")
        self.ed_mid = QLineEdit()
        self.ed_mid.setPlaceholderText("XXXX-XXXX-XXXX-XXXX  (Help › License on their PC)")
        self.ed_note = QLineEdit()
        self.ed_note.setPlaceholderText("Price paid, payment method…")
        self.ed_order = QLineEdit()
        self.ed_order.setPlaceholderText("VX-261022-4F2A (from the customer's message)")
        self.cmb_paid = QComboBox()
        for k in PAY:
            self.cmb_paid.addItem(payments.STATES[k], k)
        self.cmb_paid.setToolTip("Check the payment in ABA / KHQR yourself, then choose "
                                 "“Paid – checked”. A key is made only for a checked order, "
                                 "and only once.")
        self.cmb_paid.activated.connect(lambda *_: self._pay_changed())
        for ed in (self.ed_name, self.ed_contact, self.ed_mid, self.ed_note, self.ed_order):
            ed.editingFinished.connect(self._save_fields)
        f.addRow("Name", self.ed_name)
        f.addRow("Contact", self.ed_contact)
        f.addRow("Machine ID", self.ed_mid)
        orow = QHBoxLayout()
        orow.addWidget(self.ed_order, 1)
        orow.addWidget(self.cmb_paid)
        f.addRow("Order", orow)
        f.addRow("Note", self.ed_note)

        self.cmb_plan = QComboBox()
        for k, v in lic.PLANS.items():
            if k != "owner":
                self.cmb_plan.addItem(v, k)
        self.cmb_days = QComboBox()
        for d, label in DURATIONS:
            self.cmb_days.addItem(label, d)
        self._price_labels()
        self.dt_until = QDateEdit()
        self.dt_until.setCalendarPopup(True)
        self.dt_until.setDisplayFormat("yyyy-MM-dd")
        self.dt_until.setDate(QDate.currentDate().addDays(30))
        self.dt_until.setVisible(False)
        self.cmb_days.currentIndexChanged.connect(
            lambda *_: self.dt_until.setVisible(self.cmb_days.currentData() == 0))
        row = QHBoxLayout()
        row.addWidget(self.cmb_plan)
        row.addWidget(self.cmb_days)
        row.addWidget(self.dt_until)
        row.addStretch(1)
        f.addRow("Key", row)
        self.lb_status = QLabel("")
        f.addRow("Status", self.lb_status)

        self.btn_key = QPushButton("🔑 Make key")
        self.btn_key.setObjectName("AccentButton")
        self.btn_key.setToolTip("New customer: a key from today.\n"
                                "Renewal: the time is ADDED to what is left.")
        self.btn_key.clicked.connect(self._make_key)
        self.btn_copy = QPushButton("📋 Copy key")
        self.btn_copy.clicked.connect(lambda: self._copy(False))
        self.btn_msg = QPushButton("💬 Copy message")
        self.btn_msg.setToolTip("The key + how to activate, ready to paste in Telegram / Messenger")
        self.btn_msg.clicked.connect(lambda: self._copy(True))
        self.btn_del = QPushButton("🗑 Delete")
        self.btn_del.setObjectName("DangerButton")
        self.btn_del.clicked.connect(self._delete)
        brow = QHBoxLayout()
        for b in (self.btn_key, self.btn_copy, self.btn_msg):
            brow.addWidget(b)
        brow.addStretch(1)
        brow.addWidget(self.btn_del)
        f.addRow(brow)
        self.ed_key = QPlainTextEdit()
        self.ed_key.setReadOnly(True)
        self.ed_key.setFixedHeight(70)
        self.ed_key.setPlaceholderText("The key appears here")
        f.addRow(self.ed_key)
        self.lb_hist = QLabel("")
        self.lb_hist.setObjectName("MutedLabel")
        self.lb_hist.setWordWrap(True)
        f.addRow(self.lb_hist)
        self.box = box

        split = QSplitter(Qt.Orientation.Vertical)
        split.addWidget(self.tbl)
        split.addWidget(box)
        split.setSizes([400, 320])
        note = QLabel(f"This PC is the seller's PC (it has the signing key) – it never needs a "
                      f"license itself. Keys and customers: {admin.ADMIN_DIR}")
        note.setObjectName("MutedLabel")
        note.setWordWrap(True)
        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addWidget(self.lb_stats)
        lay.addWidget(split, 1)
        lay.addWidget(note)

        if admin.import_issued_log(self.customers):        # keys made with make_license.bat
            admin.save(self.customers)
        self._fill()
        self._show_selected()

    # ------------------------------------------------------------------ #
    def _visible(self):
        q = self.ed_search.text().strip().lower()
        out = []
        for c in self.customers:
            hay = " ".join(str(c.get(k, "")) for k in ("name", "contact", "machine", "note",
                                                        "order"))
            if not q or q in hay.lower():
                out.append(c)
        return out

    def _price_labels(self):
        """"1 month – $15": the price next to each duration."""
        from core import pricing

        data = pricing.load()
        for i, (d, label) in enumerate(DURATIONS):
            self.cmb_days.setItemText(i, pricing.label_for(d, data) or label)

    def _prices(self):
        from ui.prices_dialog import PricesDialog

        if PricesDialog(self).exec():
            self._price_labels()

    def _fill(self, *_):
        keep = self._current_id()
        self._loading = True
        self.tbl.setSortingEnabled(False)
        rows = self._visible()
        self.tbl.setRowCount(len(rows))
        for r, c in enumerate(rows):
            st = admin.status(c)
            vals = [c.get("name", ""), c.get("contact", ""), c.get("machine", ""),
                    lic.PLANS.get(c.get("plan", ""), c.get("plan", "")), c.get("expires", ""),
                    st["text"], self._order_text(c), c.get("note", "")]
            for k, v in enumerate(vals):
                it = QTableWidgetItem(str(v))
                if k == 0:
                    it.setData(Qt.ItemDataRole.UserRole, c["id"])
                if k == 5:
                    it.setForeground(QBrush(QColor(STATE_COLOR[st["state"]])))
                    # sort by days left, not by the text
                    it.setData(Qt.ItemDataRole.UserRole + 1, st["days"] if st["days"] is not None
                               else -99999)
                self.tbl.setItem(r, k, it)
        self.tbl.setSortingEnabled(True)
        self._loading = False
        states = [admin.status(c)["state"] for c in self.customers]
        self.lb_stats.setText(
            f"{len(self.customers)} customers  ·  ✅ {states.count('active')} active  ·  "
            f"⚠ {states.count('soon')} end within 5 days  ·  ⛔ {states.count('expired')} expired")
        self._select(keep)

    def _select(self, cid):
        for r in range(self.tbl.rowCount()):
            it = self.tbl.item(r, 0)
            if it and it.data(Qt.ItemDataRole.UserRole) == cid:
                self.tbl.selectRow(r)
                return

    def _current_id(self):
        rows = {i.row() for i in self.tbl.selectedIndexes()}
        if not rows:
            return None
        it = self.tbl.item(min(rows), 0)
        return it.data(Qt.ItemDataRole.UserRole) if it else None

    def _current(self):
        cid = self._current_id()
        return next((c for c in self.customers if c["id"] == cid), None)

    def _show_selected(self):
        if self._loading:
            return
        c = self._current()
        self.box.setEnabled(c is not None)
        if c is None:
            for ed in (self.ed_name, self.ed_contact, self.ed_mid, self.ed_note, self.ed_order):
                ed.clear()
            self.ed_key.clear()
            self.lb_status.setText("")
            self.lb_hist.setText("Click ＋ New customer, or pick one in the list.")
            return
        self.ed_name.setText(c.get("name", ""))
        self.ed_contact.setText(c.get("contact", ""))
        self.ed_mid.setText(c.get("machine", ""))
        self.ed_note.setText(c.get("note", ""))
        self.ed_order.setText(c.get("order", ""))
        rec = payments.find(c.get("order", "")) if c.get("order") else None
        st = rec["status"] if rec else "pending"
        if st == "issued":
            self.cmb_paid.setEnabled(False)
            self.cmb_paid.setToolTip(payments.STATES["issued"])
        else:
            self.cmb_paid.setEnabled(bool(c.get("order")))
            self.cmb_paid.setCurrentIndex(max(0, self.cmb_paid.findData(st)))
        self.cmb_plan.setCurrentIndex(max(0, self.cmb_plan.findData(c.get("plan", "pro"))))
        st = admin.status(c)
        self.lb_status.setText(f"<span style='color:{STATE_COLOR[st['state']]}'>{st['text']}</span>"
                               + (f"  (until {c['expires']})" if c.get("expires") else ""))
        self.ed_key.setPlainText(c.get("key", ""))
        self.btn_key.setText("🔑 Renew (add time)" if c.get("key") else "🔑 Make key")
        hist = c.get("history", [])
        self.lb_hist.setText("History: " + ", ".join(
            f"{h['issued']} → {h['expires']}" + (f" ({h['order']})" if h.get("order") else "")
            for h in hist[-6:]) if hist else "")

    def _save_fields(self):
        c = self._current()
        if c is None:
            return
        c["name"] = self.ed_name.text().strip()
        c["contact"] = self.ed_contact.text().strip()
        c["machine"] = admin.normalize_machine(self.ed_mid.text())
        c["note"] = self.ed_note.text().strip()
        c["order"] = self.ed_order.text().strip().upper()
        if c["order"] and payments.find(c["order"]) is None:
            payments.add(c["order"], c["id"], c["machine"])
        admin.save(self.customers)
        self._fill()

    # ------------------------------------------------------------------ #
    def _new(self):
        c = admin.new_customer("New customer", "")
        self.customers.insert(0, c)
        admin.save(self.customers)
        self.ed_search.clear()
        self._fill()
        self._select(c["id"])
        self.ed_name.setFocus()
        self.ed_name.selectAll()

    def _make_key(self):
        c = self._current()
        if c is None:
            return
        self._save_fields()
        c = self._current()
        if not c.get("name") or c["name"] == "New customer":
            QMessageBox.information(self, "Make key", "Type the customer's name first.")
            return
        if not admin.machine_ok(c.get("machine", "")):
            QMessageBox.information(self, "Make key",
                                    "Paste the customer's Machine ID first (16 characters, "
                                    "they find it in Help › License).")
            return
        days = self.cmb_days.currentData()
        if days:
            until = admin.renew_date(c, days)
        else:
            q = self.dt_until.date()
            until = dt.date(q.year(), q.month(), q.day())
        order = c.get("order", "")
        if order:
            why = payments.can_issue(order)
            if why:
                QMessageBox.information(self, "Make key", f"No key: {why}.\n\nCheck the "
                                        "payment in ABA / KHQR yourself, then choose “Paid – "
                                        "checked”." if "already" not in why else
                                        f"No key: {why}.\nA new payment needs a new Order ID.")
                return
        else:
            ans = QMessageBox.question(
                self, "Payment", f"{c['name']} has no payment request (Order ID).\n\n"
                "Make the key anyway – e.g. free, a gift or an old customer? It is written "
                "in the audit log.")
            if ans != QMessageBox.StandardButton.Yes:
                return
        if c.get("key"):
            ans = QMessageBox.question(self, "Renew", f"New key for {c['name']} until "
                                                      f"{until.isoformat()}?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        try:
            admin.issue(c, until, self.cmb_plan.currentData() or "pro")
        except Exception as e:
            QMessageBox.warning(self, "Make key", str(e))
            return
        if c.get("history"):
            c["history"][-1].update(order=order, paid=bool(order))
        if order:
            payments.mark_issued(order, until.isoformat())
            c["order"] = ""                 # the next renewal needs a new order
        else:
            payments.audit("key_issued_without_order", customer=c["id"],
                           expires=until.isoformat())
        admin.save(self.customers)
        self._fill()
        self._show_selected()
        self._copy(True)

    @staticmethod
    def _order_text(c: dict) -> str:
        if not c.get("order"):
            return ""
        rec = payments.find(c["order"])
        return f"{c['order']} · " + (payments.STATES[rec["status"]] if rec else "?")

    def _pay_changed(self):
        c = self._current()
        if c is None or not c.get("order"):
            return
        st = self.cmb_paid.currentData()
        if st == "approved":
            ans = QMessageBox.question(
                self, "Payment", f"Did you check yourself that {c['order']} is paid "
                "(in ABA / KHQR – not only a screenshot)?")
            if ans != QMessageBox.StandardButton.Yes:
                self._show_selected()
                return
        try:
            payments.set_status(c["order"], st)
        except Exception as e:
            QMessageBox.warning(self, "Payment", str(e))
        self._fill()
        self._show_selected()

    def show_payments(self):
        PaymentsDialog(self).exec()

    def paste_request(self, text: str = ""):
        """📋 A customer's buy message -> the customer (found by Machine ID, or new)
        with the order and the duration chosen."""
        from core import pricing

        text = text or QGuiApplication.clipboard().text()
        req = pricing.parse_request(text)
        if not req["machine"]:
            QMessageBox.information(self, "Paste request",
                                    "No Machine ID in the copied text. Copy the customer's "
                                    "whole message first.")
            return None
        c = next((x for x in self.customers if x.get("machine") == req["machine"]), None)
        if c is None:
            c = admin.new_customer("New customer", req["machine"])
            self.customers.insert(0, c)
        if req["order"]:
            c["order"] = req["order"]
            price = next((pricing.money(i["price"], pricing.load()["currency"])
                          for i in pricing.load()["items"] if i["days"] == req["days"]), "")
            payments.add(req["order"], c["id"], req["machine"], req["days"], req["label"],
                         price)
        admin.save(self.customers)
        self.ed_search.clear()
        self._fill()
        self._select(c["id"])
        self._show_selected()
        if req["days"]:
            i = self.cmb_days.findData(req["days"])
            if i >= 0:
                self.cmb_days.setCurrentIndex(i)
        self.lb_hist.setText(f"📋 Request: {req['label'] or '?'} · {req['order'] or 'no order'}"
                             " – check the payment, set “Paid”, then Make key.")
        if c["name"] == "New customer":
            self.ed_name.setFocus()
            self.ed_name.selectAll()
        return c

    def _copy(self, message: bool):
        c = self._current()
        if c is None or not c.get("key"):
            return
        text = c["key"]
        if message:
            text = (f"សួស្តី {c.get('name', '')}!\n"
                    f"License key SARIKA VOXDUB PRO (ប្រើបានដល់ {c.get('expires', '')}):\n\n"
                    f"{c['key']}\n\n"
                    "របៀបដាក់៖ បើកកម្មវិធី → Help › License → paste key → Activate។\n"
                    "Key នេះប្រើបានតែលើកុំព្យូទ័ររបស់អ្នកប៉ុណ្ណោះ។ អរគុណ! 🙏")
        QGuiApplication.clipboard().setText(text)
        self.lb_hist.setText(("Message" if message else "Key") + " copied ✔ – paste it to the "
                             "customer.")

    def _delete(self):
        c = self._current()
        if c is None:
            return
        ans = QMessageBox.question(self, "Delete", f"Delete {c.get('name', '')} from the list?\n"
                                                   "(A key already sent keeps working until "
                                                   "its date.)")
        if ans != QMessageBox.StandardButton.Yes:
            return
        self.customers = [x for x in self.customers if x["id"] != c["id"]]
        admin.save(self.customers)
        payments.audit("customer_deleted", customer=c["id"], name=c.get("name", ""))
        self._fill()
        self._show_selected()

    def _export(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export customers",
                                              os.path.join(os.path.expanduser("~"),
                                                           "voxdub_customers.csv"),
                                              "CSV (*.csv)")
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(["name", "contact", "machine", "plan", "expires", "status", "note", "key"])
            for c in self.customers:
                w.writerow([c.get("name", ""), c.get("contact", ""), c.get("machine", ""),
                            c.get("plan", ""), c.get("expires", ""), admin.status(c)["text"],
                            c.get("note", ""), c.get("key", "")])
        self.lb_hist.setText(f"Saved: {path}")


class PaymentsDialog(QDialog):
    """🧾 Every payment request + the audit log (checked: a changed line shows)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Payments & audit log")
        self.resize(1000, 640)
        lay = QVBoxLayout(self)
        s = payments.summary()
        lay.addWidget(QLabel("  ·  ".join(f"{payments.STATES[k]}: {s.get(k, 0)}"
                                           for k in payments.STATES)))
        cols = ["Order", "Status", "Plan", "Price", "Machine ID", "Created", "Checked",
                "Key made"]
        t = QTableWidget(0, len(cols))
        t.setHorizontalHeaderLabels(cols)
        t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        t.verticalHeader().setVisible(False)
        rows = payments.load()
        t.setRowCount(len(rows))
        for r, o in enumerate(rows):
            vals = [o.get("order", ""), payments.STATES.get(o.get("status", ""), ""),
                    o.get("label", ""), o.get("price", ""), o.get("machine", ""),
                    o.get("created", "")[:16].replace("T", " "),
                    o.get("reviewed", "")[:16].replace("T", " "),
                    o.get("issued", "")[:16].replace("T", " ")]
            for k, v in enumerate(vals):
                t.setItem(r, k, QTableWidgetItem(str(v)))
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        lay.addWidget(QLabel("Payment requests"))
        lay.addWidget(t, 1)
        bad = payments.verify_audit()
        ok = QLabel("✅ Audit log is whole (no line changed or removed)" if bad is None else
                    f"⚠ Audit log line {bad} was changed or removed")
        ok.setStyleSheet(f"color: {'#22c3a6' if bad is None else '#ef5350'}; font-weight: 700;")
        lay.addWidget(ok)
        a = QTableWidget(0, 3)
        a.setHorizontalHeaderLabels(["Time", "What", "Details"])
        a.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        a.verticalHeader().setVisible(False)
        log = payments.read_audit()
        a.setRowCount(len(log))
        for r, e in enumerate(log):
            det = ", ".join(f"{k}={v}" for k, v in e.items() if k not in ("time", "action",
                                                                           "prev") and v)
            for k, v in enumerate((e.get("time", "").replace("T", " "), e.get("action", ""),
                                   det)):
                a.setItem(r, k, QTableWidgetItem(v))
        a.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        lay.addWidget(a, 1)
        b = QPushButton("Close")
        b.clicked.connect(self.accept)
        lay.addWidget(b, 0, Qt.AlignmentFlag.AlignRight)


def _open(path: str):
    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QDesktopServices

    os.makedirs(path, exist_ok=True)
    QDesktopServices.openUrl(QUrl.fromLocalFile(path))
