"""theme.py - SARIKA VOXDUB 2.0 design tokens (presentation only, no logic).

One place for every colour of the app. The old 1.7 style sheet (ui/style.py)
keeps its rules; its colours are moved onto this palette by ``remap()``:

* greys / dark surfaces  -> a slate ramp anchored on the 2.0 tokens
  (#0B1120 background, #1E293B surface, #94A3B8 / #F8FAFC text)
* teal accents           -> #14B8A6 family, purple -> violet, yellow -> amber,
  red -> #EF4444 family, green -> emerald, blue -> blue
  (hue changes, the lightness of each shade stays, so hover / pressed /
  selected states keep their order)

Set the environment variable VOXDUB_LEGACY_THEME=1 to start with the
untouched 1.7 colours (side-by-side check / quick rollback).
"""

import colorsys
import os
import re

# ------------------------------------------------------------------ #
# 2.0 tokens
# ------------------------------------------------------------------ #
BG = "#0B1120"            # primary background
SURFACE = "#1E293B"       # secondary surface (panels, cards, inputs)
ACCENT = "#14B8A6"        # primary accent (teal)
ACCENT_2 = "#8B5CF6"      # secondary accent (Auto Dub / Export gradient)
TEXT = "#F8FAFC"          # primary text
TEXT_2 = "#94A3B8"        # secondary text
WARNING = "#F59E0B"
ERROR = "#EF4444"
SUCCESS = "#10B981"
INFO = "#3B82F6"

RADIUS = 8                # px - buttons / inputs
RADIUS_PANEL = 12         # px - panels / cards
SPACE = 8                 # px - base spacing unit

LEGACY = os.environ.get("VOXDUB_LEGACY_THEME", "").strip() in ("1", "true", "yes")

# ------------------------------------------------------------------ #
# legacy 1.7 colour -> 2.0 colour
# ------------------------------------------------------------------ #
# exact pins: the 1.7 brand colours become the 2.0 tokens
_PINS = {
    "#22c3a6": ACCENT,
    "#7c5cff": ACCENT_2,
    "#0f1216": BG,
    "#1a1f26": SURFACE,
    "#e6edf3": "#F1F5F9",
    "#ffffff": TEXT,
    "#8b949e": TEXT_2,
    "#f5b942": WARNING,
    "#e8553e": ERROR,
    # timeline tracks (1.7 colour -> 2.0 track colour)
    "#5d6182": "#4B5A7A",   # video clip
    "#4c5070": "#3C4A66",   # video: original audio part
    "#a9addb": "#8291B0",   # video waveform (calmer: the voice track stays the focus)
    "#3a3d55": "#2E3A52",   # video clip line
    "#3f6b5f": "#0F766E",   # AI voice clip
    "#93d6bf": "#5EEAD4",   # AI voice waveform
    "#2f5d7a": "#1E5A8A",   # music clip
    "#8cc8f0": "#93C5FD",   # music waveform
    "#6a5a94": "#6D4FB0",   # subtitle clip
    "#f2b33d": WARNING,     # selected clip
    "#2fd59a": "#2DD4BF",   # checked tool icon
}

# neutral ramp: (luminance of the 1.7 grey, 2.0 slate colour)
_RAMP = [
    (0.000, "#050914"),
    (0.004, "#080D19"),     # 1.7 #0b0d10 menu / top bar
    (0.006, BG),            # 1.7 #0f1216 window
    (0.013, "#162032"),     # 1.7 #14181d side panel
    (0.018, SURFACE),       # 1.7 #1a1f26 group box
    (0.032, "#273449"),     # 1.7 #232a33 buttons
    (0.048, "#334155"),     # 1.7 #2f3742 borders
    (0.090, "#475569"),
    (0.140, "#64748B"),     # 1.7 #5a636e disabled text
    (0.300, TEXT_2),        # 1.7 #8b949e muted text
    (0.600, "#CBD5E1"),
    (0.840, "#F1F5F9"),
    (1.000, TEXT),
]

# chromatic families: (hue in degrees, hue of the 2.0 colour)
_FAMILIES = [
    (0, 0),          # red     -> #EF4444
    (40, 38),        # amber   -> #F59E0B
    (155, 160),      # green   -> emerald
    (170, 173),      # teal    -> #14B8A6
    (210, 217),      # blue    -> #3B82F6
    (255, 258),      # violet  -> #8B5CF6
]


def _rgb(h: str):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def _hex(r, g, b) -> str:
    return "#{:02X}{:02X}{:02X}".format(*(max(0, min(255, round(v * 255))) for v in (r, g, b)))


def _lum(r, g, b) -> float:
    lin = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in (r, g, b)]
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]


def _neutral(lum: float) -> str:
    for (l0, c0), (l1, c1) in zip(_RAMP, _RAMP[1:]):
        if lum <= l1:
            t = 0 if l1 == l0 else (lum - l0) / (l1 - l0)
            a, b = _rgb(c0), _rgb(c1)
            return _hex(*(x + (y - x) * t for x, y in zip(a, b)))
    return TEXT


def _hue_dist(a: float, b: float) -> float:
    d = abs(a - b) % 360
    return min(d, 360 - d)


def legacy(color: str) -> str:
    """The 2.0 colour for a 1.7 colour ('#rrggbb' / '#rgb')."""
    key = color.lower()
    if len(key) == 4:
        key = "#" + "".join(c * 2 for c in key[1:])
    if LEGACY:
        return color
    if key in _PINS:
        return _PINS[key]
    r, g, b = _rgb(key)
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    chroma = max(r, g, b) - min(r, g, b)
    if chroma < 0.10:                       # grey / near-grey surface
        return _neutral(_lum(r, g, b))
    deg = h * 360
    _src, dst = min(_FAMILIES, key=lambda f: _hue_dist(deg, f[0]))
    if chroma < 0.16 and l < 0.3:           # dark tinted surface: tint on slate
        base = _rgb(_neutral(_lum(r, g, b)))
        bh, bl, bs = colorsys.rgb_to_hls(*base)
        return _hex(*colorsys.hls_to_rgb(dst / 360, max(bl, l * 0.95), max(s * 0.8, 0.35)))
    return _hex(*colorsys.hls_to_rgb(dst / 360, l, s))


_HEX = re.compile(r"#(?:[0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b")


def remap(qss: str) -> str:
    """Move every colour of a style sheet onto the 2.0 palette."""
    if LEGACY:
        return qss
    return _HEX.sub(lambda m: legacy(m.group(0)), qss)


def qcolor(color: str):
    """QColor for painting code (timeline, waveform, preview overlays)."""
    from PySide6.QtGui import QColor
    return QColor(legacy(color))


def extra_qss() -> str:
    """2.0 rules added after the 1.7 style sheet (later rules win in Qt).
    Empty with VOXDUB_LEGACY_THEME=1."""
    if LEGACY:
        return ""
    return f"""
/* top bar: Auto Dub is the one primary action; the others are secondary */
QPushButton#TopSecondary {{ background: transparent; color: #CBD5E1;
    border: 1px solid #334155; border-radius: {RADIUS}px; padding: 7px 14px; font-weight: 600; }}
QPushButton#TopSecondary:hover {{ background: {SURFACE}; color: {TEXT}; border-color: #475569; }}
QPushButton#TopSecondary:pressed {{ background: #162032; }}
/* licence badge: information, not an action */
QPushButton#LicenseBadge {{ background: transparent; color: #5EEAD4;
    border: 1px solid #115E59; border-radius: 10px; padding: 4px 12px; }}
QPushButton#LicenseBadge:hover {{ background: #0F2A2E; }}
"""
