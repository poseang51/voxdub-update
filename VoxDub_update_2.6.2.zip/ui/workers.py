"""
workers.py - Run slow jobs (Whisper, translation, TTS, export) in a
background QThread so the window never freezes.
"""

import traceback

from PySide6.QtCore import QThread, Signal


class TaskWorker(QThread):
    """Runs fn(progress, should_stop) in a thread.

    Signals
      progress(int percent, str message)
      done(object result)
      failed(str error)
    """

    progress = Signal(int, str)
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, title: str = "Working", parent=None):
        super().__init__(parent)
        self.fn = fn
        self.title = title
        self._stop = False

    def stop(self):
        self._stop = True

    def should_stop(self) -> bool:
        return self._stop

    def run(self):
        try:
            result = self.fn(self.progress.emit, self.should_stop)
            self.done.emit(result)
        except InterruptedError:
            self.failed.emit("Cancelled by user.")
        except Exception as e:  # show any error in the UI instead of crashing
            traceback.print_exc()
            from core.errors import friendly

            self.failed.emit(friendly(e))       # what happened + what to do


def wait_for_threads(threads, parent=None, text: str = "Stopping...", limit: float = 180.0):
    """Wait (window still painting) until stopped workers really end - a QThread
    destroyed while it runs makes Qt abort the whole program. A step that
    cannot stop in time (a long Whisper chunk) ends with the process."""
    import os
    import time

    from PySide6.QtWidgets import QApplication

    threads = [t for t in threads if t is not None and t.isRunning()]
    if not threads:
        return
    if parent is not None and hasattr(parent, "statusBar"):
        parent.statusBar().showMessage(text)
    start = time.time()
    while any(t.isRunning() for t in threads):
        QApplication.processEvents()
        for t in threads:
            t.wait(50)
        if time.time() - start > limit:
            os._exit(0)         # everything is saved already; avoid Qt's crash dialog
