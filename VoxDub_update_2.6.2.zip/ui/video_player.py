"""
video_player.py - Preview player that understands the edited timeline.

* Plays the original video (with its own audio, adjustable volume).
* Plays the AI voice clips themselves in sync (a small pool of players
  picks up each clip as the playhead reaches it). Nothing has to be mixed
  after an edit, so this works the same for a 1-minute and a 2-hour video.
* Skips over cut parts of the video (timeline time -> source time).
* Shows the current subtitle on top of the video.
"""

import bisect
import copy
import os
import tempfile
from typing import Callable, Dict, List, Optional

from core.crashlog import safe_video_decoding  # noqa: E402

safe_video_decoding()           # before Qt Multimedia starts (also in ui/__init__)

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPen, QPixmap, QTransform
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtMultimediaWidgets import QGraphicsVideoItem
from PySide6.QtWidgets import (
    QCheckBox, QGraphicsItem, QGraphicsPixmapItem, QGraphicsRectItem, QGraphicsScene, QGraphicsTextItem,
    QGraphicsView, QHBoxLayout, QLabel, QPushButton, QSlider, QVBoxLayout, QWidget,
)

from core import branding, effects, subfit
from core.media import format_time
from core.project import Project
from ui.theme import legacy as _t


from core.media import VIDEO_EXT  # noqa: E402


def _video_in(mime) -> str:
    """First video file in a drag & drop, or ""."""
    if mime is not None and mime.hasUrls():
        for url in mime.urls():
            path = os.path.normpath(url.toLocalFile())
            if path.lower().endswith(VIDEO_EXT):
                return path
    return ""


class _VideoView(QGraphicsView):
    """Graphics view that keeps the video item the size of the viewport.
    A video file can be dragged & dropped onto it (opens the video)."""

    resized = Signal()
    fileDropped = Signal(str)
    dragHover = Signal(bool)
    emptyClicked = Signal()

    def __init__(self, scene):
        super().__init__(scene)
        self.setAcceptDrops(True)
        self.viewport().setAcceptDrops(True)
        self.empty = True               # no video yet: a click opens the file dialog

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.resized.emit()

    def dragEnterEvent(self, event):
        if _video_in(event.mimeData()):
            event.acceptProposedAction()
            self.dragHover.emit(True)
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if _video_in(event.mimeData()):
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self.dragHover.emit(False)
        event.accept()

    def dropEvent(self, event):
        self.dragHover.emit(False)
        path = _video_in(event.mimeData())
        if path:
            event.acceptProposedAction()
            self.fileDropped.emit(path)
        else:
            event.ignore()

    def mouseReleaseEvent(self, event):
        super().mouseReleaseEvent(event)
        if self.empty and event.button() == Qt.MouseButton.LeftButton:
            self.emptyClicked.emit()


HANDLE = 9.0                        # px: the corner squares of a selected item
SEL_PEN = QColor(_t("#22c3a6"))


def _draw_selection(p: QPainter, r: QRectF, scale: float = 1.0, inside: bool = False):
    """Dashed frame + 4 corner handles around r (item coordinates). inside:
    the handles sit inside the corners (items that cannot paint outside)."""
    h = HANDLE / max(0.05, scale)
    pen = QPen(SEL_PEN, 1.2 / max(0.05, scale))
    pen.setStyle(Qt.PenStyle.DashLine)
    p.setPen(pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawRect(r)
    p.setPen(QPen(QColor(_t("#0b1d1a")), 1 / max(0.05, scale)))
    p.setBrush(QBrush(SEL_PEN))
    for name in ("tl", "tr", "bl", "br"):
        p.drawRect(_handle_rect(r, name, h, inside))


def _handle_rect(r: QRectF, name: str, h: float, inside: bool) -> QRectF:
    c = _corner_point(r, name)
    if not inside:
        return QRectF(c.x() - h / 2, c.y() - h / 2, h, h)
    x = c.x() if name[1] == "l" else c.x() - h
    y = c.y() if name[0] == "t" else c.y() - h
    return QRectF(x, y, h, h)


def _corner_at(r: QRectF, pos: QPointF, scale: float = 1.0, inside: bool = False) -> str:
    """'tl' / 'tr' / 'bl' / 'br' when pos is on a corner handle of r, else ''."""
    h = HANDLE / max(0.05, scale)
    for name in ("tl", "tr", "bl", "br"):
        if _handle_rect(r, name, h, inside).adjusted(-h / 2, -h / 2, h / 2, h / 2) \
                .contains(pos):
            return name
    return ""


_CORNER_CURSOR = {"tl": Qt.CursorShape.SizeFDiagCursor, "br": Qt.CursorShape.SizeFDiagCursor,
                  "tr": Qt.CursorShape.SizeBDiagCursor, "bl": Qt.CursorShape.SizeBDiagCursor}
_OPPOSITE = {"tl": "br", "br": "tl", "tr": "bl", "bl": "tr"}


def _corner_point(r: QRectF, name: str) -> QPointF:
    return {"tl": r.topLeft(), "tr": r.topRight(), "bl": r.bottomLeft(),
            "br": r.bottomRight()}[name]


class _DragMixin:
    """A logo / brand text item the user can click, drag around the canvas
    and resize with its corner handles. The player passes `bounds` (the
    canvas) and gets `on_drop(item)` / `on_resize(item, scene_rect)`."""

    def _init_drag(self, on_drop, on_resize=None):
        self.bounds = QRectF()
        self.on_drop = on_drop
        self.on_resize = on_resize
        self._resize = ""                   # corner being dragged
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable)
        self.setAcceptHoverEvents(True)
        self.set_draggable(False)

    def set_draggable(self, on: bool):
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable, on)
        self.setCursor(Qt.CursorShape.OpenHandCursor if on else Qt.CursorShape.ArrowCursor)
        self.setToolTip("Drag to move · drag a corner to resize" if on else
                        "It moves by itself - set Style › Movement to Fixed to drag it")

    def itemChange(self, change, value):
        if change == QGraphicsItem.GraphicsItemChange.ItemPositionChange \
                and self.bounds.width() > 0 and self.isUnderMouse() and not self._resize:
            r = self.boundingRect()
            x = max(self.bounds.left(), min(value.x(), self.bounds.right() - r.width()))
            y = max(self.bounds.top(), min(value.y(), self.bounds.bottom() - r.height()))
            return QPointF(x, y)
        return super().itemChange(change, value)

    def _movable(self) -> bool:
        return bool(self.flags() & QGraphicsItem.GraphicsItemFlag.ItemIsMovable)

    def hoverMoveEvent(self, event):
        corner = _corner_at(self.boundingRect(), event.pos(), inside=True) \
            if self.isSelected() and self._movable() and self.on_resize else ""
        self.setCursor(_CORNER_CURSOR[corner] if corner else
                       (Qt.CursorShape.OpenHandCursor if self._movable()
                        else Qt.CursorShape.ArrowCursor))
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event):
        self._press_pos = self.pos()
        corner = _corner_at(self.boundingRect(), event.pos(), inside=True) \
            if self.isSelected() and self._movable() and self.on_resize else ""
        if corner:
            self._resize = corner
            r = self.boundingRect()
            self._fixed = self.mapToScene(_corner_point(r, _OPPOSITE[corner]))
            self._start_w = max(1.0, r.width())
            self.setTransformOriginPoint(_corner_point(r, _OPPOSITE[corner]))
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resize:
            d = event.scenePos() - self._fixed
            r = self.boundingRect()
            # keep the shape: the larger of the two directions decides
            f = max(abs(d.x()) / max(1.0, r.width()), abs(d.y()) / max(1.0, r.height()))
            f = max(0.15, min(6.0, f))
            if self.bounds.width() > 0:
                f = min(f, self.bounds.width() / max(1.0, r.width()),
                        self.bounds.height() / max(1.0, r.height()))
            self.setScale(f)
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._resize:
            self._resize = ""
            rect = self.mapRectToScene(self.boundingRect())
            self.setScale(1.0)
            self.setTransformOriginPoint(QPointF(0, 0))
            if self.on_resize:
                self.on_resize(self, rect)
            return
        super().mouseReleaseEvent(event)
        if self._movable() and self.pos() != getattr(self, "_press_pos", self.pos()):
            self.on_drop(self)

    def _paint_selection(self, p: QPainter):
        if self.isSelected() and self._movable():
            p.save()
            _draw_selection(p, self.boundingRect(), self.scale(), inside=True)
            p.restore()


class _DragCover(QGraphicsRectItem):
    """2.4: the box that hides the original subtitles - drag it up / down /
    sideways, drag its bottom-right corner to change its size.
    `on_change(scene_rect)` when the mouse is released."""

    def __init__(self, on_change=None, on_press=None):
        super().__init__()
        self.on_change = on_change
        self.on_press = on_press
        self.bounds = QRectF()
        self._drag = ""                     # "" / "move" / "size"
        self.setAcceptHoverEvents(True)
        self.setToolTip("Hides the original subtitles – drag to move, "
                        "drag the corner to resize")

    def set_box(self, rect: QRectF):
        if not self._drag:                  # the user is moving it: keep still
            self.setRect(rect)

    def _corner(self, pos: QPointF) -> bool:
        r = self.rect()
        return QRectF(r.right() - HANDLE * 1.5, r.bottom() - HANDLE * 1.5,
                      HANDLE * 3, HANDLE * 3).contains(pos)

    def hoverMoveEvent(self, event):
        self.setCursor(Qt.CursorShape.SizeFDiagCursor if self._corner(event.pos())
                       else Qt.CursorShape.SizeAllCursor)
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton:
            return super().mousePressEvent(event)
        if self.on_press:
            self.on_press()
        self._drag = "size" if self._corner(event.pos()) else "move"
        self._press = event.scenePos()
        self._start = QRectF(self.rect())
        event.accept()

    def mouseMoveEvent(self, event):
        if not self._drag:
            return
        d = event.scenePos() - self._press
        r = QRectF(self._start)
        b = self.bounds if self.bounds.width() > 0 else r
        if self._drag == "move":
            x = max(b.left(), min(r.left() + d.x(), b.right() - r.width()))
            y = max(b.top(), min(r.top() + d.y(), b.bottom() - r.height()))
            r.moveTo(x, y)
        else:
            r.setWidth(max(12.0, min(b.right() - r.left(), r.width() + d.x())))
            r.setHeight(max(6.0, min(b.bottom() - r.top(), r.height() + d.y())))
        self.setRect(r)

    def mouseReleaseEvent(self, event):
        if not self._drag:
            return
        self._drag = ""
        if (event.scenePos() - self._press).manhattanLength() > 2 and self.on_change:
            self.on_change(QRectF(self.rect()))

    def paint(self, p: QPainter, option, widget=None):
        super().paint(p, option, widget)
        r = self.rect()
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(QColor("#f5b942")))
        p.drawRect(QRectF(r.right() - HANDLE / 2, r.bottom() - HANDLE / 2, HANDLE, HANDLE))


class _DragPixmap(_DragMixin, QGraphicsPixmapItem):
    def __init__(self, on_drop, on_resize=None):
        super().__init__()
        # the whole box can be grabbed: a logo is mostly see-through (PNG),
        # and with the default MaskShape a click between its letters / inside
        # a ring fell through to the video, so the logo "could not be moved"
        self.setShapeMode(QGraphicsPixmapItem.ShapeMode.BoundingRectShape)
        self._init_drag(on_drop, on_resize)

    # (also by hand: hit-testing never looks at the see-through pixels)
    def shape(self):
        path = QPainterPath()
        path.addRect(self.boundingRect())
        return path

    def contains(self, point) -> bool:
        return self.boundingRect().contains(point)

    def isObscuredBy(self, item) -> bool:
        return False

    def paint(self, p, option, widget=None):
        from PySide6.QtWidgets import QStyle

        option.state &= ~QStyle.StateFlag.State_Selected     # our own frame instead
        super().paint(p, option, widget)
        self._paint_selection(p)


class _DragText(_DragMixin, QGraphicsTextItem):
    def __init__(self, on_drop, on_resize=None):
        super().__init__()
        self._init_drag(on_drop, on_resize)

    def paint(self, p, option, widget=None):
        from PySide6.QtWidgets import QStyle

        option.state &= ~QStyle.StateFlag.State_Selected
        super().paint(p, option, widget)
        self._paint_selection(p)


class _SubItem(QGraphicsItem):
    """The subtitle as it will be burned in: text colour, outline, shadow or
    a box behind it (Style tab > Subtitles) - drawn as a path so the outline
    looks like libass's.

    Click it to select: drag to move it anywhere on the picture, drag a
    corner to make the text bigger / smaller. `on_change(cx, bottom, factor)`
    gets the new centre x, the new bottom (scene coordinates) and the size
    factor when the mouse is released."""

    def __init__(self, on_change=None, on_press=None):
        super().__init__()
        self._path = QPainterPath()
        self._box = QRectF()
        self._rect = QRectF()
        self._style = {}
        self._anchor = QPointF()            # bottom centre of the text block
        self.on_change = on_change
        self.on_press = on_press
        self._drag = ""                     # "" / "move" / a corner
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable)
        self.setAcceptHoverEvents(True)
        self.setToolTip("Click, then drag to move the subtitles · drag a corner to resize")

    def set_content(self, lines, font: QFont, style: dict, scale: float,
                    cx: float, anchor_y: float, centered: bool):
        from PySide6.QtGui import QFontMetricsF

        if self._drag:                      # the user is moving it: keep still
            return
        self.prepareGeometryChange()
        fm = QFontMetricsF(font)
        lh = fm.height()
        total = lh * len(lines)
        top = anchor_y - total / 2 if centered else anchor_y - total
        path = QPainterPath()
        box = QRectF()
        for i, line in enumerate(lines):
            w = fm.horizontalAdvance(line)
            x = cx - w / 2
            path.addText(x, top + i * lh + fm.ascent(), font, line)
            box = box.united(QRectF(x, top + i * lh, w, lh))
        pad = 3.0 * scale
        self._box = box.adjusted(-pad, -pad * 0.4, pad, pad * 0.4)
        self._path = path
        self._anchor = QPointF(cx, top + total)
        self._style = dict(style, scale=scale)
        grow = (float(style.get("outline", 0)) + float(style.get("shadow", 0)) + 4) * scale
        self._rect = self._box.adjusted(-grow - HANDLE, -grow - HANDLE, grow + HANDLE,
                                        grow + HANDLE)
        self.update()

    def boundingRect(self) -> QRectF:
        return self._rect

    def shape(self):
        sh = QPainterPath()
        sh.addRect(self._box.adjusted(-HANDLE, -HANDLE, HANDLE, HANDLE))
        return sh

    def text_rect(self) -> QRectF:
        return self._box

    def paint(self, p: QPainter, option, widget=None):
        st = self._style
        if self._path.isEmpty():
            return
        s = st.get("scale", 1.0)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        if st.get("box"):
            c = QColor(st.get("box_color", "#000000"))
            c.setAlphaF(max(0.0, min(1.0, float(st.get("box_opacity", 0.6)))))
            p.fillRect(self._box, c)
        else:
            sh = float(st.get("shadow", 0.0)) * s
            if sh > 0:
                p.fillPath(self._path.translated(sh, sh), QColor(0, 0, 0, 128))
            ow = float(st.get("outline", 0.0)) * s
            if ow > 0:
                pen = QPen(QColor(st.get("outline_color", "#000000")), 2 * ow)
                pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
                p.strokePath(self._path, pen)
        p.fillPath(self._path, QColor(st.get("color", "#FFFFFF")))
        if self.isSelected():
            _draw_selection(p, self._box, self.scale())

    # ---- drag to move / resize
    def hoverMoveEvent(self, event):
        corner = _corner_at(self._box, event.pos()) if self.isSelected() else ""
        self.setCursor(_CORNER_CURSOR[corner] if corner else Qt.CursorShape.SizeAllCursor)
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton:
            return super().mousePressEvent(event)
        if self.on_press:
            self.on_press()                 # pause the video while editing
        corner = _corner_at(self._box, event.pos()) if self.isSelected() else ""
        self.setSelected(True)
        self._drag = corner or "move"
        self._press = event.scenePos()
        self._start_pos = self.pos()
        if corner:
            self.setTransformOriginPoint(self._anchor)     # grows from its bottom centre
        event.accept()

    def mouseMoveEvent(self, event):
        if not self._drag:
            return
        if self._drag == "move":
            self.setPos(self._start_pos + event.scenePos() - self._press)
            return
        a = self._anchor
        b = self._box
        p = event.scenePos()
        fx = abs(p.x() - a.x()) / max(1.0, b.width() / 2)
        fy = abs(a.y() - p.y()) / max(1.0, b.height())
        self.setScale(max(0.3, min(4.0, max(fx, fy))))

    def mouseReleaseEvent(self, event):
        if not self._drag:
            return
        kind, self._drag = self._drag, ""
        anchor = self.mapToScene(self._anchor)
        factor = self.scale()
        self.setPos(0, 0)
        self.setScale(1.0)
        moved = kind != "move" or (event.scenePos() - self._press).manhattanLength() > 2
        if moved and self.on_change:
            self.on_change(anchor.x(), anchor.y(), factor)


class VideoPlayer(QWidget):
    positionChanged = Signal(float)     # timeline seconds
    playingChanged = Signal(bool)
    overlayMoved = Signal()             # logo / brand text dragged to a new place
    overlayAboutToMove = Signal()       # (before the change: for undo)
    subsShownToggled = Signal(bool)     # the CC button: subtitles on / off (export too)
    videoDropped = Signal(str)          # a video file dropped on the preview
    browseRequested = Signal()          # click on the empty preview

    def __init__(self, parent=None):
        super().__init__(parent)
        self.project: Optional[Project] = None
        self._t = 0.0
        self._playing = False
        self._clip_idx = 0
        self._dub_enabled = True
        self._mute_ranges = []          # timeline ranges where original speech is muted
        self._mute_starts: List[float] = []
        self._subs = []                 # subtitles sorted by start
        self._sub_starts: List[float] = []
        self._ignore_until = 0          # ignore stale positions right after a jump
        self._build_ui()

        self.player = QMediaPlayer(self)
        self.audio_out = QAudioOutput(self)
        self.player.setAudioOutput(self.audio_out)
        self.player.setVideoOutput(self.video_item)
        self.player.errorOccurred.connect(self._on_error)
        self.player.mediaStatusChanged.connect(self._on_media_status)

        # the AI voice: mixed by us into one audio stream (reliable); the old
        # one-player-per-clip pool only when no audio output can be opened
        from ui.voice_mixer import VoiceMixer
        mixer = VoiceMixer(self)
        self.voices = mixer if mixer.ok else VoicePool(self)
        # the video's own sound follows Windows' default output too (headphones
        # plugged in / Bluetooth connected while the app runs)
        try:
            from PySide6.QtMultimedia import QMediaDevices
            self._media_devices = QMediaDevices(self)
            self._media_devices.audioOutputsChanged.connect(
                lambda: self.audio_out.setDevice(QMediaDevices.defaultAudioOutput()))
        except Exception:
            pass

        self.set_original_volume(30)
        self.set_dub_volume(100)

        self.timer = QTimer(self)
        self.timer.setInterval(30)
        self.timer.timeout.connect(self._tick)
        self.timer.start()

    # ------------------------------------------------------------------ #
    # UI
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        self.scene = QGraphicsScene(self)
        self.view = _VideoView(self.scene)
        self.view.setObjectName("VideoView")
        self.view.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.view.setBackgroundBrush(QBrush(QColor("#000000")))
        self.view.setFrameShape(QGraphicsView.Shape.NoFrame)
        self.view.resized.connect(self._layout_scene)

        # output canvas (visible when the export ratio differs from the video)
        self.canvas_item = QGraphicsRectItem()
        self.canvas_item.setBrush(QBrush(QColor(_t("#2a3038"))))
        self.canvas_item.setPen(QPen(Qt.PenStyle.NoPen))
        self.canvas_item.setZValue(-1)
        self.scene.addItem(self.canvas_item)

        # the video sits inside a clip rect, so crop / zoom / "fill by cropping"
        # show exactly the part of the picture that is exported
        self.video_clip = QGraphicsRectItem()
        self.video_clip.setPen(QPen(Qt.PenStyle.NoPen))
        self.video_clip.setFlag(QGraphicsRectItem.GraphicsItemFlag.ItemClipsChildrenToShape)
        self.scene.addItem(self.video_clip)
        self.video_item = QGraphicsVideoItem(self.video_clip)
        self.video_item.setAspectRatioMode(Qt.AspectRatioMode.KeepAspectRatio)
        # Color Adjustments preview: an ffmpeg-rendered frame shown while paused
        self.still_item = QGraphicsPixmapItem(self.video_clip)
        self.still_item.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
        self.still_item.setVisible(False)
        self._still_pix: Optional[QPixmap] = None
        # Crop & Rotate: the dashed crop box (only in crop mode)
        self.crop_overlay = CropOverlay(self._on_crop_dragged)
        self.crop_overlay.setZValue(20)
        self.crop_overlay.setVisible(False)
        self.scene.addItem(self.crop_overlay)
        self._crop_mode = False
        self.cropChangedCallback: Optional[Callable[[float, float, float, float], None]] = None

        # covers the original burned-in subtitles (blur is shown as a grey veil)
        self.cover_item = _DragCover(self._on_cover_moved, self._cover_pressed)
        self.cover_item.setZValue(5)
        self.scene.addItem(self.cover_item)
        self.logo_item = _DragPixmap(self._on_item_dropped, self._on_item_resized)
        self.logo_item.setZValue(6)
        self.logo_item.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
        self.scene.addItem(self.logo_item)
        self._logo_src = ("", None)         # (path, QPixmap) cache
        self.extra_items: list = []         # more logos (sponsor / customer)
        self._extra_src: dict = {}          # path -> QPixmap
        self.brand_item = _DragText(self._on_item_dropped, self._on_item_resized)
        self.brand_item.setZValue(7)
        self.scene.addItem(self.brand_item)

        self.placeholder = QGraphicsTextItem()
        self.placeholder.setDefaultTextColor(QColor(_t("#9aa4b2")))
        self.placeholder.setFont(QFont("Segoe UI", 13))
        self.placeholder.setTextWidth(420)
        self.scene.addItem(self.placeholder)
        self._set_placeholder()
        # shown while a video file is dragged over the preview
        self.drop_frame = QGraphicsRectItem()
        pen = QPen(QColor(_t("#22c3a6")), 3)
        pen.setStyle(Qt.PenStyle.DashLine)
        self.drop_frame.setPen(pen)
        self.drop_frame.setBrush(QBrush(QColor(34, 195, 166, 40)))
        self.drop_frame.setZValue(30)
        self.drop_frame.setVisible(False)
        self.scene.addItem(self.drop_frame)
        self.view.fileDropped.connect(self.videoDropped.emit)
        self.view.dragHover.connect(self.drop_frame.setVisible)
        self.view.emptyClicked.connect(self.browseRequested.emit)

        self.sub_item = _SubItem(self._on_sub_moved, self.pause)
        self.sub_item.setZValue(11)
        self.scene.addItem(self.sub_item)
        self._current_sub = None
        self._show_sub("")

        # controls
        self.btn_play = QPushButton("▶")
        self.btn_play.setObjectName("PlayButton")
        self.btn_play.setFixedSize(42, 34)
        self.btn_play.clicked.connect(self.toggle)
        self.btn_back = QPushButton("⏮")
        self.btn_back.setFixedSize(34, 34)
        self.btn_back.setToolTip("Go to start")
        self.btn_back.clicked.connect(lambda: self.seek(0))

        self.seek_slider = QSlider(Qt.Orientation.Horizontal)
        self.seek_slider.setRange(0, 0)
        self.seek_slider.sliderMoved.connect(lambda v: self.seek(v / 1000.0))
        self.seek_slider.sliderPressed.connect(
            lambda: self.seek(self.seek_slider.value() / 1000.0))

        self.time_label = QLabel("00:00:00.000 / 00:00:00")
        self.time_label.setObjectName("TimeLabel")

        self.btn_cc = QPushButton("CC")
        self.btn_cc.setObjectName("CCButton")
        self.btn_cc.setCheckable(True)
        self.btn_cc.setChecked(True)
        self.btn_cc.setFixedWidth(40)
        self.btn_cc.setToolTip("Subtitles on / off – in the preview AND the exported video")
        self.btn_cc.toggled.connect(self._cc_toggled)
        self.chk_dub = QCheckBox("AI Voice")
        self.chk_dub.setChecked(True)
        self.chk_dub.toggled.connect(self.set_dub_enabled)

        self.vol_orig = QSlider(Qt.Orientation.Horizontal)
        self.vol_orig.setRange(0, 100)
        self.vol_orig.setValue(30)
        self.vol_orig.setFixedWidth(70)
        self.vol_orig.setToolTip("Original audio volume (preview)")
        self.vol_orig.valueChanged.connect(self.set_original_volume)
        self.vol_dub = QSlider(Qt.Orientation.Horizontal)
        self.vol_dub.setRange(0, 100)
        self.vol_dub.setValue(100)
        self.vol_dub.setFixedWidth(70)
        self.vol_dub.setToolTip("AI voice volume (preview)")
        self.vol_dub.valueChanged.connect(self.set_dub_volume)

        ctrl = QHBoxLayout()
        ctrl.setContentsMargins(8, 6, 8, 6)
        ctrl.setSpacing(8)
        ctrl.addWidget(self.btn_back)
        ctrl.addWidget(self.btn_play)
        ctrl.addWidget(self.seek_slider, 1)
        ctrl.addWidget(self.time_label)
        ctrl.addSpacing(6)
        ctrl.addWidget(QLabel("Orig"))
        ctrl.addWidget(self.vol_orig)
        ctrl.addWidget(self.chk_dub)
        ctrl.addWidget(self.vol_dub)
        ctrl.addWidget(self.btn_cc)

        bar = QWidget()
        bar.setObjectName("PlayerBar")
        bar.setLayout(ctrl)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(self.view, 1)
        lay.addWidget(bar)

    def _layout_scene(self):
        vp = self.view.viewport().rect()
        w, h = max(1, vp.width()), max(1, vp.height())
        self.scene.setSceneRect(0, 0, w, h)
        canvas = self._canvas_rect()
        vr = self._video_rect()
        self.canvas_item.setRect(canvas)
        self.canvas_item.setVisible(bool(self.project) and self.project.out_ratio != "original"
                                    and self.project.has_video())
        self.video_clip.setRect(vr.intersected(canvas))
        sr = self._source_rect()
        stretch = bool(self.project) and self.project.ratio_fill == "stretch" \
            and self.project.out_ratio != "original" and not self._crop_mode
        self.video_item.setAspectRatioMode(Qt.AspectRatioMode.IgnoreAspectRatio if stretch
                                           else Qt.AspectRatioMode.KeepAspectRatio)
        self.video_item.setPos(sr.topLeft())
        self.video_item.setSize(sr.size())
        # Crop & Rotate: the angle is shown live by rotating the video item
        angle = float(self.project.rotate or 0.0) if self.project else 0.0
        # Transform › Flip: rotate first, then mirror (as the export does)
        fx, fy = self._flips()
        cx, cy = sr.width() / 2, sr.height() / 2
        self.video_item.setRotation(0.0)
        self.video_item.setTransform(QTransform().translate(cx, cy).scale(fx, fy)
                                     .rotate(angle).translate(-cx, -cy))
        self._place_still(sr, angle)
        if self._crop_mode:
            self.crop_overlay.set_frame(sr)
            self.crop_overlay.setVisible(True)
        else:
            self.crop_overlay.setVisible(False)
        pr = self.placeholder.boundingRect()
        self.placeholder.setPos((w - pr.width()) / 2, (h - pr.height()) / 2)
        self.drop_frame.setRect(QRectF(6, 6, w - 12, h - 12))
        self._layout_overlays()
        self._position_sub()

    def _flips(self):
        """(-1 / 1, -1 / 1): Transform › Flip (not while the crop box is edited)."""
        p = self.project
        if not p or self._crop_mode:
            return 1.0, 1.0
        return (-1.0 if getattr(p, "flip_h", False) else 1.0,
                -1.0 if getattr(p, "flip_v", False) else 1.0)

    def _geo(self) -> Optional[Project]:
        """Project used for the picture geometry. In crop mode the whole
        uncropped frame is shown (like Movavi), so the crop box can be edited."""
        if not self._crop_mode or not self.project:
            return self.project
        g = copy.copy(self.project)
        g.crop_left = g.crop_top = g.crop_right = g.crop_bottom = 0.0
        g.zoom = 1.0
        g.pan_x = g.pan_y = 0.0
        g.out_ratio = "original"
        g.out_width = g.out_height = 0
        return g

    def _out_size(self):
        """Aspect (W, H) of the exported picture."""
        p = self._geo()
        if not p or p.width <= 0 or p.height <= 0:
            vp = self.scene.sceneRect()
            return max(1, int(vp.width())), max(1, int(vp.height()))
        return branding.output_size(p, 0)

    def _canvas_rect(self) -> QRectF:
        """The exported picture (output ratio) fitted inside the view."""
        w = self.scene.sceneRect().width()
        h = self.scene.sceneRect().height()
        ow, oh = self._out_size()
        s = min(w / ow, h / oh)
        return QRectF((w - ow * s) / 2, (h - oh * s) / 2, ow * s, oh * s)

    def _video_rect(self) -> QRectF:
        """Where the source picture sits inside the canvas."""
        c = self._canvas_rect()
        if not self.project or self.project.width <= 0:
            return c
        x, y, w, h = branding.content_rect(self._geo(), c.width(), c.height())
        return QRectF(c.left() + x, c.top() + y, w, h)

    def _source_rect(self) -> QRectF:
        """Where the WHOLE source frame sits (larger than the canvas when the
        picture is cropped / zoomed; the clip rect hides the rest)."""
        c = self._canvas_rect()
        if not self.project or self.project.width <= 0:
            return c
        x, y, w, h = branding.source_on_canvas(self._geo(), c.width(), c.height())
        return QRectF(c.left() + x, c.top() + y, w, h)

    def _layout_overlays(self):
        p = self.project
        c = self._canvas_rect()
        show = bool(p) and p.has_video() and not self._crop_mode
        # cover box
        cov = branding.cover_on_canvas(p, c.width(), c.height()) if show else None
        self.cover_item.setVisible(cov is not None)
        if cov is not None:
            x, y, w, h = cov
            self.cover_item.bounds = QRectF(c)
            self.cover_item.set_box(QRectF(c.left() + x, c.top() + y, w, h))
            if p.cover_mode == "box":
                self.cover_item.setBrush(QBrush(QColor(0, 0, 0, 235)))
                self.cover_item.setPen(QPen(Qt.PenStyle.NoPen))
            else:
                self.cover_item.setBrush(QBrush(QColor(70, 76, 84, 215)))
                pen = QPen(QColor(_t("#22c3a6")))
                pen.setStyle(Qt.PenStyle.DashLine)
                self.cover_item.setPen(pen)
        # logo
        pix = None
        if show and branding.has_logo(p):
            if self._logo_src[0] != p.logo_path:
                self._logo_src = (p.logo_path, QPixmap(p.logo_path))
            pix = self._logo_src[1]
        self.logo_item.setVisible(pix is not None and not pix.isNull())
        if pix is not None and not pix.isNull():
            lw = c.width() * p.logo_size
            scaled = pix.scaledToWidth(max(1, int(lw)),
                                       Qt.TransformationMode.SmoothTransformation)
            self.logo_item.setPixmap(scaled)
            self.logo_item.setOpacity(p.logo_opacity)
        # more logos
        extras = branding.extra_logos(p) if show else []
        while len(self.extra_items) < len(extras):
            it = _DragPixmap(self._on_item_dropped, self._on_item_resized)
            it.setZValue(6)
            it.setTransformationMode(Qt.TransformationMode.SmoothTransformation)
            self.scene.addItem(it)
            self.extra_items.append(it)
        for k, it in enumerate(self.extra_items):
            d = extras[k] if k < len(extras) else None
            src = None
            if d is not None:
                if d["path"] not in self._extra_src:
                    self._extra_src[d["path"]] = QPixmap(d["path"])
                src = self._extra_src[d["path"]]
            ok = src is not None and not src.isNull()
            it.setVisible(ok)
            it.extra = d if ok else None
            if ok:
                it.setPixmap(src.scaledToWidth(max(1, int(c.width() * float(d["size"]))),
                                               Qt.TransformationMode.SmoothTransformation))
                it.setOpacity(float(d["opacity"]))
        # brand text
        text = p.brand_text.strip() if show else ""
        self.brand_item.setVisible(bool(text))
        if text:
            ow, oh = self._out_size()
            size = branding.brand_size(p, ow, oh)
            font = QFont("Noto Sans Khmer")
            font.setBold(True)
            font.setPixelSize(max(7, int(0.65 * size * c.height() / subfit.SCRIPT_HEIGHT)))
            self.brand_item.setFont(font)
            self.brand_item.setDefaultTextColor(QColor(p.brand_color))
            self.brand_item.setPlainText(text)
        self._place_branding()

    def _place_branding(self):
        """Put the logo / brand text where they are at the playhead (they can
        be set to move by themselves)."""
        p = self.project
        if not p:
            return
        c = self._canvas_rect()
        items = [(self.logo_item, p.logo_corner, p.logo_pos, p.logo_motion),
                 (self.brand_item, p.brand_corner, p.brand_pos, p.brand_motion)]
        items += [(it, it.extra["corner"], it.extra["pos"], it.extra["motion"])
                  for it in self.extra_items if getattr(it, "extra", None)]
        for item, corner, pos, motion in items:
            if not item.isVisible() or item._resize or item.scene().mouseGrabberItem() is item:
                continue                # the user is moving / resizing it
            r = item.boundingRect()
            x, y = branding.item_xy(corner, pos, motion, self._t, c.width(), c.height(),
                                    r.width(), r.height())
            item.bounds = c
            item.set_draggable(branding.MOTIONS.get(motion, 0.0) <= 0)
            item.setPos(c.left() + x, c.top() + y)

    def _on_item_dropped(self, item):
        """The user dragged the logo or the brand text: keep it there."""
        p = self.project
        if not p:
            return
        self.overlayAboutToMove.emit()
        c = self._canvas_rect()
        r = item.boundingRect()
        pos = branding.pos_from_xy(item.x() - c.left(), item.y() - c.top(),
                                   c.width(), c.height(), r.width(), r.height())
        if getattr(item, "extra", None):
            branding.set_extra_logo(p, item.extra["index"], corner="custom", pos=pos)
            self._layout_overlays()
        elif item is self.logo_item:
            p.logo_corner, p.logo_pos = "custom", pos
        else:
            p.brand_corner, p.brand_pos = "custom", pos
        self.overlayMoved.emit()

    def _cc_toggled(self, on: bool):
        self.btn_cc.setText("CC" if on else "C̶C̶")
        self.subsShownToggled.emit(on)

    def _on_sub_moved(self, cx: float, bottom: float, factor: float):
        """The subtitle was dragged / resized in the preview: keep it there
        (the export puts it at the same place and size)."""
        p = self.project
        if not p:
            return
        c = self._canvas_rect()
        if c.width() <= 0 or c.height() <= 0:
            return
        self.overlayAboutToMove.emit()
        if abs(factor - 1.0) > 0.01:
            p.subtitle_scale = round(max(0.4, min(3.0, (p.subtitle_scale or 1.0) * factor)), 2)
        half = self.sub_item.text_rect().width() * factor / 2
        x = max(c.left() + half, min(c.right() - half, cx)) if half * 2 < c.width() \
            else c.center().x()
        p.sub_x = round(max(3.0, min(97.0, (x - c.left()) / c.width() * 100)), 1)
        # the text must stay on the picture: at least its height above the bottom
        top_room = self.sub_item.text_rect().height() * factor / c.height() * 100
        pct = (c.bottom() - bottom) / c.height() * 100
        p.sub_bottom = round(max(0.0, min(95.0 - top_room, pct)), 1)
        p.sub_position = "bottom"            # moved by hand: no longer glued to the old ones
        self._position_sub()
        self.overlayMoved.emit()

    def _cover_pressed(self):
        self.pause()
        self.overlayAboutToMove.emit()      # (undo)

    def _on_cover_moved(self, rect: QRectF):
        """The hide box was dragged / resized: keep it there (the export too)."""
        p = self.project
        if not p:
            return
        c = self._canvas_rect()
        if c.width() <= 0 or c.height() <= 0:
            return
        sx, sy, sw, sh = branding.source_on_canvas(p, c.width(), c.height())
        if sw <= 0 or sh <= 0:
            return
        fx = (rect.left() - c.left() - sx) / sw
        fy = (rect.top() - c.top() - sy) / sh
        fw, fh = rect.width() / sw, rect.height() / sh
        fw, fh = max(0.02, min(1.0, fw)), max(0.02, min(1.0, fh))
        fx, fy = max(0.0, min(1.0 - fw, fx)), max(0.0, min(1.0 - fh, fy))
        p.cover_rect = [round(fx, 4), round(fy, 4), round(fw, 4), round(fh, 4)]
        self._layout_overlays()
        self._position_sub()
        self.overlayMoved.emit()

    def _on_item_resized(self, item, rect: QRectF):
        """A corner of the logo / brand text was dragged: new size + place."""
        p = self.project
        if not p:
            return
        c = self._canvas_rect()
        if c.width() <= 0:
            return
        self.overlayAboutToMove.emit()
        old = item.boundingRect()
        factor = rect.width() / max(1.0, old.width())
        pos = branding.pos_from_xy(rect.left() - c.left(), rect.top() - c.top(),
                                   c.width(), c.height(), rect.width(), rect.height())
        if getattr(item, "extra", None):
            branding.set_extra_logo(p, item.extra["index"], corner="custom", pos=pos,
                                    size=round(max(0.03, min(0.8, rect.width() / c.width())), 3))
            self._layout_overlays()
            item.setSelected(True)
            self.overlayMoved.emit()
            return
        if item is self.logo_item:
            p.logo_size = round(max(0.03, min(0.6, rect.width() / c.width())), 3)
        else:
            p.brand_size = round(max(0.3, min(3.0, (p.brand_size or 1.0) * factor)), 2)
        if item is self.logo_item:
            p.logo_corner, p.logo_pos = "custom", pos
        else:
            p.brand_corner, p.brand_pos = "custom", pos
        self._layout_overlays()
        item.setSelected(True)
        self.overlayMoved.emit()

    def _position_sub(self):
        """Lay the subtitle out exactly like the export draws it (both use
        core/subrender.py): same size relative to the picture, same line
        breaks, same place."""
        from core import subrender

        c = self._canvas_rect()
        p = self.project
        if not p:
            return
        ow, oh = self._out_size()
        lines, font, style, scale, cx, ay, centered = subrender.layout(
            p, self._current_sub or "", c.width(), c.height(), ow, oh)
        self.sub_item.set_content(lines, font, style, scale, c.left() + cx, c.top() + ay,
                                  centered)

    @staticmethod
    def _escape(text: str) -> str:
        return (text.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\n", "<br>"))

    def _show_sub(self, text: str):
        if getattr(self, "_subs_hidden", False) or getattr(self, "_crop_mode", False):
            text = ""
        if text == self._current_sub:
            return
        self._current_sub = text
        visible = bool(text)
        self.sub_item.setVisible(visible)
        if visible:
            self._position_sub()

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def retranslate(self):
        """The language changed (ui/appearance.py)."""
        if self.placeholder.isVisible():
            self._set_placeholder()

    def _set_placeholder(self):
        from core.i18n import tr

        self.placeholder.setHtml(
            "<div align='center'><span style='font-size:44px'>🎞️</span><br>"
            f"<b>{tr('Drag & drop a video here').replace('&', '&amp;')}</b><br>"
            f"<span style='font-size:11pt'>{tr('or click to choose a file · MP4 · MOV · MKV')}"
            "</span></div>")

    def load_video(self, path: str):
        self.pause()
        self.player.setSource(QUrl.fromLocalFile(path))
        self.placeholder.setVisible(False)
        self.view.empty = False
        self._t = 0.0
        self._clip_idx = 0

    def clear(self):
        self.pause()
        self.player.setSource(QUrl())
        self.voices.release_all()
        self._set_placeholder()
        self.placeholder.setVisible(True)
        self.view.empty = True
        self._show_sub("")

    def set_project(self, project: Optional[Project]):
        """Called after every edit so the player knows the cut list + subs."""
        self.project = project
        self._mute_ranges = project.dubbed_ranges() if project else []
        self._mute_starts = [a for a, _ in self._mute_ranges]
        self._subs = project.shown_subtitles() if project else []
        on = not (project and project.subs_hidden)
        if self.btn_cc.isChecked() != on:
            self.btn_cc.blockSignals(True)
            self.btn_cc.setChecked(on)
            self.btn_cc.blockSignals(False)
        self.btn_cc.setText("CC" if on else "C̶C̶")
        self._sub_starts = [c.start for c in self._subs]
        self.voices.set_clips(project.audio_clips if project else [])
        if hasattr(self.voices, "set_music"):
            self.voices.set_music(getattr(project, "music_clips", []) if project else [])
        self._update_background()
        self._apply_speed()
        dur = project.sequence_duration() if project else 0.0
        self.seek_slider.setRange(0, int(dur * 1000))
        if self._t > dur:
            self._t = dur
        if not self._playing:
            self._seek_source()
        self._layout_scene()            # ratio / overlays / subtitle size may have changed
        self._update_overlay()
        self._update_labels()
        if not self._playing:
            self._request_still()

    def set_original_volume(self, v: int):
        self._orig_volume = v / 100.0
        self._apply_original_volume()

    def music_only(self) -> bool:
        """Background: music & effects only, and the music track is made
        (checked when the project changes, not on every frame)."""
        return getattr(self, "_music", False)

    def _check_music(self) -> bool:
        p = self.project
        if not p or getattr(p, "bg_mode", "original") != "music" \
                or not hasattr(self.voices, "set_background"):
            return False
        from core.separate import has_music

        try:
            return has_music(p)
        except OSError:
            return False

    def _update_background(self):
        """The music-only track replaces the video's own sound in the preview."""
        self._music = self._check_music()
        if not hasattr(self.voices, "set_background"):
            return
        if self._music:
            from core.separate import music_path

            self.voices.set_background(music_path(self.project), self.project.video_clips,
                                       self._bg_volume())
        else:
            self.voices.set_background(None)
        self._apply_original_volume()

    def _bg_volume(self) -> float:
        return 0.0 if getattr(self, "_orig_muted", False) else getattr(self, "_orig_volume", 0.3)

    def _in_mute_range(self, t: float) -> bool:
        i = bisect.bisect_right(self._mute_starts, t) - 1
        return i >= 0 and t < self._mute_ranges[i][1]

    def _apply_original_volume(self):
        """Mute the original audio while a dubbed line plays (so the original
        speech is not heard under the AI voice); keep it elsewhere."""
        vol = getattr(self, "_orig_volume", 0.3)
        if self.music_only():
            # the music-only track plays in the mixer instead of the video's sound
            bg = self._bg_volume()
            if self._dub_enabled and self.project and self.project.audio_clips \
                    and self._in_mute_range(self._t):
                from core.sync import MUSIC_DUCK

                bg *= MUSIC_DUCK            # (as the export: lower under the AI voice)
            self.voices.bg_volume = bg
            vol = 0.0
        elif getattr(self, "_orig_muted", False):
            vol = 0.0
        elif self._dub_enabled and self.project and self.project.audio_clips \
                and self._in_mute_range(self._t):
            vol = 0.0
        if abs(self.audio_out.volume() - vol) > 1e-3:
            self.audio_out.setVolume(vol)

    def set_music_muted(self, muted: bool):
        """Timeline header speaker on the 🎵 Music track (preview only)."""
        if hasattr(self.voices, "music_on"):
            self.voices.music_on = not muted

    def set_original_muted(self, muted: bool):
        """Timeline header speaker on the video track (preview only)."""
        self._orig_muted = muted
        self._apply_original_volume()

    def set_video_visible(self, on: bool):
        """Timeline header eye on the video track (preview only)."""
        self.video_item.setVisible(on)

    def set_subtitles_visible(self, on: bool):
        """Timeline header eye on the subtitle track (preview only)."""
        self._subs_hidden = not on
        self._current_sub = None
        self._update_overlay()

    # ------------------------------------------------------------------ #
    # Tools: Crop & Rotate / Color preview
    # ------------------------------------------------------------------ #
    def set_crop_mode(self, on: bool, keep_aspect: bool = False):
        """Show the whole frame with an editable dashed crop box (Movavi)."""
        self._crop_mode = on
        self.crop_overlay.keep_aspect = keep_aspect
        if on and self.project:
            p = self.project
            self.crop_overlay.set_fractions(p.crop_left, p.crop_top, p.crop_right, p.crop_bottom)
        self._current_sub = None
        self._layout_scene()
        self._update_overlay()

    def set_crop_keep_aspect(self, on: bool):
        self.crop_overlay.keep_aspect = on

    def _on_crop_dragged(self, l: float, t: float, r: float, b: float):
        if self.cropChangedCallback:
            self.cropChangedCallback(l, t, r, b)

    def _place_still(self, sr: QRectF, angle: float):
        pm = self._still_pix
        if pm is None or pm.isNull() or pm.width() <= 0:
            return
        # scale from the top-left corner (NOT the centre, which shifted the
        # frame), then rotate around the centre of the placed picture
        sx, sy = sr.width() / pm.width(), sr.height() / pm.height()
        cx, cy = sr.width() / 2, sr.height() / 2
        fx, fy = self._flips()
        tr = QTransform().translate(cx, cy).scale(fx, fy).rotate(angle).translate(-cx, -cy) \
            .scale(sx, sy)
        self.still_item.setPos(sr.topLeft())
        self.still_item.setTransformOriginPoint(0, 0)
        self.still_item.setScale(1.0)
        self.still_item.setRotation(0.0)
        self.still_item.setTransform(tr)

    def stop_workers(self):
        w = getattr(self, "_still_worker", None)
        if w is not None and w.isRunning():
            w.wait(5000)

    def _request_still(self):
        """Paused + color adjustments on: show an ffmpeg-rendered frame with the
        colours as they will be exported (debounced, newest request wins)."""
        p = self.project
        if not p or not p.has_video() or self._playing or not effects.has_color(p):
            self.still_item.setVisible(False)
            return
        if not hasattr(self, "_still_timer"):
            self._still_timer = QTimer(self)
            self._still_timer.setSingleShot(True)
            self._still_timer.setInterval(180)
            self._still_timer.timeout.connect(self._render_still)
            self._still_seq = 0
            self._still_worker = None
        self._still_timer.start()

    def _render_still(self):
        from ui.workers import TaskWorker

        p = self.project
        if not p or self._playing or not effects.has_color(p):
            return
        if self._still_worker is not None and self._still_worker.isRunning():
            self._still_timer.start()          # try again when the last one is done
            return
        self._still_seq += 1
        seq = self._still_seq
        snap = copy.copy(p)
        src = p.timeline_to_source(self._t)[1] if p.video_clips else self._t
        out = os.path.join(tempfile.gettempdir(),
                           f"voxdub_color_{os.getpid()}_{seq % 4}.png")
        width = int(min(1280, max(320, self._source_rect().width())))
        worker = TaskWorker(lambda prog, stop: effects.render_color_still(snap, src, out, width),
                            "color", self)

        def done(path, seq=seq):
            if seq != self._still_seq or self._playing or not self.project \
                    or not effects.has_color(self.project):
                return
            self._still_pix = QPixmap(path)
            self.still_item.setPixmap(self._still_pix)
            self._place_still(self._source_rect(), float(self.project.rotate or 0.0))
            self.still_item.setVisible(True)

        worker.done.connect(done)
        worker.failed.connect(lambda e: print(f"[color preview] {e}"))
        self._still_worker = worker
        worker.start()

    def set_dub_volume(self, v: int):
        self.voices.set_volume(v / 100.0)

    def set_dub_enabled(self, on: bool):
        self._dub_enabled = on
        self._sync_voices(force=True)

    def position(self) -> float:
        return self._t

    def is_playing(self) -> bool:
        return self._playing

    def toggle(self):
        if self._playing:
            self.pause()
        else:
            self.play()

    def play(self):
        if not self.project or not self.project.has_video():
            return
        self.still_item.setVisible(False)
        if self._t >= self.project.sequence_duration() - 0.05:
            self._t = 0.0
        self._seek_source()
        self._playing = True
        self.player.play()
        self._sync_voices(force=True)
        self.btn_play.setText("⏸")
        self.playingChanged.emit(True)

    def pause(self):
        was = self._playing
        self._playing = False
        self.player.pause()
        self.voices.pause_all()
        self.btn_play.setText("▶")
        if was:
            self.playingChanged.emit(False)
        self._request_still()

    def seek(self, t: float):
        if not self.project:
            return
        t = max(0.0, min(float(t), self.project.sequence_duration()))
        self._t = t
        self._seek_source()
        self._sync_voices(force=True)
        self._update_overlay()
        self._update_labels()
        self.positionChanged.emit(self._t)
        if not self._playing:
            self._request_still()

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #
    def _seek_source(self):
        if not self.project or not self.project.video_clips:
            return
        idx, src = self.project.timeline_to_source(self._t)
        self._clip_idx = max(0, idx)
        self.player.setPosition(int(src * 1000))
        self._ignore_until = 6      # next few ticks may still report old position

    def _sync_voices(self, force=False):
        self._apply_speed()
        music = self.music_only()
        if hasattr(self.voices, "voices_on"):
            self.voices.voices_on = self._dub_enabled
        playing = self._playing and self.project is not None and (self._dub_enabled or music)
        self.voices.update(self._t, playing, force)

    def _apply_speed(self):
        """Clip Properties > Video > Speed: the preview plays that fast too
        (the video's own sound and the AI voice keep their pitch)."""
        p = self.project
        speed = p.speed() if p else 1.0
        rate = speed
        if p and p.video_clips:
            # a piece slowed for a long line plays slower (the timeline is longer there)
            rate *= p.video_clips[min(max(0, self._clip_idx), len(p.video_clips) - 1)].rate
        if abs(rate - getattr(self, "_rate", 1.0)) >= 0.001:
            self._rate = rate
            try:
                if hasattr(self.player, "setPitchCompensation"):
                    self.player.setPitchCompensation(True)
                self.player.setPlaybackRate(rate)
            except Exception as e:
                print(f"[preview] speed {rate}: {e}")
        if abs(speed - getattr(self, "_speed", 1.0)) >= 0.001:
            self._speed = speed
            if hasattr(self.voices, "set_speed"):
                self.voices.set_speed(speed)

    def _tick(self):
        if not self._playing or not self.project or not self.project.video_clips:
            return
        clips = self.project.video_clips
        if self._clip_idx >= len(clips):
            self._clip_idx = len(clips) - 1
        clip = clips[self._clip_idx]
        src = self.player.position() / 1000.0

        if self._ignore_until > 0:
            self._ignore_until -= 1
            if not (clip.src_in - 0.25 <= src <= clip.src_out + 0.25):
                return
            self._ignore_until = 0

        if src >= clip.src_out - 0.03:
            # reached the end of this clip -> jump to next one
            if self._clip_idx + 1 < len(clips):
                self._clip_idx += 1
                nxt = clips[self._clip_idx]
                if abs(nxt.src_in - clip.src_out) < 0.05 and src < nxt.src_out:
                    # the next piece follows on in the file (only its speed
                    # differs): no seek, so no stutter
                    self._t = nxt.to_timeline(max(src, nxt.src_in))
                else:
                    self._t = nxt.start
                    self.player.setPosition(int(nxt.src_in * 1000))
                    self._ignore_until = 6
                self._apply_speed()
            else:
                self._t = self.project.sequence_duration()
                self.pause()
        else:
            self._t = clip.to_timeline(max(src, clip.src_in))

        self._sync_voices()
        self._update_overlay()
        self._update_labels()
        self.positionChanged.emit(self._t)

    def _update_overlay(self):
        self._apply_original_volume()
        text = ""
        i = bisect.bisect_right(self._sub_starts, self._t) - 1
        # a long earlier subtitle can still be showing: look back a little
        for k in range(i, max(-1, i - 4), -1):
            if self._subs[k].start <= self._t < self._subs[k].end:
                text = self._subs[k].text
                break
        self._show_sub(text)
        p = self.project
        if p and (branding.MOTIONS.get(p.logo_motion, 0.0) > 0
                  or branding.MOTIONS.get(p.brand_motion, 0.0) > 0):
            self._place_branding()

    def _update_labels(self):
        dur = self.project.sequence_duration() if self.project else 0.0
        sp = self.project.speed() if self.project else 1.0
        if abs(sp - 1.0) > 0.001:       # Video > Speed: the time of the exported video
            self.time_label.setText(f"{format_time(self._t / sp)} / {format_time(dur / sp, False)}"
                                    f"  ·  {round(sp * 100)}%")
        else:
            self.time_label.setText(f"{format_time(self._t)} / {format_time(dur, False)}")
        if not self.seek_slider.isSliderDown():
            self.seek_slider.blockSignals(True)
            self.seek_slider.setValue(int(self._t * 1000))
            self.seek_slider.blockSignals(False)

    def _on_media_status(self, status):
        if status == QMediaPlayer.MediaStatus.LoadedMedia:
            self._seek_source()
        elif status == QMediaPlayer.MediaStatus.EndOfMedia and self._playing:
            self.pause()

    def _on_error(self, error, message):
        if error != QMediaPlayer.Error.NoError:
            self.placeholder.setPlainText(f"Preview error: {message}")
            self._layout_scene()
            self.placeholder.setVisible(True)
            self._layout_scene()


# --------------------------------------------------------------------------- #
# AI voice playback
# --------------------------------------------------------------------------- #
class VoicePool:
    """Plays the AI voice clips directly from their own wav files.

    A few QMediaPlayers are handed out to the clips around the playhead:
    a clip is loaded LOOKAHEAD seconds before it starts, played from the
    right offset when the playhead reaches it, and released when it ends.
    """

    SIZE = 4
    LOOKAHEAD = 1.5
    MAX_DRIFT_MS = 150

    def __init__(self, parent):
        self.slots = []
        for _ in range(self.SIZE):
            player = QMediaPlayer(parent)
            out = QAudioOutput(parent)
            player.setAudioOutput(out)
            self.slots.append({"player": player, "out": out, "clip": None, "path": ""})
        self.clips = []
        self.starts: List[float] = []
        self.by_id: Dict[str, object] = {}
        self.volume = 1.0

    def set_speed(self, speed: float):
        """Video › Speed: the clips play as fast as the video (pitch kept);
        positions stay in timeline time."""
        for slot in self.slots:
            try:
                if hasattr(slot["player"], "setPitchCompensation"):
                    slot["player"].setPitchCompensation(True)
                slot["player"].setPlaybackRate(speed)
            except Exception:
                pass

    def set_clips(self, clips):
        self.clips = sorted(clips, key=lambda c: c.start)
        self.starts = [c.start for c in self.clips]
        self.by_id = {c.id: c for c in self.clips}
        # forget clips that were deleted / replaced
        for slot in self.slots:
            if slot["clip"] is not None and slot["clip"].id not in self.by_id:
                self._release(slot)
            elif slot["clip"] is not None:
                slot["clip"] = self.by_id[slot["clip"].id]   # moved / trimmed copy

    def set_volume(self, v: float):
        self.volume = v
        for slot in self.slots:
            if slot["clip"] is not None:
                self._apply_volume(slot)

    def _apply_volume(self, slot):
        slot["out"].setVolume(max(0.0, min(1.0, self.volume * slot["clip"].volume)))

    def _release(self, slot):
        slot["player"].stop()
        slot["clip"] = None

    def release_all(self):
        for slot in self.slots:
            self._release(slot)
            slot["player"].setSource(QUrl())
            slot["path"] = ""

    def pause_all(self):
        for slot in self.slots:
            if slot["clip"] is not None:
                slot["player"].pause()

    def wanted(self, t: float):
        """Clips playing now or starting within LOOKAHEAD seconds."""
        i = bisect.bisect_right(self.starts, t + self.LOOKAHEAD)
        out = []
        k = i - 1
        while k >= 0 and len(out) < self.SIZE:
            c = self.clips[k]
            if c.end > t:
                out.append(c)
            elif t - c.start > 120:      # clips are short: stop looking far back
                break
            k -= 1
        out.reverse()
        return out

    def update(self, t: float, playing: bool, force: bool = False):
        if not playing:
            self.pause_all()
            return
        want = self.wanted(t)
        want_ids = {c.id for c in want}
        for slot in self.slots:
            if slot["clip"] is not None and slot["clip"].id not in want_ids:
                self._release(slot)
        have = {slot["clip"].id for slot in self.slots if slot["clip"] is not None}
        free = [slot for slot in self.slots if slot["clip"] is None]
        for clip in want:
            if clip.id not in have and free:
                slot = free.pop(0)
                slot["clip"] = clip
                if slot["path"] != clip.path:
                    slot["player"].setSource(QUrl.fromLocalFile(clip.path))
                    slot["path"] = clip.path
                self._apply_volume(slot)
                slot["player"].setPosition(int(clip.src_in * 1000))
        for slot in self.slots:
            clip = slot["clip"]
            if clip is None:
                continue
            player = slot["player"]
            if t < clip.start:
                if player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
                    player.pause()
                continue
            expected = int((clip.src_in + t - clip.start) * 1000)
            state = player.playbackState()
            if state != QMediaPlayer.PlaybackState.PlayingState:
                player.setPosition(expected)
                player.play()
            elif force or abs(player.position() - expected) > self.MAX_DRIFT_MS:
                player.setPosition(expected)



# --------------------------------------------------------------------------- #
# Crop box (Movavi "Crop and Rotate")
# --------------------------------------------------------------------------- #
class CropOverlay(QGraphicsItem):
    """Dashed crop rectangle with a 3x3 grid and 8 handles. Drag the inside to
    move it, drag a handle to resize. Reports crop fractions (left, top, right,
    bottom) of the frame through on_change."""

    HANDLE = 5.0
    MIN_FRAC = 0.10            # keep at least 10 % of the frame
    MAX_EDGE = 0.45            # each edge may cut at most 45 % (branding.MAX_CROP)

    def __init__(self, on_change):
        super().__init__()
        self.on_change = on_change
        self.frame = QRectF(0, 0, 100, 100)     # the whole source frame on screen
        self.l = self.t = self.r = self.b = 0.0
        self.keep_aspect = False
        self._drag = None
        self.setAcceptHoverEvents(True)
        self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)

    # geometry
    def set_frame(self, rect: QRectF):
        self.prepareGeometryChange()
        self.frame = QRectF(rect)
        self.update()

    def set_fractions(self, l, t, r, b):
        self.l, self.t, self.r, self.b = (float(v or 0.0) for v in (l, t, r, b))
        self.update()

    def box(self) -> QRectF:
        f = self.frame
        return QRectF(f.left() + self.l * f.width(), f.top() + self.t * f.height(),
                      f.width() * (1 - self.l - self.r), f.height() * (1 - self.t - self.b))

    def boundingRect(self) -> QRectF:
        return self.frame.adjusted(-10, -10, 10, 10)

    def _handles(self):
        r = self.box()
        cx, cy = r.center().x(), r.center().y()
        return {"tl": QPointF(r.left(), r.top()), "t": QPointF(cx, r.top()),
                "tr": QPointF(r.right(), r.top()), "r": QPointF(r.right(), cy),
                "br": QPointF(r.right(), r.bottom()), "b": QPointF(cx, r.bottom()),
                "bl": QPointF(r.left(), r.bottom()), "l": QPointF(r.left(), cy)}

    # painting
    def paint(self, p: QPainter, option, widget=None):
        r = self.box()
        f = self.frame
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(0, 0, 0, 110))            # dim what will be cut off
        for part in (QRectF(f.left(), f.top(), f.width(), r.top() - f.top()),
                     QRectF(f.left(), r.bottom(), f.width(), f.bottom() - r.bottom()),
                     QRectF(f.left(), r.top(), r.left() - f.left(), r.height()),
                     QRectF(r.right(), r.top(), f.right() - r.right(), r.height())):
            if part.width() > 0 and part.height() > 0:
                p.drawRect(part)
        for color, style in ((QColor(0, 0, 0, 160), Qt.PenStyle.SolidLine),
                             (QColor("white"), Qt.PenStyle.DashLine)):
            pen = QPen(color, 1.2)
            pen.setStyle(style)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRect(r)
            for k in (1, 2):                            # rule-of-thirds grid
                x = r.left() + r.width() * k / 3
                y = r.top() + r.height() * k / 3
                p.drawLine(QPointF(x, r.top()), QPointF(x, r.bottom()))
                p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y))
        p.setPen(QPen(QColor(0, 0, 0, 180), 1))
        p.setBrush(QColor("white"))
        for pt in self._handles().values():
            p.drawEllipse(pt, self.HANDLE - 1.5, self.HANDLE - 1.5)

    # mouse
    def _hit(self, pos: QPointF) -> str:
        for name, pt in self._handles().items():
            if (pt - pos).manhattanLength() <= self.HANDLE * 2.4:
                return name
        return "move" if self.box().contains(pos) else ""

    def hoverMoveEvent(self, event):
        cursors = {"tl": Qt.CursorShape.SizeFDiagCursor, "br": Qt.CursorShape.SizeFDiagCursor,
                   "tr": Qt.CursorShape.SizeBDiagCursor, "bl": Qt.CursorShape.SizeBDiagCursor,
                   "t": Qt.CursorShape.SizeVerCursor, "b": Qt.CursorShape.SizeVerCursor,
                   "l": Qt.CursorShape.SizeHorCursor, "r": Qt.CursorShape.SizeHorCursor,
                   "move": Qt.CursorShape.SizeAllCursor}
        self.setCursor(cursors.get(self._hit(event.pos()), Qt.CursorShape.ArrowCursor))

    def mousePressEvent(self, event):
        mode = self._hit(event.pos())
        if not mode:
            event.ignore()
            return
        self._drag = (mode, event.pos(), (self.l, self.t, self.r, self.b))
        event.accept()

    def mouseMoveEvent(self, event):
        if not self._drag:
            return
        mode, start, (l0, t0, r0, b0) = self._drag
        f = self.frame
        dx = (event.pos().x() - start.x()) / max(1.0, f.width())
        dy = (event.pos().y() - start.y()) / max(1.0, f.height())
        l, t, r, b = l0, t0, r0, b0
        if mode == "move":
            dx = max(-l0, min(r0, dx))
            dy = max(-t0, min(b0, dy))
            l, r, t, b = l0 + dx, r0 - dx, t0 + dy, b0 - dy
        else:
            if "l" in mode:
                l = l0 + dx
            if "r" in mode:
                r = r0 - dx
            if "t" in mode:
                t = t0 + dy
            if "b" in mode:
                b = b0 - dy
            l, t, r, b = self._limit(l, t, r, b)
            if self.keep_aspect:
                l, t, r, b = self._keep_ratio(mode, (l0, t0, r0, b0), l, t, r, b)
        self.l, self.t, self.r, self.b = l, t, r, b
        self.update()
        self.on_change(round(l, 4), round(t, 4), round(r, 4), round(b, 4))

    def _limit(self, l, t, r, b):
        m = self.MAX_EDGE
        l, t, r, b = (max(0.0, min(m, v)) for v in (l, t, r, b))
        if 1 - l - r < self.MIN_FRAC:
            r = 1 - l - self.MIN_FRAC
        if 1 - t - b < self.MIN_FRAC:
            b = 1 - t - self.MIN_FRAC
        return l, t, r, b

    def _keep_ratio(self, mode, orig, l, t, r, b):
        """Keep the frame's own width/height ratio (no black bars in export)."""
        w, h = 1 - l - r, 1 - t - b              # as fractions -> same ratio as frame
        side = min(w, h) if mode in ("tl", "tr", "bl", "br") else (w if mode in "lr" else h)
        side = max(self.MIN_FRAC, side)
        l0, t0, r0, b0 = orig
        cx, cy = l0 + (1 - l0 - r0) / 2, t0 + (1 - t0 - b0) / 2
        if mode in ("l", "r"):
            t, b = cy - side / 2, 1 - (cy + side / 2)
            if mode == "l":
                l = 1 - r - side
            else:
                r = 1 - l - side
        elif mode in ("t", "b"):
            l, r = cx - side / 2, 1 - (cx + side / 2)
            if mode == "t":
                t = 1 - b - side
            else:
                b = 1 - t - side
        else:
            if "l" in mode:
                l = 1 - r - side
            else:
                r = 1 - l - side
            if "t" in mode:
                t = 1 - b - side
            else:
                b = 1 - t - side
        m = self.MAX_EDGE
        if min(l, t, r, b) < 0 or max(l, t, r, b) > m:
            return orig
        return l, t, r, b

    def mouseReleaseEvent(self, event):
        self._drag = None
