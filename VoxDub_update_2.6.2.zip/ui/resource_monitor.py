"""
resource_monitor.py - the small "GPU 34% · VRAM 3.2/8.0 GB · RAM 9/16 GB"
label (main window status bar, Batch queue top bar).

Read every few seconds in a thread (nvidia-smi can take a moment), green /
orange / red by how full the GPU memory or RAM is. A click opens a menu:
what to do when the GPU memory is too small for Whisper.
"""

import threading
from typing import Callable, Optional

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QAction, QActionGroup
from PySide6.QtWidgets import QMenu, QToolButton

from core import resources, settings

COLORS = {"ok": "#2fd59a", "busy": "#f0a640", "full": "#ff6b6b"}
EVERY_MS = 3000


class _Reader(QObject):
    done = Signal(object, object)


class ResourceMonitor(QToolButton):
    def __init__(self, parent=None, jobs: Optional[Callable[[], str]] = None,
                 every_ms: int = EVERY_MS):
        super().__init__(parent)
        self.jobs = jobs
        self.setAutoRaise(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.setText("GPU …")
        self.setToolTip("GPU & memory use. Click: what to do when the GPU memory is low.")
        self.gpus, self.ram, self.state = [], (0.0, 0.0), "ok"
        self._busy = False
        self._reader = _Reader()
        self._reader.done.connect(self._show)
        menu = QMenu(self)
        menu.addSection("When the GPU memory is too small for Whisper")
        grp = QActionGroup(menu)
        mode = settings.get("low_vram", "smaller") or "smaller"
        for key, label in resources.LOW_VRAM_CHOICES:
            a = QAction(label, menu, checkable=True)
            a.setChecked(key == mode)
            a.triggered.connect(lambda _=False, k=key: settings.set("low_vram", k))
            grp.addAction(a)
            menu.addAction(a)
        self.setMenu(menu)
        self.timer = QTimer(self)
        self.timer.setInterval(every_ms)
        self.timer.timeout.connect(self.refresh)
        self.timer.start()
        QTimer.singleShot(200, self.refresh)

    def refresh(self):
        """Read the numbers in a thread (never freezes the window)."""
        if self._busy or not self.isVisible():
            return
        self._busy = True

        def work():
            try:
                g, r = resources.gpu_stats(), resources.ram_stats()
            except Exception:
                g, r = [], (0.0, 0.0)
            try:
                self._reader.done.emit(g, r)
            except RuntimeError:            # (the window was closed meanwhile)
                pass

        threading.Thread(target=work, daemon=True).start()

    def _show(self, gpus, ram):
        self._busy = False
        self.gpus, self.ram = gpus, ram
        self.state = resources.level(gpus, ram)
        text = resources.summary(gpus, ram)
        if self.jobs:
            try:
                extra = self.jobs()
            except Exception:
                extra = ""
            if extra:
                text += f"  ·  {extra}"
        self.setText(text)
        self.setStyleSheet(f"QToolButton {{ color: {COLORS[self.state]}; }}")
        tip = "GPU & memory use (every 3 s)."
        if gpus:
            tip = f"{gpus[0]['name']}\n" + tip
        if self.state != "ok":
            tip += ("\n\nAlmost full: run fewer videos at once (Batch › At once), close "
                    "other programs, or choose a smaller Whisper model.\n"
                    "(Whisper large-v3 takes almost all of a 4 GB card while it is loaded - "
                    "that works; there is just no room for more.)")
        self.setToolTip(tip + "\nClick: what to do when the GPU memory is low.")
