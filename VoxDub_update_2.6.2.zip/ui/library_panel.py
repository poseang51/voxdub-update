"""
library_panel.py - The Filmora-style library of the Edit workspace (left):

    [🎞 Media] [T Titles] [★ Stickers] [◐ Filters]
    Media     the media bin: imported videos with thumbnails (double-click opens)
    Titles    the brand text that stays on screen + the subtitle looks
    Stickers  logos from a folder: use as the logo / add another logo
    Filters   colour looks with a preview of the current frame

Nothing here edits the project directly: it asks the window through
`apply(kind, fn)` (one Undo step) or the open / logo signals.
"""

import os
import tempfile
import threading
from typing import Callable, Dict, List

from PySide6.QtCore import QObject, QSize, Qt, Signal
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMenu, QPushButton, QStackedWidget, QToolButton,
    QVBoxLayout, QWidget,
)

from core import settings
from core.branding import SUB_PRESETS
from core.media import VIDEO_EXT, VIDEO_FILTER
from core.music import AUDIO_EXT
from core.project import Project

BIN_SETTING = "media_bin"
LOGO_DIR_SETTING = "logo_folder"
IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp", ".bmp")
ROLE = Qt.ItemDataRole.UserRole

# colour looks: field -> value (everything else back to neutral)
FILTERS: Dict[str, Dict[str, float]] = {
    "None": {},
    "Vivid": {"color_saturation": 35, "color_contrast": 15},
    "Warm": {"color_temperature": 35, "color_saturation": 10},
    "Cool": {"color_temperature": -35, "color_saturation": 5},
    "Cinematic": {"color_contrast": 22, "color_saturation": -15, "color_shadows": -15,
                  "color_highlights": 10, "color_temperature": -10},
    "Bright": {"color_brightness": 12, "color_gamma": 1.1},
    "Soft": {"color_contrast": -15, "color_highlights": -10, "color_saturation": -10},
    "Drama": {"color_contrast": 35, "color_saturation": -10, "color_shadows": -20},
    "Vintage": {"color_saturation": -30, "color_temperature": 25, "color_contrast": -10,
                "color_tint": 8},
    "Black & White": {"color_saturation": -100, "color_contrast": 10},
}


def apply_filter(p: Project, name: str):
    from core import effects

    effects.reset_color(p, manual=True, auto=False)
    for f, v in FILTERS.get(name, {}).items():
        setattr(p, f, float(v))


def current_filter(p: Project) -> str:
    """The look the project has now ("" = changed by hand)."""
    from core import effects

    for name, vals in FILTERS.items():
        neutral = {f: (1.0 if f == "color_gamma" else 0.0) for f in effects.COLOR_FIELDS}
        neutral["color_gamma"] = 1.0
        want = {**neutral, **{k: float(v) for k, v in vals.items()}}
        if all(abs(float(getattr(p, f, 0) or 0) - v) < 1e-6 for f, v in want.items()):
            return name
    return ""


def bin_items() -> List[str]:
    return [p for p in (settings.get(BIN_SETTING, []) or []) if isinstance(p, str)]


def add_to_bin(paths: List[str]) -> List[str]:
    have = bin_items()
    for p in paths:
        p = os.path.abspath(p)
        if p.lower().endswith(VIDEO_EXT + AUDIO_EXT) and os.path.isfile(p):
            have = [h for h in have if os.path.normcase(h) != os.path.normcase(p)]
            have.insert(0, p)
    settings.set(BIN_SETTING, have[:60])
    return have[:60]


class _Worker(QObject):
    """Runs small jobs (thumbnails, filter previews) in a thread."""
    ready = Signal(str, str)            # key, picture path

    def run(self, jobs: List[tuple]):
        """jobs: [(key, fn() -> picture path)]"""
        def go():
            for key, fn in jobs:
                try:
                    path = fn()
                except Exception:
                    path = ""
                self.ready.emit(key, path or "")
        threading.Thread(target=go, daemon=True).start()


class _DragGrid(QListWidget):
    """Tiles can be dragged out as files (onto the timeline / preview)."""

    def mimeData(self, items):
        from PySide6.QtCore import QMimeData, QUrl

        md = QMimeData()
        md.setUrls([QUrl.fromLocalFile(it.data(ROLE)) for it in items if it.data(ROLE)])
        return md


def _grid(drag: bool = False) -> QListWidget:
    g = _DragGrid() if drag else QListWidget()
    g.setObjectName("LibGrid")
    g.setViewMode(QListWidget.ViewMode.IconMode)
    g.setResizeMode(QListWidget.ResizeMode.Adjust)
    g.setMovement(QListWidget.Movement.Static)
    g.setSpacing(8)
    g.setWordWrap(True)
    g.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    if drag:            # (after setMovement: Static switches dragging off)
        g.setDragEnabled(True)
        g.setDragDropMode(QAbstractItemView.DragDropMode.DragOnly)
        g.setDefaultDropAction(Qt.DropAction.CopyAction)
    return g


def _add(grid: QListWidget, it: QListWidgetItem):
    """Every tile the same size (picture + one line of name), also before its
    picture is there."""
    gs = grid.gridSize()
    it.setSizeHint(QSize(gs.width() - 6, gs.height() - 6))
    it.setTextAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
    grid.addItem(it)


def _hint(text: str) -> QLabel:
    lb = QLabel(text)
    lb.setObjectName("MutedLabel")
    lb.setWordWrap(True)
    return lb


# --------------------------------------------------------------------------- #
def _note_icon() -> QIcon:
    """A ♪ tile for sound files."""
    from PySide6.QtGui import QColor, QFont, QPainter

    pm = QPixmap(150, 84)
    pm.fill(QColor("#1f3b4f"))
    p = QPainter(pm)
    p.setPen(QColor("#8cc8f0"))
    p.setFont(QFont("Segoe UI Symbol", 34))
    p.drawText(pm.rect(), Qt.AlignmentFlag.AlignCenter, "♪")
    p.end()
    return QIcon(pm)


def is_audio(path: str) -> bool:
    return path.lower().endswith(AUDIO_EXT)


class MediaPage(QWidget):
    openRequested = Signal(str)
    musicRequested = Signal(str)        # a sound file: on the Music track at the playhead

    def __init__(self):
        super().__init__()
        self.current = ""
        self.worker = _Worker()
        self.worker.ready.connect(self._thumb_ready)
        bar = QHBoxLayout()
        b_import = QPushButton("＋  Import")
        b_import.setObjectName("LibImport")
        b_import.clicked.connect(self._import)
        bar.addWidget(b_import)
        bar.addStretch(1)
        self.grid = _grid(drag=True)
        self.grid.setIconSize(QSize(150, 84))
        self.grid.setGridSize(QSize(166, 124))
        self.grid.itemDoubleClicked.connect(lambda it: self._activate(it.data(ROLE)))
        self.grid.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.grid.customContextMenuRequested.connect(self._menu)
        self.empty = QLabel("⤓\nImport videos and music, or drop them here")
        self.empty.setObjectName("LibEmpty")
        self.empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty.setMinimumHeight(160)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.addLayout(bar)
        lay.addWidget(self.empty)
        lay.addWidget(self.grid, 1)
        lay.addWidget(_hint("Drag music (♪) onto the timeline where it should play – or "
                            "double-click it (at the playhead). Double-click a video to open "
                            "it in the editor."))
        self.setAcceptDrops(True)

    def _activate(self, path: str):
        (self.musicRequested if is_audio(path) else self.openRequested).emit(path)

    def _import(self):
        pat = " ".join("*" + e for e in AUDIO_EXT)
        files, _ = QFileDialog.getOpenFileNames(
            self, "Import videos and music", "",
            VIDEO_FILTER.replace(")", " " + pat + ")", 1) + f";;Music ({pat})")
        if files:
            add_to_bin(files)
            self.refresh(self.current)

    def dragEnterEvent(self, ev):
        if ev.mimeData().hasUrls():
            ev.acceptProposedAction()

    def dropEvent(self, ev):
        add_to_bin([os.path.normpath(u.toLocalFile()) for u in ev.mimeData().urls() if u.isLocalFile()])
        self.refresh(self.current)

    def _menu(self, pos):
        it = self.grid.itemAt(pos)
        if it is None:
            return
        path = it.data(ROLE)
        m = QMenu(self)
        a_open = m.addAction("Add to the Music track at the playhead" if is_audio(path)
                             else "Open in the editor")
        a_dir = m.addAction("Show in folder")
        a_rm = m.addAction("Remove from the list")
        act = m.exec(self.grid.mapToGlobal(pos))
        if act is a_open:
            self._activate(path)
        elif act is a_dir:
            from ui.main_window import open_path

            open_path(os.path.dirname(path))
        elif act is a_rm:
            settings.set(BIN_SETTING, [p for p in bin_items() if p != path])
            self.refresh(self.current)

    def refresh(self, current: str = "", force: bool = False):
        from ui.batch_dialog import make_thumb, thumb_path

        state = (current or "", tuple(bin_items()))
        if not force and state == getattr(self, "_state", None):
            return                      # nothing new: keep the tiles (no reload)
        self.current = current or ""
        paths = bin_items()
        if self.current and os.path.isfile(self.current) and not any(
                os.path.normcase(p) == os.path.normcase(self.current) for p in paths):
            paths = add_to_bin([self.current])
        paths = [p for p in paths if os.path.isfile(p)]
        self.grid.clear()
        jobs = []
        for p in paths:
            name = os.path.splitext(os.path.basename(p))[0]
            on = self.current and os.path.normcase(p) == os.path.normcase(self.current)
            it = QListWidgetItem(("▶ " if on else "") + name)
            it.setData(ROLE, p)
            it.setToolTip(p + ("\n(open in the editor now)" if on else ""))
            tp = thumb_path(p)
            if is_audio(p):
                it.setIcon(_note_icon())
            elif os.path.isfile(tp):
                it.setIcon(QIcon(tp))
            else:
                jobs.append((p, lambda p=p, tp=tp: tp if make_thumb(p, tp) else ""))
            _add(self.grid, it)
        self.empty.setVisible(not paths)
        self.grid.setVisible(bool(paths))
        self._state = (self.current, tuple(bin_items()))
        if jobs:
            self.worker.run(jobs)

    def _thumb_ready(self, path: str, pic: str):
        if not pic:
            return
        for i in range(self.grid.count()):
            it = self.grid.item(i)
            if it.data(ROLE) == path:
                it.setIcon(QIcon(pic))


class TitlesPage(QWidget):
    def __init__(self, apply: Callable):
        super().__init__()
        self.apply = apply
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(8)
        head = QLabel("Brand text  (stays on screen the whole video)")
        head.setObjectName("InsHead")
        lay.addWidget(head)
        self.ed_text = QLineEdit()
        self.ed_text.setPlaceholderText("e.g. កែសម្រួលដោយ F2 MOVIE")
        b_set = QPushButton("Apply")
        b_set.setObjectName("LibImport")
        b_set.clicked.connect(self._set_text)
        b_clear = QPushButton("Remove")
        b_clear.clicked.connect(lambda: (self.ed_text.clear(), self._set_text()))
        row = QHBoxLayout()
        row.addWidget(self.ed_text, 1)
        row.addWidget(b_set)
        row.addWidget(b_clear)
        lay.addLayout(row)
        lay.addWidget(_hint("Drag it on the video to place it; colour, size and movement are "
                            "in the Style tab."))
        head2 = QLabel("Subtitle looks")
        head2.setObjectName("InsHead")
        lay.addWidget(head2)
        grid = QGridLayout()
        grid.setSpacing(8)
        self.look_buttons = {}
        for i, (key, (label, vals)) in enumerate(SUB_PRESETS.items()):
            name, _, desc = label.partition(" – ")
            b = QPushButton(f"{name}\n{desc}")
            b.setObjectName("LibLook")
            b.setCheckable(True)
            b.setMinimumHeight(64)
            fg = vals.get("sub_color", "#FFFFFF")
            bg = vals.get("sub_box_color", "#000000") if vals.get("sub_box") else "#1b2129"
            b.setStyleSheet(f"QPushButton#LibLook {{ color: {fg}; background: {bg}; "
                            f"font-weight: {'800' if vals.get('sub_bold') else '600'}; }}")
            b.clicked.connect(lambda _=False, k=key: self._look(k))
            self.look_buttons[key] = b
            grid.addWidget(b, i // 2, i % 2)
        lay.addLayout(grid)
        lay.addStretch(1)

    def load(self, p: Project):
        self.ed_text.setText(p.brand_text or "")
        from core.branding import SUB_PRESETS as SP

        now = ""
        for key, (_l, vals) in SP.items():
            if all(getattr(p, f, None) == v for f, v in vals.items()):
                now = key
        for k, b in self.look_buttons.items():
            b.setChecked(k == now)

    def _set_text(self):
        text = self.ed_text.text().strip()
        self.apply("style", lambda p: setattr(p, "brand_text", text))

    def _look(self, key: str):
        vals = SUB_PRESETS[key][1]

        def do(p):
            for f, v in vals.items():
                setattr(p, f, v)
        self.apply("style", do)
        for k, b in self.look_buttons.items():
            b.setChecked(k == key)


class StickersPage(QWidget):
    logoRequested = Signal(str)          # the main logo
    extraLogoRequested = Signal(str)     # one more logo

    def __init__(self, apply: Callable):
        super().__init__()
        self.apply = apply
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        bar = QHBoxLayout()
        self.lb_dir = QLabel("")
        self.lb_dir.setObjectName("MutedLabel")
        b_dir = QPushButton("📁 Logo folder…")
        b_dir.clicked.connect(self._choose_dir)
        b_file = QPushButton("＋ Logo file…")
        b_file.clicked.connect(self._choose_file)
        bar.addWidget(b_dir)
        bar.addWidget(b_file)
        bar.addStretch(1)
        lay.addLayout(bar)
        lay.addWidget(self.lb_dir)
        self.grid = _grid()
        self.grid.setIconSize(QSize(96, 96))
        self.grid.setGridSize(QSize(118, 128))
        self.grid.itemDoubleClicked.connect(lambda it: self.logoRequested.emit(it.data(ROLE)))
        lay.addWidget(self.grid, 1)
        brow = QHBoxLayout()
        self.b_main = QPushButton("Use as the logo")
        self.b_main.setObjectName("LibImport")
        self.b_main.clicked.connect(lambda: self._use(False))
        self.b_extra = QPushButton("Add as another logo")
        self.b_extra.clicked.connect(lambda: self._use(True))
        b_none = QPushButton("No logo")
        b_none.clicked.connect(lambda: self.apply("style", lambda p: setattr(p, "logo_path", "")))
        for b in (self.b_main, self.b_extra, b_none):
            brow.addWidget(b)
        brow.addStretch(1)
        lay.addLayout(brow)
        lay.addWidget(_hint("Double-click a logo to use it. PNG with a transparent background "
                            "looks best. Drag it on the video to place it."))

    def folder(self) -> str:
        return settings.get(LOGO_DIR_SETTING, "") or ""

    def _choose_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of logos", self.folder())
        if d:
            settings.set(LOGO_DIR_SETTING, d)
            self.refresh()

    def _choose_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Logo", self.folder(),
                                              "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if path:
            if not self.folder():
                settings.set(LOGO_DIR_SETTING, os.path.dirname(path))
                self.refresh()
            self.logoRequested.emit(path)

    def _use(self, extra: bool):
        it = self.grid.currentItem()
        if it is None:
            return
        (self.extraLogoRequested if extra else self.logoRequested).emit(it.data(ROLE))

    def refresh(self, current: str = ""):
        d = self.folder()
        self.grid.clear()
        if not d or not os.path.isdir(d):
            self.lb_dir.setText("Choose the folder where you keep your logos.")
            return
        self.lb_dir.setText(d)
        for f in sorted(os.listdir(d), key=str.lower):
            if not f.lower().endswith(IMAGE_EXT):
                continue
            p = os.path.join(d, f)
            it = QListWidgetItem(QIcon(QPixmap(p)), os.path.splitext(f)[0])
            it.setData(ROLE, p)
            it.setToolTip(p)
            if current and os.path.normcase(p) == os.path.normcase(current):
                it.setText("✓ " + it.text())
            _add(self.grid, it)


class FiltersPage(QWidget):
    def __init__(self, apply: Callable):
        super().__init__()
        self.apply = apply
        self.worker = _Worker()
        self.worker.ready.connect(self._pic_ready)
        self._key = ""
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        self.grid = _grid()
        self.grid.setIconSize(QSize(150, 84))
        self.grid.setGridSize(QSize(166, 118))
        self.grid.itemClicked.connect(self._chosen)
        for name in FILTERS:
            it = QListWidgetItem(name)
            it.setData(ROLE, name)
            _add(self.grid, it)
        lay.addWidget(self.grid, 1)
        lay.addWidget(_hint("Click a look to use it (one Undo step). Fine-tune it in "
                            "🎨 Color on the right. The pictures show the frame at the playhead."))

    def _chosen(self, it):
        name = it.data(ROLE)
        self.apply("color", lambda p: apply_filter(p, name))

    def load(self, p: Project, at: float = 0.0):
        now = current_filter(p)
        for i in range(self.grid.count()):
            it = self.grid.item(i)
            it.setText(("✓ " if it.data(ROLE) == now else "") + it.data(ROLE))
        if not p.has_video():
            return
        # the pictures again only for another video, or 30 s further on - not on
        # every Undo / step (10 ffmpeg frames each time slowed the preview)
        key = f"{p.video_path}|{int(at // 30)}|{p.width}x{p.height}"
        if key == self._key:
            return
        self._key = key
        import copy

        from core import effects

        folder = tempfile.mkdtemp(prefix="vxd_filters_")
        jobs = []
        for name in FILTERS:
            q = copy.copy(p)
            apply_filter(q, name)
            out = os.path.join(folder, f"{len(jobs)}.png")
            jobs.append((name, lambda q=q, out=out: effects.render_color_still(q, at, out, 300)))
        self.worker.run(jobs)

    def _pic_ready(self, name: str, pic: str):
        if not pic:
            return
        for i in range(self.grid.count()):
            it = self.grid.item(i)
            if it.data(ROLE) == name:
                it.setIcon(QIcon(pic))


# --------------------------------------------------------------------------- #
class LibraryPanel(QFrame):
    openRequested = Signal(str)
    musicRequested = Signal(str)
    logoRequested = Signal(str)
    extraLogoRequested = Signal(str)
    applyRequested = Signal(str, object)     # kind, fn(project)

    CATS = [("media", "🎞", "Media"), ("titles", "T", "Titles"),
            ("stickers", "★", "Stickers"), ("filters", "◐", "Filters")]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("LibPanel")
        self.setMinimumWidth(330)
        self.project = None
        self._at = 0.0
        apply = self.applyRequested.emit
        self.media = MediaPage()
        self.media.openRequested.connect(self.openRequested.emit)
        self.media.musicRequested.connect(self.musicRequested.emit)
        self.titles = TitlesPage(apply)
        self.stickers = StickersPage(apply)
        self.stickers.logoRequested.connect(self.logoRequested.emit)
        self.stickers.extraLogoRequested.connect(self.extraLogoRequested.emit)
        self.filters = FiltersPage(apply)
        self.pages = QStackedWidget()
        for w in (self.media, self.titles, self.stickers, self.filters):
            self.pages.addWidget(w)
        top = QFrame()
        top.setObjectName("LibTop")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(6, 6, 6, 4)
        tl.setSpacing(2)
        self.group = QButtonGroup(self)
        self.cat_buttons: Dict[str, QToolButton] = {}
        for i, (key, ic, name) in enumerate(self.CATS):
            b = QToolButton()
            b.setObjectName("LibCat")
            b.setText(f"{ic}\n{name}")
            b.setCheckable(True)
            b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
            b.setMinimumSize(68, 52)
            self.group.addButton(b, i)
            self.cat_buttons[key] = b
            tl.addWidget(b)
        tl.addStretch(1)
        self.group.idClicked.connect(self.show_page)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(top)
        lay.addWidget(self.pages, 1)
        self.show_page(0)

    def show_page(self, i: int):
        self.pages.setCurrentIndex(i)
        self.group.button(i).setChecked(True)
        if self.project is not None:
            self._load_page(i)

    def _load_page(self, i: int):
        p = self.project
        if i == 0:
            self.media.refresh(p.video_path if p.has_video() else "")
        elif i == 1:
            self.titles.load(p)
        elif i == 2:
            self.stickers.refresh(p.logo_path)
        else:
            self.filters.load(p, self._at)

    def load(self, project: Project, at: float = 0.0):
        self.project = project
        self._at = at
        self._load_page(self.pages.currentIndex())
