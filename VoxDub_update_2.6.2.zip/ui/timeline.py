"""
timeline.py - Multi-track timeline editor (Movavi Video Editor style).

Layout
  ┌ toolbar: undo redo delete | split snap properties text │ 00:20:06.000 │ ⏮ ▶ ⏭ │ fit ┐
  ├ header ┬ ruler 00:00:00 ─ 00:05:00 ─ 00:10:00 ...                                    ┤
  │ T  👁  │ Subtitles track                                                           │
  │ 🎞 👁🔊│ Video clip: film strip + name, original-audio waveform attached below     │
  │ 🎙 🔊  │ AI Voice track (waveforms)                                                │
  └ Scale: [▫──●──▭]                 Project settings / Project length      [ Export ] ┘

Mouse
  * click ruler / empty area ...... move playhead (and seek video)
  * click clip .................... select
  * drag AI voice / subtitle clip . move it in time (snaps to playhead & clip edges)
  * drag clip edge ................ trim (video clips ripple-trim)
  * Ctrl + mouse wheel ............ zoom around the mouse
  * mouse wheel ................... scroll left / right
  * right click clip .............. context menu
Keys (timeline focused)
  S split at playhead · Delete remove clip · Space play/pause
  Left / Right move playhead 0.1 s (Shift = 1 s) · Home / End
"""

import copy
import dataclasses
import math
import os
from typing import Dict, List, Optional, Tuple

import numpy as np
from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import (
    QColor, QFont, QFontMetrics, QImage, QPainter, QPainterPath, QPen, QPixmap, QPolygonF,
)
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QInputDialog, QLabel, QMenu, QScrollArea, QSlider, QToolButton, QToolTip,
    QVBoxLayout, QWidget,
)

from core import branding
from core.media import format_time
from core.project import AudioClip, Project, SubtitleClip, new_id
from ui.icons import icon, icon_size, pixmap
from ui.theme import legacy as _t
from ui.waveform import WaveformCache, draw_waveform

# --------------------------------------------------------------------------- #
# Look (Movavi-like dark slate)
# --------------------------------------------------------------------------- #
C = {
    "bg": QColor(_t("#262a35")),            # track area
    "lane": QColor(_t("#2a2e3a")),
    "lane_line": QColor(_t("#1d2029")),
    "ruler": QColor(_t("#2b2f3b")),
    "ruler_text": QColor(_t("#b9bdc9")),
    "tick": QColor(_t("#6b7080")),
    "tick_minor": QColor(_t("#454a58")),
    "header": QColor(_t("#232731")),
    "header_icon": _t("#9aa0b0"),
    "header_on": _t("#e8eaf0"),
    "header_off": _t("#5b6070"),
    "video": QColor(_t("#5d6182")),
    "video_audio": QColor(_t("#4c5070")),
    "video_wave": QColor(_t("#a9addb")),
    "video_line": QColor(_t("#3a3d55")),
    "voice": QColor(_t("#3f6b5f")),
    "voice_wave": QColor(_t("#93d6bf")),
    "music": QColor(_t("#2f5d7a")),
    "music_wave": QColor(_t("#8cc8f0")),
    "subs": QColor(_t("#6a5a94")),
    "text": QColor(_t("#f2f3f7")),
    "selected": QColor(_t("#f2b33d")),
    "playhead": QColor(_t("#e8553e")),
}

RULER_H = 26
TRACK_GAP = 2
LEFT_PAD = 8
EDGE_PX = 7
MIN_LEN = 0.1
HEADER_W = 76
VIDEO_PART = 60          # top of the video clip: film strip + name
AUDIO_PART = 42          # bottom of the video clip: original audio waveform

TRACKS = [
    # key, label, height
    ("subs", "Subtitles", 34),
    ("video", "Video", VIDEO_PART + AUDIO_PART),
    ("audio", "AI Voice", 56),
    ("music", "Music", 46),
]
TRACK_ICON = {"subs": "subtitle", "video": "film", "audio": "mic", "music": "music"}
TRACK_COLOR = {"subs": "subs", "video": "video", "audio": "voice", "music": "music"}   # 2.0 header stripe
SOUND_KINDS = ("audio", "music")        # clips with a sound file (move / trim alike)
# toggles shown in each track header: (what, icon on, icon off, tooltip)
TOGGLES = {
    "subs": [("visible", "eye", "eye_off", "Show subtitles in the preview")],
    "video": [("visible", "eye", "eye_off", "Show the video picture in the preview"),
              ("sound", "volume", "volume_off", "Original audio in the preview")],
    "audio": [("sound", "volume", "volume_off", "AI voice in the preview")],
    "music": [("sound", "volume", "volume_off", "Music in the preview")],
}


def track_rects() -> dict:
    """y-position and height of every track inside the canvas."""
    y = RULER_H + TRACK_GAP
    out = {}
    for key, _label, h in TRACKS:
        out[key] = (y, h)
        y += h + TRACK_GAP
    return out


TRACK_Y = track_rects()
CANVAS_H = RULER_H + sum(t[2] + TRACK_GAP for t in TRACKS) + TRACK_GAP


def hms(t: float) -> str:
    """Ruler label: always hh:mm:ss like Movavi (00:05:00)."""
    t = int(round(max(0.0, t)))
    return f"{t // 3600:02d}:{t % 3600 // 60:02d}:{t % 60:02d}"


# --------------------------------------------------------------------------- #
# Film strip thumbnails
# --------------------------------------------------------------------------- #
class Thumbnails:
    """Keyframe thumbnails of the source video (filled in the background)."""

    def __init__(self):
        self.video = ""
        self.times = np.zeros(0, np.float32)
        self.frames = None
        self._pix: Dict[int, QPixmap] = {}

    def set(self, video: str, times, frames):
        self.video, self.times, self.frames = video, times, frames
        self._pix.clear()

    def clear(self):
        self.set("", np.zeros(0, np.float32), None)

    def ready(self) -> bool:
        return self.frames is not None and len(self.times) > 0

    def size(self) -> Tuple[int, int]:
        if not self.ready():
            return 0, 0
        return self.frames.shape[2], self.frames.shape[1]

    def at(self, src_t: float) -> Optional[QPixmap]:
        """Thumbnail for source time src_t (nearest earlier keyframe)."""
        if not self.ready():
            return None
        i = int(np.searchsorted(self.times, src_t + 0.01, side="right")) - 1
        i = max(0, min(i, len(self.times) - 1))
        pm = self._pix.get(i)
        if pm is None:
            f = np.ascontiguousarray(self.frames[i])
            h, w, _ = f.shape
            img = QImage(f.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy()
            pm = QPixmap.fromImage(img)
            if len(self._pix) > 600:
                self._pix.clear()
            self._pix[i] = pm
        return pm


# --------------------------------------------------------------------------- #
# Track header column
# --------------------------------------------------------------------------- #
class TrackHeader(QWidget):
    """Left column: track icon + eye / speaker toggles (like Movavi)."""

    toggled = Signal(str, str, bool)        # track key, "visible"/"sound", on

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(HEADER_W)
        self.setMinimumHeight(CANVAS_H)
        self.setMouseTracking(True)
        self.state = {(k, what): True for k, ts in TOGGLES.items() for what, *_ in ts}

    def set_state(self, key: str, what: str, on: bool):
        """Change a toggle from outside (no signal)."""
        if (key, what) in self.state and self.state[(key, what)] != on:
            self.state[(key, what)] = on
            self.update()

    def _toggle_rects(self):
        """[(key, what, rect, icon_on, icon_off, tip)]"""
        out = []
        for key, _label, h in TRACKS:
            y, h = TRACK_Y[key]
            items = TOGGLES.get(key, [])
            for k, (what, on, off, tip) in enumerate(items):
                if h < 50:          # short track: icon left, toggles to its right
                    out.append((key, what, QRectF(40 + k * 28, y + (h - 20) / 2, 22, 20),
                                on, off, tip))
                else:               # tall track: icon on top, toggles below (Movavi)
                    out.append((key, what, QRectF(10 + k * 30, y + h - 26, 22, 20),
                                on, off, tip))
        return out

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), C["header"])
        p.fillRect(QRectF(0, 0, HEADER_W, RULER_H), C["ruler"])
        for key, label, h in TRACKS:
            y, h = TRACK_Y[key]
            p.fillRect(QRectF(0, y, HEADER_W, h), C["header"])
            p.setPen(C["lane_line"])
            p.drawLine(QPointF(0, y + h + 0.5), QPointF(HEADER_W, y + h + 0.5))
            # 2.0: a stripe in the track's clip colour says which track this is;
            # dimmed when the track is hidden / muted in the preview
            off = any(not on for (k, _w), on in self.state.items() if k == key)
            stripe = QColor(C[TRACK_COLOR[key]])
            if off:
                stripe.setAlpha(70)
            p.fillRect(QRectF(0, y + 2, 3, h - 4), stripe)
            # track icon, like Movavi's film / overlay icons
            pos = QPointF(10, y + (h - 20) / 2) if h < 50 else QPointF(26, y + 8)
            p.drawPixmap(pos, pixmap(TRACK_ICON[key], 20,
                                     C["header_off"] if off else C["header_icon"]))
        for key, what, r, on, off, _tip in self._toggle_rects():
            state = self.state[(key, what)]
            p.drawPixmap(QPointF(r.left() + 2, r.top() + 1),
                         pixmap(on if state else off, 17,
                                C["header_on"] if state else C["header_off"]))
        p.setPen(C["lane_line"])
        p.drawLine(QPointF(HEADER_W - 0.5, 0), QPointF(HEADER_W - 0.5, self.height()))
        p.end()

    def _hit(self, pos):
        for key, what, r, _on, _off, tip in self._toggle_rects():
            if r.adjusted(-3, -3, 3, 3).contains(pos):
                return key, what, tip
        return None

    def mousePressEvent(self, event):
        hit = self._hit(event.position())
        if hit and event.button() == Qt.MouseButton.LeftButton:
            key, what, _tip = hit
            self.state[(key, what)] = not self.state[(key, what)]
            self.update()
            self.toggled.emit(key, what, self.state[(key, what)])

    def mouseMoveEvent(self, event):
        self.setCursor(Qt.CursorShape.PointingHandCursor if self._hit(event.position())
                       else Qt.CursorShape.ArrowCursor)

    def event(self, e):
        if e.type() == QEvent.Type.ToolTip:
            hit = self._hit(QPointF(e.pos()))
            if hit:
                QToolTip.showText(e.globalPos(), hit[2] + " (click to turn on / off)", self)
            else:
                label = next((lbl for k, lbl, _h in TRACKS
                              if TRACK_Y[k][0] <= e.pos().y() <= sum(TRACK_Y[k])), "")
                if label:
                    QToolTip.showText(e.globalPos(), label, self)
                else:
                    QToolTip.hideText()
            return True
        return super().event(e)


# --------------------------------------------------------------------------- #
# The tracks
# --------------------------------------------------------------------------- #
class TimelineCanvas(QWidget):
    seekRequested = Signal(float)
    aboutToEdit = Signal()          # emitted BEFORE a change (for undo)
    edited = Signal(str)            # after a change: 'video' / 'audio' / 'subs'
    selectionChanged = Signal(str, str)
    playToggleRequested = Signal()
    splitRequested = Signal()
    deleteRequested = Signal()
    filesDropped = Signal(list, float)      # files dragged from Media / Explorer, at time

    def __init__(self, waveforms: WaveformCache, parent=None):
        super().__init__(parent)
        self.project: Optional[Project] = None
        self.waveforms = waveforms
        self.thumbs = Thumbnails()
        self.pps = 40.0                 # pixels per second (zoom)
        self.playhead = 0.0
        self.selected: Optional[Tuple[str, str]] = None
        self.snap = True
        self.dimmed = set()             # tracks/lanes switched off in the header
        self._drag = None               # dict describing the current drag
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMinimumHeight(CANVAS_H)
        self.setAcceptDrops(True)
        self._drop_t = None             # where a dragged file would land (drawn)
        self._update_width()

    # ------------------------------------------------------------------ #
    # Drop files from the Media library (or Explorer)
    # ------------------------------------------------------------------ #
    @staticmethod
    def _drop_paths(ev) -> list:
        if not ev.mimeData().hasUrls():
            return []
        return [os.path.normpath(u.toLocalFile()) for u in ev.mimeData().urls() if u.isLocalFile()]

    def dragEnterEvent(self, ev):
        if self.project and self._drop_paths(ev):
            ev.acceptProposedAction()

    def dragMoveEvent(self, ev):
        if not self._drop_paths(ev):
            return
        self._drop_t = self.t_of(ev.position().x())
        s = self._snap(self._drop_t, "")
        self._drop_t = s if s is not None else self._drop_t
        self.update()
        ev.acceptProposedAction()

    def dragLeaveEvent(self, ev):
        self._drop_t = None
        self.update()

    def dropEvent(self, ev):
        paths = self._drop_paths(ev)
        t = self._drop_t if self._drop_t is not None else self.t_of(ev.position().x())
        self._drop_t = None
        self.update()
        if paths:
            ev.acceptProposedAction()
            self.filesDropped.emit(paths, max(0.0, t))

    # ------------------------------------------------------------------ #
    # Geometry helpers
    # ------------------------------------------------------------------ #
    def x_of(self, t: float) -> float:
        return LEFT_PAD + t * self.pps

    def t_of(self, x: float) -> float:
        return max(0.0, (x - LEFT_PAD) / self.pps)

    def _update_width(self):
        length = self.project.timeline_length() if self.project else 60.0
        w = int(self.x_of(length + 8))
        parent = self.parentWidget()
        if parent is not None:
            w = max(w, parent.width())
        self.setFixedWidth(max(w, 400))

    def set_project(self, project: Optional[Project]):
        self.project = project
        if self.selected and not self._find(*self.selected):
            self.selected = None
        self._update_width()
        self.update()

    def set_zoom(self, pps: float, anchor_x: Optional[float] = None):
        """Change zoom. anchor_x keeps the time under the mouse still."""
        pps = max(0.2, min(600.0, pps))
        scroll = self._scroll_area()
        if anchor_x is None:
            anchor_x = self.x_of(self.playhead)
        t_anchor = self.t_of(anchor_x)
        view_offset = anchor_x - (scroll.horizontalScrollBar().value() if scroll else 0)
        self.pps = pps
        self._update_width()
        if scroll:
            scroll.horizontalScrollBar().setValue(int(self.x_of(t_anchor) - view_offset))
        self.update()

    def _scroll_area(self) -> Optional[QScrollArea]:
        w = self.parentWidget()
        while w is not None and not isinstance(w, QScrollArea):
            w = w.parentWidget()
        return w

    # ------------------------------------------------------------------ #
    # Clip lookup
    # ------------------------------------------------------------------ #
    def _clips(self, kind: str) -> list:
        if not self.project:
            return []
        return {"video": self.project.video_clips,
                "audio": self.project.audio_clips,
                "music": self.project.music_clips,
                "subs": self.project.subtitle_clips}[kind]

    def _visible(self, kind: str, vis) -> list:
        """The clips that can be in view (a 2-hour film has thousands: the
        playhead repaints many times a second, so do not walk them all)."""
        import bisect

        clips = self._clips(kind)
        if len(clips) < 300:
            return clips
        starts = [c.start for c in clips]           # (a few ms; a drag moves clips)
        if not all(a <= b for a, b in zip(starts, starts[1:])):
            return clips
        ends = [c.end for c in clips]
        longest = max(e - s for s, e in zip(starts, ends))
        t0, t1 = self.t_of(vis.left() - 4), self.t_of(vis.right() + 4)
        i = bisect.bisect_left(starts, t0 - longest - 0.01)
        j = bisect.bisect_right(starts, t1)
        return clips[i:j]

    def _find(self, kind: str, cid: str):
        for c in self._clips(kind):
            if c.id == cid:
                return c
        return None

    def selected_clip(self):
        if not self.selected:
            return None, None
        kind, cid = self.selected
        return kind, self._find(kind, cid)

    @staticmethod
    def _clip_span(kind: str, c) -> Tuple[float, float]:
        return c.start, c.end

    def _hit(self, pos: QPointF):
        """Return (kind, clip, edge) under the mouse. edge = 'l', 'r' or ''."""
        for kind, (y, h) in TRACK_Y.items():
            if not (y <= pos.y() <= y + h):
                continue
            # last drawn = on top -> search reversed
            for c in reversed(self._clips(kind)):
                s, e = self._clip_span(kind, c)
                x0, x1 = self.x_of(s), self.x_of(e)
                if x0 - 2 <= pos.x() <= x1 + 2:
                    edge = ""
                    if x1 - x0 > 3 * EDGE_PX:
                        if pos.x() - x0 <= EDGE_PX:
                            edge = "l"
                        elif x1 - pos.x() <= EDGE_PX:
                            edge = "r"
                    return kind, c, edge
            return kind, None, ""
        return None, None, ""

    def edit_points(self) -> List[float]:
        """Clip starts / ends (for the ⏮ ⏭ buttons)."""
        pts = {0.0}
        if self.project:
            pts.add(self.project.sequence_duration())
            for kind in ("video", "audio", "music", "subs"):
                for c in self._clips(kind):
                    pts.update((round(c.start, 3), round(c.end, 3)))
        return sorted(pts)

    # ------------------------------------------------------------------ #
    # Painting
    # ------------------------------------------------------------------ #
    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        vis = event.rect()
        p.fillRect(vis, C["bg"])
        self._paint_ruler(p, vis)

        for key, _label, _h in TRACKS:
            y, h = TRACK_Y[key]
            p.fillRect(QRectF(vis.left(), y, vis.width(), h), C["lane"])
            p.setPen(C["lane_line"])
            p.drawLine(QPointF(vis.left(), y + h + 0.5), QPointF(vis.right(), y + h + 0.5))
            for clip in self._visible(key, vis):
                self._paint_clip(p, key, clip, y, h, vis)

        if self._drop_t is not None:        # where a dragged file will land
            xd = self.x_of(self._drop_t)
            y, h = TRACK_Y["music"]
            p.setPen(QPen(C["selected"], 2, Qt.PenStyle.DashLine))
            p.drawLine(QPointF(xd, RULER_H), QPointF(xd, self.height()))
            p.fillRect(QRectF(xd, y + 2, 120, h - 4), QColor(242, 179, 61, 60))
        # playhead: thin orange-red line + handle in the ruler
        x = self.x_of(self.playhead)
        p.setPen(QPen(C["playhead"], 1.5))
        p.drawLine(QPointF(x, 2), QPointF(x, self.height()))
        p.setBrush(C["playhead"])
        p.setPen(Qt.PenStyle.NoPen)
        p.drawPolygon(QPolygonF([QPointF(x - 6, 2), QPointF(x + 6, 2), QPointF(x + 6, 11),
                                 QPointF(x, 17), QPointF(x - 6, 11)]))
        p.end()

    def _tick_step(self) -> float:
        for step in (0.5, 1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800):
            if step * self.pps >= 90:
                return step
        return 3600

    def _paint_ruler(self, p: QPainter, vis):
        p.fillRect(QRectF(vis.left(), 0, vis.width(), RULER_H), C["ruler"])
        step = self._tick_step()
        minor = step / 10 if step >= 10 else step / 5
        # Video > Speed: the ruler counts the time of the EXPORTED video
        sp = self.project.speed() if self.project else 1.0
        t0 = math.floor(self.t_of(vis.left()) / sp / minor) * minor
        t1 = self.t_of(vis.right()) / sp + minor
        p.setFont(QFont("Segoe UI", 8))
        n = 0
        t = t0
        while t <= t1 and n < 6000:
            x = self.x_of(t * sp)
            is_major = abs((t / step) - round(t / step)) < 1e-6
            if is_major:
                p.setPen(C["tick"])
                p.drawLine(QPointF(x, RULER_H - 10), QPointF(x, RULER_H))
                p.setPen(C["ruler_text"])
                label = hms(t) if step >= 1 else f"{hms(t)}.{int(round(t * 10)) % 10}"
                p.drawText(QPointF(x + 1, 12), label)
            else:
                p.setPen(C["tick_minor"])
                p.drawLine(QPointF(x, RULER_H - 4), QPointF(x, RULER_H))
            t = round(t + minor, 6)
            n += 1
        p.setPen(C["lane_line"])
        p.drawLine(QPointF(vis.left(), RULER_H - 0.5), QPointF(vis.right(), RULER_H - 0.5))

    @staticmethod
    def _fmt(t: float, step: float) -> str:
        return hms(t)

    def _paint_clip(self, p, kind, clip, y, h, vis):
        x0, x1 = self.x_of(clip.start), self.x_of(clip.end)
        if x1 < vis.left() - 2 or x0 > vis.right() + 2:
            return
        r = QRectF(x0 + 0.5, y + 1.5, max(2.0, x1 - x0 - 1), h - 3)
        sel = self.selected == (kind, clip.id)
        out_of_video = (kind != "video" and self.project
                        and clip.start >= self.project.sequence_duration())
        if kind == "video":
            self._paint_video_clip(p, clip, r, vis)
        else:
            body = {"audio": C["voice"], "music": C["music"]}.get(kind, C["subs"])
            hidden = kind == "subs" and (getattr(clip, "hidden", False)
                                         or getattr(self.project, "subs_hidden", False))
            if out_of_video or kind in self.dimmed:
                body = body.darker(150)
            if hidden:
                body = body.darker(220)
            p.setPen(QPen(body.lighter(135), 1))
            p.setBrush(body)
            p.drawRoundedRect(r, 3, 3)
            if kind in SOUND_KINDS and r.width() > 4:
                peaks = self.waveforms.peaks(clip.path)
                wave = C["voice_wave"] if kind == "audio" else C["music_wave"]
                draw_waveform(p, r.adjusted(2, 15, -2, -2), peaks, clip.src_in, clip.src_out,
                              wave.darker(140) if kind in self.dimmed else wave,
                              vis.left(), vis.right())
            if r.width() > 22:
                font = QFont("Segoe UI", 8)
                p.setFont(font)
                p.setPen(C["text"])
                fm = QFontMetrics(font)
                if kind in SOUND_KINDS:
                    text = clip.label or ("AI voice" if kind == "audio" else "Music")
                    if abs(clip.volume - 1.0) > 0.01:
                        text = f"[{int(clip.volume * 100)}%] " + text
                    lr = QRectF(r.left() + 5, r.top() + 1, r.width() - 8, 14)
                    p.drawText(lr, Qt.AlignmentFlag.AlignVCenter,
                               fm.elidedText(text, Qt.TextElideMode.ElideRight, int(lr.width())))
                else:
                    text = ("🙈 " if hidden else "") + clip.text.replace("\n", " ")
                    lr = r.adjusted(6, 0, -4, 0)
                    p.drawText(lr, Qt.AlignmentFlag.AlignVCenter,
                               fm.elidedText(text, Qt.TextElideMode.ElideRight, int(lr.width())))

        if sel:
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(C["selected"], 2))
            p.drawRoundedRect(r.adjusted(0.5, 0.5, -0.5, -0.5), 3, 3)
            if r.width() > 3 * EDGE_PX:     # trim handles
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(C["selected"])
                p.drawRect(QRectF(r.left(), r.top(), 4, r.height()))
                p.drawRect(QRectF(r.right() - 4, r.top(), 4, r.height()))

    def _paint_video_clip(self, p: QPainter, clip, r: QRectF, vis):
        """Movavi-style video clip: film strip + name on top, the original audio
        waveform attached underneath in the same clip."""
        top = QRectF(r.left(), r.top(), r.width(), VIDEO_PART - 1)
        bottom = QRectF(r.left(), r.top() + VIDEO_PART, r.width(), r.height() - VIDEO_PART)
        hidden = "video" in self.dimmed
        muted = "video_sound" in self.dimmed

        path = QPainterPath()
        path.addRoundedRect(r, 3, 3)
        p.save()
        p.setClipPath(path)
        p.fillRect(top, C["video"].darker(140) if hidden else C["video"])
        p.fillRect(bottom, C["video_audio"].darker(140) if muted else C["video_audio"])
        p.setPen(C["video_line"])
        p.drawLine(QPointF(r.left(), bottom.top() - 0.5), QPointF(r.right(), bottom.top() - 0.5))

        # --- film strip: first frame at the clip start, then one every ~220 px
        tw, th = self.thumbs.size()
        name_x = top.left() + 6
        if tw:
            ph = top.height() - 6
            pw = tw * ph / th
            frame_r = QRectF(top.left() + 3, top.top() + 3, pw, ph)
            xs = [frame_r.left()]
            spacing = max(220.0, pw + 140)
            x = frame_r.left() + spacing
            while x < top.right() - pw:
                xs.append(x)
                x += spacing
            name_x = frame_r.right() + 8
            for fx in xs:
                if fx + pw < vis.left() or fx > vis.right():
                    continue
                src = clip.src_in + (fx - r.left()) / self.pps * getattr(clip, "rate", 1.0)
                pm = self.thumbs.at(min(src, clip.src_out))
                if pm is not None:
                    dst = QRectF(fx, frame_r.top(), pw, ph)
                    if dst.right() > top.right() - 2:
                        continue
                    p.drawPixmap(dst, pm, QRectF(pm.rect()))
                    if hidden:
                        p.fillRect(dst, QColor(20, 22, 30, 150))

        # --- name (file name, like "[CH-204] 01.mp4")
        name = os.path.basename(self.project.video_path) if self.project else "Video"
        font = QFont("Segoe UI", 9)
        p.setFont(font)
        fm = QFontMetrics(font)
        room = top.right() - name_x - 6
        if room > 24:
            p.setPen(C["text"])
            label = name if len(self.project.video_clips) == 1 else \
                f"{name}  ({format_time(clip.src_in, False)} – {format_time(clip.src_out, False)})"
            p.drawText(QRectF(name_x, top.top(), room, top.height()),
                       Qt.AlignmentFlag.AlignVCenter,
                       fm.elidedText(label, Qt.TextElideMode.ElideRight, int(room)))

        # --- attached original audio
        if self.project and self.project.original_audio:
            peaks = self.waveforms.peaks(self.project.original_audio)
            wave = C["video_wave"].darker(170) if muted else C["video_wave"]
            draw_waveform(p, bottom.adjusted(1, 3, -1, -1), peaks, clip.src_in, clip.src_out,
                          wave, vis.left(), vis.right())
        small = QFont("Segoe UI", 8)
        p.setFont(small)
        p.setPen(QColor(235, 237, 245, 210))
        if bottom.width() > 40:
            p.drawText(QRectF(bottom.left() + 8, bottom.top() + 1, bottom.width() - 12, 14),
                       Qt.AlignmentFlag.AlignVCenter,
                       QFontMetrics(small).elidedText(name, Qt.TextElideMode.ElideRight,
                                                      int(bottom.width() - 12)))
        p.restore()
        # outline
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(QColor(_t("#7d81a6")), 1))
        p.drawRoundedRect(r, 3, 3)

    # ------------------------------------------------------------------ #
    # Mouse
    # ------------------------------------------------------------------ #
    def _snap_points(self, exclude_id: str) -> List[float]:
        pts = [0.0, self.playhead]
        if self.project:
            pts.append(self.project.sequence_duration())
            for kind in ("video", "audio", "music", "subs"):
                for c in self._clips(kind):
                    if c.id != exclude_id:
                        pts += [c.start, c.end]
        return pts

    def _snap(self, t: float, exclude_id: str) -> Optional[float]:
        if not self.snap:
            return None
        tol = 8.0 / self.pps
        best, best_d = None, tol
        for s in self._snap_points(exclude_id):
            d = abs(s - t)
            if d < best_d:
                best, best_d = s, d
        return best

    def mousePressEvent(self, event):
        self.setFocus()
        pos = event.position()
        if not self.project:
            return
        if event.button() == Qt.MouseButton.RightButton:
            kind, clip, _ = self._hit(pos)
            if clip is not None:
                self._select(kind, clip.id)
                self._context_menu(kind, clip, event.globalPosition().toPoint())
            return
        if event.button() != Qt.MouseButton.LeftButton:
            return

        if pos.y() <= RULER_H:
            self._drag = {"mode": "playhead"}
            self._move_playhead(self.t_of(pos.x()))
            return

        kind, clip, edge = self._hit(pos)
        if clip is None:
            self._select(None, None)
            self._drag = {"mode": "playhead"}
            self._move_playhead(self.t_of(pos.x()))
            return

        self._select(kind, clip.id)
        mode = {"l": "trim_l", "r": "trim_r"}.get(edge, "move")
        if kind == "video" and mode == "move":
            # video clips are rippled - clicking the body just moves the playhead
            self._drag = {"mode": "playhead"}
            self._move_playhead(self.t_of(pos.x()))
            return
        self._drag = {"mode": mode, "kind": kind, "clip": clip,
                      "orig": copy.copy(clip), "x": pos.x(), "started": False}

    def mouseMoveEvent(self, event):
        pos = event.position()
        if self._drag is None:
            kind, clip, edge = self._hit(pos)
            if clip is not None and edge:
                self.setCursor(Qt.CursorShape.SizeHorCursor)
            elif clip is not None and kind != "video":
                self.setCursor(Qt.CursorShape.OpenHandCursor)
            else:
                self.setCursor(Qt.CursorShape.ArrowCursor)
            return

        if self._drag["mode"] == "playhead":
            self._move_playhead(self.t_of(pos.x()))
            return

        d = self._drag
        dt = (pos.x() - d["x"]) / self.pps
        if not d["started"]:
            if abs(pos.x() - d["x"]) < 3:
                return
            self.aboutToEdit.emit()          # snapshot for undo before changing
            d["started"] = True
        self._apply_drag(d, dt)
        if self.project:
            self.project.layout_video()
        self._update_width()
        self.update()

    def _apply_drag(self, d, dt):
        kind, clip, o, mode = d["kind"], d["clip"], d["orig"], d["mode"]
        if kind == "video":
            vd = self.project.video_duration
            dt *= clip.rate                 # (a slowed piece: timeline s > video s)
            if mode == "trim_l":
                clip.src_in = min(max(0.0, o.src_in + dt), o.src_out - MIN_LEN)
            elif mode == "trim_r":
                clip.src_out = max(min(vd, o.src_out + dt), o.src_in + MIN_LEN)
        elif kind in SOUND_KINDS:
            if mode == "move":
                start = max(0.0, o.start + dt)
                s1 = self._snap(start, clip.id)
                s2 = self._snap(start + o.length, clip.id)
                if s1 is not None:
                    start = s1
                elif s2 is not None:
                    start = s2 - o.length
                clip.start = max(0.0, start)
            elif mode == "trim_l":
                src_in = min(max(0.0, o.src_in + dt), o.src_out - MIN_LEN)
                src_in = max(src_in, o.src_in - o.start)        # start can't go < 0
                clip.src_in = src_in
                clip.start = o.start + (src_in - o.src_in)
            elif mode == "trim_r":
                end_t = o.start + (o.src_out - o.src_in) + dt
                s = self._snap(end_t, clip.id)
                if s is not None:
                    dt = s - (o.start + o.src_out - o.src_in)
                clip.src_out = max(min(o.file_duration, o.src_out + dt), o.src_in + MIN_LEN)
        elif kind == "subs":
            if mode == "move":
                start = max(0.0, o.start + dt)
                s1 = self._snap(start, clip.id)
                s2 = self._snap(start + o.length, clip.id)
                if s1 is not None:
                    start = s1
                elif s2 is not None:
                    start = s2 - o.length
                start = max(0.0, start)
                clip.start, clip.end = start, start + o.length
            elif mode == "trim_l":
                t = max(0.0, o.start + dt)
                s = self._snap(t, clip.id)
                t = s if s is not None else t
                clip.start = min(t, o.end - MIN_LEN)
            elif mode == "trim_r":
                t = o.end + dt
                s = self._snap(t, clip.id)
                t = s if s is not None else t
                clip.end = max(t, o.start + MIN_LEN)

    def mouseReleaseEvent(self, event):
        d = self._drag
        self._drag = None
        if d and d.get("started"):
            c = d["clip"]
            for attr in ("start", "src_in", "src_out", "end"):
                if hasattr(c, attr) and not isinstance(getattr(type(c), attr, None), property):
                    setattr(c, attr, round(getattr(c, attr), 3))
            if d["kind"] in SOUND_KINDS:
                self._clips(d["kind"]).sort(key=lambda x: x.start)
            elif d["kind"] == "subs":
                self.project.subtitle_clips.sort(key=lambda x: x.start)
            self.edited.emit(d["kind"])

    def mouseDoubleClickEvent(self, event):
        kind, clip, _ = self._hit(event.position())
        if kind == "subs" and clip is not None:
            self._edit_sub_text(clip)

    def wheelEvent(self, event):
        delta = event.angleDelta().y() or event.angleDelta().x()
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            factor = 1.25 if delta > 0 else 0.8
            self.set_zoom(self.pps * factor, event.position().x())
            self.parent_editor_sync_zoom()
        else:
            scroll = self._scroll_area()
            if scroll:
                bar = scroll.horizontalScrollBar()
                bar.setValue(bar.value() - delta)
        event.accept()

    def parent_editor_sync_zoom(self):
        w = self.parentWidget()
        while w is not None and not isinstance(w, TimelineEditor):
            w = w.parentWidget()
        if w is not None:
            w.sync_zoom_slider()

    def keyPressEvent(self, event):
        key = event.key()
        if key == Qt.Key.Key_Space:
            self.playToggleRequested.emit()
        elif key == Qt.Key.Key_S:
            self.splitRequested.emit()
        elif key in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.deleteRequested.emit()
        elif key in (Qt.Key.Key_Left, Qt.Key.Key_Right):
            step = 1.0 if event.modifiers() & Qt.KeyboardModifier.ShiftModifier else 0.1
            sign = -1 if key == Qt.Key.Key_Left else 1
            self._move_playhead(self.playhead + sign * step)
        elif key == Qt.Key.Key_Home:
            self._move_playhead(0.0)
        elif key == Qt.Key.Key_End and self.project:
            self._move_playhead(self.project.sequence_duration())
        else:
            super().keyPressEvent(event)

    # ------------------------------------------------------------------ #
    # Actions
    # ------------------------------------------------------------------ #
    def _move_playhead(self, t: float):
        if self.project:
            t = min(t, self.project.sequence_duration())
        self.playhead = max(0.0, t)
        self.update()
        self.seekRequested.emit(self.playhead)

    def _select(self, kind, cid):
        self.selected = (kind, cid) if kind and cid else None
        self.update()
        self.selectionChanged.emit(kind or "", cid or "")

    def select(self, kind: str, cid: str):
        """Select a clip from outside (e.g. a subtitle table row)."""
        if kind and cid and self._find(kind, cid):
            self.selected = (kind, cid)
        else:
            self.selected = None
        self.update()

    def _context_menu(self, kind, clip, global_pos):
        menu = QMenu(self)
        a_split = menu.addAction(icon("scissors", 16), "Split at playhead  (S)")
        a_del = menu.addAction(icon("trash", 16), "Delete  (Del)")
        if kind == "video" and self.project and len(self.project.video_clips) <= 1:
            a_del.setText("Delete the whole video…  (Del)")
        a_text = a_vol = None
        if kind == "subs":
            a_text = menu.addAction(icon("pencil", 16), "Edit text…")
        if kind in SOUND_KINDS:
            a_vol = menu.addAction(icon("volume", 16), "Clip volume…")
        a_seek = menu.addAction(icon("prev", 16), "Move playhead to clip start")
        chosen = menu.exec(global_pos)
        if chosen is None:
            return
        if chosen == a_split:
            self.splitRequested.emit()
        elif chosen == a_del:
            self.deleteRequested.emit()
        elif chosen == a_text:
            self._edit_sub_text(clip)
        elif chosen == a_vol:
            self._edit_volume(clip)
        elif chosen == a_seek:
            self._move_playhead(clip.start)

    def edit_selected_properties(self) -> bool:
        """Toolbar 'clip properties': volume for AI voice, text for subtitles."""
        kind, clip = self.selected_clip()
        if clip is None:
            return False
        if kind in SOUND_KINDS:
            self._edit_volume(clip)
        elif kind == "subs":
            self._edit_sub_text(clip)
        else:
            return False
        return True

    def _edit_volume(self, clip: AudioClip):
        val, ok = QInputDialog.getInt(self, "Clip volume", "Volume %:",
                                      int(clip.volume * 100), 0, 300, 5)
        if ok:
            self.aboutToEdit.emit()
            clip.volume = val / 100.0
            self.edited.emit("audio")
            self.update()

    def _edit_sub_text(self, clip: SubtitleClip):
        text, ok = QInputDialog.getMultiLineText(self, "Subtitle text", "Text:", clip.text)
        if ok:
            self.aboutToEdit.emit()
            clip.text = text.strip()
            self.edited.emit("subs")
            self.update()

    def follow_playhead(self):
        """Keep the playhead visible while playing."""
        scroll = self._scroll_area()
        if not scroll:
            return
        bar = scroll.horizontalScrollBar()
        x = self.x_of(self.playhead)
        left, width = bar.value(), scroll.viewport().width()
        if x < left or x > left + width - 40:
            bar.setValue(int(x - width * 0.1))


# --------------------------------------------------------------------------- #
# Timecode display (00:20:06.000 - leading zeros dim, like Movavi)
# --------------------------------------------------------------------------- #
class TimecodeDisplay(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.t = 0.0
        self.font = QFont("Consolas", 17)
        self.font.setStyleHint(QFont.StyleHint.Monospace)
        self.setMinimumWidth(QFontMetrics(self.font).horizontalAdvance("00:00:00.000") + 24)
        self.setFixedHeight(34)
        self.setToolTip("Playhead position")

    def set_time(self, t: float):
        if abs(t - self.t) >= 0.0005:
            self.t = t
            self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        text = format_time(self.t)             # 00:20:06.000
        # digits before the first significant one are drawn dim
        k = 0
        while k < len(text) and text[k] in "0:":
            k += 1
        k = min(k, len(text) - 5)              # always light up "0.000"
        p.setFont(self.font)
        fm = QFontMetrics(self.font)
        x = (self.width() - fm.horizontalAdvance(text)) / 2
        y = (self.height() + fm.ascent() - fm.descent()) / 2
        p.setPen(QColor(_t("#5d6270")))
        p.drawText(QPointF(x, y), text[:k])
        p.setPen(C["playhead"])
        p.drawText(QPointF(x + fm.horizontalAdvance(text[:k]), y), text[k:])
        p.end()


# --------------------------------------------------------------------------- #
# The whole editor
# --------------------------------------------------------------------------- #
class TimelineEditor(QWidget):
    """Toolbar + track header + scrollable canvas + bottom bar (Movavi layout)."""

    exportRequested = Signal()
    quickRequested = Signal(str)                # flip_h / flip_v / logo / blur
    ratioChosen = Signal(str)                   # Original / 9:16 / 16:9 ... (at once)
    bgmRequested = Signal()                     # Load BGM (music under the voice)
    isolateRequested = Signal()                 # Isolate BGM (take the voices out)
    importSrtRequested = Signal()
    exportSrtRequested = Signal()
    toolRequested = Signal(str)                 # "crop" / "color" / "audio"
    trackToggled = Signal(str, str, bool)       # key, "visible"/"sound", on
    addSubtitleRequested = Signal()
    projectSettingsRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("TimelineEditor")
        self.waveforms = WaveformCache()
        self.canvas = TimelineCanvas(self.waveforms)
        self.project: Optional[Project] = None
        self._thumb_worker = None
        self._thumb_video = ""

        # ---------------- toolbar ----------------
        def tool(name, tip, slot=None, checkable=False):
            b = QToolButton()
            b.setIcon(icon(name, 20, checked=_t("#2fd59a") if checkable else ""))
            b.setIconSize(icon_size(20))
            b.setToolTip(tip)
            b.setObjectName("MvTool")
            b.setCheckable(checkable)
            b.setAutoRaise(True)
            if slot is not None:
                b.clicked.connect(slot)
            return b

        self.btn_undo = tool("undo", "Undo (Ctrl+Z)")
        self.btn_redo = tool("redo", "Redo (Ctrl+Y)")
        self.btn_delete = tool("trash", "Delete selected clip (Del)",
                               self.canvas.deleteRequested.emit)
        self.btn_split = tool("scissors", "Split at playhead (S)",
                              self.canvas.splitRequested.emit)
        self.btn_snap = tool("magnet", "Snap to playhead and clip edges", checkable=True)
        self.btn_snap.setChecked(True)
        self.btn_snap.toggled.connect(lambda v: setattr(self.canvas, "snap", v))
        self.btn_crop = tool("crop", "Crop and Rotate\nCut off the edges of the picture, "
                                     "straighten it", lambda: self.toolRequested.emit("crop"))
        self.btn_color = tool("color", "Color Adjustments\nEnhance and adjust the colors "
                                       "of the video", lambda: self.toolRequested.emit("color"))
        self.btn_props = tool("sliders", "Audio Properties\nManage the volume and edit the "
                                         "selected audio", lambda: self.toolRequested.emit("audio"))
        # quick picture tools (like other dubbing apps: one click each)
        self.btn_text = tool("text", "Add text at the playhead",
                             self.addSubtitleRequested.emit)
        self.btn_flip_h = tool("flip_h", "Flip left ↔ right (mirror)",
                               lambda: self.quickRequested.emit("flip_h"))
        self.btn_flip_v = tool("flip_v", "Flip upside down",
                               lambda: self.quickRequested.emit("flip_v"))
        self.btn_logo = tool("image", "Logo: put your logo on the video",
                             lambda: self.quickRequested.emit("logo"))
        self.btn_blur = tool("blur", "Blur the original subtitles (found automatically)",
                             lambda: self.quickRequested.emit("blur"))
        self.btn_ratio = tool("ratio", "Video size and ratio (16:9, 9:16, 1:1 ...)")
        self.ratio_menu = QMenu(self.btn_ratio)
        self.ratio_menu.setObjectName("RatioMenu")
        self.ratio_menu.aboutToShow.connect(self._fill_ratio_menu)
        self.btn_ratio.setMenu(self.ratio_menu)
        self.btn_ratio.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self.btn_ratio.setStyleSheet("QToolButton::menu-indicator { image: none; width: 0; }")

        self.timecode = TimecodeDisplay()
        self.btn_prev = tool("prev", "Previous edit point (Home = start)", self._prev_point)
        self.btn_play = tool("play", "Play / Pause (Space)", self.canvas.playToggleRequested.emit)
        self.btn_next = tool("next", "Next edit point", self._next_point)
        self.btn_fit = tool("fit", "Fit the whole project in view (Ctrl+0)", self.zoom_fit)

        bar = QHBoxLayout()
        bar.setContentsMargins(6, 3, 6, 3)
        bar.setSpacing(2)
        for w in (self.btn_undo, self.btn_redo, self.btn_delete):
            bar.addWidget(w)
        bar.addSpacing(10)
        for w in (self.btn_split, self.btn_crop, self.btn_color,
                  self.btn_snap, self.btn_props):
            bar.addWidget(w)
        bar.addSpacing(10)
        for w in (self.btn_text, self.btn_flip_h, self.btn_flip_v, self.btn_logo,
                  self.btn_blur, self.btn_ratio):
            bar.addWidget(w)
        bar.addStretch(2)
        bar.addWidget(self.timecode)
        bar.addSpacing(10)
        for w in (self.btn_prev, self.btn_play, self.btn_next):
            bar.addWidget(w)
        bar.addStretch(3)
        bar.addWidget(self.btn_fit)
        toolbar = QWidget()
        toolbar.setObjectName("MvToolbar")
        toolbar.setLayout(bar)

        # ---------------- tracks ----------------
        self.scroll = QScrollArea()
        self.scroll.setObjectName("MvTracks")
        self.scroll.setWidget(self.canvas)
        self.scroll.setWidgetResizable(False)
        self.scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        self.canvas.setFixedHeight(CANVAS_H)

        self.header = TrackHeader()
        self.header.toggled.connect(self._on_toggle)
        body = QHBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(0)
        header_wrap = QVBoxLayout()
        header_wrap.setContentsMargins(0, 0, 0, 0)
        header_wrap.addWidget(self.header)
        header_wrap.addStretch(1)
        body.addLayout(header_wrap)
        body.addWidget(self.scroll, 1)

        # ---------------- bottom bar ----------------
        self.zoom_slider = QSlider(Qt.Orientation.Horizontal)
        self.zoom_slider.setObjectName("MvScale")
        self.zoom_slider.setRange(0, 100)
        self.zoom_slider.setFixedWidth(150)
        self.zoom_slider.valueChanged.connect(self._zoom_from_slider)
        btn_out = tool("zoom_out", "Zoom out (Ctrl+-)", lambda: self._zoom_step(0.8))
        btn_in = tool("zoom_in", "Zoom in (Ctrl+=)", lambda: self._zoom_step(1.25))
        scale_lbl = QLabel("Scale:")
        scale_lbl.setObjectName("MvMuted")

        self.info = QLabel("")
        self.info.setObjectName("MvMuted")
        self.lbl_settings = QLabel("")
        self.lbl_settings.setObjectName("MvInfo")
        self.lbl_length = QLabel("")
        self.lbl_length.setObjectName("MvInfo")
        self.btn_settings = tool("pencil", "Project settings: video size and ratio "
                                           "(16:9, 9:16, 1:1 ...), framing",
                                 self.projectSettingsRequested.emit)
        self.btn_settings.setIconSize(icon_size(15))
        info_box = QVBoxLayout()
        info_box.setSpacing(2)
        row1 = QHBoxLayout()
        row1.setSpacing(4)
        row1.addWidget(self.lbl_settings)
        row1.addWidget(self.btn_settings)
        row1.addStretch(1)
        info_box.addLayout(row1)
        info_box.addWidget(self.lbl_length)

        self.btn_export = QToolButton()
        self.btn_export.setObjectName("MvExport")
        self.btn_export.setText("Export Video")
        self.btn_export.setMinimumSize(150, 36)
        self.btn_export.clicked.connect(self.exportRequested.emit)

        def quick(text, tip, signal):
            b = QToolButton()
            b.setObjectName("MvQuick")
            b.setText(text)
            b.setToolTip(tip)
            b.setMinimumHeight(32)
            b.clicked.connect(signal.emit)
            return b

        self.btn_bgm = quick("Load BGM", "Add background music under the voice",
                             self.bgmRequested)
        self.btn_isolate = quick("Isolate BGM", "Take the original voices out: the music "
                                 "and ambience of the video stay", self.isolateRequested)
        self.btn_import_srt = quick("Import SRT", "Lines from a subtitle file (.srt) - "
                                    "Khmer subtitles are ready for the AI voice",
                                    self.importSrtRequested)
        self.btn_export_srt = quick("Export SRT", "Save the subtitles as an .srt file",
                                    self.exportSrtRequested)

        def bar():
            f = QFrame()
            f.setObjectName("MvQuickSep")
            f.setFixedSize(1, 22)
            return f

        bottom = QHBoxLayout()
        bottom.setContentsMargins(12, 6, 14, 8)
        bottom.setSpacing(6)
        bottom.addWidget(scale_lbl)
        bottom.addWidget(btn_out)
        bottom.addWidget(self.zoom_slider)
        bottom.addWidget(btn_in)
        bottom.addSpacing(16)
        bottom.addWidget(self.info)
        bottom.addStretch(1)
        bottom.addLayout(info_box)
        bottom.addSpacing(16)
        bottom.addWidget(self.btn_bgm)
        bottom.addWidget(self.btn_isolate)
        bottom.addSpacing(4)
        bottom.addWidget(bar())
        bottom.addSpacing(4)
        bottom.addWidget(self.btn_import_srt)
        bottom.addWidget(self.btn_export_srt)
        bottom.addSpacing(10)
        bottom.addWidget(self.btn_export)
        bottom_w = QWidget()
        bottom_w.setObjectName("MvBottom")
        bottom_w.setLayout(bottom)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(toolbar)
        lay.addLayout(body, 1)
        lay.addWidget(bottom_w)
        self.setMinimumHeight(CANVAS_H + 120)
        self.sync_zoom_slider()
        self.update_info()

    # ------------------------------------------------------------------ #
    # Zoom (slider on a log scale: 0 -> 0.2 px/s, 100 -> 600 px/s)
    # ------------------------------------------------------------------ #
    _ZMIN, _ZMAX = 0.2, 600.0

    @classmethod
    def _slider_to_pps(cls, v: int) -> float:
        return cls._ZMIN * ((cls._ZMAX / cls._ZMIN) ** (v / 100.0))

    @classmethod
    def _pps_to_slider(cls, pps: float) -> int:
        pps = max(cls._ZMIN, min(cls._ZMAX, pps))
        return int(round(100.0 * math.log(pps / cls._ZMIN) / math.log(cls._ZMAX / cls._ZMIN)))

    def _zoom_from_slider(self, v: int):
        self.canvas.set_zoom(self._slider_to_pps(v))

    def _zoom_step(self, factor: float):
        self.canvas.set_zoom(self.canvas.pps * factor)
        self.sync_zoom_slider()

    def sync_zoom_slider(self):
        self.zoom_slider.blockSignals(True)
        self.zoom_slider.setValue(self._pps_to_slider(self.canvas.pps))
        self.zoom_slider.blockSignals(False)

    def zoom_fit(self):
        if not self.project:
            return
        length = max(1.0, self.project.timeline_length())
        width = max(200, self.scroll.viewport().width() - LEFT_PAD - 30)
        self.canvas.set_zoom(width / length)
        self.scroll.horizontalScrollBar().setValue(0)
        self.sync_zoom_slider()

    # ------------------------------------------------------------------ #
    # Project
    # ------------------------------------------------------------------ #
    def set_project(self, project: Optional[Project]):
        self.project = project
        self.canvas.set_project(project)
        self.update_info()
        self._load_thumbnails()

    def refresh(self):
        self.canvas.set_project(self.project)
        self.update_info()

    def update_info(self):
        p = self.project
        if not p or not p.has_video():
            self.info.setText("No video loaded")
            self.lbl_settings.setText("Project settings:  –")
            self.lbl_length.setText("Project length:  00:00")
            self.btn_export.setEnabled(False)
            return
        self.btn_export.setEnabled(True)
        vc = p.video_clips
        # pieces made by the automatic slow-down are not separate videos
        parts = sum(1 for i, c in enumerate(vc)
                    if i == 0 or abs(vc[i - 1].src_out - c.src_in) > 1e-3)
        slow = sum(1 for c in vc if c.rate < 0.999)
        self.info.setText(
            f"{parts} video · {len(p.audio_clips)} voice · {len(p.subtitle_clips)} subtitle "
            f"clips" + (f" · slowed in {slow} places" if slow else ""))
        w, h = p.width, p.height
        if w and h:
            w, h = branding.output_size(p, 0)    # after the Video ratio setting
        ratio = ""
        if w and h:
            g = math.gcd(w, h)
            rw, rh = w // g, h // g
            ratio = f" {rw}:{rh}" if rw <= 300 and rh <= 300 else f" {w / h:.2f}:1"
            if branding.RATIOS.get(p.out_ratio):            # rounded sizes: show 9:16
                ratio = f" {p.out_ratio}"
        fps = getattr(p, "out_fps", 0.0) or getattr(p, "fps", 0.0) or 0.0
        fps_txt = f" {fps:.2f}".rstrip("0").rstrip(".") + " FPS" if fps else ""
        ch = {1: "Mono", 2: "Stereo", 6: "5.1"}.get(int(p.audio_channels or 2), "Stereo")
        self.lbl_settings.setText(f"Project settings:  {w}x{h}{ratio}{fps_txt}, "
                                  f"{int(p.audio_rate or 44100)} Hz {ch}")
        length = p.sequence_duration()
        text = f"Project length:  {self._length(length)}"
        if abs(p.speed() - 1.0) > 0.001:       # Clip Properties > Video > Speed
            text += f"  →  {self._length(p.output_duration())}  (speed {round(p.speed() * 100)}%)"
        self.lbl_length.setText(text)

    @staticmethod
    def _length(t: float) -> str:
        t = int(round(t))
        if t >= 3600:
            return f"{t // 3600}:{t % 3600 // 60:02d}:{t % 60:02d}"
        return f"{t // 60}:{t % 60:02d}"

    def _load_thumbnails(self):
        """Film strip frames, extracted in the background (cached on disk)."""
        p = self.project
        video = p.video_path if p and p.has_video() else ""
        if video == self._thumb_video:
            return
        self._thumb_video = video
        self.canvas.thumbs.clear()
        self.canvas.update()
        if not video or not os.path.isfile(video):
            return
        from core.media import extract_thumbnails
        from ui.workers import TaskWorker

        cache = p.work_dir if p.work_dir and os.path.isdir(p.work_dir) else ""
        worker = TaskWorker(lambda prog, stop: extract_thumbnails(video, cache, should_stop=stop),
                            "thumbnails", self)

        def done(result, video=video):
            if video == self._thumb_video:
                self.canvas.thumbs.set(video, *result)
                self.canvas.update()

        worker.done.connect(done)
        worker.failed.connect(lambda err: print(f"[thumbnails] {err}"))
        if self._thumb_worker is not None and self._thumb_worker.isRunning():
            self._thumb_worker.stop()
        self._thumb_worker = worker
        worker.start()

    def stop_workers(self):
        if self._thumb_worker is not None and self._thumb_worker.isRunning():
            self._thumb_worker.stop()
            self._thumb_worker.wait(3000)

    # ------------------------------------------------------------------ #
    # Playhead / transport
    # ------------------------------------------------------------------ #
    def set_playhead(self, t: float, follow: bool = False):
        c = self.canvas
        old = c.playhead
        c.playhead = t
        # only the strips under the old and the new playhead (playing calls
        # this ~30 times a second; the whole timeline of a film is huge)
        for x in {int(c.x_of(old)), int(c.x_of(t))}:
            c.update(x - 9, 0, 18, c.height())
        p = self.canvas.project
        self.timecode.set_time(t / p.speed() if p else t)      # time in the exported video
        if follow:
            self.canvas.follow_playhead()

    def set_playing(self, playing: bool):
        self.btn_play.setIcon(icon("pause" if playing else "play", 20))

    @staticmethod
    def _ratio_icon(key: str) -> QPixmap:
        """A small rectangle with the shape of the ratio (a dot for Original)."""
        from core import branding

        size = 22
        pm = QPixmap(size, size)
        pm.fill(Qt.GlobalColor.transparent)
        qp = QPainter(pm)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        qp.setPen(QPen(QColor("#c9cdd8"), 1.4))
        r = branding.RATIOS.get(key)
        a, b = r if r else (1, 1)
        s = 16.0 / max(a, b)
        w, h = a * s, b * s
        qp.drawRoundedRect(QRectF((size - w) / 2, (size - h) / 2, w, h), 1.5, 1.5)
        if not r:
            qp.setBrush(QColor("#c9cdd8"))
            qp.drawEllipse(QPointF(size / 2, size / 2), 2, 2)
        qp.end()
        return pm

    def _fill_ratio_menu(self):
        """Original · 9:16 · 16:9 · 1:1 · 4:5 · 3:4 · 4:3 · 21:9 - chosen at once."""
        from PySide6.QtGui import QIcon

        from core import branding
        from core.i18n import tr

        m = self.ratio_menu
        m.clear()
        cur = (self.project.out_ratio if self.project else "original") or "original"
        for key in branding.RATIOS:
            text = tr("Original") if key == "original" else key
            act = m.addAction(QIcon(self._ratio_icon(key)), text + ("   ✓" if key == cur else ""))
            act.setToolTip(branding.RATIO_LABELS.get(key, key))
            if key == cur:
                f = act.font()
                f.setBold(True)
                act.setFont(f)
            act.triggered.connect(lambda _=False, k=key: self.ratioChosen.emit(k))
        m.addSeparator()
        m.addAction(tr("More settings…"), self.projectSettingsRequested.emit)

    def _prev_point(self):
        t = self.canvas.playhead
        pts = [x for x in self.canvas.edit_points() if x < t - 0.05]
        self.canvas._move_playhead(pts[-1] if pts else 0.0)

    def _next_point(self):
        t = self.canvas.playhead
        pts = [x for x in self.canvas.edit_points() if x > t + 0.05]
        if pts:
            self.canvas._move_playhead(pts[0])

    def _properties(self):
        if not self.canvas.edit_selected_properties():
            QToolTip.showText(self.btn_props.mapToGlobal(self.btn_props.rect().bottomLeft()),
                              "Select an AI voice clip (volume) or a subtitle (text) first",
                              self.btn_props)

    def _on_toggle(self, key: str, what: str, on: bool):
        tag = key if what == "visible" or key != "video" else "video_sound"
        if on:
            self.canvas.dimmed.discard(tag)
        else:
            self.canvas.dimmed.add(tag)
        self.canvas.update()
        self.trackToggled.emit(key, what, on)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.canvas._update_width()

    # ------------------------------------------------------------------ #
    # Split / delete (work on the shared project object)
    # ------------------------------------------------------------------ #
    def split_at_playhead(self) -> bool:
        """Split the selected clip (or the video clip under the playhead)."""
        p = self.project
        if not p:
            return False
        t = self.canvas.playhead
        kind, clip = self.canvas.selected_clip()
        if clip is None or not (clip.start + 0.05 < t < clip.end - 0.05):
            kind, clip = "video", None
            for c in p.video_clips:
                if c.start + 0.05 < t < c.end - 0.05:
                    clip = c
                    break
        if clip is None:
            return False

        self.canvas.aboutToEdit.emit()
        if kind == "video":
            cut = clip.to_source(t)
            idx = p.video_clips.index(clip)
            right = dataclasses.replace(clip, id=new_id(), src_in=cut)
            clip.src_out = cut
            p.video_clips.insert(idx + 1, right)
            p.layout_video()
            self.canvas.selected = ("video", right.id)
        elif kind in SOUND_KINDS:
            cut = clip.src_in + (t - clip.start)
            # the right part keeps volume / speed / fade-out, the left keeps fade-in
            right = dataclasses.replace(clip, id=new_id(), start=t, src_in=cut, seg_id="",
                                        fade_in=0.0)
            clip.src_out = cut
            clip.fade_out = 0.0
            track = p.audio_clips if kind == "audio" else p.music_clips
            track.append(right)
            track.sort(key=lambda c: c.start)
            self.canvas.selected = (kind, right.id)
        elif kind == "subs":
            right = SubtitleClip(new_id(), t, clip.end, clip.text, "", hidden=clip.hidden)
            clip.end = t
            p.subtitle_clips.append(right)
            p.subtitle_clips.sort(key=lambda c: c.start)
            self.canvas.selected = ("subs", right.id)
        self.canvas.edited.emit(kind)
        self.refresh()
        return True

    def delete_selected(self) -> bool:
        p = self.project
        kind, clip = self.canvas.selected_clip()
        if not p or clip is None:
            return False
        if kind == "video" and len(p.video_clips) <= 1:
            return False
        self.canvas.aboutToEdit.emit()
        if kind == "video":
            p.video_clips.remove(clip)
            p.layout_video()
        elif kind == "audio":
            p.audio_clips.remove(clip)
        elif kind == "music":
            p.music_clips.remove(clip)
        elif kind == "subs":
            p.subtitle_clips.remove(clip)
        self.canvas.selected = None
        self.canvas.edited.emit(kind)
        self.refresh()
        return True
