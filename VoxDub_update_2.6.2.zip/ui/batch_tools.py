"""
batch_tools.py - The editor's Tools for the whole batch queue.

The same pages as the editor (Color Adjustments, Clip Properties, Equalizer,
Noise Removal, Audio Effects) plus Crop & Rotate as numbers and Project
settings, with a preview of the exported picture of any queued video
(‹ › walks through the queue) and "Listen" for the sound. Everything is set
here, without opening a video in the editor first; OK writes it into the
queue's settings, which every video gets when it is dubbed.
"""

import copy
import os
import tempfile
import time
from types import SimpleNamespace
from typing import Dict, List, Optional

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QPixmap
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QFrame, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
    QPushButton, QSlider, QStackedWidget, QVBoxLayout, QWidget,
)

from core import batch
from core.project import Project
from ui.tools_panel import SliderRow, ToolsPanel
from ui.workers import TaskWorker

# what the dialog edits (and OK writes back into the queue's settings)
# Style tab of the editor: original subtitles, subtitle look, logo, brand text
STYLE_FIELDS = (
    "cover_enabled", "cover_rect", "cover_mode", "sub_position", "subtitle_scale",
    "sub_font", "sub_color", "sub_bold", "sub_outline", "sub_outline_color", "sub_shadow",
    "sub_box", "sub_box_color", "sub_box_opacity", "sub_bottom", "sub_x", "subs_hidden",
    "logo_path", "logo_corner", "logo_pos", "logo_motion", "logo_size", "logo_opacity",
    "extra_logos", "brand_text", "brand_corner", "brand_pos", "brand_motion", "brand_size", "brand_color")
TEST_SECONDS = 6          # "Play": seconds of the real export
SAMPLE_SUB = {"km": "នេះជាគំរូ subtitle ខ្មែរ", "en": "This is how the subtitles look"}

EDIT_FIELDS = tuple(dict.fromkeys(
    batch.TOOL_FIELDS + ("out_ratio", "ratio_fill", "out_width", "out_height", "out_fps",
                         "audio_rate", "audio_channels", "crop_left", "crop_top",
                         "crop_right", "crop_bottom", "zoom", "original_volume",
                         "dub_volume", "mute_original_speech", "bg_mode")
    + STYLE_FIELDS))

NAV = [
    ("📐  Project settings", "settings"),
    ("🎨  Style · Subtitles · Logo", "style"),
    ("✂  Crop and Rotate", "crop"),
    ("◑  Color Adjustments", "color"),
    ("🎞  Video · Speed · Fades", "video"),
    ("🔊  Sound", "sound"),
    ("      Original sound · Fades", "audio"),
    ("      Equalizer", "eq:orig"),
    ("      Noise Removal", "noise:orig"),
    ("      Audio Effects", "effects:orig"),
    ("🎙  AI voice · Equalizer", "eq:voice"),
    ("🎙  AI voice · Noise Removal", "noise:voice"),
    ("🎙  AI voice · Audio Effects", "effects:voice"),
]


class _CropNumbers(QWidget):
    """Crop & Rotate for the queue: no box to drag (the videos differ), so the
    edges are numbers (% of the frame)."""

    def __init__(self, dlg: "BatchToolsDialog"):
        super().__init__()
        self.dlg = dlg
        from PySide6.QtWidgets import QGridLayout

        g = QGridLayout(self)
        g.setContentsMargins(24, 16, 18, 8)
        g.setHorizontalSpacing(14)
        g.setVerticalSpacing(12)
        head = QLabel("Crop and Rotate")
        head.setObjectName("MvToolTitle")
        g.addWidget(head, 0, 0, 1, 2)
        self.rows: Dict[str, SliderRow] = {}
        spec = [("rotate", "Angle:", -180, 180, 0.1, 1, "°", 1.0),
                ("zoom", "Zoom:", 100, 150, 1, 0, " %", 100.0),
                ("crop_top", "Cut top:", 0, 45, 0.5, 1, " %", 100.0),
                ("crop_bottom", "Cut bottom:", 0, 45, 0.5, 1, " %", 100.0),
                ("crop_left", "Cut left:", 0, 45, 0.5, 1, " %", 100.0),
                ("crop_right", "Cut right:", 0, 45, 0.5, 1, " %", 100.0)]
        self.scale = {}
        for r, (field, label, lo, hi, step, dec, suf, sc) in enumerate(spec, start=1):
            row = SliderRow(lo, hi, step, dec, suf)
            row.valueChanged.connect(lambda v, f=field: self._set(f, v))
            lbl = QLabel(label)
            lbl.setObjectName("MvLabel")
            g.addWidget(lbl, r, 0)
            g.addWidget(row, r, 1)
            self.rows[field] = row
            self.scale[field] = sc
        reset = QPushButton("Reset")
        reset.setObjectName("MvApply")
        reset.clicked.connect(self._reset)
        g.addWidget(reset, len(spec) + 1, 1, Qt.AlignmentFlag.AlignLeft)
        hint = QLabel("The same cut is used for every video. Black bars that differ from "
                      "video to video: tick “Remove black bars in each video” (Auto tab).")
        hint.setWordWrap(True)
        hint.setObjectName("MvMuted")
        g.addWidget(hint, len(spec) + 2, 0, 1, 2)
        g.setRowStretch(len(spec) + 3, 1)

    def load(self, p: Project):
        for f, row in self.rows.items():
            v = float(getattr(p, f) or (1.0 if f == "zoom" else 0.0))
            row.set_value(round(v * self.scale[f], 1))

    def _set(self, field: str, v: float):
        val = round(v / self.scale[field], 4)
        if field == "zoom":
            val = max(1.0, val)
        setattr(self.dlg.p, field, val)
        self.dlg.changed("crop")

    def _reset(self):
        p = self.dlg.p
        p.rotate, p.zoom = 0.0, 1.0
        p.crop_left = p.crop_top = p.crop_right = p.crop_bottom = 0.0
        self.load(p)
        self.dlg.changed("crop")


class _SoundPage(QWidget):
    """The SOUND part of the editor's Export window, for every video of the
    queue: remove the original dialogue (keep music & ambience), how loud the
    background is, and how loud the AI voice is."""

    def __init__(self, dlg: "BatchToolsDialog"):
        super().__init__()
        self.dlg = dlg
        self._loading = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 16, 18, 8)
        lay.setSpacing(6)
        head = QLabel("Sound")
        head.setObjectName("MvToolTitle")
        lay.addWidget(head)

        self.chk_drop = QCheckBox("Isolate BGM – remove the original dialogue")
        self.chk_drop.toggled.connect(self._drop_changed)
        lay.addWidget(self.chk_drop)
        lay.addWidget(self._hint("Silences the original actors while keeping the music and "
                                 "ambience."))

        self.lbl_bg = QLabel("Music & ambience")
        self.sl_bg, self.lb_bg = self._slider(100)
        lay.addLayout(self._row(self.lbl_bg, self.sl_bg, self.lb_bg))
        self.chk_mute = QCheckBox("Mute the original speech where the AI voice speaks")
        self.chk_mute.toggled.connect(self._apply)
        mute = QHBoxLayout()
        mute.setContentsMargins(26, 0, 0, 0)
        mute.addWidget(self.chk_mute)
        lay.addLayout(mute)
        self.sl_dub, self.lb_dub = self._slider(200)
        lay.addLayout(self._row(QLabel("AI voice"), self.sl_dub, self.lb_dub))
        self.note = QLabel("")
        self.note.setObjectName("MvMuted")
        self.note.setWordWrap(True)
        lay.addSpacing(8)
        lay.addWidget(self.note)
        more = QLabel("Equalizer, Noise Removal and Audio Effects of the original sound and "
                      "of the AI voice: the pages under this one.")
        more.setObjectName("MvMuted")
        more.setWordWrap(True)
        lay.addWidget(more)
        lay.addStretch(1)

    @staticmethod
    def _hint(text: str) -> QLabel:
        lb = QLabel(text)
        lb.setObjectName("MutedLabel")
        lb.setWordWrap(True)
        lb.setContentsMargins(26, 0, 0, 4)
        return lb

    def _slider(self, top: int):
        sl = QSlider(Qt.Orientation.Horizontal)
        sl.setRange(0, top)
        lb = QLabel("0%")
        lb.setFixedWidth(44)
        lb.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        sl.valueChanged.connect(lambda v: (lb.setText(f"{v}%"), self._apply()))
        return sl, lb

    @staticmethod
    def _row(label: QLabel, sl: QSlider, val: QLabel) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setContentsMargins(26, 0, 0, 0)
        label.setMinimumWidth(130)
        row.addWidget(label)
        row.addWidget(sl, 1)
        row.addWidget(val)
        return row

    def load(self, p: Project):
        self._loading = True
        self.chk_drop.setChecked(getattr(p, "bg_mode", "original") == "music")
        self.sl_bg.setValue(int(round(p.original_volume * 100)))
        self.sl_dub.setValue(int(round(p.dub_volume * 100)))
        self.chk_mute.setChecked(bool(p.mute_original_speech))
        self._loading = False
        self._show()

    def _drop_changed(self, on: bool):
        if on and not self._loading and self.sl_bg.value() <= 20:
            self.sl_bg.setValue(80)             # the music alone can be louder
        self._apply()

    def _show(self):
        music = self.chk_drop.isChecked()
        self.chk_mute.setVisible(not music)     # no original speech left to mute
        self.lbl_bg.setText("Music & ambience" if music else "Original sound")
        self.sl_bg.setToolTip("0% = silent · 100% = as loud as in the video")
        if music:
            from core.separate import model_ready

            self.note.setText(
                "The original voices are taken out of every video; the music and ambience "
                "stay. Each video takes a little longer (~1 min per 2 min of video)"
                + ("." if model_ready() else ", and a 64 MB model is downloaded once."))
        else:
            self.note.setText("The original sound stays in the background at the volume "
                              "above (0% = removed).")

    def _apply(self, *_):
        self._show()
        if self._loading:
            return
        p = self.dlg.p
        p.bg_mode = "music" if self.chk_drop.isChecked() else "original"
        p.original_volume = self.sl_bg.value() / 100.0
        p.dub_volume = self.sl_dub.value() / 100.0
        p.mute_original_speech = self.chk_mute.isChecked()
        self.dlg.changed("audio")


class _SettingsPage(QWidget):
    def __init__(self, dlg: "BatchToolsDialog"):
        super().__init__()
        self.dlg = dlg
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 16, 18, 8)
        head = QLabel("Project settings")
        head.setObjectName("MvToolTitle")
        self.summary = QLabel("")
        self.summary.setWordWrap(True)
        self.summary.setObjectName("MvToolTarget")
        btn = QPushButton("Change…")
        btn.setObjectName("AccentButton")
        btn.clicked.connect(dlg.edit_project_settings)
        note = QLabel("Resolution (16:9, 9:16 TikTok, 1:1 …), framing, FPS, sample rate and "
                      "channels of every exported video.")
        note.setWordWrap(True)
        note.setObjectName("MvMuted")
        lay.addWidget(head)
        lay.addWidget(self.summary)
        lay.addWidget(btn, 0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(note)
        lay.addStretch(1)

    def load(self, p: Project):
        size = "same as each video"
        if p.out_ratio != "original":
            size = (f"{p.out_width}x{p.out_height}" if p.out_width and p.out_height
                    else p.out_ratio)
            size += f" · framing: {p.ratio_fill}"
        fps = f"{p.out_fps:g} FPS" if p.out_fps else "FPS of each video"
        ch = {1: "Mono", 2: "Stereo", 6: "Surround 5.1"}.get(int(p.audio_channels or 2), "Stereo")
        self.summary.setText(f"Size: {size}\n{fps} · {p.audio_rate} Hz {ch}")


# 2.4 Style Studio toolbar above the preview: (key, button, tooltip)
STUDIO = [
    ("text", "T  Text", "Add your brand text on the video – drag it to its place"),
    ("logo", "🖼  Logo", "Choose a logo (PNG) – drag it to its place, the small square resizes"),
    ("subtitle", "💬  Subtitle", "Show our subtitles – drag them up / down, set font and colour"),
    ("blur", "▭  Blur box", "Hide the original subtitles with a blur box – drag / resize it"),
    ("crop", "✂  Crop", "Crop the picture (black bars, a watermark at the edge)"),
    ("rotate", "⟳  Rotate", "Rotate or flip the picture"),
    ("color", "◑  Color", "Brightness, contrast, saturation, auto colour"),
    ("ratio", "📐  Ratio", "9:16 TikTok, 16:9 YouTube, 1:1 … and the size of the video"),
]
DEFAULT_TEXT = "SARIKA"


class BatchToolsDialog(QDialog):
    def __init__(self, parent, base: dict, videos: List[str]):
        super().__init__(parent)
        self.setWindowTitle("Batch queue – Tools for every video")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(1280, 760)
        self.base = base
        self.videos = [v for v in videos if os.path.isfile(v)]
        self.p = Project()                      # the queue's settings being edited
        for k, v in base.items():
            if hasattr(self.p, k):
                setattr(self.p, k, copy.deepcopy(v))
        self._prev: Dict[str, Project] = {}
        self._idx = 0
        self._seq = 0
        self._worker: Optional[TaskWorker] = None
        self._test_worker: Optional[TaskWorker] = None
        self._test_n = 0
        self._test_file = ""
        self._audio_worker: Optional[TaskWorker] = None

        # ---- left: tool list
        self.nav = QListWidget()
        self.nav.setObjectName("BatchToolNav")
        self.nav.setFixedWidth(230)
        for text, key in NAV:
            it = QListWidgetItem(text)
            it.setData(Qt.ItemDataRole.UserRole, key)
            self.nav.addItem(it)
        self.nav.currentRowChanged.connect(self._nav_changed)

        # ---- middle: the editor's own pages
        self.panel = ToolsPanel()
        self.panel.changed.connect(self.changed)
        self.panel.toolSwitchRequested.connect(self._switch)
        self.panel.previewRequested.connect(self.listen)
        for page in (self.panel.crop, self.panel.color, self.panel.eq, self.panel.noise,
                     self.panel.fx):
            page.btn_back.hide()        # the list on the left is the navigation here
            page.btn_ok.hide()
        self.crop = _CropNumbers(self)
        self.settings_page = _SettingsPage(self)
        self.sound = _SoundPage(self)
        self.middle = QStackedWidget()
        self.middle.addWidget(self.settings_page)
        self.middle.addWidget(self.sound)
        self.middle.addWidget(self.crop)
        self.middle.addWidget(self.panel)
        from ui.style_panel import StylePanel

        self.style = StylePanel()
        self.style.btn_detect.setToolTip(
            "Find the original subtitles in the video shown on the right and hide them.\n"
            "Every video in the queue then looks for its own when it is dubbed.")
        self.style.detectRequested.connect(self.detect_cover)
        self.style.btn_preview.hide()        # the preview on the right is always "as exported"
        self.style.changed.connect(self._style_changed)
        self.style.subsShownToggled.connect(
            lambda on: (setattr(self.p, "subs_hidden", not on), self._schedule()))
        self.auto_cover = False              # OK: turn on "find the original subtitles" per video
        self.cover_by_hand = False           # OK: the dragged box for every video (auto off)
        self.middle.addWidget(self.style)
        self.middle.setMinimumWidth(430)

        # ---- right: preview of the exported picture
        from ui.drag_preview import DragPreview

        self.pic = DragPreview()             # drag the logo / brand text / subtitles here
        self.pic.edited.connect(self._dragged)
        self.btn_prev = QPushButton("‹")
        self.btn_next = QPushButton("›")
        for b in (self.btn_prev, self.btn_next):
            b.setFixedWidth(36)
        self.btn_prev.clicked.connect(lambda: self._walk(-1))
        self.btn_next.clicked.connect(lambda: self._walk(1))
        self.lb_video = QLabel("")
        self.lb_video.setObjectName("MutedLabel")
        self.lb_video.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pos = QSlider(Qt.Orientation.Horizontal)
        self.pos.setRange(0, 100)
        self.pos.setValue(20)
        self.pos.setToolTip("Where in the video the preview frame is taken")
        self.pos.valueChanged.connect(lambda *_: self._schedule())
        self.lb_state = QLabel("")
        self.lb_state.setObjectName("MutedLabel")
        walk = QHBoxLayout()
        walk.addWidget(self.btn_prev)
        walk.addWidget(self.lb_video, 1)
        walk.addWidget(self.btn_next)
        right = QFrame()
        right.setObjectName("DashPanel")
        rl = QVBoxLayout(right)
        cap = QLabel("Preview (as exported)")
        cap.setObjectName("SectionTitle")
        rl.addWidget(cap)
        # 2.4 Style Studio: click a tool, it appears on the video, drag it there;
        # the panel in the middle shows the details of that one thing
        studio = QHBoxLayout()
        studio.setSpacing(6)
        self.studio_buttons = {}
        for key, text, tip in STUDIO:
            b = QPushButton(text)
            b.setObjectName("StudioButton")
            b.setToolTip(tip)
            b.setMinimumHeight(34)
            b.clicked.connect(lambda _=False, k=key: self.studio(k))
            studio.addWidget(b)
            self.studio_buttons[key] = b
        studio.addStretch(1)
        rl.addLayout(studio)
        # the picture you can drag things in / a few seconds of the real export
        from PySide6.QtMultimediaWidgets import QVideoWidget

        self.view_stack = QStackedWidget()
        self.view_stack.addWidget(self.pic)
        play_page = QWidget()
        pl = QVBoxLayout(play_page)
        pl.setContentsMargins(0, 0, 0, 0)
        self.video_out = QVideoWidget()
        self.video_out.setMinimumSize(420, 300)
        pl.addWidget(self.video_out, 1)
        prow = QHBoxLayout()
        self.btn_replay = QPushButton("⟲ Play again")
        self.btn_replay.clicked.connect(self._replay)
        self.btn_back_edit = QPushButton("✎ Back to editing")
        self.btn_back_edit.clicked.connect(self._stop_test)
        prow.addWidget(self.btn_replay)
        prow.addStretch(1)
        prow.addWidget(self.btn_back_edit)
        pl.addLayout(prow)
        self.view_stack.addWidget(play_page)
        rl.addWidget(self.view_stack, 1)
        self.vplayer = QMediaPlayer(self)
        self.vplayer.setAudioOutput(QAudioOutput(self))
        self.vplayer.setVideoOutput(self.video_out)
        self.btn_play_test = QPushButton(f"▶  Play {TEST_SECONDS} s – check it as exported")
        self.btn_play_test.setObjectName("AccentButton")
        self.btn_play_test.setToolTip(
            "Makes a few seconds of the real export from the place of the slider below "
            "(logo, text, subtitles, colour, sound) and plays it.\nThe AI voice is not in "
            "it: the videos are not dubbed yet.")
        self.btn_play_test.clicked.connect(self.play_test)
        rl.addWidget(self.btn_play_test)
        drag_hint = QLabel("Drag the logo, the brand text, the subtitles or the dashed box "
                           "(hides the original subtitles) – the small square resizes.")
        drag_hint.setObjectName("MutedLabel")
        drag_hint.setWordWrap(True)
        rl.addWidget(drag_hint)
        rl.addLayout(walk)
        rl.addWidget(self.pos)
        rl.addWidget(self.lb_state)

        # ---- bottom
        self.btn_reset = QPushButton("Reset all tools")
        self.btn_reset.clicked.connect(self.reset_all)
        ok = QPushButton("OK – use for every video")
        ok.setObjectName("AccentButton")
        ok.clicked.connect(self.accept)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        note = QLabel("Used for every video when it is dubbed (videos that are already "
                      "dubbed keep their own settings).")
        note.setObjectName("MutedLabel")
        bottom = QHBoxLayout()
        bottom.addWidget(self.btn_reset)
        bottom.addSpacing(12)
        bottom.addWidget(note, 1)
        bottom.addWidget(ok)
        bottom.addWidget(cancel)

        body = QHBoxLayout()
        body.addWidget(self.nav)
        body.addWidget(self.middle)
        body.addWidget(right, 1)
        lay = QVBoxLayout(self)
        lay.addLayout(body, 1)
        lay.addLayout(bottom)

        self.player = QMediaPlayer(self)
        self.player.setAudioOutput(QAudioOutput(self))
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(250)
        self._timer.timeout.connect(self._render)

        self.nav.setCurrentRow([k for _t, k in NAV].index("color"))
        self._show_video()

    # ------------------------------------------------------------------ #
    # navigation
    # ------------------------------------------------------------------ #
    def _nav_changed(self, row: int):
        if row < 0:
            return
        self.open(NAV[row][1])

    def open(self, key: str):
        """settings / crop / color / video / audio / eq:orig / noise:voice ..."""
        p = self.p
        if key == "settings":
            self.settings_page.load(p)
            self.middle.setCurrentWidget(self.settings_page)
            return
        if key == "sound":
            self.sound.load(p)
            self.middle.setCurrentWidget(self.sound)
            return
        if key == "style":
            self.style.load(p)
            self.middle.setCurrentWidget(self.style)
            return
        if key == "crop":
            self.crop.load(p)
            self.middle.setCurrentWidget(self.crop)
            return
        self.middle.setCurrentWidget(self.panel)
        if key in ("color", "video", "audio"):
            self.panel.open_tool(key, p, None)
        else:
            sub, track = key.split(":")
            self.panel.project = p
            page = {"eq": self.panel.eq, "noise": self.panel.noise,
                    "effects": self.panel.fx}[sub]
            page.load(p, track)
            self.panel.stack.setCurrentWidget(page)

    def _switch(self, tool: str):
        """'Crop and Rotate' / 'Color' / 'Video Ratio' rows of Clip Properties."""
        key = {"ratio": "settings"}.get(tool, tool)
        rows = [k for _t, k in NAV]
        if key in rows:
            self.nav.setCurrentRow(rows.index(key))

    # ------------------------------------------------------------------ #
    # editing
    # ------------------------------------------------------------------ #
    def changed(self, kind: str = ""):
        if kind in ("", "crop", "color", "video", "ratio"):
            self._schedule()

    def edit_project_settings(self):
        from PySide6.QtWidgets import QDialog as _D

        from ui.dialogs import ProjectSettingsDialog

        q = self._preview_project() or copy.deepcopy(self.p)
        dlg = ProjectSettingsDialog(q, self)
        if dlg.exec() != _D.DialogCode.Accepted:
            return
        for k, v in dlg.values().items():
            setattr(self.p, k, v)
        self.settings_page.load(self.p)
        self._schedule()

    def reset_all(self):
        fresh = Project()
        for k in EDIT_FIELDS:
            setattr(self.p, k, copy.deepcopy(getattr(fresh, k)))
        self.open(NAV[max(0, self.nav.currentRow())][1])
        self._schedule()

    def values(self) -> dict:
        return {k: copy.deepcopy(getattr(self.p, k)) for k in EDIT_FIELDS}

    # ------------------------------------------------------------------ #
    # preview
    # ------------------------------------------------------------------ #
    def _walk(self, step: int):
        if self.videos:
            self._idx = (self._idx + step) % len(self.videos)
            self._show_video()

    def _show_video(self):
        has = bool(self.videos)
        for w in (self.btn_prev, self.btn_next, self.pos):
            w.setEnabled(has and (w is self.pos or len(self.videos) > 1))
        if not has:
            self.lb_video.setText("No video in the queue")
            return
        path = self.videos[self._idx]
        self.lb_video.setText(f"{self._idx + 1} / {len(self.videos)} · {os.path.basename(path)}")
        self._schedule()

    def _preview_project(self) -> Optional[Project]:
        """The current queued video with the settings being edited."""
        if not self.videos:
            return None
        path = self.videos[self._idx]
        if path not in self._prev:
            try:
                self._prev[path] = batch.preview_project({}, path)
            except Exception as e:
                self.lb_state.setText(f"Cannot read this video: {e}")
                return None
        q = copy.deepcopy(self._prev[path])
        for k in batch.SETTING_FIELDS:
            setattr(q, k, copy.deepcopy(getattr(self.p, k)))
        return q

    def _schedule(self):
        if self.videos:
            self._timer.start()

    # ------------------------------------------------------------------ #
    # ▶ Play: a few seconds exported with every setting
    # ------------------------------------------------------------------ #
    def play_test(self):
        from core.export import ExportOptions, export_video
        from core.project import SubtitleClip

        q = self._preview_project()
        if q is None:
            self.lb_state.setText("Add videos to the queue first")
            return
        if self._test_worker is not None and self._test_worker.isRunning():
            return
        dur = q.video_duration or q.sequence_duration()
        s0 = max(0.0, min(dur - 1.0, dur * self.pos.value() / 100.0))
        clip = q.video_clips[0]
        clip.src_in, clip.src_out = s0, min(dur, s0 + TEST_SECONDS)
        q.video_clips = [clip]
        q.layout_video()
        length = q.sequence_duration()
        q.subtitle_clips = [SubtitleClip("sample", min(0.4, length / 4), length * 0.85,
                                         SAMPLE_SUB.get(q.target_lang, SAMPLE_SUB["en"]))]
        note = ""
        if getattr(q, "bg_mode", "original") == "music":
            q.bg_mode = "original"          # (taking the voices out needs the whole video)
            note = " · music-only is done in the real export"
        self._test_n += 1
        out = os.path.join(tempfile.gettempdir(),
                           f"voxdub_batch_test_{os.getpid()}_{self._test_n % 2}.mp4")
        opts = ExportOptions(output_path=out, resolution="720p",
                             burn_subtitles=self._subs_on(), export_srt=False, original_volume=q.original_volume,
                             dub_volume=q.dub_volume, crf=26, preset="ultrafast",
                             subtitle_font=q.sub_font or (
                                 "Noto Sans Khmer" if q.target_lang == "km" else "Arial"),
                             encoder="x264")
        self.vplayer.stop()
        self.vplayer.setSource(QUrl())
        self.btn_play_test.setEnabled(False)
        self.lb_state.setText("Making the test clip…")
        w = TaskWorker(lambda prog, stop: export_video(q, opts, prog, stop), "Test", self)

        def done(r):
            self.btn_play_test.setEnabled(True)
            self.lb_state.setText(f"Playing {TEST_SECONDS} s from "
                                  f"{int(s0 // 60)}:{int(s0 % 60):02d} as exported{note}")
            self._test_file = r["video"]
            self.view_stack.setCurrentIndex(1)
            self._replay()

        def failed(e):
            self.btn_play_test.setEnabled(True)
            self.lb_state.setText(f"Test clip failed: {e}")

        w.done.connect(done)
        w.failed.connect(failed)
        self._test_worker = w
        w.start()

    def _replay(self):
        if self._test_file:
            self.vplayer.setSource(QUrl.fromLocalFile(self._test_file))
            self.vplayer.play()

    def _stop_test(self):
        self.vplayer.stop()
        self.view_stack.setCurrentIndex(0)

    def _subs_on(self) -> bool:
        """Are subtitles burned into the exported videos? (Output › Burn
        subtitles of the queue, Style › Show subtitles)"""
        chk = getattr(self.parent(), "chk_burn", None)
        burn = chk.isChecked() if chk is not None else True
        return burn and not getattr(self.p, "subs_hidden", False)

    def studio(self, key: str):
        """Style Studio button: put the thing on the video and show its details."""
        rows = [k for _t, k in NAV]
        page = {"crop": "crop", "rotate": "crop", "color": "color",
                "ratio": "settings"}.get(key, "style")
        self.nav.setCurrentRow(rows.index(page))
        for k, b in self.studio_buttons.items():
            b.setProperty("on", k == key)
            b.style().polish(b)
        st = self.style
        if key == "text":
            if not st.ed_text.text().strip():
                st.ed_text.setText(DEFAULT_TEXT)
            st.ensureWidgetVisible(st.ed_text)
            st.ed_text.setFocus()
            st.ed_text.selectAll()
        elif key == "logo":
            st.ensureWidgetVisible(st.ed_logo)
            if not st.ed_logo.text():
                st._choose_logo()
        elif key == "subtitle":
            st.chk_subs_show.setChecked(True)
            st.ensureWidgetVisible(st.chk_subs_show)
        elif key == "blur":
            st.chk_cover.setChecked(True)
            st.ensureWidgetVisible(st.chk_cover)
        self.pic.refresh()
        self._schedule()

    def _style_changed(self):
        self.pic.refresh()                  # logo / text / subtitles follow at once
        self._schedule()

    def _dragged(self, what: str):
        """Something was dragged in the preview: show the new numbers."""
        if self.middle.currentWidget() is self.style:
            self.style.load(self.p)
        if what == "cover":
            # 2.4: a box put in place by hand stays there for every video
            # (each video no longer looks for its own and moves it)
            self.auto_cover, self.cover_by_hand = False, True
            self._schedule()                # the blur is part of the rendered picture

    def detect_cover(self):
        """🔍 Auto detect: find the original subtitles in the video shown."""
        from core import hardsub

        if not self.videos:
            self.lb_state.setText("Add videos to the queue first")
            return
        path = self.videos[self._idx]
        self.style.btn_detect.setEnabled(False)
        self.lb_state.setText("Looking for the original subtitles…")
        w = TaskWorker(lambda prog, stop: hardsub.detect_subtitle_area(
            path, progress=prog, should_stop=stop), "Detect", self)

        def done(rect):
            self.style.btn_detect.setEnabled(True)
            if rect is None:
                self.lb_state.setText("No burned-in subtitles found in this video – "
                                      "drag the dashed box by hand, or try another video (›)")
                return
            p = self.p
            p.cover_rect, p.cover_enabled = rect, True     # our subtitles stay put
            self.auto_cover, self.cover_by_hand = True, False
            self.style.load(p)
            self._schedule()
            self.lb_state.setText("✅ Original subtitles found and hidden. Every video will "
                                  "also look for its own when it is dubbed.")

        def failed(e):
            self.style.btn_detect.setEnabled(True)
            self.lb_state.setText(f"Detect failed: {e}")

        w.done.connect(done)
        w.failed.connect(failed)
        self._detect_worker = w
        w.start()

    def _render(self):
        from core.export import ExportOptions, render_frame

        if self._worker is not None and self._worker.isRunning():
            self._timer.start()                     # newest request wins
            return
        q = self._preview_project()
        if q is None:
            return
        self._seq += 1
        seq = self._seq
        t = q.sequence_duration() * self.pos.value() / 100.0
        out = os.path.join(tempfile.gettempdir(),
                           f"voxdub_batch_prev_{os.getpid()}_{seq % 3}.png")
        from core.project import SubtitleClip

        # the sample subtitle only when the export burns subtitles in (Output tab
        # › Burn subtitles, Style › Show subtitles) - the preview shows the export
        sample = SAMPLE_SUB.get(q.target_lang, SAMPLE_SUB["en"]) if self._subs_on() else ""
        # the picture WITHOUT logo / brand text / subtitles: those are drawn by
        # the preview itself (same geometry as the export), so they can be dragged
        base = copy.deepcopy(q)
        base.logo_path, base.brand_text, base.extra_logos = "", "", []
        base.subtitle_clips = [SubtitleClip("sample", max(0.0, t - 1.0), t + 2.0, sample)]
        opts = ExportOptions(output_path="", resolution="720p", burn_subtitles=False)
        self.lb_state.setText("Rendering preview…")
        self._worker = TaskWorker(lambda prog, stop: render_frame(base, opts, t, out),
                                  "Preview", self)

        def done(path, seq=seq):
            if seq != self._seq:
                return
            pm = QPixmap(path)
            if not pm.isNull():
                self.pic.set_frame(pm, self.p, q, t, sample)
            self.lb_state.setText(f"{pm.width()}x{pm.height()} preview at "
                                  f"{int(t // 60)}:{int(t % 60):02d}" + (
                                      "" if sample else " · no subtitles: Output › Burn "
                                      "subtitles is off (or Style › Show subtitles)"))

        self._worker.done.connect(done)
        self._worker.failed.connect(lambda e: self.lb_state.setText(f"Preview failed: {e}"))
        self._worker.start()

    # ------------------------------------------------------------------ #
    # listen
    # ------------------------------------------------------------------ #
    def listen(self, track: str):
        """8 s of the original sound of the current video, or a sample line of
        the AI voice, with the Equalizer / Noise Removal / Effects."""
        from core.effects import render_audio_preview
        from core.tts import AUTO_VOICE, synthesize, voice_for_gender

        q = self._preview_project()
        if q is None:
            self.lb_state.setText("Add a video to the queue to listen")
            return
        if self._audio_worker is not None and self._audio_worker.isRunning():
            return
        stamp = int(time.time() * 1000)
        out = os.path.join(tempfile.gettempdir(), f"voxdub_batch_listen_{stamp}.wav")
        t = q.sequence_duration() * self.pos.value() / 100.0

        def job(progress, should_stop):
            if track != "voice":
                return render_audio_preview(q, "orig", out, t)
            from ui.main_window import SAMPLE_TEXT

            voice = q.voice
            if voice == AUTO_VOICE:
                voice = voice_for_gender(q.tts_engine, q.target_lang, "male")
            raw = os.path.join(tempfile.gettempdir(), f"voxdub_batch_voice_{stamp}.wav")
            synthesize(SAMPLE_TEXT.get(q.target_lang, SAMPLE_TEXT["en"]), raw,
                       q.tts_engine, voice, q.target_lang)
            return render_audio_preview(q, "voice", out, 0.0,
                                        SimpleNamespace(path=raw, src_in=0.0))

        self.lb_state.setText("Preparing the sound…")
        self._audio_worker = TaskWorker(job, "Listen", self)
        self._audio_worker.done.connect(self._play)
        self._audio_worker.failed.connect(lambda e: self.lb_state.setText(f"Listen failed: {e}"))
        self._audio_worker.start()

    def _play(self, path: str):
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()
        self.lb_state.setText("Playing 8 seconds with the audio effects")

    # ------------------------------------------------------------------ #
    def done(self, r):
        self._timer.stop()
        for w in (self._worker, self._audio_worker, self._test_worker,
                  getattr(self, "_detect_worker", None)):
            if w is not None and w.isRunning():
                if w is not self._worker:
                    w.stop()
                w.wait(8000)
        self.player.stop()
        self.vplayer.stop()
        super().done(r)
