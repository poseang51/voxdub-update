"""
voice_mixer.py - plays the AI voice in the preview through ONE audio stream.

The old way gave each voice clip its own QMediaPlayer and kept them in step
with the video by seeking them. On Windows a media player needs a moment to
open a file and reports its position only roughly, so lines were sometimes
started late, cut by a seek, or not heard at all ("sometimes there is sound,
sometimes not").

Here the clips are mixed by us, sample by sample, exactly where they sit on
the timeline (volume, normalize, fade in / out like the export), and the
result is written into one QAudioSink every few milliseconds. Its clock is
the video's playhead: if the two drift apart by more than ~0.12 s the mix
jumps to the playhead, so a line can not get lost.
"""

import bisect
from collections import OrderedDict
from typing import Dict, List, Optional

import numpy as np
from PySide6.QtMultimedia import QAudio, QAudioFormat, QAudioSink, QMediaDevices

DRIFT = 0.2             # s: further apart than this (3 ticks running) -> jump
DRIFT_TICKS = 3         # the video reports its position in steps: do not chase one
BUFFER = 0.35           # s of audio queued in the sink (rides out a busy UI moment)
CACHE_CLIPS = 80        # decoded clips kept in memory


def mix_window(clips: List, starts: List[float], t0: float, n: int, rate: int,
               get_audio, master: float = 1.0, gain_of=None,
               bg_gain: float = 1.0, music_gain: float = 1.0) -> np.ndarray:
    """Mono float32 mix of the clips for n samples starting at timeline t0.
    get_audio(clip) -> (float32 mono samples, sample rate == rate)."""
    out = np.zeros(n, np.float32)
    if n <= 0 or not clips:
        return out
    t1 = t0 + n / rate
    i = bisect.bisect_right(starts, t1)
    k = i - 1
    while k >= 0:
        c = clips[k]
        k -= 1
        if c.start + (c.src_out - c.src_in) <= t0:
            if t0 - c.start > 120:          # lines are short: stop looking back
                break
            continue
        data = get_audio(c)
        if data is None or not len(data):
            continue
        # where the clip overlaps [t0, t1) in output samples / clip samples
        a_out = max(0, int(round((c.start - t0) * rate)))
        clip_from = int(round(c.src_in * rate)) + max(0, int(round((t0 - c.start) * rate)))
        clip_end = min(len(data), int(round(c.src_out * rate)))
        m = min(n - a_out, clip_end - clip_from)
        if m <= 0:
            continue
        seg = data[clip_from:clip_from + m].astype(np.float32, copy=True)
        if getattr(c, "bg", False):         # music & effects (not the AI voice)
            vol = bg_gain
        elif getattr(c, "music", False):    # 🎵 Music track
            vol = float(getattr(c, "volume", 1.0)) * music_gain
        else:
            vol = float(getattr(c, "volume", 1.0)) * master
        if gain_of is not None and getattr(c, "normalize", False):
            vol *= gain_of(c)
        # fades, measured inside the trimmed clip (as the export does)
        fi = float(getattr(c, "fade_in", 0.0) or 0.0)
        fo = float(getattr(c, "fade_out", 0.0) or 0.0)
        if fi > 0 or fo > 0:
            # (a music piece: the fades belong to the whole clip it comes from)
            pos = (np.arange(m) + (clip_from - int(round(c.src_in * rate)))) / rate \
                + float(getattr(c, "env_off", 0.0))
            length = float(getattr(c, "env_len", 0.0)) or (c.src_out - c.src_in)
            g = np.ones(m, np.float32)
            if fi > 0:
                g *= np.clip(pos / fi, 0.0, 1.0)
            if fo > 0:
                g *= np.clip((length - pos) / fo, 0.0, 1.0)
            seg *= g
        out[a_out:a_out + m] += seg * vol
    np.clip(out, -1.0, 1.0, out=out)
    return out


from core.stretch import stretch  # noqa: E402  (pitch-kept time stretch)


BG_PIECE = 10.0             # s: the music track is played in pieces this long


class _BgPiece:
    """A part of the music-only track (Background: music & effects) under one
    video piece of the timeline. A slowed video piece (rate < 1) gets its
    music slowed the same way."""

    bg = True
    volume = 1.0
    normalize = False
    fade_in = fade_out = 0.0

    def __init__(self, file: str, a: float, b: float, rate: float, start: float):
        self.file, self.a, self.b, self.rate = file, a, b, rate
        self.path = f"{file}#{a:.3f}-{b:.3f}@{rate:.4f}"
        self.start = start
        self.src_in = 0.0
        self.src_out = (b - a) / rate


def bg_pieces(file: str, video_clips) -> List[_BgPiece]:
    out = []
    for vc in video_clips:
        step = BG_PIECE * vc.rate
        x = vc.src_in
        while x < vc.src_out - 1e-3:
            y = min(vc.src_out, x + step)
            out.append(_BgPiece(file, x, y, vc.rate, vc.to_timeline(x)))
            x = y
    return out


class _MusicPiece:
    """10 s of a 🎵 Music clip (a song is minutes long: the mixer looks back
    only a little, so it is played in pieces like the music-only track)."""

    music = True
    bg = False
    normalize = False

    def __init__(self, clip, a: float, b: float):
        self.path = clip.path
        self.volume = float(getattr(clip, "volume", 1.0))
        self.start = clip.start + (a - clip.src_in)
        self.src_in, self.src_out = a, b
        self.fade_in = float(getattr(clip, "fade_in", 0.0) or 0.0)
        self.fade_out = float(getattr(clip, "fade_out", 0.0) or 0.0)
        self.env_off = a - clip.src_in
        self.env_len = clip.src_out - clip.src_in


def music_pieces(clips) -> List[_MusicPiece]:
    out = []
    for c in clips or []:
        x = c.src_in
        while x < c.src_out - 1e-3:
            y = min(c.src_out, x + BG_PIECE)
            out.append(_MusicPiece(c, x, y))
            x = y
    return out


class _Sped:
    """A voice clip as heard when the whole video plays `speed` times faster:
    timeline times divided by the speed (the audio itself is stretched)."""

    def __init__(self, clip, speed: float):
        self.orig = clip
        self.path = clip.path
        self.start = clip.start / speed
        self.src_in = clip.src_in / speed
        self.src_out = clip.src_out / speed
        self.volume = getattr(clip, "volume", 1.0)
        self.normalize = getattr(clip, "normalize", False)
        self.fade_in = float(getattr(clip, "fade_in", 0.0) or 0.0) / speed
        self.fade_out = float(getattr(clip, "fade_out", 0.0) or 0.0) / speed
        self.bg = getattr(clip, "bg", False)
        self.music = getattr(clip, "music", False)
        self.env_off = float(getattr(clip, "env_off", 0.0)) / speed
        self.env_len = float(getattr(clip, "env_len", 0.0)) / speed


class VoiceMixer:
    """Same interface as the old VoicePool: set_clips / set_volume /
    update(t, playing, force) / pause_all / release_all."""

    def __init__(self, parent):
        self.parent = parent
        self.clips: List = []
        self.starts: List[float] = []
        self._source: List = []         # the project's clips (self.clips: as heard)
        self._bg: List = []             # music-only pieces (Background: music & effects)
        self._bg_key = None
        self.bg_volume = 0.0
        self.voices_on = True           # the AI voice (the music may play without it)
        self._music: List = []          # 🎵 Music track pieces
        self.music_on = True
        self.speed = 1.0                # Clip Properties > Video > Speed
        self.volume = 1.0
        self._cache: "OrderedDict[str, np.ndarray]" = OrderedDict()
        self.sink: Optional[QAudioSink] = None
        self.dev = None
        self.rate = 44100
        self.channels = 2
        self.fmt = QAudioFormat.SampleFormat.Int16
        self.pos = 0.0              # timeline time of the next sample written
        self._off = 0               # ticks in a row the mix was off the playhead
        self.running = False
        self.ok = self._open()
        try:
            self._devices = QMediaDevices(parent)
            self._devices.audioOutputsChanged.connect(self._device_changed)
        except Exception:
            self._devices = None

    # ---- the audio stream
    def _open(self) -> bool:
        try:
            device = QMediaDevices.defaultAudioOutput()
            if device.isNull():
                return False
            pref = device.preferredFormat()
            fmt = QAudioFormat()
            fmt.setSampleRate(pref.sampleRate() or 48000)
            fmt.setChannelCount(min(2, max(1, pref.channelCount() or 2)))
            fmt.setSampleFormat(QAudioFormat.SampleFormat.Int16)
            if not device.isFormatSupported(fmt):
                fmt.setSampleFormat(QAudioFormat.SampleFormat.Float)
                if not device.isFormatSupported(fmt):
                    fmt = pref
            self.rate, self.channels = fmt.sampleRate(), fmt.channelCount()
            self.fmt = fmt.sampleFormat()
            self.sink = QAudioSink(device, fmt, self.parent)
            self.sink.setBufferSize(int(self.rate * self.channels * self._bytes() * BUFFER))
            self._cache.clear()         # decoded for the old sample rate
            return True
        except Exception as e:
            print(f"[voices] no audio stream: {e}")
            self.sink = None
            return False

    def _bytes(self) -> int:
        return 4 if self.fmt == QAudioFormat.SampleFormat.Float else 2

    def _device_changed(self):
        """Headphones plugged in / Bluetooth: follow Windows' default output."""
        was = self.running
        self.release_all()
        if self.sink is not None:
            self.sink.stop()
            self.sink.deleteLater()
        self.ok = self._open()
        if was:
            self.running = False      # restarted by the next update()

    def _start(self):
        if self.sink is None:
            return
        if self.dev is None or self.sink.state() == QAudio.State.StoppedState:
            self.dev = self.sink.start()
        elif self.sink.state() == QAudio.State.SuspendedState:
            self.sink.resume()
        self.running = True

    def _buffered(self) -> float:
        if self.sink is None:
            return 0.0
        bps = self.rate * self.channels * self._bytes()
        return max(0, self.sink.bufferSize() - self.sink.bytesFree()) / bps

    # ---- clips
    def set_background(self, file: Optional[str], video_clips=(), volume: float = 0.0):
        """Play the music-only track under the video (None = no music)."""
        self.bg_volume = max(0.0, float(volume))
        key = (file, tuple((c.src_in, c.src_out, c.rate, round(c.start, 3))
                           for c in video_clips)) if file else None
        if key == self._bg_key:
            return
        self._bg_key = key
        self._bg = bg_pieces(file, video_clips) if file else []
        self.set_clips(self._source)
        self._off = DRIFT_TICKS

    def set_clips(self, clips):
        self._source = list(clips)
        src = sorted(self._source + self._bg + self._music, key=lambda c: c.start)
        self.clips = src if self.speed == 1.0 else [_Sped(c, self.speed) for c in src]
        self.starts = [c.start for c in self.clips]

    def set_speed(self, speed: float):
        """The video plays `speed` times faster: so does the voice (pitch kept)."""
        speed = max(0.5, min(2.0, float(speed or 1.0)))
        if abs(speed - self.speed) < 0.001:
            return
        self.speed = 1.0 if abs(speed - 1.0) < 0.001 else speed
        self.set_clips(self._source)
        if self.sink is not None and self.running:
            self.sink.reset()               # queued audio was made for the old speed
            self.dev = self.sink.start()
        self._off = DRIFT_TICKS             # jump to the playhead on the next update

    def set_music(self, clips):
        """The 🎵 Music track (Edit workspace)."""
        key = tuple((c.path, round(c.start, 3), round(c.src_in, 3), round(c.src_out, 3),
                     round(c.volume, 3), c.fade_in, c.fade_out) for c in clips or [])
        if key == getattr(self, "_music_key", None):
            return
        self._music_key = key
        self._music = music_pieces(clips)
        self.set_clips(self._source)
        self._off = DRIFT_TICKS

    def set_volume(self, v: float):
        self.volume = max(0.0, float(v))

    def _audio(self, clip) -> Optional[np.ndarray]:
        sped = isinstance(clip, _Sped)
        base = clip.orig if sped else clip
        key = f"{clip.path}|{self.speed:.3f}" if sped else clip.path
        data = self._cache.get(key)
        if data is not None:
            self._cache.move_to_end(key)
            return data
        try:
            from core.media import read_wav

            if isinstance(base, _BgPiece):
                data, sr = self._read_range(base.file, base.a, base.b)
            else:
                data, sr = read_wav(clip.path)
            if sr != self.rate and len(data):
                n = int(round(len(data) * self.rate / sr))
                data = np.interp(np.arange(n) * (sr / self.rate), np.arange(len(data)),
                                 data).astype(np.float32)
            if isinstance(base, _BgPiece) and abs(base.rate - 1.0) > 0.001:
                data = stretch(data, base.rate, self.rate)
            if sped:
                data = stretch(data, self.speed, self.rate)
        except Exception as e:
            print(f"[voices] cannot read {clip.path}: {e}")
            data = np.zeros(0, np.float32)
        self._cache[key] = data
        while len(self._cache) > CACHE_CLIPS:
            self._cache.popitem(last=False)
        return data

    @staticmethod
    def _read_range(path: str, a: float, b: float):
        """Seconds a..b of a wav as mono float32 (only that part is read)."""
        import wave

        with wave.open(path, "rb") as wf:
            sr, ch = wf.getframerate(), wf.getnchannels()
            n = wf.getnframes()
            i = max(0, min(n, int(round(a * sr))))
            wf.setpos(i)
            raw = wf.readframes(max(0, min(n, int(round(b * sr))) - i))
        data = np.frombuffer(raw, "<i2").astype(np.float32) / 32768.0
        if ch > 1:
            data = data.reshape(-1, ch).mean(axis=1)
        return data, sr

    def _gain(self, clip) -> float:
        try:
            from core.sync import clip_normalize_gain

            return clip_normalize_gain(getattr(clip, "orig", clip))
        except Exception:
            return 1.0

    def _preload(self, t: float):
        """Decode the next lines before they are needed (no hiccup)."""
        i = bisect.bisect_left(self.starts, t)
        for c in self.clips[max(0, i - 2):i + 4]:
            key = f"{c.path}|{self.speed:.3f}" if isinstance(c, _Sped) else c.path
            if key not in self._cache:
                self._audio(c)

    # ---- the player calls these
    def pause_all(self):
        if self.sink is not None and self.running:
            self.sink.suspend()
        self.running = False

    def release_all(self):
        if self.sink is not None:
            self.sink.reset()
            self.dev = None
            self.sink.stop()
        self.running = False

    def update(self, t: float, playing: bool, force: bool = False):
        t = t / self.speed                  # timeline time -> time as heard
        if not playing or self.sink is None:
            if self.running:
                self.pause_all()
            if force and self.sink is not None:
                self.sink.reset()           # a seek while paused: drop what is queued
                self.dev = None
            return
        if not self.running:
            self._start()
            self.pos = t + self._buffered()
        heard = self.pos - self._buffered()
        self._off = self._off + 1 if abs(heard - t) > DRIFT else 0
        if force or self._off >= DRIFT_TICKS or abs(heard - t) > 1.0:
            self._off = 0
            if force and self.sink is not None:
                self.sink.reset()           # seek: drop the old audio at once
                self.dev = self.sink.start()
            self.pos = t + self._buffered()
        self._preload(self.pos)
        if self.dev is None:
            return
        frame = self.channels * self._bytes()
        free = self.sink.bytesFree() // frame
        if free <= 0:
            return
        mono = mix_window(self.clips, self.starts, self.pos, free, self.rate, self._audio,
                          self.volume if self.voices_on else 0.0, self._gain, self.bg_volume,
                          self.volume if self.music_on else 0.0)
        if self.channels > 1:
            mono = np.repeat(mono[:, None], self.channels, axis=1).reshape(-1)
        if self.fmt == QAudioFormat.SampleFormat.Float:
            raw = mono.astype("<f4").tobytes()
        else:
            raw = (mono * 32767.0).astype("<i2").tobytes()
        written = self.dev.write(raw)
        if written and written > 0:
            self.pos += (written // frame) / self.rate
