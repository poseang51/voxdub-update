"""
icons.py - Line icons for the toolbar / track headers, drawn from inline SVG
(no image files to ship). Style: 24x24 grid, 2 px round strokes.
"""

from functools import lru_cache

from PySide6.QtCore import QByteArray, QRectF, QSize, Qt
from PySide6.QtGui import QIcon, QPainter, QPixmap
from PySide6.QtSvg import QSvgRenderer

from ui.theme import legacy as _t

# name -> SVG body (inside a 24x24 viewBox). {c} = colour.
_PATHS = {
    # 2.0: magnifier zoom icons for the timeline scale
    "zoom_in": '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'
               '<path d="M11 8v6"/><path d="M8 11h6"/>',
    "zoom_out": '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/><path d="M8 11h6"/>',
    "undo": '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
    "redo": '<path d="m15 14 5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/>',
    "trash": '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>'
             '<path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M10 11v6"/>'
             '<path d="M14 11v6"/>',
    "scissors": '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>'
                '<path d="M20 4 8.12 15.88"/><path d="M14.47 14.48 20 20"/>'
                '<path d="M8.12 8.12 12 12"/>',
    "magnet": '<path d="m6 15-4-4 6.75-6.77a7.79 7.79 0 0 1 11 11L13 22l-4-4 '
              '6.39-6.36a2.14 2.14 0 0 0-3-3L6 15"/><path d="m5 8 4 4"/><path d="m12 15 4 4"/>',
    "sliders": '<path d="M4 21v-7"/><path d="M4 10V3"/><path d="M12 21v-9"/><path d="M12 8V3"/>'
               '<path d="M20 21v-5"/><path d="M20 12V3"/><path d="M2 14h4"/>'
               '<path d="M10 8h4"/><path d="M18 16h4"/>',
    "text": '<path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/>',
    "prev": '<path d="M19 20 9 12l10-8z" fill="{c}"/><path d="M5 19V5"/>',
    "next": '<path d="m5 4 10 8-10 8z" fill="{c}"/><path d="M19 5v14"/>',
    "play": '<path d="m7 4 13 8-13 8z" fill="{c}"/>',
    "pause": '<rect x="6" y="4" width="4" height="16" rx="1" fill="{c}"/>'
             '<rect x="14" y="4" width="4" height="16" rx="1" fill="{c}"/>',
    "fit": '<path d="M8 3H5a2 2 0 0 0-2 2v3"/><path d="M21 8V5a2 2 0 0 0-2-2h-3"/>'
           '<path d="M3 16v3a2 2 0 0 0 2 2h3"/><path d="M16 21h3a2 2 0 0 0 2-2v-3"/>',
    "eye": '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
    "eye_off": '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>'
               '<circle cx="12" cy="12" r="3"/><path d="M3 3l18 18"/>',
    "volume": '<path d="M11 5 6 9H2v6h4l5 4z" fill="{c}"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/>'
              '<path d="M19 5a10 10 0 0 1 0 14"/>',
    "volume_off": '<path d="M11 5 6 9H2v6h4l5 4z" fill="{c}"/><path d="m22 9-6 6"/>'
                  '<path d="m16 9 6 6"/>',
    "film": '<rect x="2" y="3" width="20" height="18" rx="2"/><path d="M7 3v18"/>'
            '<path d="M17 3v18"/><path d="M2 8h5"/><path d="M2 16h5"/><path d="M17 8h5"/>'
            '<path d="M17 16h5"/>',
    "film_small": '<rect x="6" y="7" width="12" height="10" rx="1.5"/><path d="M9 7v10"/>'
                  '<path d="M15 7v10"/>',
    "layers": '<path d="m12 2 10 5-10 5L2 7z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/>',
    "subtitle": '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M6 12h4"/>'
                '<path d="M14 12h4"/><path d="M6 16h8"/><path d="M16 16h2"/>',
    "mic": '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>'
           '<path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3"/>',
    "music": '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/>'
             '<circle cx="18" cy="16" r="3"/>',
    "pencil": '<path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>',
    "crop": '<path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/>',
    "color": '<circle cx="12" cy="12" r="10"/><path d="M12 2a10 10 0 0 1 0 20z" fill="{c}"/>',
    "rotate": '<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>',
    "back": '<circle cx="12" cy="12" r="10"/><path d="m12 16-4-4 4-4"/><path d="m16 16-4-4 4-4"/>',
    "check": '<circle cx="12" cy="12" r="10"/><path d="m8 12 3 3 5-6"/>',
    "reset": '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
    "ratio": '<rect x="2" y="6" width="20" height="12" rx="2"/>'
             '<rect x="8" y="2" width="8" height="20" rx="1.5" stroke-dasharray="2.5 2"/>',
    "chevrons": '<path d="m6 17 5-5-5-5"/><path d="m13 17 5-5-5-5"/>',
    "play_small": '<path d="m7 4 13 8-13 8z" fill="{c}"/>',
    "export": '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/>'
              '<path d="M12 3v12"/>',
    "flip_h": '<path d="M12 3v18" stroke-dasharray="2.5 2"/><path d="M9 6 3 12l6 6z"/>'
              '<path d="m15 6 6 6-6 6z" fill="{c}"/>',
    "flip_v": '<path d="M3 12h18" stroke-dasharray="2.5 2"/><path d="M6 9l6-6 6 6z"/>'
              '<path d="m6 15 6 6 6-6z" fill="{c}"/>',
    "image": '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/>'
             '<path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
    "blur": '<path d="M12 2.7c-3 4-6 7.2-6 10.8a6 6 0 0 0 12 0c0-3.6-3-6.8-6-10.8z"/>'
            '<path d="M9 15h6" stroke-dasharray="1.5 1.5"/>',
}


def _svg(name: str, color: str) -> bytes:
    body = _PATHS[name].replace("{c}", color)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
            f'stroke="{color}" stroke-width="2" stroke-linecap="round" '
            f'stroke-linejoin="round">{body}</svg>').encode()


@lru_cache(maxsize=256)
def pixmap(name: str, size: int = 20, color: str = _t("#e8eaf0")) -> QPixmap:
    """Render an icon at size x size pixels (cached)."""
    scale = 2                                   # draw at 2x for crisp HiDPI
    pm = QPixmap(size * scale, size * scale)
    pm.fill(Qt.GlobalColor.transparent)
    renderer = QSvgRenderer(QByteArray(_svg(name, color)))
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    renderer.render(p, QRectF(0, 0, size * scale, size * scale))
    p.end()
    pm.setDevicePixelRatio(scale)
    return pm


def icon(name: str, size: int = 20, color: str = _t("#e8eaf0"),
         disabled: str = _t("#5b6070"), checked: str = "") -> QIcon:
    ic = QIcon()
    ic.addPixmap(pixmap(name, size, color), QIcon.Mode.Normal, QIcon.State.Off)
    ic.addPixmap(pixmap(name, size, disabled), QIcon.Mode.Disabled, QIcon.State.Off)
    if checked:
        ic.addPixmap(pixmap(name, size, checked), QIcon.Mode.Normal, QIcon.State.On)
    return ic


def icon_size(size: int = 20) -> QSize:
    return QSize(size, size)
