"""A "Voice style" drop-down that sets Voice speed + Slow the video together
(Natural, or Original VoxDub = how the first VoxDub PRO spoke)."""

from PySide6.QtWidgets import QComboBox

from core import sync

PLAIN_TIP = ("Edge / Azure: Piseth and Sreymom sound exactly like the first SARIKA VOXDUB PRO.\n"
             "No automatic pitch per character (Man 2 a little lower, Girl higher ...)\n"
             "and no automatic delivery (happy, sad, shout ...).\n"
             "A pitch or delivery you chose by hand is still used.\n"
             "Off: characters get their own pitch and lines follow the original emotion.\n"
             "Takes effect on the next 3 · Voice (or Auto Dub).")
TIP = ("Natural: a long line is sped up at most 1.1 × and that part of the video\n"
       "plays a little slower, so the voice is not rushed.\n\n"
       "Original VoxDub: the voice of the first SARIKA VOXDUB PRO - Edge / Azure\n"
       "speak up to +40 % faster to fit, then up to 1.5 ×; the video keeps its speed.\n\n"
       "Changing Voice speed or Slow the video by hand shows Custom.\n"
       "Takes effect on the next 3 · Voice (or Auto Dub).")


def make_voice_style_combo(spn_speed, chk_stretch) -> QComboBox:
    cmb = QComboBox()
    for key, label, _s, _st in sync.VOICE_STYLES:
        cmb.addItem(label, key)
    cmb.addItem("Custom", "custom")
    cmb.setToolTip(TIP)

    def follow(*_):
        key = sync.voice_style_of(spn_speed.value(), chk_stretch.isChecked())
        cmb.blockSignals(True)
        cmb.setCurrentIndex(max(0, cmb.findData(key)))
        cmb.blockSignals(False)

    def chosen(_i):
        key = cmb.currentData()
        if key == "custom":
            return
        speed, stretch = sync.voice_style_values(key)
        # setting the two controls saves them the usual way (their own signals)
        spn_speed.setValue(speed)
        chk_stretch.setChecked(stretch)
        follow()

    cmb.activated.connect(chosen)
    spn_speed.valueChanged.connect(follow)
    chk_stretch.toggled.connect(follow)
    cmb.follow = follow
    follow()
    return cmb
