"""
reframe_dialog.py - 🔄 Reframe videos: turn, mirror, change the shape.

    ┌ videos ───────────┐┌ Before ───────┐┌ After ────────┐
    │ ep01.mp4          ││               ││               │
    │ ep02.mp4          ││               ││               │
    └───────────────────┘└───────────────┘└───────────────┘
    Turn   [No turn] [↻ 90° right] [180°] [↺ 90° left]
    Mirror [↔ left / right] [↕ upside down]
    Shape  [Keep ▾]   Fill [Blurred background ▾]
    [▶ Reframe 2 videos]                       Open in Dub

Every setting is used for every video in the list; each becomes
<name>_reframe.mp4 (the original is not changed).
"""

import os
import tempfile
import threading
from typing import List, Optional

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QButtonGroup, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox,
    QProgressBar, QPushButton, QVBoxLayout, QWidget,
)

from core import reframe
from core.media import VIDEO_EXT, VIDEO_FILTER, get_media_info
from ui.workers import TaskWorker

TURN_TEXT = {0: "No turn", 90: "↻  90° right", 180: "⟳  180°", 270: "↺  90° left"}
PREVIEW = 360


def _shape_word(w: int, h: int) -> str:
    if not w or not h:
        return ""
    r = w / float(h)
    return "landscape" if r > 1.05 else "vertical" if r < 0.95 else "square"


class _Previewer(QObject):
    """Makes the Before / After pictures in a thread (no freeze)."""
    ready = Signal(int, str, str)          # ticket, before png, after png

    def __init__(self):
        super().__init__()
        self.ticket = 0
        self.folder = tempfile.mkdtemp(prefix="vxd_reframe_prev_")

    def make(self, src: str, at: float, **kw):
        self.ticket += 1
        t = self.ticket

        def run():
            before = os.path.join(self.folder, f"b{t}.png")
            after = os.path.join(self.folder, f"a{t}.png")
            try:
                reframe.preview_frame(src, at, before, size=PREVIEW)
                reframe.preview_frame(src, at, after, size=PREVIEW, **kw)
            except Exception:
                pass
            self.ready.emit(t, before, after)

        threading.Thread(target=run, daemon=True).start()


class ReframeDialog(QDialog):
    openRequested = Signal(str, str)        # workspace ("dub" / "edit"), video

    def __init__(self, parent=None, paths: Optional[List[str]] = None):
        super().__init__(parent)
        self.setWindowTitle("SARIKA VOXDUB PRO – Reframe videos")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(1080, 720)
        self.setAcceptDrops(True)
        self.worker: Optional[TaskWorker] = None
        self.results: List[str] = []
        self._info = {}
        self._prev = _Previewer()
        self._prev.ready.connect(self._show_preview)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(250)
        self._timer.timeout.connect(self._make_preview)
        self._build()
        if paths:
            self.add_videos(paths)
        self._changed()

    # ------------------------------------------------------------------ #
    def _build(self):
        head = QLabel("🔄  Reframe videos")
        head.setObjectName("HomeH2")
        sub = QLabel("For videos that are the wrong way round: turn them, mirror them back, or "
                     "change the shape (16:9 ↔ 9:16). The original is not changed – you get a "
                     "new “…_reframe.mp4”.")
        sub.setObjectName("MutedLabel")
        sub.setWordWrap(True)

        # ---- the videos
        self.lst = QListWidget()
        self.lst.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.lst.currentRowChanged.connect(lambda *_: self._changed())
        b_add = QPushButton("＋ Videos…")
        b_add.clicked.connect(self._browse)
        b_dir = QPushButton("📁 Folder…")
        b_dir.clicked.connect(self._browse_folder)
        b_rm = QPushButton("− Remove")
        b_rm.clicked.connect(self._remove)
        lb = QHBoxLayout()
        for b in (b_add, b_dir, b_rm):
            lb.addWidget(b)
        left = QVBoxLayout()
        left.addWidget(QLabel("Videos (drop them here)"))
        left.addWidget(self.lst, 1)
        left.addLayout(lb)
        lw = QWidget()
        lw.setLayout(left)
        lw.setFixedWidth(300)

        # ---- before / after
        self.pic_before, self.pic_after = QLabel(), QLabel()
        self.lb_before, self.lb_after = QLabel("Before"), QLabel("After")
        pics = QGridLayout()
        for col, (pic, cap) in enumerate(((self.pic_before, self.lb_before),
                                          (self.pic_after, self.lb_after))):
            pic.setObjectName("HomeThumb")
            pic.setAlignment(Qt.AlignmentFlag.AlignCenter)
            pic.setMinimumSize(PREVIEW, PREVIEW)
            cap.setObjectName("HomeBoxTitle")
            pics.addWidget(cap, 0, col)
            pics.addWidget(pic, 1, col)

        # ---- settings
        box = QFrame()
        box.setObjectName("HomeBox")
        g = QGridLayout(box)
        g.setContentsMargins(16, 14, 16, 14)
        g.setHorizontalSpacing(12)
        g.addWidget(QLabel("<b>Turn</b>"), 0, 0)
        self.turns = QButtonGroup(self)
        trow = QHBoxLayout()
        for t in reframe.TURNS:
            b = QPushButton(TURN_TEXT[t])
            b.setCheckable(True)
            b.setObjectName("HomeGhost")
            b.setChecked(t == 0)
            self.turns.addButton(b, t)
            trow.addWidget(b)
        trow.addStretch(1)
        self.turns.idClicked.connect(lambda *_: self._changed())
        g.addLayout(trow, 0, 1)
        g.addWidget(QLabel("<b>Mirror</b>"), 1, 0)
        self.chk_h = QCheckBox("↔  Mirror left / right (writing back to normal)")
        self.chk_v = QCheckBox("↕  Upside down")
        mrow = QHBoxLayout()
        mrow.addWidget(self.chk_h)
        mrow.addWidget(self.chk_v)
        mrow.addStretch(1)
        for c in (self.chk_h, self.chk_v):
            c.toggled.connect(lambda *_: self._changed())
        g.addLayout(mrow, 1, 1)
        g.addWidget(QLabel("<b>Shape</b>"), 2, 0)
        self.cmb_shape = QComboBox()
        for k, (name, _w, _h) in reframe.SHAPES.items():
            self.cmb_shape.addItem(name, k)
        self.cmb_fill = QComboBox()
        for k, name in reframe.FILLS.items():
            self.cmb_fill.addItem(name, k)
        self.lb_fill = QLabel("Fill")
        srow = QHBoxLayout()
        srow.addWidget(self.cmb_shape)
        srow.addSpacing(14)
        srow.addWidget(self.lb_fill)
        srow.addWidget(self.cmb_fill)
        srow.addStretch(1)
        for c in (self.cmb_shape, self.cmb_fill):
            c.currentIndexChanged.connect(lambda *_: self._changed())
        g.addLayout(srow, 2, 1)
        g.addWidget(QLabel("<b>Save in</b>"), 3, 0)
        self.ed_out = QLineEdit()
        self.ed_out.setPlaceholderText("The same folder as each video")
        b_out = QPushButton("…")
        b_out.clicked.connect(self._choose_out)
        orow = QHBoxLayout()
        orow.addWidget(self.ed_out, 1)
        orow.addWidget(b_out)
        g.addLayout(orow, 3, 1)
        self.lb_size = QLabel("")
        self.lb_size.setObjectName("MutedLabel")
        g.addWidget(self.lb_size, 4, 1)

        # ---- run
        self.bar = QProgressBar()
        self.bar.setVisible(False)
        self.lb_status = QLabel("")
        self.lb_status.setObjectName("MutedLabel")
        self.lb_status.setWordWrap(True)
        self.btn_go = QPushButton("▶  Reframe")
        self.btn_go.setObjectName("HomeCta")
        self.btn_go.setMinimumHeight(40)
        self.btn_go.clicked.connect(self._start)
        self.btn_stop = QPushButton("■ Cancel")
        self.btn_stop.setObjectName("DangerButton")
        self.btn_stop.setVisible(False)
        self.btn_stop.clicked.connect(lambda: self.worker and self.worker.stop())
        self.btn_folder = QPushButton("📂 Open folder")
        self.btn_folder.setVisible(False)
        self.btn_folder.clicked.connect(self._open_folder)
        self.btn_dub = QPushButton("🎙️ Open in Dub")
        self.btn_dub.setVisible(False)
        self.btn_dub.clicked.connect(lambda: self._open_result("dub"))
        self.btn_edit = QPushButton("✂️ Open in Edit")
        self.btn_edit.setVisible(False)
        self.btn_edit.clicked.connect(lambda: self._open_result("edit"))
        brow = QHBoxLayout()
        brow.addWidget(self.btn_go)
        brow.addWidget(self.btn_stop)
        brow.addWidget(self.bar, 1)
        brow.addWidget(self.btn_folder)
        brow.addWidget(self.btn_edit)
        brow.addWidget(self.btn_dub)

        right = QVBoxLayout()
        right.addLayout(pics, 1)
        right.addWidget(box)
        top = QHBoxLayout()
        top.addWidget(lw)
        top.addLayout(right, 1)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.addWidget(head)
        lay.addWidget(sub)
        lay.addLayout(top, 1)
        lay.addLayout(brow)
        lay.addWidget(self.lb_status)

    # ------------------------------------------------------------------ #
    def settings(self) -> dict:
        return {"turn": self.turns.checkedId() if self.turns.checkedId() >= 0 else 0,
                "flip_h": self.chk_h.isChecked(), "flip_v": self.chk_v.isChecked(),
                "shape": self.cmb_shape.currentData(), "fill": self.cmb_fill.currentData()}

    def videos(self) -> List[str]:
        return [self.lst.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.lst.count())]

    def add_videos(self, paths: List[str]):
        have = set(self.videos())
        found: List[str] = []
        for p in paths:
            if os.path.isdir(p):
                found += sorted(os.path.join(p, f) for f in os.listdir(p)
                                if f.lower().endswith(VIDEO_EXT))
            elif p.lower().endswith(VIDEO_EXT):
                found.append(p)
        for p in found:
            if p in have or not os.path.isfile(p):
                continue
            have.add(p)
            it = QListWidgetItem(os.path.basename(p))
            it.setData(Qt.ItemDataRole.UserRole, p)
            it.setToolTip(p)
            self.lst.addItem(it)
        if self.lst.currentRow() < 0 and self.lst.count():
            self.lst.setCurrentRow(0)
        self._changed()

    def _browse(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Videos to reframe", "", VIDEO_FILTER)
        self.add_videos(files)

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos")
        if d:
            self.add_videos([d])

    def _remove(self):
        for it in self.lst.selectedItems():
            self.lst.takeItem(self.lst.row(it))
        self._changed()

    def _choose_out(self):
        d = QFileDialog.getExistingDirectory(self, "Save the reframed videos in")
        if d:
            self.ed_out.setText(d)

    def dragEnterEvent(self, ev):
        if ev.mimeData().hasUrls():
            ev.acceptProposedAction()

    def dropEvent(self, ev):
        self.add_videos([os.path.normpath(u.toLocalFile()) for u in ev.mimeData().urls() if u.isLocalFile()])

    # ------------------------------------------------------------------ #
    def _current(self) -> str:
        it = self.lst.currentItem() or (self.lst.item(0) if self.lst.count() else None)
        return it.data(Qt.ItemDataRole.UserRole) if it else ""

    def _media(self, path: str):
        if path not in self._info:
            try:
                self._info[path] = get_media_info(path)
            except Exception:
                self._info[path] = None
        return self._info[path]

    def _changed(self):
        s = self.settings()
        keep = s["shape"] == "keep"
        self.cmb_fill.setEnabled(not keep)
        self.lb_fill.setEnabled(not keep)
        n = self.lst.count()
        same = reframe.is_identity(s["turn"], s["flip_h"], s["flip_v"], s["shape"])
        self.btn_go.setText(f"▶  Reframe {n} video" + ("s" if n != 1 else ""))
        self.btn_go.setEnabled(n > 0 and not same and self.worker is None)
        src = self._current()
        info = self._media(src) if src else None
        if info and info.width:
            w, h = reframe.out_size(info.width, info.height, s["turn"], s["shape"])
            self.lb_before.setText(f"Before · {info.width}×{info.height} "
                                   f"{_shape_word(info.width, info.height)}")
            self.lb_after.setText(f"After · {w}×{h} {_shape_word(w, h)}")
            self.lb_size.setText("Nothing to change yet – choose a turn, a mirror or a shape."
                                 if same else f"Every video in the list gets these settings "
                                              f"({n}).")
            self._timer.start()
        else:
            self.lb_before.setText("Before")
            self.lb_after.setText("After")
            self.lb_size.setText("Add videos – or drop them on this window.")
            self.pic_before.clear()
            self.pic_after.clear()

    def _make_preview(self):
        src = self._current()
        info = self._media(src) if src else None
        if info and info.width:
            self._prev.make(src, min(info.duration * 0.3, 30.0), **self.settings())

    def _show_preview(self, ticket: int, before: str, after: str):
        if ticket != self._prev.ticket:
            return              # an older picture: the settings changed since
        for pic, path in ((self.pic_before, before), (self.pic_after, after)):
            pm = QPixmap(path) if path and os.path.isfile(path) else QPixmap()
            if pm.isNull():
                pic.setText("(no picture)")
            else:
                pic.setPixmap(pm.scaled(PREVIEW, PREVIEW, Qt.AspectRatioMode.KeepAspectRatio,
                                        Qt.TransformationMode.SmoothTransformation))

    # ------------------------------------------------------------------ #
    def _start(self):
        videos, s = self.videos(), self.settings()
        folder = self.ed_out.text().strip()
        if not videos:
            return
        jobs = [(v, reframe.output_name(v, folder)) for v in videos]

        def job(progress, should_stop):
            done = []
            for i, (src, out) in enumerate(jobs):
                if should_stop():
                    raise InterruptedError("Cancelled")
                name = os.path.basename(src)

                def prog(p, m, i=i, name=name):
                    progress((100 * i + p) // len(jobs), f"{i + 1}/{len(jobs)}  {name}: {m}")
                done.append(reframe.reframe(src, out, progress=prog, should_stop=should_stop,
                                            **s))
            return done

        self.results = []
        for b in (self.btn_folder, self.btn_dub, self.btn_edit):
            b.setVisible(False)
        self.worker = TaskWorker(job, "Reframe", self)
        self.worker.progress.connect(lambda p, m: (self.bar.setValue(p),
                                                   self.lb_status.setText(m)))
        self.worker.done.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.bar.setValue(0)
        self.bar.setVisible(True)
        self.btn_stop.setVisible(True)
        self.btn_go.setEnabled(False)
        self.worker.start()

    def _finish(self):
        self.worker = None
        self.btn_stop.setVisible(False)
        self._changed()

    def _done(self, outs: list):
        self._finish()
        self.results = list(outs or [])
        self.bar.setValue(100)
        self.lb_status.setText(f"✓ {len(self.results)} video(s) reframed:  "
                               + ", ".join(os.path.basename(o) for o in self.results[:4])
                               + (" …" if len(self.results) > 4 else ""))
        self.btn_folder.setVisible(bool(self.results))
        one = len(self.results) == 1
        self.btn_dub.setVisible(one)
        self.btn_edit.setVisible(one)

    def _failed(self, msg: str):
        self._finish()
        self.bar.setVisible(False)
        self.lb_status.setText("")
        if "Cancelled" not in msg:
            QMessageBox.warning(self, "Reframe", msg)

    def _open_folder(self):
        if self.results:
            from ui.main_window import open_path

            open_path(os.path.dirname(self.results[0]))

    def _open_result(self, kind: str):
        if self.results:
            self.openRequested.emit(kind, self.results[0])
            self.close()

    def closeEvent(self, ev):
        if self.worker is not None:
            self.worker.stop()
            self.worker.wait(5000)
        super().closeEvent(ev)
