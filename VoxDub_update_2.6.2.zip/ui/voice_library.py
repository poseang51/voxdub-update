"""
voice_library.py - 📚 Voice Library window (VoxCPM2 voices to clone), 2.4.

Cards with picture, name, category and man / woman / child; ▶ Preview plays
the recording. The selected voice can be:
  * used as the default man / woman / child / elder voice (Settings › AI
    engines › Voice clone) - mode "settings";
  * chosen for one character (👥 Characters › Clone from) - mode "pick".
"+ Add voice…" puts a recording into VoxDub's own library. On the owner's
PC the voices of SARIKA VOICE are listed too (read only).
"""

import os
from typing import List, Optional

from PySide6.QtCore import QSize, Qt, QUrl, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QComboBox, QDialog, QFileDialog, QFormLayout, QFrame, QHBoxLayout, QInputDialog, QLabel,
    QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPlainTextEdit, QPushButton,
    QVBoxLayout,
)

from core import voice_library as vl

CARD = QSize(150, 150)
COLORS = {"male": "#3b6fd8", "female": "#c2417e", "child": "#d98a1c"}
SLOTS = [("male", "♂ Man voice"), ("female", "♀ Woman voice"), ("child", "Child"),
         ("elder_male", "Elder man"), ("elder_female", "Elder woman")]


def card_icon(v: vl.Voice) -> QIcon:
    pm = QPixmap(CARD)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    src = QPixmap(v.avatar) if v.avatar else QPixmap()
    if not src.isNull():
        src = src.scaled(CARD, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                         Qt.TransformationMode.SmoothTransformation)
        x, y = (src.width() - CARD.width()) // 2, (src.height() - CARD.height()) // 2
        p.drawPixmap(0, 0, src, x, y, CARD.width(), CARD.height())
    else:
        p.setBrush(QBrush(QColor(COLORS.get(v.gender, "#555"))))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(0, 0, CARD.width(), CARD.height(), 14, 14)
        f = QFont()
        f.setPixelSize(64)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(pm.rect(), Qt.AlignmentFlag.AlignCenter, (v.name or "?")[:1].upper())
    if v.source == "sarika":                                   # small "SV" badge
        p.setBrush(QBrush(QColor(124, 92, 255, 230)))
        p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(CARD.width() - 34, 6, 28, 18, 5, 5)
        f = QFont()
        f.setPixelSize(11)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("white"))
        p.drawText(CARD.width() - 34, 6, 28, 18, Qt.AlignmentFlag.AlignCenter, "SV")
    p.end()
    return QIcon(pm)


class VoiceLibraryDialog(QDialog):
    defaultChanged = Signal(str)          # slot (male / female / ...) was set

    def __init__(self, parent=None, mode: str = "settings", who: str = ""):
        super().__init__(parent)
        self.mode, self.chosen = mode, None
        self.setWindowTitle("📚 Voice Library – VoxCPM2 voices" +
                            (f" for {who}" if who else ""))
        self.resize(1080, 680)
        self._voices: List[vl.Voice] = []
        self.player = None

        # ---- top: search / category / add
        self.ed_search = QLineEdit()
        self.ed_search.setPlaceholderText("Search name, category…")
        self.ed_search.textChanged.connect(self._fill)
        self.cmb_cat = QComboBox()
        self.cmb_cat.currentIndexChanged.connect(self._fill)
        self.cmb_gender = QComboBox()
        self.cmb_gender.addItem("Everyone", "")
        for k, label in vl.GENDERS.items():
            self.cmb_gender.addItem(label, k)
        self.cmb_gender.currentIndexChanged.connect(self._fill)
        b_add = QPushButton("+ Add voice…")
        b_add.setObjectName("AccentButton")
        b_add.setToolTip("A clean 5–30 s recording of one voice (wav, mp3, m4a …)")
        b_add.clicked.connect(self.add_voice)
        top = QHBoxLayout()
        top.addWidget(self.ed_search, 2)
        top.addWidget(self.cmb_cat, 1)
        top.addWidget(self.cmb_gender)
        top.addWidget(b_add)

        # ---- cards
        self.grid = QListWidget()
        self.grid.setViewMode(QListWidget.ViewMode.IconMode)
        self.grid.setIconSize(CARD)
        self.grid.setGridSize(QSize(CARD.width() + 24, CARD.height() + 58))
        self.grid.setResizeMode(QListWidget.ResizeMode.Adjust)
        self.grid.setMovement(QListWidget.Movement.Static)
        self.grid.setWordWrap(True)
        self.grid.setSpacing(8)
        self.grid.currentItemChanged.connect(self._show)
        self.grid.itemDoubleClicked.connect(lambda *_: self.preview())

        # ---- details of the selected voice
        side = QFrame()
        side.setObjectName("DashPanel")
        side.setFixedWidth(330)
        sl = QVBoxLayout(side)
        self.lb_name = QLabel("Choose a voice")
        self.lb_name.setStyleSheet("font-size: 15px; font-weight: 700;")
        self.lb_name.setWordWrap(True)
        self.lb_info = QLabel("")
        self.lb_info.setObjectName("MutedLabel")
        self.lb_info.setWordWrap(True)
        self.btn_play = QPushButton("▶  Preview")
        self.btn_play.clicked.connect(self.preview)
        sl.addWidget(self.lb_name)
        sl.addWidget(self.lb_info)
        sl.addWidget(self.btn_play)
        said = QLabel("Said in the recording (makes the clone better):")
        said.setWordWrap(True)
        sl.addWidget(said)
        self.ed_text = QPlainTextEdit()
        self.ed_text.setMaximumHeight(90)
        self.ed_text.setPlaceholderText("Type what is said – or 🎧 let Whisper hear it")
        sl.addWidget(self.ed_text)
        row = QHBoxLayout()
        self.btn_hear = QPushButton("🎧 Hear it")
        self.btn_hear.setToolTip("Whisper listens to the recording and writes what is said")
        self.btn_hear.clicked.connect(self.hear)
        self.btn_save_text = QPushButton("💾 Keep text")
        self.btn_save_text.clicked.connect(self.keep_text)
        row.addWidget(self.btn_hear)
        row.addWidget(self.btn_save_text)
        sl.addLayout(row)
        sl.addSpacing(8)
        self.use_buttons = {}
        if mode == "pick":
            b = QPushButton("✓  Use this voice")
            b.setObjectName("AccentButton")
            b.setMinimumHeight(38)
            b.clicked.connect(self._pick)
            sl.addWidget(b)
            self.use_buttons["pick"] = b
        else:
            head = QLabel("Use as the default voice for:")
            head.setObjectName("SideHead")
            sl.addWidget(head)
            for slot, label in SLOTS:
                b = QPushButton(label)
                b.clicked.connect(lambda _=False, s=slot: self.use_as(s))
                sl.addWidget(b)
                self.use_buttons[slot] = b
        sl.addStretch(1)
        self.btn_rename = QPushButton("✎ Rename / category")
        self.btn_rename.clicked.connect(self.rename)
        self.btn_delete = QPushButton("🗑 Delete")
        self.btn_delete.clicked.connect(self.delete)
        row = QHBoxLayout()
        row.addWidget(self.btn_rename)
        row.addWidget(self.btn_delete)
        sl.addLayout(row)
        self.lb_state = QLabel("")
        self.lb_state.setObjectName("MutedLabel")
        self.lb_state.setWordWrap(True)
        sl.addWidget(self.lb_state)

        body = QHBoxLayout()
        body.addWidget(self.grid, 1)
        body.addWidget(side)
        close = QPushButton("Close")
        close.clicked.connect(self.reject)
        bottom = QHBoxLayout()
        note = QLabel("SV = from SARIKA VOICE (read only, this PC only). Your own voices: "
                      "+ Add voice.")
        note.setObjectName("MutedLabel")
        bottom.addWidget(note, 1)
        bottom.addWidget(close)
        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addLayout(body, 1)
        lay.addLayout(bottom)
        self.reload()

    # ------------------------------------------------------------------ #
    def reload(self, select: str = ""):
        self._voices = vl.all_voices()
        cats = sorted({v.category for v in self._voices} | set(vl.CATEGORIES))
        cur = self.cmb_cat.currentData()
        self.cmb_cat.blockSignals(True)
        self.cmb_cat.clear()
        self.cmb_cat.addItem("All categories", "")
        for c in cats:
            self.cmb_cat.addItem(c, c)
        self.cmb_cat.setCurrentIndex(max(0, self.cmb_cat.findData(cur)))
        self.cmb_cat.blockSignals(False)
        self._fill(select=select)

    def _fill(self, *_, select: str = ""):
        q = self.ed_search.text().strip().lower()
        cat, gender = self.cmb_cat.currentData() or "", self.cmb_gender.currentData() or ""
        self.grid.clear()
        for v in self._voices:
            if cat and v.category != cat or gender and v.gender != gender:
                continue
            if q and q not in f"{v.name} {v.category}".lower():
                continue
            it = QListWidgetItem(card_icon(v),
                                 f"{v.name}\n{v.category} · {vl.GENDERS.get(v.gender, '')}")
            it.setData(Qt.ItemDataRole.UserRole, v.id)
            it.setToolTip(v.file)
            self.grid.addItem(it)
            if select and v.id == select:
                self.grid.setCurrentItem(it)
        if self.grid.currentItem() is None and self.grid.count():
            self.grid.setCurrentRow(0)
        self._show()

    def current(self) -> Optional[vl.Voice]:
        it = self.grid.currentItem()
        vid = it.data(Qt.ItemDataRole.UserRole) if it else ""
        return next((v for v in self._voices if v.id == vid), None)

    def _show(self, *_):
        v = self.current()
        on = v is not None
        for b in list(self.use_buttons.values()) + [self.btn_play, self.btn_hear,
                                                    self.btn_save_text]:
            b.setEnabled(on)
        self.btn_rename.setEnabled(on and v.editable)
        self.btn_delete.setEnabled(on and v.editable)
        if not on:
            self.lb_name.setText("No voices yet – + Add voice…")
            self.lb_info.setText("")
            self.ed_text.setPlainText("")
            return
        src = "SARIKA VOICE" if v.source == "sarika" else "VoxDub library"
        secs = f" · {v.seconds:.0f} s" if v.seconds else ""
        self.lb_name.setText(v.name)
        self.lb_info.setText(f"{v.category} · {vl.GENDERS.get(v.gender, v.gender)}{secs}\n"
                             f"{src}")
        self.ed_text.setPlainText(v.text or vl.text_for(v.file))

    # ------------------------------------------------------------------ #
    def preview(self):
        v = self.current()
        if v is None:
            return
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
        except ImportError:
            return
        if self.player is None:
            self.player = QMediaPlayer(self)
            self.audio = QAudioOutput(self)
            self.player.setAudioOutput(self.audio)
        self.player.stop()
        self.player.setSource(QUrl.fromLocalFile(v.file))
        self.player.play()

    def keep_text(self):
        v = self.current()
        if v is not None:
            vl.set_text(v.file, self.ed_text.toPlainText())
            v.text = self.ed_text.toPlainText().strip()
            self.lb_state.setText("✓ Text kept")

    def hear(self):
        v = self.current()
        if v is None:
            return
        from ui.workers import TaskWorker

        self.btn_hear.setEnabled(False)
        self.lb_state.setText("🎧 Whisper is listening…")
        def job(prog, stop):
            try:
                return vl.hear_text(v, prog)
            except vl.NotKhmer:
                return None                     # (not kept)

        w = TaskWorker(job, "Hear", self)

        def done(text):
            self.btn_hear.setEnabled(True)
            if text is None:
                self.lb_state.setText("Not heard as Khmer – please type what is said, "
                                      "then 💾 Keep text")
                return
            if self.current() is v:
                self.ed_text.setPlainText(text)
            self.lb_state.setText("✓ Heard and kept" if text else "Nothing was heard")

        def failed(err):
            self.btn_hear.setEnabled(True)
            self.lb_state.setText(f"Could not hear it: {err}")

        w.done.connect(done)
        w.failed.connect(failed)
        self._hear_worker = w
        w.start()

    def use_as(self, slot: str):
        v = self.current()
        if v is None:
            return
        self.keep_text()
        vl.use_as_default(v, slot)
        label = dict(SLOTS).get(slot, slot)
        self.lb_state.setText(f"✓ “{v.name}” is now the {label.lower()}")
        self.defaultChanged.emit(slot)

    def _pick(self):
        v = self.current()
        if v is None:
            return
        self.keep_text()
        self.chosen = v
        self.accept()

    def add_voice(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Add a voice – a clean 5–30 s recording", "",
            "Audio (" + " ".join("*" + e for e in vl.AUDIO_EXT) + ");;All files (*)")
        if not path:
            return
        name, ok = QInputDialog.getText(self, "Add voice", "Name of the voice:",
                                        text=os.path.splitext(os.path.basename(path))[0])
        if not ok:
            return
        gender, ok = QInputDialog.getItem(self, "Add voice", "Man / woman / child:",
                                          list(vl.GENDERS.values()), 0, False)
        if not ok:
            return
        g = next(k for k, lab in vl.GENDERS.items() if lab == gender)
        cat, ok = QInputDialog.getItem(self, "Add voice", "Category:", vl.CATEGORIES, 0, True)
        if not ok:
            return
        try:
            v = vl.add_voice(path, name, g, cat)
        except Exception as e:
            QMessageBox.warning(self, "Add voice", f"Could not add it:\n{e}")
            return
        self.reload(select=v.id)
        self.lb_state.setText("✓ Added – 🎧 Hear it fills in what is said")

    def rename(self):
        v = self.current()
        if v is None or not v.editable:
            return
        name, ok = QInputDialog.getText(self, "Rename", "Name:", text=v.name)
        if not ok or not name.strip():
            return
        cats = vl.CATEGORIES if v.category in vl.CATEGORIES else [v.category] + vl.CATEGORIES
        cat, ok = QInputDialog.getItem(self, "Category", "Category:", cats,
                                       max(0, cats.index(v.category)), True)
        if not ok:
            return
        vl.update_voice(v.id, name=name.strip(), category=cat)
        self.reload(select=v.id)

    def delete(self):
        v = self.current()
        if v is None or not v.editable:
            return
        if QMessageBox.question(self, "Delete voice", f"Delete “{v.name}” from the library?") \
                != QMessageBox.StandardButton.Yes:
            return
        if self.player is not None:
            self.player.stop()
            self.player.setSource(QUrl())
        vl.delete_voice(v.id)
        self.reload()

    def done(self, r):
        if self.player is not None:
            self.player.stop()
        super().done(r)
