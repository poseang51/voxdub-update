"""
batch_preview.py - The video preview on the left of the Batch queue (2.3).

Click a row: its frame shows at once (no waiting). ▶ plays it, with sound.
When the video is dubbed / exported, "Original | Dubbed" switches between the
source video and the finished one, so a change can be checked right away.

The media player is made only on the first ▶ (160 rows clicked through must
not open 160 players), and it is stopped when the window closes.
"""

import os
from typing import Optional

from PySide6.QtCore import QSize, Qt, QUrl
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QButtonGroup, QHBoxLayout, QLabel, QPushButton, QSlider, QStackedWidget, QVBoxLayout,
    QWidget,
)


def _fmt(ms: int) -> str:
    s = max(0, int(ms // 1000))
    return f"{s // 60:02d}:{s % 60:02d}"


class BatchPreview(QWidget):
    def __init__(self, thumb_for, parent=None):
        """thumb_for(video_path) -> path of a still frame ("" while it is made)."""
        super().__init__(parent)
        self.thumb_for = thumb_for
        self.source = ""            # the original video
        self.output = ""            # the dubbed / exported video ("" = not yet)
        self.player = None
        self.audio = None
        self._dragging = False
        self.setMinimumWidth(240)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(6)
        head = QLabel("Preview (as exported)")
        head.setToolTip("The picture is how the video will look when exported with the "
                        "queue's tools\n(logo, brand text, hidden subtitles, crop, colour …).\n"
                        "▶ plays the video itself.")
        head.setStyleSheet("font-weight: 600; font-size: 15px;")
        lay.addWidget(head)
        self.lb_name = QLabel("Click a video in the queue")
        self.lb_name.setObjectName("MutedLabel")
        self.lb_name.setWordWrap(True)
        lay.addWidget(self.lb_name)

        self.lb_wait = QLabel("⏳ Making the export look… (the plain frame meanwhile)")
        self.lb_wait.setObjectName("MutedLabel")
        self.lb_wait.setVisible(False)
        lay.addWidget(self.lb_wait)

        self.stack = QStackedWidget()
        self.stack.setMinimumHeight(220)
        self.stack.setStyleSheet("background: #05070a; border-radius: 8px;")
        self.poster = QLabel("🎬")
        self.poster.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.poster.setStyleSheet("color: #5b6575; font-size: 40px;")
        self.poster.setCursor(Qt.CursorShape.PointingHandCursor)
        self.poster.setToolTip("Click to play")
        self.poster.mousePressEvent = lambda e: self.toggle()     # click the picture: ▶
        self.stack.addWidget(self.poster)
        self.video_box = QWidget()
        self.video_lay = QVBoxLayout(self.video_box)
        self.video_lay.setContentsMargins(0, 0, 0, 0)
        self.stack.addWidget(self.video_box)
        lay.addWidget(self.stack, 1)

        # Original | Dubbed
        row = QHBoxLayout()
        self.btn_orig = QPushButton("Original")
        self.btn_dub = QPushButton("Dubbed")
        self.which = QButtonGroup(self)
        for b in (self.btn_orig, self.btn_dub):
            b.setCheckable(True)
            self.which.addButton(b)
            row.addWidget(b)
        self.btn_orig.setChecked(True)
        self.btn_orig.toggled.connect(lambda on: on and self._switch())
        self.btn_dub.toggled.connect(lambda on: on and self._switch())
        lay.addLayout(row)

        ctl = QHBoxLayout()
        self.btn_play = QPushButton("▶  Play")
        self.btn_play.setToolTip("Play this video with its sound (or click the picture)")
        self.btn_play.setMinimumWidth(84)
        self.btn_play.clicked.connect(self.toggle)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.sliderPressed.connect(lambda: setattr(self, "_dragging", True))
        self.slider.sliderReleased.connect(self._seek)
        self.lb_time = QLabel("00:00 / 00:00")
        self.lb_time.setObjectName("MutedLabel")
        ctl.addWidget(self.btn_play)
        ctl.addWidget(self.slider, 1)
        ctl.addWidget(self.lb_time)
        lay.addLayout(ctl)

        self.lb_info = QLabel("")
        self.lb_info.setObjectName("MutedLabel")
        self.lb_info.setWordWrap(True)
        lay.addWidget(self.lb_info)
        self._enable(False)

    # ------------------------------------------------------------------ #
    def _enable(self, on: bool):
        for w in (self.btn_play, self.slider, self.btn_orig):
            w.setEnabled(on)
        self.btn_dub.setEnabled(on and bool(self.output))

    def current_path(self) -> str:
        return self.output if (self.btn_dub.isChecked() and self.output) else self.source

    def set_item(self, source: str, output: str = "", info: str = ""):
        """Show this queue row (the frame at once; ▶ plays it)."""
        output = output if output and os.path.isfile(output) else ""
        same = source == self.source
        self.source, self.output = source, output
        self.lb_name.setText(os.path.basename(source) if source else "Click a video in the queue")
        self.lb_info.setText(info)
        if not same or not output:
            self.btn_orig.setChecked(True)
        self._enable(bool(source))
        if not same:
            self.stop()
            self._show_poster()

    def refresh_poster(self, source: str):
        """The frame of this video is ready (made in the background)."""
        if source == self.source and self.stack.currentIndex() == 0:
            self._show_poster()

    def _show_poster(self):
        self.stack.setCurrentIndex(0)
        path = self.thumb_for(self.source) if self.source else ""
        waiting = False
        if isinstance(path, tuple):         # (frame, the export look still being made)
            path, waiting = path
        self.lb_wait.setVisible(bool(waiting and self.source))
        pix = QPixmap(path) if path and os.path.isfile(path) else QPixmap()
        if pix.isNull():
            self.poster.setPixmap(QPixmap())
            self.poster.setText("🎬" if self.source else "")
            return
        size = self.stack.size() - QSize(8, 8)
        self.poster.setPixmap(pix.scaled(size, Qt.AspectRatioMode.KeepAspectRatio,
                                         Qt.TransformationMode.SmoothTransformation))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self.stack.currentIndex() == 0 and self.source:
            self._show_poster()

    # ------------------------------------------------------------------ #
    def _ensure_player(self) -> bool:
        if self.player is not None:
            return True
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
            from PySide6.QtMultimediaWidgets import QVideoWidget
        except ImportError:
            return False
        self.video = QVideoWidget()
        self.video.setCursor(Qt.CursorShape.PointingHandCursor)
        self.video.mousePressEvent = lambda e: self.toggle()      # click: pause / play
        self.video_lay.addWidget(self.video)
        self.player = QMediaPlayer(self)
        self.audio = QAudioOutput(self)
        self.audio.setVolume(0.8)
        self.player.setAudioOutput(self.audio)
        self.player.setVideoOutput(self.video)
        self.player.durationChanged.connect(lambda d: (self.slider.setRange(0, int(d)),
                                                       self._time()))
        self.player.positionChanged.connect(self._moved)
        self.player.playbackStateChanged.connect(self._state)
        return True

    def toggle(self):
        if not self.source or not self._ensure_player():
            return
        from PySide6.QtMultimedia import QMediaPlayer

        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            self.player.pause()
            return
        want = QUrl.fromLocalFile(self.current_path())
        if self.player.source() != want:
            self.player.setSource(want)
        self.stack.setCurrentIndex(1)
        self.player.play()

    def _switch(self):
        """Original <-> Dubbed: the same moment of the other video."""
        if self.player is None or self.stack.currentIndex() == 0:
            return
        from PySide6.QtMultimedia import QMediaPlayer

        pos = self.player.position()
        playing = self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState
        self.player.setSource(QUrl.fromLocalFile(self.current_path()))
        self.player.setPosition(pos)
        if playing:
            self.player.play()

    def stop(self):
        if self.player is not None:
            self.player.stop()
            self.player.setSource(QUrl())
        self.slider.setValue(0)
        self.btn_play.setText("▶  Play")
        self.lb_time.setText("00:00 / 00:00")

    def _seek(self):
        self._dragging = False
        if self.player is not None:
            self.player.setPosition(self.slider.value())

    def _moved(self, pos: int):
        if not self._dragging:
            self.slider.setValue(int(pos))
        self._time()

    def _time(self):
        if self.player is not None:
            self.lb_time.setText(f"{_fmt(self.player.position())} / {_fmt(self.player.duration())}")

    def _state(self, state):
        from PySide6.QtMultimedia import QMediaPlayer

        self.btn_play.setText("⏸  Pause" if state == QMediaPlayer.PlaybackState.PlayingState
                              else "▶  Play")
