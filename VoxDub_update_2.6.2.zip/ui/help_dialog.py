"""
help_dialog.py - Help > User guide (F1): how to use SARIKA VOXDUB PRO, in
Khmer with the button names in English (as they appear in the app).

A topic list on the left, the page on the right, and a search box that keeps
only the topics containing the words typed.
"""

import html
import re
from typing import List, Optional, Tuple

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QPushButton,
    QTextBrowser, QVBoxLayout,
)

APP_NAME = "SARIKA VOXDUB PRO"

# (key, title, html body). Button / menu names are written exactly as in the app.
TOPICS: List[Tuple[str, str, str]] = [
    ("start", "🚀  ចាប់ផ្ដើម", """
<h2>ចាប់ផ្ដើមប្រើ SARIKA VOXDUB PRO</h2>
<p>កម្មវិធីនេះបកប្រែ និងបញ្ចូលសំលេង (Dub) វីដេអូដោយ AI៖ ស្ដាប់សំដីក្នុងវីដេអូ →
បកប្រែ → បង្កើតសំលេង AI → ដាក់ subtitle → Export ជា MP4។</p>
<h3>៣ ជំហានងាយៗ</h3>
<ol>
<li><b>បើកវីដេអូ</b> – ទាញវីដេអូ (MP4 · MOV · MKV) ទម្លាក់លើ <b>Video Preview</b>
    ឬចុចលើ Preview / <b>File › Open Video…</b> (<code>Ctrl+O</code>)។</li>
<li><b>ជ្រើសភាសា និងសំលេង</b> នៅខាងឆ្វេង៖ <b>Speech</b> (ភាសាដើម, ទុក Auto detect),
    <b>Dub to</b> (ឧ. Khmer), <b>Voice</b> (Auto = ប្រុស/ស្រីតាមតួអង្គ)។</li>
<li>ចុច <b>⚡ AUTO DUB</b> ឬ <b>Auto Dub</b> ខាងលើ — រង់ចាំរហូត 100% រួចចុច
    <b>Export</b> (ខាងក្រោមស្ដាំ)។</li>
</ol>
<p class="tip">💡 ការងារត្រូវបាន Save ដោយស្វ័យប្រវត្តិ។ បើបិទកម្មវិធីពាក់កណ្ដាលទី
បើកវីដេអូដដែលម្ដងទៀត កម្មវិធីនឹងសួរថាចង់បន្តពីកន្លែងចាស់ឬទេ។</p>
<h3>ផ្ទាំងសំខាន់ៗ</h3>
<ul>
<li><b>ខាងឆ្វេង</b> – ភាសា, AI Voice, Speech recognition, AUTO DUB និង Log។</li>
<li><b>កណ្ដាល</b> – Video Preview (Orig = សំលេងដើម, AI Voice = សំលេង AI)។</li>
<li><b>ខាងស្ដាំ</b> – Transcript · Translation · Subtitles · Style។</li>
<li><b>ខាងក្រោម</b> – Timeline ដូច Movavi (កាត់, ផ្លាស់ទី, Tools)។</li>
</ul>
"""),
    ("autodub", "⚡  Auto Dub ជំហានៗ", """
<h2>AUTO DUB និងជំហាន 1 · 2 · 3</h2>
<p><b>⚡ AUTO DUB</b> ធ្វើទាំង ៣ ជំហានក្នុងម្ដង។ អ្នកក៏អាចចុចម្ដងមួយៗបាន៖</p>
<ol>
<li><b>1 · Transcribe</b> – Whisper ស្ដាប់សំដីក្នុងវីដេអូ ហើយសរសេរជាអក្សរ (Transcript tab)។</li>
<li><b>2 · Translate</b> – បកប្រែទៅភាសា <b>Dub to</b> (Translation tab)។</li>
<li><b>3 · Voice</b> – បង្កើតសំលេង AI សម្រាប់គ្រប់ប្រយោគ ហើយដាក់លើ Timeline។</li>
</ol>
<p>ចុច <b>Cancel</b> ដើម្បីឈប់។ អ្វីដែលធ្វើរួចត្រូវបានរក្សាទុក — ចុចម្ដងទៀតដើម្បីបន្ត។</p>
<p class="tip">💡 ចុច <b>1 · Transcribe</b> ម្ដងទៀតលើវីដេអូដែលធ្វើរួច = ស្ដាប់ឡើងវិញ
(ការបកប្រែ និងសំលេង AI ចាស់នឹងត្រូវលុប)។</p>
<h3>Max speed</h3>
<p>បើប្រយោគខ្មែរវែងជាងពេលវេលាដែលតួអង្គនិយាយ សំលេង AI ត្រូវនិយាយលឿនជាងមុន។
<b>Max speed</b> កំណត់ល្បឿនអតិបរមា (1.50 × = លឿនបំផុតមួយដងកន្លះ)។</p>
<h3>Voice style</h3>
<p><b>Natural</b>៖ សំលេងលឿនបំផុត 1.1 × ហើយ video យឺតបន្តិចត្រង់ប្រយោគវែង។<br>
<b>Original VoxDub</b>៖ សំលេងដូច VoxDub PRO កំណែដំបូង – Edge និយាយលឿនរហូត +40 %
បន្ទាប់មករហូត 1.5 × ហើយ video មិនយឺត។ ប្តូរហើយ ចុច 3 · Voice ម្តងទៀត។</p>
"""),
    ("speech", "🎧  ស្ដាប់សំដី (Whisper) និង OCR", """
<h2>Speech recognition</h2>
<p><b>Whisper</b> model៖ <code>tiny/base</code> លឿនតែមិនសូវត្រូវ, <code>small</code> ល្អ,
<code>medium</code> / <code>large-v3</code> ត្រឹមត្រូវបំផុត (ប្រើជាមួយ NVIDIA GPU)។
លើកដំបូងវាទាញយក model (ត្រូវការ Internet)។</p>
<p>កម្មវិធីរកកន្លែងមានសំដីមុន ហើយស្ដាប់ជាបំណែកខ្លីៗ ដូច្នេះវីដេអូវែង 1–2 ម៉ោងក៏ចាប់បានគ្រប់កន្លែង
— រួមទាំងកន្លែងតួអង្គស្រែក ឬមានភ្លេងខ្លាំង។</p>
<h3>Double-check with the subtitles burned into the video (OCR)</h3>
<p>រឿងចិនភាគច្រើនមាន subtitle ចិននៅលើរូបភាពស្រាប់។ ពេលធីកប្រអប់នេះ (នៅក្រោម Whisper)
កម្មវិធីអានអក្សរទាំងនោះ ហើយយកមកកែពាក្យដែល Whisper ស្ដាប់ខុស (ឈ្មោះ, ពាក្យសូរដូចគ្នា)
និងបន្ថែមប្រយោគដែល Whisper ខកខាន។ ដំណើរការសម្រាប់ភាសាចិន និងអង់គ្លេស។</p>
<p>សម្រាប់ project ដែលធ្វើរួចហើយ៖ <b>Tools › 🔍 Double-check the transcript with the
burned-in subtitles</b> — រួចចុច AUTO DUB ដើម្បីបកប្រែ និងបញ្ចូលសំលេងតែប្រយោគដែលបានកែ។</p>
<p class="tip">OCR មានស្រាប់ក្នុងកម្មវិធីដែលដំឡើងរួច។ (Version source code៖ run
<b>install.bat</b> ម្ដងទៀត។)</p>
"""),
    ("voice", "🎙  សំលេង AI (Voice)", """
<h2>AI Voice</h2>
<ul>
<li><b>Engine</b> – <b>Edge Neural (free)</b> សំលេងធម្មជាតិ ឥតគិតថ្លៃ (ត្រូវការ Internet),
    <b>Google TTS (simple)</b> ជាជម្រើសបម្រុង, <b>Azure Speech (your key)</b> ប្រើ key ផ្ទាល់ខ្លួន
    (<b>🔑 Azure key…</b> ឬ <b>Help › Azure Speech key…</b>)។</li>
<li><b>Voice</b> – <b>Auto (Male / Female per line)</b> ជ្រើសសំលេងប្រុស ឬស្រីសម្រាប់ប្រយោគនីមួយៗ
    តាមសំលេងតួអង្គក្នុងវីដេអូ។ ឬជ្រើសសំលេងមួយសម្រាប់ទាំងអស់ (ឧ. Piseth / Sreymom)។</li>
<li><b>▶ Test voice</b> – ស្ដាប់គំរូសំលេង។</li>
</ul>
<p>ក្នុង <b>Translation</b> tab ជួរឈរ ♂/♀ បង្ហាញភេទដែលបានរកឃើញ —
<b>Double-click</b> ដើម្បីប្ដូរ រួចចុច <b>Re-voice selected</b>។</p>
"""),
    ("engines", "✨  Gemini · VoxCPM (AI engines)", """
<h2>AI engines និង API keys</h2>
<p>បើកពី <b>Tools › ⚙ AI engines &amp; API keys</b> ឬប៊ូតុង 🔑 / ⚙ នៅខាងឆ្វេង។
Key ទាំងអស់រក្សាទុកតែលើកុំព្យូទ័រនេះ (មិនដាក់ក្នុង project file ទេ)។</p>
<h3>Gemini (Google API key)</h3>
<ol>
<li>បើក <b>aistudio.google.com/apikey</b> → <b>Create API key</b> → copy។</li>
<li>Paste ក្នុង tab <b>Gemini</b> → <b>＋ Add key</b> → <b>Test keys</b>។ អាចដាក់ key ច្រើន
    (Google account មួយ = quota មួយ) — កម្មវិធីប្រើវេនគ្នា ហើយរំលង key ដែលអស់ quota។</li>
<li>ជ្រើស <b>Model</b> (ចុច <b>List models</b> ដើម្បីមើល model ដែល key អ្នកប្រើបាន)។</li>
</ol>
<ul>
<li><b>Translate: Gemini – follows the story</b> – បកប្រែដោយមើលសាច់រឿង៖ ឈ្មោះតួអង្គដដែលគ្រប់វគ្គ,
    ពាក្យហៅ (បង/ប្អូន/ម៉ាក់ក្មេក…) ត្រូវតាមទំនាក់ទំនង, ភាសានិយាយធម្មជាតិ។
    ប្រយោគដែល Gemini ខកខាន ត្រូវបាន Google Translate បំពេញ។</li>
<li><b>Speech recognition › Engine: Gemini</b> – ផ្ញើកន្លែងមានសំដី (ម្ដងប្រហែល 1 នាទី)
    ទៅ Google ជំនួស Whisper (ប្រើ quota ច្រើនជាងការបកប្រែ)។</li>
</ul>
<h3>VoxCPM2 – Voice clone</h3>
<p>VoxCPM2 (ឥតគិតថ្លៃ) និយាយខ្មែរបាន ហើយចម្លងសំលេងពីការថតខ្លីៗ (5–15 វិនាទី)។ វាដំណើរការលើ
កាត NVIDIA ក្នុង Python 3.10–3.12 <b>ដាច់ដោយឡែក</b> (venv-voxcpm)។</p>
<ol>
<li>ដំឡើងម្ដង៖ ចុចពីរដង <b>setup_voxcpm.bat</b> ក្នុង folder កម្មវិធី — វាបង្កើត <b>venv-voxcpm</b>
    នៅជាប់កម្មវិធី ហើយកម្មវិធីរកឃើញដោយខ្លួនឯង (មិនពឹង Sarika Studio ទៀតទេ)។</li>
<li><b>Male voice</b> / <b>Female voice</b> – file ថតសំលេង និងអក្សរដែលនិយាយក្នុងនោះ។</li>
<li><b>Test VoxCPM</b> → ស្ដាប់គំរូ។</li>
<li>AI Voice › <b>Engine: VoxCPM2 – voice clone</b> › Voice <b>Auto</b> (ប្រុស/ស្រីតាមតួអង្គ)។</li>
</ol>
<p class="tip">💡 VoxCPM យឺតជាង Edge (ប៉ុន្មានវិនាទីក្នុងមួយប្រយោគ)។ គន្លឹះ៖ ប្រើ Edge សម្រាប់វីដេអូទាំងមូល
ហើយប្ដូរ Engine ទៅ VoxCPM រួច <b>Re-voice selected</b> សម្រាប់ប្រយោគសំខាន់ៗ។</p>
"""),
    ("characters", "👥  តួអង្គ (Characters) – សំលេងម្នាក់មួយ", """
<h2>តួអង្គ – តួ A សំលេង A, តួ B សំលេង B</h2>
<p>ក្រោយ Transcribe កម្មវិធីស្ដាប់ <b>ស្នាមសំលេង (voice print)</b> នៃប្រយោគនីមួយៗ ហើយចាត់ក្រុម៖
ក្រុមមួយ = តួអង្គមួយ (A, B, C… — A និយាយច្រើនជាងគេ)។ តួអង្គមួយប្រើ <b>សំលេងតែមួយ</b>
ពេញវីដេអូ — លែងមានតួស្រីចេញសំលេងប្រុស ឬមនុស្សតែម្នាក់ដូរសំលេងទៀតហើយ។
ប្រុស/ស្រី វាស់ពី pitch នៃប្រយោគ<b>ទាំងអស់</b>របស់តួនោះ (ជាក់លាក់ជាងមួយប្រយោគៗ)។</p>
<h3>Tab 👥 Characters (ខាងស្ដាំ)</h3>
<ul>
<li><b>🔍 Find characters</b> – ស្វែងរកម្ដងទៀត (ឈ្មោះ/សំលេងដែលអ្នកកំណត់ ត្រូវរក្សាទុក)។</li>
<li>ជ្រើសតួ → <b>Name</b> (ឧ. ម៉ាក់, យាយ, Ming), <b>♂/♀</b>, <b>Age</b>៖ Child · Young · Adult · Elder។
    កូនក្មេងស្ដាប់បានតែពេល pitch ខ្ពស់ខ្លាំង — <b>មនុស្សចាស់</b> ត្រូវជ្រើសដោយដៃ។</li>
<li><b>▶ Listen</b> ស្ដាប់សំលេងដើមរបស់តួនោះ · <b>⏩ First line</b> លោតទៅប្រយោគដំបូង ·
    <b>Move lines to…</b> រួមតួពីរដែលជាមនុស្សតែម្នាក់។</li>
<li><b>Edge / Azure</b>៖ ភាសាខ្មែរមានសំលេងប្រុស១ ស្រី១ — តួដូចគ្នាភេទ ទទួល <b>Pitch</b> ខុសគ្នាបន្តិច
    (Auto) ដើម្បីកុំឲ្យ A និង B ឮដូចគ្នា។ ក្មេង = សំលេងស្រីខ្ពស់, ចាស់ = ទាបជាង។</li>
<li><b>VoxCPM2</b> › <b>Clone from</b>៖ <b>Auto/This video</b> = ចម្លងសំលេងតារាផ្ទាល់ពីវីដេអូ
    (មាន music ច្រើន សំលេងនឹងមិនស្អាត) · <b>My recording</b> = file ថតស្អាត 5–15s (ល្អបំផុត) ·
    <b>Default</b> = សំលេង Male/Female/Child/Elder ក្នុង Settings › AI engines។</li>
<li>ប្ដូររួច ចុច <b>🔊 Voice the changed lines</b> — បង្កើតឡើងវិញតែប្រយោគដែលប៉ះពាល់។</li>
</ul>
<p>ប្រយោគមួយចាត់តួខុស? Tab 🌐 Translation → ចុចពីរដងលើ cell <b>🎙</b> (ឧ. <b>A ♀</b>) → ជ្រើសតួត្រូវ
ឬ <b>＋ New character</b>។ ជ្រើសច្រើនប្រយោគ ដើម្បីផ្លាស់ក្នុងពេលតែមួយ។</p>
"""),
    ("tables", "📝  កែអក្សរ និងបកប្រែ", """
<h2>Transcript · Translation · Subtitles</h2>
<ul>
<li><b>Transcript</b> – អក្សរដើមដែល Whisper ស្ដាប់បាន។ កែបានដោយផ្ទាល់។
    Double-click លើពេលវេលា ដើម្បីលោតទៅកន្លែងនោះ។</li>
<li><b>Translation</b> – ការបកប្រែ។ កែប្រយោគណាមួយ ជ្រើសជួរនោះ ហើយចុច
    <b>🔊 Re-voice selected</b> ដើម្បីបង្កើតសំលេងថ្មី។ <b>🌐 Translate all</b> បកប្រែប្រយោគដែលនៅសល់។
    <b>🔊 Re-voice all</b> បង្កើតសំលេងទាំងអស់ឡើងវិញ។</li>
<li><b>Subtitles</b> – Subtitle ដែលនឹងបង្ហាញលើវីដេអូ។ <b>＋ Add</b> / <b>－ Delete</b>,
    <b>↻ From translation</b> (បង្កើតពីការបកប្រែ), <b>↻ From original</b> (ពីអក្សរដើម),
    <b>💾 Save SRT</b>។</li>
</ul>
<p><b>↓ Follow video</b> – តារាងរំកិលតាមវីដេអូពេលកំពុងចាក់។</p>
"""),
    ("timeline", "🎞  Timeline", """
<h2>Timeline (ដូច Movavi)</h2>
<p>មាន ៣ បន្ទាត់៖ <b>Subtitles</b> (ពណ៌ស្វាយ) · <b>Video</b> + សំលេងដើម · <b>AI voice</b> (ពណ៌បៃតង)។</p>
<ul>
<li><b>ចុច</b> លើ ruler ដើម្បីផ្លាស់ playhead (បន្ទាត់ក្រហម)។</li>
<li><b>ទាញ</b> clip ដើម្បីផ្លាស់ទី · ទាញគែម clip ដើម្បីកាត់ខ្លី/ពង្រីក។</li>
<li><b>✂ Split</b> (<code>S</code> ឬ <code>Ctrl+B</code>) កាត់ clip នៅ playhead ·
    <b>🗑</b> (<code>Delete</code>) លុប clip ដែលបានជ្រើស។</li>
<li><b>🧲 Snap</b> – clip ជាប់នឹង playhead និងគែម clip ផ្សេង។</li>
<li>👁 / 🔊 នៅក្បាលបន្ទាត់ – លាក់ ឬបិទសំលេងបន្ទាត់នោះពេល Preview។</li>
<li><b>Scale</b> (ខាងក្រោម) ឬ <code>Ctrl + Scroll</code> – ពង្រីក/បង្រួម Timeline ·
    <code>Ctrl+0</code> មើលទាំងមូល។</li>
<li>Right-click លើ clip សម្រាប់ menu បន្ថែម (Split, Delete, Edit text…, Clip volume…)។</li>
</ul>
<p>Undo / Redo៖ <code>Ctrl+Z</code> / <code>Ctrl+Y</code>។</p>
"""),
    ("tools", "🛠  Tools (Crop · Color · Audio)", """
<h2>Tools នៅលើ Timeline</h2>
<ul>
<li><b>✂ Crop and Rotate</b> – ទាញប្រអប់ដាច់ៗលើ Preview ដើម្បីកាត់គែម, <b>Angle</b> បង្វិល,
    <b>Zoom</b> ពង្រីក, <b>Remove black bars</b> កាត់ឆ្នូតខ្មៅដោយស្វ័យប្រវត្តិ,
    <b>Keep proportions</b> រក្សាទម្រង់។</li>
<li><b>◑ Color Adjustments</b> – Auto (Magic Enhance, Auto contrast …) ឬ
    <b>Manual Adjustments</b>៖ Brightness, Contrast, Saturation, Highlights, Gamma, Shadows,
    Hue, Temperature, Tint។ Preview បង្ហាញពណ៌ពេល Pause។</li>
<li><b>🎚 Audio Properties</b> – ជ្រើស clip សំលេង AI លើ Timeline (ឬគ្មាន = សំលេងដើម)៖
    Volume, Normalize, Speed, Fade in/out ព្រមទាំង <b>Equalizer</b> (preset Voice
    enhancement, Bass boost …), <b>Noise Removal</b>, <b>Audio Effects</b> (Radio, Echo,
    Telephone, Robot …)។ ចុច <b>▶ Listen (8 sec.)</b> ដើម្បីស្ដាប់។</li>
<li><b>Video</b> tab – Fade in / Fade out នៃរូបភាព។</li>
</ul>
<p>ចុច <b>✓</b> ឬ <b>«</b> ដើម្បីបិទ Tools។ ការកែទាំងអស់ Undo បាន។</p>
"""),
    ("style", "🎨  Style · Subtitle · Logo", """
<h2>Style tab</h2>
<h3>Original subtitles</h3>
<p><b>Hide the original subtitles</b> – លាក់ subtitle ចិនដើម។ ចុច <b>🔍 Auto detect</b>
ដើម្បីរកទីតាំងដោយស្វ័យប្រវត្តិ។ <b>Hide with</b>៖ Blur ឬ Black box។
<b>Our subtitles</b>៖ នៅបាតវីដេអូ ឬដាក់ពីលើ subtitle ដើម។</p>
<h3>Subtitles (look)</h3>
<p><b>Look</b> មានគំរូស្រាប់ (Classic, Bold, Yellow, Soft shadow, Box) ឬកែខ្លួនឯង៖
Font, Size, Bold, Colour, Outline, Shadow, Box behind the text (ពណ៌ + %), From bottom។
Preview បង្ហាញដូចពេល Export។</p>
<p><b>ទាញ Subtitle លើវីដេអូ៖</b> Pause ពេល subtitle កំពុងបង្ហាញ → ចុចលើវា (មានស៊ុមពណ៌បៃតង) →
ទាញ <b>ឆ្វេង/ស្ដាំ/លើ/ក្រោម</b> ទៅកន្លែងចង់បាន · ទាញ<b>ជ្រុង</b>ដើម្បីពង្រីក/ពង្រួមអក្សរ។
តម្លៃ <b>From bottom</b>, <b>Left ↔ right</b>, <b>Size</b> ប្ដូរតាម ហើយ Export ដាក់ត្រូវកន្លែងដដែល។
ប៊ូតុង <b>⟲</b> ដាក់ត្រឡប់មកកណ្ដាលវិញ។</p>
<p><b>លាក់ Subtitle៖</b> ប៊ូតុង <b>CC</b> ក្បែរ AI Voice (ឬ Edit › Hide / show all subtitles,
<b>Ctrl+Shift+H</b>, ឬ Style › <b>👁 Show subtitles</b>) — បិទ subtitle ទាំងអស់ ទាំង Preview និង
Export (អក្សរនៅរក្សាទុក ចុចម្ដងទៀតដើម្បីបង្ហាញវិញ)។ លាក់<b>តែប្រយោគខ្លះ</b> (ឧ. ចម្រៀង)៖
Tab 💬 Subtitles → ជ្រើស → <b>🙈 Hide / show</b> (បង្ហាញជាអក្សរប្រផេះឆូត)។ Ctrl+Z ត្រឡប់វិញបាន។</p>
<h3>Logo និង Brand text</h3>
<p>ជ្រើសរូប Logo (PNG ផ្ទៃថ្លា), Position, Size, Opacity, <b>Movement</b> (រំកិលដើម្បីការពារ
គេ crop ចេញ)។ <b>Brand text</b> ដូចគ្នា។ អាចទាញ Logo / អក្សរលើ Preview ទៅកន្លែងណាក៏បាន ·
ចុចលើ Logo ម្ដង ហើយទាញ<b>ជ្រុង</b>ដើម្បីពង្រីក/ពង្រួម (Brand text ដូចគ្នា)។</p>
<p><b>🖼 Preview frame (as exported)</b> – មើលរូបភាពពិតដូចពេល Export។</p>
"""),
    ("settings", "📐  Project settings (ទំហំវីដេអូ)", """
<h2>Project settings</h2>
<p>ចុច ✏ ក្បែរ <b>Project settings</b> (ខាងក្រោមស្ដាំ)៖</p>
<ul>
<li><b>Resolution</b> – Same as the video, 1920x1080 (16:9 YouTube),
    1080x1920 (9:16 TikTok / Reels / Shorts), 1080x1080 (1:1), 1080x1350 (4:5) … ឬ
    <b>Custom</b> (វាយ Width x Height, 🔗 = រក្សាសមាមាត្រ)។</li>
<li><b>Framing</b> – Letterbox (ឆ្នូតខ្មៅ), Blur (វីដេអូព្រាលៗពីក្រោយ), Stretch (ទាញពេញ),
    Crop (ពង្រីករហូតពេញ)។ ចុច <b>?</b> សម្រាប់ការពន្យល់។</li>
<li><b>FPS</b>, <b>Sample rate</b>, <b>Channels</b> (Mono / Stereo / 5.1)។</li>
</ul>
"""),
    ("export", "⬆  Export", """
<h2>Export</h2>
<p>ចុច <b>Export</b> (ខាងក្រោមស្ដាំ) ឬ <code>Ctrl+E</code>៖</p>
<ul>
<li><b>Save to</b> – កន្លែងរក្សាទុក MP4។</li>
<li><b>Resolution</b> – Project settings / 1080p / 720p · <b>Quality</b> · <b>Encoder</b>
    (NVIDIA GPU លឿនជាង)។</li>
<li><b>Original audio</b> / <b>AI voice</b> – កម្រិតសំលេង ·
    <b>Mute original speech where the AI voice speaks</b> – បិទសំដីចិនកន្លែងមានសំលេងខ្មែរ។</li>
<li><b>Burn subtitles into the video</b> · <b>Also save .srt subtitle file</b>។</li>
</ul>
<p>Menu <b>Export</b> មាន៖ Export Subtitles (SRT), Export AI Voice (WAV)។</p>
"""),
    ("batch", "☰  Batch queue", """
<h2>Batch queue – ធ្វើវីដេអូច្រើនក្នុងម្ដង</h2>
<ol>
<li>ចុច <b>☰ Batch</b> ខាងលើ (<code>Ctrl+Shift+B</code>)។</li>
<li><b>➕ Videos…</b> / <b>📁 Folder…</b> ឬទាញវីដេអូ/folder ទម្លាក់ចូល។</li>
<li>Tab <b>⚙ Dub</b>៖ ភាសា, Whisper, Voice, After dubbing (Export ស្វ័យប្រវត្តិ ឬឈប់ដើម្បីពិនិត្យ)។</li>
<li>Tab <b>⬆ Output</b>៖ folder, Resolution, Quality, Subtitles។</li>
<li>Tab <b>🛠 Tools</b>៖ <b>Open Tools…</b> (Crop, Color, Audio, EQ, Effects ជាមួយ Preview)
    និង <b>Project settings…</b> សម្រាប់គ្រប់វីដេអូ។</li>
<li>Tab <b>✨ Auto</b>៖ លាក់ subtitle ដើម, កាត់ឆ្នូតខ្មៅក្នុងវីដេអូនីមួយៗ។</li>
<li><b>At once</b> (ក្បែរ ▶ Start)៖ ចំនួនវីដេអូដែលធ្វើក្នុងពេលតែមួយ (1–8)។ 2–3 ល្អសម្រាប់កុំព្យូទ័រខ្លាំង;
    ច្រើនពេកត្រូវការ RAM / GPU ច្រើន។ អាចប្ដូរពេលកំពុងរត់បាន។</li>
<li>ចុច <b>▶ Start</b>។ អាចបិទផ្ទាំងនេះបាន — វានៅតែធ្វើការ។</li>
</ol>
<p><b>↻ Take from main window</b> ចម្លងការកំណត់ពី Editor។ បញ្ចប់ហើយមាន <b>📄 Report</b> (CSV)
និង <b>🔗 Merge finished</b>។</p>
"""),
    ("merge", "🔗  Merge / Split", """
<h2>Merge / Split</h2>
<ul>
<li><b>Merge</b> – ភ្ជាប់វីដេអូច្រើន (ឧ. វគ្គ 1–10) ជាវីដេអូតែមួយ។ អាចកាត់វាជាផ្នែកៗ
    N នាទីបន្ទាប់ពីភ្ជាប់ (<b>Then split the merged video into parts of</b>)។</li>
<li><b>Split</b> – កាត់វីដេអូវែងជាផ្នែក N នាទី។</li>
</ul>
<p>បើកពី <b>🔗 Merge / Split</b> ខាងលើ ឬ <b>Tools</b> menu។</p>
"""),
    ("keys", "⌨  Keyboard shortcuts", """
<h2>Keyboard shortcuts</h2>
<table>
<tr><td><code>Space</code> / <code>Ctrl+Space</code></td><td>Play / Pause</td></tr>
<tr><td><code>S</code> / <code>Ctrl+B</code></td><td>Split at playhead</td></tr>
<tr><td><code>Delete</code> / <code>Ctrl+Delete</code></td><td>Delete selected clip</td></tr>
<tr><td><code>←</code> <code>→</code></td><td>Playhead 0.1 វិនាទី (+ <code>Shift</code> = 1 វិនាទី)</td></tr>
<tr><td><code>Home</code> / <code>End</code></td><td>ទៅដើម / ចុង</td></tr>
<tr><td><code>Ctrl+Z</code> / <code>Ctrl+Y</code></td><td>Undo / Redo</td></tr>
<tr><td><code>Ctrl+=</code> / <code>Ctrl+-</code> / <code>Ctrl+0</code></td><td>Zoom in / out / Fit timeline</td></tr>
<tr><td><code>Ctrl+O</code></td><td>Open Video</td></tr>
<tr><td><code>Ctrl+Shift+O</code></td><td>Open Project</td></tr>
<tr><td><code>Ctrl+S</code> / <code>Ctrl+Shift+S</code></td><td>Save Project / Save As</td></tr>
<tr><td><code>Ctrl+E</code></td><td>Export Video</td></tr>
<tr><td><code>Ctrl+Shift+B</code></td><td>Batch queue</td></tr>
<tr><td><code>F1</code></td><td>Help (User guide)</td></tr>
</table>
<p>Shortcut <code>Space</code>, <code>S</code>, <code>Delete</code>, ព្រួញ ដំណើរការពេលចុចលើ Timeline ជាមុន។</p>
"""),
    ("trouble", "🩺  បញ្ហា និងដំណោះស្រាយ", """
<h2>បញ្ហាដែលជួបញឹកញាប់</h2>
<h3>Whisper យឺត / មិនប្រើ GPU</h3>
<p>Log បង្ហាញ "NVIDIA GPU found"។ បើវាប្រើ CPU — update NVIDIA driver ហើយដំឡើង
<b>NVIDIA GPU pack</b> (ជម្រើសក្នុង Setup) ឬ (version source code) run <b>install_gpu.bat</b> ម្ដង។</p>
<h3>សំដីខ្លះមិនត្រូវបានចាប់</h3>
<p>ប្រើ Whisper <code>medium</code> ឬ <code>large-v3</code> ហើយធីក <b>Double-check … (OCR)</b>
បើវីដេអូមាន subtitle ដើម។ រួចចុច <b>1 · Transcribe</b> ម្ដងទៀត។</p>
<h3>សំលេង AI បរាជ័យ ("failed")</h3>
<p>Edge / Google ត្រូវការ Internet។ ចុច <b>3 · Voice</b> ម្ដងទៀត — វាធ្វើតែប្រយោគដែលនៅខ្វះ។</p>
<h3>ffmpeg missing</h3>
<p>ដំឡើង SARIKA VOXDUB PRO ម្ដងទៀត (ffmpeg មកជាមួយ Setup)។</p>
<h3>អក្សរខ្មែរខូចក្នុង subtitle</h3>
<p>ជ្រើស Font ដែលសរសេរខ្មែរបាន (Style › Subtitles (look) › Font ឧ. Noto Sans Khmer)។</p>
<h3>Project / ការងារ</h3>
<p>ការងាររក្សាទុកក្នុង folder <b>output</b> (File › Open output folder) — ក្នុង version ដំឡើង
វាគឺ <b>Videos\\SARIKA VOXDUB PRO</b>។ ប្ដូរបានតាម <b>File › Change output folder…</b>។
បើកវីដេអូដដែលម្ដងទៀតដើម្បីបន្ត ឬ <b>File › Open Project…</b>។</p>
"""),
]

STYLE = """
body { font-family: 'Noto Sans Khmer', 'Segoe UI'; font-size: 11pt; color: #d7dde5; }
h2 { color: #22c3a6; font-size: 16pt; margin-bottom: 6px; }
h3 { color: #e8eaf0; font-size: 12pt; margin-top: 14px; margin-bottom: 4px; }
code { background-color: #252b33; color: #ffd27a; }
p.tip { background-color: #17302b; color: #bff3e7; padding: 6px; }
td { padding: 3px 14px 3px 0; }
b { color: #ffffff; }
"""


def _plain(text: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", " ", text)).lower()


class HelpDialog(QDialog):
    def __init__(self, parent=None, topic: str = ""):
        super().__init__(parent)
        self.setWindowTitle(f"{APP_NAME} – Help")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinMaxButtonsHint)
        self.resize(1000, 700)

        self.search = QLineEdit()
        self.search.setPlaceholderText("🔍  Search help… (e.g. Export, OCR, Logo)")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._filter)
        self.list = QListWidget()
        self.list.setFixedWidth(260)
        self.list.setObjectName("HelpTopics")
        f = QFont()
        f.setFamilies(["Noto Sans Khmer", "Segoe UI"])
        f.setPointSize(11)
        self.list.setFont(f)
        for key, title, _body in TOPICS:
            it = QListWidgetItem(title)
            it.setData(Qt.ItemDataRole.UserRole, key)
            it.setSizeHint(QSize(0, 34))
            self.list.addItem(it)
        self.list.currentItemChanged.connect(self._show)
        self.view = QTextBrowser()
        self.view.setOpenExternalLinks(True)
        self.view.document().setDefaultStyleSheet(STYLE)
        self.empty = QLabel("No topic contains these words.")
        self.empty.setObjectName("MutedLabel")
        self.empty.hide()

        left = QVBoxLayout()
        left.addWidget(self.search)
        left.addWidget(self.list, 1)
        left.addWidget(self.empty)
        body = QHBoxLayout()
        body.addLayout(left)
        body.addWidget(self.view, 1)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        foot = QHBoxLayout()
        note = QLabel(f"{APP_NAME} · F1 opens this guide at any time")
        note.setObjectName("MutedLabel")
        foot.addWidget(note, 1)
        foot.addWidget(close)
        lay = QVBoxLayout(self)
        lay.addLayout(body, 1)
        lay.addLayout(foot)
        self.open_topic(topic or TOPICS[0][0])

    def open_topic(self, key: str):
        for i in range(self.list.count()):
            if self.list.item(i).data(Qt.ItemDataRole.UserRole) == key:
                self.list.setCurrentRow(i)
                return

    def current_key(self) -> Optional[str]:
        it = self.list.currentItem()
        return it.data(Qt.ItemDataRole.UserRole) if it else None

    def _show(self, item, _prev=None):
        if item is None:
            return
        key = item.data(Qt.ItemDataRole.UserRole)
        body = next(b for k, _t, b in TOPICS if k == key)
        self.view.setHtml(f"<html><body>{body}</body></html>")

    def _filter(self, text: str):
        words = [w for w in text.lower().split() if w]
        first = None
        for i, (_k, title, body) in enumerate(TOPICS):
            hay = title.lower() + " " + _plain(body)
            hit = all(w in hay for w in words)
            self.list.item(i).setHidden(not hit)
            if hit and first is None:
                first = i
        self.empty.setVisible(first is None)
        if first is not None and (self.list.currentItem() is None
                                  or self.list.currentItem().isHidden()):
            self.list.setCurrentRow(first)
