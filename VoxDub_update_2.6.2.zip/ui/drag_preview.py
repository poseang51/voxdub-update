"""
drag_preview.py - the batch Tools preview you can drag things in.

The exported picture of a queued video is rendered by ffmpeg WITHOUT the logo,
the brand text and the subtitles; those three are drawn here by Qt with the
same geometry the export uses (core/branding.py, core/subrender.py), so they
follow the mouse live:

  * drag the logo / the brand text / the subtitles to move them
    (logo and brand text become "Custom (drag in the preview)");
  * drag the small square at their bottom-right corner to resize them;
  * the area that hides the original subtitles (dashed box) moves and
    resizes the same way; subtitles shown "over the original subtitles" move
    with it.
"""

from typing import Dict, Optional, Tuple

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import QWidget

from core import branding, subrender
from core.project import Project

HANDLE = 12            # px on screen: the resize square
MIN_LOGO, MAX_LOGO = 0.03, 0.60
MIN_BRAND, MAX_BRAND = 0.30, 3.00
MIN_SUB, MAX_SUB = 0.40, 3.00


class DragPreview(QWidget):
    aboutToEdit = Signal()
    edited = Signal(str)          # "logo" / "brand" / "subs" / "cover" (mouse released)
    moving = Signal(str)          # live, while dragging

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(420, 300)
        self.setMouseTracking(True)
        self.base: Optional[QPixmap] = None      # the frame without logo / text / subtitles
        self.p: Optional[Project] = None         # the settings being edited
        self.geo: Optional[Project] = None       # the queued video (crop, size ...) + settings
        self.t = 0.0
        self.sample = ""
        self.message = "Add videos to the queue to see a preview"
        self._logo: Tuple[str, Optional[QImage]] = ("", None)
        self._extra: Dict[str, QImage] = {}       # more logos: path -> picture
        self._brand: Dict[tuple, QImage] = {}
        self._drag = None                         # (item, mode, start canvas pt, start values)
        self._hover = ""

    # ------------------------------------------------------------------ #
    def set_frame(self, pix: Optional[QPixmap], p: Project, geo: Project, t: float,
                  sample: str):
        self.base, self.p, self.geo, self.t, self.sample = pix, p, geo, t, sample
        self.update()

    def pixmap(self) -> QPixmap:
        return self.base if self.base is not None else QPixmap()

    def set_message(self, text: str):
        self.message = text
        self.update()

    def refresh(self, geo: Optional[Project] = None):
        """Settings changed (Style page): draw the overlays again."""
        if geo is not None:
            self.geo = geo
        self.update()

    # ------------------------------------------------------------------ #
    # geometry (canvas = the exported picture, W x H)
    # ------------------------------------------------------------------ #
    def _canvas(self) -> Tuple[int, int]:
        return self.base.width(), self.base.height()

    def _view(self) -> Tuple[float, float, float]:
        """(left, top, scale) of the canvas inside the widget."""
        W, H = self._canvas()
        s = min(self.width() / W, self.height() / H)
        return (self.width() - W * s) / 2, (self.height() - H * s) / 2, s

    def _to_canvas(self, pt) -> QPointF:
        x0, y0, s = self._view()
        return QPointF((pt.x() - x0) / s, (pt.y() - y0) / s)

    def _q(self) -> Project:
        """The queued video with the current settings (for the geometry)."""
        q = self.geo
        for k in ("cover_enabled", "cover_rect", "cover_mode", "sub_position", "sub_x",
                  "sub_bottom", "subtitle_scale", "sub_font", "sub_color", "sub_bold",
                  "sub_outline", "sub_outline_color", "sub_shadow", "sub_box", "sub_box_color",
                  "sub_box_opacity", "logo_path", "logo_corner", "logo_pos", "logo_motion",
                  "logo_size", "logo_opacity", "extra_logos", "brand_text", "brand_corner", "brand_pos",
                  "brand_motion", "brand_size", "brand_color"):
            setattr(q, k, getattr(self.p, k))
        return q

    def _logo_image(self) -> Optional[QImage]:
        path = self.p.logo_path if branding.has_logo(self.p) else ""
        if self._logo[0] != path:
            img = QImage(path) if path else QImage()
            self._logo = (path, None if img.isNull() else img)
        return self._logo[1]

    def _extra_image(self, path: str) -> Optional[QImage]:
        if path not in self._extra:
            self._extra[path] = QImage(path)
        img = self._extra[path]
        return None if img.isNull() else img

    def _brand_image(self, q: Project, W: int, H: int) -> Optional[QImage]:
        if not (q.brand_text or "").strip() or not subrender.available():
            return None
        key = (q.brand_text, q.brand_color, q.brand_size, W, H)
        if key not in self._brand:
            import os
            import tempfile

            out = os.path.join(tempfile.gettempdir(), f"voxdub_brand_{os.getpid()}.png")
            try:
                subrender.render_brand_png(q, W, H, out)
                self._brand = {key: QImage(out)}
            except Exception:
                self._brand = {key: QImage()}
        img = self._brand[key]
        return None if img.isNull() else img

    def rects(self) -> Dict[str, QRectF]:
        """Where every draggable thing is on the canvas."""
        out: Dict[str, QRectF] = {}
        if self.base is None or self.p is None or self.geo is None:
            return out
        q = self._q()
        W, H = self._canvas()
        cov = branding.cover_on_canvas(q, W, H)
        if cov is not None:
            out["cover"] = QRectF(*cov)
        img = self._logo_image()
        if img is not None:
            lw = W * q.logo_size
            lh = lw * img.height() / max(1, img.width())
            x, y = branding.item_xy(q.logo_corner, q.logo_pos, q.logo_motion, self.t, W, H, lw, lh)
            out["logo"] = QRectF(x, y, lw, lh)
        for k, d in enumerate(branding.extra_logos(q)):
            im = self._extra_image(d["path"])
            if im is None:
                continue
            lw = W * float(d["size"])
            lh = lw * im.height() / max(1, im.width())
            x, y = branding.item_xy(d["corner"], d["pos"], d["motion"], self.t, W, H, lw, lh)
            out[f"x{d['index']}"] = QRectF(x, y, lw, lh)
        b = self._brand_image(q, W, H)
        if b is not None:
            x, y = branding.item_xy(q.brand_corner, q.brand_pos, q.brand_motion, self.t, W, H,
                                    b.width(), b.height())
            out["brand"] = QRectF(x, y, b.width(), b.height())
        if self.sample and subrender.available():
            lines, font, _st, _sc, cx, ay, centered = subrender.layout(q, self.sample, W, H, W, H)
            _path, box, _ = subrender.build_path(lines, font, cx, ay, centered)
            out["subs"] = box.adjusted(-4, -2, 4, 2)
        return out

    # ------------------------------------------------------------------ #
    def paintEvent(self, _ev):
        qp = QPainter(self)
        qp.fillRect(self.rect(), QColor("#0b0d10"))
        if self.base is None or self.p is None or self.geo is None:
            qp.setPen(QColor("#8b93a3"))
            qp.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.message)
            return
        x0, y0, s = self._view()
        W, H = self._canvas()
        qp.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        qp.drawPixmap(QRectF(x0, y0, W * s, H * s), self.base, QRectF(0, 0, W, H))
        qp.save()
        qp.translate(x0, y0)
        qp.scale(s, s)
        qp.setClipRect(QRectF(0, 0, W, H))
        q = self._q()
        r = self.rects()
        img = self._logo_image()
        if "logo" in r and img is not None:
            qp.setOpacity(max(0.0, min(1.0, q.logo_opacity)))
            qp.drawImage(r["logo"], img)
            qp.setOpacity(1.0)
        for d in branding.extra_logos(q):
            rc, im = r.get(f"x{d['index']}"), self._extra_image(d["path"])
            if rc is not None and im is not None:
                qp.setOpacity(max(0.0, min(1.0, float(d["opacity"]))))
                qp.drawImage(rc, im)
                qp.setOpacity(1.0)
        b = self._brand_image(q, W, H)
        if "brand" in r and b is not None:
            qp.drawImage(r["brand"].topLeft(), b)
        if "subs" in r:
            lines, font, style, scale, cx, ay, centered = subrender.layout(
                q, self.sample, W, H, W, H)
            path, box, _ = subrender.build_path(lines, font, cx, ay, centered)
            subrender.paint(qp, path, box, style, scale)
        if self._drag and self._drag[0] == "cover" and "cover" in r:
            qp.fillRect(r["cover"], QColor(70, 76, 84, 200))   # (blurred again on release)
        qp.restore()
        # handles (screen pixels)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        active = self._drag[0] if self._drag else self._hover
        for name, rc in r.items():
            sr = QRectF(x0 + rc.x() * s, y0 + rc.y() * s, rc.width() * s, rc.height() * s)
            on = name == active
            colour = QColor("#ff8a4c" if on else ("#f5b942" if name == "cover" else "#2fd59a"))
            pen = QPen(colour, 2 if on else 1)
            pen.setStyle(Qt.PenStyle.SolidLine if on else Qt.PenStyle.DashLine)
            qp.setPen(pen)
            qp.setBrush(Qt.BrushStyle.NoBrush)
            qp.drawRect(sr)
            qp.setPen(Qt.PenStyle.NoPen)
            qp.setBrush(colour)
            qp.drawRect(QRectF(sr.right() - HANDLE / 2, sr.bottom() - HANDLE / 2, HANDLE, HANDLE))
            if on or name == "cover":
                label = {"logo": "Logo", "brand": "Brand text", "subs": "Subtitles",
                         "cover": "Hide original subtitles"}.get(
                    name, f"Logo {int(name[1:]) + 2}" if name.startswith("x") else name)
                qp.setPen(colour)
                qp.drawText(QPointF(sr.left() + 2, max(12.0, sr.top() - 4)), label)

    # ------------------------------------------------------------------ #
    def _hit(self, pos) -> Tuple[str, str]:
        """(item, "move" / "resize") under the mouse, the top-most first."""
        r = self.rects()
        if not r:
            return "", ""
        x0, y0, s = self._view()
        # 2.4: our subtitles can always be grabbed on their own (also when they
        # sit over the box that hides the original ones)
        extras = sorted((n for n in r if n.startswith("x")), reverse=True)
        for name in ["subs", "brand"] + extras + ["logo", "cover"]:
            rc = r.get(name)
            if rc is None:
                continue
            sr = QRectF(x0 + rc.x() * s, y0 + rc.y() * s, rc.width() * s, rc.height() * s)
            corner = QRectF(sr.right() - HANDLE, sr.bottom() - HANDLE, HANDLE * 2, HANDLE * 2)
            if corner.contains(pos):
                return name, "resize"
            if sr.contains(pos):
                return name, "move"
        return "", ""

    def mousePressEvent(self, ev):
        if ev.button() != Qt.MouseButton.LeftButton:
            return
        name, mode = self._hit(ev.position())
        if not name:
            return
        self.aboutToEdit.emit()
        p = self.p
        if name == "subs" and p.sub_position == "cover":
            # glued to the hide box until now: free them, from where they are seen
            W, H = self._canvas()
            rc = self.rects()["subs"]
            p.sub_x = round(max(3.0, min(97.0, rc.center().x() / W * 100)), 1)
            p.sub_bottom = round(max(0.0, min(95.0, (H - rc.bottom() + 2) / H * 100)), 1)
            p.sub_position = "bottom"
        start = {"rect": self.rects()[name], "logo_size": p.logo_size,
                 "brand_size": p.brand_size, "scale": p.subtitle_scale or 1.0,
                 "sub_x": p.sub_x, "sub_bottom": p.sub_bottom,
                 "cover": list(p.cover_rect),
                 "xsize": {i: float({**branding.EXTRA_LOGO, **d}["size"])
                           for i, d in enumerate(p.extra_logos or [])}}
        self._drag = (name, mode, self._to_canvas(ev.position()), start)
        self.update()

    def mouseMoveEvent(self, ev):
        if self._drag is None:
            name, mode = self._hit(ev.position())
            if name != self._hover:
                self._hover = name
                self.update()
            self.setCursor(Qt.CursorShape.SizeFDiagCursor if mode == "resize" else
                           Qt.CursorShape.SizeAllCursor if mode == "move" else
                           Qt.CursorShape.ArrowCursor)
            return
        name, mode, a, st = self._drag
        b = self._to_canvas(ev.position())
        self._apply(name, mode, b.x() - a.x(), b.y() - a.y(), st)
        self.update()
        self.moving.emit(name)

    def mouseReleaseEvent(self, ev):
        if self._drag is None:
            return
        name = self._drag[0]
        self._drag = None
        self.update()
        self.edited.emit(name)

    # ------------------------------------------------------------------ #
    def _apply(self, name: str, mode: str, dx: float, dy: float, st: dict):
        """Change the settings for a drag of (dx, dy) canvas pixels."""
        p = self.p
        W, H = self._canvas()
        rc: QRectF = st["rect"]
        if name.startswith("x"):                    # one of the extra logos
            i = int(name[1:])
            if mode == "move":
                pos = branding.pos_from_xy(rc.x() + dx, rc.y() + dy, W, H,
                                           rc.width(), rc.height())
                branding.set_extra_logo(p, i, corner="custom", pos=pos, motion="none")
            else:
                k = max(0.1, (rc.width() + dx) / max(1.0, rc.width()))
                size = round(max(MIN_LOGO, min(0.8, st["xsize"].get(i, 0.25) * k)), 3)
                branding.set_extra_logo(p, i, size=size)
                nr = self.rects().get(name)
                if nr is not None:
                    pos = branding.pos_from_xy(rc.x(), rc.y(), W, H, nr.width(), nr.height())
                    branding.set_extra_logo(p, i, corner="custom", pos=pos)
            return
        if name in ("logo", "brand"):
            if mode == "move":
                pos = branding.pos_from_xy(rc.x() + dx, rc.y() + dy, W, H,
                                           rc.width(), rc.height())
                if name == "logo":
                    p.logo_corner, p.logo_pos, p.logo_motion = "custom", pos, "none"
                else:
                    p.brand_corner, p.brand_pos, p.brand_motion = "custom", pos, "none"
            else:
                k = max(0.1, (rc.width() + dx) / max(1.0, rc.width()))
                if name == "logo":
                    p.logo_size = round(max(MIN_LOGO, min(MAX_LOGO, st["logo_size"] * k)), 3)
                else:
                    p.brand_size = round(max(MIN_BRAND, min(MAX_BRAND, st["brand_size"] * k)), 2)
                # keep the top-left corner where it is
                pin = "logo" if name == "logo" else "brand"
                nr = self.rects().get(pin)
                if nr is not None:
                    pos = branding.pos_from_xy(rc.x(), rc.y(), W, H, nr.width(), nr.height())
                    if name == "logo":
                        p.logo_corner, p.logo_pos = "custom", pos
                    else:
                        p.brand_corner, p.brand_pos = "custom", pos
        elif name == "subs":
            if mode == "move":
                p.sub_x = round(max(3.0, min(97.0, st["sub_x"] + dx / W * 100)), 1)
                p.sub_bottom = round(max(0.0, min(95.0, st["sub_bottom"] - dy / H * 100)), 1)
            else:
                k = max(0.1, (rc.height() + dy) / max(1.0, rc.height()))
                p.subtitle_scale = round(max(MIN_SUB, min(MAX_SUB, st["scale"] * k)), 2)
        elif name == "cover":
            q = self._q()
            sx, sy, sw, sh = branding.source_on_canvas(q, W, H)
            fx, fy, fw, fh = st["cover"]
            if mode == "move":
                fx = max(0.0, min(1.0 - fw, fx + dx / sw))
                fy = max(0.0, min(1.0 - fh, fy + dy / sh))
            else:
                fw = max(0.02, min(1.0 - fx, fw + dx / sw))
                fh = max(0.02, min(1.0 - fy, fh + dy / sh))
            p.cover_rect = [round(fx, 4), round(fy, 4), round(fw, 4), round(fh, 4)]

