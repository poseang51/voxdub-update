"""
tools_panel.py - Movavi-style "Tools" panel (shown in place of the left panel):

  * Crop and Rotate    - angle, keep proportions; the crop box is dragged on the
                         video preview itself
  * Color Adjustments  - auto view (saturation / contrast / Magic Enhance / white
                         balance) and manual view (brightness, contrast, saturation,
                         highlights, gamma, shadows, hue, temperature, tint)
  * Clip Properties    - Video tab (fade in/out) and Audio tab: for the selected AI
                         voice clip or the video's own sound (volume, normalize,
                         speed, fade in/out) + Equalizer, Noise Removal, Audio Effects
  (the video ratio is in the Project settings dialog, like Movavi)

The panel edits the Project directly. Before the first change of a session it
emits changing() (the window pushes one Undo step), after every change changed().
"""

from typing import List, Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDoubleSpinBox, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QPushButton, QScrollArea, QSlider, QStackedWidget, QToolButton,
    QVBoxLayout, QWidget,
)

from core import effects
from core.project import AudioClip, Project
from ui.icons import icon, icon_size


BG_MODES = {
    "original": "Original sound (its speech muted under the AI voice)",
    "music": "Music & effects only (remove all original voices)",
}


class SliderRow(QWidget):
    """Label · red slider · number box (Movavi look). Emits valueChanged(float)."""

    valueChanged = Signal(float)

    def __init__(self, lo: float, hi: float, step: float = 1.0, decimals: int = 0,
                 suffix: str = "", parent=None):
        super().__init__(parent)
        self.scale = 1.0 / step
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setObjectName("MvSlider")
        self.slider.setRange(int(round(lo * self.scale)), int(round(hi * self.scale)))
        self.spin = QDoubleSpinBox()
        self.spin.setObjectName("MvSpin")
        self.spin.setRange(lo, hi)
        self.spin.setDecimals(decimals)
        self.spin.setSingleStep(step)
        self.spin.setSuffix(suffix)
        self.spin.setFixedWidth(84)
        self.spin.setButtonSymbols(QDoubleSpinBox.ButtonSymbols.UpDownArrows)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        lay.addWidget(self.slider, 1)
        lay.addWidget(self.spin)
        self.slider.valueChanged.connect(self._from_slider)
        self.spin.valueChanged.connect(self._from_spin)

    def _from_slider(self, v: int):
        val = v / self.scale
        self.spin.blockSignals(True)
        self.spin.setValue(val)
        self.spin.blockSignals(False)
        self.valueChanged.emit(val)

    def _from_spin(self, val: float):
        self.slider.blockSignals(True)
        self.slider.setValue(int(round(val * self.scale)))
        self.slider.blockSignals(False)
        self.valueChanged.emit(val)

    def value(self) -> float:
        return self.spin.value()

    def set_value(self, val: float):
        for w in (self.slider, self.spin):
            w.blockSignals(True)
        self.spin.setValue(val)
        self.slider.setValue(int(round(val * self.scale)))
        for w in (self.slider, self.spin):
            w.blockSignals(False)


def _form() -> QGridLayout:
    g = QGridLayout()
    g.setContentsMargins(28, 12, 18, 12)
    g.setHorizontalSpacing(18)
    g.setVerticalSpacing(14)
    g.setColumnStretch(1, 1)
    return g


def _label(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("MvFormLabel")
    lbl.setMinimumWidth(96)
    return lbl


class _Page(QWidget):
    """A tool page: '«  Title  ✓' bar + content."""

    backRequested = Signal()

    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        bar = QWidget()
        bar.setObjectName("MvToolBar")
        h = QHBoxLayout(bar)
        h.setContentsMargins(8, 4, 8, 4)
        self.btn_back = QToolButton()
        self.btn_back.setIcon(icon("back", 22))
        self.btn_back.setIconSize(icon_size(22))
        self.btn_back.setAutoRaise(True)
        self.btn_back.setToolTip("Back")
        self.title = QLabel(title)
        self.title.setObjectName("MvToolTitle")
        self.btn_ok = QToolButton()
        self.btn_ok.setIcon(icon("check", 22))
        self.btn_ok.setIconSize(icon_size(22))
        self.btn_ok.setAutoRaise(True)
        self.btn_ok.setToolTip("Done")
        h.addWidget(self.btn_back)
        h.addWidget(self.title, 1)
        h.addWidget(self.btn_ok)
        self.btn_back.clicked.connect(self.backRequested.emit)
        self.btn_ok.clicked.connect(self.backRequested.emit)
        self.body = QVBoxLayout()
        self.body.setContentsMargins(0, 0, 0, 0)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(bar)
        lay.addLayout(self.body)
        lay.addStretch(1)


# --------------------------------------------------------------------------- #
class CropPage(_Page):
    def __init__(self, panel: "ToolsPanel"):
        super().__init__("Crop and Rotate")
        self.panel = panel
        g = _form()
        self.angle = SliderRow(-180, 180, 0.1, 1, "°")
        self.angle.valueChanged.connect(self._angle)
        g.addWidget(_label("Angle:"), 0, 0)
        g.addWidget(self.angle, 0, 1)
        self.keep = QCheckBox("Keep proportions")
        self.keep.setToolTip("The crop box keeps the video's shape, so the export has no "
                             "black bars")
        self.keep.toggled.connect(self.panel.cropKeepAspect.emit)
        g.addWidget(self.keep, 1, 1)
        self.zoom = SliderRow(100, 150, 1, 0, " %")
        self.zoom.setToolTip("Zoom into the centre of the picture. 105-115 % makes the "
                             "video look different from the original upload "
                             "(shown after Apply).")
        self.zoom.valueChanged.connect(self._zoom)
        g.addWidget(_label("Zoom:"), 2, 0)
        g.addWidget(self.zoom, 2, 1)
        self.btn_bars = QPushButton("Remove black bars")
        self.btn_bars.setObjectName("MvApply")
        self.btn_bars.setToolTip("Find black borders around the picture and crop them off")
        self.btn_bars.clicked.connect(self.panel.blackBarsRequested.emit)
        g.addWidget(self.btn_bars, 3, 1, Qt.AlignmentFlag.AlignLeft)
        self.readout = QLabel("")
        self.readout.setObjectName("MvMuted")
        g.addWidget(self.readout, 4, 1)
        row = QHBoxLayout()
        self.btn_apply = QPushButton("Apply")
        self.btn_apply.setObjectName("MvApply")
        self.btn_apply.clicked.connect(self.backRequested.emit)
        self.btn_reset = QPushButton("Reset")
        self.btn_reset.setObjectName("MvApply")
        self.btn_reset.clicked.connect(self._reset)
        row.addWidget(self.btn_apply)
        row.addWidget(self.btn_reset)
        row.addStretch(1)
        g.addLayout(row, 5, 0, 1, 2)
        hint = QLabel("Drag the dashed box on the video: the corners and sides resize it, "
                      "the inside moves it. Everything outside the box is cut off.")
        hint.setWordWrap(True)
        hint.setObjectName("MvMuted")
        g.addWidget(hint, 6, 0, 1, 2)
        self.body.addLayout(g)

    def load(self, p: Project):
        self.angle.set_value(float(p.rotate or 0.0))
        self.zoom.set_value(round(float(p.zoom or 1.0) * 100))
        self.show_crop(p)

    def show_crop(self, p: Project):
        def pc(v):
            return f"{float(v or 0) * 100:.0f}%"
        self.readout.setText(f"Cut:  left {pc(p.crop_left)} · top {pc(p.crop_top)} · "
                             f"right {pc(p.crop_right)} · bottom {pc(p.crop_bottom)}")

    def _angle(self, v: float):
        self.panel.edit("crop", lambda p: setattr(p, "rotate", round(v, 1)))

    def _zoom(self, v: float):
        self.panel.edit("crop", lambda p: setattr(p, "zoom", round(v / 100.0, 3)))

    def _reset(self):
        def do(p):
            p.crop_left = p.crop_top = p.crop_right = p.crop_bottom = 0.0
            p.rotate = 0.0
            p.zoom = 1.0
        self.panel.edit("crop", do)
        self.load(self.panel.project)


# --------------------------------------------------------------------------- #
class ColorPage(_Page):
    """Movavi: an 'auto' view (4 checkboxes + Manual Adjustments) and a
    'manual' view (9 sliders + Auto Adjustments)."""

    AUTO = [("color_auto_saturation", "Auto saturation"),
            ("color_auto_contrast", "Auto contrast"),
            ("color_magic", "Magic Enhance"),
            ("color_auto_wb", "Auto white balance")]
    # field, label, lo, hi, step, decimals
    MANUAL = [("color_brightness", "Brightness", -100, 100, 1, 0),
              ("color_contrast", "Contrast", -100, 100, 1, 0),
              ("saturation", "Saturation", 0, 2, 0.01, 2),
              ("color_highlights", "Highlights", -100, 100, 1, 0),
              ("color_gamma", "Gamma", 0.2, 3, 0.01, 2),
              ("color_shadows", "Shadows", -100, 100, 1, 0),
              ("color_hue", "Hue", -180, 180, 1, 0),
              ("color_temperature", "Temperature", -100, 100, 1, 0),
              ("color_tint", "Tint", -100, 100, 1, 0)]

    def __init__(self, panel: "ToolsPanel"):
        super().__init__("Color Adjustments")
        self.panel = panel
        self.views = QStackedWidget()

        # --- auto view
        auto = QWidget()
        g = _form()
        self.checks = {}
        for r, (field, text) in enumerate(self.AUTO):
            cb = QCheckBox(text)
            cb.toggled.connect(lambda on, f=field: self.panel.edit(
                "color", lambda p: setattr(p, f, on)))
            self.checks[field] = cb
            g.addWidget(cb, r, 0, 1, 2)
        b_manual = QPushButton("Manual Adjustments")
        b_manual.setObjectName("MvApply")
        b_manual.clicked.connect(lambda: self.views.setCurrentIndex(1))
        g.addWidget(b_manual, len(self.AUTO), 0, 1, 2, Qt.AlignmentFlag.AlignLeft)
        auto.setLayout(g)

        # --- manual view
        manual = QWidget()
        mg = _form()
        self.sliders = {}
        for k, (field, text, lo, hi, step, dec) in enumerate(self.MANUAL):
            s = SliderRow(lo, hi, step, dec)
            s.valueChanged.connect(lambda v, f=field: self._set(f, v))
            self.sliders[field] = s
            mg.addWidget(_label(text), k, 0)
            mg.addWidget(s, k, 1)
        row = QHBoxLayout()
        b_auto = QPushButton("Auto Adjustments")
        b_auto.setObjectName("MvApply")
        b_auto.clicked.connect(lambda: self.views.setCurrentIndex(0))
        b_reset = QPushButton("Reset")
        b_reset.setObjectName("MvApply")
        b_reset.clicked.connect(self._reset)
        row.addWidget(b_auto)
        row.addWidget(b_reset)
        row.addStretch(1)
        mg.addLayout(row, len(self.MANUAL), 0, 1, 2)
        manual.setLayout(mg)

        self.views.addWidget(auto)
        self.views.addWidget(manual)
        self.body.addWidget(self.views)
        hint = QLabel("The preview shows the colours when the video is paused "
                      "(the export always has them).")
        hint.setWordWrap(True)
        hint.setObjectName("MvMuted")
        hint.setContentsMargins(28, 4, 18, 0)
        self.body.addWidget(hint)

    def _set(self, field: str, v: float):
        if field == "saturation":           # shown as 0 .. 2 (1.00 = unchanged)
            self.panel.edit("color", lambda p: setattr(p, "color_saturation",
                                                       round((v - 1.0) * 100, 2)))
        else:
            self.panel.edit("color", lambda p: setattr(p, field, float(v)))

    def load(self, p: Project):
        for field, cb in self.checks.items():
            cb.blockSignals(True)
            cb.setChecked(bool(getattr(p, field)))
            cb.blockSignals(False)
        for field, s in self.sliders.items():
            if field == "saturation":
                s.set_value(1.0 + float(p.color_saturation or 0) / 100.0)
            else:
                s.set_value(float(getattr(p, field) or (1.0 if field == "color_gamma" else 0)))

    def _reset(self):
        self.panel.edit("color", lambda p: effects.reset_color(p, manual=True, auto=False))
        self.load(self.panel.project)


# --------------------------------------------------------------------------- #
class FxRow(QPushButton):
    """'○  Equalizer  »' row (● when the effect is on), opens a sub-page."""

    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setObjectName("MvFxRow")
        self.active = False
        self.setMinimumHeight(38)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def set_active(self, on: bool):
        self.active = on
        self.update()

    def paintEvent(self, event):
        from PySide6.QtGui import QColor, QPainter, QPen

        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = self.rect()
        p.fillRect(r, QColor("#343948") if self.underMouse() else QColor("#1f222b"))
        p.setPen(QPen(QColor("#e8eaf0"), 1.6))
        p.setBrush(QColor("#2fd59a") if self.active else Qt.BrushStyle.NoBrush)
        p.drawEllipse(r.left() + 12, r.center().y() - 7, 14, 14)
        f = p.font()
        f.setPointSize(11)
        p.setFont(f)
        p.drawText(r.adjusted(38, 0, -40, 0), Qt.AlignmentFlag.AlignVCenter, self.text())
        from ui.icons import pixmap

        p.drawPixmap(r.right() - 32, r.center().y() - 10, pixmap("chevrons", 20))
        p.end()


class ClipPage(QWidget):
    """Movavi 'Clip Properties': Video | Audio tabs."""

    def __init__(self, panel: "ToolsPanel"):
        super().__init__()
        self.panel = panel
        self.target: Optional[AudioClip] = None      # None = the video's own sound
        tabs = QHBoxLayout()
        tabs.setSpacing(0)
        self.tab_video = QPushButton("Video")
        self.tab_audio = QPushButton("Audio")
        for b, i in ((self.tab_video, 0), (self.tab_audio, 1)):
            b.setObjectName("MvTab")
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, i=i: self.show_tab(i))
            tabs.addWidget(b)
        self.stack = QStackedWidget()
        self.stack.addWidget(self._video_tab())
        self.stack.addWidget(self._audio_tab())
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addLayout(tabs)
        lay.addWidget(self.stack)
        lay.addStretch(1)
        self._last_volume = 100.0

    def show_tab(self, i: int):
        self.stack.setCurrentIndex(i)
        self.tab_video.setChecked(i == 0)
        self.tab_audio.setChecked(i == 1)

    # ---------------- Video tab
    def _video_tab(self) -> QWidget:
        """Movavi's Video tab: Volume · Normalize · Speed · Duration · Fades.
        Speed is the whole finished video: the AI voice is made to fit the
        original speech first, then the video can be made faster here."""
        w = QWidget()
        g = _form()
        # the video's own sound (the same values as Audio tab > Original sound)
        self.v_volume = SliderRow(0, 300, 1, 0, " %")
        self.v_volume.valueChanged.connect(lambda v: self.panel.edit(
            "audio", lambda p: setattr(p, "original_volume", v / 100.0)))
        self.v_btn_mute = QToolButton()
        self.v_btn_mute.setIcon(icon("volume", 18))
        self.v_btn_mute.setAutoRaise(True)
        self.v_btn_mute.setToolTip("Mute / unmute the original sound")
        self.v_btn_mute.clicked.connect(self._v_mute)
        row = QHBoxLayout()
        row.addWidget(self.v_volume, 1)
        row.addWidget(self.v_btn_mute)
        g.addWidget(_label("Volume:"), 0, 0)
        g.addLayout(row, 0, 1)
        self.v_normalize = QCheckBox()
        self.v_normalize.toggled.connect(lambda on: self.panel.edit(
            "audio", lambda p: setattr(p, "orig_normalize", on)))
        g.addWidget(_label("Normalize:"), 1, 0)
        g.addWidget(self.v_normalize, 1, 1)

        self.v_speed = SliderRow(50, 200, 1, 0, " %")
        self.v_speed.setToolTip("The whole video: picture, original sound, AI voice and "
                                "subtitles together (the voices keep their pitch)")
        self.v_speed.valueChanged.connect(self._v_speed)
        g.addWidget(_label("Speed:"), 2, 0)
        g.addWidget(self.v_speed, 2, 1)
        self.v_duration = QLabel("")
        self.v_duration.setObjectName("MvValue")
        g.addWidget(_label("Duration:"), 3, 0)
        g.addWidget(self.v_duration, 3, 1)

        self.v_fade_in = SliderRow(0, 10, 0.1, 1, " sec.")
        self.v_fade_in.valueChanged.connect(lambda v: self.panel.edit(
            "video", lambda p: setattr(p, "video_fade_in", v)))
        self.v_fade_out = SliderRow(0, 10, 0.1, 1, " sec.")
        self.v_fade_out.valueChanged.connect(lambda v: self.panel.edit(
            "video", lambda p: setattr(p, "video_fade_out", v)))
        g.addWidget(_label("Fade in:"), 4, 0)
        g.addWidget(self.v_fade_in, 4, 1)
        g.addWidget(_label("Fade out:"), 5, 0)
        g.addWidget(self.v_fade_out, 5, 1)
        note = QLabel("Speed changes the whole exported video - the AI voice keeps its "
                      "pitch and stays on the lips. Fades go from / to black.")
        note.setObjectName("MvMuted")
        note.setWordWrap(True)
        g.addWidget(note, 6, 0, 1, 2)
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        lay.addLayout(g)
        for text, tool in (("Crop and Rotate", "crop"), ("Color Adjustments", "color"),
                           ("Video Ratio (Project settings)", "ratio")):
            row = FxRow(text)
            row.clicked.connect(lambda _=False, t=tool: self.panel.switch_tool(t))
            lay.addWidget(row)
        return w

    def _v_speed(self, v: float):
        self.panel.edit("video", lambda p: setattr(p, "video_speed", round(v / 100.0, 2)))
        if self.panel.project is not None:
            self._show_duration(self.panel.project)

    def _show_duration(self, p: Project):
        from core.media import format_time

        out = p.output_duration()
        text = format_time(out)
        if abs(p.speed() - 1.0) > 0.001:
            text += f"   (was {format_time(p.sequence_duration(), False)})"
        self.v_duration.setText(text)

    def _v_mute(self):
        v = self.v_volume.value()
        new = 0 if v > 0 else (self._last_volume or 100)
        if v > 0:
            self._last_volume = v
        self.v_volume.set_value(new)
        self.panel.edit("audio", lambda p: setattr(p, "original_volume", new / 100.0))

    # ---------------- Audio tab
    def _audio_tab(self) -> QWidget:
        w = QWidget()
        g = _form()
        self.who = QLabel("")
        self.who.setObjectName("MvToolTarget")
        self.who.setWordWrap(True)
        g.addWidget(self.who, 0, 0, 1, 2)

        self.volume = SliderRow(0, 300, 1, 0, " %")
        self.volume.valueChanged.connect(self._volume)
        self.btn_mute = QToolButton()
        self.btn_mute.setIcon(icon("volume", 18))
        self.btn_mute.setAutoRaise(True)
        self.btn_mute.setToolTip("Mute / unmute")
        self.btn_mute.clicked.connect(self._mute)
        vol_row = QHBoxLayout()
        vol_row.addWidget(self.volume, 1)
        vol_row.addWidget(self.btn_mute)
        g.addWidget(_label("Volume:"), 1, 0)
        g.addLayout(vol_row, 1, 1)

        self.normalize = QCheckBox()
        self.normalize.toggled.connect(self._normalize)
        g.addWidget(_label("Normalize:"), 2, 0)
        g.addWidget(self.normalize, 2, 1)

        # the original sound only: keep it all, or music & effects without voices
        self.bg_mode = QComboBox()
        for key, text in BG_MODES.items():
            self.bg_mode.addItem(text, key)
        self.bg_mode.setToolTip(
            "Music & effects only: every original voice is taken out of the video's "
            "sound\n(AI, ~1 min per 2 min of video the first time), so only the music "
            "and effects\nare heard under the AI voice. Volume above = how loud.")
        self.bg_mode.currentIndexChanged.connect(self._bg_mode)
        self.lbl_bg = _label("Keep:")
        g.addWidget(self.lbl_bg, 7, 0)
        g.addWidget(self.bg_mode, 7, 1)

        self.speed = SliderRow(50, 200, 1, 0, " %")
        self.btn_speed = QPushButton("Apply")
        self.btn_speed.setObjectName("MvApply")
        self.btn_speed.setToolTip("Make the selected AI voice faster / slower (pitch kept)")
        self.btn_speed.clicked.connect(self._speed)
        sp_row = QHBoxLayout()
        sp_row.addWidget(self.speed, 1)
        sp_row.addWidget(self.btn_speed)
        self.lbl_speed = _label("Speed:")
        g.addWidget(self.lbl_speed, 3, 0)
        g.addLayout(sp_row, 3, 1)

        self.fade_in = SliderRow(0, 10, 0.1, 1, " sec.")
        self.fade_in.valueChanged.connect(lambda v: self._fade("in", v))
        self.fade_out = SliderRow(0, 10, 0.1, 1, " sec.")
        self.fade_out.valueChanged.connect(lambda v: self._fade("out", v))
        g.addWidget(_label("Fade in:"), 4, 0)
        g.addWidget(self.fade_in, 4, 1)
        g.addWidget(_label("Fade out:"), 5, 0)
        g.addWidget(self.fade_out, 5, 1)

        self.all_voices = QCheckBox("Apply to all AI voice clips")
        g.addWidget(self.all_voices, 6, 0, 1, 2)

        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)
        lay.addLayout(g)
        self.rows = {}
        for key, text in (("eq", "Equalizer"), ("noise", "Noise Removal"),
                          ("effects", "Audio Effects")):
            row = FxRow(text)
            row.clicked.connect(lambda _=False, k=key: self.panel.open_sub(k))
            self.rows[key] = row
            lay.addWidget(row)
        self.btn_listen = QPushButton("  Listen (8 sec.)")
        self.btn_listen.setIcon(icon("play_small", 14))
        self.btn_listen.setObjectName("MvApply")
        self.btn_listen.setToolTip("Hear the sound with Equalizer / Noise Removal / Effects")
        self.btn_listen.clicked.connect(lambda: self.panel.previewRequested.emit(self.track()))
        lr = QHBoxLayout()
        lr.setContentsMargins(28, 12, 18, 0)
        lr.addWidget(self.btn_listen)
        lr.addStretch(1)
        lay.addLayout(lr)
        self.note = QLabel("")
        self.note.setObjectName("MvMuted")
        self.note.setWordWrap(True)
        self.note.setContentsMargins(28, 8, 18, 0)
        lay.addWidget(self.note)
        return w

    def _bg_mode(self, *_):
        mode = self.bg_mode.currentData()
        self.panel.edit("audio", lambda p: setattr(p, "bg_mode", mode))

    def track(self) -> str:
        return "voice" if self.target is not None else "orig"

    def _voices(self, p: Project) -> List[AudioClip]:
        if self.target is None:
            return []
        music = any(c.id == self.target.id for c in getattr(p, "music_clips", []))
        if music:                       # a 🎵 Music clip: just that one
            return [c for c in p.music_clips if c.id == self.target.id]
        if self.all_voices.isChecked():
            return list(p.audio_clips)
        return [c for c in p.audio_clips if c.id == self.target.id]

    def load(self, p: Project, clip: Optional[AudioClip]):
        self.target = clip
        voice = clip is not None
        self.v_fade_in.set_value(float(p.video_fade_in or 0))
        self.v_fade_out.set_value(float(p.video_fade_out or 0))
        self.v_volume.set_value(round(p.original_volume * 100))
        self.v_normalize.blockSignals(True)
        self.v_normalize.setChecked(bool(p.orig_normalize))
        self.v_normalize.blockSignals(False)
        self.v_speed.set_value(round(p.speed() * 100))
        self._show_duration(p)
        for w in (self.lbl_speed, self.speed, self.btn_speed, self.all_voices):
            w.setVisible(voice)
        for w in (self.lbl_bg, self.bg_mode):
            w.setVisible(not voice)
        self.bg_mode.blockSignals(True)
        self.bg_mode.setCurrentIndex(max(0, self.bg_mode.findData(
            getattr(p, "bg_mode", "original"))))
        self.bg_mode.blockSignals(False)
        music = voice and any(c.id == clip.id for c in getattr(p, "music_clips", []))
        if music:
            for w in (self.lbl_speed, self.speed, self.btn_speed, self.all_voices):
                w.setVisible(False)
        if voice:
            text = (clip.label or "AI voice").replace("\n", " ")
            self.who.setText(f"🎵  Music clip:  {text[:60]}" if music else
                             f"🎙  AI voice clip:  {text[:60]}")
            self.volume.set_value(round(clip.volume * 100))
            self.normalize.blockSignals(True)
            self.normalize.setChecked(bool(clip.normalize))
            self.normalize.blockSignals(False)
            self.speed.set_value(round(float(clip.speed or 1.0) * 100))
            mx = max(0.1, round(clip.length / 2, 1))
            for s in (self.fade_in, self.fade_out):
                s.slider.setMaximum(int(mx * s.scale))
                s.spin.setMaximum(mx)
            self.fade_in.set_value(clip.fade_in)
            self.fade_out.set_value(clip.fade_out)
            self.note.setText("Volume and fades are this music clip's own. Equalizer, Noise "
                              "Removal and Audio Effects apply to the AI voice and the music "
                              "together." if music else
                              "Equalizer, Noise Removal and Audio Effects apply to the "
                              "whole AI voice track (every AI voice clip).")
        else:
            self.who.setText("🎞  Original sound of the video  (select an AI voice clip "
                             "on the timeline to edit the AI voice instead)")
            self.volume.set_value(round(p.original_volume * 100))
            self.normalize.blockSignals(True)
            self.normalize.setChecked(bool(p.orig_normalize))
            self.normalize.blockSignals(False)
            for s in (self.fade_in, self.fade_out):
                s.slider.setMaximum(int(10 * s.scale))
                s.spin.setMaximum(10)
            self.fade_in.set_value(p.orig_fade_in)
            self.fade_out.set_value(p.orig_fade_out)
            self.note.setText("Volume is the background level of the original sound in the "
                              "export (also in the Export window). The original speech is "
                              "still muted where the AI voice speaks.")
        self.refresh_rows(p)

    def refresh_rows(self, p: Project):
        act = effects.track_active(p, self.track())
        for k, row in self.rows.items():
            row.set_active(act[k])

    def _volume(self, v: float):
        if self.target is None:
            self.panel.edit("audio", lambda p: setattr(p, "original_volume", v / 100.0))
        else:
            self.panel.edit("voice", lambda p: [setattr(c, "volume", v / 100.0)
                                                for c in self._voices(p)])

    def _mute(self):
        v = self.volume.value()
        if v > 0:
            self._last_volume = v
            self.volume.set_value(0)
            self._volume(0)
        else:
            self.volume.set_value(self._last_volume or 100)
            self._volume(self._last_volume or 100)

    def _normalize(self, on: bool):
        if self.target is None:
            self.panel.edit("audio", lambda p: setattr(p, "orig_normalize", on))
        else:
            self.panel.edit("voice", lambda p: [setattr(c, "normalize", on)
                                                for c in self._voices(p)])

    def _fade(self, which: str, v: float):
        if self.target is None:
            self.panel.edit("audio", lambda p: setattr(p, f"orig_fade_{which}", v))
        else:
            def do(p):
                for c in self._voices(p):
                    setattr(c, f"fade_{which}", min(v, c.length / 2))
            self.panel.edit("voice", do)

    def _speed(self):
        if self.target is None:
            return
        ids = [c.id for c in self._voices(self.panel.project)]
        self.panel.voiceSpeedRequested.emit(ids, self.speed.value() / 100.0)


# --------------------------------------------------------------------------- #
def _track_label(track: str) -> str:
    return ("For: the AI voice track (every AI voice clip)" if track == "voice"
            else "For: the original sound of the video")


class EqPage(_Page):
    def __init__(self, panel: "ToolsPanel"):
        super().__init__("Equalizer")
        self.panel = panel
        self.track = "orig"
        g = _form()
        self.who = QLabel("")
        self.who.setObjectName("MvToolTarget")
        g.addWidget(self.who, 0, 0, 1, 2)
        self.preset = QComboBox()
        for key, label in effects.EQ_PRESET_LABELS.items():
            self.preset.addItem(label, key)
        self.preset.model().item(0).setEnabled(False)       # "Custom" = set by hand
        self.preset.currentIndexChanged.connect(self._preset)
        g.addWidget(_label("Preset:"), 1, 0)
        g.addWidget(self.preset, 1, 1)
        self.body.addLayout(g)

        bands = QHBoxLayout()
        bands.setContentsMargins(20, 6, 18, 0)
        scale = QVBoxLayout()
        for t in ("+20 dB", "", "0 dB", "", "-20 dB"):
            lbl = QLabel(t)
            lbl.setObjectName("MvMuted")
            scale.addWidget(lbl, 1)
        scale.addSpacing(22)
        bands.addLayout(scale)
        self.bands: List[QSlider] = []
        for k, name in enumerate(effects.EQ_LABELS):
            col = QVBoxLayout()
            s = QSlider(Qt.Orientation.Vertical)
            s.setObjectName("MvEq")
            s.setRange(-20, 20)
            s.setMinimumHeight(150)
            s.setTickPosition(QSlider.TickPosition.TicksBothSides)
            s.setTickInterval(5)
            s.valueChanged.connect(lambda v, k=k: self._band(k, v))
            s.setToolTip(name)
            num, unit = name.split(" ")
            lbl = QLabel(f"{num}\n{unit}")         # two lines: no overlap
            lbl.setObjectName("MvMuted")
            lbl.setStyleSheet("font-size: 10px;")
            lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter)
            col.addWidget(s, 1, Qt.AlignmentFlag.AlignHCenter)
            col.addWidget(lbl)
            bands.addLayout(col)
            self.bands.append(s)
        self.body.addLayout(bands)
        self.body.addLayout(_listen_row(self))

    def load(self, p: Project, track: str):
        self.track = track
        self.who.setText(_track_label(track))
        pre = "voice" if track == "voice" else "orig"
        gains = list(getattr(p, f"{pre}_eq") or [0.0] * 10)
        for s, g in zip(self.bands, gains):
            s.blockSignals(True)
            s.setValue(int(round(g)))
            s.setToolTip(f"{int(round(g)):+d} dB")
            s.blockSignals(False)
        self.preset.blockSignals(True)
        idx = self.preset.findData(getattr(p, f"{pre}_eq_preset") or "flat")
        self.preset.setCurrentIndex(max(0, idx))
        self.preset.blockSignals(False)

    def _field(self):
        return "voice_eq" if self.track == "voice" else "orig_eq"

    def _preset(self, _i):
        key = self.preset.currentData()
        gains = effects.EQ_PRESETS.get(key)
        if gains is None:
            return
        f = self._field()

        def do(p):
            setattr(p, f, [float(x) for x in gains])
            setattr(p, f + "_preset", key)
        self.panel.edit("audio", do)
        self.load(self.panel.project, self.track)

    def _band(self, k: int, v: int):
        f = self._field()
        self.bands[k].setToolTip(f"{v:+d} dB")

        def do(p):
            gains = list(getattr(p, f) or [0.0] * 10)
            gains[k] = float(v)
            setattr(p, f, gains)                      # a new list (Undo keeps the old)
            setattr(p, f + "_preset", "custom")
        self.panel.edit("audio", do)
        self.preset.blockSignals(True)
        self.preset.setCurrentIndex(0)
        self.preset.blockSignals(False)


class NoisePage(_Page):
    def __init__(self, panel: "ToolsPanel"):
        super().__init__("Noise Removal")
        self.panel = panel
        self.track = "orig"
        g = _form()
        self.who = QLabel("")
        self.who.setObjectName("MvToolTarget")
        g.addWidget(self.who, 0, 0, 1, 2)
        self.enable = QCheckBox("Remove background noise")
        self.enable.toggled.connect(lambda on: self.panel.edit(
            "audio", lambda p: setattr(p, self._pre() + "_denoise", on)))
        g.addWidget(self.enable, 1, 0, 1, 2)
        self.strength = SliderRow(0, 100, 1, 0, " %")
        self.strength.valueChanged.connect(lambda v: self.panel.edit(
            "audio", lambda p: setattr(p, self._pre() + "_denoise_strength", v)))
        g.addWidget(_label("Strength:"), 2, 0)
        g.addWidget(self.strength, 2, 1)
        hint = QLabel("Reduces hiss, hum and wind. Too strong can make speech sound "
                      "metallic - listen and adjust.")
        hint.setObjectName("MvMuted")
        hint.setWordWrap(True)
        g.addWidget(hint, 3, 0, 1, 2)
        self.body.addLayout(g)
        self.body.addLayout(_listen_row(self))

    def _pre(self):
        return "voice" if self.track == "voice" else "orig"

    def load(self, p: Project, track: str):
        self.track = track
        self.who.setText(_track_label(track))
        self.enable.blockSignals(True)
        self.enable.setChecked(bool(getattr(p, self._pre() + "_denoise")))
        self.enable.blockSignals(False)
        self.strength.set_value(float(getattr(p, self._pre() + "_denoise_strength")))


class EffectsPage(_Page):
    def __init__(self, panel: "ToolsPanel"):
        super().__init__("Audio Effects")
        self.panel = panel
        self.track = "orig"
        g = _form()
        self.who = QLabel("")
        self.who.setObjectName("MvToolTarget")
        g.addWidget(self.who, 0, 0, 1, 2)
        self.combo = QComboBox()
        for key, (label, _f) in effects.AUDIO_EFFECTS.items():
            self.combo.addItem(label, key)
        self.combo.currentIndexChanged.connect(lambda _i: self.panel.edit(
            "audio", lambda p: setattr(p, self._pre() + "_effect", self.combo.currentData())))
        g.addWidget(self.combo, 1, 0, 1, 2)
        self.body.addLayout(g)
        self.body.addLayout(_listen_row(self))

    def _pre(self):
        return "voice" if self.track == "voice" else "orig"

    def load(self, p: Project, track: str):
        self.track = track
        self.who.setText(_track_label(track))
        self.combo.blockSignals(True)
        self.combo.setCurrentIndex(max(0, self.combo.findData(
            getattr(p, self._pre() + "_effect") or "none")))
        self.combo.blockSignals(False)


def _listen_row(page) -> QHBoxLayout:
    b = QPushButton("  Listen (8 sec.)")
    b.setIcon(icon("play_small", 14))
    b.setObjectName("MvApply")
    b.clicked.connect(lambda: page.panel.previewRequested.emit(page.track))
    row = QHBoxLayout()
    row.setContentsMargins(28, 14, 18, 0)
    row.addWidget(b)
    row.addStretch(1)
    return row


def _ratio_icon(ratio):
    """A frame drawn with the ratio's shape (dashed = keep original)."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap

    size = 112
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    pen = QPen(QColor("#e8eaf0"), 5)
    if ratio is None:
        pen.setStyle(Qt.PenStyle.DashLine)
        w, h = 90, 64
    else:
        rw, rh = ratio
        s = 92 / max(rw, rh)
        w, h = rw * s, rh * s
    p.setPen(pen)
    p.drawRoundedRect(QRectF((size - w) / 2, (size - h) / 2, w, h), 8, 8)
    p.end()
    pm.setDevicePixelRatio(2)
    return QIcon(pm)


# --------------------------------------------------------------------------- #
class ToolsPanel(QScrollArea):
    changing = Signal(str)          # before the first change of a session (undo)
    changed = Signal(str)           # "crop" / "color" / "audio" / "voice" / "video"
    closed = Signal(str)            # tool that was open
    cropKeepAspect = Signal(bool)
    voiceSpeedRequested = Signal(list, float)
    previewRequested = Signal(str)  # "orig" / "voice" - listen with the effects
    toolSwitchRequested = Signal(str)
    blackBarsRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setMinimumWidth(400)
        self.project: Optional[Project] = None
        self.tool = ""
        inner = QWidget()
        inner.setObjectName("MvTools")
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        head = QLabel("Tools")
        head.setObjectName("MvToolsHead")
        head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(head)
        self.stack = QStackedWidget()
        self.crop = CropPage(self)
        self.color = ColorPage(self)
        self.clip = ClipPage(self)
        self.eq = EqPage(self)
        self.noise = NoisePage(self)
        self.fx = EffectsPage(self)
        self.audio = self.clip                       # old name
        for page in (self.crop, self.color, self.clip, self.eq, self.noise, self.fx):
            self.stack.addWidget(page)
        for page in (self.crop, self.color):
            page.backRequested.connect(self.close_tool)
        for page in (self.eq, self.noise, self.fx):     # sub-pages go back to the clip page
            page.backRequested.connect(self._back_to_clip)
        lay.addWidget(self.stack, 1)
        self.setWidget(inner)
        self._started = False
        self._voice_clip: Optional[AudioClip] = None

    def open_tool(self, tool: str, project: Project, voice_clip: Optional[AudioClip] = None):
        """tool: crop / color / audio (Clip Properties, Audio tab) /
        video (Clip Properties, Video tab)."""
        self.project = project
        if tool != self.tool:
            self._started = False
        self.tool = tool
        self._voice_clip = voice_clip
        if tool in ("audio", "video"):
            self.clip.load(project, voice_clip)
            self.clip.show_tab(1 if tool == "audio" else 0)
            self.stack.setCurrentWidget(self.clip)
            return
        page = {"crop": self.crop, "color": self.color}[tool]
        page.load(project)
        self.stack.setCurrentWidget(page)

    def open_sub(self, key: str):
        page = {"eq": self.eq, "noise": self.noise, "effects": self.fx}[key]
        page.load(self.project, self.clip.track())
        self.stack.setCurrentWidget(page)

    def _back_to_clip(self):
        self.clip.refresh_rows(self.project)
        self.stack.setCurrentWidget(self.clip)

    def switch_tool(self, tool: str):
        self.toolSwitchRequested.emit(tool)

    def edit(self, kind: str, fn):
        """Change the project: one Undo step per tool session."""
        if self.project is None:
            return
        if not self._started:
            self._started = True
            self.changing.emit(kind)
        fn(self.project)
        self.changed.emit(kind)

    def crop_from_preview(self, l, t, r, b):
        def do(p):
            p.crop_left, p.crop_top, p.crop_right, p.crop_bottom = l, t, r, b
        self.edit("crop", do)
        self.crop.show_crop(self.project)

    def close_tool(self):
        tool, self.tool = self.tool, ""
        self.closed.emit(tool)
