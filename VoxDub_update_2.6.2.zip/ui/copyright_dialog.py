"""
copyright_dialog.py - "© Copyright check".

Three honest checks before a dubbed video goes online:
  1. Rights   – the Rights log of the story (who owns it, licence, until when)
  2. Music    – known songs in the sound (AudD, with the user's own token)
  3. YouTube  – the only real Content ID check: upload as Private / Unlisted
                and read YouTube Studio › Checks before making it public
No program outside YouTube / Facebook can promise "no claim".
"""

import os
from typing import Optional

from PySide6.QtCore import QDate, Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDateEdit, QDialog, QFileDialog, QFormLayout,
    QHBoxLayout, QHeaderView, QInputDialog, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget,
)

from core import music_check, rights
from ui.workers import TaskWorker

STATE_STYLE = {
    "ok": ("✅", "#15302b", "#7ff0da"),
    "soon": ("⏳", "#3a2e14", "#ffcf6b"),
    "expired": ("⛔", "#3a1c1e", "#ff9a9a"),
    "missing": ("⚠", "#3a2e14", "#ffcf6b"),
}
YT_STEPS = (
    "1. Export the video as usual.\n"
    "2. In YouTube Studio click Create › Upload videos and choose the video.\n"
    "3. On the Visibility step choose Private (or Unlisted) – NOT Public.\n"
    "4. Wait for “Checks” to finish (a few minutes). It says “No issues found” or "
    "shows the copyright claim: what was found, at which minute, and who claims it.\n"
    "5. Only when it is clean, change the video to Public.\n\n"
    "This is the same Content ID check YouTube runs after publishing, so it is the "
    "only check that tells what YouTube will do. Facebook: Creator Studio / "
    "Meta Business Suite shows a rights warning for a scheduled post in the same way.")


def status_label(state: str, text: str) -> QLabel:
    icon, bg, fg = STATE_STYLE.get(state, STATE_STYLE["missing"])
    lb = QLabel(f"{icon}  {text}")
    lb.setWordWrap(True)
    lb.setStyleSheet(f"background: {bg}; color: {fg}; border-radius: 8px; padding: 8px 10px;")
    return lb


class CopyrightDialog(QDialog):
    def __init__(self, parent, video_path: str, story: str = "", sound_path: str = ""):
        super().__init__(parent)
        self.setWindowTitle("© Copyright check")
        self.resize(760, 600)
        self.video_path = video_path
        self.sound_path = sound_path            # music & effects only track, if made
        self.key = rights.story_key(video_path, story)
        self._worker: Optional[TaskWorker] = None
        lay = QVBoxLayout(self)
        head = QLabel(f"<b>{os.path.basename(video_path) or 'No video'}</b>"
                      f" &nbsp;·&nbsp; story: <b>{self.key or '—'}</b>")
        lay.addWidget(head)
        warn = QLabel("No program can promise that YouTube or Facebook will not claim a video – "
                      "only their own check can. These three steps help you see the risk before "
                      "you publish.")
        warn.setObjectName("MutedLabel")
        warn.setWordWrap(True)
        lay.addWidget(warn)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._rights_tab(), "1 · Rights")
        self.tabs.addTab(self._music_tab(), "2 · Music")
        self.tabs.addTab(self._youtube_tab(), "3 · YouTube check")
        lay.addWidget(self.tabs, 1)
        row = QHBoxLayout()
        row.addStretch(1)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        lay.addLayout(row)
        self._load_rights()

    # ------------------------------------------------------------------ #
    # 1. Rights
    # ------------------------------------------------------------------ #
    def _rights_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        self.banner_box = QVBoxLayout()
        v.addLayout(self.banner_box)
        f = QFormLayout()
        self.cmb_kind = QComboBox()
        for k, name in rights.KINDS:
            self.cmb_kind.addItem(name, k)
        self.ed_owner = QLineEdit()
        self.ed_owner.setPlaceholderText("e.g. the production company / platform that owns the drama")
        self.ed_source = QLineEdit()
        self.ed_source.setPlaceholderText("How: contract no., e-mail, distributor …")
        self.chk_end = QCheckBox("Ends on")
        self.dt_end = QDateEdit()
        self.dt_end.setCalendarPopup(True)
        self.dt_end.setDisplayFormat("yyyy-MM-dd")
        self.dt_end.setDate(QDate.currentDate().addYears(1))
        self.chk_end.toggled.connect(self.dt_end.setEnabled)
        end = QHBoxLayout()
        end.addWidget(self.chk_end)
        end.addWidget(self.dt_end, 1)
        self.ed_contract = QLineEdit()
        self.ed_contract.setPlaceholderText("The contract / permission (PDF, image …)")
        b_pick = QPushButton("…")
        b_pick.setFixedWidth(34)
        b_pick.clicked.connect(self._pick_contract)
        b_open = QPushButton("Open")
        b_open.clicked.connect(lambda: self.ed_contract.text() and QDesktopServices.openUrl(
            QUrl.fromLocalFile(self.ed_contract.text())))
        con = QHBoxLayout()
        con.addWidget(self.ed_contract, 1)
        con.addWidget(b_pick)
        con.addWidget(b_open)
        self.ed_platforms = QLineEdit()
        self.ed_platforms.setPlaceholderText("Where it may be posted: YouTube, Facebook, TikTok …")
        self.ed_notes = QPlainTextEdit()
        self.ed_notes.setFixedHeight(70)
        f.addRow("Rights", self.cmb_kind)
        f.addRow("Owner", self.ed_owner)
        f.addRow("Source", self.ed_source)
        f.addRow("Licence", end)
        f.addRow("Contract", con)
        f.addRow("Platforms", self.ed_platforms)
        f.addRow("Notes", self.ed_notes)
        v.addLayout(f)
        save = QPushButton("💾  Save for this story")
        save.setObjectName("AccentButton")
        save.clicked.connect(self._save_rights)
        self.lb_saved = QLabel("")
        self.lb_saved.setStyleSheet("color: #7ff0da;")
        srow = QHBoxLayout()
        srow.addWidget(self.lb_saved, 1)
        srow.addWidget(save)
        v.addLayout(srow)
        hint = QLabel("Saved for every episode of this story. Export and Batch warn you when a "
                      "story has no rights, or when its licence has ended.")
        hint.setObjectName("MutedLabel")
        hint.setWordWrap(True)
        v.addWidget(hint)
        v.addStretch(1)
        return w

    def _load_rights(self):
        e = rights.get(self.key)
        self.cmb_kind.setCurrentIndex(max(0, self.cmb_kind.findData(e.get("kind", "unknown"))))
        self.ed_owner.setText(e.get("owner", ""))
        self.ed_source.setText(e.get("source", ""))
        until = e.get("valid_until", "")
        self.chk_end.setChecked(bool(until))
        self.dt_end.setEnabled(bool(until))
        if until:
            self.dt_end.setDate(QDate.fromString(until, "yyyy-MM-dd"))
        self.ed_contract.setText(e.get("contract", ""))
        self.ed_platforms.setText(e.get("platforms", ""))
        self.ed_notes.setPlainText(e.get("notes", ""))
        self._show_banner(e)

    def _show_banner(self, e: dict):
        while self.banner_box.count():
            it = self.banner_box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        state, text = rights.status(e)
        self.state = state
        self.banner_box.addWidget(status_label(state, text))

    def _pick_contract(self):
        path, _ = QFileDialog.getOpenFileName(self, "Contract / permission", "",
                                              "Documents (*.pdf *.png *.jpg *.jpeg *.docx);;"
                                              "All files (*)")
        if path:
            self.ed_contract.setText(path)

    def rights_entry(self) -> dict:
        return {"kind": self.cmb_kind.currentData(), "owner": self.ed_owner.text().strip(),
                "source": self.ed_source.text().strip(),
                "valid_until": self.dt_end.date().toString("yyyy-MM-dd")
                if self.chk_end.isChecked() else "",
                "contract": self.ed_contract.text().strip(),
                "platforms": self.ed_platforms.text().strip(),
                "notes": self.ed_notes.toPlainText().strip()}

    def _save_rights(self):
        import time

        rights.put(self.key, self.rights_entry())
        self._show_banner(rights.get(self.key))
        self.lb_saved.setText(f"✓ Saved for “{self.key}” at {time.strftime('%H:%M')}")

    # ------------------------------------------------------------------ #
    # 2. Music
    # ------------------------------------------------------------------ #
    def _music_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        about = QLabel("Background music is the most common reason for a claim. This listens to "
                       "10 s of the sound every 30 s and lists the songs the AudD music service "
                       "knows, with the minute they play – take them out or replace them before "
                       "you upload. Uses your own AudD API token (audd.io, paid per request).")
        about.setWordWrap(True)
        v.addWidget(about)
        row = QHBoxLayout()
        self.lb_token = QLabel()
        b_tok = QPushButton("🔑  AudD API token…")
        b_tok.clicked.connect(self._set_token)
        row.addWidget(self.lb_token, 1)
        row.addWidget(b_tok)
        v.addLayout(row)
        self.chk_bg = QCheckBox("Check the background track that is exported (music & effects "
                                "only)")
        self.chk_bg.setChecked(bool(self.sound_path and os.path.isfile(self.sound_path)))
        self.chk_bg.setVisible(bool(self.sound_path and os.path.isfile(self.sound_path)))
        v.addWidget(self.chk_bg)
        self.btn_scan = QPushButton("🎵  Find songs")
        self.btn_scan.setObjectName("AccentButton")
        self.btn_scan.clicked.connect(self.scan_music)
        v.addWidget(self.btn_scan, 0, Qt.AlignmentFlag.AlignLeft)
        self.lb_music = QLabel("")
        self.lb_music.setObjectName("MutedLabel")
        self.lb_music.setWordWrap(True)
        v.addWidget(self.lb_music)
        self.tbl = QTableWidget(0, 4)
        self.tbl.setHorizontalHeaderLabels(["Time", "Song", "Artist", "Link"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        h = self.tbl.horizontalHeader()
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.tbl.cellDoubleClicked.connect(self._open_link)
        v.addWidget(self.tbl, 1)
        self._show_token()
        return w

    def _show_token(self):
        ok = music_check.configured()
        self.lb_token.setText("AudD token: saved" if ok else "AudD token: not set")
        self.btn_scan.setEnabled(ok and bool(self.video_path))

    def _set_token(self):
        token, ok = QInputDialog.getText(self, "AudD API token",
                                         "Paste your AudD API token (from dashboard.audd.io):",
                                         QLineEdit.EchoMode.Password)
        if ok and token.strip():
            music_check.set_token(token)
        self._show_token()

    def scan_music(self, recognize=None):
        if self._worker is not None and self._worker.isRunning():
            return
        src = self.sound_path if self.chk_bg.isChecked() else self.video_path
        self.btn_scan.setEnabled(False)
        self.tbl.setRowCount(0)
        self.lb_music.setText("Listening…")
        self._worker = TaskWorker(lambda prog, stop: music_check.scan(
            src, progress=prog, should_stop=stop, recognize=recognize), "Music check", self)
        self._worker.progress.connect(lambda p, m: self.lb_music.setText(m))

        def done(hits):
            self.btn_scan.setEnabled(True)
            self.hits = hits
            self.tbl.setRowCount(len(hits))
            for r, h in enumerate(hits):
                when = f"{int(h['start'] // 60)}:{int(h['start'] % 60):02d} – " \
                       f"{int(h['end'] // 60)}:{int(h['end'] % 60):02d}"
                for c, text in enumerate((when, h.get("title", ""), h.get("artist", ""),
                                          "open" if h.get("link") else "")):
                    it = QTableWidgetItem(text)
                    if c == 3:
                        it.setData(Qt.ItemDataRole.UserRole, h.get("link", ""))
                    self.tbl.setItem(r, c, it)
            self.lb_music.setText(
                f"⚠ {len(hits)} known song(s) found – a likely reason for a claim. Remove or "
                "replace them, or lower “Music & ambience” there." if hits else
                "✅ No known song found in the samples (the picture and unknown music are not "
                "checked – still do step 3).")

        def failed(e):
            self.btn_scan.setEnabled(True)
            self.lb_music.setText(f"Music check failed: {e}")

        self._worker.done.connect(done)
        self._worker.failed.connect(failed)
        self._worker.start()

    def _open_link(self, row, col):
        it = self.tbl.item(row, 3)
        link = it.data(Qt.ItemDataRole.UserRole) if it else ""
        if link:
            QDesktopServices.openUrl(QUrl(link))

    # ------------------------------------------------------------------ #
    # 3. YouTube
    # ------------------------------------------------------------------ #
    def _youtube_tab(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        steps = QLabel(YT_STEPS)
        steps.setWordWrap(True)
        v.addWidget(steps)
        row = QHBoxLayout()
        b = QPushButton("▶  Open YouTube Studio")
        b.setObjectName("AccentButton")
        b.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://studio.youtube.com")))
        row.addWidget(b)
        row.addStretch(1)
        v.addLayout(row)
        v.addStretch(1)
        return w

    def done(self, r):
        if self._worker is not None and self._worker.isRunning():
            self._worker.stop()
            self._worker.wait(5000)
        super().done(r)


def warn_before_export(parent, video_path: str, story: str = "") -> bool:
    """Export / Batch: a story with no rights, or an ended licence, asks first.
    True = go on."""
    key, state, text = rights.check(video_path, story)
    if state in ("ok", "soon"):
        return True
    box = QMessageBox(parent)
    box.setWindowTitle("Rights")
    box.setIcon(QMessageBox.Icon.Warning)
    box.setText(f"“{key}”: {text}")
    box.setInformativeText("Posting a video without the rights can bring a copyright claim or "
                           "a strike on the channel. Export anyway?")
    go = box.addButton("Export anyway", QMessageBox.ButtonRole.AcceptRole)
    rec = box.addButton("Record the rights…", QMessageBox.ButtonRole.ActionRole)
    box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
    box.exec()
    if box.clickedButton() is go:
        return True
    if box.clickedButton() is rec:
        CopyrightDialog(parent, video_path, story).exec()
    return False

