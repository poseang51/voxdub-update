"""
greenscreen_dialog.py - Style › 🟩 Green screen: intro, outro, Like &
Subscribe, moving logo (a clip with a green / blue background laid over the
video when it is exported). Preview shows the finished picture.
"""

import copy
import os

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QPixmap
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QColorDialog, QComboBox, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QSlider, QSpinBox, QVBoxLayout, QWidget,
)

from core import greenscreen as gs

VIDEO_FILTER = "Videos (*.mp4 *.mov *.webm *.mkv *.avi *.m4v)"


class GreenScreenDialog(QDialog):
    def __init__(self, project, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Green screen – intro / outro / Like & Subscribe / logo")
        self.setMinimumSize(980, 600)
        self.project = project
        self.items = copy.deepcopy(list(getattr(project, "green_overlays", None) or []))
        self._loading = False

        lay = QHBoxLayout(self)
        left = QVBoxLayout()
        self.lst = QListWidget()
        self.lst.setMinimumWidth(240)
        self.lst.currentRowChanged.connect(self._show)
        left.addWidget(self.lst, 1)
        row = QHBoxLayout()
        b_add = QPushButton("＋ Add clip…")
        b_add.clicked.connect(self.add)
        b_del = QPushButton("✕ Remove")
        b_del.clicked.connect(self.remove)
        row.addWidget(b_add)
        row.addWidget(b_del)
        left.addLayout(row)
        hint = QLabel("A video with a green (or blue) background: the colour is cut out "
                      "and the clip plays over your video when you Export.")
        hint.setWordWrap(True)
        hint.setObjectName("MutedLabel")
        left.addWidget(hint)
        lay.addLayout(left)

        self.form_w = QWidget()
        f = QFormLayout(self.form_w)
        self.chk_on = QCheckBox("Use this clip")
        self.ed_path = QLineEdit()
        self.ed_path.setReadOnly(True)
        b_pick = QPushButton("…")
        b_pick.setFixedWidth(34)
        b_pick.clicked.connect(self.pick)
        pr = QHBoxLayout()
        pr.addWidget(self.ed_path, 1)
        pr.addWidget(b_pick)
        self.lb_info = QLabel("")
        self.lb_info.setObjectName("MutedLabel")
        self.cmb_kind = QComboBox()
        for k, v in gs.KINDS.items():
            self.cmb_kind.addItem(v, k)
        self.cmb_mode = QComboBox()
        for k, v in gs.MODES.items():
            self.cmb_mode.addItem(v, k)
        self.sp_every = QDoubleSpinBox()
        self.sp_every.setRange(0.5, 60)
        self.sp_every.setSingleStep(0.5)
        self.sp_every.setSuffix(" min")
        self.sp_start = QDoubleSpinBox()
        self.sp_start.setRange(0, 36000)
        self.sp_start.setSuffix(" s")
        self.cmb_pos = QComboBox()
        for c in gs.CORNERS:
            self.cmb_pos.addItem(gs.CORNER_LABELS[c], c)
        self.sp_size = QSpinBox()
        self.sp_size.setRange(3, 100)
        self.sp_size.setSuffix(" % width")
        self.cmb_key = QComboBox()
        for k, v in gs.KEYS.items():
            self.cmb_key.addItem(v, k)
        self.cmb_key.addItem("Other colour…", "custom")
        self.sl_sim = QSlider(Qt.Orientation.Horizontal)
        self.sl_sim.setRange(1, 60)
        self.sl_blend = QSlider(Qt.Orientation.Horizontal)
        self.sl_blend.setRange(0, 40)
        self.chk_sound = QCheckBox("Play its sound")
        self.sp_vol = QSpinBox()
        self.sp_vol.setRange(0, 200)
        self.sp_vol.setSuffix(" %")
        sr = QHBoxLayout()
        sr.addWidget(self.chk_sound)
        sr.addWidget(self.sp_vol)
        sr.addStretch(1)
        f.addRow("", self.chk_on)
        f.addRow("Clip", pr)
        f.addRow("", self.lb_info)
        f.addRow("What is it", self.cmb_kind)
        f.addRow("When", self.cmb_mode)
        f.addRow("Every", self.sp_every)
        f.addRow("First at", self.sp_start)
        f.addRow("Position", self.cmb_pos)
        f.addRow("Size", self.sp_size)
        f.addRow("Background colour", self.cmb_key)
        f.addRow("Cut-out strength", self.sl_sim)
        f.addRow("Smooth edge", self.sl_blend)
        f.addRow("Sound", sr)

        right = QVBoxLayout()
        right.addWidget(self.form_w)
        self.preview = QLabel("Preview")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumHeight(220)
        self.preview.setStyleSheet("background:#0b0e17;border:1px solid #2a3142;border-radius:6px;")
        b_prev = QPushButton("👁  Preview")
        b_prev.clicked.connect(self.show_preview)
        right.addWidget(b_prev, 0, Qt.AlignmentFlag.AlignLeft)
        right.addWidget(self.preview, 1)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                              | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        right.addWidget(bb)
        lay.addLayout(right, 1)

        for w, sig in ((self.chk_on, "toggled"), (self.cmb_mode, "currentIndexChanged"),
                       (self.sp_every, "valueChanged"), (self.sp_start, "valueChanged"),
                       (self.cmb_pos, "currentIndexChanged"), (self.sp_size, "valueChanged"),
                       (self.sl_sim, "valueChanged"), (self.sl_blend, "valueChanged"),
                       (self.chk_sound, "toggled"), (self.sp_vol, "valueChanged")):
            getattr(w, sig).connect(self._save)
        self.cmb_kind.currentIndexChanged.connect(self._kind)
        self.cmb_key.activated.connect(self._key)
        self._fill_list()

    # ------------------------------------------------------------------ #
    def _label(self, d: dict) -> str:
        name = os.path.basename(d.get("path", "")) or "(no clip)"
        kind = gs.KINDS.get(d.get("kind"), "")
        off = "" if d.get("on", True) else "  (off)"
        miss = "⚠ " if d.get("path") and not os.path.isfile(d["path"]) else ""
        return f"{miss}{kind} · {name}{off}"

    def _fill_list(self, row: int = 0):
        self.lst.blockSignals(True)
        self.lst.clear()
        for d in self.items:
            self.lst.addItem(QListWidgetItem(self._label(d)))
        self.lst.blockSignals(False)
        self.form_w.setEnabled(bool(self.items))
        if self.items:
            self.lst.setCurrentRow(max(0, min(row, len(self.items) - 1)))
            self._show(self.lst.currentRow())

    def _cur(self):
        r = self.lst.currentRow()
        return self.items[r] if 0 <= r < len(self.items) else None

    def _show(self, r: int):
        if not 0 <= r < len(self.items):
            return
        d = {**gs.DEFAULT, **self.items[r]}
        self._loading = True
        self.chk_on.setChecked(bool(d.get("on", True)))
        self.ed_path.setText(d["path"])
        dur, snd = gs.clip_info(d["path"]) if d["path"] else (0.0, False)
        self.lb_info.setText(f"{dur:.1f} s" + (" · with sound" if snd else " · no sound")
                             if dur else "")
        self.cmb_kind.setCurrentIndex(max(0, self.cmb_kind.findData(d["kind"])))
        self.cmb_mode.setCurrentIndex(max(0, self.cmb_mode.findData(d["mode"])))
        self.sp_every.setValue(float(d["every_min"]))
        self.sp_start.setValue(float(d["start_sec"]))
        self.cmb_pos.setCurrentIndex(max(0, self.cmb_pos.findData(d["corner"])))
        self.sp_size.setValue(int(round(float(d["size"]) * 100)))
        i = self.cmb_key.findData(d["key"].upper())
        if i < 0:
            self.cmb_key.insertItem(self.cmb_key.count() - 1, d["key"].upper(), d["key"].upper())
            i = self.cmb_key.findData(d["key"].upper())
        self.cmb_key.setCurrentIndex(i)
        self.sl_sim.setValue(int(round(float(d["similarity"]) * 100)))
        self.sl_blend.setValue(int(round(float(d["blend"]) * 100)))
        self.chk_sound.setChecked(bool(d["sound"]))
        self.sp_vol.setValue(int(round(float(d["volume"]) * 100)))
        self._loading = False
        self._enable()

    def _enable(self):
        mode = self.cmb_mode.currentData()
        self.sp_every.setEnabled(mode == "every")
        self.sp_start.setEnabled(mode in ("start", "every"))
        self.sp_size.setEnabled(self.cmb_pos.currentData() != "full")

    def _save(self, *_):
        if self._loading:
            return
        d = self._cur()
        if d is None:
            return
        key = self.cmb_key.currentData()
        d.update(on=self.chk_on.isChecked(), mode=self.cmb_mode.currentData(),
                 every_min=self.sp_every.value(), start_sec=self.sp_start.value(),
                 corner=self.cmb_pos.currentData(), size=self.sp_size.value() / 100,
                 similarity=self.sl_sim.value() / 100, blend=self.sl_blend.value() / 100,
                 sound=self.chk_sound.isChecked(), volume=self.sp_vol.value() / 100)
        if key and key != "custom":
            d["key"] = key
        self.lst.currentItem().setText(self._label(d))
        self._enable()

    def _kind(self, *_):
        """A new kind: its usual timing / place (the clip stays)."""
        if self._loading:
            return
        d = self._cur()
        if d is None:
            return
        kind = self.cmb_kind.currentData()
        d.update(kind=kind, **gs.KIND_DEFAULTS.get(kind, {}))
        self._show(self.lst.currentRow())
        self.lst.currentItem().setText(self._label(d))

    def _key(self, *_):
        if self.cmb_key.currentData() != "custom":
            self._save()
            return
        d = self._cur()
        c = QColorDialog.getColor(QColor(d.get("key", "#00FF00")) if d else QColor("#00FF00"),
                                  self, "Background colour of the clip")
        if c.isValid() and d is not None:
            d["key"] = c.name().upper()
        self._show(self.lst.currentRow())

    # ------------------------------------------------------------------ #
    def add(self, path: str = "", kind: str = ""):
        if not path:
            path, _ = QFileDialog.getOpenFileName(self, "Green screen clip", "", VIDEO_FILTER)
        if not path:
            return
        if not kind:
            name = os.path.basename(path).lower()
            kind = ("intro" if "intro" in name else "outro" if "outro" in name else
                    "subscribe" if any(w in name for w in ("sub", "like", "follow", "bell"))
                    else "logo" if "logo" in name else "subscribe")
        self.items.append(gs.new_overlay(path, kind))
        self._fill_list(len(self.items) - 1)

    def pick(self):
        d = self._cur()
        if d is None:
            return
        path, _ = QFileDialog.getOpenFileName(self, "Green screen clip",
                                              os.path.dirname(d.get("path", "")), VIDEO_FILTER)
        if path:
            d["path"] = path
            self._show(self.lst.currentRow())
            self.lst.currentItem().setText(self._label(d))

    def remove(self):
        r = self.lst.currentRow()
        if 0 <= r < len(self.items):
            del self.items[r]
            self._fill_list(r)

    def show_preview(self):
        """The exported picture when the chosen clip is on screen."""
        import tempfile

        from core.export import ExportOptions, render_frame

        d = self._cur()
        p = self.project
        if d is None or not p.has_video():
            return
        trial = copy.copy(p)
        trial.green_overlays = [x for x in self.items]
        its = [x for x in gs.items(trial) if x["index"] == self.lst.currentRow()]
        if not its:
            self.preview.setText("This clip is off or its file was not found.")
            return
        it = its[0]
        total = p.output_duration()
        t = min(total - 0.05, gs.start_of(it, total) + min(1.0, it["duration"] / 2))
        out = os.path.join(tempfile.gettempdir(), "voxdub_greenscreen_preview.png")
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            render_frame(trial, ExportOptions(output_path="x", resolution="720p"), max(0.0, t),
                         out)
            pm = QPixmap(out)
            self.preview.setPixmap(pm.scaled(self.preview.size(),
                                             Qt.AspectRatioMode.KeepAspectRatio,
                                             Qt.TransformationMode.SmoothTransformation))
        except Exception as e:
            self.preview.setText(f"Could not make the preview:\n{e}")
        finally:
            QApplication.restoreOverrideCursor()

    def result_items(self):
        return copy.deepcopy(self.items)
