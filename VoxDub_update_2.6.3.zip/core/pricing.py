"""
pricing.py - The licence prices customers see on the Plan & licence page.

The Admin sets them (Help › Admin › 💲 Prices, or ✏ Edit prices on the Plan &
licence page). They are kept in three places, read in this order:

  1. the Admin's PC:  %USERPROFILE%\\.voxdub_admin\\prices.json
  2. the internet:    "prices" in version.json (Help › Check for updates) -
                      change the prices for every customer without a new build
  3. the program:     assets/prices.json (shipped by build_exe.bat; the Admin's
                      save also writes it in the source folder)
  4. DEFAULT below

    {"currency": "$", "contact": "Telegram 0xx xxx xxx",
     "pay": "ABA / KHQR", "note": "",
     "items": [{"days": 30, "label": "1 month", "price": 15}, ...]}
"""

import json
import os
from typing import Dict, List, Optional

from . import settings
from .media import APP_DIR

REMOTE_SETTING = "prices_remote"
DEFAULT: Dict = {
    "currency": "$",
    "contact": "",
    "pay": "ABA / KHQR",
    "note": "",
    "items": [
        {"days": 30, "label": "1 month", "price": 15},
        {"days": 90, "label": "3 months", "price": 39},
        {"days": 180, "label": "6 months", "price": 69},
        {"days": 365, "label": "1 year", "price": 119},
    ],
}


def _admin_file() -> str:
    from . import admin

    return os.path.join(admin.ADMIN_DIR, "prices.json")


def asset_file() -> str:
    return os.path.join(APP_DIR, "assets", "prices.json")      # (_internal in the .exe)


def clean(data) -> Optional[Dict]:
    """A checked copy (bad items dropped), or None when nothing usable."""
    if not isinstance(data, dict):
        return None
    items = []
    for it in data.get("items") or []:
        try:
            days = int(it.get("days", 0))
            price = float(it.get("price", 0))
        except (TypeError, ValueError, AttributeError):
            continue
        if days > 0 and price >= 0 and all(i["days"] != days for i in items):
            label = str(it.get("label") or "").strip() or f"{days} days"
            items.append({"days": days, "label": label,
                          "price": int(price) if price == int(price) else round(price, 2)})
    if not items:
        return None
    items.sort(key=lambda i: i["days"])
    out = {k: str(data.get(k, DEFAULT[k]) or "").strip() for k in ("currency", "contact",
                                                                      "pay", "note")}
    out["currency"] = out["currency"] or "$"
    out["items"] = items
    # Help › About: the seller's pages (empty = not shown)
    for k in LINK_KEYS:
        v = str(data.get(k) or "").strip()
        if v:
            out[k] = v
    return out


LINK_KEYS = ("facebook", "telegram_channel", "youtube", "developer", "tutorials")


def link_url(text: str) -> str:
    """A web address from what the Admin typed: 'https://...', 't.me/x',
    '@name' (Telegram), 'facebook.com/x', 'youtube.com/@x' ('' = none)."""
    c = (text or "").strip()
    for part in c.replace(",", " ").split():
        if part.startswith(("http://", "https://")):
            return part
        if part.startswith("t.me/") or part.startswith(("facebook.com/", "www.facebook.com/",
                                                        "fb.com/", "youtube.com/",
                                                        "www.youtube.com/", "youtu.be/")):
            return "https://" + part
        if part.startswith("@") and len(part) > 2:
            return "https://t.me/" + part[1:]
    return ""


def _read(path: str) -> Optional[Dict]:
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return clean(json.load(f))
    except (OSError, ValueError):
        return None


def _is_owner() -> bool:
    try:
        from . import admin

        return admin.is_owner()
    except Exception:
        return False


def load() -> Dict:
    if _is_owner():
        own = _read(_admin_file())
        if own:
            return own
    remote = clean(settings.get(REMOTE_SETTING, None))
    if remote:
        return remote
    return _read(asset_file()) or clean(DEFAULT)


def save(data: Dict) -> Dict:
    """Admin: keep the prices (and put them in the program's assets folder when
    it can be written, so the next build ships them)."""
    data = clean(data)
    if not data:
        raise ValueError("Add at least one price.")
    try:
        from . import payments

        payments.audit("prices_changed", items=", ".join(
            f"{i['label']}={i['price']}" for i in data["items"]), currency=data["currency"])
    except Exception:
        pass                    # (not the seller's PC: nothing to log)
    text = json.dumps(data, ensure_ascii=False, indent=2)
    path = _admin_file()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    try:
        os.makedirs(os.path.dirname(asset_file()), exist_ok=True)
        with open(asset_file(), "w", encoding="utf-8") as f:
            f.write(text)
    except OSError:
        pass                    # installed copy in Program Files: not writable
    return data


def take_remote(info: dict) -> None:
    """version.json may carry "prices": keep them for the Plan page."""
    p = clean((info or {}).get("prices"))
    if p:
        settings.set(REMOTE_SETTING, p)


def money(value, currency: str = "$") -> str:
    v = float(value)
    num = f"{int(v):,}" if v == int(v) else f"{v:,.2f}"
    return f"{currency}{num}" if len(currency) <= 1 else f"{num} {currency}"


def months(item: Dict) -> int:
    """Whole months in a duration: 30 -> 1, 90 -> 3, 180 -> 6, 365 -> 12."""
    return max(1, int(round(int(item["days"]) / 30.4)))


def per_month(item: Dict) -> float:
    return float(item["price"]) / months(item)


def saving(item: Dict, items: List[Dict]) -> int:
    """Percent saved per month against the shortest duration (0 = none)."""
    base = min(items, key=lambda i: i["days"])
    if item is base or per_month(base) <= 0:
        return 0
    return max(0, int(round(100 * (1 - per_month(item) / per_month(base)))))


def best(items: List[Dict]) -> Optional[Dict]:
    """The longest duration is shown as "Best value" when it saves money."""
    if len(items) < 2:
        return None
    top = max(items, key=lambda i: i["days"])
    return top if saving(top, items) > 0 else None


def label_for(days: int, data: Optional[Dict] = None) -> str:
    """"1 month – $15" for the Admin's duration list ("" when no price)."""
    data = data or load()
    for it in data["items"]:
        if it["days"] == days:
            return f"{it['label']} – {money(it['price'], data['currency'])}"
    return ""


def request_message(item: Dict, machine: str, data: Optional[Dict] = None,
                    order: str = "") -> str:
    """What the customer sends the seller (copied to the clipboard)."""
    from .appinfo import APP_NAME

    data = data or load()
    return (f"សួស្តី! ខ្ញុំចង់ទិញ / បន្ត {APP_NAME} – {item['label']} "
            f"({money(item['price'], data['currency'])}).\n"
            f"Machine ID: {machine}" + (f"\nOrder ID: {order}" if order else ""))


def new_order_id(today=None) -> str:
    """VX-261022-4F2A: the seller matches the payment to this request."""
    import datetime as dt
    import secrets

    d = today or dt.date.today()
    return f"VX-{d:%y%m%d}-{secrets.token_hex(2).upper()}"


def remember_order(order: str, item: Dict, currency: str = "$") -> None:
    """The requests made on this PC (Plan & licence › Recent activity)."""
    import datetime as dt

    lst = [o for o in (settings.get("lic_orders", []) or []) if isinstance(o, dict)
           and o.get("order") != order]
    lst.insert(0, {"order": order, "label": item["label"],
                   "price": money(item["price"], currency),
                   "time": dt.datetime.now().strftime("%Y-%m-%d %H:%M")})
    settings.set("lic_orders", lst[:20])


def orders() -> List[Dict]:
    return [o for o in (settings.get("lic_orders", []) or []) if isinstance(o, dict)]


def parse_request(text: str) -> Dict[str, str]:
    """Admin: the Machine ID, Order ID and duration from a customer's message."""
    import re

    out = {"machine": "", "order": "", "label": "", "days": 0}
    m = re.search(r"\b([0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4})\b", (text or "").upper())
    if m:
        out["machine"] = m.group(1)
    m = re.search(r"\b(VX-\d{6}-[0-9A-F]{4})\b", (text or "").upper())
    if m:
        out["order"] = m.group(1)
    m = re.search(r"–\s*(.+?)\s*\(", text or "")
    if m:
        out["label"] = m.group(1).strip()
        for it in load()["items"]:
            if it["label"] == out["label"]:
                out["days"] = it["days"]
    return out
