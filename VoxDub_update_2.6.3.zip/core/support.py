"""
support.py - Help › Send problem report (2.6.3).

One small zip a customer sends to the admin on Telegram: the app's logs
(the end of voxdub.log, crash_trace.log), the version and update state, this
PC (Windows, GPU, disk space) and the settings WITHOUT any key, password,
token or licence - so the admin sees what happened without asking
"what did you click?".
"""

import datetime as dt
import json
import os
import platform
import zipfile
from typing import Dict, List, Optional

from . import __version__

SECRET_WORDS = ("key", "token", "secret", "password", "passwd", "license", "licence",
                "sig", "cookie", "auth", "email", "phone", "machine")
LOG_TAIL = 1_500_000            # bytes of voxdub.log (the newest part)


def _secret(name: str) -> bool:
    n = name.lower()
    return any(w in n for w in SECRET_WORDS)


def clean_settings(data, depth: int = 0):
    """The settings without anything secret (API keys, licence, e-mail ...)."""
    if depth > 6:
        return "…"
    if isinstance(data, dict):
        return {k: ("(hidden)" if _secret(str(k)) else clean_settings(v, depth + 1))
                for k, v in data.items()}
    if isinstance(data, list):
        return [clean_settings(v, depth + 1) for v in data[:50]]
    if isinstance(data, str) and len(data) > 30 and " " not in data and (
            data.startswith(("AIza", "sk-", "ghp_")) or data.count(".") == 2):
        return "(hidden)"                       # a key typed into some other field
    return data


def system_info() -> Dict[str, str]:
    info = {"app": __version__, "time": dt.datetime.now().isoformat(timespec="seconds"),
            "windows": platform.platform(), "python": platform.python_version()}
    try:
        import patchboot

        info["update_in_use"] = patchboot.active or "installed"
        info["installed"] = patchboot.base_version or ""
        if patchboot.problem:
            info["update_problem"] = patchboot.problem
    except Exception:
        pass
    try:
        from .transcribe import cuda_gpu_count, device_label

        info["nvidia_gpus"] = str(cuda_gpu_count())
        info["whisper_on"] = device_label("small")
    except Exception as e:
        info["gpu"] = f"? {e}"
    try:
        import shutil

        from .media import data_dir

        free = shutil.disk_usage(data_dir()).free / 1e9
        info["free_disk_gb"] = f"{free:.1f}"
    except Exception:
        pass
    return info


def _log_files() -> List[str]:
    from .media import APP_DIR, data_dir

    out = []
    for base in dict.fromkeys((data_dir(), APP_DIR)):
        for name in ("voxdub.log", "voxdub.log.old", "crash_trace.log"):
            p = os.path.join(base, "logs", name)
            if os.path.isfile(p):
                out.append(p)
    return out


def _settings() -> dict:
    try:
        from . import settings

        path = os.path.join(settings.settings_dir(), "settings.json")
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def make_report(folder: Optional[str] = None, note: str = "") -> str:
    """Write SARIKA_VOXDUB_report_<date>.zip (Desktop by default). Returns its path."""
    if not folder:
        desk = os.path.join(os.path.expanduser("~"), "Desktop")
        folder = desk if os.path.isdir(desk) else os.path.expanduser("~")
    os.makedirs(folder, exist_ok=True)
    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M")
    path = os.path.join(folder, f"SARIKA_VOXDUB_report_{stamp}.zip")
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        info = system_info()
        if note:
            info["customer_note"] = note
        z.writestr("about_this_pc.json", json.dumps(info, ensure_ascii=False, indent=1))
        z.writestr("settings_no_keys.json",
                   json.dumps(clean_settings(_settings()), ensure_ascii=False, indent=1))
        for p in _log_files():
            name = os.path.basename(os.path.dirname(os.path.dirname(p))) + "_" + \
                os.path.basename(p)
            try:
                size = os.path.getsize(p)
                with open(p, "rb") as f:
                    if size > LOG_TAIL:
                        f.seek(size - LOG_TAIL)
                    z.writestr(name, f.read())
            except OSError:
                continue
    return path
