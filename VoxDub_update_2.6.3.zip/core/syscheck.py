"""
syscheck.py - Help › System check (2.6.3): is this PC ready to dub?

Every item: (key, name, state, detail, fix). state: "ok" / "warn" (works, but
slower or without a feature) / "bad" (the app cannot dub) / "off" (optional,
not set up). fix: what the button next to it does in the UI ("" = none).
Fast: nothing is downloaded or loaded (no model, no GPU work).
"""

import os
import shutil
from typing import List, NamedTuple


class Item(NamedTuple):
    key: str
    name: str
    state: str
    detail: str
    fix: str = ""


def _whisper_model_found(size: str) -> bool:
    homes = [os.environ.get("HF_HUB_CACHE", ""), os.environ.get("HF_HOME", ""),
             os.path.join(os.path.expanduser("~"), ".cache", "huggingface")]
    for h in filter(None, homes):
        for sub in ("", "hub"):
            d = os.path.join(h, sub, f"models--Systran--faster-whisper-{size}")
            if os.path.isdir(d):
                return True
    return False


def run() -> List[Item]:
    out: List[Item] = []
    # ffmpeg - nothing works without it
    try:
        from .media import find_ffmpeg

        ff = find_ffmpeg()
        out.append(Item("ffmpeg", "FFmpeg (video / sound)", "ok" if ff else "bad",
                        ff or "not found – reinstall SARIKA VOXDUB PRO", ""))
    except Exception as e:
        out.append(Item("ffmpeg", "FFmpeg (video / sound)", "bad", str(e)[:120]))
    # GPU
    try:
        from .transcribe import _add_cuda_dll_dirs, cuda_gpu_count, cudnn_found

        _add_cuda_dll_dirs()        # the CUDA pack (pip nvidia-*) is found like Whisper does
        n = cuda_gpu_count()
        if n and cudnn_found():
            out.append(Item("gpu", "NVIDIA GPU", "ok", f"{n} GPU – Whisper runs fast"))
        elif n:
            out.append(Item("gpu", "NVIDIA GPU", "warn",
                            "found, but the CUDA pack is missing – Whisper runs on the CPU "
                            "(slower)", "cuda"))
        else:
            out.append(Item("gpu", "NVIDIA GPU", "warn",
                            "none – everything works on the CPU, only slower"))
    except Exception as e:
        out.append(Item("gpu", "NVIDIA GPU", "warn", str(e)[:120]))
    # Whisper model
    try:
        from . import settings

        size = settings.get("whisper_model", "small") or "small"
    except Exception:
        size = "small"
    found = _whisper_model_found(size)
    out.append(Item("whisper", f"Speech recognition (Whisper {size})", "ok" if found else "off",
                    "downloaded" if found else
                    "downloads by itself the first time you transcribe (needs internet)"))
    # disk space
    try:
        from .media import data_dir

        free = shutil.disk_usage(data_dir()).free / 1e9
        state = "ok" if free >= 20 else "warn" if free >= 5 else "bad"
        out.append(Item("disk", "Free disk space", state,
                        f"{free:.0f} GB" + ("" if state == "ok" else
                                            " – a Batch of many episodes needs 20 GB or more")))
    except Exception:
        pass
    # Gemini
    try:
        from . import gemini

        n = len(gemini.keys())
        out.append(Item("gemini", "Gemini API key (translation that follows the story, "
                                  "AI check)", "ok" if n else "off",
                        f"{n} key(s)" if n else "not set – Google Translate is used",
                        "" if n else "gemini"))
    except Exception:
        pass
    # OCR
    try:
        from . import ocr_subs

        ok = ocr_subs.available()
        out.append(Item("ocr", "Read the subtitles on the video (OCR)", "ok" if ok else "warn",
                        "ready" if ok else "not installed – no double-check with the screen"))
    except Exception:
        pass
    # Isolate BGM
    try:
        from . import separate

        ok = separate.model_ready()
        out.append(Item("bgm", "Isolate BGM model", "ok" if ok else "off",
                        "downloaded" if ok else "downloads the first time you use Isolate BGM"))
    except Exception:
        pass
    # VoxCPM (optional)
    try:
        from . import voxcpm

        ok = voxcpm.ready()
        out.append(Item("voxcpm", "Voice clone (VoxCPM)", "ok" if ok else "off",
                        "ready" if ok else "optional – run setup_voxcpm.bat to clone voices",
                        "" if ok else "voxcpm"))
    except Exception:
        pass
    return out


def problems(items: List[Item]) -> List[Item]:
    """What is worth showing by itself at the first start."""
    return [i for i in items if i.state in ("bad", "warn")]
