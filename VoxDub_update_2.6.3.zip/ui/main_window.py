"""
main_window.py - SARIKA VOXDUB PRO main window.

Layout
  ┌──────────────── top bar: SARIKA VOXDUB PRO · project · Auto Dub · Export ───────────────┐
  │ Left panel        │          Video preview             │   Right panel (tabs)    │
  │ upload/lang/voice │                                    │ transcript/translation/ │
  │ AI actions        │                                    │ subtitles               │
  ├───────────────────┴────────────────────────────────────┴─────────────────────────┤
  │                      Timeline (video · AI voice · subtitles)                      │
  └───────────────────────────────────────────────────────────────────────────────────┘
"""

import copy
import glob
import json
import os
import sys
import tempfile
import time
from typing import Callable, List, Optional

from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QAction, QCursor, QDesktopServices, QKeySequence, QPixmap
from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QProgressBar,
    QPushButton, QSlider, QSpinBox, QSplitter, QStackedWidget, QToolTip, QVBoxLayout, QWidget,
)

from core import hardsub, pipeline, plans, recent, settings
from core import license as lic
from core.appinfo import EDITION, TITLE
from core.export import ENCODERS, LOUDNESS, ExportOptions, export_video, render_frame
from core.media import (APP_DIR, FROZEN, FFmpegError, default_output_dir, find_ffmpeg,
                        change_speed, format_time, get_media_info, nvenc_available, parse_time)
from core.project import Project, SubtitleClip, new_id
from core.sync import build_subtitles, render_dub_mix, set_clip_speed, write_srt
from core.transcribe import cuda_gpu_count
from core.tts import AUTO_VOICE, azure_configured, synthesize, voice_for_gender
from ui.batch_dialog import BatchDialog
from ui.home_page import HomePage
from ui.merge_split import MergeSplitDialog
from ui.dialogs import AzureKeyDialog, LicenseDialog, ProjectSettingsDialog, apply_azure_settings
from ui.panels import LeftPanel, RightPanel
from ui.style_panel import StylePanel
from ui.timeline import TimelineEditor
from ui.tools_panel import ToolsPanel
from ui.video_player import VideoPlayer
from ui.workers import TaskWorker, wait_for_threads

OUTPUT_DIR = default_output_dir()          # File › Output folder… changes it

SAMPLE_TEXT = {
    "km": "សួស្តី! នេះគឺជាសំឡេង AI សម្រាប់បកប្រែវីដេអូរបស់អ្នក។",
    "en": "Hello! This is the AI voice that will dub your video.",
    "zh": "你好！这是为您的视频配音的人工智能声音。",
    "ja": "こんにちは！これはあなたの動画を吹き替えるAI音声です。",
    "ko": "안녕하세요! 이것은 동영상을 더빙할 AI 음성입니다.",
    "th": "สวัสดี! นี่คือเสียง AI ที่จะพากย์วิดีโอของคุณ",
    "vi": "Xin chào! Đây là giọng nói AI sẽ lồng tiếng cho video của bạn.",
    "fr": "Bonjour ! Voici la voix IA qui doublera votre vidéo.",
    "es": "¡Hola! Esta es la voz de IA que doblará tu video.",
}


# --------------------------------------------------------------------------- #
# Export dialog (options + live progress)
# --------------------------------------------------------------------------- #
class ExportDialog(QDialog):
    def __init__(self, window: "MainWindow"):
        super().__init__(window)
        self.win = window
        self.project = window.project
        self.worker: Optional[TaskWorker] = None
        self._started = 0.0
        self.setWindowTitle("Export dubbed video")
        self.setMinimumWidth(600)

        p = self.project
        stem = os.path.splitext(os.path.basename(p.video_path))[0]
        folder = settings.get("export_folder", "") or OUTPUT_DIR
        if not os.path.isdir(folder):
            folder = OUTPUT_DIR

        # ---- title (the file name) + folder
        self.ed_title = QLineEdit(f"{stem}_dubbed_{p.target_lang}")
        self.ed_title.setPlaceholderText("e.g. រឿងអធិរាជ ភាគ01")
        self.ed_title.setToolTip("The name of the video file (also saved as the video's "
                                 "title inside the MP4)")
        self.ed_folder = QLineEdit(folder)
        b_browse = QPushButton("…")
        b_browse.setFixedWidth(36)
        b_browse.clicked.connect(self._browse)
        path_row = QHBoxLayout()
        path_row.addWidget(self.ed_folder, 1)
        path_row.addWidget(b_browse)
        self.ed_path = QLineEdit()                 # the full path (title + folder)
        self.ed_path.setVisible(False)
        self.lb_file = QLabel("")
        self.lb_file.setObjectName("MutedLabel")
        self.lb_file.setWordWrap(True)
        for ed in (self.ed_title, self.ed_folder):
            ed.textChanged.connect(self._update_path)

        # ---- cut the finished video into parts
        from core import joiner

        self._joiner = joiner
        self.chk_split = QCheckBox("Cut the finished video into parts")
        self.chk_split.setChecked(bool(settings.get("export_split", False)))
        self.spn_part = QSpinBox()
        self.spn_part.setRange(1, 600)
        self.spn_part.setSuffix(" min")
        self.spn_part.setValue(int(settings.get("export_part_min", 10) or 10))
        self.ed_part_name = QLineEdit(settings.get("export_part_name", "") or "")
        self.ed_part_name.setPlaceholderText("Part name, e.g. រឿងអធិរាជ ភាគ{n}  "
                                             "(empty: <title>_part01, _part02 …)")
        self.ed_part_name.setToolTip("{n} = the part number. A number at the end "
                                     "(ភាគ06) is the first part: ភាគ06, ភាគ07 …")
        self.chk_exact = QCheckBox("Exact length (slower)")
        self.chk_exact.setToolTip("Off: fast, a cut lands on the nearest keyframe (a part can "
                                  "be a few seconds longer / shorter).\nOn: every part is "
                                  "exactly that long (encoded again).")
        self.chk_keep_full = QCheckBox("Keep the full video too")
        self.chk_keep_full.setChecked(bool(settings.get("export_keep_full", True)))
        self.lb_parts = QLabel("")
        self.lb_parts.setObjectName("MutedLabel")
        self.lb_parts.setWordWrap(True)
        self.split_box = QWidget()
        sb = QVBoxLayout(self.split_box)
        sb.setContentsMargins(26, 0, 0, 0)
        sb.setSpacing(4)
        r1 = QHBoxLayout()
        r1.addWidget(QLabel("Every"))
        r1.addWidget(self.spn_part)
        for m in (5, 10, 15, 20, 30):
            qb = QPushButton(f"{m}")
            qb.setFixedWidth(38)
            qb.setToolTip(f"{m} minutes")
            qb.clicked.connect(lambda _=False, m=m: self.spn_part.setValue(m))
            r1.addWidget(qb)
        r1.addStretch(1)
        sb.addLayout(r1)
        sb.addWidget(self.ed_part_name)
        r2 = QHBoxLayout()
        r2.addWidget(self.chk_exact)
        r2.addWidget(self.chk_keep_full)
        r2.addStretch(1)
        sb.addLayout(r2)
        sb.addWidget(self.lb_parts)
        self.chk_split.toggled.connect(self._split_changed)
        self.spn_part.valueChanged.connect(self._split_changed)

        self.cmb_res = QComboBox()
        if p.out_ratio != "original" and p.out_width and p.out_height:
            # the exact size chosen in Project settings
            self.cmb_res.addItem(f"Project settings ({p.out_width}x{p.out_height})", "original")
        self.cmb_res.addItem("1080p (Full HD)", "1080p")
        self.cmb_res.addItem("720p (HD)", "720p")
        self.cmb_res.addItem("1440p (2K)", "1440p")
        self.cmb_res.addItem("2160p (4K)", "2160p")
        if not (p.out_ratio != "original" and p.out_width and p.out_height):
            self.cmb_res.addItem("Original size", "original")
        from core import plans
        if not plans.allows("hd_1080p"):         # (Testing: the plan in use)
            self.cmb_res.clear()
            self.cmb_res.addItem(f"720p (HD) – 1080p is in the {plans.needed('hd_1080p')} plan",
                                 "720p")

        self.cmb_quality = QComboBox()
        self.cmb_quality.addItem("High (bigger file)", 18)
        self.cmb_quality.addItem("Normal", 20)
        self.cmb_quality.addItem("Small file", 24)
        self.cmb_quality.setCurrentIndex(1)

        # 2.2 Export Center: presets, frame rate, audio quality, file size
        from core.export import AUDIO_KBPS, FPS_CHOICES, PRESETS

        self.cmb_preset = QComboBox()
        for key, label, _v in PRESETS:
            self.cmb_preset.addItem(label, key)
        self.cmb_preset.activated.connect(self._preset_chosen)
        self.cmb_fps = QComboBox()
        src_fps = float(p.fps or 0.0)
        self.cmb_fps.addItem(f"Same as the video ({src_fps:g} fps)" if src_fps else
                             "Same as the video", 0.0)
        for f in FPS_CHOICES:
            if f >= 23:
                self.cmb_fps.addItem(f"{f:g} fps", float(f))
        i = self.cmb_fps.findData(float(getattr(p, "out_fps", 0.0) or 0.0))
        self.cmb_fps.setCurrentIndex(max(0, i))
        self.cmb_audio = QComboBox()
        self.cmb_audio.addItem("Standard (192 kbps)", 0)
        for k in AUDIO_KBPS:
            if k != 192:
                self.cmb_audio.addItem({128: "Small (128 kbps)", 256: "High (256 kbps)",
                                        320: "Best (320 kbps)"}[k], k)
        self.lb_estimate = QLabel("")
        self.lb_estimate.setObjectName("MutedLabel")
        for cb in (self.cmb_res, self.cmb_quality, self.cmb_fps, self.cmb_audio):
            cb.currentIndexChanged.connect(self._update_estimate)
        for cb in (self.cmb_res, self.cmb_quality, self.cmb_audio):
            cb.activated.connect(lambda *_: self.cmb_preset.setCurrentIndex(0))

        # ---- sound (Sarika Studio style: one clear choice + a hint under it)
        self.chk_drop = QCheckBox("Isolate BGM – remove the original dialogue")
        self.chk_drop.setChecked(getattr(p, "bg_mode", "original") == "music")
        self.chk_drop.setEnabled(p.has_audio)
        self.chk_drop.toggled.connect(self._bg_changed)
        self.sl_orig = QSlider(Qt.Orientation.Horizontal)
        self.sl_orig.setRange(0, 100)
        self.sl_orig.setValue(int(p.original_volume * 100))
        self.lb_orig = QLabel()
        self.sl_dub = QSlider(Qt.Orientation.Horizontal)
        self.sl_dub.setRange(0, 200)
        self.sl_dub.setValue(int(p.dub_volume * 100))
        self.lb_dub = QLabel()
        for sl, lb in ((self.sl_orig, self.lb_orig), (self.sl_dub, self.lb_dub)):
            lb.setFixedWidth(44)
            lb.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            sl.valueChanged.connect(lambda v, lb=lb: lb.setText(f"{v}%"))
            lb.setText(f"{sl.value()}%")
        self.chk_mute = QCheckBox("Mute the original speech where the AI voice speaks")
        self.chk_mute.setChecked(p.mute_original_speech)

        # ---- subtitles & files
        self.chk_burn = QCheckBox("Burn subtitles into the picture")
        self.chk_burn.setChecked(bool(p.shown_subtitles()))
        if p.subs_hidden:
            self.chk_burn.setChecked(False)
            self.chk_burn.setEnabled(False)
            self.chk_burn.setText("Burn subtitles – off: subtitles are hidden (CC)")
        self.chk_srt = QCheckBox("Also export SRT")
        self.chk_srt.setChecked(True)
        self.chk_mp3 = QCheckBox("Also export MP3 (the dubbed sound)")
        self.chk_mp3.setChecked(bool(settings.get("export_mp3", False)))
        self.chk_loud = QCheckBox("Even loudness (-15 LUFS, like YouTube / TikTok)")
        self.chk_loud.setToolTip("The finished sound is made as loud as the platforms play it,\n"
                                 "so viewers do not have to turn the volume up.")
        self.chk_loud.setChecked(bool(settings.get("export_loudness", True)))

        # ---- more settings (folded away)
        self.cmb_encoder = QComboBox()
        for key, label in ENCODERS.items():
            self.cmb_encoder.addItem(label, key)
        self.lb_encoder = QLabel("")
        self.lb_encoder.setObjectName("MutedLabel")
        QTimer.singleShot(0, self._check_nvenc)
        self.ed_font = QLineEdit(window._subtitle_font())
        self.ed_font.setToolTip("Font for burned subtitles. Noto Sans Khmer is bundled in "
                                "assets/fonts; any font installed on Windows also works.")
        self.spn_sub_size = QSpinBox()
        self.spn_sub_size.setRange(50, 200)
        self.spn_sub_size.setSingleStep(10)
        self.spn_sub_size.setSuffix(" %")
        self.spn_sub_size.setValue(int(round(p.subtitle_scale * 100)))
        self.spn_sub_size.setToolTip("100% = sized automatically for the video shape")

        def section(title: str) -> QLabel:
            lb = QLabel(title)
            lb.setObjectName("ExportSection")
            lb.setStyleSheet("font-weight: 600; letter-spacing: 1px; color: #9aa4b2; "
                             "margin-top: 10px;")
            return lb

        def hint(text: str) -> QLabel:
            lb = QLabel(text)
            lb.setObjectName("MutedLabel")
            lb.setWordWrap(True)
            lb.setContentsMargins(26, 0, 0, 4)
            return lb

        def slider_row(label: QLabel, sl: QSlider, val: QLabel) -> QHBoxLayout:
            row = QHBoxLayout()
            row.setContentsMargins(26, 0, 0, 0)
            label.setMinimumWidth(130)
            row.addWidget(label)
            row.addWidget(sl, 1)
            row.addWidget(val)
            return row

        self.lbl_bgvol = QLabel("Music & ambience")
        lay = QVBoxLayout(self)
        lay.setSpacing(4)
        top = QFormLayout()
        top.addRow("Title", self.ed_title)
        top.addRow("Folder", path_row)
        top.addRow("", self.lb_file)
        lay.addLayout(top)

        lay.addWidget(section("PICTURE"))
        pic = QFormLayout()
        pic.addRow("Preset", self.cmb_preset)

        def pair(a, label, b):              # two settings on one row (fits a 1080p screen)
            r = QHBoxLayout()
            r.addWidget(a, 3)
            r.addSpacing(6)
            r.addWidget(QLabel(label))
            r.addWidget(b, 2)
            return r

        pic.addRow("Size", pair(self.cmb_res, "Frame rate", self.cmb_fps))
        pic.addRow("Quality", pair(self.cmb_quality, "Audio", self.cmb_audio))
        pic.addRow("", self.lb_estimate)
        lay.addLayout(pic)

        lay.addWidget(section("SOUND"))
        lay.addWidget(self.chk_drop)
        lay.addWidget(hint("Silences the original actors while keeping the music and "
                           "ambience."))
        lay.addLayout(slider_row(self.lbl_bgvol, self.sl_orig, self.lb_orig))
        mute_row = QHBoxLayout()
        mute_row.setContentsMargins(26, 0, 0, 0)
        mute_row.addWidget(self.chk_mute)
        lay.addLayout(mute_row)
        lay.addLayout(slider_row(QLabel("AI voice"), self.sl_dub, self.lb_dub))

        lay.addWidget(section("SUBTITLES & FILES"))
        lay.addWidget(self.chk_burn)
        lay.addWidget(hint("Permanent on-screen text that cannot be turned off (slower)."))
        lay.addWidget(self.chk_srt)
        lay.addWidget(self.chk_mp3)
        lay.addWidget(self.chk_loud)

        lay.addWidget(section("CUT INTO PARTS"))
        lay.addWidget(self.chk_split)
        lay.addWidget(self.split_box)

        self.btn_more = QPushButton("▸  More settings")
        self.btn_more.setFlat(True)
        self.btn_more.setCheckable(True)
        self.more = QWidget()
        more = QFormLayout(self.more)
        more.setContentsMargins(0, 0, 0, 0)
        enc_row = QHBoxLayout()
        enc_row.addWidget(self.cmb_encoder, 1)
        enc_row.addWidget(self.lb_encoder)
        more.addRow("Encoder", enc_row)
        more.addRow("Subtitle font", self.ed_font)
        more.addRow("Subtitle size", self.spn_sub_size)
        self.more.setVisible(False)
        self.btn_more.toggled.connect(lambda on: (
            self.more.setVisible(on),
            self.btn_more.setText(("▾" if on else "▸") + "  More settings"),
            self.adjustSize()))
        lay.addWidget(self.btn_more, 0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(self.more)

        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.status = QLabel("")
        self.status.setObjectName("MutedLabel")
        self.status.setWordWrap(True)

        self.btn_start = QPushButton("⬆  Export Video")
        self.btn_start.setObjectName("AccentButton")
        self.btn_start.clicked.connect(self._start)
        self.btn_close = QPushButton("Close")
        self.btn_close.clicked.connect(self._close_or_cancel)
        self.btn_open = QPushButton("📂 Open folder")
        self.btn_open.setVisible(False)
        self.btn_open.clicked.connect(self._open_folder)
        btns = QHBoxLayout()
        btns.addWidget(self.btn_open)
        btns.addStretch(1)
        btns.addWidget(self.btn_close)
        btns.addWidget(self.btn_start)

        lay.addSpacing(8)
        lay.addWidget(self.progress)
        lay.addWidget(self.status)
        lay.addLayout(btns)
        self._bg_changed()
        self._update_path()
        self._split_changed()
        self._update_estimate()

    def _preset_chosen(self, *_):
        from core.export import PRESETS

        values = dict((k, v) for k, _l, v in PRESETS).get(self.cmb_preset.currentData())
        if not values:
            return
        res, crf, kbps = values
        key = self.cmb_preset.currentData()
        for cb, v in ((self.cmb_res, res), (self.cmb_quality, crf), (self.cmb_audio, kbps)):
            i = cb.findData(v if not (cb is self.cmb_audio and v == 192) else 0)
            if i >= 0:
                cb.setCurrentIndex(i)
        self.cmb_preset.setCurrentIndex(max(0, self.cmb_preset.findData(key)))
        self._update_estimate()

    def _export_options_for_estimate(self) -> ExportOptions:
        return ExportOptions("x.mp4", self.cmb_res.currentData(),
                             crf=int(self.cmb_quality.currentData()),
                             audio_kbps=int(self.cmb_audio.currentData() or 0))

    def _update_estimate(self, *_):
        """Picture size, frame rate and about how big the file will be."""
        from core.export import canvas_size, estimate_size, size_text

        p = self.project
        old = getattr(p, "out_fps", 0.0)
        try:
            p.out_fps = float(self.cmb_fps.currentData() or 0.0)
            opts = self._export_options_for_estimate()
            w, h = canvas_size(p, opts)
            fps = p.out_fps or float(p.fps or 0.0)
            size = estimate_size(p, opts)
        except Exception:
            self.lb_estimate.setText("")
            return
        finally:
            p.out_fps = old
        self.lb_estimate.setText(f"{w}×{h}" + (f" · {fps:g} fps" if fps else "")
                                 + f" · about {size_text(size)}")

    @staticmethod
    def _plan_watermark() -> str:
        from core import plans
        from core.appinfo import APP_NAME
        return "" if plans.allows("no_watermark") else f"{APP_NAME} · Basic"

    def _bg_changed(self, *_):
        from core import plans
        if self.chk_drop.isChecked() and not plans.allows("music_only"):
            self.chk_drop.setChecked(False)
            QMessageBox.information(self, "Plan", "Removing the original dialogue is in the "
                                    f"{plans.needed('music_only')} plan.")
            return
        music = self.chk_drop.isChecked()
        self.chk_mute.setVisible(not music)       # no original speech left to mute
        if music and self.sl_orig.value() <= 20:
            self.sl_orig.setValue(80)             # the music alone can be louder
        self.lbl_bgvol.setText("Music & ambience" if music else "Original sound")
        self.sl_orig.setToolTip("0% = silent · 100% = as loud as in the video")
        if not self.worker:
            self.status.setText(self._note())

    def _note(self) -> str:
        if self.chk_drop.isChecked():
            from core.separate import has_music, model_ready

            note = "The original voices are taken out; the music and ambience stay."
            if not has_music(self.project):
                note += (" The first export of this video takes a little longer "
                         "(~1 min per 2 min of video)")
                note += "." if model_ready() else ", and a 64 MB model is downloaded once."
        else:
            note = ("The original sound stays in the background at the volume above "
                    "(0% = removed).")
        if lic.watermark_text():
            note = (f"⚠ Trial: the video gets the watermark “{lic.TRIAL_WATERMARK}”. "
                    "Help > License to activate.\n" + note)
        return note

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Save the video in", self.ed_folder.text())
        if d:
            self.ed_folder.setText(d)

    def title(self) -> str:
        """The typed title, without characters Windows does not allow in a file name."""
        t = "".join(c for c in self.ed_title.text().strip()
                    if c not in '<>:"/\\|?*' and ord(c) >= 32).strip(" .")
        if t.lower().endswith(".mp4"):
            t = t[:-4].strip(" .")
        return t

    def _update_path(self, *_):
        title = self.title() or "video"
        path = os.path.join(self.ed_folder.text().strip() or OUTPUT_DIR, title + ".mp4")
        self.ed_path.setText(path)
        self.lb_file.setText(f"File: {path}" + ("   ⚠ already exists – it will be replaced"
                                               if os.path.exists(path) else ""))
        if hasattr(self, "lb_parts"):
            self._split_changed()

    def parts_folder(self) -> str:
        return os.path.join(self.ed_folder.text().strip() or OUTPUT_DIR,
                            f"{self.title() or 'video'} - parts")

    def _split_changed(self, *_):
        on = self.chk_split.isChecked()
        self.split_box.setVisible(on)
        if not on:
            self.adjustSize()
            return
        total = self.project.output_duration() or 0.0
        sec = self.spn_part.value() * 60.0
        cuts = self._joiner.plan_split(total, sec, 60.0)
        if not cuts:
            self.lb_parts.setText(f"The video is {format_time(total, False)} – shorter than "
                                  f"{self.spn_part.value()} min: nothing to cut.")
        else:
            lens = self._joiner.part_lengths(total, cuts)
            self.lb_parts.setText(
                f"{format_time(total, False)} → {len(lens)} parts ("
                + ", ".join(format_time(x, False) for x in lens[:6])
                + (" …" if len(lens) > 6 else "")
                + f") in the folder “{os.path.basename(self.parts_folder())}”.")
        self.adjustSize()

    def _start(self):
        if not self.title():
            QMessageBox.information(self, "Export", "Type a title for the video first.")
            self.ed_title.setFocus()
            return
        self._update_path()
        out = self.ed_path.text().strip()
        if not out:
            return
        if not out.lower().endswith(".mp4"):
            out += ".mp4"
        if os.path.abspath(out) == os.path.abspath(self.project.video_path):
            QMessageBox.warning(self, "Export", "Choose a different file than the source video.")
            return
        from ui.copyright_dialog import warn_before_export
        if not warn_before_export(self, self.project.video_path):
            return
        self.project.original_volume = self.sl_orig.value() / 100.0
        self.project.dub_volume = self.sl_dub.value() / 100.0
        self.project.mute_original_speech = self.chk_mute.isChecked()
        self.project.bg_mode = "music" if self.chk_drop.isChecked() else "original"
        settings.set("export_mp3", self.chk_mp3.isChecked())
        settings.set("export_loudness", self.chk_loud.isChecked())
        self.project.subtitle_scale = self.spn_sub_size.value() / 100.0
        self.project.out_fps = float(self.cmb_fps.currentData() or 0.0)
        opts = ExportOptions(
            output_path=out,
            resolution=self.cmb_res.currentData(),
            burn_subtitles=self.chk_burn.isChecked(),
            export_srt=self.chk_srt.isChecked(),
            export_mp3=self.chk_mp3.isChecked(),
            original_volume=self.project.original_volume,
            dub_volume=self.project.dub_volume,
            crf=int(self.cmb_quality.currentData()),
            subtitle_font=self.ed_font.text().strip() or "Arial",
            encoder=self.cmb_encoder.currentData(),
            watermark=lic.watermark_text() or self._plan_watermark(),
            title=self.title(),
            audio_kbps=int(self.cmb_audio.currentData() or 0),
            loudness=LOUDNESS if self.chk_loud.isChecked() else 0.0,
        )
        settings.set("export_folder", os.path.dirname(out))
        split = self.chk_split.isChecked()
        settings.set("export_split", split)
        settings.set("export_part_min", self.spn_part.value())
        settings.set("export_part_name", self.ed_part_name.text().strip())
        settings.set("export_keep_full", self.chk_keep_full.isChecked())
        part_sec = self.spn_part.value() * 60.0
        part_name = self.ed_part_name.text().strip() or self._joiner.part_template(self.title())
        exact, keep_full = self.chk_exact.isChecked(), self.chk_keep_full.isChecked()
        parts_dir = self.parts_folder()
        snapshot = copy.deepcopy(self.project)
        joiner = self._joiner

        def job(prog, stop):
            if not split:
                return export_video(snapshot, opts, prog, stop)
            res = export_video(snapshot, opts, lambda p, m: prog(int(p * 0.85), m), stop)
            if not joiner.plan_split(get_media_info(res["video"]).duration, part_sec,
                                    min(60.0, part_sec * 0.25)):
                res["warning"] = (res.get("warning", "") or "") + \
                    "Shorter than one part – not cut."
                return res
            cut = joiner.split_video(
                res["video"], part_sec, parts_dir, exact=exact,
                min_last=min(60.0, part_sec * 0.25), name=part_name,
                progress=lambda p, m: prog(85 + int(p * 0.15), "Cutting into parts… " + m),
                should_stop=stop)
            res["parts"] = cut["parts"]
            if not keep_full:
                try:
                    os.remove(res["video"])
                except OSError:
                    pass
                res["video"] = cut["parts"][0]
            return res

        self.worker = TaskWorker(job, "Export", self)
        self.worker.progress.connect(self._on_progress)
        self.worker.done.connect(self._on_done)
        self.worker.failed.connect(self._on_failed)
        self.btn_start.setEnabled(False)
        self.btn_close.setText("Cancel")
        self.btn_open.setVisible(False)
        self.progress.setValue(0)
        self._started = time.time()
        self.worker.start()

    def _check_nvenc(self):
        ok = nvenc_available()
        self.lb_encoder.setText("✅ NVIDIA GPU ready" if ok else "GPU encoder not found → CPU")

    def _on_progress(self, pct, msg):
        self.progress.setValue(pct)
        if self._started:
            el = time.time() - self._started
            if pct > 12 and el > 20:
                left = el * (100 - pct) / max(1, pct - 8)
                msg += f"   ·   ~{format_time(left, False)} left"
        self.status.setText(msg)

    def _on_done(self, result: dict):
        self.btn_start.setEnabled(True)
        self.btn_close.setText("Close")
        self.progress.setValue(100)
        self._last = result["video"]
        took = format_time(time.time() - self._started, False)
        enc = "NVIDIA GPU" if result.get("encoder") == "nvenc" else "CPU"
        msg = f"✅ Saved in {took} ({enc}): {result['video']}"
        if result.get("parts"):
            self._last = result["parts"][0]
            msg = (f"✅ Saved in {took} ({enc}) and cut into {len(result['parts'])} parts: "
                   f"{os.path.dirname(result['parts'][0])}")
        if result.get("srt"):
            msg += f"\nSubtitles: {result['srt']}"
        if result.get("mp3"):
            msg += f"\nSound: {result['mp3']}"
        if result.get("warning"):
            msg += f"\n⚠ {result['warning'].splitlines()[0]}"
        self.status.setText(msg)
        self.btn_open.setVisible(True)
        self.win.log(msg)

    def _on_failed(self, err: str):
        self.btn_start.setEnabled(True)
        self.btn_close.setText("Close")
        self.status.setText("❌ " + err)
        self.win.log("Export failed: " + err)

    def _close_or_cancel(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.status.setText("Cancelling...")
            return
        self.accept()

    def _open_folder(self):
        folder = os.path.dirname(getattr(self, "_last", self.ed_path.text()))
        open_path(folder)

    def reject(self):
        """Esc / ✕ while exporting: cancel the export (the dialog stays open
        until it has stopped) instead of hiding a job that keeps running."""
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.status.setText("Cancelling...")
            return
        super().reject()

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.status.setText("Cancelling...")
            event.ignore()
            return
        super().closeEvent(event)


class FramePreviewDialog(QDialog):
    """Shows one rendered frame exactly as it will be exported."""

    def __init__(self, png: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Preview frame (as exported)")
        pix = QPixmap(png)
        screen = self.screen().availableGeometry() if self.screen() else None
        max_w = int(screen.width() * 0.8) if screen else 1200
        max_h = int(screen.height() * 0.8) if screen else 800
        if pix.width() > max_w or pix.height() > max_h:
            pix = pix.scaled(max_w, max_h, Qt.AspectRatioMode.KeepAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
        lbl = QLabel()
        lbl.setPixmap(pix)
        lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        btn = QPushButton("Close")
        btn.clicked.connect(self.accept)
        lay = QVBoxLayout(self)
        lay.addWidget(lbl, 1)
        lay.addWidget(btn, 0, Qt.AlignmentFlag.AlignRight)


def open_path(path: str):
    """Open a file or folder with the default Windows program."""
    if sys.platform == "win32":
        os.startfile(path)  # type: ignore[attr-defined]
    else:
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))


# --------------------------------------------------------------------------- #
# Main window
# --------------------------------------------------------------------------- #
# Default window layout (Po's set-up on a 1920x1080 screen): left panel,
# preview, right panel / preview area, timeline. The preview takes what is left.
DEFAULT_H_SIZES = [390, 930, 590]
DEFAULT_V_SIZES = [565, 345]


def _log_qt_messages() -> None:
    """Qt writes why it stops (e.g. "QThread: Destroyed while thread is still
    running") only to a console the built .exe does not have: copy critical
    and fatal Qt messages into the log."""
    try:
        from PySide6.QtCore import QtMsgType, qInstallMessageHandler

        def handler(kind, context, text):
            if kind not in (QtMsgType.QtDebugMsg, QtMsgType.QtInfoMsg):
                try:
                    print(f"[qt] {text}", file=sys.stderr, flush=True)
                except Exception:
                    pass
                if kind in (QtMsgType.QtCriticalMsg, QtMsgType.QtFatalMsg):
                    from core import crashlog
                    crashlog.note(f"[qt] {text}")

        global _QT_HANDLER
        _QT_HANDLER = handler          # keep a reference
        qInstallMessageHandler(handler)
    except Exception:
        pass


_QT_HANDLER = None


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        from core import crashlog
        crashlog.enable()            # a hard crash leaves its place in the log
        _log_qt_messages()           # Qt's own "fatal" text goes into the log too
        from core import __version__
        from core import appinfo as _ai
        _label = getattr(_ai, "BUILD_LABEL", "")
        self.setWindowTitle(f"{TITLE} {__version__}" + (f" [{_label}]" if _label else "")
                            + " – AI Video Dubbing & Editor")
        self.workspace = "dub"                  # "edit" / "dub" (Home dashboard cards)
        self.resize(1500, 920)
        try:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
        except OSError:
            pass                    # shown when something is saved there

        self.project = Project()
        self.project_path = ""
        self.dirty = False
        self.undo_stack: List[dict] = []
        self.redo_stack: List[dict] = []
        self.worker: Optional[TaskWorker] = None
        self.batch: Optional[BatchDialog] = None
        self.merge_dlg: Optional[MergeSplitDialog] = None

        self.sample_player = QMediaPlayer(self)
        self.sample_out = QAudioOutput(self)
        self.sample_player.setAudioOutput(self.sample_out)

        apply_azure_settings()
        self._build_ui()
        self._build_menus()
        self._connect()
        self._apply_sidebar()
        self._update_license_badge()
        QTimer.singleShot(1500, self._remind_admin)
        QTimer.singleShot(2500, self._remind_renew)

        # crash safety: save edits to the autosave file every minute
        self.autosave_timer = QTimer(self)
        self.autosave_timer.setInterval(60_000)
        self.autosave_timer.timeout.connect(self._autosave)
        self.autosave_timer.start()

        self._refresh_all()
        QTimer.singleShot(300, self._check_ffmpeg)
        QTimer.singleShot(400, self._check_batch_queue)
        QTimer.singleShot(4000, self._auto_update_check)

    def _check_batch_queue(self):
        from core import batch
        items, _o = batch.load_queue()
        left = sum(1 for i in items if i.status not in (batch.DONE, batch.SKIPPED))
        if left:
            self.log(f"☰ Batch queue: {left} unfinished videos – File > Batch queue to continue")

    # ------------------------------------------------------------------ #
    # UI construction
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        # top bar
        top = QWidget()
        top.setObjectName("TopBar")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(14, 8, 14, 8)
        self.btn_home = QPushButton("🏠 Home")
        self.btn_home.setToolTip("Back to the Home dashboard")
        self.btn_home.clicked.connect(self.show_home)
        # 2.0: hide / show the left side panel (more room for the preview)
        self._sidebar_collapsed = bool(settings.get("layout_sidebar_collapsed", False))
        self.btn_sidebar = QPushButton("◀")
        self.btn_sidebar.setObjectName("TopSecondary")
        self.btn_sidebar.setFixedWidth(40)
        self.btn_sidebar.clicked.connect(self.toggle_sidebar)
        title = QLabel("🎙️ SARIKA VOXDUB")
        title.setObjectName("AppTitle")
        pro = QLabel("PRO")
        pro.setObjectName("AppTitlePro")
        from core import appinfo as _ai
        _badge = EDITION.upper() or getattr(_ai, "BUILD_LABEL", "")
        testing = QLabel(_badge)
        testing.setObjectName("TestingBadge")
        testing.setVisible(bool(_badge))
        # the two workspaces of one project
        self.ws_buttons = {}
        for key, text in (("edit", "✂ Edit"), ("dub", "🎙 Dub")):
            b = QPushButton(text)
            b.setObjectName("WorkspaceTab")
            b.setCheckable(True)
            b.clicked.connect(lambda _=False, k=key: self.set_workspace(k))
            self.ws_buttons[key] = b
        self.lbl_project = QLabel("Untitled project")
        self.lbl_project.setObjectName("ProjectName")
        self.btn_top_auto = QPushButton("⚡ Auto Dub")
        self.btn_top_auto.setObjectName("TopAuto")
        self.btn_top_batch = QPushButton("☰ Batch")
        self.btn_top_batch.setObjectName("TopSecondary")
        self.btn_top_batch.setToolTip("Batch queue: dub and export many videos one after another")
        self.btn_top_batch.clicked.connect(self.show_batch)
        self.btn_top_merge = QPushButton("🔗 Merge / Split")
        self.btn_top_merge.setToolTip("Join many videos into one, or cut a long video into "
                                      "parts of N minutes")
        self.btn_top_merge.setObjectName("TopSecondary")
        self.btn_top_merge.clicked.connect(lambda: self.show_merge_split())
        # Edit a whole folder: back to the folder after setting up episode 1
        self.btn_top_folder = QPushButton("📂 Apply to the folder")
        self.btn_top_folder.setObjectName("AccentButton")
        self.btn_top_folder.setToolTip("Use the edit of this video (logo, speed, colour …) "
                                       "for every episode of the folder")
        self.btn_top_folder.clicked.connect(lambda: self.show_folder_edit(resume=True))
        self.btn_top_folder.setVisible(False)
        self._folder_pending: Optional[dict] = None
        self.btn_license = QPushButton("TRIAL")
        self.btn_license.setObjectName("LicenseBadge")
        self.btn_license.setToolTip("License")
        self.btn_license.clicked.connect(self.show_license)
        self.btn_help = QPushButton("❓ Help")
        self.btn_help.setObjectName("TopSecondary")
        self.btn_help.setToolTip("How to use SARIKA VOXDUB PRO (F1)")
        self.btn_help.clicked.connect(lambda: self.show_help())
        tl.addWidget(self.btn_home)
        tl.addWidget(self.btn_sidebar)
        tl.addSpacing(8)
        tl.addWidget(title)
        tl.addWidget(pro)
        tl.addWidget(testing)
        tl.addSpacing(14)
        tl.addWidget(self.ws_buttons["edit"])
        tl.addWidget(self.ws_buttons["dub"])
        tl.addSpacing(14)
        tl.addWidget(self.lbl_project)
        tl.addStretch(1)
        tl.addWidget(self.btn_license)
        tl.addWidget(self.btn_help)
        tl.addWidget(self.btn_top_folder)
        tl.addWidget(self.btn_top_merge)
        tl.addWidget(self.btn_top_batch)
        tl.addWidget(self.btn_top_auto)

        self.left = LeftPanel()
        self.player = VideoPlayer()
        self.right = RightPanel()
        self.style_panel = StylePanel()
        self.right.addTab(self.style_panel, "🎨 Style")
        self.timeline = TimelineEditor()

        # Movavi-style Tools (Crop / Color / Audio) open in place of the left panel
        self.tools = ToolsPanel()
        # Edit workspace (Filmora style): the library on the left, the
        # inspector (Video / Audio / Speed / Color) as tabs on the right
        from ui.inspector import Inspector
        from ui.library_panel import LibraryPanel

        self.library = LibraryPanel()
        self.inspector = Inspector(self)
        self._ins_tabs = []
        for key in Inspector.TABS:
            w = self.inspector.widgets[key]
            self.right.addTab(w, Inspector.NAMES[key])
            self._ins_tabs.append(w)
        self._ins_crop = False
        self.left_stack = QStackedWidget()
        self.left_stack.addWidget(self.left)
        self.left_stack.addWidget(self.tools)
        self.left_stack.addWidget(self.library)
        self.h_split = QSplitter(Qt.Orientation.Horizontal)
        self.h_split.addWidget(self.left_stack)
        self.h_split.addWidget(self.player)
        self.h_split.addWidget(self.right)
        self.h_split.setStretchFactor(0, 0)
        self.h_split.setStretchFactor(1, 1)
        self.h_split.setStretchFactor(2, 0)
        self.h_split.setSizes(DEFAULT_H_SIZES)
        self.h_split.setChildrenCollapsible(False)

        self.v_split = QSplitter(Qt.Orientation.Vertical)
        self.v_split.addWidget(self.h_split)
        self.v_split.addWidget(self.timeline)
        self.v_split.setStretchFactor(0, 1)
        self.v_split.setStretchFactor(1, 0)
        self.v_split.setSizes(DEFAULT_V_SIZES)
        self._restore_layout()
        self.v_split.setChildrenCollapsible(False)

        central = QWidget()
        cl = QVBoxLayout(central)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(0)
        cl.addWidget(top)
        cl.addWidget(self.v_split, 1)
        # Home dashboard first; the editor (Edit / Dub) behind it
        self.home = HomePage()
        self.home.batch_status = self._batch_status
        self.home.workspaceRequested.connect(self.open_workspace)
        self.home.batchRequested.connect(self._home_batch)
        self.home.quickRequested.connect(self._home_quick)
        self.home.recentRequested.connect(self._home_recent)
        self.home.planChanged.connect(self._plan_changed)
        self.home.settingsRequested.connect(lambda: self.show_engines("gemini"))
        self.home.licenseRequested.connect(self._home_license)
        self.home.sarikaVoiceRequested.connect(self.show_sarika_voice)
        self.home.recapRequested.connect(self.show_recap)
        self.home.recapVideosRequested.connect(self.show_recap)
        self.home.voiceLibraryRequested.connect(self.show_voice_library)
        self.home.projectsRequested.connect(self.open_project)
        self.home.appearanceRequested.connect(self.show_appearance)
        self.home.libraryRequested.connect(
            lambda name: QMessageBox.information(
                self, name, f"“{name}” comes in a later version."))
        self.editor_page = central
        self.root_stack = QStackedWidget()
        self.root_stack.addWidget(self.home)
        self.root_stack.addWidget(central)
        self.setCentralWidget(self.root_stack)
        self.ws_buttons["dub"].setChecked(True)
        self.statusBar().showMessage("Ready – drop a video to begin")
        # 2.3: GPU / VRAM / RAM always in view (bottom right)
        from ui.resource_monitor import ResourceMonitor

        self.res_monitor = ResourceMonitor(self, jobs=self._jobs_text)
        self.statusBar().addPermanentWidget(self.res_monitor)

    def _action(self, menu, text, slot, shortcut=None):
        act = QAction(text, self)
        if shortcut:
            act.setShortcut(QKeySequence(shortcut))
        act.triggered.connect(slot)
        menu.addAction(act)
        return act

    def _build_menus(self):
        mb = self.menuBar()
        m_file = mb.addMenu("&File")
        self._action(m_file, "📁  Open Video…", self.browse_video, "Ctrl+O")
        self._action(m_file, "🎵  Add music…", self.browse_music)
        self._action(m_file, "✖  Close video (empty timeline)", lambda: self.close_video())
        self._action(m_file, "📂  Open Project…", self.open_project, "Ctrl+Shift+O")
        self._action(m_file, "🕘  Open a backup…", self.open_backup)
        m_file.addSeparator()
        self._action(m_file, "💾  Save Project", self.save_project, "Ctrl+S")
        self._action(m_file, "💾  Save Project As…", self.save_project_as, "Ctrl+Shift+S")
        m_file.addSeparator()
        self._action(m_file, "☰  Batch queue…", self.show_batch, "Ctrl+Shift+B")
        m_file.addSeparator()
        self._action(m_file, "📂  Open output folder", lambda: open_path(OUTPUT_DIR))
        self._action(m_file, "📁  Change output folder…", self.change_output_folder)
        m_file.addSeparator()
        self._action(m_file, "Exit", self.close, "Alt+F4")

        m_edit = mb.addMenu("&Edit")
        self._action(m_edit, "↶  Undo", self.undo, "Ctrl+Z")
        self._action(m_edit, "↷  Redo", self.redo, "Ctrl+Y")
        m_edit.addSeparator()
        self._action(m_edit, "✂  Split at playhead", self.timeline.split_at_playhead, "Ctrl+B")
        self._action(m_edit, "🙈  Hide / show all subtitles",
                     lambda: self.set_subtitles_shown(self.project.subs_hidden), "Ctrl+Shift+H")
        self._action(m_edit, "🗑  Delete selected clip", self.delete_clip,
                     "Ctrl+Delete")
        m_edit.addSeparator()
        self._action(m_edit, "◧  Hide / show side panel", self.toggle_sidebar, "Ctrl+\\")
        self._action(m_edit, "▶  Play / Pause", self.player.toggle, "Ctrl+Space")
        self._action(m_edit, "🔍  Zoom in", lambda: self.timeline._zoom_step(1.25), "Ctrl+=")
        self._action(m_edit, "🔍  Zoom out", lambda: self.timeline._zoom_step(0.8), "Ctrl+-")
        self._action(m_edit, "⤢  Fit timeline", self.timeline.zoom_fit, "Ctrl+0")

        m_exp = mb.addMenu("E&xport")
        self._action(m_exp, "🎬  Export Video (MP4)…", self.export_video, "Ctrl+E")
        self._action(m_exp, "💬  Export Subtitles (SRT)…", self.export_srt)
        self._action(m_exp, "🔊  Export AI Voice (WAV)…", self.export_dub_wav)

        m_tools = mb.addMenu("&Tools")
        self._action(m_tools, "🔗  Merge videos into one…", lambda: self.show_merge_split(tab=0),
                     "Ctrl+Shift+M")
        self._action(m_tools, "✂  Split a video into parts…", lambda: self.show_merge_split(tab=1),
                     "Ctrl+Shift+K")
        self._action(m_tools, "🔄  Reframe – turn, mirror, 16:9 ↔ 9:16…",
                     lambda: self.show_reframe())
        self._action(m_tools, "📂  Edit a whole folder (no dubbing)…", self.show_folder_edit)
        self._action(m_tools, "☰  Batch queue…", self.show_batch)
        self._action(m_tools, "🎬  AI Recap – a long drama in a few minutes…", self.show_recap)
        self._action(m_tools, "©  Copyright check (rights · music · YouTube)…",
                     self.show_copyright)
        self._action(m_tools, "📖  Glossary (same names in every episode)…", self.show_glossary)
        self._action(m_tools, "✅  Quality check of this video…", self.show_qc)
        m_tools.addSeparator()
        self._action(m_tools, "⚙  AI engines && API keys (Gemini, VoxCPM)…",
                     lambda: self.show_engines("gemini"))
        self._action(m_tools, "🎨  Appearance && language (English / ខ្មែរ, colour, light / "
                              "dark)…", self.show_appearance)
        self._action(m_tools, "🔍  Double-check the transcript with the burned-in subtitles",
                     self.run_double_check)
        from core import admin as _admin
        if _admin.is_owner():       # owner's PC only - customers never see SARIKA VOICE
            m_tools.addSeparator()
            self._action(m_tools, "🎙  SARIKA VOICE (Voice · Story Studio)…", self.show_sarika_voice,
                         "Ctrl+Alt+V")

        m_help = mb.addMenu("&Help")
        self._action(m_help, "📖  User guide", lambda: self.show_help(), "F1")
        self._action(m_help, "🚀  Getting started", lambda: self.show_help("start"))
        self._action(m_help, "⌨  Keyboard shortcuts", lambda: self.show_help("keys"))
        self._action(m_help, "🩺  Problems && solutions", lambda: self.show_help("trouble"))
        self._action(m_help, "🎓  Video tutorials", self._tutorials)
        self._action(m_help, "✅  System check…", self.show_system_check)
        self._action(m_help, "📨  Send problem report…", self._problem_report)
        m_help.addSeparator()
        self._action(m_help, "🔑  License…", self.show_license)
        from core import admin
        if admin.is_owner():
            self._action(m_help, "👑  Admin – Customers & keys…", self.show_admin, "Ctrl+Alt+Shift+A")
        self._action(m_help, "☁  Azure Speech key…", self.show_azure_key)
        m_help.addSeparator()
        self._action(m_help, "⬆  Check for updates…", self.check_updates)
        self._action(m_help, "ℹ  About…", self.show_about)
        from core import updates as _upd

        if _upd.active_update():
            self._action(m_help, f"↩  Remove update {_upd.active_update()} (back to "
                                 f"{_upd.installed_version()})", self.remove_update)

    def _connect(self):
        L, R, T, P = self.left, self.right, self.timeline, self.player
        L.videoChosen.connect(self.load_video)
        L.autoDubRequested.connect(self.run_auto_dub)
        L.transcribeRequested.connect(self.run_transcribe)
        L.translateRequested.connect(self.run_translate)
        L.voiceRequested.connect(lambda: self.run_voice(None))
        L.testVoiceRequested.connect(self.test_voice)
        L.azureKeyRequested.connect(self.show_azure_key)
        L.enginesRequested.connect(self.show_engines)
        L.cmb_stt.activated.connect(lambda *_: self._check_engine_keys())
        L.cmb_translator.activated.connect(lambda *_: self._check_engine_keys())
        L.cmb_engine.activated.connect(lambda *_: self._check_engine_keys())
        L.cancelRequested.connect(self.cancel_task)
        L.settingsChanged.connect(self._settings_changed)
        L.presetChosen.connect(self.apply_preset)
        L.presetSaveRequested.connect(self.save_preset)
        L.presetDeleteRequested.connect(self.delete_preset)
        self.btn_top_auto.clicked.connect(self.run_auto_dub)

        R.segmentTextEdited.connect(self._on_segment_text)
        R.checkDoneRequested.connect(self._on_check_done)
        R.translationEdited.connect(self._on_translation_text)
        R.seekSourceRequested.connect(self._seek_source)
        R.seekTimelineRequested.connect(self.seek)
        R.translateAllRequested.connect(self.run_translate)
        R.autoDeliveryRequested.connect(self.run_auto_delivery)
        R.revoiceRequested.connect(self.run_voice)
        R.revoiceAllRequested.connect(lambda: self.run_voice(None, force=True))
        R.genderToggled.connect(self._toggle_gender)
        R.lineSettingEdited.connect(self._on_line_setting)
        R.subtitleEdited.connect(self._on_subtitle_edit)
        R.subtitleSelected.connect(self._on_subtitle_selected)
        R.addSubtitleRequested.connect(self._add_subtitle)
        R.deleteSubtitleRequested.connect(self._delete_subtitles)
        R.rebuildSubtitlesRequested.connect(self._rebuild_subtitles)
        R.exportSrtRequested.connect(self.export_srt)
        R.hideSubtitlesRequested.connect(self.hide_subtitle_lines)
        C = R.characters
        C.findRequested.connect(self.run_find_characters)
        C.aboutToChange.connect(self.push_undo)
        C.changed.connect(self._characters_changed)
        C.listenRequested.connect(self.listen_character)
        C.seekSourceRequested.connect(self._seek_source)
        C.revoiceRequested.connect(lambda: self.run_voice(None))

        S = self.style_panel
        S.changed.connect(self._on_style_changed)
        S.detectRequested.connect(self.detect_original_subtitles)
        S.previewFrameRequested.connect(self.preview_frame)
        self.player.overlayMoved.connect(self._on_overlay_moved)
        self.player.overlayAboutToMove.connect(lambda: self.push_undo(overlay=True))
        self.style_panel.subsShownToggled.connect(self.set_subtitles_shown)
        self.style_panel.greenScreenRequested.connect(self.show_green_screen)
        self.player.subsShownToggled.connect(self.set_subtitles_shown)
        self.player.videoDropped.connect(self.load_video)
        self.player.browseRequested.connect(self.browse_video)
        self.tools.blackBarsRequested.connect(self.remove_black_bars)

        c = T.canvas
        c.seekRequested.connect(self.seek)
        c.aboutToEdit.connect(self.push_undo)
        c.edited.connect(lambda kind: self.after_edit(
            audio=kind in ("audio", "video", ""), tables=False,
            subs=kind in ("subs", "video", "")))
        c.selectionChanged.connect(self._on_timeline_selection)
        c.playToggleRequested.connect(P.toggle)
        c.splitRequested.connect(T.split_at_playhead)
        c.deleteRequested.connect(self.delete_clip)
        c.filesDropped.connect(self._timeline_drop)
        T.btn_undo.clicked.connect(self.undo)
        T.btn_redo.clicked.connect(self.redo)
        T.exportRequested.connect(self.export_video)
        T.bgmRequested.connect(self.browse_music)
        T.isolateRequested.connect(self.isolate_bgm)
        T.quickRequested.connect(self.quick_tool)
        T.ratioChosen.connect(self.set_ratio)
        T.importSrtRequested.connect(self.import_srt)
        T.exportSrtRequested.connect(self.export_srt)
        T.toolRequested.connect(self.open_tool)
        self.tools.changing.connect(lambda kind: self.push_undo())
        self.tools.changed.connect(self._on_tool_changed)
        self.tools.closed.connect(self._close_tool)
        self.tools.cropKeepAspect.connect(P.set_crop_keep_aspect)
        self.tools.voiceSpeedRequested.connect(self._apply_voice_speed)
        self.tools.previewRequested.connect(self._preview_audio)
        self.tools.toolSwitchRequested.connect(self.open_tool)
        P.cropChangedCallback = self._crop_from_preview
        I = self.inspector
        I.changing.connect(lambda kind: self.push_undo())
        I.changed.connect(self._on_tool_changed)
        I.cropKeepAspect.connect(P.set_crop_keep_aspect)
        I.cropModeRequested.connect(self._inspector_crop)
        I.voiceSpeedRequested.connect(self._apply_voice_speed)
        I.previewRequested.connect(self._preview_audio)
        I.toolSwitchRequested.connect(self.open_tool)
        I.blackBarsRequested.connect(self.remove_black_bars)
        I.reframeRequested.connect(lambda: self.show_reframe())
        L = self.library
        L.openRequested.connect(self.load_video)
        L.musicRequested.connect(self.add_music)
        L.applyRequested.connect(self._library_apply)
        L.logoRequested.connect(lambda path: self._library_apply(
            "style", lambda p: setattr(p, "logo_path", path)))
        L.extraLogoRequested.connect(self._library_extra_logo)
        self.right.currentChanged.connect(self._right_tab_changed)
        T.addSubtitleRequested.connect(self._add_subtitle)
        T.trackToggled.connect(self._on_track_toggled)
        T.projectSettingsRequested.connect(self.show_project_settings)
        P.playingChanged.connect(T.set_playing)
        P.chk_dub.toggled.connect(lambda on: (T.header.set_state("audio", "sound", on),
                                              T.canvas.dimmed.discard("audio") if on
                                              else T.canvas.dimmed.add("audio"),
                                              T.canvas.update()))

        P.positionChanged.connect(lambda t: T.set_playhead(t, follow=P.is_playing()))
        P.positionChanged.connect(self._follow_tables)

    def _on_track_toggled(self, key: str, what: str, on: bool):
        """Eye / speaker buttons in the timeline header (preview only, like
        Movavi's track toggles; the export settings are not changed)."""
        P = self.player
        if key == "video" and what == "sound":
            P.set_original_muted(not on)
        elif key == "video":
            P.set_video_visible(on)
        elif key == "audio":
            P.chk_dub.setChecked(on)
        elif key == "music":
            P.set_music_muted(not on)
        elif key == "subs":
            P.set_subtitles_visible(on)
        names = {("video", "sound"): "Original audio", ("video", "visible"): "Video picture",
                 ("audio", "sound"): "AI voice", ("subs", "visible"): "Subtitles",
                 ("music", "sound"): "Music"}
        self.statusBar().showMessage(
            f"{names.get((key, what), key)} {'on' if on else 'off'} in the preview", 3000)

    def _follow_tables(self, t: float):
        """Transcript / Translation / Subtitles follow the playing video."""
        p = self.project
        if not p.has_video():
            return
        src = p.timeline_to_source(t)[1] if p.video_clips else t
        self.right.follow(src, t)

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #
    def log(self, msg: str):
        self.left.add_log(f"[{time.strftime('%H:%M:%S')}] {msg}")
        self.statusBar().showMessage(msg.splitlines()[0][:160], 8000)

    def change_output_folder(self):
        """Where projects and exported videos go (saved in the settings)."""
        global OUTPUT_DIR
        path = QFileDialog.getExistingDirectory(self, "Output folder", OUTPUT_DIR)
        if not path:
            return
        try:
            os.makedirs(path, exist_ok=True)
            probe = os.path.join(path, ".voxdub_write_test")
            with open(probe, "w") as f:
                f.write("ok")
            os.remove(probe)
        except OSError as e:
            QMessageBox.warning(self, "Output folder", f"Cannot write into this folder:\n{e}")
            return
        settings.set("output_dir", path)
        OUTPUT_DIR = path
        self.log(f"Output folder: {path}")

    def _check_ffmpeg(self):
        try:
            path = find_ffmpeg()
            self.log(f"ffmpeg: {path}")
        except FFmpegError as e:
            QMessageBox.critical(self, "ffmpeg missing", str(e))
            return
        import threading

        def gpu():
            # (loading the CUDA libraries takes seconds: never in the window's thread)
            gpus = cuda_gpu_count()
            if gpus:
                msg = f"NVIDIA GPU found ({gpus}) - Whisper will try CUDA" + (
                    "" if FROZEN else " (if it falls back to CPU, run install_gpu.bat)")
                QTimer.singleShot(0, self, lambda: self.log(msg))
        threading.Thread(target=gpu, daemon=True).start()
        from core import ocr_subs
        if not ocr_subs.available():
            self.log("ℹ Double-check with burned-in subtitles (OCR) is not installed." + (
                " Please install SARIKA VOXDUB PRO again." if FROZEN else
                " Run install.bat again, or: .venv\\Scripts\\python -m pip install "
                "rapidocr_onnxruntime"))

    def _autosave(self):
        """Keep a copy of unsaved edits next to the work files."""
        path = self.project.autosave_path()
        if not self.dirty or not path or not self.project.has_video():
            return
        if self.worker and self.worker.isRunning():
            return          # the AI step saves its own progress
        if self.batch and self.batch.is_busy_dir(self.project.work_dir):
            return          # the batch queue is writing this video right now
        try:
            self.left.apply_to_project(self.project)
            from core.backup import AUTOSAVE_EVERY

            self.project.save(path, backup=AUTOSAVE_EVERY)     # + a copy every 10 min
            self._record_recent()
            self._note_session(path)
        except Exception as e:
            self.log(f"Autosave failed: {e}")

    def _jobs_text(self) -> str:
        """Job status for the resource monitor: what is running now."""
        parts = []
        w = self.worker
        if w is not None and w.isRunning():
            parts.append(f"▶ {getattr(w, 'title', '') or 'working'}")
        b = getattr(self, "batch", None)
        if b is not None and getattr(b, "running", False):
            parts.append(f"Batch: {len(b.dub_jobs)} dubbing, {len(b.exp_jobs)} exporting")
        return " · ".join(parts)

    def _note_session(self, autosave: str = "", dirty: Optional[bool] = None):
        """Crash recovery: which project is open, with unsaved edits or not."""
        from core import session

        session.note(autosave or self.project.autosave_path(), self.project_path,
                     self.project.video_path, self.dirty if dirty is None else dirty)

    def _offer_recovery(self, prev: dict):
        """The app did not close properly last time: open the unsaved work?"""
        from core import session

        auto = prev.get("autosave", "")
        if not session.recoverable(prev):
            return
        name = os.path.basename(prev.get("video") or "") or os.path.basename(auto)
        when = time.strftime("%d %b %H:%M", time.localtime(os.path.getmtime(auto)))
        ans = QMessageBox.question(
            self, "Recover unsaved work",
            "SARIKA VOXDUB PRO did not close properly last time\n"
            "(crash, power cut or closed from Task Manager).\n\n"
            f"Open the unsaved work of “{name}” (autosaved {when})?")
        if ans != QMessageBox.StandardButton.Yes:
            return
        if self._busy("Open project") or not self._maybe_save():
            return
        self.set_workspace("dub")
        self.show_editor()
        self._open_project_file(auto, as_autosave=True)
        self._set_dirty(True)               # not saved to a project file yet
        self.log("↺ Recovered the unsaved work from the autosave")

    def _set_dirty(self, dirty=True):
        self.dirty = dirty
        name = os.path.basename(self.project_path) if self.project_path else (
            os.path.basename(self.project.video_path) if self.project.video_path else
            "Untitled project")
        self.lbl_project.setText(("● " if dirty else "") + name)

    def _refresh_all(self):
        """Push the whole project into every widget."""
        self.left.load_from_project(self.project)
        self.right.load(self.project)
        self.style_panel.load(self.project)
        self.timeline.set_project(self.project)
        self.player.set_project(self.project)
        self._load_edit_panels()
        self._set_dirty(self.dirty)

    def after_edit(self, audio: bool = True, tables: bool = True, subs: bool = True):
        """Call after any change to clips / text."""
        self.timeline.refresh()
        self.player.set_project(self.project)
        if tables:
            self.right._project = self.project
            self.right.load_segments(self.project.segments)
            self.right.characters.load(self.project)
        if subs:
            self.right.load_subtitles(self.project.subtitles_sorted())
        self._set_dirty(True)

    def _settings_changed(self):
        self.left.apply_to_project(self.project)
        self.right.characters.load(self.project)        # voices follow the engine
        self._set_dirty(True)

    # ------------------------------------------------------------------ #
    # Presets (2.4) - shared with Batch
    # ------------------------------------------------------------------ #
    def apply_preset(self, name: str):
        from core import presets

        values = presets.get(name)
        if values is None:
            self.left.reload_presets()
            return
        self.left.apply_to_project(self.project)
        self.push_undo(overlay=True)
        changed = presets.apply(self.project, values)
        self._refresh_all()
        self.left.reload_presets(select=name)
        if changed:
            self._set_dirty(True)
        self.log(f"⭐ Preset “{name}”: {len(changed)} setting(s) changed")
        self.statusBar().showMessage(f"Preset “{name}” applied", 4000)

    def save_preset(self):
        from PySide6.QtWidgets import QInputDialog

        from core import presets

        current = self.left.cmb_preset.currentData() or ""
        name, ok = QInputDialog.getText(
            self, "Save as preset",
            "Preset name (e.g. “រឿងចិន → ខ្មែរ (F2 Movie)”, “TikTok 9:16”):\n"
            "Keeps languages, voice, subtitle style, logo, blur, output size and tools.",
            text=current)
        name = presets.clean_name(name)
        if not ok or not name:
            return
        if name in presets.list_presets() and not presets.is_builtin(name):
            if QMessageBox.question(self, "Save as preset",
                                    f"Replace the preset “{name}”?") != QMessageBox.StandardButton.Yes:
                return
        self.left.apply_to_project(self.project)
        presets.save(name, presets.from_project(self.project))
        self.left.reload_presets(select=name)
        self.log(f"⭐ Saved preset “{name}” (also in Batch)")

    def delete_preset(self, name: str):
        from core import presets

        if presets.is_builtin(name):
            return
        if QMessageBox.question(self, "Delete preset",
                                f"Delete the preset “{name}”?") != QMessageBox.StandardButton.Yes:
            return
        presets.delete(name)
        self.left.reload_presets()
        self.log(f"🗑 Deleted preset “{name}”")

    def _require_video(self) -> bool:
        if not self.project.has_video():
            QMessageBox.information(self, "SARIKA VOXDUB PRO", "Please upload a video first.")
            return False
        return True

    # ------------------------------------------------------------------ #
    # Undo / redo
    # ------------------------------------------------------------------ #
    def push_undo(self, overlay: bool = False):
        self.undo_stack.append(self.project.snapshot(overlay=bool(overlay)))
        if len(self.undo_stack) > 100:
            self.undo_stack.pop(0)
        self.redo_stack.clear()

    def undo(self):
        if not self.undo_stack:
            self.statusBar().showMessage("Nothing to undo", 2000)
            return
        snap = self.undo_stack.pop()
        self.redo_stack.append(self.project.snapshot(overlay="overlay" in snap))
        self.project.restore(snap)
        self.style_panel.load(self.project)
        self._load_edit_panels()
        self.after_edit()

    def redo(self):
        if not self.redo_stack:
            self.statusBar().showMessage("Nothing to redo", 2000)
            return
        snap = self.redo_stack.pop()
        self.undo_stack.append(self.project.snapshot(overlay="overlay" in snap))
        self.project.restore(snap)
        self.style_panel.load(self.project)
        self._load_edit_panels()
        self.after_edit()

    # ------------------------------------------------------------------ #
    # License / Azure key / speaker gender
    # ------------------------------------------------------------------ #
    def _update_license_badge(self):
        info = lic.current()
        if info.valid and info.plan == "owner":
            self.btn_license.setText("ADMIN")
            self.btn_license.setProperty("trial", False)
            self.btn_license.setToolTip("Seller's PC – click: customers & license keys")
        elif info.valid:
            self.btn_license.setText(f"PRO · {info.days_left}d" if info.days_left <= 7
                                     else lic.PLANS.get(info.plan, "PRO").upper())
            self.btn_license.setProperty("trial", False)
            self.btn_license.setToolTip(info.summary())
        elif not lic.TRIAL_ENABLED:
            self.btn_license.setText("PRO")
            self.btn_license.setProperty("trial", False)
            self.btn_license.setToolTip("Trial watermark is off – click for License")
        else:
            self.btn_license.setText("TRIAL")
            self.btn_license.setProperty("trial", True)
            self.btn_license.setToolTip(info.reason + " – click to activate")
        self.btn_license.style().polish(self.btn_license)

    def show_appearance(self):
        """🎨 English / ខ្មែរ, the colour, Auto / Light / Dark - shown at once."""
        from ui.appearance_dialog import AppearanceDialog

        AppearanceDialog(self).exec()
        self.home.refresh()

    def show_voice_library(self):
        """🗣 Voice Library (Home sidebar): the voices to clone with VoxCPM2."""
        from ui.voice_library import VoiceLibraryDialog

        VoiceLibraryDialog(self, mode="settings").exec()

    def show_recap(self, videos=None):
        """🎬 AI Recap (2.5 preview): its own window, works beside the editor.
        videos: dropped on the AI Recap card of Home."""
        from ui.recap_dialog import RecapDialog

        if not self._gate("recap"):
            return
        dlg = getattr(self, "_recap", None)
        if dlg is None:
            dlg = RecapDialog(self)
            self._recap = dlg
        have = set(dlg.videos())
        for v in videos if isinstance(videos, list) else []:
            if v not in have:
                dlg._add(v)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def show_batch(self):
        if not self._gate("batch"):
            return
        if self.batch is None:
            self.batch = BatchDialog(self, OUTPUT_DIR)
        self.batch.show()
        self.batch.raise_()
        self.batch.activateWindow()

    def show_folder_edit(self, paths: Optional[List[str]] = None, resume: bool = False):
        """📂 The edit of the video in the editor, applied to a whole folder."""
        from ui.folder_edit_dialog import FolderEditDialog

        dlg = FolderEditDialog(self, self.project, OUTPUT_DIR)
        pending = self._folder_pending if resume else None
        if pending:
            if pending.get("out_dir"):
                dlg.ed_out.setText(pending["out_dir"])
            dlg.add_videos(pending["videos"])
            self._folder_pending = None
            self.btn_top_folder.setVisible(False)
        if paths:
            dlg.add_videos(paths)
        dlg.setupRequested.connect(self._folder_setup)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.show()
        return dlg

    def _folder_setup(self, pending: dict):
        """Open episode 1 in Edit; the top bar button brings the folder back."""
        self._folder_pending = pending
        n = len(pending["videos"])
        self.btn_top_folder.setText(f"📂 Apply to the folder ({n})")
        self.btn_top_folder.setVisible(True)
        self.open_workspace("edit", pending["videos"][0])
        self.statusBar().showMessage(
            "Set the logo (Style tab), speed (Tools › Video), colour (Tools › Color "
            "Adjustments) … then click “📂 Apply to the folder” at the top.", 30000)

    def show_reframe(self, paths: Optional[List[str]] = None, shape: str = ""):
        """🔄 Reframe: turn / mirror / change the shape of videos (a new MP4 each)."""
        from ui.reframe_dialog import ReframeDialog

        if not paths and self.project.has_video() and self.project.video_path:
            paths = [self.project.video_path]
        dlg = ReframeDialog(self, paths or [])
        if shape:
            i = dlg.cmb_shape.findData(shape)
            if i >= 0:
                dlg.cmb_shape.setCurrentIndex(i)
        dlg.openRequested.connect(self.open_workspace)
        dlg.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose)
        dlg.show()
        return dlg

    def show_merge_split(self, paths: Optional[List[str]] = None, out_path: str = "",
                         tab: int = 0) -> MergeSplitDialog:
        """Merge & Split tool. paths = videos to put in the merge list."""
        if self.merge_dlg is None:
            self.merge_dlg = MergeSplitDialog(self, OUTPUT_DIR)
        dlg = self.merge_dlg
        if paths:
            dlg.set_videos(paths, out_path)
        else:
            dlg.tabs.setCurrentIndex(tab)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()
        return dlg

    def open_batch_item(self, autosave: str) -> bool:
        """Open a video of the batch queue in the editor (to check / fix it)."""
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, "Busy", "Please wait for the current task to finish.")
            return False
        if not self._maybe_save():
            return False
        self._open_project_file(autosave, as_autosave=True)
        return True

    def browse_video(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose a video", "", "Video files (*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.ts *.m2ts *.mts *.flv *.wmv *.mpg *.mpeg *.3gp *.vob)")
        if path:
            self.load_video(path)

    def show_project_settings(self):
        """Movavi: the pencil next to "Project settings" - video ratio + framing."""
        if not self._require_video():
            return
        dlg = ProjectSettingsDialog(self.project, self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        vals = dlg.values()
        p = self.project
        if all(getattr(p, k) == v for k, v in vals.items()):
            return
        self.push_undo()
        for k, v in vals.items():
            setattr(p, k, v)
        self.after_edit(audio=False, tables=False, subs=False)

    # window layout: Po's default sizes, then whatever was used last time
    def _restore_layout(self):
        h = settings.get("layout_h_split")
        v = settings.get("layout_v_split")
        if isinstance(h, list) and len(h) == 3 and all(isinstance(x, int) and x > 50 for x in h):
            self.h_split.setSizes(h)
        if isinstance(v, list) and len(v) == 2 and all(isinstance(x, int) and x > 50 for x in v):
            self.v_split.setSizes(v)

    def toggle_sidebar(self):
        """Hide / show the left side panel (AI steps, Tools, Library). Ctrl+\\"""
        self._sidebar_collapsed = not self._sidebar_collapsed
        try:
            settings.set("layout_sidebar_collapsed", self._sidebar_collapsed)
        except OSError:
            pass
        self._apply_sidebar()

    def _apply_sidebar(self):
        hidden = self._sidebar_collapsed
        self.left_stack.setVisible(not hidden)
        self.btn_sidebar.setText("▶" if hidden else "◀")
        self.btn_sidebar.setToolTip(("Show" if hidden else "Hide") + " the side panel (Ctrl+\\)")

    def _save_layout(self):
        h = getattr(self, "_left_sizes", None) or self.h_split.sizes()
        try:
            if h and h[0] > 50:                 # (0 while the side panel is hidden)
                settings.set("layout_h_split", [int(x) for x in h])
            settings.set("layout_v_split", [int(x) for x in self.v_split.sizes()])
            settings.set("window_maximized", bool(self.isMaximized()))
        except OSError:
            pass

    # ------------------------------------------------------------------ #
    # Home dashboard + workspaces (Testing)
    # ------------------------------------------------------------------ #
    def show_home(self):
        self.player.pause()
        self.home.refresh()
        self.home.show_page("home")
        self.root_stack.setCurrentWidget(self.home)
        self.menuBar().setVisible(False)

    def show_editor(self):
        self.root_stack.setCurrentWidget(self.editor_page)
        self.menuBar().setVisible(True)

    def open_workspace(self, kind: str, path: str = ""):
        """A Home card: Edit / Dub, with a dropped video or none."""
        self.set_workspace(kind)
        self.show_editor()
        if path:
            self.load_video(path)
        elif not self.project.has_video():
            self.statusBar().showMessage("Drop a video on the preview, or File › Open video", 8000)

    def set_workspace(self, kind: str):
        """Edit = picture + timeline + Subtitles / Style (no dubbing steps);
        Dub = everything. The project stays the same."""
        self.workspace = kind if kind in ("edit", "dub") else "dub"
        for k, b in self.ws_buttons.items():
            b.setChecked(k == self.workspace)
        self._apply_workspace()
        self._record_recent()

    def _apply_workspace(self):
        edit = self.workspace == "edit"
        if edit:
            if self.left_stack.currentWidget() is not self.tools:
                self.left_stack.setCurrentWidget(self.library)
        elif self.left_stack.currentWidget() is self.library:
            self.left_stack.setCurrentWidget(self.left)
        self.left_stack.setVisible(not self._sidebar_collapsed)
        self.btn_top_auto.setVisible(not edit)
        for i in range(self.right.count()):
            from ui.appearance import english_tab
            text = english_tab(self.right, i)
            dub_only = any(w in text for w in ("Transcript", "Translation", "Characters"))
            inspector = self.right.widget(i) in self._ins_tabs
            self.right.setTabVisible(i, (inspector and edit) or (not inspector and not
                                                                  (edit and dub_only)))
        if edit:
            self._load_edit_panels()
            if self.right.widget(self.right.currentIndex()) not in self._ins_tabs and \
                    not getattr(self, "_edit_seen", False):
                self.right.setCurrentWidget(self._ins_tabs[0])     # Video, like Filmora
            self._edit_seen = True
        elif self.right.widget(self.right.currentIndex()) in self._ins_tabs:
            self.right.setCurrentIndex(0)
        if edit and not self.right.isTabVisible(self.right.currentIndex()):
            for i in range(self.right.count()):
                if self.right.isTabVisible(i):
                    self.right.setCurrentIndex(i)
                    break

    def _plan_changed(self, plan: str):
        self.statusBar().showMessage(
            f"Previewing as a {plans.PLAN_NAMES[plan]} customer", 6000)

    def _gate(self, feature: str, what: str = "") -> bool:
        """True when the plan in use has the feature; else says which plan has it."""
        if plans.allows(feature):
            return True
        name = what or plans.FEATURE_NAMES.get(feature, feature)
        ans = QMessageBox.question(
            self, "Plan",
            f"“{name}” is in the {plans.needed(feature)} plan.\n"
            + (f"You are PREVIEWING the {plans.PLAN_NAMES[plans.current()]} plan as a customer "
               "(Plan page › Back to Admin opens everything).\n\n" if plans.is_admin() else
               f"You are testing the {plans.PLAN_NAMES[plans.current()]} plan.\n\n")
            + "Open the Plan page?")
        if ans == QMessageBox.StandardButton.Yes:
            self.show_home()
            self.home.show_page("plans")
        return False

    def _batch_status(self):
        b = self.batch
        if b is None or not getattr(b, "items", None):
            return None
        from core import batch as cb

        total = len(b.items)
        done = sum(1 for i in b.items if i.status == cb.DONE)
        busy = [os.path.basename(i.video_path) for i in b.items if i.status in cb.ACTIVE]
        if busy:
            now = "Now: " + ", ".join(busy[:2])
        else:
            now = "Running" if getattr(b, "running", False) else \
                "Not running – open it and click Start"
        return done, total, now

    def _home_batch(self, paths: list):
        if not self._gate("batch"):
            return
        self.show_batch()
        if paths:
            self.batch.add_videos(paths)

    def _home_quick(self, key: str):
        need = {"hide_subs": "hide_subs", "music_only": "music_only"}.get(key)
        if need and not self._gate(need):
            return
        if key == "merge":
            self.show_merge_split(tab=0)
            return
        if key == "split":
            self.show_merge_split(tab=1)
            return
        if key == "copyright":
            self.show_copyright()
            return
        if key == "reframe":
            self.show_reframe()
            return
        if key == "folder_edit":
            self.show_folder_edit()
            return
        kind = "dub" if key in ("srt",) else "edit"
        hints = {
            "hide_subs": "Open a video, then 🎨 Style › Hide the original subtitles › Auto detect",
            "black_bars": "Open a video, then Tools › Crop and Rotate › Remove black bars",
            "srt": "Open a video, run 1 · Transcribe and 2 · Translate, then Export › SRT",
            "music_only": "Open a video, then click Isolate BGM (bottom bar)",
            "tiktok": "Open a video, then Project settings (✎) › 9:16",
            "compress": "Open a video, then Export › Size 720p and Quality Smaller file",
        }
        self.open_workspace(kind, "")
        if self.project.has_video():
            if key == "hide_subs":
                self.right.setCurrentWidget(self.style_panel)
                self.detect_original_subtitles()
                return
            if key == "black_bars":
                self.remove_black_bars()
                return
            if key == "tiktok":
                self.show_project_settings()
                return
            if key in ("compress", "music_only"):
                self.export_video()
                return
        self.statusBar().showMessage(hints.get(key, ""), 12000)

    def show_glossary(self):
        from ui.glossary_dialog import GlossaryDialog, lists_for

        GlossaryDialog(self, lists_for(self.project)).exec()

    def show_sarika_voice(self):
        """🎙 Owner-only: SARIKA VOICE (ui/sarika_voice.py) in its own window."""
        from core import admin

        if not admin.is_owner():            # (never on a customer's PC)
            return
        # VoxCPM2 needs the GPU: let Whisper's memory go first (a 4 GB card had
        # 3.8 GB held by large-v3 - VoxCPM2 then failed and the server stopped)
        from core import transcribe

        busy = self.worker is not None and self.worker.isRunning()
        if not busy and not (self.batch and self.batch.is_running()) \
                and transcribe.release_models():
            self.log("🎤 SARIKA VOICE: Whisper's GPU memory was freed for VoxCPM2")
        from ui.sarika_voice import SarikaVoiceWindow

        w = getattr(self, "_sarika_voice", None)
        if w is None:
            w = self._sarika_voice = SarikaVoiceWindow(self)
        w.show()
        w.raise_()
        w.activateWindow()

    def show_qc(self):
        """✅ The lines of this video worth a look (core/qc.py)."""
        from core import qc
        from ui.qc_dialog import QCDialog

        p = self.project
        if not p.segments:
            QMessageBox.information(self, "Quality check", "Dub a video first.")
            return
        rows = qc.check_project(p)
        if not rows:
            QMessageBox.information(self, "Quality check", "✓ Nothing to check in this video.")
            return
        name = os.path.splitext(os.path.basename(p.video_path or ""))[0]
        for r in rows:
            r["episode"], r["autosave"] = name, ""
        dlg = QCDialog(self, rows, "", 1)
        dlg.tbl.cellDoubleClicked.disconnect()
        dlg.tbl.cellDoubleClicked.connect(
            lambda row, _c: self.seek(max(0.0, float(
                dlg.tbl.item(row, 0).data(Qt.ItemDataRole.UserRole)["time"]) - 0.3)))
        dlg.show()

    # ------------------------------------------------------------------ #
    # Updates
    # ------------------------------------------------------------------ #
    def _auto_update_check(self):
        from core import updates

        if not updates.url():
            return
        import threading

        def run():
            try:
                info = updates.check()
            except Exception as e:
                print(f"[update] {e}")
                return
            if info:
                self._update_found = info
                QTimer.singleShot(0, self, lambda: self._show_update(info, auto=True))
        threading.Thread(target=run, daemon=True).start()

    def show_system_check(self):
        from ui.support_dialogs import SystemCheckDialog

        SystemCheckDialog(self).exec()

    def _problem_report(self):
        from ui.support_dialogs import send_problem_report

        send_problem_report(self)

    def _tutorials(self):
        from ui.support_dialogs import open_tutorials

        open_tutorials(self)

    def show_about(self):
        from ui.about_dialog import AboutDialog

        AboutDialog(self, on_check_updates=self.check_updates).exec()

    def check_updates(self, ask_link: bool = False):
        from PySide6.QtWidgets import QInputDialog

        from core import admin, updates

        link = updates.url()
        if not link and not ask_link and not admin.is_owner():
            QMessageBox.information(self, "Check for updates",
                                    "This copy has no update link yet.\n"
                                    "Ask the seller for the newest version.")
            return
        if not link or ask_link:
            link, ok = QInputDialog.getText(
                self, "Check for updates",
                "Where version.json is - a direct web link (GitHub raw, your website …)\n"
                "or a file on this PC / the network (D:\\updates\\version.json):",
                text=link)
            if not ok or not link.strip():
                return
            updates.set_url(link)
        from PySide6.QtWidgets import QApplication

        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        err = None
        try:
            info = updates.check(force=True)
        except Exception as e:
            info, err = None, e
        finally:
            QApplication.restoreOverrideCursor()
        if err is not None:
            box = QMessageBox(QMessageBox.Icon.Warning, "Check for updates",
                              f"Could not check:\n{err}\n\nLink: {updates.url()}", parent=self)
        elif info:
            self._update_found = info
            self._show_update(info)          # a new version: told right away
            return
        else:
            from core import __version__
            box = QMessageBox(QMessageBox.Icon.Information, "Check for updates",
                              f"✓ You have the newest version ({__version__}).", parent=self)
        b_link = box.addButton("Change link…", QMessageBox.ButtonRole.ActionRole)
        box.addButton(QMessageBox.StandardButton.Ok)
        box.exec()
        if box.clickedButton() is b_link:
            self.check_updates(ask_link=True)

    def _show_update(self, info: dict, auto: bool = False):
        from core import __version__, settings as st, updates

        ok, why = updates.can_patch(info)
        box = QMessageBox(self)
        box.setWindowTitle("New version")
        box.setText(f"<b>Version {info['version']}</b> is ready (you have {__version__}).")
        notes = str(info.get("notes", "") or "")
        if ok:
            notes += "\n\n⬆ Update now: downloads only the changes and installs them – " \
                     "no new installer. The app restarts once."
        elif info.get("patch_url"):
            notes += f"\n\n(Update now is not possible: {why})"
        box.setInformativeText(notes)
        b_now = box.addButton("⬆ Update now", QMessageBox.ButtonRole.AcceptRole) if ok else None
        b_get = box.addButton("⬇ Download installer" if ok else "⬇ Download",
                              QMessageBox.ButtonRole.ActionRole) if info.get("url") else None
        b_skip = box.addButton("Skip this version", QMessageBox.ButtonRole.RejectRole) \
            if auto else None
        box.addButton("Later", QMessageBox.ButtonRole.RejectRole)
        if b_now is not None:
            box.setDefaultButton(b_now)
        box.exec()
        clicked = box.clickedButton()
        if b_now is not None and clicked is b_now:
            self.install_update(info)
        elif b_get is not None and clicked is b_get:
            open_path(info["url"])
        elif b_skip is not None and clicked is b_skip:
            st.set(updates.SKIP_SETTING, str(info["version"]))

    def install_update(self, info: dict):
        """⬆ Update now: download + check + unpack the update package, restart."""
        import tempfile

        from PySide6.QtWidgets import QProgressDialog

        from core import updates
        from ui.workers import TaskWorker

        dest = os.path.join(tempfile.gettempdir(), f"voxdub_update_{info['version']}.zip")

        def job(progress, should_stop):
            updates.download(str(info["patch_url"]), dest, progress, should_stop)
            progress(95, "Checking and installing…")
            return updates.install_package(dest, info)

        dlg = QProgressDialog("Downloading the update…", "Cancel", 0, 100, self)
        dlg.setWindowTitle("Update")
        dlg.setMinimumDuration(0)
        dlg.setAutoClose(False)
        w = TaskWorker(job, "Update", self)
        w.progress.connect(lambda v, t: (dlg.setValue(v), dlg.setLabelText(t)))
        dlg.canceled.connect(w.stop)

        def done(version):
            dlg.close()
            self.log(f"⬆ Update {version} installed - used from the next start")
            if QMessageBox.question(
                    self, "Update",
                    f"✓ Version {version} is installed.\n\nRestart SARIKA VOXDUB PRO now?") \
                    == QMessageBox.StandardButton.Yes:
                self.restart_app()

        def failed(err):
            dlg.close()
            QMessageBox.warning(self, "Update", f"The update was not installed:\n{err}")

        w.done.connect(done)
        w.failed.connect(failed)
        self._update_worker = w
        w.start()
        dlg.show()

    def restart_app(self):
        """Close (asking to save as usual) and start again."""
        import subprocess

        if not self.close():
            return
        args = [sys.executable] + (sys.argv[1:] if getattr(sys, "frozen", False)
                                   else [os.path.abspath(sys.argv[0])] + sys.argv[1:])
        try:
            subprocess.Popen(args, close_fds=True)
        finally:
            from PySide6.QtWidgets import QApplication

            QApplication.quit()

    def remove_update(self):
        from core import updates

        if QMessageBox.question(
                self, "Remove update",
                f"Go back to the installed version {updates.installed_version()}?\n"
                "(Your projects, settings and presets stay.)") != QMessageBox.StandardButton.Yes:
            return
        updates.remove_updates()
        if QMessageBox.question(self, "Remove update", "Done. Restart now?") \
                == QMessageBox.StandardButton.Yes:
            self.restart_app()

    def show_copyright(self):
        """© Copyright check of the video in the editor (rights · music · YouTube)."""
        from core.separate import has_music, music_path
        from ui.copyright_dialog import CopyrightDialog

        p = self.project
        if not p.has_video():
            path, _ = QFileDialog.getOpenFileName(
                self, "Video to check", "", "Video files (*.mp4 *.mov *.mkv *.avi *.webm *.m4v *.ts *.m2ts *.mts *.flv *.wmv *.mpg *.mpeg *.3gp *.vob)")
            if not path:
                return
            CopyrightDialog(self, path).exec()
            return
        sound = music_path(p) if p.work_dir and has_music(p) else ""
        CopyrightDialog(self, p.video_path, sound_path=sound).exec()

    def _home_recent(self, entry: dict):
        path = entry.get("path", "")
        if not os.path.isfile(path):
            recent.remove(path)
            self.home.refresh()
            return
        self.set_workspace(entry.get("kind", "dub"))
        self.show_editor()
        if os.path.abspath(path) == os.path.abspath(self.project_path or "") or \
                os.path.abspath(path) == os.path.abspath(self.project.autosave_path() or "x"):
            return
        if self._busy("Open project") or not self._maybe_save():
            return
        self._open_project_file(path, as_autosave=path.endswith("autosave.voxdub.json"))

    def _project_state(self) -> str:
        p = self.project
        if any(s.tts_path for s in p.segments):
            return "Voices ready"
        if any(s.translation.strip() for s in p.segments):
            return "Translated"
        if p.segments:
            return "Transcribed"
        return "Draft"

    def _record_recent(self, state: str = ""):
        p = self.project
        if not p.has_video():
            return
        path = self.project_path or p.autosave_path()
        if not path or not os.path.isfile(path):
            return
        recent.add(path, self.workspace, os.path.basename(p.video_path), p.video_path,
                   p.video_duration, state or self._project_state())

    def show_initial(self):
        """Open maximized (the layout is made for a full screen) unless the user
        last closed the app in a smaller window."""
        if settings.get("window_maximized", True):
            self.showMaximized()
        else:
            self.resize(1400, 860)
            self.show()
        self.show_home()
        # 2.6.3: a new version, something missing (ffmpeg ...): System check shows it
        from PySide6.QtCore import QTimer

        def first_check():
            try:
                from ui.support_dialogs import maybe_first_check
                maybe_first_check(self)
            except Exception as e:
                print(f"[syscheck] {e}")
        QTimer.singleShot(2500, first_check)

    def show_help(self, topic: str = ""):
        from ui.help_dialog import HelpDialog

        dlg = getattr(self, "_help", None)
        if dlg is None:
            dlg = self._help = HelpDialog(self, topic)
        elif topic:
            dlg.open_topic(topic)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def show_admin(self):
        from ui.admin_dialog import AdminDialog

        AdminDialog(self).exec()

    def _remind_admin(self):
        """Seller's PC: who must renew soon (shown once at start)."""
        from core import admin
        if not admin.is_owner():
            return
        soon = [c.get("name", "") for c in admin.load()
                if admin.status(c)["state"] == "soon"]
        if soon:
            self.log(f"👑 License ends within 5 days: {', '.join(soon[:8])}"
                     + (" …" if len(soon) > 8 else "") + "  (Help › Admin – Customers & keys)")

    def _remind_renew(self):
        """7 and 3 days before the licence ends: a message (once each)."""
        try:
            step = lic.reminder_due()
        except Exception:
            return
        if not step:
            return
        info = lic.current()
        box = QMessageBox(self)
        box.setWindowTitle("Licence")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText(f"<b>Your licence ends in {max(0, info.days_left)} day(s)</b> "
                    f"({info.expires.isoformat()}).<br><br>Renew now – the new time is "
                    "added to the days that are left, and your settings and projects stay.")
        renew = box.addButton("Renew now", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Later", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is renew:
            self.show_home()
            self.home.show_page("plans")

    def show_license(self):
        from core import admin
        if admin.is_owner():
            self.show_admin()
            self._update_license_badge()
            return
        dlg = LicenseDialog(self)
        dlg.licenseChanged.connect(self._update_license_badge)
        dlg.exec()
        self._update_license_badge()

    def _home_license(self):
        """Plan & licence › Enter licence key (the Admin's PC: customers & keys)."""
        self.show_license()
        self.home.refresh()

    def show_engines(self, tab: str = "gemini"):
        from ui.engines_dialog import EnginesDialog

        EnginesDialog(self, tab).exec()
        self.left._refresh_voices()

    def _check_engine_keys(self):
        """Gemini / VoxCPM chosen but not set up yet: open the settings at once."""
        from core import gemini, voxcpm

        L = self.left
        if "gemini" in (L.cmb_stt.currentData(), L.cmb_translator.currentData()) \
                and not gemini.configured():
            self.log("✨ Gemini needs your Google AI Studio API key")
            self.show_engines("gemini")
        elif L.cmb_engine.currentData() == "voxcpm" and not (
                settings.get("voxcpm_python", "")
                or any(os.path.isfile(c) for c in voxcpm.candidates())):
            self.log("🎙 VoxCPM2 is not set up yet")
            self.show_engines("voxcpm")

    def show_azure_key(self):
        if AzureKeyDialog(self).exec():
            self.log("Azure Speech key saved")

    # ------------------------------------------------------------------ #
    # Characters (one voice per character)
    # ------------------------------------------------------------------ #
    def run_find_characters(self):
        if not self.project.segments:
            QMessageBox.information(self, "Characters", "Transcribe the video first (step 1).")
            return
        work = self._work_copy()

        def done(w):
            self._adopt(w, f"✅ {len(w.cast)} characters found – check them in 👥 Characters")
            self.right.setCurrentWidget(self.right.characters_page)

        self._start_task("Find characters",
                         lambda prog, stop: (pipeline.detect_characters(work, prog, stop), work)[1],
                         done)

    def run_auto_delivery(self):
        """Delivery of every line (not chosen by hand) from the original speech."""
        if not self.project.segments:
            QMessageBox.information(self, "Delivery", "Transcribe the video first (step 1).")
            return
        from core import emotion

        work = self._work_copy()

        def done(w):
            n = sum(1 for a, b in zip(self.project.segments, w.segments)
                    if a.id == b.id and a.delivery != b.delivery)
            c = emotion.counts(w)
            parts = ", ".join(f"{v} {k}" for k, v in sorted(c.items(), key=lambda kv: -kv[1])
                              if k != "normal")
            self._adopt(w, f"🎭 Delivery: {parts or 'all normal'} – {n} lines changed "
                           "(‘Re-voice all’ to hear them)")

        self._start_task("Auto delivery",
                         lambda prog, stop: (emotion.detect(work), work)[1], done)

    def _characters_changed(self):
        self.after_edit(audio=False, subs=False)
        if self.project.series_cast:            # the next episodes follow the change
            from core import series

            try:
                series.update_from_project(self.project)
            except Exception as e:
                self.log(f"⚠ Series cast not updated: {e}")
        stale = len(self.project.stale_voices())
        if stale and any(s.tts_path for s in self.project.segments):
            self.statusBar().showMessage(
                f"{stale} lines will get the new voice – click ‘🔊 Voice the changed lines’", 6000)

    def listen_character(self, label: str):
        """Play this character's lines from the original audio (a few seconds)."""
        from core import speakers

        if not self.project.original_audio or not os.path.isfile(self.project.original_audio):
            return
        out = os.path.join(tempfile.gettempdir(), f"voxdub_char_{label}_{int(time.time())}.wav")
        try:
            speakers.reference_from_video(self.project, label, out, seconds=8.0)
        except Exception as e:
            self.statusBar().showMessage(f"Cannot play {label}: {e}", 5000)
            return
        self.sample_player.setSource(QUrl.fromLocalFile(out))
        self.sample_player.play()

    def _toggle_gender(self, seg_id: str):
        seg = self.project.segment_by_id(seg_id)
        if seg is None:
            return
        if self.project.cast:
            self._speaker_menu(seg)
            return
        self.push_undo()
        seg.gender = "female" if seg.gender == "male" else "male"
        self.after_edit(audio=False, subs=False)
        if self.project.voice == AUTO_VOICE:
            self.statusBar().showMessage(
                f"Line set to {'♀ female' if seg.gender == 'female' else '♂ male'} – "
                "click ‘3 · Voice’ to regenerate the changed lines", 6000)

    def _speaker_menu(self, seg):
        """Who speaks this line (and the other selected lines)?"""
        from PySide6.QtGui import QCursor
        from PySide6.QtWidgets import QMenu

        from core import speakers
        from ui.characters_panel import move_lines

        ids = self.right.selected_segment_ids()
        if seg.id not in ids:
            ids = [seg.id]
        menu = QMenu(self)
        title = menu.addAction(f"Who speaks {'these ' + str(len(ids)) + ' lines' if len(ids) > 1 else 'this line'}?")
        title.setEnabled(False)
        cast = self.project.cast
        for lab in sorted(cast, key=lambda l: (-(cast[l].get("seconds") or 0), l)):
            c = cast[lab]
            sign = {"male": "♂", "female": "♀"}.get(c.get("gender"), "")
            a = menu.addAction(f"{sign}  {speakers.display(self.project, lab)}")
            a.setCheckable(True)
            a.setChecked(lab == seg.speaker)
            a.setData(lab)
        menu.addSeparator()
        new = menu.addAction("＋ New character")
        new.setData("__new__")
        chosen = menu.exec(QCursor.pos())
        if chosen is None or not chosen.data():
            return
        target = chosen.data()
        if target == "__new__":
            target = speakers.next_label(self.project)
        self.push_undo()
        move_lines(self.project, ids, target)
        self._characters_changed()

    def _azure_ready(self) -> bool:
        """Engine Azure without a key: ask for it first."""
        self.left.apply_to_project(self.project)
        if self.project.tts_engine != "azure" or azure_configured():
            return True
        QMessageBox.information(self, "Azure Speech",
                                "Engine is Azure Speech: enter your Azure key first.")
        self.show_azure_key()
        return azure_configured()

    # ------------------------------------------------------------------ #
    # Background tasks
    # ------------------------------------------------------------------ #
    def _start_task(self, title: str, fn: Callable, on_done: Callable,
                    on_partial: Optional[Callable] = None):
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, "Busy", "Please wait for the current task to finish.")
            return
        if self.batch and self.batch.is_running():
            QMessageBox.information(self, "Busy", "The batch queue is running. Stop it first "
                                                  "(File > Batch queue) or wait for it to finish.")
            return
        self.player.pause()
        self.left.set_busy(True)
        # the task works on a copy and brings its lines / clips / characters
        # back when it ends: edits made meanwhile would be lost, so the
        # tables and the timeline wait (the video can still be played)
        self.right.setEnabled(False)
        self.timeline.setEnabled(False)
        self.btn_top_auto.setEnabled(False)
        self.left.set_progress(0, title + "...")
        self.log(f"▶ {title}")
        started = time.time()
        self.worker = TaskWorker(fn, title, self)
        self.worker.progress.connect(self.left.set_progress)

        def done(result):
            self._task_finished()
            self.log(f"✔ {title} finished in {time.time() - started:.1f}s")
            on_done(result)

        def failed(err):
            self._task_finished()
            kept = on_partial() if on_partial else ""
            self.left.set_progress(0, "❌ " + err.splitlines()[0])
            self.log(f"✖ {title} failed: {err}")
            if kept:
                self.log(kept)
            if "Cancelled" not in err:
                QMessageBox.warning(self, title, err + ("\n\n" + kept if kept else ""))

        self.worker.done.connect(done)
        self.worker.failed.connect(failed)
        self.worker.start()

    def _task_finished(self):
        self.right.setEnabled(True)
        self.timeline.setEnabled(True)
        self.left.set_busy(False)
        self.btn_top_auto.setEnabled(True)

    def cancel_task(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.log("Cancelling... (stops after the current line)")

    def _adopt(self, work: Project, label: str):
        """Take the result of a background step into the live project."""
        self.push_undo()
        self.project.segments = work.segments
        # the dub may slow parts of the video for long lines: the voices and
        # subtitles were placed on THAT timeline, so take the video clips too
        self.project.video_clips = work.video_clips
        self.project.layout_video()
        self.project.audio_clips = work.audio_clips
        self.project.subtitle_clips = work.subtitle_clips
        self.project.detected_lang = work.detected_lang
        self.project.transcribe_done = work.transcribe_done
        self.project.transcribed_until = work.transcribed_until
        self.project.cast = work.cast
        if (work.tts_engine, work.voice) != (self.project.tts_engine, self.project.voice):
            # VoxCPM gave up and Edge finished the job: show the engine really used
            self.project.tts_engine, self.project.voice = work.tts_engine, work.voice
            self.left.load_from_project(self.project)
        for note in work.engine_notes:      # Gemini / VoxCPM gave up: what took over
            self.log(note)
        work.engine_notes.clear()
        self.project.engine_notes.clear()
        self.after_edit()
        self.left.set_progress(100, label)
        self._autosave_now()

    def _autosave_now(self):
        path = self.project.autosave_path()
        if path:
            try:
                self.project.save(path)
            except Exception as e:
                self.log(f"Autosave failed: {e}")

    def _keep_partial(self, work: Project) -> str:
        """A step stopped part-way: keep what it finished. Returns a message."""
        if not work.has_progress() and not work.audio_clips:
            return ""
        self._adopt(work, "⚠ Stopped – finished work kept")
        return "✔ " + self._progress_text(work) + "\nClick the same button again to continue."

    @staticmethod
    def _progress_text(p: Project) -> str:
        st = p.progress_summary()
        n = st["lines"]
        parts = []
        if st["transcribed"]:
            parts.append(f"transcribed {n} lines")
        else:
            parts.append(f"transcribed up to {format_time(st['transcribed_until'], False)} "
                         f"({n} lines)")
        parts.append(f"translated {st['translated']}/{n}")
        parts.append(f"voiced {st['voiced']}/{n}")
        return "Progress saved: " + ", ".join(parts)

    # ------------------------------------------------------------------ #
    # Video loading
    # ------------------------------------------------------------------ #
    def _find_unfinished(self, video_path: str) -> str:
        """Newest autosave in output/ that belongs to this video, or ''."""
        target = os.path.normcase(os.path.abspath(video_path))
        best, best_t = "", 0.0
        for f in glob.glob(os.path.join(OUTPUT_DIR, "*", "autosave.voxdub.json")):
            try:
                t = os.path.getmtime(f)
                if t <= best_t:
                    continue
                with open(f, "r", encoding="utf-8") as fh:
                    head = fh.read(4096)          # video_path is near the top
                i = head.find('"video_path"')
                if i < 0:
                    continue
                val = json.loads(head[i:].split(":", 1)[1].split(",\n", 1)[0])
                if os.path.normcase(os.path.abspath(val)) == target:
                    best, best_t = f, t
            except Exception:
                continue
        return best

    def _busy(self, what: str) -> bool:
        """A step is running on the current project: opening another one now
        would get that step's result written into it."""
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, what, "Please wait for the current task to finish "
                                                "(or click Cancel) first.")
            return True
        return False

    def load_video(self, path: str):
        if not os.path.isfile(path):
            return
        if self._busy("Open video"):
            return
        if not self._maybe_save():
            return
        saved = self._find_unfinished(path)
        if saved:
            try:
                prev = Project.load(saved)
            except Exception:
                prev = None
            if prev is not None and prev.has_progress():
                ans = QMessageBox.question(
                    self, "Continue earlier work?",
                    f"This video was worked on before "
                    f"({time.strftime('%Y-%m-%d %H:%M', time.localtime(os.path.getmtime(saved)))}).\n"
                    + self._progress_text(prev) + "\n\nOpen that work and continue?")
                if ans == QMessageBox.StandardButton.Yes:
                    self._open_project_file(saved, as_autosave=True)
                    return
        stem = os.path.splitext(os.path.basename(path))[0]
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in stem)[:40]
        work_dir = os.path.join(OUTPUT_DIR, f"{safe}_{time.strftime('%Y%m%d_%H%M%S')}")
        fresh = Project()
        self.left.apply_to_project(fresh)

        def job(progress, should_stop):
            return pipeline.prepare_video(fresh, path, work_dir, progress)

        def done(project: Project):
            self.project = project
            self.project_path = ""
            self.undo_stack.clear()
            self.redo_stack.clear()
            self.player.load_video(project.video_path)
            self.dirty = False
            self._refresh_all()
            QTimer.singleShot(50, self.timeline.zoom_fit)
            self.log(f"Loaded {os.path.basename(path)} "
                     f"({project.width}x{project.height}, {project.video_duration:.1f}s)")
            if not project.has_audio:
                self.log("⚠ This video has no audio track – nothing to transcribe.")

        self._start_task("Loading video", job, done)

    # ------------------------------------------------------------------ #
    # AI steps
    # ------------------------------------------------------------------ #
    def _work_copy(self) -> Project:
        self.left.apply_to_project(self.project)
        return copy.deepcopy(self.project)

    def _ask_resume(self, title: str) -> Optional[bool]:
        """Existing progress: continue (False) / start over (True) / cancel (None)."""
        box = QMessageBox(self)
        box.setWindowTitle(title)
        box.setIcon(QMessageBox.Icon.Question)
        box.setText(self._progress_text(self.project) + "\n\nContinue where it stopped?")
        b_cont = box.addButton("Continue", QMessageBox.ButtonRole.AcceptRole)
        b_new = box.addButton("Start over", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton(QMessageBox.StandardButton.Cancel)
        box.setDefaultButton(b_cont)
        box.exec()
        clicked = box.clickedButton()
        if clicked == b_cont:
            return False
        if clicked == b_new:
            return True
        return None

    def run_auto_dub(self):
        if not self._require_video() or not self._azure_ready():
            return
        self.left.apply_to_project(self.project)
        if self.project.translate_engine == "gemini" and not self._gate("gemini"):
            return
        if self.project.tts_engine == "voxcpm" and not self._gate("voice_clone"):
            return
        restart = False
        if self.project.has_progress():
            if self.project.is_complete():
                ans = QMessageBox.question(
                    self, "Auto Dub",
                    "This video is already dubbed.\nStart over and redo everything?")
                if ans != QMessageBox.StandardButton.Yes:
                    return
                restart = True
            else:
                choice = self._ask_resume("Auto Dub")
                if choice is None:
                    return
                restart = choice
        work = self._work_copy()
        self._start_task("Auto Dub",
                         lambda prog, stop: pipeline.auto_dub(work, prog, stop, restart=restart),
                         lambda w: (self._adopt(w, "✅ Auto Dub complete – edit on the "
                                                   "timeline, then Export"),
                                    self.right.setCurrentIndex(1)),
                         lambda: self._keep_partial(work))

    def run_transcribe(self):
        if not self._require_video():
            return
        restart = False
        if self.project.transcribe_done and self.project.segments:
            ans = QMessageBox.question(
                self, "Transcribe",
                "The video is already transcribed.\nTranscribe it again? "
                "(translations and AI voices will be removed)")
            if ans != QMessageBox.StandardButton.Yes:
                return
            restart = True
        work = self._work_copy()
        self._start_task("Transcribe",
                         lambda prog, stop: pipeline.step_transcribe(work, prog, stop,
                                                                     restart=restart),
                         lambda w: (self._adopt(w, f"✅ {len(w.segments)} lines transcribed "
                                                   f"(language: {w.detected_lang})"),
                                    self.right.setCurrentIndex(0)),
                         lambda: self._keep_partial(work))

    def run_double_check(self):
        """Read the subtitles burned into the picture (OCR) and correct the
        transcript with them; changed lines are translated / voiced again."""
        from core import ocr_subs
        from core.sync import build_subtitles

        if not self._require_video():
            return
        if not self.project.segments:
            QMessageBox.information(self, "Double-check", "Transcribe the video first (step 1).")
            return
        if not ocr_subs.available():
            QMessageBox.information(
                self, "Double-check",
                "The OCR reader is not installed.\n\n" + (
                    "Please install SARIKA VOXDUB PRO again." if FROZEN else
                    "Run install.bat again (or: .venv\\Scripts\\python -m pip install "
                    "rapidocr_onnxruntime)."))
            return
        work = self._work_copy()

        def job(progress, should_stop):
            msg = pipeline.double_check_with_screen(work, progress, should_stop)
            build_subtitles(work, use_translation=True)
            return msg

        def done(msg):
            self._adopt(work, "🔍 " + msg)
            n = len(work.untranslated())
            if n:
                self.log(f"{n} lines are new or corrected – click AUTO DUB (or 2 · Translate, "
                         f"3 · Voice) to translate and voice them")
            self.right.setCurrentIndex(0)

        self._start_task("Double-check", job, done)

    def run_translate(self):
        if not self._require_video():
            return
        self.left.apply_to_project(self.project)
        if self.project.translate_engine == "gemini" and not self._gate("gemini"):
            return
        if not self.project.segments:
            QMessageBox.information(self, "Translate", "Transcribe the video first (step 1).")
            return
        only_missing = True
        if not self.project.untranslated():
            ans = QMessageBox.question(self, "Translate",
                                       "All lines are translated.\nTranslate every line again?")
            if ans != QMessageBox.StandardButton.Yes:
                return
            only_missing = False
        work = self._work_copy()
        self._start_task("Translate",
                         lambda prog, stop: pipeline.step_translate(work, prog, stop,
                                                                    only_missing=only_missing),
                         lambda w: (self._adopt(w, "✅ Translation done"),
                                    self.right.setCurrentIndex(1)),
                         lambda: self._keep_partial(work))

    def run_voice(self, ids: Optional[List[str]] = None, force: bool = False):
        if not self._require_video() or not self._azure_ready():
            return
        if self.project.tts_engine == "voxcpm" and not self._gate("voice_clone"):
            return
        if not self.project.segments:
            QMessageBox.information(self, "AI Voice", "Transcribe the video first (step 1).")
            return
        if ids is not None and not ids:
            QMessageBox.information(self, "AI Voice", "Select one or more lines first.")
            return
        if ids is None and not force and not self.project.stale_voices():
            ans = QMessageBox.question(self, "AI Voice",
                                       "Every line already has an up-to-date voice.\n"
                                       "Generate all voices again?")
            if ans != QMessageBox.StandardButton.Yes:
                return
            force = True
        work = self._work_copy()
        self._start_task("Generate AI voice",
                         lambda prog, stop: pipeline.step_voice(work, ids, prog, stop,
                                                                force=force),
                         lambda w: self._adopt(w, "✅ AI voice placed on the timeline"),
                         lambda: self._keep_partial(work))

    def test_voice(self):
        p = Project()
        self.left.apply_to_project(p)
        text = SAMPLE_TEXT.get(p.target_lang, SAMPLE_TEXT["en"])
        out = os.path.join(tempfile.gettempdir(), f"voxdub_sample_{int(time.time())}.wav")

        voice = p.voice
        if voice == AUTO_VOICE:     # play the male voice, then the female one
            voice = voice_for_gender(p.tts_engine, p.target_lang, "male")
        if p.tts_engine == "azure" and not self._azure_ready():
            return

        def job(progress, should_stop):
            progress(30, "Generating sample voice...")
            return synthesize(text, out, p.tts_engine, voice, p.target_lang)

        def done(path):
            self.sample_player.setSource(QUrl.fromLocalFile(path))
            self.sample_player.play()
            self.left.set_progress(100, f"Playing sample: {voice}")

        self._start_task("Test voice", job, done)

    # ------------------------------------------------------------------ #
    # Style: original subtitles, ratio, logo, brand text
    # ------------------------------------------------------------------ #
    def _on_style_changed(self):
        self.player.set_project(self.project)
        self.timeline.refresh()             # hidden subtitles are drawn dimmed
        self._set_dirty(True)

    def set_subtitles_shown(self, on: bool):
        """CC button / Edit menu / Style tab: subtitles on or off (export too)."""
        if self.project.subs_hidden == (not on):
            return
        self.push_undo(overlay=True)
        self.project.subs_hidden = not on
        self.style_panel.load(self.project)
        self._on_style_changed()
        self.statusBar().showMessage(
            "Subtitles shown" if on else
            "Subtitles hidden – the exported video will have no subtitles (CC to show them)",
            5000)

    def hide_subtitle_lines(self, ids: List[str]):
        """Hide / show the selected subtitle lines (all hidden -> show them)."""
        if not ids:
            QMessageBox.information(self, "Subtitles", "Select one or more subtitles first.")
            return
        clips = [c for c in self.project.subtitle_clips if c.id in set(ids)]
        if not clips:
            return
        self.push_undo()
        hide = not all(c.hidden for c in clips)
        for c in clips:
            c.hidden = hide
        self.after_edit(audio=False, tables=False)
        self.statusBar().showMessage(
            f"{len(clips)} subtitle(s) {'hidden' if hide else 'shown again'}", 4000)

    def _on_overlay_moved(self):
        """Logo / brand text dragged in the preview: show "Custom" position."""
        self.style_panel.load(self.project)
        self._on_style_changed()

    def detect_original_subtitles(self):
        if not self._require_video() or not self._gate("hide_subs"):
            return
        path = self.project.video_path

        def job(progress, should_stop):
            return hardsub.detect_subtitle_area(path, progress=progress, should_stop=should_stop)

        def done(rect):
            if rect is None:
                self.left.set_progress(100, "No burned-in subtitles found")
                QMessageBox.information(
                    self, "Original subtitles",
                    "No burned-in subtitles were found.\n"
                    "Set the area by hand with Top / Height / Left / Width.")
                return
            p = self.project
            p.cover_rect = rect
            p.cover_enabled = True             # 2.4: our subtitles stay where they are
            self.style_panel.load(p)
            self._on_style_changed()
            self.left.set_progress(100, "✅ Original subtitles found – they will be hidden")
            self.log(f"Original subtitles at top {rect[1] * 100:.1f}%, "
                     f"height {rect[3] * 100:.1f}%")

        self._start_task("Detect original subtitles", job, done)

    def remove_black_bars(self):
        if not self._require_video():
            return
        path = self.project.video_path

        def job(progress, should_stop):
            return hardsub.detect_black_bars(path, progress=progress, should_stop=should_stop)

        def done(edges):
            if edges is None:
                self.left.set_progress(100, "No black bars found")
                QMessageBox.information(self, "Black bars",
                                        "No black bars were found around the picture.\n"
                                        "Set Top / Bottom / Left / Right by hand to crop.")
                return
            p = self.project
            self.push_undo()
            p.crop_left, p.crop_top, p.crop_right, p.crop_bottom = edges
            if self.tools.tool == "crop":
                self.tools.crop.show_crop(p)
            self.inspector.video.show_crop(p)
            self._on_style_changed()
            self.left.set_progress(100, "Black bars cropped: " + ", ".join(
                f"{n} {v * 100:.1f}%" for n, v in zip(("left", "top", "right", "bottom"), edges)
                if v))

        self._start_task("Remove black bars", job, done)

    def _subtitle_font(self) -> str:
        if getattr(self.project, "sub_font", ""):
            return self.project.sub_font
        return "Noto Sans Khmer" if self.project.target_lang == "km" else "Arial"

    def preview_frame(self):
        if not self._require_video():
            return
        snap = copy.deepcopy(self.project)
        t = self.player.position()
        out = os.path.join(tempfile.gettempdir(), f"voxdub_frame_{int(time.time() * 1000)}.png")
        opts = ExportOptions(output_path=out, resolution="720p",
                             burn_subtitles=bool(snap.shown_subtitles()),
                             subtitle_font=self._subtitle_font(),
                             watermark=lic.watermark_text())

        def job(progress, should_stop):
            progress(30, "Rendering frame...")
            return render_frame(snap, opts, t, out)

        def done(path):
            self.left.set_progress(100, "Preview frame ready")
            FramePreviewDialog(path, self).exec()

        self._start_task("Preview frame", job, done)

    # ------------------------------------------------------------------ #
    # Seeking / selection
    # ------------------------------------------------------------------ #
    def seek(self, t: float):
        self.player.seek(t)
        self.timeline.set_playhead(self.player.position())

    def _seek_source(self, src: float):
        t = self.project.source_to_timeline(src)
        if t is None:
            self.statusBar().showMessage("That part of the video was cut on the timeline", 3000)
            return
        self.seek(t)

    def _on_timeline_selection(self, kind: str, cid: str):
        if kind == "subs":
            self.right.select_subtitle(cid)
        if self.workspace == "edit" and kind in ("audio", "music"):
            # Filmora: clicking a sound clip shows its Audio properties
            clips = self.project.audio_clips if kind == "audio" else self.project.music_clips
            clip = next((c for c in clips if c.id == cid), None)
            self.inspector.load(self.project, clip)
            self.right.setCurrentWidget(self.inspector.widgets["audio"])
        if self.tools.tool == "audio":          # Audio Properties follows the selection
            clip = next((c for c in self.project.audio_clips if c.id == cid), None) \
                if kind == "audio" else None
            self.tools.open_tool("audio", self.project, clip)

    # ------------------------------------------------------------------ #
    # Tools: Crop & Rotate, Color Adjustments, Audio Properties
    # ------------------------------------------------------------------ #
    def open_tool(self, tool: str):
        if not self._require_video():
            return
        if tool == "ratio":                     # Video ratio lives in Project settings
            self.show_project_settings()
            return
        if self.workspace == "edit" and tool in ("crop", "color", "audio", "video"):
            # Edit (Filmora style): the inspector tab on the right
            tab = {"crop": "video", "video": "video", "color": "color", "audio": "audio"}[tool]
            voice = None
            if tool == "audio":
                kind, clip = self.timeline.canvas.selected_clip()
                voice = clip if kind == "audio" else None
            self.inspector.load(self.project, voice)
            self.right.setCurrentWidget(self.inspector.widgets[tab])
            if tool == "crop":
                self.inspector.video.btn_crop.setChecked(True)
            return
        if self.tools.tool == tool and self.left_stack.currentWidget() is self.tools:
            self.tools.close_tool()             # second click on the button closes it
            return
        if self.tools.tool == "crop" and tool != "crop":
            self.player.set_crop_mode(False)
        voice = None
        if tool in ("audio", "video"):
            kind, clip = self.timeline.canvas.selected_clip()
            voice = clip if kind == "audio" else None
        self.tools.open_tool(tool, self.project, voice)
        if self.left_stack.currentWidget() is not self.tools:
            sizes = self.h_split.sizes()
            self._left_sizes = sizes
            want = 470                          # the Tools panel needs room for sliders
            if sizes[0] < want:
                grow = want - sizes[0]
                self.h_split.setSizes([want, max(300, sizes[1] - grow), sizes[2]])
        self.left_stack.setCurrentWidget(self.tools)
        self.left_stack.setVisible(True)        # (Edit workspace hides the dub steps)
        if tool == "crop":
            self.player.pause()
            self.player.set_crop_mode(True, self.tools.crop.keep.isChecked())
        names = {"crop": "Crop and Rotate", "color": "Color Adjustments",
                 "audio": "Audio Properties", "video": "Clip Properties"}
        self.statusBar().showMessage(f"Tools: {names[tool]}", 3000)

    # ------------------------------------------------------------------ #
    # Edit workspace: library (left) + inspector (right)
    # ------------------------------------------------------------------ #
    def _load_edit_panels(self):
        if getattr(self, "workspace", "dub") != "edit" or not hasattr(self, "inspector"):
            return
        self.inspector.load(self.project)
        self.library.load(self.project, self._source_at_playhead())

    def _source_at_playhead(self) -> float:
        try:
            if self.project.video_clips:
                return float(self.project.timeline_to_source(self.player.position())[1] or 0)
        except Exception:
            pass
        return 0.0

    def _right_tab_changed(self, i: int):
        if self.right.widget(i) in getattr(self, "_ins_tabs", []):
            self.inspector.load(self.project)
        if self._ins_crop and self.right.widget(i) is not self.inspector.widgets["video"]:
            self.inspector.video.btn_crop.setChecked(False)

    def _inspector_crop(self, on: bool):
        if on and not self._require_video():
            self.inspector.video.btn_crop.setChecked(False)
            return
        self._ins_crop = on
        if on:
            self.player.pause()
        self.player.set_crop_mode(on, self.inspector.video.keep.isChecked())
        if not on:
            self.style_panel.load(self.project)
            self.after_edit(audio=False, tables=False, subs=False)

    def _crop_from_preview(self, l, t, r, b):
        (self.inspector if self._ins_crop else self.tools).crop_from_preview(l, t, r, b)

    def _library_apply(self, kind: str, fn):
        """A look from the library (title, logo, colour filter): one Undo step."""
        self.push_undo()
        fn(self.project)
        self.style_panel.load(self.project)
        self._load_edit_panels()
        self._on_style_changed()
        self.after_edit(audio=False, tables=False, subs=False)

    def delete_clip(self):
        """Delete key / 🗑 / right-click › Delete: say why when nothing happens."""
        if self.timeline.delete_selected():
            return
        kind, clip = self.timeline.canvas.selected_clip()
        if clip is not None and kind == "video":
            self.close_video()              # the last piece: the whole video goes
            return
        if clip is None:
            msg = "Click a clip on the timeline first, then Delete."
        else:
            msg = "This clip cannot be deleted."
        self.statusBar().showMessage(msg, 10000)
        QToolTip.showText(QCursor.pos(), msg, self.timeline)

    def close_video(self, ask: bool = True) -> bool:
        """Take the video off the timeline: an empty project, ready for another
        video (the video file itself is not touched)."""
        if not self.project.has_video():
            return False
        if self._busy("Delete the video"):
            return False
        if ask:
            ans = QMessageBox.question(
                self, "Delete the whole video",
                "Take this video off the timeline?\n\nThe timeline becomes empty – drop or "
                "open another video. The video file is not deleted, and this work stays "
                "under Home › Recent projects.\n\n(To remove only a part: press S at its "
                "start and end, then delete that piece.)")
            if ans != QMessageBox.StandardButton.Yes:
                return False
        self._autosave()                    # (kept under Home › Recent projects)
        fresh = Project()
        self.left.apply_to_project(fresh)
        self.player.clear()
        self.project = fresh
        self.project_path = ""
        self.undo_stack.clear()
        self.redo_stack.clear()
        self.timeline.canvas.selected = None
        self.dirty = False
        self._refresh_all()
        self.statusBar().showMessage("The timeline is empty – drop a video on the preview, or "
                                     "double-click one in Media.", 10000)
        return True

    def _timeline_drop(self, paths: list, t: float):
        """Files dragged from Media (or Explorer) onto the timeline."""
        from core.media import VIDEO_EXT
        from core.music import is_audio

        sounds = [p for p in paths if is_audio(p)]
        videos = [p for p in paths if p.lower().endswith(VIDEO_EXT)]
        if sounds and self.project.has_video() and \
                self._music_ready(sounds, lambda: self._timeline_drop(paths, t)):
            return
        at = t
        for s in sounds:                    # one after the other from the drop point
            self.add_music(s, at)
            if self.project.music_clips:
                at = max(c.end for c in self.project.music_clips if c.start >= t - 1e-3)
        if videos and not sounds:
            if not self.project.has_video():
                self.load_video(videos[0])
            else:
                QMessageBox.information(
                    self, "Video",
                    "A project has one video for now.\n\nTo open this video instead, "
                    "double-click it in Media. To join several videos into one, use "
                    "Merge / Split.")
        elif not sounds and not videos:
            self.statusBar().showMessage("Only music / sound files and videos can be "
                                         "dropped on the timeline.", 6000)

    # ---- 🎵 Music track
    def browse_music(self):
        from core.music import AUDIO_EXT

        if not self._require_video():
            return
        pat = " ".join("*" + e for e in AUDIO_EXT)
        path, _ = QFileDialog.getOpenFileName(self, "Add music", "", f"Audio ({pat})")
        if path:
            self.add_music(path)

    def _music_ready(self, paths: list, then) -> bool:
        """Songs not read yet: read them in the background (a long song takes a
        moment - the window must not freeze), then call `then`. True = later."""
        from core import music
        from ui.workers import TaskWorker

        todo = [p for p in paths if music.is_audio(p) and music.needs_convert(self.project, p)]
        if not todo:
            return False
        self.statusBar().showMessage("🎵 Reading " + ", ".join(os.path.basename(p)
                                                              for p in todo) + " …")
        project = self.project

        def job(prog, stop):
            for p in todo:
                music.wav_for(project, p)
        wk = TaskWorker(job, "music", self)
        wk.done.connect(lambda _r: then() if self.project is project else None)
        wk.failed.connect(lambda e: QMessageBox.warning(
            self, "Add music", f"Could not read this sound:\n{e}"))
        self._music_workers = [w for w in getattr(self, "_music_workers", [])
                               if w.isRunning()] + [wk]
        wk.start()
        return True

    def add_music(self, path: str, at: Optional[float] = None):
        """Put a music / sound file on the Music track at the playhead."""
        from core import music

        if not self._require_video():
            return
        at = self.player.position() if at is None else at
        if self._music_ready([path], lambda: self.add_music(path, at)):
            return None
        self.push_undo()
        try:
            clip = music.add_music(self.project, path, at)
        except Exception as e:
            self.undo_stack.pop()
            QMessageBox.warning(self, "Add music", f"Could not add this sound:\n{e}")
            return
        self.after_edit(tables=False, subs=False)
        self.timeline.canvas.select("music", clip.id)
        try:
            from ui.library_panel import add_to_bin

            add_to_bin([path])
        except Exception:
            pass
        self.statusBar().showMessage(
            f"🎵 {os.path.basename(path)} added at {format_time(clip.start, False)} "
            f"({format_time(clip.length, False)}) – drag it on the Music track; "
            "right-click › Clip volume", 8000)

    def _library_extra_logo(self, path: str):
        self.push_undo()
        self.style_panel._add_extra_logo(path)
        self._load_edit_panels()

    def _on_tool_changed(self, kind: str):
        self.after_edit(audio=kind == "voice", tables=False, subs=False)
        if kind == "audio":
            self._maybe_make_music()

    def _maybe_make_music(self):
        """Background: music & effects only - make that track now, so the
        preview plays it (the export would make it anyway)."""
        p = self.project
        if getattr(p, "bg_mode", "original") != "music" or not p.has_video() \
                or not p.has_audio or (self.worker and self.worker.isRunning()):
            return
        from core.separate import has_music, make_music_track

        if has_music(p):
            return
        snap = copy.deepcopy(p)

        def done(_path):
            self.player.set_project(self.project)
            self.left.set_progress(100, "Music & effects ready")
            self.log("🎵 Music & effects track ready - the preview plays it now")

        self._start_task("Removing the original voices (music & effects only)",
                         lambda prog, stop: make_music_track(snap, prog, stop), done)

    def _close_tool(self, tool: str):
        if tool == "crop":
            self.player.set_crop_mode(False)
        self.left_stack.setCurrentWidget(self.left)
        self._apply_workspace()
        if getattr(self, "_left_sizes", None):
            self.h_split.setSizes(self._left_sizes)
            self._left_sizes = None
        self.style_panel.load(self.project)     # crop values are also in the Style tab
        self.after_edit(audio=False, tables=False, subs=False)

    def _preview_audio(self, track: str):
        """Listen to 8 s with the track's Equalizer / Noise Removal / Effects."""
        from core.effects import render_audio_preview

        p = copy.deepcopy(self.project)
        clip = None
        if track == "voice":
            kind, sel = self.timeline.canvas.selected_clip()
            clip = sel if kind == "audio" else None
            if clip is None and p.audio_clips:
                clip = min(p.audio_clips, key=lambda c: abs(c.start - self.player.position()))
            if clip is None:
                QMessageBox.information(self, "Listen", "There is no AI voice clip yet.")
                return
        src = p.timeline_to_source(self.player.position())[1] if p.video_clips else 0.0
        out = os.path.join(tempfile.gettempdir(), f"voxdub_listen_{int(time.time() * 1000)}.wav")
        self.player.pause()

        def job(progress, should_stop):
            progress(30, "Preparing the sound...")
            return render_audio_preview(p, track, out, src, clip)

        def done(path):
            self.sample_player.setSource(QUrl.fromLocalFile(path))
            self.sample_player.play()
            self.left.set_progress(100, "Playing 8 seconds with the audio effects")

        self._start_task("Listen", job, done)

    def _apply_voice_speed(self, ids: list, speed: float):
        clips = [c for c in self.project.audio_clips if c.id in set(ids)]
        if not clips:
            return
        work = [copy.copy(c) for c in clips]

        def job(progress, should_stop):
            for k, c in enumerate(work):
                if should_stop():
                    raise InterruptedError("Cancelled")
                set_clip_speed(c, speed)
                progress(int((k + 1) * 100 / len(work)), f"Speed {k + 1}/{len(work)}")
            return work

        def done(result):
            self.push_undo()
            by_id = {c.id: c for c in result}
            for c in self.project.audio_clips:
                n = by_id.get(c.id)
                if n is not None:
                    c.path, c.base_path, c.file_duration = n.path, n.base_path, n.file_duration
                    c.src_in, c.src_out, c.speed = n.src_in, n.src_out, n.speed
            self.after_edit(audio=True, tables=False, subs=False)
            self.tools.audio.load(self.project, next(
                (c for c in self.project.audio_clips if c.id == ids[0]), None))
            self.left.set_progress(100, f"✅ Speed {int(speed * 100)}% applied to "
                                        f"{len(result)} voice clip(s)")

        self._start_task("Voice speed", job, done)

    def _on_subtitle_selected(self, sub_id: str):
        self.timeline.canvas.select("subs", sub_id)
        for s in self.project.subtitle_clips:
            if s.id == sub_id:
                self.seek(s.start)
                break

    # ------------------------------------------------------------------ #
    # Text edits from the right panel
    # ------------------------------------------------------------------ #
    def _on_segment_text(self, seg_id: str, text: str):
        seg = self.project.segment_by_id(seg_id)
        if seg and seg.text != text:
            self.push_undo()
            seg.text = text
            seg.check = ""                  # corrected by hand = checked
            self._set_dirty(True)

    def _on_check_done(self, seg_ids: list):
        """Smart Review: ✓ OK on lines that are right."""
        segs = [s for s in (self.project.segment_by_id(i) for i in seg_ids) if s and s.check]
        for s in segs:
            s.check = ""
        if segs:
            self._set_dirty(True)

    def _on_line_setting(self, seg_ids: list, field: str, value: str):
        """Translation table: Voice / Delivery / Speed of one or more lines.
        Voice '@A' = the line is spoken by character A (with its voice),
        '@+' = by a new character."""
        if field == "voice" and value.startswith("@"):
            self._give_lines_to(seg_ids, value[1:])
            return
        segs = [s for s in (self.project.segment_by_id(i) for i in seg_ids)
                if s is not None and getattr(s, field) != value]
        if not segs:
            return
        self.push_undo()
        for s in segs:
            setattr(s, field, value or ("normal" if field != "voice" else ""))
            if field == "delivery":
                s.delivery_auto = False          # chosen by hand: kept from now on
        self.right.load_segments(self.project.segments)
        self.right.characters.load(self.project)
        self._set_dirty(True)
        what = {"voice": "Voice", "delivery": "Delivery", "pace": "Speed"}[field]
        self.statusBar().showMessage(
            f"{what} changed on {len(segs)} line(s) – ‘Re-voice selected’ to hear it", 6000)

    def _give_lines_to(self, seg_ids: list, target: str):
        from core import speakers
        from ui.characters_panel import move_lines

        p = self.project
        if target == "+":
            target = speakers.next_label(p)
        segs = [s for s in (p.segment_by_id(i) for i in seg_ids) if s is not None]
        if not segs or all(s.speaker == target and not s.voice for s in segs):
            return
        self.push_undo()
        for s in segs:
            s.voice = ""                     # the character's voice from now on
        move_lines(p, [s.id for s in segs], target)
        self._characters_changed()
        self.statusBar().showMessage(
            f"{len(segs)} line(s) now spoken by {speakers.display(p, target)} – "
            "‘Re-voice selected’ to hear it", 6000)

    def _on_translation_text(self, seg_id: str, text: str):
        seg = self.project.segment_by_id(seg_id)
        if not seg or seg.translation == text:
            return
        self.push_undo()
        old = seg.translation
        seg.translation = text
        changed = False
        for sub in self.project.subtitle_clips:
            if sub.seg_id == seg_id and (sub.text == old or not sub.text):
                sub.text = text
                changed = True
        if changed:
            self.after_edit(audio=False, tables=False)
        self.right.refresh_segment(seg)             # Audio status: ⟳ Changed
        self._set_dirty(True)
        self.statusBar().showMessage(
            "Translation changed – click ‘Re-voice selected’ to regenerate its voice", 5000)

    def _on_subtitle_edit(self, sub_id: str, field: str, value: str):
        sub = next((s for s in self.project.subtitle_clips if s.id == sub_id), None)
        if sub is None:
            return
        try:
            if field in ("start", "end"):
                t = max(0.0, parse_time(value))
                if field == "start" and t >= sub.end:
                    raise ValueError("start must be before end")
                if field == "end" and t <= sub.start:
                    raise ValueError("end must be after start")
        except ValueError as e:
            self.statusBar().showMessage(f"Invalid time: {e}", 4000)
            self.right.load_subtitles(self.project.subtitles_sorted())
            return
        self.push_undo()
        if field == "text":
            sub.text = value
        else:
            setattr(sub, field, round(t, 3))
        self.after_edit(audio=False, tables=False, subs=(field != "text"))

    def _add_subtitle(self):
        if not self._require_video():
            return
        self.push_undo()
        t = self.player.position()
        sub = SubtitleClip(new_id(), round(t, 3), round(t + 2.0, 3), "New subtitle")
        self.project.subtitle_clips.append(sub)
        self.after_edit(audio=False, tables=False)
        self.right.setCurrentIndex(2)
        self.right.select_subtitle(sub.id)

    def _delete_subtitles(self, ids: List[str]):
        if not ids:
            return
        self.push_undo()
        self.project.subtitle_clips = [s for s in self.project.subtitle_clips if s.id not in ids]
        self.after_edit(audio=False, tables=False)

    def _rebuild_subtitles(self, use_translation: bool):
        if not self.project.segments:
            QMessageBox.information(self, "Subtitles", "Transcribe the video first.")
            return
        self.push_undo()
        build_subtitles(self.project, use_translation)
        self.after_edit(audio=False, tables=False)

    # ------------------------------------------------------------------ #
    # Project files
    # ------------------------------------------------------------------ #
    def save_project(self) -> bool:
        if not self.project.has_video():
            QMessageBox.information(self, "Save", "Nothing to save yet – load a video first.")
            return False
        if not self.project_path:
            return self.save_project_as()
        self.left.apply_to_project(self.project)
        try:
            self.project.save(self.project_path, backup=0)   # the old file -> backups/
        except OSError as e:
            QMessageBox.critical(self, "Save failed", str(e))
            return False
        self._set_dirty(False)
        self.log(f"Project saved: {self.project_path}")
        self._record_recent()
        self._note_session(dirty=False)
        return True

    def save_project_as(self) -> bool:
        if not self.project.has_video():
            return False
        stem = os.path.splitext(os.path.basename(self.project.video_path))[0]
        start = self.project_path or os.path.join(self.project.work_dir or OUTPUT_DIR,
                                                  f"{stem}.voxdub.json")
        path, _ = QFileDialog.getSaveFileName(self, "Save project", start,
                                              "SARIKA VOXDUB PRO project (*.json)")
        if not path:
            return False
        if not path.lower().endswith(".json"):
            path += ".json"
        self.project_path = path
        return self.save_project()

    def open_project(self):
        if self._busy("Open project"):
            return
        if not self._maybe_save():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Open project", OUTPUT_DIR,
                                              "SARIKA VOXDUB PRO project (*.json)")
        if not path:
            return
        self._open_project_file(path)

    def open_backup(self):
        """An older copy of this project (core/backup.py): opened as unsaved
        work, so Save puts it back as the project."""
        from core import backup

        if self._busy("Open project") or not self._maybe_save():
            return
        base = self.project_path or self.project.autosave_path()
        start = backup.folder_for(base) if base else OUTPUT_DIR
        if not os.path.isdir(start):
            start = OUTPUT_DIR
        path, _ = QFileDialog.getOpenFileName(self, "Open a backup", start,
                                              "Project backup (*.json)")
        if not path:
            return
        keep_path = self.project_path if base and os.path.dirname(
            os.path.dirname(os.path.abspath(path))) == os.path.dirname(
            os.path.abspath(base)) else ""
        self._open_project_file(path, as_autosave=True)
        self.project_path = keep_path       # Save writes it back over the project
        self._set_dirty(True)
        self.log(f"🕘 Backup opened: {os.path.basename(path)} – Save to keep it")

    def _open_project_file(self, path: str, as_autosave: bool = False):
        try:
            project = Project.load(path)
        except Exception as e:
            QMessageBox.critical(self, "Open project", f"Could not open project:\n{e}")
            return
        self.project = project
        self.project_path = "" if as_autosave else path
        self.undo_stack.clear()
        self.redo_stack.clear()
        self.player.clear()
        self.player.load_video(project.video_path)
        self.dirty = False
        self._refresh_all()
        QTimer.singleShot(50, self.timeline.zoom_fit)
        self.log(f"Project opened: {path}")
        self._record_recent()
        for w in getattr(project, "load_warnings", []) or []:
            self.log("⚠ " + w)
            self.statusBar().showMessage("⚠ " + w, 10000)

    def _maybe_save(self) -> bool:
        """Ask to save unsaved work. Returns False if the user cancelled."""
        if not self.dirty or not self.project.has_video():
            return True
        ans = QMessageBox.question(
            self, "Unsaved changes", "Save the current project first?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard
            | QMessageBox.StandardButton.Cancel)
        if ans == QMessageBox.StandardButton.Cancel:
            return False
        if ans == QMessageBox.StandardButton.Save:
            return self.save_project()
        return True

    # ------------------------------------------------------------------ #
    # Export
    # ------------------------------------------------------------------ #
    def export_video(self):
        if not self._require_video():
            return
        self.player.pause()
        if not self.project.audio_clips:
            ans = QMessageBox.question(
                self, "Export", "There is no AI voice on the timeline yet.\nExport anyway?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        old = [s for s in self.project.stale_voices() if s.tts_path]
        if old:
            # the voice settings changed (a voice, a character, the 1 Male + 1
            # Female box ...) but the lines were not voiced again: Export would
            # use the old voices
            box = QMessageBox(self)
            box.setWindowTitle("Export")
            box.setIcon(QMessageBox.Icon.Question)
            box.setText(f"{len(old)} lines still have their old voice (their text or the "
                        "voice settings changed after the voice was made).")
            b_voice = box.addButton("Make the new voices first",
                                    QMessageBox.ButtonRole.AcceptRole)
            box.addButton("Export with the old voices", QMessageBox.ButtonRole.DestructiveRole)
            b_cancel = box.addButton(QMessageBox.StandardButton.Cancel)
            box.exec()
            if box.clickedButton() is b_cancel:
                return
            if box.clickedButton() is b_voice:
                self.run_voice()
                return
        dlg = ExportDialog(self)
        dlg.exec()
        self.after_edit(audio=False, tables=False, subs=False)   # preview: new subtitle size

    def _licensed_only(self, what: str) -> bool:
        """Trial: separate voice / subtitle files need a license key."""
        if not lic.restricted():
            return True
        QMessageBox.information(
            self, "SARIKA VOXDUB PRO",
            f"{what} needs a license key.\n\nThe trial exports the dubbed video with a "
            "watermark. Help › License shows your Machine ID - send it to us to get a key.")
        return False

    def show_green_screen(self):
        """Style › 🟩 Green screen: intro / outro / Like & Subscribe / moving logo."""
        from core import plans
        from ui.greenscreen_dialog import GreenScreenDialog

        if not self._require_video():
            return
        if not plans.allows("green_screen"):
            QMessageBox.information(self, "Plan", "Green screen clips are in the "
                                    f"{plans.needed('green_screen')} plan.")
            return
        dlg = GreenScreenDialog(self.project, self)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        new = dlg.result_items()
        if new == list(self.project.green_overlays or []):
            return
        self.push_undo()
        self.project.green_overlays = new
        self.style_panel.load(self.project)
        self.after_edit(audio=False, tables=False, subs=False)
        self.log(f"🟩 Green screen: {sum(1 for d in new if d.get('on', True))} clip(s) – "
                 "they play over the video when you Export")

    def set_ratio(self, key: str):
        """Timeline bar › Ratio: Original / 9:16 / 16:9 ... at once (one undo step).
        The framing (blur / black bars / crop) stays as in Project settings."""
        from core import branding

        if not self._require_video():
            return
        p = self.project
        w, h = branding.ratio_size(key)
        if (p.out_ratio, p.out_width, p.out_height) == (key, w, h):
            return
        self.push_undo()
        p.out_ratio, p.out_width, p.out_height = key, w, h
        self.after_edit(audio=False, tables=False, subs=False)
        self.statusBar().showMessage(f"Video ratio: {branding.RATIO_LABELS.get(key, key)}", 4000)

    def quick_tool(self, key: str):
        """Timeline bar: flip, logo, blur the original subtitles (one undo step)."""
        if not self._require_video():
            return
        if key in ("flip_h", "flip_v"):
            self._library_apply("style", lambda p: setattr(p, key, not getattr(p, key, False)))
            return
        if key == "logo":
            path, _ = QFileDialog.getOpenFileName(
                self, "Logo", "", "Pictures (*.png *.jpg *.jpeg *.webp *.bmp)")
            if path:
                self._library_apply("style", lambda p: setattr(p, "logo_path", path))
                self.right.setCurrentWidget(self.style_panel)
            return
        if key == "blur":
            self.right.setCurrentWidget(self.style_panel)
            self.detect_original_subtitles()

    def isolate_bgm(self):
        """Take the original voices out of the video's sound: the music and
        ambience stay under the AI voice (Export › Remove the original dialogue)."""
        from core import plans

        if not self._require_video():
            return
        p = self.project
        if not p.has_audio:
            QMessageBox.information(self, "Isolate BGM", "This video has no sound.")
            return
        if not plans.allows("music_only"):
            QMessageBox.information(self, "Plan", "Removing the original dialogue is in the "
                                    f"{plans.needed('music_only')} plan.")
            return
        self.push_undo()
        p.bg_mode = "music"
        if p.original_volume < 0.2:
            p.original_volume = 0.8             # the music alone can be louder
        self._set_dirty(True)
        from core.separate import has_music

        if has_music(p):
            self.player.set_project(p)
            self.log("🎵 Music & effects are used under the AI voice")
        else:
            self._maybe_make_music()

    def import_srt(self):
        """Lines from a subtitle file (Khmer = ready for the AI voice)."""
        from core import srt_import

        if not self._require_video():
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import SRT", "", "SubRip (*.srt)")
        if not path:
            return
        if self.project.segments:
            ans = QMessageBox.question(
                self, "Import SRT", f"Replace the {len(self.project.segments)} lines of this "
                "project with the lines of the file?")
            if ans != QMessageBox.StandardButton.Yes:
                return
        self.push_undo()
        try:
            n = srt_import.import_into(self.project, path)
        except Exception as e:
            QMessageBox.warning(self, "Import SRT", f"Could not read this file:\n{e}")
            return
        self._refresh_all()
        self.after_edit()
        km = self.project.segments and self.project.segments[0].translation
        self.log(f"📄 {n} lines imported from {os.path.basename(path)}"
                 + (" – Khmer: ready for 3 · Voice" if km else " – next: 2 · Translate"))

    def export_srt(self):
        if not self._licensed_only("Saving the subtitles (.srt)"):
            return
        if not any(not c.hidden for c in self.project.subtitle_clips):
            QMessageBox.information(self, "Export SRT", "There are no subtitles yet.")
            return
        stem = os.path.splitext(os.path.basename(self.project.video_path))[0]
        start = os.path.join(OUTPUT_DIR, f"{stem}_{self.project.target_lang}.srt")
        path, _ = QFileDialog.getSaveFileName(self, "Save subtitles", start, "SubRip (*.srt)")
        if path:
            write_srt([c for c in self.project.subtitles_sorted() if not c.hidden], path,
                      limit=self.project.sequence_duration(), speed=self.project.speed())
            self.log(f"Subtitles saved: {path}")

    def export_dub_wav(self):
        if not self._licensed_only("Saving the AI voice (.wav)"):
            return
        if not self.project.audio_clips:
            QMessageBox.information(self, "Export WAV", "There is no AI voice yet.")
            return
        stem = os.path.splitext(os.path.basename(self.project.video_path))[0]
        start = os.path.join(OUTPUT_DIR, f"{stem}_voice_{self.project.target_lang}.wav")
        path, _ = QFileDialog.getSaveFileName(self, "Save AI voice", start, "WAV audio (*.wav)")
        if path:
            snap = copy.deepcopy(self.project)

            def job(prog, stop):
                speed = snap.speed()
                if abs(speed - 1.0) < 0.001:
                    return render_dub_mix(snap, path, should_stop=stop)
                # Video > Speed: the voice track as fast as the exported video
                raw = os.path.splitext(path)[0] + ".tmp.wav"
                try:
                    render_dub_mix(snap, raw, should_stop=stop)
                    change_speed(raw, path, speed)
                finally:
                    if os.path.isfile(raw):
                        os.remove(raw)
                return path

            self._start_task("Export AI voice", job,
                             lambda p: self.log(f"AI voice saved: {p}"))

    # ------------------------------------------------------------------ #
    def closeEvent(self, event):
        if not self._maybe_save():
            event.ignore()
            return
        if self.batch and self.batch.is_running():
            ans = QMessageBox.question(self, "Batch queue",
                                       "The batch queue is still running.\nStop it and exit?")
            if ans != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        w = self.worker
        if w and w.isRunning():
            ans = QMessageBox.question(self, "SARIKA VOXDUB PRO",
                                       "A task is still running.\nStop it and exit? "
                                       "(finished work is kept)")
            if ans != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        if self.batch:
            self.batch.shutdown()
        self._save_layout()
        self.timeline.stop_workers()
        self.player.stop_workers()
        if w and w.isRunning():
            w.stop()
            wait_for_threads([w], self, "Stopping the task...")
        self.player.clear()
        # samples / previews written to %TEMP% during the session
        for pattern in ("voxdub_sample_*", "voxdub_char_*", "voxdub_frame_*",
                        "voxdub_listen_*", "voxdub_voxcpm_test*", "voxdub_azure_test*"):
            for f in glob.glob(os.path.join(tempfile.gettempdir(), pattern)):
                try:
                    os.remove(f)
                except OSError:
                    pass
        if "ui.sarika_voice" in sys.modules:      # stop the SARIKA VOICE server if we started it
            sys.modules["ui.sarika_voice"].stop_server()
        from core import session

        session.end()                       # closed properly: nothing to recover
        event.accept()
