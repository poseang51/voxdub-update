"""
support_dialogs.py - Help › System check, Send problem report, Video tutorials (2.6.3).
"""

import os
import subprocess
import sys

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices, QGuiApplication
from PySide6.QtWidgets import (
    QDialog, QHBoxLayout, QInputDialog, QLabel, QMessageBox, QPushButton, QVBoxLayout,
    QWidget,
)

from core import pricing, settings, syscheck
from core.i18n import tr

MARK = {"ok": ("✓", "#22c55e"), "warn": ("⚠", "#f59e0b"), "bad": ("✗", "#ef4444"),
        "off": ("–", "#8b93a3")}
FIX_TEXT = {"gemini": "Add key…", "voxcpm": "Set up…", "cuda": "How?"}


class SystemCheckDialog(QDialog):
    def __init__(self, win, items=None):
        super().__init__(win)
        self.win = win
        self.setWindowTitle(tr("✅ System check"))
        self.resize(720, 420)
        v = QVBoxLayout(self)
        head = QLabel(tr("Is this PC ready to dub? ✓ ready · ⚠ works, but slower or without "
                         "a feature · ✗ must be fixed · – optional"))
        head.setWordWrap(True)
        v.addWidget(head)
        self.box = QVBoxLayout()
        v.addLayout(self.box)
        v.addStretch(1)
        row = QHBoxLayout()
        again = QPushButton(tr("⟳ Check again"))
        again.clicked.connect(lambda: self.fill(syscheck.run()))
        rep = QPushButton(tr("📨 Send problem report…"))
        rep.clicked.connect(lambda: send_problem_report(self.win))
        close = QPushButton(tr("Close"))
        close.clicked.connect(self.accept)
        row.addWidget(again)
        row.addWidget(rep)
        row.addStretch(1)
        row.addWidget(close)
        v.addLayout(row)
        self.rows = []
        self.fill(items if items is not None else syscheck.run())

    def fill(self, items):
        for w in self.rows:
            w.setParent(None)
        self.rows = []
        for it in items:
            w = QWidget()
            h = QHBoxLayout(w)
            h.setContentsMargins(0, 2, 0, 2)
            sign, colour = MARK.get(it.state, ("?", "#ffffff"))
            m = QLabel(sign)
            m.setStyleSheet(f"color:{colour}; font-size:14pt; font-weight:800;")
            m.setFixedWidth(26)
            name = QLabel(f"<b>{tr(it.name)}</b><br><span style='color:#8b93a3'>"
                          f"{tr(it.detail)}</span>")
            name.setWordWrap(True)
            h.addWidget(m)
            h.addWidget(name, 1)
            if it.fix:
                b = QPushButton(tr(FIX_TEXT.get(it.fix, "Fix…")))
                b.clicked.connect(lambda _=False, f=it.fix: self._fix(f))
                h.addWidget(b)
            self.box.addWidget(w)
            self.rows.append(w)

    def _fix(self, what: str):
        if what in ("gemini", "voxcpm") and hasattr(self.win, "show_engines"):
            self.win.show_engines(what)
            self.fill(syscheck.run())
        elif what == "cuda":
            QMessageBox.information(self, tr("NVIDIA GPU"), tr(
                "Run install_gpu.bat in the SARIKA VOXDUB PRO folder once (internet needed), "
                "then start the app again. Whisper then runs on the GPU."))


def maybe_first_check(win):
    """At the first start of this version: show the check if something is wrong."""
    from core import __version__

    if settings.get("syscheck_seen", "") == __version__:
        return
    settings.set("syscheck_seen", __version__)
    try:
        items = syscheck.run()
    except Exception as e:
        print(f"[syscheck] {e}")
        return
    if any(i.state == "bad" for i in items):
        SystemCheckDialog(win, items).show()


def _reveal(path: str):
    try:
        if sys.platform == "win32":
            subprocess.Popen(["explorer", "/select,", os.path.normpath(path)])
        else:
            QDesktopServices.openUrl(QUrl.fromLocalFile(os.path.dirname(path)))
    except Exception:
        pass


def send_problem_report(win):
    from core import support

    note, ok = QInputDialog.getMultiLineText(
        win, tr("📨 Send problem report"),
        tr("What happened? (optional – e.g. \"the app closed when I clicked Start Batch\")"))
    if not ok:
        return
    try:
        path = support.make_report(note=note.strip())
    except Exception as e:
        QMessageBox.warning(win, tr("📨 Send problem report"), f"{e}")
        return
    QGuiApplication.clipboard().setText(path)
    data = pricing.load()
    url = pricing.link_url(data.get("contact", "")) or \
        pricing.link_url(data.get("telegram_channel", ""))
    box = QMessageBox(win)
    box.setWindowTitle(tr("📨 Send problem report"))
    box.setText(tr("The report is on your Desktop:") + f"\n{os.path.basename(path)}\n\n"
                + tr("Send this file to the admin (Telegram). It has no API key, password "
                     "or licence in it."))
    b_open = box.addButton(tr("Show the file"), QMessageBox.ButtonRole.ActionRole)
    b_tg = box.addButton(tr("Open Telegram"), QMessageBox.ButtonRole.ActionRole) if url else None
    box.addButton(QMessageBox.StandardButton.Close)
    box.exec()
    if box.clickedButton() is b_open:
        _reveal(path)
    elif b_tg is not None and box.clickedButton() is b_tg:
        _reveal(path)
        QDesktopServices.openUrl(QUrl(url))


def open_tutorials(win):
    url = pricing.link_url(pricing.load().get("tutorials", ""))
    if url:
        QDesktopServices.openUrl(QUrl(url))
        return
    QMessageBox.information(win, tr("🎓 Video tutorials"),
                            tr("The video tutorials are coming soon – see the Facebook page "
                               "and Telegram channel in Help › About."))
