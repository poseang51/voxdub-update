"""
style_panel.py - "Style" tab: cover the original subtitles, logo and brand text.
(Crop / zoom live in Tools > Crop and Rotate, the video ratio in Project settings.)
Every change is written straight into the project and
announced with `changed` so the preview updates.
"""

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QFontDatabase
from PySide6.QtWidgets import (
    QCheckBox, QColorDialog, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout,
    QFrame, QGroupBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea,
    QSpinBox, QVBoxLayout, QWidget,
)

from core.branding import CORNERS, MOTION_LABELS, SUB_PRESETS
from core.project import Project

CORNER_LABELS = {
    "top-left": "Top left", "top-center": "Top centre", "top-right": "Top right",
    "center": "Middle of the video",
    "bottom-left": "Bottom left", "bottom-center": "Bottom centre", "bottom-right": "Bottom right",
    "custom": "Custom (drag in the preview)",
}


def _motion_combo() -> QComboBox:
    c = QComboBox()
    for key, label in MOTION_LABELS.items():
        c.addItem(label, key)
    c.setToolTip("Moving: it drifts across the video by itself and bounces off the "
                 "edges, like a watermark that is hard to crop out")
    return c


def _pct_spin(lo=0, hi=100, step=1) -> QDoubleSpinBox:
    s = QDoubleSpinBox()
    s.setRange(lo, hi)
    s.setSingleStep(step)
    s.setDecimals(1)
    s.setSuffix(" %")
    return s


class StylePanel(QScrollArea):
    changed = Signal()
    subsShownToggled = Signal(bool)         # "Show subtitles" (preview + export)
    greenScreenRequested = Signal()         # 🟩 Green screen… (intro / outro / subscribe)
    detectRequested = Signal()
    previewFrameRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.project: Project = Project()
        self._loading = False

        inner = QWidget()
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(6, 6, 6, 6)
        lay.setSpacing(8)

        # --- original (burned-in) subtitles
        g1 = QGroupBox("🈶  Original subtitles")
        f1 = QFormLayout(g1)
        self.chk_cover = QCheckBox("Hide the original subtitles")
        self.btn_detect = QPushButton("🔍 Auto detect")
        self.btn_detect.setToolTip("Scan the video and find where the original "
                                   "(e.g. Chinese) subtitles are burned in")
        self.btn_detect.clicked.connect(self.detectRequested.emit)
        self.cmb_cover_mode = QComboBox()
        self.cmb_cover_mode.addItem("Blur", "blur")
        self.cmb_cover_mode.addItem("Black box", "box")
        self.sp_top, self.sp_height = _pct_spin(step=0.5), _pct_spin(step=0.5)
        self.sp_left, self.sp_width = _pct_spin(step=0.5), _pct_spin(step=0.5)
        area = QHBoxLayout()
        for lbl, w in (("Top", self.sp_top), ("Height", self.sp_height)):
            area.addWidget(QLabel(lbl))
            area.addWidget(w, 1)
        area2 = QHBoxLayout()
        for lbl, w in (("Left", self.sp_left), ("Width", self.sp_width)):
            area2.addWidget(QLabel(lbl))
            area2.addWidget(w, 1)
        self.cmb_sub_pos = QComboBox()
        self.cmb_sub_pos.addItem("Bottom of the video", "bottom")
        self.cmb_sub_pos.addItem("Over the original subtitles", "cover")
        f1.addRow(self.chk_cover)
        f1.addRow(self.btn_detect)
        f1.addRow("Hide with", self.cmb_cover_mode)
        f1.addRow(area)
        f1.addRow(area2)
        f1.addRow("Our subtitles", self.cmb_sub_pos)
        lay.addWidget(g1)

        # --- our subtitles: how they look
        gs = QGroupBox("💬  Subtitles (look)")
        fs = QFormLayout(gs)
        self.chk_subs_show = QCheckBox("👁 Show subtitles (preview + export)")
        self.chk_subs_show.setToolTip(
            "Untick to make the video WITHOUT our subtitles (the lines are kept – tick "
            "again to bring them back). One line only: Subtitles tab › 🙈 Hide selected.")
        self.chk_subs_show.toggled.connect(self._subs_show_changed)
        fs.addRow(self.chk_subs_show)
        self.cmb_sub_preset = QComboBox()
        for key, (label, _v) in SUB_PRESETS.items():
            self.cmb_sub_preset.addItem(label, key)
        self.cmb_sub_preset.addItem("Custom", "custom")
        self.cmb_sub_font = QComboBox()
        self.cmb_sub_font.addItem("Auto (Noto Sans Khmer / Arial)", "")
        fams = ["Noto Sans Khmer"]
        try:
            fams += QFontDatabase.families(QFontDatabase.WritingSystem.Khmer)
        except Exception:
            pass
        fams += ["Arial", "Segoe UI", "Tahoma", "Microsoft YaHei"]
        for f in dict.fromkeys(fams):
            self.cmb_sub_font.addItem(f, f)
        self.cmb_sub_font.setToolTip("Fonts that can write Khmer are listed first. Your own "
                                     ".ttf files can be put in assets\\fonts.")
        self.sp_sub_size = QSpinBox()
        self.sp_sub_size.setRange(40, 300)
        self.sp_sub_size.setSingleStep(5)
        self.sp_sub_size.setSuffix(" %")
        self.chk_sub_bold = QCheckBox("Bold")
        self._subc = {}
        self.btn_sub_color = self._color_button("sub_color", "Text colour")
        self.sp_sub_outline = QDoubleSpinBox()
        self.sp_sub_outline.setRange(0, 8)
        self.sp_sub_outline.setSingleStep(0.5)
        self.sp_sub_outline.setDecimals(1)
        self.sp_sub_outline.setToolTip("Thickness of the line around the letters (0 = none)")
        self.btn_sub_ocolor = self._color_button("sub_outline_color", "Outline colour")
        self.sp_sub_shadow = QDoubleSpinBox()
        self.sp_sub_shadow.setRange(0, 6)
        self.sp_sub_shadow.setSingleStep(0.5)
        self.sp_sub_shadow.setDecimals(1)
        self.chk_sub_box = QCheckBox("Box behind the text")
        self.btn_sub_bcolor = self._color_button("sub_box_color", "Box colour")
        self.sp_sub_bop = QSpinBox()
        self.sp_sub_bop.setRange(0, 100)
        self.sp_sub_bop.setSuffix(" %")
        self.sp_sub_bop.setToolTip("How solid the box is (0 = invisible)")
        self.sp_sub_bottom = QDoubleSpinBox()
        self.sp_sub_bottom.setRange(0, 95)
        self.sp_sub_bottom.setDecimals(1)
        self.sp_sub_bottom.setSingleStep(0.5)
        self.sp_sub_bottom.setSuffix(" %")
        self.sp_sub_bottom.setToolTip("Space between the subtitle and the bottom of the video\n"
                                      "(or click the subtitle in the preview and drag it)")
        self.sp_sub_x = QDoubleSpinBox()
        self.sp_sub_x.setRange(3, 97)
        self.sp_sub_x.setDecimals(1)
        self.sp_sub_x.setSingleStep(1)
        self.sp_sub_x.setSuffix(" %")
        self.sp_sub_x.setToolTip("Left ↔ right: where the middle of the text is (50 % = centre)")
        self.btn_sub_center = QPushButton("⟲")
        self.btn_sub_center.setFixedWidth(34)
        self.btn_sub_center.setToolTip("Back to the middle, 9.7 % from the bottom")
        self.btn_sub_center.clicked.connect(self._sub_center)

        def pair(*ws):
            h = QHBoxLayout()
            for w in ws:
                h.addWidget(w, 1 if not isinstance(w, QPushButton) else 0)
            return h
        fs.addRow("Look", self.cmb_sub_preset)
        fs.addRow("Font", self.cmb_sub_font)
        fs.addRow("Size", pair(self.sp_sub_size, self.chk_sub_bold))
        fs.addRow("Colour", self.btn_sub_color)
        fs.addRow("Outline", pair(self.sp_sub_outline, self.btn_sub_ocolor))
        fs.addRow("Shadow", self.sp_sub_shadow)
        fs.addRow(self.chk_sub_box)
        fs.addRow("Box", pair(self.btn_sub_bcolor, self.sp_sub_bop))
        fs.addRow("From bottom", self.sp_sub_bottom)
        fs.addRow("Left ↔ right", pair(self.sp_sub_x, self.btn_sub_center))
        tip = QLabel("💡 Click the subtitle on the video: drag it to move, drag a corner "
                     "to resize. Same for the logo.")
        tip.setWordWrap(True)
        tip.setObjectName("MutedLabel")
        fs.addRow(tip)
        lay.addWidget(gs)
        self.cmb_sub_preset.currentIndexChanged.connect(self._sub_preset)
        self.cmb_sub_font.currentIndexChanged.connect(self._apply_subs)
        for w in (self.sp_sub_size, self.sp_sub_outline, self.sp_sub_shadow, self.sp_sub_bop,
                  self.sp_sub_bottom, self.sp_sub_x):
            w.valueChanged.connect(self._apply_subs)
        for w in (self.chk_sub_bold, self.chk_sub_box):
            w.toggled.connect(self._apply_subs)

        # --- logo
        g3 = QGroupBox("🖼  Logo")
        f3 = QFormLayout(g3)
        self.ed_logo = QLineEdit()
        self.ed_logo.setPlaceholderText("PNG with transparent background")
        self.ed_logo.setReadOnly(True)
        b_logo = QPushButton("…")
        b_logo.setFixedWidth(34)
        b_logo.clicked.connect(self._choose_logo)
        b_logo_x = QPushButton("✕")
        b_logo_x.setFixedWidth(30)
        b_logo_x.setToolTip("Remove logo")
        b_logo_x.clicked.connect(lambda: self.ed_logo.setText(""))
        row = QHBoxLayout()
        row.addWidget(self.ed_logo, 1)
        row.addWidget(b_logo)
        row.addWidget(b_logo_x)
        self.cmb_logo_pos = QComboBox()
        for c in CORNERS:
            self.cmb_logo_pos.addItem(CORNER_LABELS[c], c)
        self.sp_logo_size = QSpinBox()
        self.sp_logo_size.setRange(3, 60)
        self.sp_logo_size.setSuffix(" % width")
        self.sp_logo_op = QSpinBox()
        self.sp_logo_op.setRange(10, 100)
        self.sp_logo_op.setSuffix(" %")
        f3.addRow("Image", row)
        self.cmb_logo_motion = _motion_combo()
        f3.addRow("Position", self.cmb_logo_pos)
        f3.addRow("Movement", self.cmb_logo_motion)
        f3.addRow("Size", self.sp_logo_size)
        f3.addRow("Opacity", self.sp_logo_op)
        lay.addWidget(g3)

        # --- more logos (a customer's advert next to ours)
        g3b = QGroupBox("🖼  More logos (sponsor / customer)")
        v3b = QVBoxLayout(g3b)
        self.extra_box = QVBoxLayout()
        self.extra_box.setSpacing(8)
        v3b.addLayout(self.extra_box)
        self.btn_add_logo = QPushButton("＋ Add a logo…")
        self.btn_add_logo.setToolTip("Put another logo on the video, e.g. a customer's logo "
                                     "in the middle while ours stays in the corner")
        self.btn_add_logo.clicked.connect(self._add_extra_logo)
        v3b.addWidget(self.btn_add_logo)
        lay.addWidget(g3b)

        # --- green screen clips (intro / outro / Like & Subscribe / moving logo)
        g3c = QGroupBox("🟩  Green screen (intro / outro / Like & Subscribe)")
        v3c = QVBoxLayout(g3c)
        self.lb_green = QLabel("")
        self.lb_green.setWordWrap(True)
        self.lb_green.setObjectName("MutedLabel")
        v3c.addWidget(self.lb_green)
        self.btn_green = QPushButton("🟩  Green screen clips…")
        self.btn_green.setToolTip("A video with a green / blue background (intro, outro, Like & "
                                  "Subscribe, moving logo): the colour is cut out and it plays "
                                  "over your video when you Export")
        self.btn_green.clicked.connect(self.greenScreenRequested.emit)
        v3c.addWidget(self.btn_green)
        lay.addWidget(g3c)

        # --- brand text
        g4 = QGroupBox("🔤  Brand text")
        f4 = QFormLayout(g4)
        self.ed_text = QLineEdit()
        self.ed_text.setPlaceholderText("e.g. VoxDub Khmer · @mypage")
        self.cmb_text_pos = QComboBox()
        for c in CORNERS:
            self.cmb_text_pos.addItem(CORNER_LABELS[c], c)
        self.sp_text_size = QSpinBox()
        self.sp_text_size.setRange(30, 300)
        self.sp_text_size.setSingleStep(10)
        self.sp_text_size.setSuffix(" %")
        self.btn_color = QPushButton()
        self.btn_color.clicked.connect(self._choose_color)
        f4.addRow("Text", self.ed_text)
        self.cmb_text_motion = _motion_combo()
        f4.addRow("Position", self.cmb_text_pos)
        f4.addRow("Movement", self.cmb_text_motion)
        f4.addRow("Size", self.sp_text_size)
        f4.addRow("Colour", self.btn_color)
        lay.addWidget(g4)

        self.btn_preview = QPushButton("🖼  Preview frame (as exported)")
        self.btn_preview.setObjectName("AccentButton")
        self.btn_preview.clicked.connect(self.previewFrameRequested.emit)
        lay.addWidget(self.btn_preview)
        hint = QLabel("The video preview shows the layout live – drag the logo or the brand "
                      "text there to put it anywhere. ‘Preview frame’ renders the real "
                      "exported picture at the playhead.")
        hint.setObjectName("MutedLabel")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        lay.addStretch(1)
        self.setWidget(inner)

        for w in (self.chk_cover,):
            w.toggled.connect(self._apply)
        for w in (self.cmb_cover_mode, self.cmb_sub_pos,
                  self.cmb_logo_pos, self.cmb_text_pos, self.cmb_logo_motion,
                  self.cmb_text_motion):
            w.currentIndexChanged.connect(self._apply)
        for w in (self.sp_top, self.sp_height, self.sp_left, self.sp_width,
                  self.sp_logo_size, self.sp_logo_op, self.sp_text_size):
            w.valueChanged.connect(self._apply)
        self.ed_logo.textChanged.connect(self._apply)
        self.ed_text.textChanged.connect(self._apply)
        self._color = "#FFFFFF"
        self._update_color_button()
        self._load_subs(self.project)

    # ------------------------------------------------------------------ #
    def load(self, project: Project):
        self.project = project
        self._loading = True
        p = project
        self._green_summary(p)
        self.chk_cover.setChecked(p.cover_enabled)
        self._set(self.cmb_cover_mode, p.cover_mode)
        self.set_cover_rect(p.cover_rect)
        self._set(self.cmb_sub_pos, p.sub_position)
        self.ed_logo.setText(p.logo_path)
        self._set(self.cmb_logo_pos, p.logo_corner)
        self._set(self.cmb_logo_motion, p.logo_motion)
        self.sp_logo_size.setValue(int(round(p.logo_size * 100)))
        self.sp_logo_op.setValue(int(round(p.logo_opacity * 100)))
        self.ed_text.setText(p.brand_text)
        self._set(self.cmb_text_pos, p.brand_corner)
        self._set(self.cmb_text_motion, p.brand_motion)
        self.sp_text_size.setValue(int(round(p.brand_size * 100)))
        self._color = p.brand_color or "#FFFFFF"
        self._update_color_button()
        self._load_subs(p)
        self._load_extras(p)
        self._loading = False
        self._update_enabled()

    def set_cover_rect(self, rect):
        was = self._loading
        self._loading = True
        x, y, w, h = rect
        self.sp_left.setValue(x * 100)
        self.sp_top.setValue(y * 100)
        self.sp_width.setValue(w * 100)
        self.sp_height.setValue(h * 100)
        self._loading = was

    @staticmethod
    def _set(combo: QComboBox, data):
        i = combo.findData(data)
        if i >= 0:
            combo.setCurrentIndex(i)

    def _update_enabled(self):
        on = self.chk_cover.isChecked()
        for w in (self.cmb_cover_mode, self.sp_top, self.sp_height, self.sp_left,
                  self.sp_width):
            w.setEnabled(on)

    def _apply(self, *_):
        self._update_enabled()
        if self._loading:
            return
        from core import plans
        if self.chk_cover.isChecked() and not self.project.cover_enabled \
                and not plans.allows("hide_subs"):
            from PySide6.QtWidgets import QMessageBox

            self._loading = True
            self.chk_cover.setChecked(False)
            self._loading = False
            self._update_enabled()
            QMessageBox.information(self, "Plan", "Hiding the original subtitles is in the "
                                    f"{plans.needed('hide_subs')} plan.")
            return
        p = self.project
        p.cover_enabled = self.chk_cover.isChecked()
        p.cover_mode = self.cmb_cover_mode.currentData()
        x, y = self.sp_left.value() / 100, self.sp_top.value() / 100
        w = min(self.sp_width.value() / 100, 1 - x)
        h = min(self.sp_height.value() / 100, 1 - y)
        p.cover_rect = [round(x, 4), round(y, 4), round(max(0.01, w), 4), round(max(0.01, h), 4)]
        p.sub_position = self.cmb_sub_pos.currentData()
        p.logo_path = self.ed_logo.text().strip()
        p.logo_corner = self.cmb_logo_pos.currentData()
        p.logo_motion = self.cmb_logo_motion.currentData()
        p.logo_size = self.sp_logo_size.value() / 100
        p.logo_opacity = self.sp_logo_op.value() / 100
        p.brand_text = self.ed_text.text()
        p.brand_corner = self.cmb_text_pos.currentData()
        p.brand_motion = self.cmb_text_motion.currentData()
        p.brand_size = self.sp_text_size.value() / 100
        p.brand_color = self._color
        self.changed.emit()

    def _green_summary(self, p: Project):
        from core import greenscreen as gs

        rows = [d for d in (getattr(p, "green_overlays", None) or []) if isinstance(d, dict)]
        if not rows:
            self.lb_green.setText("None yet.")
            return
        names = [f"{gs.KINDS.get(d.get('kind'), '')} · {os.path.basename(d.get('path', ''))}"
                 + ("" if d.get("on", True) else " (off)") for d in rows]
        self.lb_green.setText("\n".join(names))

    # ------------------------------------------------------------------ #
    # more logos
    # ------------------------------------------------------------------ #
    def _load_extras(self, p: Project):
        while self.extra_box.count():
            it = self.extra_box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        for i, d in enumerate(getattr(p, "extra_logos", None) or []):
            self.extra_box.addWidget(self._extra_row(i, d))

    def _extra_row(self, i: int, d: dict) -> QFrame:
        from core.branding import EXTRA_LOGO

        d = {**EXTRA_LOGO, **d}
        box = QFrame()
        box.setObjectName("DashPanel")
        f = QFormLayout(box)
        f.setContentsMargins(8, 6, 8, 6)
        name = QLabel(os.path.basename(d["path"]) or "(no picture)")
        name.setToolTip(d["path"])
        if d["path"] and not os.path.isfile(d["path"]):
            name.setText("⚠ " + name.text() + " (file not found)")
        b_pick = QPushButton("…")
        b_pick.setFixedWidth(34)
        b_pick.clicked.connect(lambda *_: self._pick_extra(i))
        b_del = QPushButton("✕")
        b_del.setFixedWidth(30)
        b_del.setToolTip("Remove this logo")
        b_del.clicked.connect(lambda *_: self._remove_extra(i))
        row = QHBoxLayout()
        row.addWidget(name, 1)
        row.addWidget(b_pick)
        row.addWidget(b_del)
        f.addRow(f"Logo {i + 2}", row)
        pos = QComboBox()
        for c in CORNERS:
            pos.addItem(CORNER_LABELS[c], c)
        pos.setCurrentIndex(max(0, pos.findData(d["corner"])))
        motion = _motion_combo()
        motion.setCurrentIndex(max(0, motion.findData(d["motion"])))
        size = QSpinBox()
        size.setRange(3, 80)
        size.setSuffix(" % width")
        size.setValue(int(round(float(d["size"]) * 100)))
        op = QSpinBox()
        op.setRange(10, 100)
        op.setSuffix(" %")
        op.setValue(int(round(float(d["opacity"]) * 100)))
        f.addRow("Position", pos)
        f.addRow("Movement", motion)
        two = QHBoxLayout()
        two.addWidget(size, 1)
        two.addWidget(QLabel("Opacity"))
        two.addWidget(op, 1)
        f.addRow("Size", two)
        pos.currentIndexChanged.connect(lambda *_: self._set_extra(i, corner=pos.currentData()))
        motion.currentIndexChanged.connect(
            lambda *_: self._set_extra(i, motion=motion.currentData()))
        size.valueChanged.connect(lambda v: self._set_extra(i, size=v / 100))
        op.valueChanged.connect(lambda v: self._set_extra(i, opacity=v / 100))
        return box

    def _set_extra(self, i: int, **kw):
        if self._loading:
            return
        logos = self.project.extra_logos
        if 0 <= i < len(logos):
            logos[i] = {**logos[i], **kw}
            self.changed.emit()

    def _ask_logo(self, start: str = "") -> str:
        path, _ = QFileDialog.getOpenFileName(self, "Choose logo", start,
                                              "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        return path

    def _add_extra_logo(self, path: str = ""):
        from core import plans
        from core.branding import new_extra_logo

        if not plans.allows("extra_logos"):
            from PySide6.QtWidgets import QMessageBox

            QMessageBox.information(self, "Plan", "More than one logo is in the "
                                    f"{plans.needed('extra_logos')} plan.")
            return
        path = path or self._ask_logo(os.path.dirname(self.ed_logo.text()))
        if not path:
            return
        self.project.extra_logos = list(self.project.extra_logos or []) + [new_extra_logo(path)]
        self._load_extras(self.project)
        self.changed.emit()

    def _pick_extra(self, i: int):
        logos = self.project.extra_logos
        if not 0 <= i < len(logos):
            return
        path = self._ask_logo(os.path.dirname(logos[i].get("path", "")))
        if path:
            logos[i] = {**logos[i], "path": path}
            self._load_extras(self.project)
            self.changed.emit()

    def _remove_extra(self, i: int):
        logos = list(self.project.extra_logos or [])
        if 0 <= i < len(logos):
            del logos[i]
            self.project.extra_logos = logos
            self._load_extras(self.project)
            self.changed.emit()

    def _choose_logo(self):
        start = os.path.dirname(self.ed_logo.text()) if self.ed_logo.text() else ""
        path, _ = QFileDialog.getOpenFileName(self, "Choose logo", start,
                                              "Images (*.png *.jpg *.jpeg *.webp *.bmp)")
        if path:
            self.ed_logo.setText(path)

    # ------------------------------------------------------------------ #
    # subtitle look
    # ------------------------------------------------------------------ #
    SUB_FIELDS = ("sub_color", "sub_outline", "sub_outline_color", "sub_shadow", "sub_box",
                  "sub_box_color", "sub_box_opacity", "sub_bold")

    def _color_button(self, field: str, title: str) -> QPushButton:
        b = QPushButton()
        b.setMinimumWidth(90)

        def pick():
            c = QColorDialog.getColor(QColor(self._subc.get(field, "#FFFFFF")), self, title)
            if c.isValid():
                self._subc[field] = c.name().upper()
                self._paint_color(b, self._subc[field])
                self._apply_subs()
        b.clicked.connect(pick)
        b.setProperty("field", field)
        return b

    @staticmethod
    def _paint_color(b: QPushButton, color: str):
        b.setText(color)
        b.setStyleSheet(f"background-color: {color}; color: "
                        f"{'#000000' if QColor(color).lightness() > 140 else '#FFFFFF'};")

    def _subs_show_changed(self, on: bool):
        if self._loading or not self.project:
            return
        self.subsShownToggled.emit(on)          # the main window keeps an undo step

    def _load_subs(self, p: Project):
        was = self._loading
        self._loading = True
        self.chk_subs_show.setChecked(not getattr(p, "subs_hidden", False))
        for f in ("sub_color", "sub_outline_color", "sub_box_color"):
            self._subc[f] = getattr(p, f)
        for b in (self.btn_sub_color, self.btn_sub_ocolor, self.btn_sub_bcolor):
            self._paint_color(b, self._subc[b.property("field")])
        i = self.cmb_sub_font.findData(p.sub_font or "")
        if i < 0:
            self.cmb_sub_font.addItem(p.sub_font, p.sub_font)
            i = self.cmb_sub_font.count() - 1
        self.cmb_sub_font.setCurrentIndex(i)
        self.sp_sub_size.setValue(int(round((p.subtitle_scale or 1.0) * 100)))
        self.chk_sub_bold.setChecked(bool(p.sub_bold))
        self.sp_sub_outline.setValue(float(p.sub_outline))
        self.sp_sub_shadow.setValue(float(p.sub_shadow))
        self.chk_sub_box.setChecked(bool(p.sub_box))
        self.sp_sub_bop.setValue(int(round(float(p.sub_box_opacity) * 100)))
        self.sp_sub_bottom.setValue(float(p.sub_bottom))
        self.sp_sub_x.setValue(float(getattr(p, "sub_x", 50.0) or 50.0))
        self.cmb_sub_preset.setCurrentIndex(self.cmb_sub_preset.findData(self._preset_of(p)))
        self._sub_enabled()
        self._loading = was

    @staticmethod
    def _preset_of(p: Project) -> str:
        for key, (_label, vals) in SUB_PRESETS.items():
            if all(getattr(p, k) == v for k, v in vals.items()):
                return key
        return "custom"

    def _sub_enabled(self):
        box = self.chk_sub_box.isChecked()
        for w in (self.btn_sub_bcolor, self.sp_sub_bop):
            w.setEnabled(box)
        for w in (self.sp_sub_outline, self.btn_sub_ocolor, self.sp_sub_shadow):
            w.setEnabled(not box)

    def _sub_center(self):
        if not self.project:
            return
        self.project.sub_x, self.project.sub_bottom = 50.0, 9.7
        self._load_subs(self.project)
        self.changed.emit()

    def _sub_preset(self, *_):
        if self._loading:
            return
        key = self.cmb_sub_preset.currentData()
        if key not in SUB_PRESETS:
            return
        for k, v in SUB_PRESETS[key][1].items():
            setattr(self.project, k, v)
        self._load_subs(self.project)
        self.changed.emit()

    def _apply_subs(self, *_):
        self._sub_enabled()
        if self._loading:
            return
        p = self.project
        p.sub_font = self.cmb_sub_font.currentData() or ""
        p.subtitle_scale = self.sp_sub_size.value() / 100.0
        p.sub_bold = self.chk_sub_bold.isChecked()
        p.sub_color = self._subc.get("sub_color", "#FFFFFF")
        p.sub_outline = round(self.sp_sub_outline.value(), 1)
        p.sub_outline_color = self._subc.get("sub_outline_color", "#000000")
        p.sub_shadow = round(self.sp_sub_shadow.value(), 1)
        p.sub_box = self.chk_sub_box.isChecked()
        p.sub_box_color = self._subc.get("sub_box_color", "#000000")
        p.sub_box_opacity = self.sp_sub_bop.value() / 100.0
        p.sub_bottom = round(self.sp_sub_bottom.value(), 1)
        p.sub_x = round(self.sp_sub_x.value(), 1)
        self._loading = True
        self.cmb_sub_preset.setCurrentIndex(self.cmb_sub_preset.findData(self._preset_of(p)))
        self._loading = False
        self.changed.emit()

    def _choose_color(self):
        c = QColorDialog.getColor(QColor(self._color), self, "Brand text colour")
        if c.isValid():
            self._color = c.name().upper()
            self._update_color_button()
            self._apply()

    def _update_color_button(self):
        self.btn_color.setText(self._color)
        self.btn_color.setStyleSheet(
            f"background-color: {self._color}; color: "
            f"{'#000000' if QColor(self._color).lightness() > 140 else '#FFFFFF'};")
