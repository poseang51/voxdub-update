"""SARIKA VOXDUB PRO processing core (no Qt imports here)."""

__version__ = "2.6.4"          # MAJOR.MINOR.PATCH - also add it to core/changelog.py
