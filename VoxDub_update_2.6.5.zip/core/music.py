"""
music.py - 🎵 The Music track of the Edit workspace: background music / sound
files laid on the timeline (like Filmora's audio track).

A file (mp3, m4a, wav, flac, ogg …) is converted once to a WAV in the
project's work folder (<work>/music/), then becomes an AudioClip in
project.music_clips: moved, trimmed, split, deleted on the timeline like an
AI voice clip, with its own volume and fades. The export mixes it with the
AI voice; it never mutes the original speech.
"""

import hashlib
import os
import tempfile

from .media import convert_to_wav, wav_duration
from .project import AudioClip, Project, new_id

AUDIO_EXT = (".mp3", ".m4a", ".aac", ".wav", ".flac", ".ogg", ".opus", ".wma")
DEFAULT_VOLUME = 0.5            # music under speech: half as loud
DEFAULT_FADE = 1.0              # s


def is_audio(path: str) -> bool:
    return path.lower().endswith(AUDIO_EXT)


def _wav_path(project: Project, path: str) -> str:
    base = project.work_dir if project.work_dir and os.path.isdir(project.work_dir) \
        else os.path.join(tempfile.gettempdir(), "voxdub_music")
    folder = os.path.join(base, "music")
    st = os.stat(path)
    key = hashlib.sha1(f"{os.path.abspath(path)}|{st.st_size}|{int(st.st_mtime)}"
                       .encode("utf-8")).hexdigest()[:12]
    stem = os.path.splitext(os.path.basename(path))[0][:40]
    return os.path.join(folder, f"{key}_{stem}.wav")


def needs_convert(project: Project, path: str) -> bool:
    out = _wav_path(project, path)
    return not (os.path.isfile(out) and os.path.getsize(out) > 44)


def wav_for(project: Project, path: str) -> str:
    """The WAV copy of an audio file (made once, kept in the work folder)."""
    out = _wav_path(project, path)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if not (os.path.isfile(out) and os.path.getsize(out) > 44):
        tmp = out + ".part.wav"         # (a half-written file is never taken for done)
        convert_to_wav(path, tmp, 44100)
        os.replace(tmp, out)
    return out


def add_music(project: Project, path: str, at: float = 0.0,
              fit_to_video: bool = True) -> AudioClip:
    """Put an audio file on the Music track at timeline time `at`.
    fit_to_video: a song longer than the rest of the video is trimmed there."""
    wav = wav_for(project, path)
    dur = wav_duration(wav)
    if dur <= 0:
        raise ValueError(f"No sound in {os.path.basename(path)}")
    at = max(0.0, float(at))
    length = dur
    end = project.sequence_duration()
    if fit_to_video and end > at + 0.5:
        length = min(dur, end - at)
    clip = AudioClip(id=new_id(), path=wav, start=round(at, 3), src_in=0.0,
                     src_out=round(length, 3), file_duration=dur,
                     label="🎵 " + os.path.splitext(os.path.basename(path))[0],
                     volume=DEFAULT_VOLUME, fade_in=min(DEFAULT_FADE, length / 4),
                     fade_out=min(DEFAULT_FADE, length / 4))
    project.music_clips.append(clip)
    project.music_clips.sort(key=lambda c: c.start)
    return clip


# --------------------------------------------------------------------------- #
# Detach audio (2.6.5, like Filmora): the video's sound becomes clips of its own
# --------------------------------------------------------------------------- #
DETACHED = "detached"           # seg_id of the clips made from the video's sound


def detach_audio(project: Project) -> list:
    """Put the video's own sound on the Music track - one clip under every
    video clip, same place, same cut, same loudness - and play / export the
    video without it. The clips can then be moved, cut, deleted or made
    louder on their own. Returns the new clips."""
    if project.audio_detached:
        return [c for c in project.music_clips if c.seg_id == DETACHED]
    if not project.has_audio or not project.video_path:
        raise ValueError("This video has no sound")
    wav = wav_for(project, project.video_path)
    dur = wav_duration(wav)
    if dur <= 0:
        raise ValueError("No sound in this video")
    name = os.path.splitext(os.path.basename(project.video_path))[0]
    project.layout_video()
    made = []
    for v in project.video_clips:
        a, b = max(0.0, v.src_in), min(dur, v.src_out)
        if b - a < 0.02:
            continue
        # (a slowed piece: the sound keeps its own speed, from the same place)
        made.append(AudioClip(id=new_id(), path=wav, start=round(v.start, 3),
                              src_in=round(a, 3), src_out=round(b, 3), file_duration=dur,
                              seg_id=DETACHED, label="🔊 " + name,
                              volume=round(float(project.original_volume), 3)))
    if not made:
        raise ValueError("No sound in this video")
    project.music_clips.extend(made)
    project.music_clips.sort(key=lambda c: c.start)
    project.audio_detached = True
    return made


def attach_audio(project: Project) -> int:
    """Undo Detach audio: the video plays its own sound again; the detached
    clips still on the Music track are taken away. Returns how many."""
    n = sum(1 for c in project.music_clips if c.seg_id == DETACHED)
    project.music_clips = [c for c in project.music_clips if c.seg_id != DETACHED]
    project.audio_detached = False
    return n
