"""
separate.py - "Music & effects only": take the voices out of the video's own
sound and keep the music / effects (the background of the dubbed video).

Uses the UVR MDX-Net "Inst HQ 3" model (ONNX, ~64 MB) with onnxruntime, which
the app already ships for OCR. The model is downloaded once, the first time
it is needed (like the Whisper models), into  <data dir>/models/.

The sound is processed in ~6 s pieces and written straight to a wav, so a
2-hour film needs no more memory than a 2-minute clip. The result is kept in
the project's work folder and reused (preview, every export).
"""

import os
import wave
from typing import Callable, Optional

import numpy as np

from .media import GPU_LOCK, data_dir, run_ffmpeg

MODEL_NAME = "UVR-MDX-NET-Inst_HQ_3.onnx"
MODEL_URL = ("https://github.com/TRvlvr/model_repo/releases/download/"
             "all_public_uvr_models/" + MODEL_NAME)
MODEL_MIN_BYTES = 60_000_000

SR = 44100
N_FFT = 6144
HOP = 1024
DIM_F = 3072
DIM_T = 256
COMPENSATE = 1.022                      # the model's output is a little quiet
CHUNK = HOP * (DIM_T - 1)               # samples per model run (~5.9 s)
TRIM = N_FFT // 2                       # edge of every piece that is thrown away
GEN = CHUNK - 2 * TRIM                  # new samples per piece

_session = None
_on_gpu = False


def model_path() -> str:
    return os.path.join(data_dir(), "models", MODEL_NAME)


def model_ready() -> bool:
    p = model_path()
    return os.path.isfile(p) and os.path.getsize(p) >= MODEL_MIN_BYTES


def download_model(progress: Optional[Callable[[int, str], None]] = None,
                   should_stop: Optional[Callable[[], bool]] = None) -> str:
    """Download the model once (~64 MB)."""
    path = model_path()
    if model_ready():
        return path
    import requests

    os.makedirs(os.path.dirname(path), exist_ok=True)
    part = path + ".part"
    try:
        with requests.get(MODEL_URL, stream=True, timeout=60) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0)) or 67_000_000
            got = 0
            with open(part, "wb") as f:
                for block in r.iter_content(1 << 20):
                    if should_stop and should_stop():
                        raise InterruptedError("Cancelled")
                    f.write(block)
                    got += len(block)
                    if progress:
                        progress(min(99, got * 100 // total),
                                 f"Downloading the music model {got >> 20}/{total >> 20} MB "
                                 "(first time only)...")
    except InterruptedError:
        raise
    except Exception as e:
        raise RuntimeError(
            "Could not download the model that removes the voices "
            f"({e}).\nCheck the internet connection and try again.") from e
    finally:
        if os.path.isfile(part) and os.path.getsize(part) < MODEL_MIN_BYTES:
            try:
                os.remove(part)
            except OSError:
                pass
    os.replace(part, path)
    return path


def _get_session():
    global _session, _on_gpu
    with GPU_LOCK:              # two episodes at once must not load it twice
        if _session is None:
            import onnxruntime as ort

            opts = ort.SessionOptions()
            opts.log_severity_level = 3
            providers = [p for p in ("CUDAExecutionProvider", "DmlExecutionProvider",
                                     "CPUExecutionProvider")
                         if p in ort.get_available_providers()]
            _session = ort.InferenceSession(model_path(), opts, providers=providers)
            _on_gpu = _session.get_providers()[0] != "CPUExecutionProvider"
    return _session


# --------------------------------------------------------------------------- #
# STFT the way the model was trained (torch.stft, center=True, hann window)
# --------------------------------------------------------------------------- #
_WIN = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(N_FFT) / N_FFT)).astype(np.float32)


def _stft(x: np.ndarray) -> np.ndarray:
    """x [n, CHUNK] -> complex [n, n_bins, DIM_T]"""
    pad = N_FFT // 2
    xp = np.pad(x, ((0, 0), (pad, pad)), mode="reflect")
    idx = np.arange(DIM_T)[:, None] * HOP + np.arange(N_FFT)[None, :]
    frames = xp[:, idx] * _WIN                              # [n, T, N_FFT]
    return np.fft.rfft(frames, axis=-1).transpose(0, 2, 1)  # [n, bins, T]


def _istft(spec: np.ndarray) -> np.ndarray:
    """complex [n, n_bins, DIM_T] -> [n, CHUNK]"""
    frames = np.fft.irfft(spec.transpose(0, 2, 1), n=N_FFT, axis=-1) * _WIN
    n = spec.shape[0]
    total = N_FFT + HOP * (DIM_T - 1)
    out = np.zeros((n, total), np.float32)
    env = np.zeros(total, np.float32)
    for t in range(DIM_T):
        out[:, t * HOP:t * HOP + N_FFT] += frames[:, t]
        env[t * HOP:t * HOP + N_FFT] += _WIN ** 2
    pad = N_FFT // 2
    return out[:, pad:pad + CHUNK] / np.maximum(env[pad:pad + CHUNK], 1e-8)


def _run_model(chunk: np.ndarray) -> np.ndarray:
    """Stereo piece [2, CHUNK] -> music [2, CHUNK]"""
    spec = _stft(chunk)                                     # [2, bins, T]
    x = np.stack([spec.real, spec.imag], axis=1)            # [2(ch), 2(re/im), bins, T]
    x = x[:, :, :DIM_F].reshape(1, 4, DIM_F, DIM_T).astype(np.float32)
    sess = _get_session()
    if _on_gpu:
        # Batch "At once 2": both episodes separating the music on the GPU at
        # the same moment closed the app (2.6.5) - one at a time there
        with GPU_LOCK:
            y = sess.run(None, {sess.get_inputs()[0].name: x})[0]
    else:
        y = sess.run(None, {sess.get_inputs()[0].name: x})[0]
    y = y.reshape(2, 2, DIM_F, DIM_T)
    full = np.zeros((2, N_FFT // 2 + 1, DIM_T), np.complex64)
    full[:, :DIM_F] = y[:, 0] + 1j * y[:, 1]
    return _istft(full)


# --------------------------------------------------------------------------- #
def music_path(project) -> str:
    return os.path.join(project.work_dir or os.path.dirname(project.video_path),
                        "music_only.wav")


def has_music(project) -> bool:
    p = music_path(project)
    return os.path.isfile(p) and os.path.getsize(p) > 1000 and \
        os.path.getmtime(p) >= os.path.getmtime(project.video_path)


def make_music_track(project, progress: Optional[Callable[[int, str], None]] = None,
                     should_stop: Optional[Callable[[], bool]] = None) -> str:
    """The video's sound without the voices (44.1 kHz stereo wav). Cached."""
    out = music_path(project)
    if has_music(project):
        return out
    if not project.has_audio:
        raise ValueError("This video has no sound.")
    if not model_ready():
        download_model(lambda p, m: progress and progress(p * 10 // 100, m), should_stop)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    src = out + ".src.wav"
    part = out + ".part"
    try:
        if progress:
            progress(10, "Reading the original sound...")
        run_ffmpeg(["-y", "-i", os.path.abspath(project.video_path), "-vn", "-ac", "2",
                    "-ar", str(SR), "-c:a", "pcm_s16le", src])
        with wave.open(src, "rb") as rf, wave.open(part, "wb") as wf:
            n = rf.getnframes()
            wf.setnchannels(2)
            wf.setsampwidth(2)
            wf.setframerate(SR)
            pieces = max(1, -(-n // GEN))
            for k in range(pieces):
                if should_stop and should_stop():
                    raise InterruptedError("Cancelled")
                a = k * GEN - TRIM                      # this piece covers [a, a + CHUNK)
                lo = max(0, a)
                rf.setpos(lo)
                raw = rf.readframes(max(0, min(n, a + CHUNK) - lo))
                data = np.frombuffer(raw, "<i2").astype(np.float32).reshape(-1, 2).T / 32768.0
                chunk = np.zeros((2, CHUNK), np.float32)
                chunk[:, lo - a:lo - a + data.shape[1]] = data
                music = _run_model(chunk)[:, TRIM:TRIM + GEN] * COMPENSATE
                keep = min(GEN, n - k * GEN)
                pcm = np.clip(music[:, :keep].T, -1.0, 1.0)
                wf.writeframes((pcm * 32767.0).astype("<i2").tobytes())
                if progress:
                    progress(10 + 90 * (k + 1) // pieces,
                             f"Removing the original voices {k + 1}/{pieces}...")
        os.replace(part, out)
        return out
    finally:
        for p in (src, part):
            if os.path.isfile(p):
                try:
                    os.remove(p)
                except OSError:
                    pass


# --------------------------------------------------------------------------- #
def voice_path(project) -> str:
    return os.path.join(project.work_dir or os.path.dirname(project.video_path),
                        "voice_only_16k.wav")


def make_voice_track(project, progress: Optional[Callable[[int, str], None]] = None,
                     should_stop: Optional[Callable[[], bool]] = None) -> str:
    """Only the voices (original sound minus music_only.wav), 16 kHz mono -
    for speech-to-text: thunder, footsteps and music are not heard as words.
    Makes the music track first when it is missing (needs the separation
    model; raises when it is not on this computer). Cached."""
    out = voice_path(project)
    if os.path.isfile(out) and has_music(project) and \
            os.path.getmtime(out) >= os.path.getmtime(music_path(project)):
        return out
    if not has_music(project):
        if not model_ready():
            raise RuntimeError("the voice separation model is not downloaded yet")
        make_music_track(project, progress, should_stop)
    part = out + ".part.wav"
    run_ffmpeg(["-y", "-i", os.path.abspath(project.video_path), "-i", music_path(project),
                "-filter_complex",
                f"[0:a]aresample={SR},aformat=channel_layouts=stereo[o];"
                f"[1:a]aformat=channel_layouts=stereo,volume=-1[m];"
                f"[o][m]amix=inputs=2:normalize=0:duration=first,"
                f"pan=mono|c0=0.5*c0+0.5*c1,aresample=16000[v]",
                "-map", "[v]", "-c:a", "pcm_s16le", part])
    os.replace(part, out)
    return out
