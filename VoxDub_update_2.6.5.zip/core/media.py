"""
media.py - ffmpeg helpers and WAV read/write utilities.

Everything that touches ffmpeg goes through this module so the rest of the
app never has to care where ffmpeg.exe lives.

ffmpeg lookup order:
  1. assets/ffmpeg/bin/ffmpeg(.exe) inside the app folder
  2. ffmpeg on the system PATH
  3. the binary shipped with the "imageio-ffmpeg" pip package
"""

import os
import re
import shutil
import subprocess
import sys
import threading
import tempfile
import wave
from dataclasses import dataclass

import numpy as np

# Where the app's own files are (assets/, tools/). In the built .exe this is
# the read-only "_internal" folder, so NOTHING is written here.
# (an update from Help › Check for updates runs from another folder: the
# installed app's folder is passed on by patchboot.py)
APP_DIR = os.environ.get("VOXDUB_APP_DIR") or \
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FROZEN = bool(getattr(sys, "frozen", False))      # running as the built .exe
# the folder of SARIKA VOXDUB PRO.exe (= APP_DIR when run from the sources)
EXE_DIR = os.path.dirname(sys.executable) if FROZEN else APP_DIR


# DirectML / CUDA models (OCR, voice/music separation) must not run from two
# threads at once: Batch "At once 2" closed the app (access violation /
# 0xc0000374 heap corruption). Every GPU model run takes this lock.
GPU_LOCK = threading.RLock()


def data_dir() -> str:
    """Per-user writable folder for logs, the CUDA pack, the voice-clone engine.
    From the sources: the app folder (as before)."""
    if not FROZEN:
        return APP_DIR
    base = os.environ.get("LOCALAPPDATA") or os.path.join(os.path.expanduser("~"), "AppData",
                                                          "Local")
    from .appinfo import DATA_FOLDER

    path = os.path.join(base, DATA_FOLDER)
    os.makedirs(path, exist_ok=True)
    return path


def default_output_dir() -> str:
    """Projects and exported videos. Settings › output_dir if chosen; the built
    .exe uses Videos/SARIKA VOXDUB PRO (Program Files is read-only), the
    sources keep <app>/output."""
    from . import settings

    chosen = (settings.get("output_dir", "") or "").strip()
    if chosen:
        return chosen
    if not FROZEN:
        return os.path.join(APP_DIR, "output")
    videos = os.path.join(os.path.expanduser("~"), "Videos")
    from .appinfo import OUTPUT_FOLDER

    return os.path.join(videos if os.path.isdir(videos) else os.path.expanduser("~"),
                        OUTPUT_FOLDER)

# Hide the black console window that pops up for each ffmpeg call on Windows
CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
DETACHED_PROCESS = 0x00000008 if sys.platform == "win32" else 0
_window_flag = CREATE_NO_WINDOW


def no_window() -> int:
    """creationflags for every helper program (ffmpeg, the VoxCPM worker).
    Normally CREATE_NO_WINDOW (a hidden console). On a PC where a console
    program can not get a console (0xc0000142 - e.g. the Windows desktop heap
    is used up, or a security tool blocks conhost) it becomes
    DETACHED_PROCESS: the program then runs with no console at all."""
    return _window_flag

_ffmpeg_cache = None


class FFmpegError(RuntimeError):
    """Raised when ffmpeg is missing or returns an error."""


def find_ffmpeg() -> str:
    """Return the full path to an ffmpeg executable or raise FFmpegError."""
    global _ffmpeg_cache
    if _ffmpeg_cache:
        return _ffmpeg_cache

    # Every candidate is tried once before it is used: a build of ffmpeg that
    # works on one PC can fail to start on another (0xc0000142 on a
    # customer's Windows) - then the next one is taken instead.
    exe = "ffmpeg.exe" if sys.platform == "win32" else "ffmpeg"
    candidates = [os.path.join(APP_DIR, "assets", "ffmpeg", "bin", exe),
                  os.path.join(EXE_DIR, "ffmpeg", exe)]
    try:
        import imageio_ffmpeg  # type: ignore

        candidates.append(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception as e:
        print(f"[ffmpeg] imageio-ffmpeg: {type(e).__name__}: {e}")
    candidates.append(shutil.which("ffmpeg") or "")
    failed = []
    missing = [c for c in candidates if c and not os.path.isfile(c)]
    for path in dict.fromkeys(c for c in candidates if c and os.path.isfile(c)):
        why = _ffmpeg_runs(path)
        if not why:
            if failed:
                print(f"[ffmpeg] using {path} ({'; '.join(failed)})")
            _ffmpeg_cache = path
            return path
        failed.append(f"{path}: {why}")
        print(f"[ffmpeg] cannot use {path}: {why}")

    for path in missing:
        print(f"[ffmpeg] not there: {path}")
    if FROZEN:
        if not failed:
            raise FFmpegError(
                "ffmpeg.exe is missing from the SARIKA VOXDUB PRO folder:\n"
                + os.path.join(EXE_DIR, "ffmpeg", exe)
                + "\n\nThe antivirus may have removed it (Windows Security › Protection "
                "history: Restore / Allow), then install SARIKA VOXDUB PRO again.")
        raise FFmpegError("ffmpeg does not start on this computer"
                          + (" (" + failed[0].split(": ", 1)[-1] + ")" if failed else "")
                          + ".\nAllow SARIKA VOXDUB PRO in the antivirus, update Windows, "
                          "or install SARIKA VOXDUB PRO again.")
    raise FFmpegError(
        "ffmpeg was not found.\n\n"
        "Fix one of these ways:\n"
        "  - pip install imageio-ffmpeg\n"
        "  - or install ffmpeg and add its 'bin' folder to PATH\n"
        "  - or copy ffmpeg.exe to voxdub_pro/assets/ffmpeg/bin/"
    )


def _ffmpeg_runs(path: str) -> str:
    """'' when `ffmpeg -version` works, else why not."""
    global _window_flag
    why = _try_version(path, _window_flag)
    if why == "exit code 0xc0000142" and _window_flag != DETACHED_PROCESS:
        # the program could not start its (hidden) console: try without one
        if not _try_version(path, DETACHED_PROCESS):
            print("[ffmpeg] console programs fail here (0xc0000142): "
                  "running helpers without a console")
            _window_flag = DETACHED_PROCESS
            return ""
    return why


def _try_version(path: str, flags: int) -> str:
    try:
        r = subprocess.run([path, "-hide_banner", "-version"], stdin=subprocess.DEVNULL,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30,
                           creationflags=flags)
    except (OSError, subprocess.TimeoutExpired) as e:
        return str(e)[:120]
    if r.returncode != 0 or b"ffmpeg version" not in r.stdout + r.stderr:
        code = r.returncode & 0xFFFFFFFF
        return f"exit code {code:#x}" if code > 255 else f"exit code {r.returncode}"
    return ""


_version_cache = None
_nvenc_cache = None


def ffmpeg_major_version() -> int:
    """Major version of the ffmpeg in use (99 when it cannot be parsed, e.g.
    git builds - those are new)."""
    global _version_cache
    if _version_cache is None:
        try:
            proc = subprocess.run([find_ffmpeg(), "-hide_banner", "-version"],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  creationflags=no_window(), timeout=20)
            first = proc.stdout.decode("utf-8", "replace").splitlines()[0]
            m = re.search(r"version\s+n?(\d+)\.", first)
            _version_cache = int(m.group(1)) if m else 99
        except Exception:
            _version_cache = 99
    return _version_cache


def nvenc_available() -> bool:
    """True when ffmpeg can encode H.264 on an NVIDIA GPU (h264_nvenc).
    Tested with a tiny real encode, because the encoder can be listed even
    when there is no NVIDIA GPU / driver."""
    global _nvenc_cache
    if _nvenc_cache is None:
        try:
            proc = subprocess.run(
                [find_ffmpeg(), "-hide_banner", "-loglevel", "error",
                 "-f", "lavfi", "-i", "color=black:s=256x256:d=0.2",
                 "-c:v", "h264_nvenc", "-preset", "p5", "-f", "null", "-"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                creationflags=no_window(), timeout=30)
            _nvenc_cache = proc.returncode == 0
        except Exception:
            _nvenc_cache = False
    return _nvenc_cache


def run_ffmpeg(args, cwd=None) -> str:
    """Run ffmpeg with the given argument list. Returns stderr text.

    Raises FFmpegError with the last lines of the log if ffmpeg fails.
    """
    cmd = [find_ffmpeg(), "-hide_banner", "-y"] + list(args)
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        creationflags=no_window(),
    )
    err = proc.stderr.decode("utf-8", errors="replace")
    if proc.returncode != 0:
        tail = "\n".join(err.strip().splitlines()[-12:])
        raise FFmpegError(f"ffmpeg failed (code {proc.returncode}):\n{tail}")
    return err


# --------------------------------------------------------------------------- #
# Media information (no ffprobe needed - we parse "ffmpeg -i" output)
# --------------------------------------------------------------------------- #
@dataclass
class MediaInfo:
    duration: float = 0.0
    width: int = 0
    height: int = 0
    fps: float = 0.0
    has_audio: bool = False
    has_video: bool = False


def get_media_info(path: str) -> MediaInfo:
    """Read duration / resolution / stream info of a media file."""
    if not os.path.isfile(path):
        raise FFmpegError(f"File not found: {path}")
    cmd = [find_ffmpeg(), "-hide_banner", "-i", path]
    try:
        proc = subprocess.run(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=no_window(),
        )
    except OSError as e:        # removed / blocked by an antivirus
        raise FFmpegError(f"ffmpeg could not be started ({e}).\nAllow SARIKA VOXDUB PRO in "
                          "the antivirus, or install it again.") from None
    text = proc.stderr.decode("utf-8", errors="replace")
    info = MediaInfo()

    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", text)
    if m:
        h, mi, s = m.groups()
        info.duration = int(h) * 3600 + int(mi) * 60 + float(s)

    in_video = False
    rotated = False
    for line in text.splitlines():
        if "Stream #" not in line:
            # phone videos: the picture is stored sideways with a rotation flag;
            # ffmpeg turns it upright when decoding, so width / height swap
            if in_video and re.search(r"(rotation of\s*-?(90|270)(\.0+)?\s*deg|"
                                      r"rotate\s*:\s*-?(90|270)\b)", line):
                rotated = True
            continue
        in_video = False
        if "Video:" in line and not info.has_video and "attached pic" not in line:
            info.has_video = True
            in_video = True
            dm = re.search(r",\s*(\d{2,5})x(\d{2,5})", line)
            if dm:
                info.width, info.height = int(dm.group(1)), int(dm.group(2))
            fm = re.search(r"([\d.]+)\s*fps", line)
            if fm:
                info.fps = float(fm.group(1))
        elif "Audio:" in line:
            info.has_audio = True
    if rotated and info.width and info.height:
        info.width, info.height = info.height, info.width

    if info.duration <= 0:
        # no duration in the header (e.g. browser-recorded .webm): read it through
        proc = subprocess.run([find_ffmpeg(), "-hide_banner", "-i", path, "-map", "0:v:0?",
                               "-map", "0:a:0?", "-c", "copy", "-f", "null", "-"],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              creationflags=no_window())
        times = re.findall(r"time=(\d+):(\d+):(\d+(?:\.\d+)?)",
                           proc.stderr.decode("utf-8", errors="replace"))
        if times:
            h, mi, s = times[-1]
            info.duration = int(h) * 3600 + int(mi) * 60 + float(s)
    if info.duration <= 0 or (not info.width and not info.has_audio):
        _probe_with_pyav(path, info)
    if info.duration <= 0:
        raise FFmpegError(_unreadable_message(path, proc.returncode, text))
    return info


def _probe_with_pyav(path: str, info: "MediaInfo") -> None:
    """Second opinion from PyAV (its own FFmpeg libraries, in the app): it
    can read some files the ffmpeg program reports without a duration."""
    try:
        import av  # type: ignore
    except Exception:
        return
    try:
        with av.open(path) as c:
            if c.duration:
                info.duration = info.duration or c.duration / 1_000_000
            for s in c.streams:
                if s.type == "video" and not info.has_video:
                    info.has_video = True
                    info.width = info.width or int(s.codec_context.width or 0)
                    info.height = info.height or int(s.codec_context.height or 0)
                    rate = s.average_rate or s.guessed_rate
                    info.fps = info.fps or (float(rate) if rate else 0.0)
                    if not info.duration and s.duration and s.time_base:
                        info.duration = float(s.duration * s.time_base)
                elif s.type == "audio":
                    info.has_audio = True
                    if not info.duration and s.duration and s.time_base:
                        info.duration = float(s.duration * s.time_base)
    except Exception as e:
        print(f"[media] PyAV could not open {path}: {e}")


def _unreadable_message(path: str, code: int, log: str) -> str:
    """Say WHY a file cannot be opened (the customer can act on it)."""
    try:
        size = os.path.getsize(path)
    except OSError:
        size = -1
    low = log.lower()
    if size == 0:
        why = "The file is empty (0 bytes) - download it again."
    elif "moov atom not found" in low or "invalid data found" in low or "end of file" in low:
        why = ("The file is damaged or was not downloaded completely. Wait until the "
               "download has finished, or download it again.")
    elif "permission denied" in low:
        why = "Windows does not allow reading this file (permission denied)."
    elif not log.strip():
        why = ("ffmpeg did not run on this computer (blocked by the antivirus?). "
               "Allow SARIKA VOXDUB PRO in the antivirus, or install it again.")
    else:
        why = "This file format could not be read."
    tail = "\n".join(l.strip() for l in log.strip().splitlines()[-4:])
    print(f"[media] cannot read {path} (exit {code}, {size} bytes):\n{log[-2000:]}")
    return (f"Cannot open this video:\n{path}\n\n{why}"
            + (f"\n\nffmpeg says:\n{tail}" if tail else ""))


# --------------------------------------------------------------------------- #
# Audio conversion
# --------------------------------------------------------------------------- #
# Every video the app accepts. The ones after .m4v (TV / camera / old formats)
# are copied into an MP4 first (prepare_video), because the preview player of
# Windows does not open all of them.
VIDEO_EXT = (".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v",
             ".ts", ".m2ts", ".mts", ".flv", ".wmv", ".mpg", ".mpeg", ".3gp", ".vob")
REMUX_EXT = (".ts", ".m2ts", ".mts", ".flv", ".wmv", ".mpg", ".mpeg", ".3gp", ".vob")
VIDEO_FILTER = ("Video files (" + " ".join("*" + e for e in VIDEO_EXT) + ")")


def needs_mp4(path: str) -> bool:
    return (path or "").lower().endswith(REMUX_EXT)


def to_mp4(src: str, out_mp4: str) -> str:
    """Put a .ts / .flv / .wmv ... video into an MP4 the player can open.
    1. copy the streams (seconds, no quality loss); 2. keep the picture, sound
    to AAC; 3. re-encode everything (old codecs such as WMV / MPEG-2)."""
    if os.path.isfile(out_mp4) and os.path.getsize(out_mp4) > 0 and \
            os.path.getmtime(out_mp4) >= os.path.getmtime(src):
        return out_mp4                                  # done before
    tmp = out_mp4 + ".part.mp4"
    base = ["-fflags", "+genpts", "-i", src, "-map", "0:v:0", "-map", "0:a:0?",
            "-sn", "-dn", "-avoid_negative_ts", "make_zero"]
    tries = [["-c", "copy"],
             ["-c:v", "copy", "-c:a", "aac", "-b:a", "192k"],
             ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p",
              "-c:a", "aac", "-b:a", "192k"]]
    last = None
    exes = [find_ffmpeg()]
    other = shutil.which("ffmpeg")      # a second ffmpeg, if the first cannot read it
    if other and os.path.normcase(other) != os.path.normcase(exes[0]):
        exes.append(other)
    for exe in exes:
        for codec in tries:
            try:
                proc = subprocess.run([exe, "-hide_banner", "-y"] + base + codec
                                      + ["-movflags", "+faststart", tmp],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                      stdin=subprocess.DEVNULL, creationflags=no_window())
                if proc.returncode != 0:
                    tail = proc.stderr.decode("utf-8", "replace").strip().splitlines()[-3:]
                    raise FFmpegError(f"code {proc.returncode}: " + " | ".join(tail))
                if os.path.isfile(tmp) and os.path.getsize(tmp) > 0:
                    os.replace(tmp, out_mp4)
                    return out_mp4
            except FFmpegError as e:                    # try the next way
                last = e
            except OSError as e:
                last = e
                break
    if os.path.isfile(tmp):
        try:
            os.remove(tmp)
        except OSError:
            pass
    raise FFmpegError(f"Could not open this video ({os.path.basename(src)}): {last}")


def extract_audio(video_path: str, out_wav: str, sample_rate: int = 16000) -> str:
    """Extract mono 16-bit PCM WAV from a video (used by Whisper + waveform)."""
    run_ffmpeg([
        "-i", video_path, "-vn", "-ac", "1", "-ar", str(sample_rate),
        "-c:a", "pcm_s16le", out_wav,
    ])
    return out_wav


def convert_to_wav(in_path: str, out_wav: str, sample_rate: int = 44100) -> str:
    """Convert any audio file (mp3 from TTS etc.) to mono 16-bit WAV."""
    run_ffmpeg([
        "-i", in_path, "-vn", "-ac", "1", "-ar", str(sample_rate),
        "-c:a", "pcm_s16le", out_wav,
    ])
    return out_wav


def _atempo_chain(factor: float) -> str:
    """atempo only accepts 0.5..2.0 per filter, so chain filters if needed."""
    parts = []
    while factor > 2.0:
        parts.append("atempo=2.0")
        factor /= 2.0
    while factor < 0.5:
        parts.append("atempo=0.5")
        factor /= 0.5
    parts.append(f"atempo={factor:.4f}")
    return ",".join(parts)


def change_speed(in_wav: str, out_wav: str, factor: float, sample_rate: int = 44100) -> str:
    """Speed audio up/down without changing pitch (factor 1.2 = 20% faster)."""
    run_ffmpeg([
        "-i", in_wav, "-filter:a", _atempo_chain(factor),
        "-ac", "1", "-ar", str(sample_rate), "-c:a", "pcm_s16le", out_wav,
    ])
    return out_wav


# --------------------------------------------------------------------------- #
# WAV read / write with numpy (16-bit PCM only - we always produce that)
# --------------------------------------------------------------------------- #
def read_wav(path: str):
    """Return (samples float32 mono in [-1, 1], sample_rate)."""
    with wave.open(path, "rb") as wf:
        sr = wf.getframerate()
        ch = wf.getnchannels()
        width = wf.getsampwidth()
        raw = wf.readframes(wf.getnframes())
    if width != 2:
        # Unusual format: let ffmpeg normalise it, then read again
        tmp = os.path.join(tempfile.gettempdir(), f"voxdub_norm_{os.getpid()}.wav")
        convert_to_wav(path, tmp, sr)
        return read_wav(tmp)
    data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    if ch > 1:
        data = data.reshape(-1, ch).mean(axis=1)
    return data, sr


def write_wav(path: str, samples: np.ndarray, sample_rate: int) -> str:
    """Write float samples in [-1, 1] as mono 16-bit WAV."""
    clipped = np.clip(samples, -1.0, 1.0)
    pcm = (clipped * 32767.0).astype(np.int16)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm.tobytes())
    return path


def read_wav_range(path: str, start: int, count: int, sample_rate: int):
    """Read `count` samples starting at sample `start` (mono float32) without
    loading the whole file. Returns fewer samples at the end of the file.
    Falls back to a full read + resample if the file has another rate."""
    with wave.open(path, "rb") as wf:
        sr = wf.getframerate()
        ch = wf.getnchannels()
        width = wf.getsampwidth()
        n_frames = wf.getnframes()
        if sr == sample_rate and width == 2:
            start = max(0, min(start, n_frames))
            wf.setpos(start)
            raw = wf.readframes(max(0, count))
            data = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
            if ch > 1:
                data = data.reshape(-1, ch).mean(axis=1)
            return data
    data, sr = read_wav(path)
    if sr != sample_rate and len(data):
        n_new = int(len(data) * sample_rate / sr)
        data = np.interp(np.linspace(0, len(data), n_new, endpoint=False),
                         np.arange(len(data)), data).astype(np.float32)
    return data[max(0, start):max(0, start) + max(0, count)]


class WavWriter:
    """Write a mono 16-bit WAV piece by piece (for files too big for RAM)."""

    def __init__(self, path: str, sample_rate: int):
        self.wf = wave.open(path, "wb")
        self.wf.setnchannels(1)
        self.wf.setsampwidth(2)
        self.wf.setframerate(sample_rate)

    def write(self, samples: np.ndarray):
        pcm = (np.clip(samples, -1.0, 1.0) * 32767.0).astype(np.int16)
        self.wf.writeframes(pcm.tobytes())

    def close(self):
        self.wf.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


def compute_peaks(path: str, peak_rate: int = 200, cache: bool = True) -> np.ndarray:
    """Waveform peaks (max |amplitude| per 1/peak_rate s, normalised 0..1).

    Reads the WAV in 60-second pieces (low memory for long videos) and, for
    big files, stores the result next to it as <file>.peaks.npy so opening
    the project again is instant."""
    npy = path + ".peaks.npy"
    if cache and os.path.isfile(npy) and os.path.getmtime(npy) >= os.path.getmtime(path):
        try:
            return np.load(npy)
        except Exception:
            pass
    with wave.open(path, "rb") as wf:
        sr, ch, width = wf.getframerate(), wf.getnchannels(), wf.getsampwidth()
        if width != 2:
            data, sr = read_wav(path)
            pieces = [data]
        else:
            pieces = None
        block = max(1, int(sr / peak_rate))
        out = []
        if pieces is None:
            step = block * peak_rate * 60          # ~60 s per read
            while True:
                raw = wf.readframes(step)
                if not raw:
                    break
                d = np.abs(np.frombuffer(raw, dtype=np.int16).astype(np.float32))
                if ch > 1:
                    d = d.reshape(-1, ch).max(axis=1)
                n = len(d) // block
                if n:
                    out.append(d[:n * block].reshape(n, block).max(axis=1) / 32768.0)
        else:
            d = np.abs(pieces[0])
            n = len(d) // block
            if n:
                out.append(d[:n * block].reshape(n, block).max(axis=1))
    arr = np.concatenate(out).astype(np.float32) if out else np.zeros(1, dtype=np.float32)
    if len(arr) > 10:
        top = float(np.percentile(arr, 99.5))
    else:
        top = float(arr.max())
    if top > 1e-4:                      # normalise so quiet audio is visible
        arr = np.clip(arr / top, 0, 1).astype(np.float32)
    if cache and len(arr) > 20000:      # > ~100 s of audio: worth keeping on disk
        try:
            np.save(npy, arr)
        except OSError:
            pass
    return arr


def wav_duration(path: str) -> float:
    """Duration of a WAV file in seconds."""
    with wave.open(path, "rb") as wf:
        return wf.getnframes() / float(wf.getframerate())


def format_time(seconds: float, millis: bool = True) -> str:
    """12.5 -> '00:00:12.500' (or '00:00:12')."""
    seconds = max(0.0, float(seconds))
    h = int(seconds // 3600)
    m = int((seconds % 3600) // 60)
    s = seconds % 60
    if millis:
        return f"{h:02d}:{m:02d}:{s:06.3f}"
    return f"{h:02d}:{m:02d}:{int(s):02d}"


def parse_time(text: str) -> float:
    """'00:01:02.500', '1:02.5', '62.5' or '00:01:02,500' -> seconds."""
    text = text.strip().replace(",", ".")
    if not text:
        raise ValueError("empty time")
    parts = text.split(":")
    total = 0.0
    for p in parts:
        total = total * 60 + float(p)
    return total


# --------------------------------------------------------------------------- #
# Timeline thumbnails (film strip on the video clip)
# --------------------------------------------------------------------------- #
THUMB_H = 54


def extract_thumbnails(video_path: str, cache_dir: str = "", height: int = THUMB_H,
                       max_count: int = 1500, should_stop=None):
    """Small frames for the timeline film strip.

    Decodes only KEYFRAMES (-skip_frame nokey), so even a 2-hour 1080p video
    takes seconds, not minutes. Returns (times float32[n], frames uint8[n,h,w,3]).
    The result is cached in cache_dir as thumbs_<h>.npz.
    """
    import threading

    cache = os.path.join(cache_dir, f"thumbs_{height}.npz") if cache_dir else ""
    if cache and os.path.isfile(cache) and os.path.getmtime(cache) >= os.path.getmtime(video_path):
        try:
            z = np.load(cache)
            return z["times"], z["frames"]
        except Exception:
            pass

    info = get_media_info(video_path)
    if info.width <= 0 or info.height <= 0:
        return np.zeros(0, np.float32), np.zeros((0, height, 1, 3), np.uint8)
    w = max(2, int(round(info.width * height / info.height / 2)) * 2)
    min_gap = max(0.0, info.duration / max_count)
    sync = ["-fps_mode", "passthrough"] if ffmpeg_major_version() >= 5 else ["-vsync", "0"]
    if info.duration <= 300:
        # short video: one frame per second (decoding everything is quick)
        skip, vf = [], f"fps=1,scale={w}:{height},showinfo"
    else:
        skip, vf = ["-skip_frame", "nokey"], f"scale={w}:{height},showinfo"
    cmd = [find_ffmpeg(), "-hide_banner", "-nostats"] + skip + ["-i", video_path,
           "-an", "-sn", "-vf", vf] + sync + \
          ["-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            creationflags=no_window())
    pts: list = []

    def read_err():
        for line in proc.stderr:
            m = re.search(rb"pts_time:\s*([\d.]+)", line)
            if m:
                pts.append(float(m.group(1)))

    reader = threading.Thread(target=read_err, daemon=True)
    reader.start()
    size = w * height * 3
    times, frames = [], []
    last = -1e9
    k = 0
    try:
        while True:
            if should_stop and should_stop():
                proc.kill()
                raise InterruptedError("Cancelled")
            buf = proc.stdout.read(size)
            if not buf or len(buf) < size:
                break
            # showinfo prints the frame's line before the frame is written out
            for _ in range(50):
                if len(pts) > k:
                    break
                import time as _t
                _t.sleep(0.002)
            t = pts[k] if len(pts) > k else (times[-1] + 1.0 if times else 0.0)
            k += 1
            if t - last < min_gap:
                continue
            last = t
            times.append(t)
            frames.append(np.frombuffer(buf, np.uint8).reshape(height, w, 3))
    finally:
        proc.stdout.close()
        proc.wait()
        reader.join(timeout=2)
    t_arr = np.array(times, np.float32)
    f_arr = np.stack(frames) if frames else np.zeros((0, height, w, 3), np.uint8)
    if cache and len(t_arr):
        try:
            np.savez(cache, times=t_arr, frames=f_arr)
        except OSError:
            pass
    return t_arr, f_arr
