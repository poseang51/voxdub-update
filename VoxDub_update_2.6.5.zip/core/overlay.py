"""
overlay.py - 🎞 The Video 2 track (2.6.5, like Filmora): another video laid
OVER the main video - picture in picture - from a place on the timeline, with
its own sound. Moved / trimmed / split / deleted on the timeline like a music
clip; dragged and resized on the preview.

Export: every clip is one more ffmpeg input (only its used part is read), put
on the picture with `overlay` while it plays, and its sound mixed in.
Times are timeline times (before Clip Properties › Speed, which is applied
to everything afterwards).
"""

import os
from typing import List, Tuple

from .media import get_media_info
from .project import OverlayClip, Project, new_id

DEFAULT_SIZE = 0.4              # of the frame width
FMT = "aresample=44100,aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo"


def add_overlay(project: Project, path: str, at: float = 0.0) -> OverlayClip:
    """Put a video on the Video 2 track at timeline time `at` (trimmed where
    the main video ends)."""
    info = get_media_info(path)
    if not info.has_video or info.duration <= 0.05:
        raise ValueError(f"No picture in {os.path.basename(path)}")
    at = max(0.0, float(at))
    end = project.sequence_duration()
    length = info.duration
    if end > at + 0.5:
        length = min(length, end - at)
    aspect = info.width / info.height if info.width > 0 and info.height > 0 else 16 / 9
    # a tall clip (9:16) on a wide frame: smaller, so it fits the height
    size = DEFAULT_SIZE
    fw, fh = (project.width or 1920), (project.height or 1080)
    if aspect < 1 and fw >= fh:
        size = min(size, 0.8 * aspect * fh / fw)
    clip = OverlayClip(id=new_id(), path=os.path.abspath(path), start=round(at, 3),
                       src_in=0.0, src_out=round(length, 3), file_duration=info.duration,
                       aspect=round(aspect, 4), has_audio=info.has_audio, size=round(size, 3),
                       label="🎞 " + os.path.splitext(os.path.basename(path))[0])
    project.overlay_clips.append(clip)
    project.overlay_clips.sort(key=lambda c: c.start)
    return clip


def active(project: Project) -> List[OverlayClip]:
    """The clips that will be in the export (inside the video, file there)."""
    end = project.sequence_duration()
    return [c for c in getattr(project, "overlay_clips", []) or []
            if c.length > 0.02 and c.start < end - 0.02 and os.path.isfile(c.path)]


def box(c: OverlayClip, W: int, H: int) -> Tuple[int, int, int, int]:
    """(x, y, w, h) of the clip's picture on a W x H frame (even numbers)."""
    w = max(16, int(W * max(0.05, min(1.0, c.size))) // 2 * 2)
    h = max(16, int(w / max(0.1, c.aspect)) // 2 * 2)
    if h > H:                                   # never taller than the frame
        h = H // 2 * 2
        w = max(16, int(h * c.aspect) // 2 * 2)
    x = int(round(c.x * W - w / 2))
    y = int(round(c.y * H - h / 2))
    return x, y, w, h


def input_args(c: OverlayClip) -> List[str]:
    return ["-ss", f"{max(0.0, c.src_in):.3f}", "-t", f"{c.length:.3f}",
            "-i", os.path.abspath(c.path)]


def video_filters(clips: List[OverlayClip], first_input: int, vin: str,
                  W: int, H: int) -> Tuple[List[str], str]:
    parts, cur = [], vin
    for k, c in enumerate(clips):
        x, y, w, h = box(c, W, H)
        parts.append(f"[{first_input + k}:v]setpts=PTS-STARTPTS+{c.start:.3f}/TB,"
                     f"scale={w}:{h},setsar=1,format=yuva420p[ovs{k}]")
        parts.append(f"[{cur}][ovs{k}]overlay=x={x}:y={y}:eof_action=pass:format=auto"
                     f":enable='between(t,{c.start:.3f},{c.end:.3f})'[ovv{k}]")
        cur = f"ovv{k}"
    return parts, cur


def audio_filters(clips: List[OverlayClip], first_input: int) -> Tuple[List[str], List[str]]:
    parts, labels = [], []
    for k, c in enumerate(clips):
        if not c.has_audio or c.volume <= 0.001:
            continue
        delay = f",adelay={int(round(c.start * 1000))}:all=1" if c.start > 0 else ""
        parts.append(f"[{first_input + k}:a]{FMT},asetpts=PTS-STARTPTS{delay},"
                     f"volume={min(2.0, c.volume):.3f}[ova{k}]")
        labels.append(f"ova{k}")
    return parts, labels
