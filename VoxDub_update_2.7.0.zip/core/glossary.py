"""
glossary.py - Names and words that must be translated the SAME way in every
episode of a story (characters, places, titles: 糖宝 -> តាំងប៉ៅ).

Two lists are used together (the story's wins):
  * My glossary        <settings dir>/glossary.json   (every video)
  * The story glossary  glossary.json in the story's output folder (Batch),
                        next to series_cast.json - it also LEARNS: names that
                        Gemini translated in one episode are added, so the
                        next episodes use the same Khmer name.

How it is used
  * Gemini: the list is given to Gemini as names it must keep.
  * Google Translate: the original word is replaced by its translation
    before the line is sent, so Google keeps it as it is.

File: {"terms": {"<original>": "<translation>", ...}, "learned": ["<original>", ...]}
"""

import json
import re
import os
from typing import Dict, List, Optional

from . import settings

MAX_LEARNED = 300


def my_path() -> str:
    return os.path.join(settings.settings_dir(), "glossary.json")


def story_path(series_cast_path: str) -> str:
    """The story glossary lives next to the story's series_cast.json."""
    return os.path.join(os.path.dirname(series_cast_path), "glossary.json") \
        if series_cast_path else ""


def load(path: str) -> Dict[str, str]:
    data = _read(path)
    terms = data.get("terms", {}) if isinstance(data, dict) else {}
    return {str(a).strip(): str(b).strip() for a, b in terms.items()
            if str(a).strip() and str(b).strip()}


def learned(path: str) -> List[str]:
    data = _read(path)
    return list(data.get("learned", [])) if isinstance(data, dict) else []


def _read(path: str) -> dict:
    if not path:
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save(path: str, terms: Dict[str, str], learned_keys: Optional[List[str]] = None) -> None:
    if not path:
        return
    clean = {a.strip(): b.strip() for a, b in terms.items() if a.strip() and b.strip()}
    keys = [k for k in (learned_keys if learned_keys is not None else learned(path))
            if k in clean]
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"version": 1, "terms": clean, "learned": keys}, f,
                  ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def for_project(project) -> Dict[str, str]:
    """My glossary + the story's glossary (the story's wins)."""
    terms = load(my_path())
    terms.update(load(story_path(getattr(project, "series_cast", "") or "")))
    return terms


def _latin_name(a: str, b: str) -> bool:
    """2.7 (3A号座位的代价, 12/11): Gemini sent "Jiang Hao" -> "Jiang Hao ឈីង ហ៊ូវ" -
    a name in Latin letters (pinyin) is no word of the original, and a
    translation with Latin letters in it is half English: not learned."""
    if not re.search(r"[^\x00-\x7f]", a):
        return True
    return bool(re.search(r"[A-Za-z]{2,}", b)) and not re.search(r"[A-Za-z]{2,}", a)


def learn(project, names: Dict[str, str]) -> int:
    """Add names Gemini chose to the story glossary (never changes a name that
    is already there). Returns how many were added."""
    path = story_path(getattr(project, "series_cast", "") or "")
    if not path or not names:
        return 0
    terms, keys = load(path), learned(path)
    added = 0
    for a, b in names.items():
        a, b = (a or "").strip(), (b or "").strip()
        if a and b and a not in terms and len(keys) < MAX_LEARNED and a != b \
                and not _latin_name(a, b):
            terms[a] = b
            keys.append(a)
            added += 1
    if added:
        save(path, terms, keys)
    return added


def apply_before_google(text: str, terms: Dict[str, str]) -> str:
    """Put the translation of every glossary word into the line (longest
    first, so 小糖宝 is replaced before 糖宝)."""
    changed = False
    for a in sorted(terms, key=len, reverse=True):
        if a in text:
            text = text.replace(a, f" {terms[a]} " if _needs_space(a) else terms[a])
            changed = True
    return " ".join(text.split()) if changed else text


def _needs_space(word: str) -> bool:
    """Latin / Cyrillic words are separated by spaces; Chinese, Japanese,
    Thai, Khmer ... are written without them."""
    return any(c.isascii() and c.isalpha() for c in word)
