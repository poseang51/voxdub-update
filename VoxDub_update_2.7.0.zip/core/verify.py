"""
verify.py - AI second opinion on the Smart Review lines (2.6.2).

After Transcribe (+ the OCR double-check) a few lines are flagged: no
subtitle on the video shows them ("nosub") or Whisper was not sure
("unsure"). Nobody looks at them in a Batch of 100 episodes, so Gemini
listens to just those 2-3 second pieces (a few per episode, ten pieces per
request - very little quota) and decides:

  * it hears the same words    -> the line is right (flag removed)
  * the same line, a letter or two different -> Gemini's spelling
  * it hears other words       -> the flag stays (shown in Quality check)
  * it hears nobody speaking   -> noise: taken out (kept in noise_lines)
  * no key / no quota / error  -> nothing changes (the flags stay)
"""

from difflib import SequenceMatcher
from typing import Callable, Dict, List, Optional

import numpy as np

from .project import Project

FLAGS = ("nosub", "unsure", "nosub_unsure")
PER_REQUEST = 10
PAD = 0.6                   # s of sound around a line (the subtitle time can be early / late)
MAX_PIECE = 15.0            # s
SAME = 0.6                  # similarity: "the same words"

Progress = Callable[[int, str], None]


def _norm(t: str) -> str:
    return "".join(ch for ch in (t or "") if ch.isalnum()).lower()


def same_words(a: str, b: str) -> bool:
    x, y = _norm(a), _norm(b)
    if not x or not y:
        return False
    return x == y or SequenceMatcher(None, x, y).ratio() >= SAME


CN_NUM = set("零一二两三四五六七八九十百千万亿")
MIN_RATIO, MAX_RATIO = 0.6, 1.5     # heard / line length for "the same line, misheard"


def _cut(raw: str, start: int, end: int) -> str:
    """raw[...] between the start-th and end-th letter (punctuation kept inside)."""
    idx = [i for i, ch in enumerate(raw) if ch.isalnum()]
    if start >= len(idx) or end <= start:
        return ""
    if end >= len(idx):                     # to the end: keep its "！" / "。"
        return raw[idx[start]:].strip()
    return raw[idx[start]:idx[end - 1] + 1].strip()


def _trim_neighbours(heard: str, before: str, after: str) -> str:
    """Gemini's words without the end of the line before / the start of the
    line after (the piece is cut 0.6 s wider than the line)."""
    h, b, a = _norm(heard), _norm(before), _norm(after)
    s, e = 0, len(h)
    # the line before: its last letters at the start ("妖魔几|乎全族被灭")
    for k in range(min(len(b), len(h) - 1), 0, -1):
        if h.startswith(b[-k:]):
            s = k
            break
    else:
        for k in range(min(len(b), 6), 1, -1):           # "吾|舞四|大家族..." (a letter off)
            at = h.find(b[-k:], 0, k + 3)
            if at >= 0:
                s = at + k
                break
    # the line after: its first letters at the end ("吾舞四|大")
    for k in range(min(len(a), e - s - 1), 0, -1):
        if h[s:e].endswith(a[:k]):
            e -= k
            break
    return _cut(heard, s, e)


def heard_instead(seg, heard: str, segments) -> str:
    """Gemini's words for a misheard line, or "" to keep the line (and its flag)."""
    if seg.check not in ("nosub", "nosub_unsure"):
        return ""                       # the video's subtitles had no complaint
    i = next((k for k, x in enumerate(segments) if x is seg), -1)
    before = segments[i - 1].text if i > 0 else ""
    after = segments[i + 1].text if 0 <= i < len(segments) - 1 else ""
    new = _trim_neighbours(heard, before, after)
    n, o = _norm(new), _norm(seg.text)
    if not n or not o:
        return ""
    if n == o:
        return new                      # only the neighbours were different: right
    if not (MIN_RATIO <= len(n) / len(o) <= MAX_RATIO or abs(len(n) - len(o)) <= 1):
        return ""                       # a scrap of it, or the lines around it too
    if any(c.isdigit() for c in n) and any(c in CN_NUM for c in n):
        return ""                       # "八 80万": the same number written twice
    if (before and n in _norm(before)) or (after and n in _norm(after)):
        return ""                       # what it heard is the next / last line
    return new


def _ask(pieces: List[np.ndarray], lang: str, should_stop=None) -> List[dict]:
    """Gemini: for every piece {"speech": bool, "text": str}."""
    from . import gemini
    from .translate import LANGUAGES

    lname = LANGUAGES.get(lang, (lang, ""))[0] if lang else ""
    parts: List[dict] = []
    for k, a in enumerate(pieces):
        parts.append({"text": f"Clip {k + 1}:"})
        parts.append({"inline_data": {"mime_type": "audio/wav", "data": gemini._wav_b64(a)}})
    parts.append({"text": (
        f"These are {len(pieces)} short clips from a "
        f"{lname + ' ' if lname else ''}video. For EACH clip write exactly what is said, "
        "in the original language (do not translate). If a clip has no speech - only "
        "music, noise, a breath or a grunt - set speech to false.\n"
        'Answer ONLY with JSON: {"clips": [{"clip": 1, "speech": true, "text": "..."}]}')})
    text, _ = gemini.generate(parts, temperature=0.0, max_tokens=4096,
                              should_stop=should_stop)
    try:
        data = gemini._json(text)
    except ValueError:
        return []
    items = data.get("clips", []) if isinstance(data, dict) else data
    out: Dict[int, dict] = {}
    for it in items if isinstance(items, list) else []:
        try:
            k = int(it.get("clip", 0)) - 1
        except (TypeError, ValueError, AttributeError):
            continue
        if 0 <= k < len(pieces):
            out[k] = {"speech": bool(it.get("speech", True)),
                      "text": str(it.get("text", "") or "").strip()}
    return [out.get(k, {}) for k in range(len(pieces))]


TIGHT = 0.1                 # s of sound around a line for the second listen


def _fit(ans: str, text: str) -> float:
    """How well what was heard fits a line: 1 = the line is in it."""
    a, t = _norm(ans), _norm(text)
    if not a or not t:
        return 0.0
    if t in a:
        return 1.0
    return SequenceMatcher(None, a, t).ratio()


def shifted(group, answers, segments) -> bool:
    """2.7 (EP002 12/11): Gemini joined clip 1 and 2 into one answer and then
    gave every next clip the words of the clip AFTER it ("咋样？ -> 落榜了？",
    "落榜了 -> 咋会呢？") - 6 right lines stayed flagged and "多多。" was
    replaced by the next line. True when the answers fit the neighbouring
    lines clearly better than their own lines."""
    pos = {id(x): k for k, x in enumerate(segments)}
    off = n = 0
    for s, ans in zip(group, answers):
        heard = (ans or {}).get("text", "")
        if not heard:
            continue
        n += 1
        k = pos.get(id(s), -1)
        own = _fit(heard, s.text)
        near = [segments[j].text for j in (k - 1, k + 1) if 0 <= j < len(segments)]
        best = max((_fit(heard, t) for t in near), default=0.0)
        if best >= 0.6 and best > own + 0.25:
            off += 1
    return off >= 2 and off >= 0.3 * max(1, n)


def _bounds(s, segments, audio_len: float, pad: float) -> tuple:
    """The piece of sound for a line: wider than the line, but never into
    the lines next to it (their words made Gemini join the clips)."""
    pos = next((k for k, x in enumerate(segments) if x is s), -1)
    lo = segments[pos - 1].end if pos > 0 else 0.0
    hi = segments[pos + 1].start if 0 <= pos < len(segments) - 1 else audio_len
    a = max(0.0, s.start - pad, min(lo, s.start))
    b = min(audio_len, max(s.end + pad, a + 0.5), max(hi, s.end), a + MAX_PIECE)
    return a, max(b, min(audio_len, a + 0.4))


def _neighbour_words(s, new: str, segments) -> bool:
    """The AI's words hold the whole line next to it ("多多。" ->
    "朵朵，你可想好了？" while the next line IS "你可想好了。"): putting them
    in would say that line twice."""
    if not segments:
        return False
    pos = next((k for k, x in enumerate(segments) if x is s), -1)
    n = _norm(new)
    for j in (pos - 1, pos + 1):
        if 0 <= j < len(segments) and pos >= 0:
            t = _norm(segments[j].text)
            if len(t) >= 2 and t in n:
                return True
    return False


def _confirm(maybe, audio, lang, stats, log, should_stop=None, segments=None) -> None:
    """Second listen, to the line's own time only (no neighbours around it):
    the AI's words go in only when it hears them again; when it now hears
    the line as it is, the line was right; anything else keeps the flag."""
    pieces = []
    for s, _new, _k in maybe:
        a = max(0.0, s.start - TIGHT)
        b = min(len(audio) / 16000.0, max(s.end + TIGHT, a + 0.4), a + MAX_PIECE)
        pieces.append(audio[int(a * 16000):int(b * 16000)])
    answers = []
    for g in range(0, len(pieces), PER_REQUEST):
        try:
            answers += _ask(pieces[g:g + PER_REQUEST], lang, should_stop)
        except InterruptedError:
            raise
        except Exception as e:                  # no second answer: the flags stay
            print(f"[verify] second listen not used: {e}")
            break
    for i, (s, new, k) in enumerate(maybe):
        ans = answers[i] if i < len(answers) else {}
        again = ans.get("text", "") if ans and ans.get("speech", True) else ""
        n, a, o = _norm(new), _norm(again), _norm(s.text)
        if a and (o in a or same_words(s.text, again)):
            s.check = ""                        # the line itself: right
            stats["right"] += 1
            log[k] += " (right on the 2nd listen)"
        elif a and (n in a or a in n or same_words(new, again)) and len(a) >= 0.6 * len(n) \
                and not _neighbour_words(s, new, segments):
            s.text = new
            s.translation, s.tts_text = "", ""
            s.check = ""
            stats["replaced"] = stats.get("replaced", 0) + 1
            log[k] += " (replaced)"
        else:
            stats["differs"] = stats.get("differs", 0) + 1
            # heard twice, but other words: offered, never put in by itself
            # (2.7 "Use the AI's words" - one click)
            # offered only when both listens agree with each other (EP002:
            # "多多" heard "朵朵" then "得多" - no guess is offered)
            if a and len(a) <= 2 * max(1, len(o)) + 4 \
                    and (n in a or a in n or same_words(new, again)) \
                    and not _neighbour_words(s, again, segments):
                s.ai_heard = again.strip()
            log[k] += f" (2nd listen: {again or 'nothing'} - kept)"


def verify_flagged(project: Project, progress: Optional[Progress] = None,
                   should_stop: Optional[Callable[[], bool]] = None) -> Dict[str, int]:
    """Let Gemini settle the flagged lines. Returns the counts
    {"checked", "right", "differs", "noise", "unclear"} (0 when Gemini is not set up)."""
    stats = {"checked": 0, "right": 0, "noise": 0}
    from . import gemini, settings

    if not settings.get("ai_verify_lines", True) or not gemini.configured():
        return stats
    try:
        from . import plans
        if not plans.allows("gemini"):          # Gemini is a Pro feature
            return stats
    except Exception:
        pass
    todo = [s for s in project.segments
            if getattr(s, "check", "") in FLAGS and not s.tts_path]
    for s in todo:
        s.ai_heard = ""
    if not todo or not project.original_audio:
        return stats
    from .media import read_wav

    try:
        audio, sr = read_wav(project.original_audio)
    except Exception as e:
        print(f"[verify] cannot read the sound: {e}")
        return stats
    if sr != 16000:
        n = int(len(audio) * 16000 / sr)
        audio = np.interp(np.linspace(0, len(audio), n, endpoint=False),
                          np.arange(len(audio)), audio).astype(np.float32)
    lang = project.detected_lang or (project.source_lang
                                     if project.source_lang != "auto" else "")
    ordered = sorted(project.segments, key=lambda x: x.start)
    noise = []
    maybe = []                                  # (line, the AI's words, log index)
    log: List[str] = []
    for g in range(0, len(todo), PER_REQUEST):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        group = todo[g:g + PER_REQUEST]
        if progress:
            progress(int(100 * g / len(todo)),
                     f"AI checks {len(todo)} unsure lines ({g + 1}-{g + len(group)})...")
        pieces = []
        for s in group:
            a, b = _bounds(s, ordered, len(audio) / 16000.0, PAD)
            pieces.append(audio[int(a * 16000):int(b * 16000)])
        try:
            answers = _ask(pieces, lang, should_stop)
            if len(group) > 1 and shifted(group, answers, ordered):
                # the answers slid onto the next clips: ask clip by clip
                print(f"[verify] answers did not match their clips - asking one by one")
                stats["one_by_one"] = stats.get("one_by_one", 0) + len(group)
                answers = []
                for piece in pieces:
                    answers += (_ask([piece], lang, should_stop) or [{}])[:1]
        except InterruptedError:
            raise
        except Exception as e:                  # no quota / network: flags stay
            print(f"[verify] Gemini not used: {e}")
            note = f"⚠ AI check of unsure lines stopped ({str(e)[:100]}) - see Quality check"
            if note not in project.engine_notes:
                project.engine_notes.append(note)
            break
        for s, ans in zip(group, answers):
            if not ans:
                continue                        # no answer for this one: keep the flag
            stats["checked"] += 1
            heard = ans.get("text", "")
            log.append(f"{s.start:.1f}s {s.text} -> "
                       + (heard if ans.get("speech", True) and heard else "(no speech)"))
            if not ans.get("speech", True) or not _norm(heard):
                # Gemini misses speech under loud music / action (a real line of
                # 8 letters was taken out): only a grunt or a short unsure scrap
                # goes; anything longer keeps its flag for the Quality check
                from .pipeline import NOISE_CHARS, NOISE_MAX_LETTERS
                short = len(_norm(s.text)) <= NOISE_MAX_LETTERS
                if any(c in NOISE_CHARS for c in s.text) or \
                        (short and s.check == "nosub_unsure"):
                    noise.append(s)
                    stats["noise"] += 1
                else:
                    stats["unclear"] = stats.get("unclear", 0) + 1
            elif _norm(s.text) in _norm(heard):
                # (the piece also holds a bit of the lines around it: Gemini
                # hearing MORE than the line still confirms it)
                s.check = ""
                stats["right"] += 1
            elif same_words(s.text, heard) and abs(len(_norm(s.text)) - len(_norm(heard))) <= 1:
                # the same line with a letter or two read wrongly ("爷希" / "爷爷"):
                # Gemini's spelling
                s.text = heard.strip()
                s.translation, s.tts_text = "", ""
                s.check = ""
                stats["fixed"] = stats.get("fixed", 0) + 1
            else:
                # other words. Gemini also hears the lines next to it ("对" came
                # back as "山 对 就是 这 细 框 山 80万"), so its words go in only
                # when no subtitle on the video backs the line ("nosub") and,
                # with the neighbours' words cut off, they are about as long as
                # the line: "年级" -> "找死" (2.6.5)
                new = heard_instead(s, heard, project.segments)
                if new and _norm(new) == _norm(s.text):
                    s.check = ""                # the line, with its neighbours around it
                    stats["right"] += 1
                elif new:
                    # not yet: Gemini may have given the line NEXT to it
                    # ("把槍放下" -> "是，老大。"): asked again below
                    maybe.append((s, new, len(log) - 1))
                else:
                    stats["differs"] = stats.get("differs", 0) + 1
    if maybe:
        _confirm(maybe, audio, lang, stats, log, should_stop, ordered)
    if noise:
        from .pipeline import take_out_lines

        take_out_lines(project, noise)
    if stats["checked"]:
        msg = (f"[verify] AI checked {stats['checked']} lines: {stats['right']} right, "
               f"{stats.get('fixed', 0)} spelling fixed, "
               f"{stats.get('replaced', 0)} misheard (AI's words), "
               f"{stats.get('differs', 0)} heard differently (kept), {stats['noise']} noise, "
               f"{stats.get('unclear', 0)} not heard (kept): " + " · ".join(log[:20]))
        print(msg)
        try:
            from . import crashlog
            crashlog.note(msg)                  # (the Test copy has no log file)
        except Exception:
            pass
    return stats
