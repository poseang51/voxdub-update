"""
series.py - one cast for a whole series (Batch Queue).

In one video the user can check the characters by hand; in a queue of 40
episodes nobody has time for that. So the episodes of a series share one
"series cast" file:

  * every character found in an episode is compared, by voice, with the
    characters already known from the other episodes;
  * a known character gets the SAME label, name, colour, voice and pitch it
    had before ("Woman 1 · Sreymom ↑" in every episode);
  * a new character is added to the file, so the next episodes know it.

What the user fixes once in the editor (name, man / woman, voice, pitch) is
written back to the file and every later episode follows it.

The voice prints are the GE2E embeddings of core/speakers.py, centred on
each episode (what all lines share - music, room - taken out), so the same
actor gives similar prints in different episodes.
"""

import json
import os
import threading
from typing import Dict, Optional, Tuple

import numpy as np

from . import speakers

FILE_NAME = "series_cast.json"
MATCH = 0.45                # voice-print similarity: the same person
KEYS = ("name", "gender", "age", "voice", "clone", "ref", "ref_text", "shift", "auto_name",
        "shift_hand", "delivery", "pace", "rank", "rank_ai")
_lock = threading.RLock()   # the queue can dub several episodes at once


def load(path: str) -> dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict) and isinstance(d.get("cast"), dict):
            return d
    except (OSError, ValueError):
        pass
    return {"version": 1, "cast": {}}


def save(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def _vec(e) -> Optional[np.ndarray]:
    if not e:
        return None
    v = np.asarray(e, np.float32)
    n = float(np.linalg.norm(v))
    return v / n if n > 0 else None


def _compatible(a: dict, b: dict) -> bool:
    """Never the same person: a clearly male and a clearly female voice."""
    pa, pb = a.get("pitch") or 0, b.get("pitch") or 0
    if pa and pb:
        side = [(-1 if p < speakers.MALE_MAX else (1 if p > speakers.FEMALE_MIN else 0))
                for p in (pa, pb)]
        if side[0] * side[1] < 0:
            return False
    return True


def _new_label(used) -> str:
    for i in range(500):
        lab = speakers.LABELS[i] if i < len(speakers.LABELS) else f"S{i + 1}"
        if lab not in used:
            return lab
    return f"S{len(used) + 1}"


def _auto_name(series: Dict[str, dict], c: dict, skip: str = "") -> str:
    kind = speakers.kind_of(c)
    n = sum(1 for lab, o in series.items()
            if lab != skip and (o.get("auto_name") or "").rsplit(" ", 1)[0] == kind)
    return f"{kind} {n + 1}"


def apply(project, path: str) -> Tuple[int, int]:
    """Give the episode's characters the series' labels and settings, and add
    its new characters to the series. Returns (known, new)."""
    cast = getattr(project, "cast", {}) or {}
    if not path or not cast:
        return 0, 0
    with _lock:
        data = load(path)
        sc: Dict[str, dict] = data["cast"]
        # best pairs first, each character used once
        pairs = []
        for lab, c in cast.items():
            e = _vec(c.get("emb"))
            if e is None:
                continue
            for sl, s in sc.items():
                se = _vec(s.get("emb"))
                if se is not None and len(se) == len(e) and _compatible(c, s):
                    sim = float(e @ se)
                    if sim >= MATCH:
                        pairs.append((sim, lab, sl))
        mapping: Dict[str, str] = {}
        taken = set()
        for sim, lab, sl in sorted(pairs, reverse=True):
            if lab not in mapping and sl not in taken:
                mapping[lab] = sl
                taken.add(sl)
                print(f"[series] {lab} = {sl} {sc[sl].get('auto_name') or ''} "
                      f"(voice match {sim:.2f})")
        known = len(mapping)
        used = set(sc) | taken
        for lab in sorted(cast, key=lambda l: -(cast[l].get("seconds") or 0)):
            if lab not in mapping:
                mapping[lab] = _new_label(used)
                used.add(mapping[lab])
        new_cast: Dict[str, dict] = {}
        for lab, c in cast.items():
            c = dict(c)
            sl = mapping[lab]
            if sl in sc:
                s = sc[sl]
                for k in KEYS:
                    if k in s:
                        c[k] = s[k]
                c["auto"] = False if s.get("user") else c.get("auto", True)
            new_cast[sl] = c
        for s in project.segments:
            if s.speaker in mapping:
                s.speaker = mapping[s.speaker]
                s.gender = new_cast[s.speaker].get("gender") or s.gender
        project.cast = new_cast
        # new characters: a fixed name and pitch from now on (the same in
        # every episode, whoever else speaks in it)
        auto = speakers._auto_shifts(project)
        for lab, c in new_cast.items():
            if lab in sc:
                continue
            if c.get("shift") is None:
                c["shift"] = auto.get(lab, 0)
            c["auto_name"] = _auto_name(sc, c)
            sc[lab] = {k: c.get(k) for k in KEYS}
            sc[lab].update(emb=c.get("emb"), pitch=c.get("pitch", 0),
                           seconds=c.get("seconds", 0.0), episodes=0)
        # learn: the voice print follows all episodes (weighted by speech)
        for lab, c in new_cast.items():
            s = sc[lab]
            e, se = _vec(c.get("emb")), _vec(s.get("emb"))
            w, sw = float(c.get("seconds") or 1.0), float(s.get("seconds") or 1.0)
            if e is not None and se is not None and len(e) == len(se) and s.get("episodes"):
                m = (se * sw + e * w) / (sw + w)
                s["emb"] = [round(float(x), 4) for x in m / (np.linalg.norm(m) + 1e-9)]
                if c.get("pitch") and s.get("pitch"):
                    s["pitch"] = round((s["pitch"] * sw + c["pitch"] * w) / (sw + w))
                s["seconds"] = round(sw + w, 1)
            s["episodes"] = int(s.get("episodes") or 0) + 1
        save(path, data)
    speakers.recount(project)
    return known, len(new_cast) - known


def update_from_project(project) -> int:
    """What the user changed in the Characters tab goes to the series, so
    the next episodes follow it. Returns the characters updated."""
    path = getattr(project, "series_cast", "")
    cast = getattr(project, "cast", {}) or {}
    if not path or not cast:
        return 0
    n = 0
    with _lock:
        data = load(path)
        sc = data["cast"]
        for lab, c in cast.items():
            s = sc.get(lab)
            if s is None or c.get("auto", True):
                continue
            changed = False
            for k in KEYS:
                if k != "auto_name" and c.get(k) != s.get(k):
                    s[k] = c.get(k)
                    changed = True
            if changed:
                if speakers.kind_of(c) != (s.get("auto_name") or "").rsplit(" ", 1)[0]:
                    s["auto_name"] = c["auto_name"] = _auto_name(sc, c, skip=lab)
                s["user"] = True
                n += 1
        if n:
            save(path, data)
    return n


def summary(path: str) -> str:
    sc = load(path)["cast"] if path and os.path.isfile(path) else {}
    return f"{len(sc)} characters" if sc else "empty"
