"""
updates.py - "A new version is ready": the app checks a small file on the
internet and tells the user when a newer version exists.

The file (version.json) is put anywhere the app can download it with a
direct link - a GitHub release / raw file, your website, ...:

    {"version": "1.0.2",
     "url": "https://.../SARIKA_VOXDUB_PRO_1.0.2_setup.exe",
     "notes": "Merge: part names. Batch: same format for fast merge."}

The link to version.json is set once in Help › Check for updates (setting
"update_url"); the installer can also ship it. Nothing is downloaded or
installed by itself: the user gets the message and the download link.
At most one automatic check a day.

2.4 - "Update now" (no new installer): version.json can also point to an
UPDATE PACKAGE (new core / ui code, made by tools/make_update.py on the
seller's PC):

    {"version": "2.4.1", "notes": "...",
     "patch_url": "https://.../VoxDub_update_2.4.1.zip",
     "patch_sha256": "...", "patch_sig": "...",      # signed with the seller's key
     "patch_base": "2.3.1",                          # oldest installed version it fits
     "needs": ["requests"]}                          # Python modules it uses

The package is checked (SHA-256 + the seller's signature: nobody else can
make one the app accepts), unpacked into the settings folder and used from
the next start (patchboot.py). A new installer (url) is still needed when
the update needs new Python packages / files that are not code.
"""

import hashlib
import json
import os
import re
import shutil
import time
import zipfile
from typing import Callable, List, Optional, Tuple

from . import __version__, settings

URL_SETTING = "update_url"
LAST_SETTING = "update_last_check"
SKIP_SETTING = "update_skip"
DAY = 24 * 3600


def parse(version: str) -> Tuple[int, ...]:
    nums = re.findall(r"\d+", version or "")
    return tuple(int(n) for n in nums[:4]) or (0,)


def newer(remote: str, local: str = __version__) -> bool:
    return parse(remote) > parse(local)


def link_file() -> str:
    """assets/update_url.txt: the link shipped with the program (build_exe.bat),
    so a customer never has to type it."""
    from .media import APP_DIR

    return os.path.join(APP_DIR, "assets", "update_url.txt")


def _shipped() -> str:
    try:
        with open(link_file(), encoding="utf-8-sig") as f:
            return next((ln.strip() for ln in f if ln.strip() and not ln.startswith("#")), "")
    except OSError:
        return ""


def _admin_default() -> str:
    """The seller's PC: the version.json that make_update.bat writes."""
    try:
        from . import admin

        if not admin.is_owner():
            return ""
    except Exception:
        return ""
    from .media import APP_DIR

    for folder in (APP_DIR, os.path.join(os.path.dirname(APP_DIR), "voxdub_pro")):
        p = os.path.join(folder, "update_output", "version.json")
        if os.path.isfile(p):
            return p
    return ""


def url() -> str:
    """Where version.json is: the link set in the app, else the one shipped with
    the program, else (seller's PC) make_update's own version.json."""
    return ((settings.get(URL_SETTING, "") or "").strip() or _shipped() or _admin_default())


def set_url(link: str) -> None:
    """Keep the link, and put it in assets/update_url.txt so the next build
    ships it to every customer (when the program folder can be written)."""
    link = (link or "").strip().strip('"')
    settings.set(URL_SETTING, link)
    try:
        os.makedirs(os.path.dirname(link_file()), exist_ok=True)
        with open(link_file(), "w", encoding="utf-8") as f:
            f.write("# where version.json is (Help › Check for updates)\n" + link + "\n")
    except OSError:
        pass


def is_local(link: str = "") -> bool:
    return bool(_local(link or url()))


def _local(link: str) -> str:
    """A file on this PC / the network (D:\\updates\\version.json, file:///...)
    instead of a web link ("" when it is a web link)."""
    link = (link or "").strip()
    if link.lower().startswith("file:"):
        from urllib.parse import unquote, urlparse

        u = urlparse(link)
        path = unquote(u.path)
        if u.netloc:                                   # file://server/share/...
            path = "//" + u.netloc + path
        elif re.match(r"^/[A-Za-z]:", path):           # file:///D:/...
            path = path[1:]
        return path
    if re.match(r"^[A-Za-z]:[\\/]", link) or link.startswith(("\\\\", "/")):
        return link
    return ""


def fetch(link: str, timeout: int = 15) -> dict:
    path = _local(link)
    if path:
        with open(path, "rb") as f:
            content = f.read()
    else:
        import requests

        r = requests.get(link, timeout=timeout, headers={"Cache-Control": "no-cache"})
        r.raise_for_status()
        content = r.content
    data = json.loads(content.decode("utf-8-sig"))
    if not isinstance(data, dict) or not data.get("version"):
        raise ValueError("version.json has no \"version\"")
    return data


def check(force: bool = False) -> Optional[dict]:
    """The update info when a newer version exists, else None.
    Without force: only once a day, and not for a version the user skipped."""
    link = url()
    if not link:
        return None
    now = time.time()
    # a file on this PC / the network costs nothing: checked at every start
    if not force and not _local(link) and now - float(settings.get(LAST_SETTING, 0) or 0) < DAY:
        return None
    settings.set(LAST_SETTING, now)
    data = fetch(link)
    try:
        from . import pricing

        pricing.take_remote(data)           # "prices" in version.json
    except Exception:
        pass
    if not newer(str(data["version"])):
        return None
    if not force and str(settings.get(SKIP_SETTING, "") or "") == str(data["version"]):
        return None
    return data


# --------------------------------------------------------------------------- #
# Update packages ("Update now")
# --------------------------------------------------------------------------- #
PACKAGES = ("core", "ui")
NEVER = ("core/license_pub.py",)        # each installer keeps its own
SIG_PREFIX = "VOXDUB-UPDATE"


def _boot():
    try:
        import patchboot
        return patchboot
    except ImportError:                 # (tests / tools without main.py)
        return None


def confirm_running() -> bool:
    """2.6.13: this window runs the update and works - write that down, and
    undo what a SECOND copy of the app (opened at the same moment, 11/11
    09:03:10 + 09:03:11) did: it saw this copy's "booting" mark and called
    the update "did not start" (Update now is not possible). True = repaired."""
    pb = _boot()
    ver = getattr(pb, "active", "") if pb else ""
    if not ver:
        return False
    try:
        st = pb.read_state()
        bad = [v for v in st.get("bad", []) if v != ver]
        if st.get("active") == ver and not st.get("booting") and bad == st.get("bad", []):
            return False
        fixed = st.get("active") != ver or bad != st.get("bad", [])
        st.update(active=ver, booting="", bad=bad, misses=0)
        pb.write_state(st)
        if fixed:
            print(f"[update] {ver} works - put back (a second copy of the app had dropped it)")
        return fixed
    except Exception as e:
        print(f"[update] {e}")
        return False


def installed_version() -> str:
    """The installer's own version (without an update)."""
    pb = _boot()
    return (pb.base_version if pb and pb.base_version else "") or __version__


def active_update() -> str:
    pb = _boot()
    return pb.active if pb else ""


def _message(version: str, sha: str) -> bytes:
    return f"{SIG_PREFIX}|{version}|{sha}".encode("ascii")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def can_patch(info: dict) -> Tuple[bool, str]:
    """(True, "") when this version can be updated with the package."""
    if not info.get("patch_url"):
        return False, "no update package - download the installer"
    if not info.get("patch_sha256") or not info.get("patch_sig"):
        return False, "the update package is not signed"
    base = installed_version()
    need = str(info.get("patch_base") or "")
    if need and parse(base) < parse(need):
        return False, f"needs the {need} installer first (you have {base})"
    pb = _boot()
    if pb is not None:
        bad = pb.read_state().get("bad", [])
        if str(info.get("version")) in bad:
            return False, "this update did not start on this PC before"
    import importlib.util

    missing = []
    for mod in info.get("needs") or []:
        try:
            if importlib.util.find_spec(str(mod)) is None:
                missing.append(str(mod))
        except (ImportError, ValueError):
            missing.append(str(mod))
    if missing:
        return False, "needs the new installer (" + ", ".join(missing) + ")"
    return True, ""


def download(link: str, dest: str, progress: Optional[Callable] = None,
             should_stop: Optional[Callable] = None) -> str:
    path = _local(link)
    if not path and not re.match(r"^[a-z]+://", link or "", re.I):
        # a bare file name: next to version.json
        base = url()
        if _local(base):
            path = os.path.join(os.path.dirname(_local(base)), link)
        elif base:
            link = base.rsplit("/", 1)[0] + "/" + link
    if path:
        shutil.copyfile(path, dest)
        if progress:
            progress(90, "Update copied")
        return dest
    import requests

    with requests.get(link, stream=True, timeout=30) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        with open(dest + ".part", "wb") as f:
            for block in r.iter_content(1 << 16):
                if should_stop and should_stop():
                    raise RuntimeError("Stopped")
                f.write(block)
                got += len(block)
                if progress and total:
                    progress(int(got * 90 / total), f"Downloading the update… "
                                                    f"{got / 1e6:.1f} / {total / 1e6:.1f} MB")
    os.replace(dest + ".part", dest)
    return dest


def verify_package(path: str, info: dict, public_key: Optional[bytes] = None) -> None:
    """Raises when the package is not exactly the one the seller signed."""
    sha = sha256_file(path)
    if sha != str(info.get("patch_sha256", "")).lower():
        raise ValueError("The update file is damaged (SHA-256 does not match) - try again.")
    from . import license as lic

    pub = public_key if public_key is not None else lic.public_key()
    if not pub:
        raise ValueError("This app has no key to check updates with.")
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        Ed25519PublicKey.from_public_bytes(pub).verify(
            lic._b64d(str(info["patch_sig"])), _message(str(info["version"]), sha))
    except Exception:
        raise ValueError("The update is not signed by SARIKA - it was not installed.")


def _safe_names(z: zipfile.ZipFile) -> List[str]:
    names = []
    for n in z.namelist():
        if n.endswith("/"):
            continue
        clean = n.replace("\\", "/")
        parts = clean.split("/")
        if clean.startswith("/") or ".." in parts or ":" in clean:
            raise ValueError(f"Bad path in the update: {n}")
        if clean == "manifest.json" or (parts[0] in PACKAGES and clean.endswith(".py")
                                        and clean not in NEVER):
            names.append(n)
    return names


def install_package(path: str, info: dict, public_key: Optional[bytes] = None) -> str:
    """Check + unpack the package; it is used from the next start."""
    verify_package(path, info, public_key)
    pb = _boot()
    from . import settings as st

    root = os.path.join(st.settings_dir(), "updates")
    version = str(info["version"])
    target = os.path.join(root, version)
    tmp = target + ".new"
    shutil.rmtree(tmp, ignore_errors=True)
    with zipfile.ZipFile(path) as z:
        names = _safe_names(z)
        if "manifest.json" in names:
            man = json.loads(z.read("manifest.json").decode("utf-8"))
            if str(man.get("version")) != version:
                raise ValueError("The update package is for another version.")
        if not any(n.replace("\\", "/") == "core/__init__.py" for n in names):
            raise ValueError("The update package has no core/__init__.py.")
        for n in names:
            out = os.path.join(tmp, *n.replace("\\", "/").split("/"))
            os.makedirs(os.path.dirname(out), exist_ok=True)
            with open(out, "wb") as f:
                f.write(z.read(n))
    shutil.rmtree(target, ignore_errors=True)
    os.replace(tmp, target)
    state = pb.read_state() if pb else {}
    state.update(active=version, booting="")
    state["bad"] = [v for v in state.get("bad", []) if v != version]
    if pb:
        pb.write_state(state)
    else:
        os.makedirs(root, exist_ok=True)
        with open(os.path.join(root, "state.json"), "w", encoding="utf-8") as f:
            json.dump(state, f)
    # older update folders are not needed any more
    for name in os.listdir(root):
        full = os.path.join(root, name)
        if os.path.isdir(full) and name != version and parse(name) < parse(version):
            shutil.rmtree(full, ignore_errors=True)
    return version


def remove_updates() -> bool:
    """Back to the installed version from the next start."""
    pb = _boot()
    if pb is None:
        return False
    state = pb.read_state()
    if not state.get("active") and not pb.active:
        return False
    state.update(active="", booting="")
    pb.write_state(state)
    return True


def make_package(src: str, version: str, out_dir: str, private_key: bytes,
                 notes: str = "", base: str = "", needs: Optional[List[str]] = None,
                 link: str = "") -> Tuple[str, dict]:
    """Seller's PC: zip core/ + ui/ of the sources at `src` and sign it.
    Returns (zip path, the version.json fields for it)."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    from . import license as lic

    os.makedirs(out_dir, exist_ok=True)
    name = f"VoxDub_update_{version}.zip"
    path = os.path.join(out_dir, name)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps({"version": version, "made": time.strftime(
            "%Y-%m-%d %H:%M")}, ensure_ascii=False))
        for pkg in PACKAGES:
            for folder, dirs, files in os.walk(os.path.join(src, pkg)):
                dirs[:] = sorted(d for d in dirs if d != "__pycache__")
                for f in sorted(files):
                    if not f.endswith(".py"):
                        continue
                    full = os.path.join(folder, f)
                    rel = os.path.relpath(full, src).replace(os.sep, "/")
                    if rel in NEVER:
                        continue
                    if rel == "core/__init__.py":     # the package's own version
                        with open(full, encoding="utf-8") as fh:
                            text = fh.read()
                        text = re.sub(r'__version__\s*=\s*"[^"]*"',
                                      f'__version__ = "{version}"', text, count=1)
                        z.writestr(rel, text)
                    else:
                        z.write(full, rel)
    sha = sha256_file(path)
    sig = Ed25519PrivateKey.from_private_bytes(private_key).sign(_message(version, sha))
    info = {"version": version, "notes": notes,
            "patch_url": (link.rstrip("/") + "/" + name) if link else name,
            "patch_sha256": sha, "patch_sig": lic._b64e(sig),
            "patch_base": base or "2.3.1", "needs": list(needs or [])}
    return path, info
