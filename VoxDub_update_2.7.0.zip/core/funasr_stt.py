"""
funasr_stt.py - Paraformer-zh / SenseVoice-Small speech-to-text (2.6.2, Test).

FunASR (Alibaba DAMO, MIT) reads Chinese much faster than Whisper and seldom
skips a line under music. It needs PyTorch, which the app itself does not
ship: core/funasr_worker.py runs with the VoxCPM Python (venv-voxcpm has
torch + funasr + modelscope already) - see core/voxcpm.python_path().

Engines (Speech-to-text › Engine):  "paraformer"  Chinese (Mandarin) only
                                    "sensevoice"  zh / yue / en / ja / ko
"""

import json
import os
import subprocess
import threading
from typing import Callable, List, Optional, Tuple

from . import settings
from .media import no_window
from .project import Segment, new_id

ENGINES = {"paraformer": "Paraformer-zh", "sensevoice": "SenseVoice-Small",
           "funasr-nano": "Fun-ASR-Nano"}


class FunASRError(RuntimeError):
    pass


# --------------------------------------------------------------------------- #
# 2.6.8: the worker stays running between episodes (Paraformer is loaded once
# per Batch, not for every episode). It ends after IDLE seconds without work
# - the models hold about 1 GB of graphics memory - and when the app quits.
# Settings "funasr_keep_loaded": False = one process per reading (as before).
# --------------------------------------------------------------------------- #
IDLE = 180.0
KEEP_MIN_VRAM_MB = 7000     # 4 GB cards: VRAM 3.9 / 4.0 GB, black screen (3/11)
_lock = threading.Lock()
_keep_auto = None


def keep_loaded() -> bool:
    """Keep the worker between episodes? Settings "funasr_keep_loaded":
    True / False; not set = only on a graphics card with 7 GB or more, or on
    a PC without an NVIDIA card (then it holds normal memory, not VRAM).
    On a 4 GB card it held ~1 GB of VRAM while the music separation, the
    OCR and the export used the card too: VRAM full, the driver reset."""
    global _keep_auto
    want = settings.get("funasr_keep_loaded", None)
    if want is not None:
        return bool(want)
    if _keep_auto is None:
        try:
            from .resources import gpu_stats

            g = gpu_stats()
            _keep_auto = (not g) or g[0]["total_mb"] >= KEEP_MIN_VRAM_MB
        except Exception:
            _keep_auto = False
    return _keep_auto
_srv = None
_timer = None
BATCH_S_SMALL = 60          # 2.6.10: seconds of speech per Paraformer step on a small card


def batch_seconds() -> int:
    """Paraformer reads this many seconds of speech in one go: 300 (fast) -
    on a card under 7 GB 60, so its memory peak is lower (a little slower).
    Settings "funasr_batch_s" overrides it."""
    want = settings.get("funasr_batch_s", None)
    if want:
        return max(10, int(want))
    try:
        from .resources import small_gpu

        return BATCH_S_SMALL if small_gpu() else 300
    except Exception:
        return 300


class _Server:
    def __init__(self, py, voxcpm, serve=True):
        self.py = py
        args = [py, "-u", _worker()] + (["--serve"] if serve else [])
        self.serve = serve
        self.proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, text=True, encoding="utf-8",
                                     errors="replace", env=voxcpm._child_env(),
                                     creationflags=no_window())
        self.err_tail: List[str] = []
        threading.Thread(target=self._read_err, daemon=True).start()

    def _read_err(self):                 # keep the last lines for the message / log
        for line in self.proc.stderr:
            self.err_tail.append(line.rstrip())
            del self.err_tail[:-20]

    def alive(self) -> bool:
        return self.proc.poll() is None

    def send(self, req: dict):
        self.err_tail.clear()
        self.proc.stdin.write(json.dumps(req, ensure_ascii=False) + "\n")
        self.proc.stdin.flush()
        if not self.serve:
            self.proc.stdin.close()

    def lines(self):
        while True:
            line = self.proc.stdout.readline()
            if not line:                 # the worker ended
                return
            yield line

    def close(self):
        try:
            if self.proc.stdin and not self.proc.stdin.closed:
                self.proc.stdin.close()
        except Exception:
            pass
        if self.proc.poll() is None:
            try:
                self.proc.kill()
            except Exception:
                pass
        try:
            self.proc.wait(timeout=10)
        except Exception:
            pass


def _server(py, voxcpm) -> "_Server":
    global _srv, _timer
    if _timer:
        _timer.cancel()
        _timer = None
    if _srv is None or not _srv.alive() or _srv.py != py:
        if _srv:
            _srv.close()
        _srv = _Server(py, voxcpm)
    return _srv


def _forget(srv) -> None:
    global _srv
    if _srv is srv:
        _srv = None


def _idle_later(srv) -> None:
    global _timer
    _timer = threading.Timer(IDLE, lambda: shutdown(srv))
    _timer.daemon = True
    _timer.start()


def shutdown(only=None) -> None:
    """End the waiting worker (idle, or the app quits)."""
    global _srv
    with _lock:
        if _srv is not None and (only is None or _srv is only):
            _srv.close()
            _srv = None


import atexit  # noqa: E402

atexit.register(shutdown)


def _worker() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "funasr_worker.py")


def python_path() -> str:
    from . import voxcpm

    return voxcpm.python_path()


def ready() -> bool:
    p = python_path()
    return bool(p) and os.path.isfile(p)


def transcribe(audio_path: str, engine: str, report: Callable[[float, str], None],
               should_stop: Optional[Callable[[], bool]] = None, start_at: float = 0.0,
               on_segment: Optional[Callable[[Segment], None]] = None,
               language: str = "auto") -> Tuple[List[Segment], str, str]:
    """Returns (segments, language, device). Raises FunASRError."""
    from . import voxcpm

    py = python_path()
    if not py or not os.path.isfile(py):
        raise FunASRError(f"{ENGINES.get(engine, engine)} needs the VoxCPM environment "
                          "(setup_voxcpm.bat) – it was not found")
    req = {"wav": os.path.abspath(audio_path), "model": engine,
           "device": settings.get("funasr_device", "auto") or "auto",
           "start_at": float(start_at or 0.0),
           "language": language if language in ("zh", "yue", "en", "ja", "ko") else "auto",
           "batch_s": batch_seconds()}
    keep = keep_loaded()
    with _lock:                            # one reading at a time (one GPU)
        for attempt in (0, 1):
            reused = keep and _srv is not None and _srv.alive()
            srv = _server(py, voxcpm) if keep else _Server(py, voxcpm, serve=False)
            segments: List[Segment] = []
            done = None
            heard = False
            last_end = 0.0
            ok = False
            try:
                try:
                    srv.send(req)
                except OSError:            # the waiting worker had ended
                    pass
                for line in srv.lines():
                    if should_stop and should_stop():
                        raise InterruptedError("Cancelled")
                    try:
                        msg = json.loads(line)
                    except ValueError:
                        continue
                    heard = True
                    if "seg" in msg:
                        s = msg["seg"]
                        a = max(float(s["start"]), last_end)
                        b = float(s["end"])
                        if b - a < 0.15:
                            continue
                        last_end = b
                        seg = Segment(id=new_id(), start=round(a, 3), end=round(b, 3),
                                      text=str(s["text"]).strip())
                        segments.append(seg)
                        if on_segment:
                            on_segment(seg)
                    elif "p" in msg:
                        report(min(99, int(msg["p"])),
                               f"{msg.get('msg', '')} – {len(segments)} lines")
                    elif "ok" in msg:
                        done = msg
                        break
                ok = bool(done and done.get("ok"))
            finally:
                if not (keep and ok):
                    # cancelled, failed, or not kept: end it (a model half way
                    # through a reading cannot be stopped any other way)
                    srv.close()
                    _forget(srv)
                else:
                    _idle_later(srv)
            err_tail = srv.err_tail
            if done is None and not heard and reused and attempt == 0:
                continue                   # the kept worker had gone: start a new one
            break
    if done is None or not done.get("ok"):
        why = (done or {}).get("error") or (err_tail[-1] if err_tail else "it stopped")
        if err_tail:
            print("[funasr] " + "\n[funasr] ".join(err_tail[-8:]))
        raise FunASRError(f"{ENGINES.get(engine, engine)} failed: {why}")
    dev = done.get("device", "")
    report(100, f"Transcription done: {len(segments)} lines [{ENGINES.get(engine)} · {dev}]")
    return segments, done.get("lang") or "zh", dev
