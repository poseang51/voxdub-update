"""
reading.py - 2.7: how the AI voice READS a word (the subtitle keeps it as
written). "VIP" -> "វីអាយភី", a Chinese name written in Latin letters, a word
Edge reads wrongly ...

Two lists, like the glossary (the story's wins):
  * My reading list     <settings dir>/reading.json        (every video)
  * The story's list    reading.json next to series_cast.json (Batch story)
Same file format as the glossary: {"terms": {"<as written>": "<as read>"}}.

Only the text sent to the voice changes - never the subtitle or the
translation. Latin words match without caring about capitals.
"""

import os
import re
from typing import Dict

from . import glossary, settings


def my_path() -> str:
    return os.path.join(settings.settings_dir(), "reading.json")


def story_path(series_cast_path: str) -> str:
    return os.path.join(os.path.dirname(series_cast_path), "reading.json") \
        if series_cast_path else ""


def is_reading_list(path: str) -> bool:
    return os.path.basename(path or "") == "reading.json"


def for_project(project) -> Dict[str, str]:
    terms = glossary.load(my_path())
    terms.update(glossary.load(story_path(getattr(project, "series_cast", "") or "")))
    return terms


def apply(text: str, terms: Dict[str, str]) -> str:
    """The text as the voice must read it (longest words first)."""
    if not text or not terms:
        return text
    for a in sorted(terms, key=len, reverse=True):
        b = terms[a]
        if a.isascii() and any(c.isalpha() for c in a):
            # a Latin word: whole word, any capitals ("vip", "VIP")
            text = re.sub(r"(?<![A-Za-z0-9])" + re.escape(a) + r"(?![A-Za-z0-9])",
                          lambda _m: b, text, flags=re.IGNORECASE)
        elif a in text:
            text = text.replace(a, b)
    return text


def changed_words(old: Dict[str, str], new: Dict[str, str]):
    """Words added, changed or taken out of the list."""
    return {a for a in set(old) | set(new) if old.get(a) != new.get(a)}


def lines_using(project, words) -> list:
    """The lines whose voice must be made again after the list changed."""
    if not words:
        return []
    probe = {w: "\0" for w in words}
    return [s for s in project.segments
            if s.voice_text() and apply(s.voice_text(), probe) != s.voice_text()]
