"""
transcribe.py - Speech-to-text with faster-whisper.

The first run downloads the chosen model from HuggingFace
(tiny ~75 MB, base ~145 MB, small ~480 MB, medium ~1.5 GB) into the
user's cache folder. After that it works offline.

GPU (NVIDIA)
  faster-whisper runs on CUDA when the cuBLAS / cuDNN libraries are
  available. On Windows the easiest way is the pip packages installed by
  install_gpu.bat (nvidia-cublas-cu12, nvidia-cudnn-cu12); their DLL folders
  are added to the search path here. The GPU is tested on 1 s of silence
  before use - if anything is missing we fall back to the CPU and say why.

Long videos
  Speech is found first (VAD) and transcribed in short chunks, so Whisper
  cannot lose its place in a 40-minute film. transcribe_audio() can start part-way (start_at) and reports every line
  through on_segment(), so an interrupted transcription is not lost and
  can continue from where it stopped.
"""

import glob
import os
import sys
import threading
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np

from .media import read_wav
from .project import Segment, new_id

WHISPER_MODELS = ["tiny", "base", "small", "medium", "large-v3", "large-v3-turbo"]
# 2.6.13: large-v3-turbo - nearly large-v3 quality, much faster, ~1.6 GB GPU
# memory instead of ~3 GB. Its download name, for faster-whisper versions
# that do not know the short name yet:
MODEL_IDS = {"large-v3-turbo": "mobiuslabsgmbh/faster-whisper-large-v3-turbo"}

_model_cache: Dict[str, object] = {}
_model_lock = threading.Lock()      # the batch queue can dub several videos at once
_device_cache: Dict[str, str] = {}
_notes: List[str] = []              # low GPU memory: what was done (shown in the log)
_dll_dirs_added = False


def _add_cuda_dll_dirs():
    """Let Windows find the cuBLAS / cuDNN DLLs: pip's nvidia-* packages (from
    the sources), bundled in the built .exe, or the CUDA pack in
    %LOCALAPPDATA%\\VoxDubPRO\\cuda / <exe folder>\\cuda."""
    global _dll_dirs_added
    if _dll_dirs_added or sys.platform != "win32":
        return
    _dll_dirs_added = True
    import site

    from .media import APP_DIR, EXE_DIR, data_dir

    bases = []
    try:
        bases += site.getsitepackages()
    except Exception:
        pass
    try:
        bases.append(site.getusersitepackages())
    except Exception:
        pass
    bases += [os.path.join(sys.prefix, "Lib", "site-packages"), APP_DIR, EXE_DIR]
    dirs = []
    for base in bases:
        dirs += glob.glob(os.path.join(base, "nvidia", "*", "bin"))
    for pack in (os.path.join(data_dir(), "cuda"), os.path.join(EXE_DIR, "cuda")):
        if os.path.isdir(pack):
            dirs.append(pack)
            dirs += glob.glob(os.path.join(pack, "nvidia", "*", "bin"))
    for d in dict.fromkeys(dirs):
        try:
            os.add_dll_directory(d)
        except (OSError, AttributeError):
            pass
        if d not in os.environ.get("PATH", ""):
            os.environ["PATH"] = d + os.pathsep + os.environ.get("PATH", "")


def cudnn_found() -> bool:
    """Windows: are the cuDNN DLLs anywhere Whisper can load them from?
    Without them ctranslate2 can hang (or close the app) on the first GPU run,
    so the GPU is not even tried - CPU is used and install_gpu.bat suggested."""
    if sys.platform != "win32":
        return True
    for d in os.environ.get("PATH", "").split(os.pathsep):
        if d and glob.glob(os.path.join(d, "cudnn*64_*.dll")):
            return True
    return False


def cuda_gpu_count() -> int:
    try:
        import ctranslate2

        return ctranslate2.get_cuda_device_count()
    except Exception:
        return 0


def _load_model(size: str):
    """Load (and cache) a faster-whisper model. Uses the GPU when it really works.
    One model is shared by all videos being dubbed at the same time."""
    with _model_lock:
        return _load_model_locked(size)


def _load_model_locked(size: str):
    if size in _model_cache:
        return _model_cache[size]
    # another model size was used before (e.g. large-v3, now medium): let it go
    # first - two models at once filled a 4 GB card (VRAM 3.8 / 4.0 GB)
    if _model_cache:
        import gc

        _model_cache.clear()
        _device_cache.clear()
        gc.collect()

    from faster_whisper import WhisperModel  # imported lazily: it is heavy

    _add_cuda_dll_dirs()
    model, device = None, ""
    gpu_error = ""
    low_vram = ""
    use = size
    if cuda_gpu_count() > 0 and not cudnn_found():
        gpu_error = "the NVIDIA cuDNN / cuBLAS files are not installed"
        print(f"[whisper] GPU skipped: {gpu_error}")
    elif cuda_gpu_count() > 0:
        # 2.3: not enough free GPU memory -> a smaller model on the GPU, or
        # this model on the CPU (Settings: low_vram), instead of failing
        from . import resources, settings

        use, where, why = resources.whisper_plan(
            size, resources.free_vram_mb(), settings.get("low_vram", "smaller") or "smaller")
        if why:
            print(f"[whisper] {why}")
            _notes.append(why)
        if where == "cpu":
            low_vram = why
    if cuda_gpu_count() > 0 and not gpu_error and not low_vram:
        for compute in ("float16", "int8_float16"):
            try:
                m = WhisperModel(MODEL_IDS.get(use, use), device="cuda", compute_type=compute)
                # A GPU can be present while the CUDA/cuDNN DLLs are missing;
                # that only fails once the model runs, so test it on silence.
                segs, _ = m.transcribe(np.zeros(16000, dtype=np.float32), language="en")
                list(segs)
                model, device = m, f"GPU (CUDA, {compute})" + (
                    f" - {use} (low GPU memory)" if use != size else "")
                break
            except Exception as e:
                gpu_error = str(e).splitlines()[0][:160]
    if model is None:
        model = WhisperModel(MODEL_IDS.get(size, size), device="cpu", compute_type="int8")
        device = "CPU"
        if low_vram:
            device += f" - {low_vram}"
        elif gpu_error:
            from .media import FROZEN
            device += (f" - GPU not usable: {gpu_error} "
                       + ("(install the NVIDIA GPU pack)" if FROZEN else "(run install_gpu.bat)"))

    _model_cache[size] = model
    _device_cache[size] = device
    return model


def release_models() -> bool:
    """Let the Whisper model go (its GPU memory is freed) - e.g. before SARIKA
    VOICE needs the GPU for VoxCPM2. It loads again by itself when needed."""
    with _model_lock:
        if not _model_cache:
            return False
        import gc

        _model_cache.clear()
        _device_cache.clear()
        gc.collect()
        return True


def device_label(size: str) -> str:
    return _device_cache.get(size, "")


# --------------------------------------------------------------------------- #
# Speech regions -> short chunks
# --------------------------------------------------------------------------- #
# Whisper run over a whole 40-minute film (with condition_on_previous_text)
# can lose its place: it hallucinates, repeats itself or makes one "line" of
# several minutes and silently skips the speech inside it. Long dramas with
# music under the dialogue are the worst case. So we find every speech region
# ourselves (Silero VAD, bundled with faster-whisper, low threshold so speech
# over music is kept), group them into chunks of at most ~28 s (one Whisper
# window) and transcribe each chunk on its own: every region is guaranteed to
# be looked at, and a bad chunk cannot spoil the rest.
SR = 16000
CHUNK_MAX = 28.0            # s, one Whisper window is 30 s
CHUNK_GAP = 1.2             # s of silence that still joins two regions
CHUNK_PAD = 0.25            # s of context around each chunk
VAD_OPTIONS = dict(threshold=0.3, min_speech_duration_ms=150,
                   min_silence_duration_ms=300, speech_pad_ms=200)

# Lines Whisper is known to invent on music / silence (from its training subtitles)
HALLUCINATIONS = (
    "amara.org", "字幕由", "字幕提供", "请不吝点赞", "订阅 转发", "打赏支持", "明镜与点点",
    "谢谢观看", "感谢观看", "thanks for watching", "thank you for watching",
    "please subscribe", "subtitles by", "ご視聴ありがとうございました", "구독과 좋아요",
    "字幕by", "字幕 by", "字幕制作", "字幕组", "索兰娅",
    # 3/11 EP004 0:57: "MING PAO CANADA .COM 打開旁邊那個鈴鐺 如果喜歡我的影片請訂閱"
    "ming pao", "mingpao", "明报", "打开旁边那个铃铛", "喜欢我的影片", "请订阅", "订阅我的频道",
    "点赞订阅", "订阅转发",
)


def speech_regions(audio: np.ndarray) -> List[Tuple[float, float]]:
    """(start, end) seconds of speech, or [] when the VAD is not available."""
    try:
        from faster_whisper.vad import VadOptions, get_speech_timestamps
    except Exception:
        return []
    try:
        ts = get_speech_timestamps(audio, VadOptions(**VAD_OPTIONS))
    except Exception as e:                                  # never fatal
        print(f"[transcribe] VAD failed: {e}")
        return []
    return [(t["start"] / SR, t["end"] / SR) for t in ts if t["end"] > t["start"]]


def make_chunks(regions: List[Tuple[float, float]], total: float,
                max_len: float = CHUNK_MAX, max_gap: float = CHUNK_GAP,
                pad: float = CHUNK_PAD) -> List[Tuple[float, float]]:
    """Group speech regions into chunks of at most max_len seconds (long
    regions are cut into pieces) and add a little context around each."""
    pieces: List[Tuple[float, float]] = []
    for a, b in regions:
        while b - a > max_len:
            pieces.append((a, a + max_len))
            a += max_len
        pieces.append((a, b))
    chunks: List[List[float]] = []
    for a, b in pieces:
        if chunks and a - chunks[-1][1] <= max_gap and b - chunks[-1][0] <= max_len:
            chunks[-1][1] = max(chunks[-1][1], b)
        else:
            chunks.append([a, b])
    out = []
    for a, b in chunks:
        out.append((max(0.0, a - pad), min(total, b + pad)))
    return out


LOUD_DB = -32.0             # dBFS: louder than this is "something is going on"
LOUD_MIN = 0.8              # s


def loud_gaps(audio: np.ndarray, regions: List[Tuple[float, float]],
              min_len: float = LOUD_MIN, level_db: float = LOUD_DB,
              margin: float = 0.3) -> List[Tuple[float, float]]:
    """Loud stretches the VAD did NOT call speech. In dramas that is often
    shouting, crying or dialogue under loud music - the speech detector gives
    up there (probability ~0.1) while Whisper still understands it. These
    parts are transcribed too, with a stricter check of what comes back."""
    hop = int(0.05 * SR)
    n = len(audio) // hop
    if n == 0:
        return []
    frames = audio[:n * hop].reshape(n, hop).astype(np.float32)
    db = 10.0 * np.log10(np.mean(frames * frames, axis=1) + 1e-10)
    loud = db > level_db
    covered = np.zeros(n, dtype=bool)
    for a, b in regions:
        covered[max(0, int((a - margin) / 0.05)):min(n, int((b + margin) / 0.05) + 1)] = True
    want = loud & ~covered
    # close short dips (a breath between two words)
    out: List[Tuple[float, float]] = []
    i = 0
    while i < n:
        if not want[i]:
            i += 1
            continue
        j = i
        quiet = 0
        while j < n and (want[j] or (quiet < 8 and not covered[j])):
            quiet = 0 if want[j] else quiet + 1
            j += 1
        j -= quiet
        a, b = i * 0.05, j * 0.05
        if b - a >= min_len:
            out.append((a, b))
        i = max(j, i + 1)
    return out


def _trust(s, strict: bool) -> bool:
    """Is a Whisper line real speech? Lines from loud parts the VAD did not
    call speech must be clearly understood (music gives low-confidence text)."""
    nsp = float(getattr(s, "no_speech_prob", 0.0) or 0.0)
    lp = float(getattr(s, "avg_logprob", 0.0) or 0.0)
    cr = float(getattr(s, "compression_ratio", 1.0) or 1.0)
    if not strict:
        return not (nsp > 0.7 and lp < -1.0)
    return nsp < 0.6 and lp > -0.9 and cr < 2.2


UNSURE_LOGPROB = -0.8       # Smart Review: Whisper is not sure of the words


def _unsure(s) -> bool:
    lp = float(getattr(s, "avg_logprob", 0.0) or 0.0)
    nsp = float(getattr(s, "no_speech_prob", 0.0) or 0.0)
    return lp < UNSURE_LOGPROB or nsp > 0.5


# the same invented lines in traditional characters ("請不吝點贊訂閱轉發打賞支持明鏡與點點
# 欄目" was voiced as a Khmer line at 0:00, EP002, 3/11)
_TRAD = str.maketrans("請點贊訂閱轉發賞鏡與謝觀組製欄開邊個鈴鐺歡報頻道",
                      "请点赞订阅转发赏镜与谢观组制栏开边个铃铛欢报频道")


def is_hallucination(text: str) -> bool:
    t = text.strip().lower().translate(_TRAD)
    if not t or all(not ch.isalnum() for ch in t):
        return True
    return any(h in t for h in HALLUCINATIONS)


# a line that is only a sound ("yeah", "huh", "啊", "呃") is not worth a voice:
# Whisper hears it in grunts and breaths, and it came out as "យើស" / "ហឺស".
# (嗯 stays: it often means "yes".)
FILLER_WORDS = {
    "huh", "uh", "uhh", "um", "umm", "hmm", "hm", "mm", "mmm", "mhm", "ah", "ahh", "aah",
    "oh", "ohh", "ooh", "eh", "ha", "hah", "haha", "hahaha", "whoa", "wow", "ugh", "oops",
    "yeah", "yea", "yep", "aw", "aww", "heh", "hey",
}
FILLER_CHARS = set("啊呃哦噢哎唉哈呵嘿哼呀嗷喔欸诶哇")


def is_filler(text: str) -> bool:
    """Only interjections (yeah / huh / 啊 / 呃 ...), nothing that needs a voice."""
    t = (text or "").strip().lower()
    for ch in ".,!?;:…~-–—'\"“”‘’（）()[]【】、，。！？；：·":
        t = t.replace(ch, " ")
    words = t.split()
    if not words:
        return False
    for w in words:
        if w in FILLER_WORDS:
            continue
        if all(c in FILLER_CHARS for c in w):
            continue
        return False
    return True


def _repeats(text: str) -> bool:
    """'哈哈哈哈哈哈哈哈哈哈哈哈' / the same phrase 5+ times: a Whisper loop."""
    t = text.replace(" ", "")
    if len(t) < 12:
        return False
    for n in range(1, 9):
        unit = t[:n]
        if unit * (len(t) // n) == t[:n * (len(t) // n)] and len(t) // n >= 5:
            return True
    return False


def _detect_language(model, audio: np.ndarray, chunks, report) -> str:
    """Vote over up to 6 of the longest chunks of the first part of the video
    (an opening song alone can fool Whisper's 30-second guess)."""
    early = chunks[:40]
    pick = sorted(early, key=lambda c: c[1] - c[0], reverse=True)[:6]
    votes: Dict[str, float] = {}
    for a, b in pick:
        piece = audio[int(a * SR):int(b * SR)]
        try:
            _segs, info = model.transcribe(piece, language=None, beam_size=1)
        except Exception:
            continue
        w = float(getattr(info, "language_probability", 1.0) or 1.0) * (b - a)
        votes[info.language] = votes.get(info.language, 0.0) + w
    if not votes:
        return ""
    lang = max(votes, key=votes.get)
    report(4, f"Language: {lang}")
    return lang


_users = 0                  # videos using the Whisper model right now
_users_lock = threading.Lock()


def _done_with_whisper(size: str) -> None:
    """2.6.13: on a graphics card under 7 GB, the Whisper model (large-v3
    ~3 GB) lets the card go when the last video stops using it - kept, it
    filled a 4 GB card (VRAM 3.8 / 4.0: the OCR fell back to the CPU and the
    video in the preview / player stood still, 11/11). It loads again in a
    few seconds when the next video needs it."""
    global _users
    with _users_lock:
        _users = max(0, _users - 1)
        last = _users == 0
    if not last or not device_label(size).startswith("GPU"):
        return
    try:
        from .resources import small_gpu

        if small_gpu() and release_models():
            print("[whisper] model let go - the graphics card has its memory back")
    except Exception as e:
        print(f"[whisper] could not let the model go: {e}")


def transcribe_audio(*args, **kwargs) -> Tuple[List[Segment], str]:
    engine = kwargs.get("engine", args[8] if len(args) > 8 else "whisper")
    if engine != "whisper":
        return _transcribe_audio(*args, **kwargs)
    size = kwargs.get("model_size", args[1] if len(args) > 1 else "small")
    global _users
    with _users_lock:
        _users += 1
    try:
        return _transcribe_audio(*args, **kwargs)
    finally:
        _done_with_whisper(size)


def _transcribe_audio(
    audio_path: str,
    model_size: str = "small",
    language: str = "auto",
    progress: Optional[Callable[[int, str], None]] = None,
    should_stop: Optional[Callable[[], bool]] = None,
    start_at: float = 0.0,
    on_segment: Optional[Callable[[Segment], None]] = None,
    on_language: Optional[Callable[[str], None]] = None,
    engine: str = "whisper",
) -> Tuple[List[Segment], str]:
    """Transcribe a WAV file (from start_at seconds to the end).
    engine "whisper" (offline), "gemini" (Google API key), "paraformer" /
    "sensevoice" (FunASR, with the VoxCPM Python - core/funasr_stt.py).

    Returns (segments, detected_language_code). Times are in seconds from
    the start of the file. on_segment(seg) is called for every line as soon
    as it is recognised.
    """
    def report(p, msg):
        if progress:
            progress(int(p), msg)

    if engine in ("paraformer", "sensevoice", "funasr-nano"):     # FunASR (VoxCPM Python)
        from . import funasr_stt

        kept = []

        def keep(seg):                  # the same filter as Whisper's lines
            if is_hallucination(seg.text) or _repeats(seg.text):
                return
            kept.append(seg)
            if on_segment:
                on_segment(seg)
        _all, lang_found, _dev = funasr_stt.transcribe(
            audio_path, engine, report, should_stop, start_at, keep, language)
        segs = kept
        if on_language and lang_found:
            on_language(lang_found)
        return segs, lang_found
    if engine == "gemini":
        model, device = None, "Gemini"
    else:
        report(0, f"Loading Whisper model '{model_size}' (first time downloads it)...")
        model = _load_model(model_size)
        device = device_label(model_size)

    lang = None if language in ("", "auto") else language
    # Decode the WAV ourselves: faster-whisper's own decoder uses PyAV, whose
    # API changes between versions (e.g. av 19 removed "metadata_errors").
    audio, sr = read_wav(audio_path)
    if sr != SR:
        n_new = int(len(audio) * SR / sr)
        audio = np.interp(np.linspace(0, len(audio), n_new, endpoint=False),
                          np.arange(len(audio)), audio).astype(np.float32)
    total = max(len(audio) / float(SR), 0.001)
    offset = max(0.0, min(float(start_at), total))
    if offset > 0:
        audio = audio[int(offset * SR):]
    if len(audio) < 1600:      # nothing (left) to transcribe
        report(100, "Transcription done")
        return [], lang or ""

    where = "Continuing" if offset > 0 else "Transcribing"
    report(2, f"Finding speech ({_mmss(total - offset)} of audio)...")
    dur = len(audio) / float(SR)
    regions = speech_regions(audio)
    chunks = make_chunks(regions, dur)
    extra = make_chunks(loud_gaps(audio, regions), dur, max_gap=0.5, pad=0.15) if regions else []
    strict = {c for c in extra}
    chunks = sorted(set(chunks) | strict)
    if engine == "gemini":
        return _transcribe_gemini(audio, regions + loud_gaps(audio, regions) if regions
                                  else [(0.0, dur)], dur, lang, offset, total, report,
                                  should_stop, on_segment, on_language)
    if not chunks:
        return _transcribe_whole(model, audio, lang, offset, total, device, where,
                                 report, should_stop, on_segment, on_language)

    if lang is None:
        lang = _detect_language(model, audio, [c for c in chunks if c not in strict] or chunks,
                                report) or None
    if on_language and lang:
        on_language(lang)

    report(5, f"{where} speech on {device.split(' - ')[0]} ({len(chunks)} parts, "
              f"{len(strict)} loud parts with music / shouting)...")
    segments: List[Segment] = []
    last_end = 0.0
    for k, (a, b) in enumerate(chunks):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        piece = audio[int(a * SR):int(b * SR)]
        try:
            seg_iter, _info = model.transcribe(
                piece, language=lang, beam_size=5, vad_filter=False,
                condition_on_previous_text=False)
            found = list(seg_iter)
        except Exception as e:                  # one bad chunk must not stop a film
            print(f"[transcribe] part {k + 1} failed: {e}")
            found = []
        for s in found:
            text = s.text.strip()
            if is_hallucination(text) or _repeats(text):
                continue
            if not _trust(s, (a, b) in strict):
                continue
            start = max(a + max(0.0, s.start), last_end)
            end = min(b, a + s.end)
            if end - start < 0.15:
                continue
            last_end = end
            seg = Segment(id=new_id(), start=round(start + offset, 3),
                          end=round(end + offset, 3), text=text,
                          check="unsure" if _unsure(s) else "")
            segments.append(seg)
            if on_segment:
                on_segment(seg)
        done = b + offset
        report(5 + 95 * min(1.0, done / total),
               f"Transcribed {len(segments)} lines ({_mmss(done)} / {_mmss(total)})")

    report(100, f"Transcription done: {len(segments)} lines, language = {lang}")
    return segments, lang or ""


GEMINI_WINDOW = 60.0        # s of audio per Gemini request


def _transcribe_gemini(audio, regions, dur, lang, offset, total, report, should_stop,
                       on_segment, on_language):
    """Speech-to-text with Gemini: the speech parts in windows of up to a
    minute (fewer requests than Whisper's 28 s chunks, still short enough for
    good timestamps)."""
    from . import gemini

    if not gemini.configured():
        raise gemini.GeminiError("Speech engine 'Gemini' needs an API key – "
                                 "Settings › AI engines & API keys")
    windows = make_chunks(sorted(regions), dur, max_len=GEMINI_WINDOW, max_gap=8.0, pad=0.3)
    report(5, f"Transcribing with Gemini ({gemini.model()}, {len(windows)} parts)...")
    segments: List[Segment] = []
    last_end = 0.0
    told = False
    votes: Dict[str, int] = {}
    for k, (a, b) in enumerate(windows):
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        piece = audio[int(a * SR):int(b * SR)]
        try:
            lines, heard = gemini.transcribe_piece(piece, lang, should_stop)
        except InterruptedError:
            raise
        except gemini.QuotaError:
            raise
        except gemini.GeminiError as e:
            if k == 0:
                raise
            print(f"[gemini stt] part {k + 1} failed: {e}")
            lines, heard = [], ""
        if heard and lang is None:
            votes[heard] = votes.get(heard, 0) + 1
            if sum(votes.values()) >= 3 or k == len(windows) - 1:
                lang = max(votes, key=votes.get)
        if lang and not told and on_language:
            on_language(lang)
            told = True
        for s0, s1, text in lines:
            if is_hallucination(text) or _repeats(text):
                continue
            start = max(a + s0, last_end)
            end = min(b, a + s1)
            if end - start < 0.15:
                continue
            last_end = end
            seg = Segment(id=new_id(), start=round(start + offset, 3),
                          end=round(end + offset, 3), text=text)
            segments.append(seg)
            if on_segment:
                on_segment(seg)
        done = b + offset
        report(5 + 95 * min(1.0, done / total),
               f"Gemini transcribed {len(segments)} lines ({_mmss(done)} / {_mmss(total)})")
    if votes and not told and on_language:
        lang = max(votes, key=votes.get)
        on_language(lang)
    report(100, f"Transcription done: {len(segments)} lines (Gemini), language = {lang}")
    return segments, lang or ""


def _transcribe_whole(model, audio, lang, offset, total, device, where,
                      report, should_stop, on_segment, on_language):
    """Fallback without our own VAD (old faster-whisper): one pass over the file."""
    report(3, f"{where} speech on {device.split(' - ')[0]}...")
    seg_iter, info = model.transcribe(
        audio,
        language=lang,
        vad_filter=True,
        vad_parameters={"min_silence_duration_ms": 400},
        beam_size=5,
        condition_on_previous_text=False,       # no runaway repeats / skipped minutes
    )
    del audio
    if on_language:
        on_language(info.language)
    segments: List[Segment] = []
    for s in seg_iter:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        text = s.text.strip()
        if is_hallucination(text) or _repeats(text):
            continue
        seg = Segment(id=new_id(), start=round(s.start + offset, 3),
                      end=round(s.end + offset, 3), text=text,
                      check="unsure" if _unsure(s) else "")
        segments.append(seg)
        if on_segment:
            on_segment(seg)
        report(3 + 97 * min(1.0, seg.end / total),
               f"Transcribed {len(segments)} lines ({_mmss(seg.end)} / {_mmss(total)})")
    report(100, f"Transcription done: {len(segments)} lines, language = {info.language}")
    return segments, info.language


def _mmss(t: float) -> str:
    t = int(t)
    if t >= 3600:
        return f"{t // 3600}:{t % 3600 // 60:02d}:{t % 60:02d}"
    return f"{t // 60}:{t % 60:02d}"
