"""
funasr_worker.py - speech-to-text with FunASR (Alibaba, MIT) for SARIKA VOXDUB PRO.

Runs with the VoxCPM Python (venv-voxcpm already has torch + funasr +
modelscope). The app starts it once per transcription:

    python -u funasr_worker.py            (one JSON request on stdin)
    -> {"wav": "C:/.../audio.wav", "model": "paraformer" | "sensevoice" | "funasr-nano",
        "device": "auto" | "cuda" | "cpu", "start_at": 0.0}

and reads one JSON object per line from stdout:

    {"p": 40, "msg": "..."}                     progress
    {"seg": {"start": 1.2, "end": 3.4, "text": "...", "lang": "zh"}}
    {"ok": true, "lang": "zh", "device": "cuda", "count": 120}   at the end
    {"ok": false, "error": "..."}

paraformer: Paraformer-zh + fsmn-vad + ct-punc (Mandarin, sentence times).
sensevoice: fsmn-vad cuts the speech, SenseVoice-Small reads every part
            (zh / yue / en / ja / ko).
funasr-nano: fsmn-vad cuts the speech, Fun-ASR-Nano-2512 (Tongyi 2025, 0.8 B,
            Apache-2.0; zh / en / ja + Chinese dialects) reads every part.
The models download from ModelScope the first time (about 1 GB), then cached.
"""

import json
import os
import re
import sys
import traceback

# this file sits in the app's core/ folder: keep that folder off the path
_HERE = os.path.normcase(os.path.dirname(os.path.abspath(__file__)))
sys.path[:] = [p for p in sys.path
               if os.path.normcase(os.path.abspath(p or os.getcwd())) != _HERE]

SR = 16000
MAX_PART_MS = 6000           # SenseVoice: one subtitle line is at most ~6 s
                             # (12 s put 4-5 sentences of 2 people in one line)
TAG = re.compile(r"<\|[^|]*\|>")
LANGS = {"zh", "yue", "en", "ja", "ko"}


def say(obj) -> None:
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _device(want: str) -> str:
    if want in ("cpu", "cuda"):
        return want
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"


def _load_audio(path: str):
    import numpy as np
    import soundfile as sf

    data, sr = sf.read(path, dtype="float32", always_2d=True)
    data = data.mean(axis=1)
    if sr != SR:
        n = int(len(data) * SR / sr)
        data = np.interp(np.linspace(0, len(data), n, endpoint=False),
                         np.arange(len(data)), data).astype("float32")
    return data


CJK = "\u3000-\u303f\u3400-\u9fff\uff00-\uffef"


def _clean(text: str) -> str:
    t = re.sub(r"\s+", " ", TAG.sub("", text or "")).strip()
    return re.sub(f"(?<=[{CJK}]) (?=[{CJK}])", "", t)      # 你 好 -> 你好


_MODELS = {}                # (name, device) -> model: kept while the worker serves (2.6.8)


def _model(name, dev, make):
    key = (name, dev)
    if key not in _MODELS:
        _MODELS[key] = make()
    return _MODELS[key]


def run_paraformer(req, dev):
    from funasr import AutoModel

    if ("paraformer", dev) not in _MODELS:
        say({"p": 5, "msg": "Loading Paraformer-zh (first time downloads ~1 GB)..."})
    model = _model("paraformer", dev, lambda: AutoModel(
        model="paraformer-zh", vad_model="fsmn-vad", punc_model="ct-punc",
        vad_kwargs={"max_single_segment_time": 20000},
        device=dev, disable_update=True, disable_pbar=True, log_level="ERROR"))
    say({"p": 20, "msg": f"Paraformer-zh reading the speech on {dev}..."})
    res = model.generate(input=req["wav"], batch_size_s=int(req.get("batch_s") or 300), sentence_timestamp=True)
    count = 0
    start_at = float(req.get("start_at") or 0.0)
    for item in res or []:
        for s in item.get("sentence_info") or []:
            for text, a, b in split_sentence(_clean(s.get("text", "")),
                                             s.get("timestamp") or [],
                                             float(s.get("start", 0)), float(s.get("end", 0))):
                if not has_words(text) or b <= start_at or b - a < 0.15:
                    continue
                say({"seg": {"start": round(a, 3), "end": round(b, 3), "text": text,
                             "lang": "zh"}})
                count += 1
    return "zh", count


GAP_MS = 700                 # a pause this long inside a "sentence" starts a new line
PUNCT = set("，。？！、；：,.?!;:…“”\"'‘’（）()《》-— ")


def split_sentence(text, stamps, start_ms, end_ms):
    """One Paraformer sentence -> subtitle lines [(text, start_s, end_s)].
    The sentence times can stretch over a long music pause ("烛灭即退" shown
    for 20 s): the times of the characters cut it at every pause."""
    units = [i for i, ch in enumerate(text) if ch not in PUNCT]
    ok = stamps and len(units) == len(stamps) and all(len(t) == 2 for t in stamps)
    if not ok:
        return [(text, start_ms / 1000.0, end_ms / 1000.0)] if text else []
    lines, first = [], 0
    for k in range(1, len(stamps) + 1):
        if k == len(stamps) or stamps[k][0] - stamps[k - 1][1] > GAP_MS:
            a_i = units[first]
            b_i = units[k] if k < len(stamps) else len(text)
            piece = text[a_i:b_i].strip()
            if k < len(stamps):                 # punctuation before the pause stays here
                piece = piece.rstrip()
            lines.append((piece, stamps[first][0] / 1000.0, stamps[k - 1][1] / 1000.0))
            first = k
    return [l for l in lines if l[0]]


def run_sensevoice(req, dev):
    from funasr import AutoModel

    if ("sensevoice", dev) not in _MODELS:
        say({"p": 5, "msg": "Loading SenseVoice-Small (first time downloads ~1 GB)..."})
    vad, asr = _model("sensevoice", dev, lambda: (
        AutoModel(model="fsmn-vad", max_single_segment_time=MAX_PART_MS,
                  device=dev, disable_update=True, disable_pbar=True, log_level="ERROR"),
        AutoModel(model="iic/SenseVoiceSmall", device=dev, disable_update=True,
                  disable_pbar=True, log_level="ERROR")))
    audio = _load_audio(req["wav"])
    say({"p": 15, "msg": f"Finding speech on {dev}..."})
    parts = []
    for item in vad.generate(input=audio) or []:
        parts += [p for p in item.get("value") or [] if len(p) == 2]
    start_at = float(req.get("start_at") or 0.0)
    parts = [(a, b) for a, b in parts if b / 1000.0 > start_at]
    langs = {}
    count = 0
    found = []
    for k, (a, b) in enumerate(parts):
        piece = audio[int(a * SR / 1000):int(b * SR / 1000)]
        if len(piece) < SR // 5:
            continue
        out = asr.generate(input=piece, language=req.get("language") or "auto",
                           use_itn=True, batch_size=1)
        raw = (out[0].get("text", "") if out else "")
        m = re.search(r"<\|(zh|yue|en|ja|ko)\|>", raw)
        lang = m.group(1) if m else ""
        text = _clean(raw)
        if has_words(text):
            if lang:
                langs[lang] = langs.get(lang, 0) + 1
            found.append((a, b, text, lang))
        if k % 5 == 0:
            say({"p": 15 + int(85 * (k + 1) / max(1, len(parts))),
                 "msg": f"SenseVoice: {k + 1} / {len(parts)} parts"})
    best = max(langs, key=langs.get) if langs else "zh"
    for a, b, text, lang in found:
        # music / a shout heard as "Yes。" "Okay。" "う。" in a Chinese film: drop it
        if lang and lang != best and not (best in ("zh", "yue") and lang in ("zh", "yue")):
            continue
        say({"seg": {"start": round(a / 1000.0, 3), "end": round(b / 1000.0, 3),
                     "text": text, "lang": lang}})
        count += 1
    return ("zh" if best == "yue" else best), count


NANO_ID = "FunAudioLLM/Fun-ASR-Nano-2512"
NANO_LANG = {"zh": "中文", "en": "英文", "ja": "日文"}


def _half_llm(asr, dev) -> None:
    """2.6.13: the Nano's small LLM in float16 on the GPU (~1.2 GB less): its
    config says fp32, which fills a 4 GB card."""
    m = getattr(asr, "model", None)
    if not str(dev).startswith("cuda") or m is None or getattr(m, "llm", None) is None:
        return
    if getattr(m, "llm_dtype", "fp32") == "fp32":
        try:
            import torch

            m.llm = m.llm.to(torch.float16)
            m.llm_dtype = "fp16"
        except Exception as e:
            say({"msg": f"Fun-ASR-Nano stays in fp32 ({e})"})


END = "。！？!?…"
KANA_ONLY = re.compile(r"^[\u3040-\u30ff\s\W]+$")   # only kana (+ punctuation), no Han
SOFT = "，,；;：:"
NANO_LINE_S = 2.0            # a line with a comma is cut at it after ~2 s (as Paraformer's)


def nano_lines(text, stamps, a_s, b_s):
    """2.6.13: one VAD part (up to 6 s) often holds 2-4 sentences - one long
    line with them all is hard to read and to voice (EP001: 23 lines where
    the others had 38). Cut it into sentences: at 。！？, at a pause in the
    speech, and at a comma when the line is long. `stamps` are the Nano's
    token times inside the part ({"token", "start_time", "end_time"}, s); without
    them the sentences share the part's time by their length."""
    text = (text or "").strip()
    toks = [t for t in (stamps or []) if isinstance(t, dict) and "token" in t]
    if toks and _clean("".join(str(t["token"]) for t in toks)) == _clean(text):
        lines, cur, t0, last_end = [], "", None, None
        for t in toks:
            tok = str(t["token"])
            st, en = float(t.get("start_time", 0)), float(t.get("end_time", 0))
            if cur.strip() and last_end is not None and st - last_end > GAP_MS / 1000.0 \
                    and _has_words(tok):
                lines.append((cur, t0, last_end))
                cur, t0 = "", None
            if t0 is None and _has_words(tok):
                t0 = st
            cur += tok
            if _has_words(tok):
                last_end = en
            stop = any(c in END for c in tok) or \
                (any(c in SOFT for c in tok) and t0 is not None and en - t0 >= NANO_LINE_S)
            if stop and t0 is not None:
                lines.append((cur, t0, last_end))
                cur, t0 = "", None
        if cur.strip() and t0 is not None:
            lines.append((cur, t0, last_end))
        out = [(_clean(x), a_s + s0, a_s + max(s0, e0)) for x, s0, e0 in lines]
        out = [o for o in out if has_words(o[0])]
        if out:
            # the last line keeps the part's end (the voice may run a little longer)
            return out[:-1] + [(out[-1][0], out[-1][1], max(out[-1][2], b_s))]
    # no times: sentences by their length
    parts = [x for x in re.split(f"(?<=[{re.escape(END)}])", text) if has_words(x)]
    if len(parts) <= 1:
        return [(_clean(text), a_s, b_s)] if has_words(text) else []
    total = sum(len(x) for x in parts)
    out, t = [], a_s
    for x in parts:
        d = (b_s - a_s) * len(x) / total
        out.append((_clean(x), t, t + d))
        t += d
    return out


def _has_words(tok):
    return bool(WORD.search(tok or ""))


def run_nano(req, dev):
    import tempfile

    import soundfile as sf
    from funasr import AutoModel

    if ("funasr-nano", dev) not in _MODELS:
        say({"p": 5, "msg": "Loading Fun-ASR-Nano (first time downloads ~2 GB)..."})

    def make():
        vad = AutoModel(model="fsmn-vad", max_single_segment_time=MAX_PART_MS,
                        device=dev, disable_update=True, disable_pbar=True, log_level="ERROR")
        asr = AutoModel(model=NANO_ID, device=dev, disable_update=True,
                        disable_pbar=True, log_level="ERROR")
        _half_llm(asr, dev)
        return vad, asr
    vad, asr = _model("funasr-nano", dev, make)
    audio = _load_audio(req["wav"])
    say({"p": 15, "msg": f"Finding speech on {dev}..."})
    parts = []
    for item in vad.generate(input=audio) or []:
        parts += [p for p in item.get("value") or [] if len(p) == 2]
    start_at = float(req.get("start_at") or 0.0)
    parts = [(a, b) for a, b in parts if b / 1000.0 > start_at]
    lang = NANO_LANG.get((req.get("language") or "").split("-")[0])
    count = 0
    tmp = tempfile.mkdtemp(prefix="voxdub_nano_")
    try:
        for k, (a, b) in enumerate(parts):
            piece = audio[int(a * SR / 1000):int(b * SR / 1000)]
            if len(piece) < SR // 5:
                continue
            wav = os.path.join(tmp, "part.wav")
            sf.write(wav, piece, SR)
            kw = {"batch_size": 1, "itn": True}
            if lang:
                kw["language"] = lang
            out = asr.generate(input=[wav], cache={}, **kw)
            res = out[0] if out else {}
            for line, s0, e0 in nano_lines(res.get("text", ""), res.get("timestamps"),
                                           a / 1000.0, b / 1000.0):
                if (not lang or lang == "中文") and KANA_ONLY.match(line):
                    continue            # a sigh heard as Japanese "はあ" in a Chinese film
                say({"seg": {"start": round(s0, 3), "end": round(e0, 3),
                             "text": line, "lang": ""}})
                count += 1
            if k % 5 == 0:
                say({"p": 15 + int(85 * (k + 1) / max(1, len(parts))),
                     "msg": f"Fun-ASR-Nano: {k + 1} / {len(parts)} parts"})
    finally:
        import shutil

        shutil.rmtree(tmp, ignore_errors=True)
    return "zh" if not lang or lang == "中文" else req.get("language"), count


WORD = re.compile(r"[^\W_]", re.UNICODE)


def has_words(text: str) -> bool:
    """Not only punctuation ("，" alone came back as a line)."""
    return bool(WORD.search(text or ""))


def handle(req) -> bool:
    try:
        dev = _device(req.get("device", "auto"))
        if req.get("model") == "sensevoice":
            lang, count = run_sensevoice(req, dev)
        elif req.get("model") == "funasr-nano":
            lang, count = run_nano(req, dev)
        else:
            lang, count = run_paraformer(req, dev)
        say({"ok": True, "lang": lang, "device": dev, "count": count})
        return True
    except Exception as e:
        traceback.print_exc(file=sys.stderr)
        say({"ok": False, "error": f"{type(e).__name__}: {e}"[:400]})
        return False


def main() -> int:
    if "--serve" not in sys.argv:              # one request, then exit (as before)
        return 0 if handle(json.loads(sys.stdin.readline() or "{}")) else 1
    # 2.6.8 --serve: one request per line, the models stay loaded between them
    # (a Batch no longer loads Paraformer again for every episode). The app
    # closes stdin (or ends the process) when it is idle or quits.
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            say({"ok": False, "error": "bad request"})
            continue
        handle(req)
    return 0


if __name__ == "__main__":
    sys.exit(main())
