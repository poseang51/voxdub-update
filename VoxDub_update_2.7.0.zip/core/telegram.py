"""
telegram.py - 2.7: a message on your phone when the Batch queue works at night
(each episode done / failed, and the end of the queue) - through YOUR OWN
Telegram bot (made in 1 minute with @BotFather).

The bot token is a secret: kept in the settings of this computer only, never
shown again (masked), never in a project or a log.
"""

import threading
from typing import Callable, Optional, Tuple

from . import settings

API = "https://api.telegram.org/bot{token}/{method}"


def token() -> str:
    return (settings.get("telegram_token", "") or "").strip()


def chat() -> str:
    return str(settings.get("telegram_chat", "") or "").strip()


def ready() -> bool:
    return bool(token() and chat())


def _call(method: str, tok: str, data: Optional[dict] = None, timeout: float = 20):
    import requests

    r = requests.post(API.format(token=tok, method=method), json=data or {}, timeout=timeout)
    try:
        body = r.json()
    except ValueError:
        body = {"ok": False, "description": r.text[:200]}
    if not body.get("ok"):
        raise RuntimeError(f"Telegram: {body.get('description') or r.status_code}")
    return body.get("result")


def _clean(err: Exception, tok: str) -> str:
    return str(err).replace(tok, settings.mask(tok)) if tok else str(err)


def find_chat(tok: str) -> Tuple[str, str]:
    """(chat id, name) of the last person who wrote to the bot (press Start
    in the bot first). ('', reason) when nobody did yet."""
    try:
        ups = _call("getUpdates", tok) or []
    except Exception as e:
        return "", _clean(e, tok)
    for u in reversed(ups):
        m = u.get("message") or u.get("my_chat_member") or {}
        c = m.get("chat") or {}
        if c.get("id") is not None:
            name = c.get("title") or " ".join(x for x in (c.get("first_name"),
                                                         c.get("last_name")) if x)
            return str(c["id"]), name or str(c["id"])
    return "", "Nobody wrote to the bot yet – open the bot in Telegram and press Start"


def send_now(text: str, tok: str = "", chat_id: str = "") -> str:
    """'' when sent, else the reason (the token never in it)."""
    tok, chat_id = tok or token(), chat_id or chat()
    if not (tok and chat_id):
        return "Telegram is not set up"
    try:
        _call("sendMessage", tok, {"chat_id": chat_id, "text": text[:4000],
                                   "disable_web_page_preview": True})
        return ""
    except Exception as e:
        return _clean(e, tok)


def send(text: str, done: Optional[Callable[[str], None]] = None):
    """In the background - the queue never waits for Telegram, a failure
    is only written to the log."""
    if not ready():
        return

    def work():
        why = send_now(text)
        if why:
            print(f"[telegram] not sent: {why}")
        if done:
            done(why)
    threading.Thread(target=work, daemon=True).start()
