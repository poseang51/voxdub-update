"""SARIKA VOXDUB PRO processing core (no Qt imports here)."""

__version__ = "2.7.0"          # MAJOR.MINOR.PATCH - also add it to core/changelog.py
