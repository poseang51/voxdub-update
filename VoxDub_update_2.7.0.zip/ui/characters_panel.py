"""
characters_panel.py - the "👥 Characters" tab.

Every line belongs to a character (A, B, C ...) found by core/speakers.py, and
one character keeps ONE voice all through the video. Here the user checks and
corrects them: name, male / female, age (child / young / adult / elder), the
voice, and for VoxCPM2 where the cloned voice comes from (this video, a
recording of their own, or the default male / female voice).
"""

from typing import Optional

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)

from core import speakers
from core.project import Project
from core.tts import AUTO_VOICE, voices_for

AGE_NAME = dict(speakers.AGES)
SIGN = {"male": "♂", "female": "♀"}
PITCH_AUTO = "auto"
_icons = {}


def dot_icon(color: str, size: int = 12) -> QIcon:
    """A round colour dot: the colour of a character, the same everywhere."""
    key = (color, size)
    if key not in _icons:
        pm = QPixmap(size, size)
        pm.fill(Qt.GlobalColor.transparent)
        qp = QPainter(pm)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        qp.setPen(Qt.PenStyle.NoPen)
        qp.setBrush(QColor(color))
        qp.drawEllipse(1, 1, size - 2, size - 2)
        qp.end()
        _icons[key] = QIcon(pm)
    return _icons[key]


class CharactersPanel(QWidget):
    findRequested = Signal()                 # run "find characters" (background task)
    aboutToChange = Signal()                 # push undo before an edit
    changed = Signal()                       # cast / line speakers changed
    listenRequested = Signal(str)            # character label: hear the original voice
    seekSourceRequested = Signal(float)
    revoiceRequested = Signal()              # voice the lines whose voice changed

    def __init__(self, parent=None):
        super().__init__(parent)
        self.project: Optional[Project] = None
        self._loading = False
        lay = QVBoxLayout(self)
        lay.setContentsMargins(6, 6, 6, 6)

        top = QHBoxLayout()
        self.btn_find = QPushButton("🔍 Find characters")
        self.btn_find.setToolTip("Listen to every line and group them by voice: each group is "
                                 "one character, with one voice all through the video.\n"
                                 "Names / voices you set are kept.")
        self.btn_find.clicked.connect(self.findRequested.emit)
        self.lbl_count = QLabel("")
        self.lbl_count.setObjectName("MutedLabel")
        from core import gender_ai, settings as _settings

        self.chk_ai = QCheckBox("🤖 AI man/woman")
        self.chk_ai.setChecked(gender_ai.enabled())
        self.chk_ai.setToolTip(
            "Find characters decides man / woman with an AI model (wav2vec2, Hugging Face)\n"
            "that hears the whole voice, not only how high it is - far fewer mistakes with\n"
            "low women's voices, high men's voices and shouting.\n"
            "~95 MB, downloaded once the first time. Off = pitch only (as before).")
        self.chk_ai.toggled.connect(lambda on: _settings.set(gender_ai.SETTING, bool(on)))
        top.addWidget(self.btn_find)
        top.addWidget(self.chk_ai)
        top.addWidget(self.lbl_count, 1)
        lay.addLayout(top)
        intro = QLabel("Every person in the video is one character, and a character keeps "
                       "ONE voice all through. Click a character to rename it or change "
                       "its voice.")
        intro.setObjectName("MutedLabel")
        intro.setWordWrap(True)
        lay.addWidget(intro)
        self.lbl_series = QLabel("")
        self.lbl_series.setWordWrap(True)
        self.lbl_series.setStyleSheet("color: #2fd59a;")
        self.lbl_series.setVisible(False)
        lay.addWidget(self.lbl_series)

        self.tbl = QTableWidget(0, 4)
        self.tbl.setHorizontalHeaderLabels(["Character", "Who", "Speaks", "Voice"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.verticalHeader().setDefaultSectionSize(30)
        self.tbl.setIconSize(QSize(12, 12))
        self.tbl.setShowGrid(False)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.tbl.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        h = self.tbl.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl.itemSelectionChanged.connect(self._show_selected)
        self.tbl.cellDoubleClicked.connect(lambda *_: self._go_first_line())
        lay.addWidget(self.tbl, 1)

        # ---- the selected character
        self.box = QGroupBox("Character")
        f = QFormLayout(self.box)
        f.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self.ed_name = QLineEdit()
        self.ed_name.setPlaceholderText("Type a name, e.g. Mother, Ming, Grandpa")
        self.ed_name.editingFinished.connect(lambda: self._set("name", self.ed_name.text().strip()))
        f.addRow("Name", self.ed_name)

        self.cmb_gender = QComboBox()
        for k, v in speakers.GENDERS:
            self.cmb_gender.addItem(f"{SIGN[k]} {v}", k)
        self.cmb_gender.activated.connect(
            lambda *_: self._set("gender", self.cmb_gender.currentData()))
        self.cmb_age = QComboBox()
        for k, v in speakers.AGES:
            self.cmb_age.addItem(v, k)
        self.cmb_age.activated.connect(lambda *_: self._set("age", self.cmb_age.currentData()))
        row = QHBoxLayout()
        row.addWidget(self.cmb_gender, 1)
        row.addWidget(self.cmb_age, 1)
        f.addRow("This is a", row)

        # 2.7: rank -> the forms of address in the translation (Gemini / Router)
        from core import register

        self.cmb_rank = QComboBox()
        for k, v in register.RANKS:
            self.cmb_rank.addItem(v, k)
        self.cmb_rank.setToolTip(
            "Who this character is in the story. Gemini / Gemini Router choose the Khmer "
            "words of address from it: រាជសព្ទ for the king and the royals (ព្រះករុណា, "
            "ទូលបង្គំ, យាង, សោយ …), ខ្ញុំម្ចាស់ from servants, អាត្មា for a monk.\n"
            "Auto: the AI tells it from the lines (shown here after the translation). "
            "Kept for the next episodes of a series. Translate again to use a change.")
        self.cmb_rank.activated.connect(lambda *_: self._set("rank", self.cmb_rank.currentData()))
        f.addRow("Rank", self.cmb_rank)

        self.cmb_voice = QComboBox()
        self.cmb_voice.activated.connect(lambda *_: self._set("voice",
                                                               self.cmb_voice.currentData()))
        f.addRow("Voice", self.cmb_voice)

        self.cmb_pitch = QComboBox()
        self.cmb_pitch.setToolTip(
            "Khmer has only 2 voices (Sreymom, Piseth). Making the voice a little higher "
            "or lower lets two characters with the same voice still sound different.\n"
            "Auto picks a different one for every character.")
        self.cmb_pitch.activated.connect(lambda *_: self._pitch_changed())
        self.lbl_shift = QLabel("Voice pitch")
        f.addRow(self.lbl_shift, self.cmb_pitch)

        # 2.2: how this character speaks in every line (and every episode)
        from core.tts import DELIVERY, PACE

        self.cmb_delivery = QComboBox()
        self.cmb_delivery.addItem("Per line (as set in 🌐 Translation)", "")
        for k in DELIVERY:
            self.cmb_delivery.addItem(k, k)
        self.cmb_delivery.setToolTip(
            "How this character speaks in all its lines: calm, gentle, angry …\n"
            "Edge / Azure voices. Kept for the next episodes of a series.")
        self.cmb_delivery.activated.connect(
            lambda *_: self._set("delivery", self.cmb_delivery.currentData()))
        self.cmb_pace = QComboBox()
        self.cmb_pace.addItem("Per line", "")
        for k in PACE:
            self.cmb_pace.addItem(k, k)
        self.cmb_pace.setToolTip("Speak all lines of this character faster or slower.")
        self.cmb_pace.activated.connect(
            lambda *_: self._set("pace", self.cmb_pace.currentData()))
        row = QHBoxLayout()
        row.addWidget(self.cmb_delivery, 2)
        row.addWidget(self.cmb_pace, 1)
        self.lbl_delivery = QLabel("Speaks")
        f.addRow(self.lbl_delivery, row)

        self.cmb_clone = QComboBox()
        for k, v in speakers.CLONE_FROM:
            self.cmb_clone.addItem(v, k)
        self.cmb_clone.setToolTip(
            "VoxCPM2 speaks Khmer in the voice of a recording:\n"
            "• This video – the actor's own voice, cut from their lines (music in the "
            "background makes it worse)\n"
            "• My recording – a clean 5–15 s recording of a similar voice (best)\n"
            "• Default – the male / female (child / elder) voice of Settings › AI engines")
        self.cmb_clone.activated.connect(self._clone_changed)
        self.btn_ref = QPushButton("📁")
        self.btn_ref.setFixedWidth(36)
        self.btn_ref.setToolTip("Choose the recording to clone (wav, mp3, m4a ...)")
        self.btn_ref.clicked.connect(self._pick_ref)
        # 2.4: a voice from the 📚 Voice Library for this character
        self.btn_lib = QPushButton("📚")
        self.btn_lib.setFixedWidth(36)
        self.btn_lib.setToolTip("Choose a voice for this character from the Voice Library "
                                "(▶ preview each one)")
        self.btn_lib.clicked.connect(self._pick_library)
        row = QHBoxLayout()
        row.addWidget(self.cmb_clone, 1)
        row.addWidget(self.btn_lib)
        row.addWidget(self.btn_ref)
        self.lbl_clone = QLabel("Clone from")
        f.addRow(self.lbl_clone, row)
        self.lbl_ref = QLabel("")
        self.lbl_ref.setObjectName("MutedLabel")
        self.lbl_ref.setWordWrap(True)
        f.addRow("", self.lbl_ref)

        row = QHBoxLayout()
        self.btn_listen = QPushButton("▶ Hear original")
        self.btn_listen.setToolTip("Hear this character's own lines from the video")
        self.btn_listen.clicked.connect(lambda: self.current() and
                                        self.listenRequested.emit(self.current()))
        self.btn_first = QPushButton("⏩ First line")
        self.btn_first.clicked.connect(self._go_first_line)
        self.cmb_merge = QComboBox()
        self.cmb_merge.setToolTip("Same person found twice? Move all lines of this "
                                  "character to another one.")
        self.cmb_merge.activated.connect(self._merge)
        row.addWidget(self.btn_listen)
        row.addWidget(self.btn_first)
        row.addWidget(self.cmb_merge, 1)
        f.addRow(row)
        self.lbl_sum = QLabel("")
        self.lbl_sum.setWordWrap(True)
        self.lbl_sum.setObjectName("MutedLabel")
        f.addRow(self.lbl_sum)
        lay.addWidget(self.box)

        self.btn_voice = QPushButton("🔊 Voice the changed lines")
        self.btn_voice.setToolTip("Generate again only the lines whose character voice changed")
        self.btn_voice.clicked.connect(self.revoiceRequested.emit)
        lay.addWidget(self.btn_voice)
        hint = QLabel("A line given to the wrong person? In 🌐 Translation click its Voice "
                      "cell and choose the right character (select several lines to move "
                      "them together).")
        hint.setObjectName("MutedLabel")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        self.box.setEnabled(False)

    # ------------------------------------------------------------------ #
    def load(self, project: Optional[Project]):
        self.project = project
        keep = self.current()
        self._loading = True
        cast = (project.cast if project else {}) or {}
        labels = sorted(cast, key=lambda l: (-(cast[l].get("seconds") or 0), l))
        self.tbl.setRowCount(len(labels))
        for r, lab in enumerate(labels):
            c = cast[lab]
            name = speakers.display(project, lab)
            colour = speakers.color_of(lab)
            first = QTableWidgetItem(name)
            first.setData(Qt.ItemDataRole.UserRole, lab)
            first.setIcon(dot_icon(colour))
            bold = first.font()
            bold.setBold(True)
            first.setFont(bold)
            first.setForeground(QBrush(QColor(colour)))
            who = QTableWidgetItem(f"{SIGN.get(c.get('gender'), '')} {speakers.kind_of(c)}"
                                   f"{_sure_text(c)}")
            if _unsure(c):
                who.setForeground(QBrush(QColor("#ffb84d")))
            n = QTableWidgetItem(f"{c.get('lines', 0)} lines · {_dur(c.get('seconds', 0))}")
            v = QTableWidgetItem(self._voice_text(lab))
            for it in (first, who, n, v):
                it.setToolTip(self._summary(lab) + _sure_tip(c))
            self.tbl.setItem(r, 0, first)
            self.tbl.setItem(r, 1, who)
            self.tbl.setItem(r, 2, n)
            self.tbl.setItem(r, 3, v)
        segs = project.segments if project else []
        if labels:
            self.lbl_count.setText(f"{len(labels)} characters")
        elif segs:
            self.lbl_count.setText("not searched yet")
        else:
            self.lbl_count.setText("transcribe first")
        self.btn_find.setEnabled(bool(segs))
        path = getattr(project, "series_cast", "") if project else ""
        if path:
            from core import series

            self.lbl_series.setText(
                f"📚 Series cast ({series.summary(path)}): characters are recognised by voice "
                "in every episode. What you change here is used by the next episodes too.")
        self.lbl_series.setVisible(bool(path))
        row = labels.index(keep) if keep in labels else (0 if labels else -1)
        self._loading = False
        if row >= 0:
            self.tbl.selectRow(row)
        self._show_selected()

    def _voice_text(self, lab: str) -> str:
        return speakers.voice_summary(self.project, lab)

    def _summary(self, lab: str) -> str:
        """'Woman 1 says 12 lines (45 s) with Sreymom, a little higher.'"""
        p = self.project
        c = p.cast.get(lab) or {}
        name = speakers.display(p, lab)
        text = f"{name} says {c.get('lines', 0)} lines ({_dur(c.get('seconds', 0))})"
        try:
            seg = next((s for s in p.segments if s.speaker == lab), None)
            v = speakers.voice_name(speakers.voice_of(p, seg) if seg else "")
        except Exception:
            v = ""
        if v:
            text += f" with the voice {v}"
            if p.tts_engine in ("edge", "azure"):
                word = speakers.shift_word(speakers.shift_of(p, lab))
                if word != "normal":
                    text += f", {word}"
        return text + "."

    def current(self) -> str:
        rows = {i.row() for i in self.tbl.selectedIndexes()}
        if not rows:
            return ""
        it = self.tbl.item(min(rows), 0)
        return it.data(Qt.ItemDataRole.UserRole) if it else ""

    def _entry(self) -> Optional[dict]:
        lab = self.current()
        if not lab or not self.project:
            return None
        return self.project.cast.get(lab)

    def _show_selected(self):
        if self._loading:
            return
        c = self._entry()
        self.box.setEnabled(c is not None)
        if c is None:
            self.box.setTitle("Character")
            return
        self._loading = True
        lab = self.current()
        p = self.project
        name = speakers.display(p, lab)
        self.box.setTitle(f"● {name}")
        self.box.setStyleSheet(f"QGroupBox::title {{ color: {speakers.color_of(lab)}; }}")
        self.ed_name.setText("" if speakers.is_auto_name(c.get("name") or "")
                             else c.get("name") or "")
        self.ed_name.setPlaceholderText(f"{name} – type a name, e.g. Mother, Ming")
        self.cmb_gender.setCurrentIndex(max(0, self.cmb_gender.findData(c.get("gender"))))
        self.cmb_age.setCurrentIndex(max(0, self.cmb_age.findData(c.get("age", "adult"))))
        from core import register

        ai = c.get("rank_ai") or ""
        from core.i18n import tr
        self.cmb_rank.setItemText(0, "Auto – AI: " + tr(dict(register.RANKS)[ai].split("  (")[0])
                                  if ai in register.RANK_IDS else register.RANKS[0][1])
        self.cmb_rank.setCurrentIndex(max(0, self.cmb_rank.findData(c.get("rank") or "")))
        # voices of the project's engine
        self.cmb_voice.clear()
        saved, c["voice"] = c.get("voice") or "", ""     # (what Auto would pick)
        try:
            auto = speakers.voice_name(speakers.voice_of(p, _Probe(lab)))
        except Exception:
            auto = ""
        c["voice"] = saved
        self.cmb_voice.addItem(f"Auto – {auto}" if auto else "Auto (by man / woman / age)", "")
        for vid, label in voices_for(p.tts_engine, p.target_lang, with_auto=False):
            if vid != AUTO_VOICE:
                self.cmb_voice.addItem(label.replace(" (Male)", "  ♂ man")
                                       .replace(" (Female)", "  ♀ woman"), vid)
        i = self.cmb_voice.findData(c.get("voice") or "")
        if i < 0:
            self.cmb_voice.addItem(c.get("voice"), c.get("voice"))
            i = self.cmb_voice.count() - 1
        self.cmb_voice.setCurrentIndex(i)
        neural = p.tts_engine in ("edge", "azure")
        clone = p.tts_engine == "voxcpm"
        for w in (self.cmb_pitch, self.lbl_shift, self.cmb_delivery, self.cmb_pace,
                  self.lbl_delivery):
            w.setVisible(neural)
        self._fill_pitch(lab, c)
        self.cmb_delivery.setCurrentIndex(max(0, self.cmb_delivery.findData(
            c.get("delivery") or "")))
        self.cmb_pace.setCurrentIndex(max(0, self.cmb_pace.findData(c.get("pace") or "")))
        for w in (self.cmb_clone, self.btn_ref, self.btn_lib, self.lbl_clone, self.lbl_ref):
            w.setVisible(clone)
        self.cmb_clone.setCurrentIndex(max(0, self.cmb_clone.findData(c.get("clone", "auto"))))
        self.lbl_ref.setText(self._ref_text(lab, c) if clone else "")
        self.cmb_merge.clear()
        self.cmb_merge.addItem("Same person as… (move all lines)", "")
        for other in sorted(p.cast, key=speakers._order):
            if other != lab:
                self.cmb_merge.addItem(dot_icon(speakers.color_of(other)),
                                       speakers.display(p, other), other)
        self.lbl_sum.setText(self._summary(lab))
        self._loading = False

    def _fill_pitch(self, lab: str, c: dict):
        cb = self.cmb_pitch
        cb.clear()
        plain = getattr(self.project, "plain_voice", False)
        auto = 0 if plain else speakers._auto_shifts(self.project).get(lab, 0)
        cb.addItem(f"Auto – {speakers.shift_word(auto)}", PITCH_AUTO)
        for hz, word in speakers.SHIFT_STEPS:
            cb.addItem(word, hz)
        shift = c.get("shift")
        if plain and not c.get("shift_hand"):
            shift = None                # (a pitch from the series, not chosen here)
        if shift is None:
            cb.setCurrentIndex(0)
            return
        i = cb.findData(int(shift))
        if i < 0:
            cb.addItem(f"{speakers.shift_word(int(shift)).capitalize()} ({int(shift):+d} Hz)",
                       int(shift))
            i = cb.count() - 1
        cb.setCurrentIndex(i)

    def _ref_text(self, lab: str, c: dict) -> str:
        import os

        how = c.get("clone", "auto")
        if c.get("voice"):
            return "A fixed voice is chosen above."
        if how == "file":
            if c.get("ref_name"):
                return f"📚 {c['ref_name']} (Voice Library)"
            return os.path.basename(c.get("ref", "")) or "Choose a recording with 📁 or 📚"
        if how == "video" or (how == "auto" and speakers._clonable(self.project, lab)):
            return "The actor's own voice, cut from this video."
        return "Default voice (Settings › AI engines › Voice clone)."

    # ------------------------------------------------------------------ #
    def _set(self, key: str, value):
        if self._loading:
            return
        c = self._entry()
        if c is None or c.get(key) == value:
            return
        self.aboutToChange.emit()
        c[key] = value
        c["auto"] = False                     # "Find characters" keeps it from now on
        if key == "gender":                   # the ♂/♀ of its lines follows
            for s in self.project.segments:
                if s.speaker == self.current():
                    s.gender = value
        self.changed.emit()

    def _pitch_changed(self):
        v = self.cmb_pitch.currentData()
        c = self._entry()
        if c is None or self._loading:
            return
        shift = None if v == PITCH_AUTO else int(v)
        hand = v != PITCH_AUTO                  # chosen here: kept with plain voice too
        if c.get("shift") == shift and bool(c.get("shift_hand")) == hand:
            return
        self.aboutToChange.emit()
        c["shift"], c["shift_hand"], c["auto"] = shift, hand, False
        self.changed.emit()

    def _clone_changed(self, *_):
        how = self.cmb_clone.currentData()
        c = self._entry()
        if how == "file" and c is not None and not c.get("ref"):
            if not self._pick_ref():
                self._show_selected()
                return
        self._set("clone", how)

    def _pick_ref(self) -> bool:
        c = self._entry()
        if c is None:
            return False
        path, _ = QFileDialog.getOpenFileName(
            self, f"Voice to clone for {speakers.display(self.project, self.current())}", "",
            "Audio (*.wav *.mp3 *.m4a *.flac *.ogg *.aac *.mp4 *.mkv);;All files (*)")
        if not path:
            return False
        self.aboutToChange.emit()
        c["ref"] = path
        c.pop("ref_name", None)
        c["clone"] = "file"
        c["auto"] = False
        self.changed.emit()
        return True

    def _pick_library(self) -> bool:
        c = self._entry()
        if c is None:
            return False
        from ui.voice_library import VoiceLibraryDialog

        dlg = VoiceLibraryDialog(self, mode="pick",
                                 who=speakers.display(self.project, self.current()))
        if not dlg.exec() or dlg.chosen is None:
            return False
        v = dlg.chosen
        self.aboutToChange.emit()
        c["ref"], c["ref_name"] = v.file, v.name
        c["clone"], c["auto"] = "file", False
        self.changed.emit()
        self._show_selected()
        return True

    def _merge(self, *_):
        target = self.cmb_merge.currentData()
        lab = self.current()
        if not target or not lab:
            return
        self.aboutToChange.emit()
        move_lines(self.project, [s.id for s in self.project.segments if s.speaker == lab],
                   target)
        self.project.cast.pop(lab, None)
        self.changed.emit()

    def _go_first_line(self):
        lab = self.current()
        if not lab or not self.project:
            return
        segs = sorted((s for s in self.project.segments if s.speaker == lab),
                      key=lambda s: s.start)
        if segs:
            self.seekSourceRequested.emit(segs[0].start)


def _ai_judged(c: dict) -> bool:
    """Man / woman was decided by the AI model, and nobody changed it since."""
    return c.get("auto", True) and str(c.get("gender_src", "")).startswith("ai") \
        and bool(c.get("gender_conf"))


def _unsure(c: dict) -> bool:
    from core import gender_ai

    return _ai_judged(c) and c["gender_conf"] < int(gender_ai.CONFIDENT * 100)


def _sure_text(c: dict) -> str:
    if not _ai_judged(c):
        return ""
    return f"  {'⚠ ' if _unsure(c) else ''}{c['gender_conf']}%"


def _sure_tip(c: dict) -> str:
    if not _ai_judged(c):
        return ""
    how = " (the AI was unsure - the pitch helped)" if c.get("gender_src") == "ai+pitch" else ""
    tip = f"\n\nAI man/woman: {c['gender_conf']}% sure{how}."
    if _unsure(c):
        tip += "\n⚠ Please listen and check: change it below if it is wrong."
    return tip


def _dur(seconds) -> str:
    s = int(round(float(seconds or 0)))
    return f"{s // 60}m {s % 60:02d}s" if s >= 60 else f"{s}s"


class _Probe:
    """A stand-in line of a character (to ask which voice it gets)."""

    def __init__(self, label: str):
        self.speaker, self.voice, self.gender = label, "", ""


def move_lines(project: Project, seg_ids, target: str) -> int:
    """Give lines to another character (new one when target is not in the cast)."""
    if target not in project.cast:
        g = next((s.gender for s in project.segments if s.id in set(seg_ids)), "") or "male"
        c = speakers.new_character(target, g)
        c["auto"] = False
        project.cast[target] = c
    gender = project.cast[target].get("gender") or "male"
    ids = set(seg_ids)
    n = 0
    for s in project.segments:
        if s.id in ids:
            s.speaker = target
            s.gender = gender
            n += 1
    speakers.recount(project)
    return n
