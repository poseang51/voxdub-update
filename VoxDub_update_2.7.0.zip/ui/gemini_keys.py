"""
gemini_keys.py - 2.6.14: the Gemini keys at work, live.

  * GeminiKeysPanel  - one card per key: Ready / Translating / Resting (limit
    per minute) / Used up today / Refused, the lines it translated today, and
    the totals on top (keys ready, translating now, lines today, need attention).
  * GeminiKeysDialog - Router (ui/gemini_router.py) and Keys tabs in their own
    window (Batch 🔑, Settings › Gemini), with Get a free key, Test keys and
    "Remove refused keys".
  * KeysChip         - the small button in the Batch top bar ("🔑 9/15 ready").

Only masked keys (••••••••wxyz) are ever shown.
"""

import threading
import time

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import (QDialog, QFrame, QGridLayout, QHBoxLayout, QLabel,
                               QMessageBox, QPushButton, QScrollArea, QVBoxLayout, QWidget)

from core import gemini

COLOR = {gemini.READY: "#3ddc97", gemini.BUSY: "#4cc9f0", gemini.RESTING: "#f4b740",
         gemini.SPENT: "#f4b740", gemini.REFUSED: "#ff6b6b"}

STYLE = """
QWidget#KeysPanel, QScrollArea#KeysScroll, QWidget#KeysGrid { background: transparent; }
QLabel#KeysTitle { font-size: 15pt; font-weight: 800; color: #ffffff; }
QLabel#KeysSub { color: #8b949e; }
QLabel#KeysChip { background: #1a1f26; border: 1px solid #2b3440; border-radius: 13px;
                  padding: 4px 12px; color: #c9d1d9; font-weight: 600; }
QLabel#KeysChip[tone="busy"] { border-color: #1f5f78; color: #8fdcf5; }
QLabel#KeysChip[tone="ok"] { border-color: #1f5a3c; color: #6ee7a8; }
QLabel#KeysChip[tone="warn"] { border-color: #6b3a3a; color: #ff9c9c; }
QFrame#KeyCard { background: #161b22; border: 1px solid #262d36; border-radius: 10px; }
QFrame#KeyCard[state="busy"] { border: 1px solid #4cc9f0; background: #12212b; }
QFrame#KeyCard[state="refused"] { border: 1px solid #7a3434; background: #221516; }
QFrame#KeyCard[state="spent"], QFrame#KeyCard[state="resting"] { border-color: #5c4a1e; }
QLabel#KeyName { color: #ffffff; font-weight: 700; font-family: Consolas, monospace; }
QLabel#KeyState { color: #8b949e; font-size: 9pt; }
QLabel#KeyLines { color: #c9d1d9; font-weight: 700; }
"""


def _summary(rows):
    n = len(rows)
    ready = sum(r["state"] in (gemini.READY, gemini.BUSY) for r in rows)
    busy = sum(r["state"] == gemini.BUSY for r in rows)
    lines = sum(r["lines"] for r in rows)
    bad = sum(r["state"] == gemini.REFUSED for r in rows)
    spent = sum(r["state"] == gemini.SPENT for r in rows)
    return n, ready, busy, lines, bad, spent


def state_text(r, now=None) -> str:
    now = now or time.time()
    s = r["state"]
    if s == gemini.READY:
        return "Ready" + (f" · {r['models_left']}/{r['models']} models"
                          if r.get("models", 1) > 1 else "")
    if s == gemini.BUSY:
        return "Translating…"
    if s == gemini.RESTING:
        return f"Resting – limit per minute ({max(1, int(r['until'] - now))} s)"
    if s == gemini.SPENT:
        return ("Used up today" if r.get("models", 1) == 1 else "Every model used up") + \
            " – free again " + time.strftime("%H:%M", time.localtime(r["until"]))
    return "Refused – replace this key"


class _Card(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("KeyCard")
        self.setMinimumWidth(220)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 9, 12, 9)
        self.dot = QLabel("●")
        self.dot.setFixedWidth(16)
        mid = QVBoxLayout()
        mid.setSpacing(1)
        self.name = QLabel()
        self.name.setObjectName("KeyName")
        self.state = QLabel()
        self.state.setObjectName("KeyState")
        mid.addWidget(self.name)
        mid.addWidget(self.state)
        self.lines = QLabel()
        self.lines.setObjectName("KeyLines")
        self.lines.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        lay.addWidget(self.dot)
        lay.addLayout(mid, 1)
        lay.addWidget(self.lines)

    def show_row(self, i, r, now):
        self.dot.setStyleSheet(f"color: {COLOR[r['state']]}; font-size: 13pt;")
        self.name.setText(f"Key {i + 1}   {r['mask']}")
        self.state.setText(state_text(r, now))
        self.lines.setText(f"{r['lines']:,}\nlines" if r["lines"] else "–")
        self.setToolTip(r["why"][:300] if r["why"] else "")
        if self.property("state") != r["state"]:
            self.setProperty("state", r["state"])
            self.style().unpolish(self)
            self.style().polish(self)


class GeminiKeysPanel(QWidget):
    """Live: refreshes itself every second while it is shown."""

    COLS = 3

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("KeysPanel")
        self.setStyleSheet(STYLE)
        title = QLabel("Gemini keys")
        title.setObjectName("KeysTitle")
        sub = QLabel("Khmer subtitles go round your keys. A key that reached its limit "
                     "rests and the next one carries on; a refused key is taken out.")
        sub.setObjectName("KeysSub")
        sub.setWordWrap(True)
        self.chips = {}
        chip_row = QHBoxLayout()
        chip_row.setSpacing(8)
        for k in ("keys", "busy", "lines", "bad"):
            c = QLabel()
            c.setObjectName("KeysChip")
            self.chips[k] = c
            chip_row.addWidget(c)
        chip_row.addStretch(1)
        self.grid_box = QWidget()
        self.grid_box.setObjectName("KeysGrid")
        self.grid = QGridLayout(self.grid_box)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(8)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setObjectName("KeysScroll")
        scroll.viewport().setAutoFillBackground(False)
        scroll.setWidget(self.grid_box)
        self.empty = QLabel("No Gemini key yet – add one in Settings › AI engines & API keys.")
        self.empty.setObjectName("KeysSub")
        self.hint = QLabel()
        self.hint.setObjectName("KeysSub")
        self.hint.setWordWrap(True)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(title)
        lay.addWidget(sub)
        lay.addSpacing(4)
        lay.addLayout(chip_row)
        lay.addWidget(scroll, 1)
        lay.addWidget(self.empty)
        lay.addWidget(self.hint)
        self.cards = []
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(1000)
        self.refresh()

    def _chip(self, k, text, tone=""):
        c = self.chips[k]
        c.setText(text)
        if c.property("tone") != tone:
            c.setProperty("tone", tone)
            c.style().unpolish(c)
            c.style().polish(c)

    def refresh(self):
        if not self.isVisible() and self.cards:
            return
        rows = gemini.status(gemini.view_models())
        now = time.time()
        while len(self.cards) < len(rows):
            card = _Card()
            i = len(self.cards)
            self.grid.addWidget(card, i // self.COLS, i % self.COLS)
            self.cards.append(card)
        while len(self.cards) > len(rows):
            card = self.cards.pop()
            self.grid.removeWidget(card)
            card.deleteLater()
        for i, (card, r) in enumerate(zip(self.cards, rows)):
            card.show_row(i, r, now)
        n, ready, busy, lines, bad, spent = _summary(rows)
        self._chip("keys", f"🔑 {n} keys · {ready} ready", "ok" if ready else "warn")
        self._chip("busy", f"⟳ {busy} translating now", "busy" if busy else "")
        self._chip("lines", f"✓ {lines:,} lines today")
        self._chip("bad", f"⚠ {bad + spent} need attention", "warn" if bad + spent else "")
        self.empty.setVisible(not rows)
        hint = []
        if bad:
            hint.append(f"{bad} key(s) refused by Google (deleted, wrong or blocked) – they "
                        "are not used any more. Remove them and add new keys; “Test keys” "
                        "checks them again.")
        if spent:
            hint.append(f"{spent} key(s) used today's free quota – they work again after "
                        "Google's daily reset (shown on the card).")
        if rows and not ready:
            hint.append("No key can translate now: Google Translate (free) finishes the "
                        "lines by itself – the work does not stop.")
        from core.i18n import tr
        self.hint.setText("\n".join(tr(h) for h in hint))
        self.hint.setVisible(bool(hint))
        self.counts = (n, ready, busy, lines, bad, spent)


class _Tester(QObject):
    done = Signal(object)


class GeminiKeysDialog(QDialog):
    _open = None

    @classmethod
    def show_for(cls, parent=None):
        if cls._open is None:
            cls._open = cls(parent)
        cls._open.show()
        cls._open.raise_()
        cls._open.activateWindow()
        return cls._open

    def __init__(self, parent=None):
        super().__init__(parent)
        from PySide6.QtWidgets import QTabWidget

        from ui.gemini_router import RouterPanel

        self.setWindowTitle("Gemini Router – live")
        self.resize(940, 640)
        self.setStyleSheet("QDialog { background: #0d1117; } "
                           "QTabWidget::pane { border: 1px solid #262d36; border-radius: 8px; "
                           "background: #0d1117; top: -1px; } "
                           "QTabWidget > QWidget > QWidget { background: #0d1117; }")
        self.panel = GeminiKeysPanel(self)
        self.router = RouterPanel(self)
        self.tabs = QTabWidget()
        self.tabs.addTab(self.router, "🔀  Router")
        self.tabs.addTab(self.panel, "🔑  Keys")
        self.b_free = QPushButton("✨ Get a free key…")
        self.b_free.setToolTip("Make a free key in Google AI Studio – copied keys are saved "
                               "by themselves")
        self.b_free.clicked.connect(self.free_key)
        self.b_test = QPushButton("Test keys")
        self.b_test.setObjectName("AccentButton")
        self.b_test.setToolTip("Ask Google with every key (a refused key that works again "
                               "is put back in the queue)")
        self.b_test.clicked.connect(self.test_keys)
        self.b_drop = QPushButton("Remove refused keys")
        self.b_drop.clicked.connect(self.drop_refused)
        self.lb = QLabel()
        self.lb.setObjectName("MutedLabel")
        close = QPushButton("Close")
        close.clicked.connect(self.close)
        row = QHBoxLayout()
        row.addWidget(self.b_free)
        row.addWidget(self.b_test)
        row.addWidget(self.b_drop)
        row.addWidget(self.lb, 1)
        row.addWidget(close)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 16, 18, 14)
        lay.addWidget(self.tabs, 1)
        lay.addLayout(row)
        self._tester = _Tester()
        self._tester.done.connect(self._tested)

    def free_key(self):
        from ui.gemini_router import FreeKeyWizard

        FreeKeyWizard(self).exec()
        self.panel.refresh()

    def closeEvent(self, e):
        type(self)._open = None
        super().closeEvent(e)

    def test_keys(self):
        ks = gemini.keys()
        if not ks:
            return
        self.b_test.setEnabled(False)
        self.lb.setText(f"Testing {len(ks)} key(s)…")

        def work():
            res = [gemini.test_key(k) for k in ks]
            self._tester.done.emit(res)
        threading.Thread(target=work, daemon=True).start()

    def _tested(self, res):
        self.b_test.setEnabled(True)
        ok = sum(1 for r in res if not r)
        self.lb.setText(f"{ok} of {len(res)} key(s) work.")
        self.panel.refresh()

    def drop_refused(self):
        bad = [k for k, r in zip(gemini.keys(), gemini.status()) if r["state"] == gemini.REFUSED]
        if not bad:
            self.lb.setText("No refused key.")
            return
        ans = QMessageBox.question(
            self, "Gemini keys",
            f"Remove the {len(bad)} refused key(s) from this computer?\n\n"
            "Add new keys from aistudio.google.com/apikey in Settings › Gemini.")
        if ans != QMessageBox.StandardButton.Yes:
            return
        for k in bad:
            gemini.forget(k)
        gemini.set_keys([k for k in gemini.keys() if k not in bad])
        self.lb.setText(f"{len(bad)} key(s) removed.")
        self.panel.refresh()


class KeysChip(QPushButton):
    """Batch top bar: '🔑 9/15 ready' - red when a key needs attention."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setToolTip("Gemini Router – the keys at work, live (click)")
        self.clicked.connect(lambda: GeminiKeysDialog.show_for(self.window()))
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(2000)
        self.refresh()

    def refresh(self):
        rows = gemini.status(gemini.view_models()) if gemini.configured() else []
        self.setVisible(bool(rows))
        if not rows:
            return
        n, ready, busy, lines, bad, spent = _summary(rows)
        self.setText(f"🔑 {ready}/{n} ready" + (f" · {lines:,} lines" if lines else "")
                     + (f" · ⚠ {bad + spent}" if bad + spent else ""))
        self.setStyleSheet("color: #ff9c9c;" if bad + spent or not ready else "")
