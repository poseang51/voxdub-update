"""📱 Telegram setup (core/telegram.py): your own bot sends the Batch news."""

import threading

from PySide6.QtCore import QObject, Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton,
                               QVBoxLayout)

from core import settings, telegram

STEPS = """<div style='line-height:150%'>
<b>1.</b> ក្នុង Telegram បើក <b>@BotFather</b> → ផ្ញើ <b>/newbot</b> → ដាក់ឈ្មោះ bot
(ឧ. Sarika Po Bot) និង username ដែលបញ្ចប់ដោយ <b>bot</b>។<br>
<b>2.</b> BotFather ផ្ញើ <b>token</b> (ដូច 123456:ABC…) – Copy ហើយ Paste ខាងក្រោម។<br>
<b>3.</b> បើក bot ថ្មីរបស់អ្នក ហើយចុច <b>Start</b>។<br>
<b>4.</b> ចុច <b>🔍 Find me</b> រួច <b>📨 Send test</b>។<br>
<span style='color:#8b949e'>Token រក្សាទុកតែលើកុំព្យូទ័រនេះ។ Bot ផ្ញើតែឈ្មោះវគ្គ និងលទ្ធផល
– មិនផ្ញើវីដេអូ ឬ key ទេ។</span></div>"""


class _Sig(QObject):
    found = Signal(str, str)
    sent = Signal(str)


class TelegramDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("📱 Telegram – news of the Batch on your phone")
        self.resize(560, 420)
        steps = QLabel(STEPS)
        steps.setWordWrap(True)
        steps.setTextFormat(Qt.TextFormat.RichText)
        b_father = QPushButton("Open @BotFather")
        b_father.clicked.connect(lambda: QDesktopServices.openUrl(
            QUrl("https://t.me/BotFather")))
        self.ed_token = QLineEdit()
        self.ed_token.setEchoMode(QLineEdit.EchoMode.Password)
        self.ed_token.setPlaceholderText(
            f"saved: {settings.mask(telegram.token())}" if telegram.token()
            else "paste the bot token from BotFather")
        self.b_find = QPushButton("🔍 Find me")
        self.b_find.clicked.connect(self.find)
        self.b_test = QPushButton("📨 Send test")
        self.b_test.setObjectName("AccentButton")
        self.b_test.clicked.connect(self.test)
        self.b_off = QPushButton("Remove")
        self.b_off.setToolTip("Forget the bot on this computer")
        self.b_off.clicked.connect(self.remove)
        self.state = QLabel()
        self.state.setWordWrap(True)
        row = QHBoxLayout()
        row.addWidget(self.ed_token, 1)
        row.addWidget(self.b_find)
        row2 = QHBoxLayout()
        row2.addWidget(b_father)
        row2.addWidget(self.b_test)
        row2.addStretch(1)
        row2.addWidget(self.b_off)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        lay = QVBoxLayout(self)
        lay.addWidget(steps)
        lay.addLayout(row)
        lay.addLayout(row2)
        lay.addWidget(self.state)
        lay.addStretch(1)
        lay.addWidget(close, 0, Qt.AlignmentFlag.AlignRight)
        self._sig = _Sig()
        self._sig.found.connect(self._found)
        self._sig.sent.connect(self._sent)
        self._show()

    def _show(self):
        if telegram.ready():
            self.state.setText(f"✅ Ready – messages go to chat {telegram.chat()}.")
        elif telegram.token():
            self.state.setText("Token saved – open your bot, press Start, then 🔍 Find me.")
        else:
            self.state.setText("Not set up yet.")

    def _token(self) -> str:
        t = self.ed_token.text().strip()
        if t:
            settings.set("telegram_token", t)
            self.ed_token.clear()
            self.ed_token.setPlaceholderText(f"saved: {settings.mask(t)}")
        return telegram.token()

    def find(self):
        tok = self._token()
        if not tok:
            self.state.setText("Paste the token first.")
            return
        self.state.setText("Looking for you…")
        threading.Thread(target=lambda: self._sig.found.emit(*telegram.find_chat(tok)),
                         daemon=True).start()

    def _found(self, chat_id, name):
        if chat_id:
            settings.set("telegram_chat", chat_id)
            self.state.setText(f"✅ Found {name}. Click 📨 Send test.")
        else:
            self.state.setText(f"❌ {name}")

    def test(self):
        self._token()
        if not telegram.ready():
            self.find()
            return
        self.state.setText("Sending…")
        threading.Thread(target=lambda: self._sig.sent.emit(telegram.send_now(
            "✅ SARIKA VOXDUB PRO is connected – the Batch news will come here.")),
            daemon=True).start()

    def _sent(self, why):
        self.state.setText("✅ Sent – look at your phone." if not why else f"❌ {why}")

    def remove(self):
        settings.set("telegram_token", "")
        settings.set("telegram_chat", "")
        self.ed_token.setPlaceholderText("paste the bot token from BotFather")
        self._show()
