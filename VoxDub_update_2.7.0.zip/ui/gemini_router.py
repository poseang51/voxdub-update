"""
gemini_router.py - 2.6.14: Gemini Router, live + "Get a free key".

  * RouterView   - keys → Router → translations, drawn: a line lights up from
    the key that is translating, through the router (with its model list), to
    the episode it works on.
  * RouterPanel  - the view, the router's models, and the activity log.
  * FreeKeyWizard - the steps to a free Google AI Studio key, in Khmer: opens
    aistudio.google.com/apikey; a key copied there (Ctrl+C) is seen on the
    clipboard, tested and saved by itself - no pasting.

Only masked keys (••••••••wxyz) are ever shown.
"""

import math
import re
import threading
import time

from PySide6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, QUrl, Signal
from PySide6.QtGui import (QBrush, QColor, QDesktopServices, QFont, QGuiApplication, QPainter,
                           QPainterPath, QPen, QRadialGradient)
from PySide6.QtWidgets import (QDialog, QHBoxLayout, QLabel, QListWidget, QPushButton,
                               QSizePolicy, QVBoxLayout, QWidget)

from core import gemini
from core.i18n import tr

STATE_COLOR = {gemini.READY: "#3ddc97", gemini.BUSY: "#4cc9f0", gemini.RESTING: "#f4b740",
               gemini.SPENT: "#f4b740", gemini.REFUSED: "#ff6b6b"}
STATE_WORD = {gemini.READY: "Ready", gemini.BUSY: "Translating", gemini.RESTING: "Resting",
              gemini.SPENT: "Used up today", gemini.REFUSED: "Refused"}
ROWS = 8                    # key cards in one column before a second column starts
MAX_COLS = 3                # columns per side = MAX_COLS - 1; more keys: the view scrolls


def short_model(m: str) -> str:
    return m.replace("gemini-", "")


class RouterView(QWidget):
    """Painted: the keys on both sides, the router in the middle, the
    translations running now under it."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(330)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.rows, self.jobs, self.models = [], [], []
        self.phase = 0.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(60)
        self._n = 0

    def _tick(self):
        self.phase = (self.phase + 1.5) % 24
        self._n += 1
        if self._n % 15 == 1 or not self.rows:          # data every ~1 s
            self.models = gemini.view_models()
            self.rows = gemini.status(self.models)
            self.jobs = gemini.jobs()
            self._fit_height()
        if self.isVisible():
            self.update()

    def _shown_keys(self):
        """Every key (2.7: 20 keys showed 6 and "+14 more") - busy first, then
        ready, then the rest."""
        order = {gemini.BUSY: 0, gemini.READY: 1, gemini.RESTING: 2, gemini.SPENT: 3,
                 gemini.REFUSED: 4}
        return sorted(range(len(self.rows)), key=lambda i: (order[self.rows[i]["state"]], i))

    def sides(self, n: int):
        """Keys on BOTH sides of the router: (left count, right count,
        columns per side, rows per column, card height)."""
        left = -(-n // 2)
        cols = min(MAX_COLS - 1, max(1, -(-left // ROWS)))     # 1 or 2 per side
        rows = max(1, -(-left // cols))
        ch = 46 if n <= 8 else (40 if rows <= ROWS else 36)
        return left, n - left, cols, rows, ch

    def _fit_height(self):
        *_x, rows, ch = self.sides(len(self.rows))
        need = max(360, 34 + 24 + rows * (ch + 6))
        if self.minimumHeight() != need:
            self.setMinimumHeight(need)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()
        p.fillRect(self.rect(), QColor("#0b1020"))
        p.setPen(QPen(QColor(255, 255, 255, 10), 1))
        for x in range(0, W, 28):
            p.drawLine(x, 0, x, H)
        for y in range(0, H, 28):
            p.drawLine(0, y, W, y)
        f = QFont(self.font())
        order = list(range(len(self.rows)))   # Key 1.. on the left, the rest on the right
        left_n, right_n, cols, rows, kch = self.sides(len(order))
        # the middle keeps room for the router and the translations under it
        mid = min(320.0, W * 0.30)
        side_w = (W - mid) / 2 - 16
        kw = min(230.0, (side_w - 8 * (cols - 1)) / cols)
        top = 34
        gap = max(6.0, (H - top - 24 - kch * rows) / rows)
        R = min(58.0, H * 0.15, mid * 0.2)
        center = QPointF(W / 2, top + R + 34)
        f.setPointSizeF(8.5)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#8b949e"))
        p.drawText(QPointF(16, 20), tr("KEYS"))
        p.drawText(QRectF(W - 216, 9, 200, 14), Qt.AlignmentFlag.AlignRight, tr("KEYS"))
        busy_keys = {j.get("key") for j in self.jobs}
        narrow = kw < 190
        cards = []
        for n, i in enumerate(order):
            right = n >= left_n
            k = n - left_n if right else n
            c, row = divmod(k, rows)
            y = top + row * (kch + gap) + gap / 2
            if right:                           # mirrored: column 0 next to the router
                x = W / 2 + mid / 2 + c * (kw + 8)
                x = min(x, W - 16 - kw)
                end = QPointF(center.x() + R, center.y())
                start_x = x
            else:
                x = W / 2 - mid / 2 - kw - c * (kw + 8)
                x = max(16.0, x)
                end = QPointF(center.x() - R, center.y())
                start_x = x + kw
            rect = QRectF(x, y, kw, kch)
            r = self.rows[i]
            col = QColor(STATE_COLOR[r["state"]])
            active = r["state"] == gemini.BUSY or r["mask"] in busy_keys
            self._curve(p, QPointF(start_x, rect.center().y()), end, col, active,
                        dead=r["state"] == gemini.REFUSED)
            cards.append((rect, i, r, col, active))
        for rect, i, r, col, active in cards:   # cards over every line
            word = tr(STATE_WORD[r["state"]].replace(" today", "") if narrow
                      else STATE_WORD[r["state"]])
            lines = (f" · {r['lines']:,}" + ("" if narrow else " " + tr("lines"))) \
                if r["lines"] else ""
            self._card(p, rect, f"Key {i + 1}  {r['mask'][-(6 if narrow else 8):]}",
                       word + lines, col, active, small=kch < 46)
        # translations running: under the router
        jw = min(mid - 20, 260.0)
        jy = center.y() + R + 56
        jobs = self.jobs[:max(1, int((H - jy - 10) // 50))]
        f.setPointSizeF(8.5)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#8b949e"))
        p.drawText(QRectF(W / 2 - jw / 2, jy - 4, jw, 16), Qt.AlignmentFlag.AlignCenter,
                   tr("TRANSLATING NOW"))
        for n, j in enumerate(jobs):
            rect = QRectF(W / 2 - jw / 2, jy + 16 + n * 50, jw, 44)
            done, total = j.get("done", 0), max(1, j.get("total", 1))
            sub = f"{done}/{total} " + tr("lines") + (f" · {short_model(j['model'])}"
                                                       if j.get("model") else " · …")
            self._card(p, rect, j.get("title", "")[:28], sub, QColor("#4cc9f0"), True,
                       frac=done / total)
        if not jobs:
            f.setBold(False)
            f.setPointSizeF(9)
            p.setFont(f)
            p.setPen(QColor("#6e7681"))
            p.drawText(QRectF(W / 2 - jw / 2, jy + 16, jw, 30),
                       Qt.AlignmentFlag.AlignCenter, tr("No translation running"))
        self._router(p, center, R, bool(jobs))
        p.end()

    def _curve(self, p, a, b, col, active, dead=False):
        path = QPainterPath(a)
        dx = (b.x() - a.x()) * 0.55
        path.cubicTo(QPointF(a.x() + dx, a.y()), QPointF(b.x() - dx, b.y()), b)
        c = QColor(col)
        c.setAlpha(55 if not active else 90)
        pen = QPen(c, 2 if not active else 3)
        if dead:
            pen.setStyle(Qt.PenStyle.DotLine)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
        if active:                       # moving light along the line
            glow = QPen(QColor(col).lighter(130), 3)
            glow.setDashPattern([2, 10])
            glow.setDashOffset(-self.phase)
            glow.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(glow)
            p.drawPath(path)

    def _card(self, p, rect, title, sub, col, active, frac=None, small=False):
        bg = QColor("#141a2a") if not active else QColor("#10243a")
        p.setPen(QPen(col if active else QColor("#2a3346"), 1.4 if active else 1))
        p.setBrush(bg)
        p.drawRoundedRect(rect, 9, 9)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(col)
        p.drawEllipse(QPointF(rect.left() + 14, rect.center().y()), 4.5, 4.5)
        f = QFont(self.font())
        f.setBold(True)
        f.setPointSizeF(8.5 if small else 9)
        p.setFont(f)
        p.setPen(QColor("#ffffff"))
        h = rect.height()
        p.drawText(QRectF(rect.left() + 26, rect.top() + h * 0.08, rect.width() - 32, h * 0.42),
                   Qt.AlignmentFlag.AlignVCenter, title)
        f.setBold(False)
        f.setPointSizeF(7.5 if small else 8)
        p.setFont(f)
        p.setPen(QColor("#8b949e"))
        p.drawText(QRectF(rect.left() + 26, rect.top() + h * 0.48, rect.width() - 32, h * 0.38),
                   Qt.AlignmentFlag.AlignVCenter, sub)
        if frac is not None:
            bar = QRectF(rect.left() + 26, rect.bottom() - 6, rect.width() - 38, 2.5)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor("#22304a"))
            p.drawRoundedRect(bar, 1, 1)
            p.setBrush(col)
            p.drawRoundedRect(QRectF(bar.left(), bar.top(), bar.width() * min(1, frac),
                                     bar.height()), 1, 1)

    def _router(self, p, c, R, running):
        pulse = 1 + (0.06 * math.sin(self.phase / 24 * 2 * math.pi) if running else 0)
        g = QRadialGradient(c, R * 1.9)
        g.setColorAt(0, QColor(76, 201, 240, 90 if running else 40))
        g.setColorAt(1, QColor(76, 201, 240, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawEllipse(c, R * 1.9, R * 1.9)
        g2 = QRadialGradient(QPointF(c.x() - R / 3, c.y() - R / 3), R * 1.4)
        g2.setColorAt(0, QColor("#5b5bf0"))
        g2.setColorAt(1, QColor("#1b1f5e"))
        p.setBrush(QBrush(g2))
        p.setPen(QPen(QColor("#4cc9f0"), 2.5))
        p.drawEllipse(c, R * pulse, R * pulse)
        f = QFont(self.font())
        f.setBold(True)
        f.setPointSizeF(13)
        p.setFont(f)
        p.setPen(QColor("#ffffff"))
        p.drawText(QRectF(c.x() - R, c.y() - 16, 2 * R, 22), Qt.AlignmentFlag.AlignCenter, "AI")
        f.setPointSizeF(8)
        f.setBold(False)
        p.setFont(f)
        p.setPen(QColor("#c7d2fe"))
        p.drawText(QRectF(c.x() - R, c.y() + 6, 2 * R, 16), Qt.AlignmentFlag.AlignCenter,
                   "Router")
        # the model list under the router
        live = sum(r["state"] in (gemini.READY, gemini.BUSY) for r in self.rows)
        f.setPointSizeF(8.5)
        f.setBold(True)
        p.setFont(f)
        p.setPen(QColor("#ffffff"))
        p.drawText(QRectF(c.x() - 150, c.y() + R + 12, 300, 18), Qt.AlignmentFlag.AlignCenter,
                   tr(f"{len(self.jobs)} running · {live} keys ready · auto failover"))
        f.setBold(False)
        p.setFont(f)
        p.setPen(QColor("#8b949e"))
        p.drawText(QRectF(c.x() - 170, c.y() + R + 30, 340, 18), Qt.AlignmentFlag.AlignCenter,
                   " → ".join(short_model(m) for m in self.models) + " → Google Translate"
                   if gemini.when_out() == "google" else
                   " → ".join(short_model(m) for m in self.models))


class RouterPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.view = RouterView(self)
        head = QLabel("ACTIVITY")
        head.setStyleSheet("color: #8b949e; font-weight: 700; font-size: 8.5pt;")
        self.log = QListWidget()
        self.log.setMaximumHeight(130)
        self.log.setStyleSheet("QListWidget { background: #0d1117; border: 1px solid #262d36; "
                               "border-radius: 8px; color: #c9d1d9; font-family: Consolas, "
                               "monospace; font-size: 9pt; }")
        from PySide6.QtWidgets import QFrame, QScrollArea

        scroll = QScrollArea()                  # very many keys: the view grows
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setWidget(self.view)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(scroll, 1)
        lay.addWidget(head)
        lay.addWidget(self.log)
        self._last = None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(1000)
        self.refresh()

    def refresh(self):
        items = gemini.activity(60)
        sig = (len(items), items[-1][0] if items else 0)
        if sig == self._last:
            return
        self._last = sig
        self.log.clear()
        for t, text in reversed(items):
            self.log.addItem(time.strftime("%H:%M:%S", time.localtime(t)) + "   " + text)
        if not items:
            self.log.addItem("Nothing yet – the router writes here what each key does.")


# --------------------------------------------------------------------------- #
# Get a free key
# --------------------------------------------------------------------------- #
KEY_RE = re.compile(r"^AIza[0-9A-Za-z_\-]{35}$")
STUDIO = "https://aistudio.google.com/apikey"

STEPS = """<div style='line-height:150%'>
<b>1.</b> ចុច <b>🌐 Open Google AI Studio</b> ខាងក្រោម ហើយ login ដោយ Gmail របស់អ្នក
(ជាលើកដំបូង: ធីក ✓ ហើយចុច <b>Continue</b>)។<br>
<b>2.</b> ចុច <b>Create API key</b> → <b>Create key</b> (Default project ក៏បាន)។<br>
<b>3.</b> ចុចប៊ូតុង <b>Copy</b> នៅក្បែរ key។ <b>SARIKA ឃើញវាដោយខ្លួនឯង</b> –
មិនចាំបាច់ paste ទេ: វា Test ហើយ Save ភ្លាម។<br>
<b>4.</b> ចង់បាន quota ច្រើនជាងនេះ? Login ដោយ <b>Gmail មួយទៀត</b> ហើយធ្វើម្តងទៀត
(Gmail មួយ = quota ឥតគិតថ្លៃមួយ)។ Gemini Router ប្រើ key ទាំងអស់ម្តងមួយៗ។<br>
<span style='color:#8b949e'>Key រក្សាទុកតែលើកុំព្យូទ័រនេះ។ SARIKA មិនដែលស្នើសុំពាក្យសម្ងាត់
Gmail របស់អ្នកទេ។</span></div>"""


class _Sig(QObject):
    tested = Signal(str, str)        # key, why ('' = works)


class FreeKeyWizard(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Get a free Gemini key")
        self.resize(560, 420)
        title = QLabel("✨ Get a free Gemini key")
        title.setStyleSheet("font-size: 15pt; font-weight: 800;")
        steps = QLabel(STEPS)
        steps.setWordWrap(True)
        steps.setTextFormat(Qt.TextFormat.RichText)
        b_open = QPushButton("🌐  Open Google AI Studio")
        b_open.setObjectName("AccentButton")
        b_open.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(STUDIO)))
        self.state = QLabel("⏳ Waiting for a key on the clipboard (Copy in AI Studio)…")
        self.state.setWordWrap(True)
        self.state.setStyleSheet("padding: 10px; border: 1px dashed #2b3440; "
                                 "border-radius: 8px;")
        self.count = QLabel()
        self.count.setObjectName("MutedLabel")
        done = QPushButton("Done")
        done.clicked.connect(self.accept)
        row = QHBoxLayout()
        row.addWidget(self.count, 1)
        row.addWidget(done)
        lay = QVBoxLayout(self)
        lay.addWidget(title)
        lay.addWidget(steps)
        lay.addWidget(b_open, 0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(self.state)
        lay.addStretch(1)
        lay.addLayout(row)
        self.added = 0
        self._seen = set()
        self._sig = _Sig()
        self._sig.tested.connect(self._tested)
        self.clip = QGuiApplication.clipboard()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_clipboard)
        self.timer.start(700)
        self._show_count()

    def _show_count(self):
        n = len(gemini.keys())
        self.count.setText(f"{n} key(s) on this computer" + (f" · {self.added} added now"
                                                              if self.added else ""))

    def check_clipboard(self):
        text = (self.clip.text() or "").strip()
        if not KEY_RE.match(text) or text in self._seen:
            return
        self._seen.add(text)
        if text in gemini.keys():
            self.state.setText("ℹ This key is already saved. Make a key with another Gmail "
                               "for more quota.")
            self.clip.clear()
            return
        self.state.setText("🔍 Key seen – testing it with Google…")
        threading.Thread(target=lambda: self._sig.tested.emit(text, gemini.test_key(text)),
                         daemon=True).start()

    def _tested(self, key, why):
        from core import errors

        kind = errors.advice(why) if why else ""
        if why and kind == errors.KEY:
            self.state.setText(f"❌ Google refused this key ({why.splitlines()[0][:120]}). "
                               "Make a new one and copy it again.")
            return
        gemini.set_keys(gemini.keys() + [key])
        self.clip.clear()                    # the key does not stay on the clipboard
        self.added += 1
        mask = key[:0] + "••••••••" + key[-4:]
        if not why:
            self.state.setText(f"✅ Key {mask} works and is saved. Copy another one (other "
                               f"Gmail) or click Done.")
        else:
            self.state.setText(f"✅ Key {mask} is saved (could not test it now: "
                               f"{why.splitlines()[0][:90]}).")
        self._show_count()
