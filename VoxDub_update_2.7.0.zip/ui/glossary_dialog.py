"""📖 Glossary: names / words translated the same way in every episode
(core/glossary.py)."""

import os
from typing import List, Tuple

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDialog, QHBoxLayout, QHeaderView, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from core import glossary


class GlossaryDialog(QDialog):
    """lists: [(label, path)] - e.g. My glossary + this story's glossary."""

    def __init__(self, parent, lists: List[Tuple[str, str]]):
        super().__init__(parent)
        self.setWindowTitle("📖 Glossary – translation and 🗣 read aloud, the same in every "
                            "episode")
        self.resize(640, 520)
        self.lists = [(l, p) for l, p in lists if p]
        self.path = ""
        v = QVBoxLayout(self)
        top = QHBoxLayout()
        self.cmb = QComboBox()
        for label, path in self.lists:
            self.cmb.addItem(label, path)
        self.cmb.currentIndexChanged.connect(self._switch)
        top.addWidget(QLabel("List"))
        top.addWidget(self.cmb, 1)
        v.addLayout(top)
        note = QLabel()
        self.note = note
        note.setWordWrap(True)
        note.setObjectName("MutedLabel")
        v.addWidget(note)
        self.tbl = QTableWidget(0, 2)
        self.tbl.setHorizontalHeaderLabels(["Original (e.g. 糖宝)", "Translation (e.g. តាំងប៉ៅ)"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        v.addWidget(self.tbl, 1)
        row = QHBoxLayout()
        b_add = QPushButton("＋ Add")
        b_add.clicked.connect(self._add)
        b_del = QPushButton("Remove")
        b_del.clicked.connect(self._remove)
        self.lb_count = QLabel("")
        self.lb_count.setObjectName("MutedLabel")
        b_save = QPushButton("Save")
        b_save.setObjectName("PrimaryButton")
        b_save.clicked.connect(self.save)
        b_close = QPushButton("Close")
        b_close.clicked.connect(self.accept)
        for w in (b_add, b_del):
            row.addWidget(w)
        row.addWidget(self.lb_count, 1)
        row.addWidget(b_save)
        row.addWidget(b_close)
        v.addLayout(row)
        self._switch()

    def _switch(self, *_):
        if self.path:
            self.save()
        self.path = self.cmb.currentData() or ""
        from core import reading

        if reading.is_reading_list(self.path):
            self.note.setText("🗣 Read aloud: how the AI VOICE says a word – the subtitle keeps "
                              "it as written.\ne.g. VIP → វីអាយភី, a name the voice reads "
                              "wrongly → the way it must sound. Lines with a changed word are "
                              "voiced again at the next Voice step.")
            self.tbl.setHorizontalHeaderLabels(["Written (e.g. VIP)", "Read as (e.g. វីអាយភី)"])
        else:
            self.note.setText("Original word → how it must be translated. Used by Gemini and "
                              "Google Translate for every line.\nThe story list also learns the "
                              "names Gemini chooses (marked ✨), so the next episodes say them "
                              "the same way.")
            self.tbl.setHorizontalHeaderLabels(["Original (e.g. 糖宝)",
                                                "Translation (e.g. តាំងប៉ៅ)"])
        terms = glossary.load(self.path)
        auto = set(glossary.learned(self.path))
        self.tbl.setRowCount(0)
        for a, b in sorted(terms.items()):
            self._add(a, b, a in auto)
        self.lb_count.setText(f"{len(terms)} words")

    def _add(self, a: str = "", b: str = "", learned: bool = False):
        r = self.tbl.rowCount()
        self.tbl.insertRow(r)
        ia = QTableWidgetItem(a)
        ia.setData(Qt.ItemDataRole.UserRole, learned)
        if learned:
            ia.setToolTip("✨ learned from Gemini – change it if it is wrong")
        ib = QTableWidgetItem(b)
        self.tbl.setItem(r, 0, ia)
        self.tbl.setItem(r, 1, ib)
        if not a:
            self.tbl.editItem(ia)

    def _remove(self):
        for r in sorted({i.row() for i in self.tbl.selectedIndexes()}, reverse=True):
            self.tbl.removeRow(r)

    def rows(self):
        out, auto = {}, []
        for r in range(self.tbl.rowCount()):
            a = (self.tbl.item(r, 0).text() if self.tbl.item(r, 0) else "").strip()
            b = (self.tbl.item(r, 1).text() if self.tbl.item(r, 1) else "").strip()
            if a and b:
                out[a] = b
                if self.tbl.item(r, 0).data(Qt.ItemDataRole.UserRole):
                    auto.append(a)
        return out, auto

    def save(self):
        if not self.path:
            return
        terms, auto = self.rows()
        old = glossary.load(self.path)
        # a learned name that was changed by hand is the user's own from now on
        auto = [a for a in auto if old.get(a) == terms.get(a)]
        glossary.save(self.path, terms, auto)
        self.lb_count.setText(f"✓ saved – {len(terms)} words")

    def accept(self):
        self.save()
        super().accept()


def lists_for(project=None, story_cast_path: str = "") -> List[Tuple[str, str]]:
    """My glossary + the story glossary (from the project or a Batch story)."""
    out = []
    cast = story_cast_path or (getattr(project, "series_cast", "") if project else "")
    if cast:
        story = os.path.basename(os.path.dirname(cast)) or "this story"
        out.append((f"Story: {story}", glossary.story_path(cast)))
    out.append(("My glossary (every video)", glossary.my_path()))
    # 2.7: how the voice reads words (core/reading.py)
    from core import reading

    if cast:
        out.append((f"🗣 Read aloud – story: {story}", reading.story_path(cast)))
    out.append(("🗣 Read aloud – my list (every video)", reading.my_path()))
    return out
