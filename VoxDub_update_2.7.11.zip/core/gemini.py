"""
gemini.py - Google Gemini with YOUR OWN API key(s) (Google AI Studio).

Used for
  * Translation that follows the story: the model sees the lines around each
    batch, keeps names and forms of address the same all through the video
    and writes natural spoken dialogue for dubbing.
  * Speech-to-text (optional, instead of Whisper): the audio is sent in
    short pieces and the model writes down what is said.

Keys are kept in the user's settings on this computer only (never in a
project file). Several keys can be added (one per Google account / Cloud
project = one quota each): the requests go round-robin, and a key that hits
its quota (HTTP 429 / RESOURCE_EXHAUSTED) rests for a minute while the others
carry on.

Gemini 3 models are sent thinkingLevel "low", Gemini 2.5 thinkingBudget 0
(translation needs no long thinking and it costs time + output tokens); a
model that refuses the field is asked again without it.
"""

import os
import base64
import io
import json
import re
import threading
import time
import wave
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from . import gemini_stats, settings

API = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_MODEL = "gemini-2.5-flash"
SUGGESTED_MODELS = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro",
                    "gemini-3.6-flash"]
BATCH_LINES = 30
CONTEXT_LINES = 8
AFTER_LINES = 4                 # the lines that come next (understand, do not translate)
TIMEOUT = 75      # 2.7.2 (19/11): was 120 - a key + model that hangs held Translate
                  # 2 minutes per try (39 lines took 627 s on 19/11, 1% for minutes)

Progress = Callable[[int, str], None]


class GeminiError(RuntimeError):
    pass


class QuotaError(GeminiError):
    pass


# --------------------------------------------------------------------------- #
# keys + model (settings)
# --------------------------------------------------------------------------- #
def keys() -> List[str]:
    ks = settings.get("gemini_keys", []) or []
    return [k.strip() for k in ks if isinstance(k, str) and k.strip()]


def set_keys(ks: Sequence[str]):
    settings.set("gemini_keys", list(dict.fromkeys(k.strip() for k in ks if k.strip())))


def model() -> str:
    return (settings.get("gemini_model", "") or DEFAULT_MODEL).strip()


def configured() -> bool:
    if keys():
        return True
    try:                                # 2.7.2: the Admin's Gemini web (text only)
        from . import gemini_web

        return gemini_web.available()
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# HTTP with key rotation
# --------------------------------------------------------------------------- #
_lock = threading.Lock()
_turn = {"i": 0}
# 2.6.14: Google's free quota is per key AND per model - the states are kept
# for each (key, model) pair; a refused key is refused for every model.
_rest: Dict[Tuple[str, str], float] = {}     # (key, model) -> may be used again at
_spent: Dict[Tuple[str, str], float] = {}    # (key, model) -> today's quota used, until
_dead: Dict[str, str] = {}                   # key -> why it was refused
_busy: Dict[str, int] = {}                   # key -> requests on the way now
_gone_models: Dict[str, str] = {}            # model -> why (404: not for these keys)
_tls = threading.local()                     # key / model the last generate() used

# The key states live on (gemini_keys_state.json next to settings.json - no key
# in it, only a fingerprint): a refused key is not tried again on every start,
# a used-up key waits for the daily reset, lines per key today are counted.
STATE_FILE = "gemini_keys_state.json"
_st: Dict[str, dict] = {}

# Gemini Router: the work goes round every key AND these models in turn
# used when Google cannot be asked which models the keys have (no internet)
ROUTER_MODELS = ["gemini-3.6-flash-lite", "gemini-3.5-flash", "gemini-3.5-flash-lite",
                 "gemini-2.5-flash", "gemini-2.5-flash-lite"]
# a fast text model of the keys: gemini-<version>-flash[-lite] (no preview / image / tts)
_FLASH = re.compile(r"^gemini-(\d+(?:\.\d+)?)-flash(-lite)?(?:-\d{3})?$")
_activity: List[Tuple[float, str]] = []      # (time, text) - newest last
_jobs: Dict[int, dict] = {}                  # thread id -> the translation it does
_job_of: Dict[int, int] = {}                 # batch thread -> the thread whose job it is


def fingerprint(key: str) -> str:
    import hashlib

    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def _pacific_now():
    """Google's free daily quota starts again at midnight, Pacific time."""
    import datetime as dt

    try:
        from zoneinfo import ZoneInfo

        return dt.datetime.now(ZoneInfo("America/Los_Angeles"))
    except Exception:                       # no tz database (old Windows Python)
        return dt.datetime.now(dt.timezone(dt.timedelta(hours=-8)))


def today() -> str:
    return _pacific_now().strftime("%Y-%m-%d")


def next_reset() -> float:
    import datetime as dt

    now = _pacific_now()
    midnight = (now + dt.timedelta(days=1)).replace(hour=0, minute=0, second=5, microsecond=0)
    return time.time() + (midnight - now).total_seconds()


def flash_models(names: Sequence[str]) -> List[str]:
    """The fast text models in a model list, newest first, flash before lite."""
    got = []
    for n in names:
        m = _FLASH.match(n or "")
        if m:
            got.append((-float(m.group(1)), bool(m.group(2)), n))
    return [n for *_k, n in sorted(got)]


def discover_models() -> List[str]:
    """2.7 (3A号座位的代价 EP026, 12/11): the Router's models were 2.5 / 2.0 -
    Google had retired them (404), so only gemini-3.6-flash was left and
    every key ran out after 25 episodes. The models are now asked from
    Google (once a day, kept in the settings)."""
    found = settings.get("router_found") or {}
    if isinstance(found, dict) and found.get("day") == today() and found.get("models"):
        return list(found["models"])
    ks = [k for k in keys() if k not in _dead]
    if not ks:
        return []
    try:
        ms = flash_models(list_models(ks[0]))
    except Exception as e:                      # no internet: the list we know
        print(f"[gemini] model list not read: {e}")
        return []
    if ms:
        settings.set("router_found", {"day": today(), "models": ms})
    return ms


def router_models(ask_google: bool = True) -> List[str]:
    """The user's list (Settings › Gemini › Router), else the model of
    Settings + the fast models the keys have. ask_google=False: no network
    (the Settings window), the list found today or the known one."""
    ms = settings.get("router_models") or []
    ms = [m.strip() for m in ms if isinstance(m, str) and m.strip()]
    if ms:
        return ms
    if ask_google:
        found = discover_models()
    else:
        f = settings.get("router_found") or {}
        found = list(f.get("models") or []) if isinstance(f, dict) else []
    return list(dict.fromkeys([model()] + (found or ROUTER_MODELS)))[:6]


def set_router_models(ms: Sequence[str]):
    settings.set("router_models", list(dict.fromkeys(m.strip() for m in ms if m.strip())))


def when_out() -> str:
    """What happens when every key (and model) is used up: 'google' / 'stop'."""
    return "stop" if settings.get("gemini_when_out", "google") == "stop" else "google"


def log(text: str):
    with _lock:
        _activity.append((time.time(), text))
        del _activity[:-200]


def activity(n: int = 50) -> List[Tuple[float, str]]:
    with _lock:
        return list(_activity[-n:])


_view = {"models": None}


def view_models() -> List[str]:
    """The models the key panel shows: the ones the last translation used."""
    return list(_view["models"] or [model()])


def jobs() -> List[dict]:
    with _lock:
        return [dict(j) for j in _jobs.values()]


def _state_path() -> str:
    import os

    return os.path.join(settings.settings_dir(), STATE_FILE)


def _load_state():
    """Once: refused / used-up keys of earlier runs go back in the queue state."""
    if _st.get("_loaded"):
        return
    data = {}
    try:
        with open(_state_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        pass
    if not isinstance(data, dict):
        data = {}
    _st.clear()
    _st.update({"_loaded": True, "day": data.get("day", ""),
                "lines": dict(data.get("lines") or {}),
                "refused": dict(data.get("refused") or {}),
                "spent": dict(data.get("spent") or {})})
    if _st["day"] != today():
        _st.update({"day": today(), "lines": {}, "spent": {}})
    by_fp = {fingerprint(k): k for k in keys()}
    now = time.time()
    for fp, why in _st["refused"].items():
        if fp in by_fp:
            _dead[by_fp[fp]] = str(why)
    for name, until in list(_st["spent"].items()):
        fp, _, m = name.partition("|")
        try:
            until = float(until)
        except (TypeError, ValueError):
            continue
        if fp in by_fp and m and until > now:
            _spent[(by_fp[fp], m)] = until


def _save_state():
    import os

    data = {k: v for k, v in _st.items() if not k.startswith("_")}
    try:
        os.makedirs(settings.settings_dir(), exist_ok=True)
        tmp = _state_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=1)
        os.replace(tmp, _state_path())
    except OSError:
        pass


def _new_day():
    if _st.get("day") != today():
        _st.update({"day": today(), "lines": {}, "spent": {}})
        _spent.clear()


def _mark_refused(key: str, why: str):
    with _lock:
        _load_state()
        _dead[key] = why
        _st["refused"][fingerprint(key)] = why[:200]
        _save_state()
    log(f"🔴 Key {settings.mask(key)} refused by Google – taken out, replace it")


def _mark_spent(key: str, m: str):
    with _lock:
        _load_state()
        _new_day()
        until = next_reset()
        _spent[(key, m)] = until
        _st["spent"][f"{fingerprint(key)}|{m}"] = until
        _save_state()
    log(f"🟡 Key {settings.mask(key)} · {m}: today's quota used")


def _mark_ok(key: str):
    """The key answered: it is not refused (any more) - e.g. after Test keys."""
    if key in _dead or fingerprint(key) in _st.get("refused", {}):
        with _lock:
            _dead.pop(key, None)
            _st.get("refused", {}).pop(fingerprint(key), None)
            _save_state()


def count_lines(n: int, key: Optional[str] = None):
    """Lines translated by a key today (shown in the key panel)."""
    key = key or getattr(_tls, "key", None)
    if not key or n <= 0:
        return
    with _lock:
        _load_state()
        _new_day()
        fp = fingerprint(key)
        _st["lines"][fp] = int(_st["lines"].get(fp, 0)) + int(n)
        _save_state()


def forget(key: str):
    """A key removed in Settings: its state goes too."""
    with _lock:
        _load_state()
        fp = fingerprint(key)
        _st["refused"].pop(fp, None)
        _st["lines"].pop(fp, None)
        for name in [n for n in _st["spent"] if n.startswith(fp + "|")]:
            _st["spent"].pop(name)
        _dead.pop(key, None)
        for d in (_spent, _rest):
            for pair in [p for p in d if p[0] == key]:
                d.pop(pair)
        _save_state()


READY, BUSY, RESTING, SPENT, REFUSED = "ready", "busy", "resting", "spent", "refused"
_last_use: dict = {}        # key -> when its last answer came (the Router page)


def _usable(k: str, m: str, now: float) -> bool:
    return k not in _dead and _spent.get((k, m), 0) <= now and _rest.get((k, m), 0) <= now


def status(models: Optional[Sequence[str]] = None) -> List[dict]:
    """One dict per key, in the order of Settings: mask, state, lines today,
    why (refused), until (resting / spent), models_left (of `models`, the
    Gemini model or the router's). Never the key itself."""
    with _lock:
        _load_state()
        _new_day()
        now = time.time()
        ms = [m for m in (models or [model()]) if m not in _gone_models] or [model()]
        out = []
        for k in keys():
            fp = fingerprint(k)
            spent = [_spent[(k, m)] for m in ms if _spent.get((k, m), 0) > now]
            rest = [_rest[(k, m)] for m in ms if _rest.get((k, m), 0) > now]
            left = sum(_usable(k, m, now) for m in ms)
            d = {"fp": fp, "mask": settings.mask(k), "lines": int(_st["lines"].get(fp, 0)),
                 "why": "", "until": 0.0, "busy": _busy.get(k, 0),
                 "last": _last_use.get(k, 0.0),
                 "models_left": 0 if k in _dead else left, "models": len(ms)}
            if k in _dead:
                d.update(state=REFUSED, why=_dead[k])
            elif len(spent) == len(ms):
                d.update(state=SPENT, until=min(spent))
            elif _busy.get(k, 0) > 0:
                d["state"] = BUSY
            elif not left:
                d.update(state=RESTING, until=min(rest + spent))
            else:
                d["state"] = READY
            out.append(d)
        return out


def _thinking(m: str) -> Optional[dict]:
    m = m.lower()
    if m.startswith("gemini-3"):
        return {"thinkingLevel": "low"}
    if m.startswith("gemini-2.5") and "pro" not in m:
        return {"thinkingBudget": 0}
    return None


def _http(url: str, body: Optional[dict], timeout: float = TIMEOUT) -> Tuple[int, dict]:
    import requests

    if body is None:
        r = requests.get(url, timeout=timeout)
    else:
        r = requests.post(url, json=body, timeout=timeout)
    try:
        data = r.json()
    except ValueError:
        data = {"error": {"message": r.text[:300]}}
    return r.status_code, data


def _err_text(data: dict) -> str:
    e = data.get("error") if isinstance(data, dict) else None
    if isinstance(e, dict):
        return f"{e.get('status', '')} {e.get('message', '')}".strip()
    return str(data)[:300]


def _daily(data: dict) -> bool:
    """429 because the quota for the whole DAY is used (not the minute)."""
    t = json.dumps(data).lower()
    return "perday" in t or "per day" in t or "requests_per_day" in t


def _retry_after(data: dict, default: float) -> float:
    try:
        for d in (data.get("error") or {}).get("details") or []:
            v = d.get("retryDelay")
            if v:
                return max(5.0, min(120.0, float(str(v).rstrip("s"))))
    except (AttributeError, TypeError, ValueError):
        pass
    return default


def _next_pair(pool: List[str], ms: List[str]) -> Optional[Tuple[str, str]]:
    """The next (key, model) that may be asked: the first model in the list
    that any key still has, keys in turn."""
    with _lock:
        _load_state()
        _new_day()
        now = time.time()
        for m in ms:
            if m in _gone_models:
                continue
            for _ in range(len(pool)):
                k = pool[_turn["i"] % len(pool)]
                _turn["i"] += 1
                if _usable(k, m, now):
                    return k, m
    return None


def _out_of_keys(pool: List[str], ms: List[str]) -> Optional[Exception]:
    """Every key refused or used up for today (every model): say it at once -
    the caller goes on with Google Translate (or stops) instead of waiting."""
    now = time.time()
    live = [m for m in ms if m not in _gone_models]
    if not live:
        return GeminiError("Model not found: " + "; ".join(
            f"{m} ({_gone_models[m][:80]})" for m in ms))
    if not all(k in _dead or all(_spent.get((k, m), 0) > now for m in live) for k in pool):
        return None
    spent = [k for k in pool if k not in _dead]
    if spent:
        hrs = max(1, round((min(_spent[(k, m)] for k in spent for m in live) - now) / 3600))
        what = f"{len(live)} models" if len(live) > 1 else live[0]
        return QuotaError(f"All Gemini keys have used today's quota ({len(spent)} used up, "
                          f"{len(pool) - len(spent)} refused; {what}) – free again in about "
                          f"{hrs} h")
    return GeminiError(f"Gemini key refused: {_dead[pool[0]]} – all {len(pool)} keys")


def generate(parts: List[dict], want_json: bool = True, max_tokens: int = 16384,
             temperature: float = 0.3, key_list: Optional[List[str]] = None,
             model_name: str = "", should_stop: Optional[Callable[[], bool]] = None,
             fresh: bool = False, models: Optional[Sequence[str]] = None,
             time_limit: float = 300.0) -> Tuple[str, str]:
    """generate_api, with the Admin's Gemini web (core/gemini_web.py) for text:
    before the keys (mode "first") or when every key is used up ("fallback")."""
    web = None
    if key_list is None and not fresh:
        try:
            from . import gemini_web

            if gemini_web.available() and gemini_web.text_only(parts):
                web = gemini_web
        except Exception:
            web = None
    wmode = web.mode() if web is not None else ""
    first = web is not None and wmode == "first" and \
        gemini_stats.kind() not in getattr(web, "KEYS_FIRST", ())
    if web is not None and wmode == "first" and not first:
        # 2.7.2: quick work (Voice's shorter lines): the keys first, the web if
        # every key is used up
        try:
            return generate_api(parts, want_json, max_tokens, temperature, key_list,
                                model_name, should_stop, fresh, models, time_limit)
        except InterruptedError:
            raise
        except GeminiError:
            out = web.generate(parts, should_stop)
            log("🌐 Every key is used up – Gemini web (Admin) answered")
            return out
    if first:
        try:
            out = web.generate(parts, should_stop)
            log("🌐 Gemini web (Admin) answered")
            return out
        except InterruptedError:
            raise
        except Exception as e:
            log(f"🌐 Gemini web: {str(e)[:80]} – the API keys go on")
    try:
        return generate_api(parts, want_json, max_tokens, temperature, key_list, model_name,
                            should_stop, fresh, models, time_limit)
    except InterruptedError:
        raise
    except GeminiError as e:
        if web is None or wmode != "fallback" or not web.available():
            raise
        try:
            out = web.generate(parts, should_stop)
        except InterruptedError:
            raise
        except Exception as e2:
            log(f"🌐 Gemini web: {str(e2)[:80]}")
            raise e
        log("🌐 Every key is used up – Gemini web (Admin) answered")
        return out


def generate_api(parts: List[dict], want_json: bool = True, max_tokens: int = 16384,
                 temperature: float = 0.3, key_list: Optional[List[str]] = None,
                 model_name: str = "", should_stop: Optional[Callable[[], bool]] = None,
                 fresh: bool = False, models: Optional[Sequence[str]] = None,
                 time_limit: float = 300.0) -> Tuple[str, str]:
    """One generateContent call. Returns (text, finishReason).
    models: the Gemini Router - every key with the first model, then the next...
    fresh: ask with key_list[0] once, whatever its state (Test keys)."""
    pool = key_list if key_list is not None else keys()
    if not pool:
        raise GeminiError("No Gemini API key – add one in Settings › AI engines & API keys")
    ms = list(dict.fromkeys(models)) if models else [model_name or model()]
    no_think = set()
    last = ""
    deadline = time.time() + time_limit
    while time.time() < deadline:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        pair = (pool[0], ms[0]) if fresh else _next_pair(pool, ms)
        if pair is None:
            gone = _out_of_keys(pool, ms)
            if gone:
                gemini_stats.lost()
                raise gone
            now = time.time()
            soon = [_rest[(k, m)] for k in pool for m in ms
                    if _rest.get((k, m), 0) > now and _spent.get((k, m), 0) <= now
                    and k not in _dead]
            wait = max(1.0, (min(soon) if soon else now + 1) - now)
            if wait > 90:
                gemini_stats.lost()
                raise QuotaError(f"All Gemini keys are over their quota: {last}")
            if not _tls.__dict__.get("waited"):
                _tls.waited = True
                log(f"⏳ Every key is resting – waiting {int(wait)} s")
            time.sleep(min(wait, 5.0))      # every key is resting for a minute
            continue
        key, m = pair
        _tls.waited = False
        cfg = {"temperature": temperature, "maxOutputTokens": max_tokens}
        if want_json:
            cfg["responseMimeType"] = "application/json"
        think = None if m in no_think else _thinking(m)
        if think:
            cfg["thinkingConfig"] = think
        body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": cfg}
        with _lock:
            _busy[key] = _busy.get(key, 0) + 1
            me_ = threading.get_ident()
            job = _jobs.get(me_) or _jobs.get(_job_of.get(me_, 0))
            if job is not None:
                job.update(key=settings.mask(key), model=m)
        sid = gemini_stats.start(settings.mask(key), "key", m)      # 2.7.2: the Gateway
        try:
            # never wait past the job's own time limit for one answer
            code, data = _http(f"{API}/models/{m}:generateContent?key={key}", body,
                               timeout=max(20.0, min(TIMEOUT, deadline - time.time() + 5)))
            gemini_stats.end(sid, "answered" if code == 200 else "retried")
        except Exception as e:                  # network
            gemini_stats.end(sid, "retried")
            last = str(e)[:200]
            if fresh:
                raise GeminiError(last)
            # 2.7.2 (14/11): a key + model that hung ("Read timed out", 120 s)
            # was asked again and again until the 5-minute deadline - for every
            # batch of voices. It rests a minute; the next key / model is asked.
            # 2.7.2 (15/11): a model that does not answer in time is slow for
            # every key - before, the Router waited 2 minutes on each of the 10
            # keys (20 minutes) before it moved to the next model. Now the
            # whole model rests 10 minutes and the next model is asked at once.
            slow = "timed out" in last.lower() or "timeout" in type(e).__name__.lower()
            with _lock:
                if slow and len(ms) > 1:
                    for k in pool:
                        _rest[(k, m)] = max(_rest.get((k, m), 0), time.time() + 600)
                else:
                    _rest[(key, m)] = time.time() + 60
            if slow:
                note = f"{m} did not answer in time – the next model is asked"
                print(f"[gemini] {note}")
                log(f"⏱ {note}")
            time.sleep(1)
            continue
        finally:
            with _lock:
                _busy[key] = max(0, _busy.get(key, 0) - 1)
                _last_use[key] = time.time()        # 2.7.2: the Router page
        if code == 200:
            _tls.key, _tls.model = key, m
            _mark_ok(key)
            cands = data.get("candidates") or []
            if not cands:
                fb = data.get("promptFeedback", {})
                raise GeminiError(f"Gemini returned nothing ({fb.get('blockReason', 'blocked')})")
            c = cands[0]
            text = "".join(p.get("text", "") for p in (c.get("content") or {}).get("parts", [])
                           if not p.get("thought"))
            return text, c.get("finishReason", "")
        last = _err_text(data)
        if code == 400 and "thinking" in last.lower() and "thinkingConfig" in cfg:
            no_think.add(m)                     # this model does not take the field
            continue
        if code in (429, 503) or "RESOURCE_EXHAUSTED" in last:
            if code == 429 and _daily(data):
                _mark_spent(key, m)             # until Google's daily reset
                print(f"[gemini] key {settings.mask(key)} · {m}: today's quota is used")
            else:
                with _lock:
                    _rest[(key, m)] = time.time() + (_retry_after(data, 60) if code == 429
                                                     else 10)
            if fresh:
                raise QuotaError(f"Gemini quota: {last}")
            continue
        bad_key = (code in (401, 403) and "quota" not in last.lower()) or (
            code == 400 and ("api key not valid" in last.lower()
                             or "api_key_invalid" in last.lower()))
        if bad_key:
            # one dead key (deleted / disabled project) must not stop the work
            # while other keys are fine - and not on the next starts either,
            # until Test keys says it works again
            _mark_refused(key, f"{code} {last}")
            if fresh or all(k in _dead for k in pool):
                raise GeminiError(f"Gemini key refused ({code}): {last}"
                                  + (f" – all {len(pool)} keys" if len(pool) > 1 else ""))
            print(f"[gemini] key {settings.mask(key)} was refused ({code}) – taken out of "
                  f"the queue, replace it in Settings › Gemini; "
                  f"{len(pool) - sum(k in _dead for k in pool)} keys left")
            continue
        if code == 404:
            if len(ms) > 1 and not fresh:       # the router goes on with the next model
                _gone_models[m] = last
                log(f"⚪ Model {m} is not available for these keys – skipped")
                continue
            raise GeminiError(f"Model '{m}' not found – choose another model ({last})")
        if code >= 500:
            time.sleep(3)
            continue
        raise GeminiError(f"Gemini error {code}: {last}")
    gemini_stats.lost()
    raise GeminiError(f"Gemini did not answer: {last}")


def test_key(key: str, model_name: str = "") -> str:
    """'' when the key + model work, else the reason."""
    try:
        text, _ = generate([{"text": "Reply with the single word OK."}], want_json=False,
                           max_tokens=256, key_list=[key], model_name=model_name, fresh=True)
        return "" if text.strip() else "empty answer"
    except Exception as e:
        return str(e)


def list_models(key: str) -> List[str]:
    code, data = _http(f"{API}/models?key={key}&pageSize=200", None, timeout=30)
    if code != 200:
        raise GeminiError(_err_text(data))
    out = []
    for m in data.get("models", []):
        if "generateContent" in (m.get("supportedGenerationMethods") or []):
            out.append(m.get("name", "").replace("models/", ""))
    return sorted((m for m in out if m.startswith("gemini")), reverse=True)


def _json(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except ValueError:
        m = re.search(r"[\[{].*[\]}]", text, re.S)
        if m:
            return json.loads(m.group(0))
        raise


# --------------------------------------------------------------------------- #
# translation
# --------------------------------------------------------------------------- #
_SCRIPT = {"km": r"[ក-៿]", "th": r"[฀-๿]", "lo": r"[຀-໿]",
           "my": r"[က-႟]", "zh": r"[一-鿿]", "ja": r"[぀-ヿ一-鿿]",
           "ko": r"[가-힯]", "vi": r"[A-Za-zÀ-ỹ]", "en": r"[A-Za-z]"}


def right_script(text: str, lang: str) -> bool:
    """A Khmer voice cannot read Chinese: a 'translation' still in the wrong
    script is treated as missing."""
    pat = _SCRIPT.get(lang)
    return bool(text.strip()) and (pat is None or re.search(pat, text) is not None) \
        and not foreign_bits(text, lang)


# 2.7: a Khmer line with Thai / Chinese letters in it ("ក្នុងเมื่อមេឃ") or English
# glued to a Khmer word ("ជាតិline") - the voice cannot read it: asked again
# 2.7.2: Myanmar too ("ថ្លៃဆេးបាយ", 13/11), Korean, Cyrillic, Devanagari
# 2.7.2 (16/11): not a list of scripts any more - Arabic "បاجទឹក" and Hebrew
# "យואន់" came through. In a Khmer line any letter that is not Khmer or Latin
# is foreign (Latin is judged by stray_english / glued words below).
_NOT_KM = (r"[^\s\d\u0000-\u024f\u1780-\u17ff\u19e0-\u19ff\u1e00-\u1eff"
           r"\u2000-\u2bff\u3000-\u303f\uff00-\uffef\u200b-\u200d\ufeff]")
_FOREIGN = {"km": re.compile(_NOT_KM + r"|[\u1780-\u17ff][A-Za-z]|[A-Za-z][\u1780-\u17ff]")}


def stray_english(source: str, text: str, lang: str, names=None) -> str:
    """2.7 (3A号座位的代价 EP001, 12/11): "ដូរ seat ជាមួយខ្ញុំ" - an English word
    in a Khmer line that the original line does not have ("hello", "3A",
    "32D" in the original stay) and that is no name in the glossary."""
    if lang != "km":
        return ""
    src = (source or "").lower()
    keep = " ".join(str(v) for v in (names or {}).values()).lower()
    for w in re.findall(r"[A-Za-z]{2,}", text or ""):
        if w.lower() not in src and w.lower() not in keep:
            return w
    return ""


def clean_foreign(text: str, lang: str) -> str:
    """Take the Thai / Chinese letters and glued English out of a Khmer line."""
    if lang != "km":
        return text
    t = re.sub(_NOT_KM + r"+[\u17b6-\u17d3]*", "", text or "")
    t = re.sub(r"(?<=[\u1780-\u17ff])[A-Za-z]+|[A-Za-z]+(?=[\u1780-\u17ff])", "", t)
    return re.sub(r"\s{2,}", " ", t).strip()


# 2.7.2 (16/11, merged): broken Khmer spelling the voice reads badly -
# "ទេី្រមែន" (two vowels on one letter), "ថា្ន" (a foot after a vowel),
# "ហ៎េស" (a vowel after a sign). A vowel sign or a foot (្) must sit on a
# letter; the ones that do not are taken out.
_KM_BASE = set(chr(c) for c in range(0x1780, 0x17B4)) | {"\u17c9", "\u17ca", "\u17cc"}


def fix_khmer(text: str) -> str:
    t = text or ""
    if not re.search(r"[\u17b6-\u17c5\u17d2]", t):
        return t
    out = []
    i = 0
    while i < len(t):
        ch = t[i]
        prev = out[-1] if out else ""
        if ch == "\u17d2":
            nxt = t[i + 1] if i + 1 < len(t) else ""
            if prev in _KM_BASE and "\u1780" <= nxt <= "\u17a2":
                out.append(ch)
                out.append(nxt)
                i += 2
                continue
            i += 2 if "\u1780" <= nxt <= "\u17a2" else 1   # the foot and its letter
            continue
        if "\u17b6" <= ch <= "\u17c5" and prev not in _KM_BASE:
            i += 1                       # the stray vowel and the signs on it ("គ្នាុំ")
            while i < len(t) and "\u17c6" <= t[i] <= "\u17d1" and t[i] != "\u17d2":
                i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def foreign_bits(text: str, lang: str) -> str:
    """The first piece of another script in a translation ('' = clean)."""
    pat = _FOREIGN.get(lang)
    m = pat.search(text or "") if pat else None
    return m.group(0) if m else ""


def _prompt(lines: List[Tuple[int, str]], src: str, tgt: str, title: str,
            context: List[Tuple[str, str]], names: Dict[str, str],
            after: Optional[List[str]] = None, people: str = "", learned: str = "") -> str:
    from .translate import LANGUAGES

    tname = LANGUAGES.get(tgt, (tgt, ""))[0]
    sname = LANGUAGES.get(src, (src, ""))[0] if src and src != "auto" else "the original language"
    ctx = "\n".join(f"- {s}  =>  {t}" if t else f"- {s}" for s, t in context) \
        or "(start of the video)"
    nxt = "\n".join(f"- {s}" for s in (after or [])) or "(end of the video)"
    gl = "\n".join(f"- {a} = {b}" for a, b in list(names.items())[:60]) or "(none yet)"
    numbered = "\n".join(f"{i}: {t}" for i, t in lines)
    return f"""You translate the dialogue of a video{f' titled "{title}"' if title else ''} from {sname} into {tname} for DUBBING (an AI voice will speak your lines over the picture).

Rules:
- Natural, spoken {tname} as people really talk in a TV drama - not word-for-word, not formal writing.
- Follow the story: use the earlier lines to understand who speaks to whom; choose kinship terms, pronouns and politeness that fit the relationship.
- Keep every person's name the SAME all through the video (use the name list); write names the way {tname} viewers read them.
- Keep each line about as short as the original so it fits the same time. Do not add explanations.{chr(10) + '- Money: say the SAME word all through the video - 元 / 块 is យ័ន (never រៀល, that is Cambodian money).' if tgt == 'km' else ''}{chr(10) + '- ' + KM_ADDRESS if tgt == 'km' else ''}{chr(10) + '- Numbers and prices in digits: 12.9元 = ១២.៩ យ័ន, 4000 = ៤០០០ (never a Chinese number word such as កៅ).' if tgt == 'km' else ''}
- Translate every line, one output per input number. Never leave a line in {sname}.{chr(10) + '- Write only Khmer script: no Thai, Chinese or English words (only names from the name list may stay as they are).' if tgt == 'km' else ''}

Names so far (ALWAYS use exactly these translations):
{gl}
{people}{learned}
Earlier lines (original => translation):
{ctx}

The lines that come right after the ones to translate (only to understand the meaning - do NOT translate them):
{nxt}

Translate these lines:
{numbered}

Answer ONLY with JSON: {{"lines": [{{"i": <number>, "t": "<translation>"}}, ...], "names": {{"<original name>": "<name in {tname}>"}}{', "ranks": {"<label>": "emperor|royal|noble|common|servant|monk"}' if people else ''}}}
In "names" put EVERY person's name in these lines that is not in the name list yet - full names (沈玉兰), surname + title (沈女士, 顾先生, 王总), nicknames and shop / brand names (强记) - written in the original script, with the {tname} you used; {{}} when there is none.
Never put the [label: who] part in a translation."""


def translate_lines(lines: List[str], source: str, target: str,
                    progress: Optional[Progress] = None,
                    should_stop: Optional[Callable[[], bool]] = None,
                    on_result: Optional[Callable[[int, str], None]] = None,
                    title: str = "", batch: int = BATCH_LINES,
                    names: Optional[Dict[str, str]] = None,
                    models: Optional[Sequence[str]] = None,
                    speakers: Optional[List[str]] = None,
                    cast: Optional[Dict[str, dict]] = None,
                    ranks: Optional[Dict[str, str]] = None,
                    learned: str = "", first_names: bool = False) -> List[str]:
    """Same contract as translate.translate_lines (1:1, on_result as batches
    finish). Lines Gemini leaves out or answers in the wrong script are
    translated by Google Translate at the end (and counted in the report).
    names: the glossary (kept as given); the names Gemini chooses are added
    to this same dict, so the caller can keep them for the next episodes."""
    out = [(t or "").strip() for t in lines]
    todo = [i for i, t in enumerate(out) if t]
    me = threading.get_ident()
    _view["models"] = list(models) if models else None
    with _lock:
        _jobs[me] = {"title": title or "Translation", "done": 0, "total": len(todo),
                     "key": "", "model": "", "router": bool(models), "start": time.time()}
    try:
        if first_names and names is not None and todo:
            # 2.7.2: the names of the whole video first, so every batch (also the
            # first) says them the same way ("莎莎" was សាណា once, សាសា after)
            if progress:
                progress(1, "Gemini: the names in this video…")
            try:
                n = pick_names([out[i] for i in todo], source, target, names, models,
                               should_stop)
                if n:
                    print(f"[gemini] {n} names chosen before translating")
            except InterruptedError:
                raise
            except QuotaError:
                raise
            except Exception as e:              # the translation still works without
                print(f"[gemini] names not chosen first: {str(e)[:120]}")
        return _translate_lines(out, todo, source, target, progress, should_stop, on_result,
                                title, batch, names, models, speakers, cast, ranks, learned)
    finally:
        with _lock:
            _jobs.pop(me, None)


def _lang_name(code: str) -> str:
    from .translate import LANGUAGES

    return LANGUAGES.get(code, (code, ""))[0]


# 19/11 (Dubify vs SARIKA, the same video): 老周 came out "ឡាវចូវ", Dubify said
# "ពូចូវ" - the way Khmer viewers call an older man
KM_ADDRESS = ("老 / 小 / 阿 + a name are Khmer forms of address, not sounds: 老周 = ពូចូវ (an older man; an older woman: មីង), 小王 = អាវ៉ាង (a young man; a young woman: នាង), 周哥 = បងចូវ, 周姐 = បងស្រីចូវ - never ឡាវ / ស៊ៀវ / អា-sounds written out. "
              # 26/11 (2.7.11, a Ming palace drama): 孙公公 came out "លោកគុងគុងស៊ុន",
              # 锦衣卫 "ជីនយីវ៉ី" as if a man's name, 太监 "កន្ទើយ"
              "Old palace titles too: 孙公公 = ខុនទីស៊ុន (公公 / 太监 = ខុនទី, never គុងគុង); "
              "锦衣卫, 东厂, 西厂 are the emperor's guards, said by meaning (锦衣卫 = "
              "កងរក្សាព្រះអង្គ), never by sound as a name")


def pick_names(lines: List[str], source: str, target: str, names: Dict[str, str],
               models: Optional[Sequence[str]] = None, should_stop=None) -> int:
    """2.7.2: every person's name in the video and how to say it in the target
    language, asked once before the translation. The names already in `names`
    (the glossary) stay as they are; the new ones are added. Returns how many."""
    tname = _lang_name(target)
    gl = "\n".join(f"- {a} = {b}" for a, b in list(names.items())[:80]) or "(none)"
    text = "\n".join(f"- {t}" for t in lines[:400])
    prompt = f"""These are the lines of a video. List EVERY person's name in them - full names (沈玉兰), surname + title (沈女士, 王总), nicknames and short forms (多多 for 钱多多, 莎莎 for 冯莎莎) - and the names of shops, restaurants, brands and companies (强记, 老王面馆), and the {tname} name a dubbing should use for each, written the way {tname} viewers read it. A shop / brand name is said by its sound, the same way every time - not translated as words (强记 is a name, not "strong").
A short form must be the matching part of the full name in {tname} (钱多多 = A B -> 多多 = B).{(chr(10) + KM_ADDRESS) if target == 'km' else ''}
The lines come from speech recognition and from reading the subtitles on the screen, so ONE person's name is often written in several ways that sound or look alike (林熙川 / 林七川 / 林霖川 / 弄川 for one man, 知薇 / 志位 for one woman). List every way it is written, each with the SAME {tname} name - the spelling written most often, or the one in the full name. A way of writing a name already chosen below gets that chosen name. Two different people with alike names (two brothers) stay apart - only when the story shows they are two.
NOT names: family order and kinship words (老二, 老三, 大哥, 大嫂, 爹, 娘, 老婆子, 媳妇), plain titles (大夫, 队长, 太监) and bodies of guards or officials (锦衣卫, 东厂) - leave them out, the translation says them as words. A surname + title IS a name (孙公公, 谭百户).
These names are already chosen - use them exactly, and build their short forms from them:
{gl}

Lines:
{text}

Answer ONLY with JSON: {{"names": {{"<name as written in the lines>": "<{tname} name>"}}}} ({{}} when there is none)."""
    with gemini_stats.work("Names", len(lines)):
        out, _ = generate([{"text": prompt}], temperature=0.1, max_tokens=4096,
                          should_stop=should_stop, models=models, time_limit=75.0)
    try:
        data = _json(out)
    except ValueError:
        return 0
    got = data.get("names") if isinstance(data, dict) else None
    n = 0
    for a, b in (got or {}).items():
        if isinstance(a, str) and isinstance(b, str) and a.strip() and b.strip() \
                and a.strip() not in names and right_script(b.strip(), target) \
                and not is_family_word(a.strip()) \
                and any(a.strip() in t for t in lines):
            names[a.strip()] = b.strip()
            n += 1
    return n


# 2.7.2 (14/11): "老二" (the second son) came back as a name, "អាជ្រូកទីពីរ"
# ("second pig"), and was put in all 25 lines that say 老二/老三/老四; "老婆子"
# (old woman) became "យាយកែវ". Family order, kinship and plain titles are words
# the translation chooses in each line (អាពីរ, បងធំ, ម៉ែ ...), never names.
_FAMILY = re.compile(
    r"^(老[大二三四五六七八九十幺]|[大二三四五六小]?(哥|姐|嫂|弟|妹|叔|婶|伯|姨|舅|姑)"
    r"|[大二三四五六]?(哥哥|姐姐|弟弟|妹妹)|爹|娘|爸|妈|爸爸|妈妈|爹娘|爷爷|奶奶|姥姥|姥爷"
    r"|外婆|外公|老婆|老公|老婆子|老头子|老头|媳妇|.{1,2}媳妇|儿子|闺女|女儿|孩子|大夫|医生"
    r"|老板|老师|师傅|同志|队长|村长|领导|小姐|先生|女士|太太|夫人|大嫂|大哥|嫂子)$")


def is_family_word(name: str) -> bool:
    return bool(_FAMILY.match((name or "").strip()))


def _common(a: str, b: str) -> int:
    """Length of the longest piece two texts share."""
    best = 0
    for i in range(len(a)):
        for j in range(i + best + 1, len(a) + 1):
            if a[i:j] in b:
                best = j - i
            else:
                break
    return best


def name_missing(source: str, text: str, names: Dict[str, str]) -> str:
    """2.7.2: a name of the name list that is in the original line but said
    another way in the translation ("莎莎" -> សាណា when the list says សាសា).
    A short form (ស្រីកែវ for ហុងស្រីកែវ) is fine, and so is leaving the name
    out (ឯង instead of the name). Returns the name, '' = fine."""
    t = (text or "").replace(" ", "")
    if not t:
        return ""
    found = [(k, v) for k, v in names.items() if len(k) >= 2 and k in (source or "")
             and v and not v.isascii()]
    for k, v in found:
        vs = [v] + [v2 for k2, v2 in found if k2 != k and (k2 in k or k in k2)]
        ok = False
        for w in vs:
            w = w.replace(" ", "")
            if w in t or _common(w, t) >= max(3, len(w) // 2):
                ok = True
                break
        if ok:
            continue
        # said another way: the translation has a name-like word close to it?
        # (only then - a line that leaves the name out is fine)
        if _looks_renamed(v, text):
            return k
    return ""


def names_not_said(source: str, text: str, names: Dict[str, str]) -> List[Tuple[str, str]]:
    """2.7.11: names of the list in the original line that the translation does
    not have (nor a short form of them) - "子航" said "ជឺហាង", not "ហ្ស៊ីហាំង"."""
    t = (text or "").replace(" ", "")
    found = [(k, v) for k, v in names.items() if len(k) >= 2 and k in (source or "")
             and v and not v.isascii()]
    out = []
    for k, v in found:
        if any(k != k2 and k in k2 for k2, _ in found):
            continue                    # 子航 inside 程子航: the longer one speaks
        vs = [v] + [v2 for k2, v2 in found if k2 != k and (k2 in k or k in k2)]
        if not any(w.replace(" ", "") in t or _common(w.replace(" ", ""), t) >=
                   max(3, len(w.replace(" ", "")) // 2) for w in vs):
            out.append((k, v))
    return out


def _looks_renamed(v: str, text: str) -> bool:
    """The first sound of the name is in the line but the name is not: សាណា
    for សាសា, ហ្វឹង for ហ្វុង. 2 letters of the name in a row are enough."""
    t = (text or "").replace(" ", "")
    for part in v.split():
        if len(part) >= 3 and part[:2] in t:
            return True
    return False


PROOF_LINES = 80                # lines per proofreading request


def proofread(originals: List[str], lines: List[str], target: str,
              names: Optional[Dict[str, str]] = None,
              models: Optional[Sequence[str]] = None, should_stop=None) -> Dict[int, str]:
    return _proofread(originals, lines, target, names, models, should_stop)


def _proofread(originals, lines, target, names=None, models=None, should_stop=None
               ) -> Dict[int, str]:
    """2.7.2: Gemini reads the finished translation once more and fixes only
    clear mistakes - spelling (ស្មើ -> ស្នើ), a word with the wrong meaning for
    the original (查 = check, not "តតាំង"), a name not as in the name list.
    Returns {index: fixed line}; the style is not rewritten."""
    tname = _lang_name(target)
    gl = "\n".join(f"- {a} = {b}" for a, b in list((names or {}).items())[:80]) or "(none)"
    todo = [i for i, t in enumerate(lines) if t.strip() and originals[i].strip()]
    fixed: Dict[int, str] = {}

    def one(ids) -> Dict[int, str]:
        got: Dict[int, str] = {}
        def row(i):
            # 26/11 (2.7.11): "子航" came out "ជឺហាង" and the proofreader kept it
            # - a name of the list missing from the line is pointed out
            miss = names_not_said(originals[i], lines[i], names or {})
            note = ("   [name not in the line: " + ", ".join(f"{k} = {v}" for k, v in miss)
                    + "]") if miss else ""
            return f"{i + 1}. {originals[i].strip()}  =>  {lines[i].strip()}{note}"
        rows = "\n".join(row(i) for i in ids)
        prompt = f"""You proofread the {tname} dubbing of a drama (original line => {tname} line).
Fix ONLY clear mistakes:
- spelling mistakes ({'ស្មើ written for ស្នើ, ឲ្យ / អោយ mixed is fine' if target == 'km' else 'typos'});
- a word whose meaning is wrong for the original line (a mistranslation);
- a person's name not written as in the name list - a line marked [name not in the line] says that name another way (put the list's name in) or by a word like "he / you" (leave it).
{'- money said two ways (元 is យ័ន, never រៀល);' + chr(10) if target == 'km' else ''}Do NOT change lines that are right, do not make them longer, do not change the style, the forms of address or the slang. Most lines need no change.

Names:
{gl}

Lines:
{rows}

Answer ONLY with JSON: {{"fix": [{{"i": <number>, "t": "<corrected {tname} line>"}}]}} ({{"fix": []}} when all are right)."""
        with gemini_stats.work("Proofread", len(ids)):
            text, _ = generate([{"text": prompt}], temperature=0.0, max_tokens=8192,
                               should_stop=should_stop, models=models, time_limit=150.0)
        try:
            data = _json(text)
        except ValueError:
            return {}
        for it in (data.get("fix") if isinstance(data, dict) else None) or []:
            try:
                i = int(it["i"]) - 1
                t = str(it["t"]).strip()
            except (KeyError, TypeError, ValueError):
                continue
            old = lines[i].strip() if 0 <= i < len(lines) else ""
            if i in ids and t and t != old and right_script(t, target) \
                    and not stray_english(originals[i], t, target, names) \
                    and 0.5 <= len(t) / max(1, len(old)) <= 1.5:
                got[i] = t
        return got

    # 2.7.2 (16/11): the parts are read side by side, like the translation
    from concurrent.futures import ThreadPoolExecutor

    parts = [todo[b0:b0 + PROOF_LINES] for b0 in range(0, len(todo), PROOF_LINES)]
    if should_stop and should_stop():
        raise InterruptedError("Cancelled")
    with ThreadPoolExecutor(max_workers=max(1, min(len(parts) or 1, parallel_slots(models))),
                            thread_name_prefix="gemini-proof") as ex:
        for got in ex.map(one, parts):
            fixed.update(got)
    return fixed


def google_used() -> Tuple[int, str]:
    """(lines Google Translate did in the last translate_lines of this thread,
    why Gemini did not answer them)."""
    return getattr(_tls, "google", (0, ""))


PARALLEL_MAX = 4


def parallel_slots(models=None) -> int:
    """2.7.2 (16/11): how many translate batches go out at the same time - one
    per free Gemini web account / key, at most PARALLEL_MAX (1 key: 1, as before)."""
    n = 0
    try:
        from . import gemini_web

        if gemini_web.available():
            n += sum(1 for a in gemini_web.accounts() if a.get("state") != "resting")
    except Exception:
        pass
    try:
        n += len([k for k in keys() if k not in _dead])
    except Exception:
        pass
    try:
        top = int(settings.get("gemini_parallel", PARALLEL_MAX))
    except (TypeError, ValueError):
        top = PARALLEL_MAX
    return max(1, min(max(1, top), n))


def same_as_next(todo, result, originals) -> List[int]:
    """Lines whose translation is (nearly) the next line's while their
    originals are not alike - a translation put on the wrong line."""
    from difflib import SequenceMatcher

    bad = []
    for a, b in zip(todo, todo[1:]):
        ta, tb = (result.get(a) or "").strip(), (result.get(b) or "").strip()
        if len(ta) < 6 or len(tb) < 6:
            continue
        alike_src = SequenceMatcher(None, originals[a] or "", originals[b] or "").ratio()
        if SequenceMatcher(None, ta, tb).ratio() >= 0.8 and alike_src < 0.5:
            bad.append(a)
            continue
        # 26/11 (2.7.10): "婉宁，你老公呢" (where is your husband) came out
        # "ស្អប់គាត់ មានរឿងអី?" - the next line's "恨他" (hate him), started the
        # same way as the next line's own "ស្អប់គាត់ ហើយម៉េចដែរ" (ratio 0.62)
        head = os.path.commonprefix([ta, tb]).rstrip()
        if len(head.replace(" ", "")) >= 6 and len(head) >= 0.4 * min(len(ta), len(tb)) \
                and alike_src < 0.3:
            bad.append(a)
    return bad


LAST_TRY_LINES = 20


def _last_try(i, out, source, target, title, names, context, who, models, should_stop) -> str:
    """One line Gemini left out, asked alone (with the lines before it). '' = no."""
    near = [(who(k) + a, b) for k, (a, b) in context if abs(k - i) <= CONTEXT_LINES]
    prompt = _prompt([(i + 1, who(i) + out[i])], source, target, title,
                     near[-CONTEXT_LINES:], names, [])
    try:
        with gemini_stats.work("Translate batch", 1):
            text, _ = generate([{"text": prompt}], should_stop=should_stop, models=models,
                               temperature=0.7, time_limit=90.0)
        data = _json(text)
    except InterruptedError:
        raise
    except QuotaError:
        return ""
    except Exception:
        return ""
    items = data.get("lines", data) if isinstance(data, dict) else data
    for it in items if isinstance(items, list) else []:
        try:
            if int(it.get("i")) - 1 != i:
                continue
        except (TypeError, ValueError, AttributeError):
            continue
        t = re.sub(r"^\s*\[[^\]]{1,60}\]\s*", "", str(it.get("t", ""))).strip()
        t = clean_foreign(t, target)
        if right_script(t, target) and not stray_english(out[i], t, target, names):
            return t
    return ""


def google_names(original: str, text: str, names: Dict[str, str], target: str) -> str:
    """17/11 (merged): Google wrote 红梅 as "Hongmei" in a Khmer line - the
    names of the story the original says are put in, in Khmer: when the line
    has one Latin word and the original one known name, that word is the name."""
    if target != "km" or not names or not text:
        return text
    said = [names[a] for a in names if a and a in (original or "") and names.get(a)]
    latin = re.findall(r"[A-Za-z][A-Za-z'\-]*(?:\s+[A-Z][a-z'\-]+)*", text)
    if len(said) == 1 and len(latin) == 1:
        return text.replace(latin[0], said[0], 1)
    return text


def google_lines_used() -> List[int]:
    """Which lines (indices into the lines given) Google Translate did last time."""
    return list(getattr(_tls, "google_ids", []))


def _translate_lines(out, todo, source, target, progress, should_stop, on_result, title,
                     batch, names, models, speakers=None, cast=None, ranks=None,
                     learned: str = "") -> List[str]:
    """speakers: who says each line (character labels), cast: label -> name,
    man / woman, rank (core/register.py) - the forms of address follow them;
    ranks: filled with the ranks the AI could tell."""
    from . import register
    from .translate import translate_lines as google_lines

    cast = cast or {}
    spoiled: Dict[int, str] = {}
    why: set = set()                    # finish reasons of the batches Gemini left empty
    who = (lambda i: register.speaker_tag(speakers[i], cast)) \
        if speakers and cast and len(speakers) == len(out) else (lambda i: "")

    me = threading.get_ident()
    result: Dict[int, str] = {}
    names = names if names is not None else {}
    context: List[Tuple[int, Tuple[str, str]]] = []
    queue: List[List[int]] = [todo[k:k + batch] for k in range(0, len(todo), batch)]
    n = max(1, len(todo))
    slots = parallel_slots(models)

    def build(ids):
        # 2.7.2 (16/11): batches go out side by side (one per free key / web
        # account) - the lines before are given with the translation done so
        # far, or as the original when that batch is still out
        p = todo.index(ids[0])
        before = [(who(i) + out[i], result.get(i, "")) for i in todo[max(0, p - CONTEXT_LINES):p]]
        last = todo.index(ids[-1])
        after = [out[i] for i in todo[last + 1:last + 1 + AFTER_LINES]]
        people = register.prompt_part(cast, target, [speakers[i] for i in ids]) \
            if speakers and cast and len(speakers) == len(out) else ""
        return _prompt([(i + 1, who(i) + out[i]) for i in ids], source, target, title,
                       before, names, after, people, learned)

    def ask(prompt, count):
        mine = threading.get_ident()
        with _lock:
            _job_of[mine] = me                  # the Router shows the key / model in use
        try:
            with gemini_stats.work("Translate batch", count):
                text, finish = generate([{"text": prompt}], should_stop=should_stop,
                                        models=models)
        finally:
            with _lock:
                _job_of.pop(mine, None)
        return text, finish, getattr(_tls, "key", ""), getattr(_tls, "model", "")

    def take(ids, text, finish, _k, _m):
        if finish == "MAX_TOKENS" and len(ids) > 1:     # cut off: halve and ask again
            h = len(ids) // 2
            queue[:0] = [ids[:h], ids[h:]]
            return
        try:
            data = _json(text)
        except ValueError:
            data = {}
        items = data.get("lines", data) if isinstance(data, dict) else data
        got = {}
        for it in items if isinstance(items, list) else []:
            try:
                i = int(it.get("i")) - 1
            except (TypeError, ValueError, AttributeError):
                continue
            t = re.sub(r"^\s*\[[^\]]{1,60}\]\s*", "", str(it.get("t", ""))).strip()
            stray = (stray_english(out[i], t, target, names)
                     or name_missing(out[i], t, names)) if i in ids else ""
            if i in ids and right_script(t, target) and not stray:
                got[i] = t
            elif i in ids and (foreign_bits(t, target) or stray):
                spoiled[i] = t                  # asked again; cleaned if it stays so
        if ranks is not None and isinstance(data, dict) and isinstance(data.get("ranks"), dict):
            for a, b in data["ranks"].items():
                if isinstance(a, str) and isinstance(b, str) and a.strip() in cast:
                    ranks.setdefault(a.strip(), b.strip().lower())
        if isinstance(data, dict) and isinstance(data.get("names"), dict):
            for a, b in data["names"].items():
                # 2.7.2 (merged 40-minute film, 13/11): "Zhao", "Shen Lan" came
                # back as names, went into the name list and from then on were
                # allowed in Khmer lines (93 lines) - a name must be in the
                # target script to be kept
                if isinstance(a, str) and isinstance(b, str) and a.strip() and b.strip() \
                        and right_script(b.strip(), target) and not is_family_word(a.strip()):
                    names.setdefault(a.strip(), b.strip())
        missing = [i for i in ids if i not in got]
        if not got and len(ids) > 7 and not set(ids) & spoiled.keys():
            # 2.7.2 (七零 EP001, 13/11): a whole batch came back empty (finish
            # SAFETY / OTHER, broken JSON) and Google Translate silently did 37
            # lines ("钱多多" -> "លុយច្រើន"): ask again in halves, so one line
            # Gemini will not answer does not cost the others
            why.add(finish or "no answer")
            h = len(ids) // 2
            queue[:0] = [ids[:h], ids[h:]]
            return
        if missing and len(missing) < len(ids) and len(ids) > 1:
            queue.insert(0, missing)                    # ask once more for the gaps
        count_lines(len(got))
        if got:
            with _lock:
                if me in _jobs:
                    _jobs[me]["done"] += len(got)
            if models:
                log(f"{title or 'Translation'} → Key {settings.mask(_k)}"
                    f" · {_m} · {len(got)} lines")
        for i, t in got.items():
            result[i] = t
            if on_result:
                on_result(i, t)
        context.extend((i, (out[i], got[i])) for i in ids if i in got)
        if progress:
            progress(int(95 * len(result) / n), f"Gemini translated {len(result)}/{len(todo)} lines")
        if missing and (len(missing) == len(ids) or len(ids) == 1):
            if not got and finish:
                why.add(finish)
            result.update({i: "" for i in missing if i not in result})

    from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

    workers = ThreadPoolExecutor(max_workers=slots, thread_name_prefix="gemini-batch")
    running: Dict[object, List[int]] = {}
    try:
        while queue or running:
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            while queue and len(running) < slots:
                ids = queue.pop(0)
                running[workers.submit(ask, build(ids), len(ids))] = ids
            done, _ = wait(list(running), timeout=0.5, return_when=FIRST_COMPLETED)
            for f in done:
                ids = running.pop(f)
                take(ids, *f.result())
    finally:
        workers.shutdown(wait=False, cancel_futures=True)
    for i in [i for i in todo if not result.get(i) and i in spoiled]:
        t = clean_foreign(spoiled[i], target)    # better than a line without the story
        for _n in range(5):                     # 2.7.2: "coi" - a stray word left
            w = stray_english(out[i], t, target, names)
            if not w:
                break
            t = re.sub(r"\s*\b" + re.escape(w) + r"\b\s*", " ", t).strip()
        if right_script(t, target):
            result[i] = t
            if on_result:
                on_result(i, t)
    # 19/11 (SenseVoice + Router): the line "收款22元" (50 s) came back with the
    # NEXT line's translation - two lines in a row said the same while their
    # originals differ: the first is asked again alone
    for i in same_as_next(todo, result, out):
        result.pop(i, None)
    rest = [i for i in todo if not result.get(i)]
    if rest and len(rest) <= LAST_TRY_LINES:
        # 2.7.2 (16/11, EP001): 2 lines went to Google with the keys working -
        # each one is asked once more alone, warmer, before Google takes it
        for i in list(rest):
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            t = _last_try(i, out, source, target, title, names, context, who, models,
                          should_stop)
            if t:
                result[i] = t
                rest.remove(i)
                if on_result:
                    on_result(i, t)
    _tls.google = (len(rest), ", ".join(sorted(why - {"STOP"})) or "") if rest else (0, "")
    _tls.google_ids = list(rest)
    if rest:
        if progress:
            progress(96, f"{len(rest)} lines left - Google Translate fills them")
        g = google_lines([out[i] for i in rest], source, target, should_stop=should_stop)
        for i, t in zip(rest, g):
            t = google_names(out[i], t, names, target)
            result[i] = t
            if on_result:
                on_result(i, t)
    final = [result.get(i, out[i]) if out[i] else "" for i in range(len(out))]
    if progress:
        progress(100, f"Translated {len(todo)} lines with Gemini"
                      + (f" ({len(rest)} by Google Translate)" if rest else ""))
    return final


# --------------------------------------------------------------------------- #
# speech-to-text
# --------------------------------------------------------------------------- #
def _wav_b64(audio: np.ndarray, sr: int = 16000) -> str:
    pcm = (np.clip(audio, -1, 1) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _secs(v) -> float:
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    parts = [float(p) for p in s.replace(",", ".").split(":") if p]
    t = 0.0
    for p in parts:
        t = t * 60 + p
    return t


def transcribe_piece(audio: np.ndarray, lang: Optional[str],
                     should_stop: Optional[Callable[[], bool]] = None
                     ) -> Tuple[List[Tuple[float, float, str]], str]:
    """Lines (start, end, text) in seconds from the start of `audio` (16 kHz)
    and the language code Gemini heard."""
    from .translate import LANGUAGES

    dur = len(audio) / 16000.0
    lname = LANGUAGES.get(lang, (lang, ""))[0] if lang else ""
    prompt = (f"Transcribe the speech in this {dur:.1f}-second audio clip from a video "
              f"{'in ' + lname + ' ' if lname else ''}exactly as spoken, in the ORIGINAL "
              "language (do not translate). One item per sentence / subtitle line, with its "
              "start and end time in seconds from the beginning of the clip. Leave out music, "
              "sound effects and noises. If nobody speaks, return an empty list.\n"
              'Answer ONLY with JSON: {"language": "<ISO 639-1 code>", '
              '"lines": [{"start": 0.0, "end": 1.5, "text": "..."}]}')
    with gemini_stats.work("AI check"):
        text, _ = generate([{"inline_data": {"mime_type": "audio/wav", "data": _wav_b64(audio)}},
                            {"text": prompt}], temperature=0.0, should_stop=should_stop)
    try:
        data = _json(text)
    except ValueError:
        return [], ""
    items = data.get("lines", []) if isinstance(data, dict) else data
    out = []
    for it in items if isinstance(items, list) else []:
        try:
            a, b = _secs(it.get("start", 0)), _secs(it.get("end", 0))
            t = str(it.get("text", "")).strip()
        except (TypeError, ValueError, AttributeError):
            continue
        a, b = max(0.0, min(a, dur)), max(0.0, min(b, dur))
        if t and b > a:
            out.append((a, b, t))
    return out, (data.get("language", "") if isinstance(data, dict) else "")
