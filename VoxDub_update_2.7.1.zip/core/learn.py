"""
learn.py - 2.7.1: the translation learns from the user's corrections.

When a translation line is changed by hand in the editor, the pair
(original line, AI translation, the user's translation) is kept. The next
translations with Gemini / Gemini Router get the closest of them as examples:
"the user corrected these before - make the same choices" (ខ្ញុំ -> កូន,
គូប្រកួត -> គូស្រករ ...).

Two lists, like the glossary:
  * the story's   corrections.json next to series_cast.json (Batch story)
  * my list       <settings dir>/corrections.json            (every video)
Only text is kept - never a key or a file.
"""

import json
import os
import re
import time
from typing import Dict, List, Sequence

from . import settings

FILE = "corrections.json"
MAX_KEPT = 80               # per list, the newest stay
MAX_EXAMPLES = 12           # given to one translation


def my_path() -> str:
    return os.path.join(settings.settings_dir(), FILE)


def story_path(series_cast_path: str) -> str:
    return os.path.join(os.path.dirname(series_cast_path), FILE) if series_cast_path else ""


def path_for(project) -> str:
    return story_path(getattr(project, "series_cast", "") or "") or my_path()


def load(path: str) -> List[dict]:
    if not path:
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        items = data.get("items", []) if isinstance(data, dict) else []
        return [i for i in items if isinstance(i, dict) and i.get("o") and i.get("b")]
    except (OSError, ValueError):
        return []


def save(path: str, items: List[dict]) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"version": 1, "items": items[-MAX_KEPT:]}, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def _core(t: str) -> str:
    return re.sub(r"[\s\W_]+", "", t or "")


def worth_keeping(before: str, after: str) -> bool:
    """A real correction: words changed, not only spaces / punctuation."""
    b, a = (before or "").strip(), (after or "").strip()
    return bool(b and a and _core(b) != _core(a))


def record(project, original: str, before: str, after: str) -> bool:
    """Keep one correction (the same original line keeps only its newest)."""
    original = (original or "").strip()
    if not original or not worth_keeping(before, after):
        return False
    path = path_for(project)
    items = [i for i in load(path) if i.get("o") != original]
    items.append({"o": original, "a": before.strip(), "b": after.strip(),
                  "t": int(time.time())})
    try:
        save(path, items)
    except OSError as e:
        print(f"[learn] not kept: {e}")
        return False
    return True


def forget(project, original: str) -> None:
    path = path_for(project)
    items = load(path)
    keep = [i for i in items if i.get("o") != original]
    if len(keep) != len(items):
        save(path, keep)


def _chars(t: str) -> set:
    t = _core(t)
    return set(t) | {t[i:i + 2] for i in range(len(t) - 1)}


def examples(project, lines: Sequence[str], k: int = MAX_EXAMPLES) -> List[Dict[str, str]]:
    """The corrections closest to these lines (shared words), newest first
    when equal; the story's before my list's."""
    story = load(story_path(getattr(project, "series_cast", "") or ""))
    mine = load(my_path())
    seen, pool = set(), []
    for rank, items in ((0, story), (1, mine)):
        for i in reversed(items):
            if i["o"] in seen:
                continue
            seen.add(i["o"])
            pool.append((rank, i))
    if not pool:
        return []
    here = set()
    for t in lines:
        here |= _chars(t)
    scored = []
    for n, (rank, i) in enumerate(pool):
        overlap = len(_chars(i["o"]) & here)
        scored.append((-overlap, rank, n, i))
    scored.sort(key=lambda x: x[:3])
    return [{"o": i["o"], "a": i.get("a", ""), "b": i["b"]} for *_x, i in scored[:k]]


def prompt_part(ex: List[Dict[str, str]]) -> str:
    if not ex:
        return ""
    rows = "\n".join(f"- {e['o']}  =>  {e['b']}" + (f"   (not: {e['a']})" if e.get("a") else "")
                     for e in ex)
    return ("\nThe user corrected these translations before - make the same choices of words, "
            "pronouns and forms of address in similar lines:\n" + rows + "\n")
