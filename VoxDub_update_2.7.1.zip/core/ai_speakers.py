"""
ai_speakers.py - 2.7.1: who says each line, asked to Gemini (voice + story).

The voice print groups (core/speakers.py) split one angry woman into 5
characters and gave a flight attendant the label of a passenger (3A号座位的代价
EP001, 12/11): an angry voice and a calm voice of the same person print far
apart. Gemini hears the episode AND reads the lines - who answers whom, who
says "my back is hurt" - and groups the lines by person.

One request per episode (the voices-only track when there is one, else the
original sound), only for videos up to MAX_SECONDS. When Gemini cannot be
asked, or its answer does not fit, the voice print groups stay as they are.
"""

import os
from typing import Dict, List, Optional, Tuple

import numpy as np

MAX_SECONDS = 600          # longer videos: the voice prints only
SR = 16000


def wanted(project) -> bool:
    from . import gemini, settings

    return bool(settings.get("ai_speakers", True)) and gemini.configured()


def _audio(project) -> Optional[np.ndarray]:
    from .media import read_wav

    work = getattr(project, "work_dir", "") or ""
    for p in (os.path.join(work, "voice_only_16k.wav"), project.original_audio):
        if p and os.path.isfile(p):
            a, sr = read_wav(p)
            if a.ndim > 1:
                a = a.mean(axis=1)
            if sr != SR:
                n = int(len(a) * SR / sr)
                a = np.interp(np.linspace(0, len(a), n, endpoint=False),
                              np.arange(len(a)), a).astype(np.float32)
            return a
    return None


def _prompt(segs, hint: List[int]) -> str:
    rows = "\n".join(
        f"{k + 1}. [{s.start:.1f}-{s.end:.1f}s] (voice group {hint[k] + 1}) {s.text.strip()}"
        for k, s in enumerate(segs))
    return f"""This is the sound of a drama episode and its {len(segs)} lines with their times.
Decide WHO says each line. Use the voices AND the story: who answers whom, what people say about themselves (an angry and a calm line can be the same person), how they address each other.
The "voice group" is a guess from voice prints only - it is often wrong (one person split in several groups, or two people in one group).

Lines:
{rows}

Answer ONLY with JSON:
{{"speakers": [{{"id": 1, "gender": "male|female", "role": "<2-4 words, e.g. woman passenger>"}}],
 "lines": [{{"i": 1, "s": 1}}, ...]}}
Give every line exactly one speaker id; the same person always has the same id."""


def ask(project, segs, hint: List[int], should_stop=None
        ) -> Optional[Tuple[List[int], Dict[int, dict]]]:
    """(speaker index per line 0.., {index: {gender, role}}) or None."""
    from . import gemini

    if not segs:
        return None
    audio = _audio(project)
    if audio is None or len(audio) / SR > MAX_SECONDS:
        return None
    end = min(len(audio), int((segs[-1].end + 1.0) * SR))
    parts = [{"inline_data": {"mime_type": "audio/wav", "data": gemini._wav_b64(audio[:end])}},
             {"text": _prompt(segs, hint)}]
    models = gemini.router_models() if project.translate_engine == "gemini-router" else None
    text, _ = gemini.generate(parts, temperature=0.0, max_tokens=8192,
                              should_stop=should_stop, models=models)
    data = gemini._json(text)
    if not isinstance(data, dict):
        return None
    ids: Dict[int, int] = {}
    for it in data.get("lines") or []:
        try:
            ids[int(it["i"]) - 1] = int(it["s"])
        except (KeyError, TypeError, ValueError):
            continue
    if any(k not in ids for k in range(len(segs))):
        return None                                 # it must place every line
    order = list(dict.fromkeys(ids[k] for k in range(len(segs))))
    if len(order) > max(2, len(segs) // 2 + 1):
        return None                                 # nonsense: almost one person per line
    idx = {s: n for n, s in enumerate(order)}
    info: Dict[int, dict] = {}
    for sp in data.get("speakers") or []:
        try:
            s = int(sp.get("id"))
        except (TypeError, ValueError, AttributeError):
            continue
        if s in idx:
            g = str(sp.get("gender", "")).lower()
            info[idx[s]] = {"gender": g if g in ("male", "female") else "",
                            "role": str(sp.get("role", "") or "").strip()[:40]}
    return [idx[ids[k]] for k in range(len(segs))], info
