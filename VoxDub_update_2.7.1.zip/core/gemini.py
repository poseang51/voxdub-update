"""
gemini.py - Google Gemini with YOUR OWN API key(s) (Google AI Studio).

Used for
  * Translation that follows the story: the model sees the lines around each
    batch, keeps names and forms of address the same all through the video
    and writes natural spoken dialogue for dubbing.
  * Speech-to-text (optional, instead of Whisper): the audio is sent in
    short pieces and the model writes down what is said.

Keys are kept in the user's settings on this computer only (never in a
project file). Several keys can be added (one per Google account / Cloud
project = one quota each): the requests go round-robin, and a key that hits
its quota (HTTP 429 / RESOURCE_EXHAUSTED) rests for a minute while the others
carry on.

Gemini 3 models are sent thinkingLevel "low", Gemini 2.5 thinkingBudget 0
(translation needs no long thinking and it costs time + output tokens); a
model that refuses the field is asked again without it.
"""

import base64
import io
import json
import re
import threading
import time
import wave
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from . import settings

API = "https://generativelanguage.googleapis.com/v1beta"
DEFAULT_MODEL = "gemini-2.5-flash"
SUGGESTED_MODELS = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro",
                    "gemini-3.6-flash"]
BATCH_LINES = 30
CONTEXT_LINES = 8
AFTER_LINES = 4                 # the lines that come next (understand, do not translate)
TIMEOUT = 120

Progress = Callable[[int, str], None]


class GeminiError(RuntimeError):
    pass


class QuotaError(GeminiError):
    pass


# --------------------------------------------------------------------------- #
# keys + model (settings)
# --------------------------------------------------------------------------- #
def keys() -> List[str]:
    ks = settings.get("gemini_keys", []) or []
    return [k.strip() for k in ks if isinstance(k, str) and k.strip()]


def set_keys(ks: Sequence[str]):
    settings.set("gemini_keys", list(dict.fromkeys(k.strip() for k in ks if k.strip())))


def model() -> str:
    return (settings.get("gemini_model", "") or DEFAULT_MODEL).strip()


def configured() -> bool:
    return bool(keys())


# --------------------------------------------------------------------------- #
# HTTP with key rotation
# --------------------------------------------------------------------------- #
_lock = threading.Lock()
_turn = {"i": 0}
# 2.6.14: Google's free quota is per key AND per model - the states are kept
# for each (key, model) pair; a refused key is refused for every model.
_rest: Dict[Tuple[str, str], float] = {}     # (key, model) -> may be used again at
_spent: Dict[Tuple[str, str], float] = {}    # (key, model) -> today's quota used, until
_dead: Dict[str, str] = {}                   # key -> why it was refused
_busy: Dict[str, int] = {}                   # key -> requests on the way now
_gone_models: Dict[str, str] = {}            # model -> why (404: not for these keys)
_tls = threading.local()                     # key / model the last generate() used

# The key states live on (gemini_keys_state.json next to settings.json - no key
# in it, only a fingerprint): a refused key is not tried again on every start,
# a used-up key waits for the daily reset, lines per key today are counted.
STATE_FILE = "gemini_keys_state.json"
_st: Dict[str, dict] = {}

# Gemini Router: the work goes round every key AND these models in turn
# used when Google cannot be asked which models the keys have (no internet)
ROUTER_MODELS = ["gemini-3.6-flash-lite", "gemini-3.5-flash", "gemini-3.5-flash-lite",
                 "gemini-2.5-flash", "gemini-2.5-flash-lite"]
# a fast text model of the keys: gemini-<version>-flash[-lite] (no preview / image / tts)
_FLASH = re.compile(r"^gemini-(\d+(?:\.\d+)?)-flash(-lite)?(?:-\d{3})?$")
_activity: List[Tuple[float, str]] = []      # (time, text) - newest last
_jobs: Dict[int, dict] = {}                  # thread id -> the translation it does


def fingerprint(key: str) -> str:
    import hashlib

    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def _pacific_now():
    """Google's free daily quota starts again at midnight, Pacific time."""
    import datetime as dt

    try:
        from zoneinfo import ZoneInfo

        return dt.datetime.now(ZoneInfo("America/Los_Angeles"))
    except Exception:                       # no tz database (old Windows Python)
        return dt.datetime.now(dt.timezone(dt.timedelta(hours=-8)))


def today() -> str:
    return _pacific_now().strftime("%Y-%m-%d")


def next_reset() -> float:
    import datetime as dt

    now = _pacific_now()
    midnight = (now + dt.timedelta(days=1)).replace(hour=0, minute=0, second=5, microsecond=0)
    return time.time() + (midnight - now).total_seconds()


def flash_models(names: Sequence[str]) -> List[str]:
    """The fast text models in a model list, newest first, flash before lite."""
    got = []
    for n in names:
        m = _FLASH.match(n or "")
        if m:
            got.append((-float(m.group(1)), bool(m.group(2)), n))
    return [n for *_k, n in sorted(got)]


def discover_models() -> List[str]:
    """2.7 (3A号座位的代价 EP026, 12/11): the Router's models were 2.5 / 2.0 -
    Google had retired them (404), so only gemini-3.6-flash was left and
    every key ran out after 25 episodes. The models are now asked from
    Google (once a day, kept in the settings)."""
    found = settings.get("router_found") or {}
    if isinstance(found, dict) and found.get("day") == today() and found.get("models"):
        return list(found["models"])
    ks = [k for k in keys() if k not in _dead]
    if not ks:
        return []
    try:
        ms = flash_models(list_models(ks[0]))
    except Exception as e:                      # no internet: the list we know
        print(f"[gemini] model list not read: {e}")
        return []
    if ms:
        settings.set("router_found", {"day": today(), "models": ms})
    return ms


def router_models(ask_google: bool = True) -> List[str]:
    """The user's list (Settings › Gemini › Router), else the model of
    Settings + the fast models the keys have. ask_google=False: no network
    (the Settings window), the list found today or the known one."""
    ms = settings.get("router_models") or []
    ms = [m.strip() for m in ms if isinstance(m, str) and m.strip()]
    if ms:
        return ms
    if ask_google:
        found = discover_models()
    else:
        f = settings.get("router_found") or {}
        found = list(f.get("models") or []) if isinstance(f, dict) else []
    return list(dict.fromkeys([model()] + (found or ROUTER_MODELS)))[:6]


def set_router_models(ms: Sequence[str]):
    settings.set("router_models", list(dict.fromkeys(m.strip() for m in ms if m.strip())))


def when_out() -> str:
    """What happens when every key (and model) is used up: 'google' / 'stop'."""
    return "stop" if settings.get("gemini_when_out", "google") == "stop" else "google"


def log(text: str):
    with _lock:
        _activity.append((time.time(), text))
        del _activity[:-200]


def activity(n: int = 50) -> List[Tuple[float, str]]:
    with _lock:
        return list(_activity[-n:])


_view = {"models": None}


def view_models() -> List[str]:
    """The models the key panel shows: the ones the last translation used."""
    return list(_view["models"] or [model()])


def jobs() -> List[dict]:
    with _lock:
        return [dict(j) for j in _jobs.values()]


def _state_path() -> str:
    import os

    return os.path.join(settings.settings_dir(), STATE_FILE)


def _load_state():
    """Once: refused / used-up keys of earlier runs go back in the queue state."""
    if _st.get("_loaded"):
        return
    data = {}
    try:
        with open(_state_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        pass
    if not isinstance(data, dict):
        data = {}
    _st.clear()
    _st.update({"_loaded": True, "day": data.get("day", ""),
                "lines": dict(data.get("lines") or {}),
                "refused": dict(data.get("refused") or {}),
                "spent": dict(data.get("spent") or {})})
    if _st["day"] != today():
        _st.update({"day": today(), "lines": {}, "spent": {}})
    by_fp = {fingerprint(k): k for k in keys()}
    now = time.time()
    for fp, why in _st["refused"].items():
        if fp in by_fp:
            _dead[by_fp[fp]] = str(why)
    for name, until in list(_st["spent"].items()):
        fp, _, m = name.partition("|")
        try:
            until = float(until)
        except (TypeError, ValueError):
            continue
        if fp in by_fp and m and until > now:
            _spent[(by_fp[fp], m)] = until


def _save_state():
    import os

    data = {k: v for k, v in _st.items() if not k.startswith("_")}
    try:
        os.makedirs(settings.settings_dir(), exist_ok=True)
        tmp = _state_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=1)
        os.replace(tmp, _state_path())
    except OSError:
        pass


def _new_day():
    if _st.get("day") != today():
        _st.update({"day": today(), "lines": {}, "spent": {}})
        _spent.clear()


def _mark_refused(key: str, why: str):
    with _lock:
        _load_state()
        _dead[key] = why
        _st["refused"][fingerprint(key)] = why[:200]
        _save_state()
    log(f"🔴 Key {settings.mask(key)} refused by Google – taken out, replace it")


def _mark_spent(key: str, m: str):
    with _lock:
        _load_state()
        _new_day()
        until = next_reset()
        _spent[(key, m)] = until
        _st["spent"][f"{fingerprint(key)}|{m}"] = until
        _save_state()
    log(f"🟡 Key {settings.mask(key)} · {m}: today's quota used")


def _mark_ok(key: str):
    """The key answered: it is not refused (any more) - e.g. after Test keys."""
    if key in _dead or fingerprint(key) in _st.get("refused", {}):
        with _lock:
            _dead.pop(key, None)
            _st.get("refused", {}).pop(fingerprint(key), None)
            _save_state()


def count_lines(n: int, key: Optional[str] = None):
    """Lines translated by a key today (shown in the key panel)."""
    key = key or getattr(_tls, "key", None)
    if not key or n <= 0:
        return
    with _lock:
        _load_state()
        _new_day()
        fp = fingerprint(key)
        _st["lines"][fp] = int(_st["lines"].get(fp, 0)) + int(n)
        _save_state()


def forget(key: str):
    """A key removed in Settings: its state goes too."""
    with _lock:
        _load_state()
        fp = fingerprint(key)
        _st["refused"].pop(fp, None)
        _st["lines"].pop(fp, None)
        for name in [n for n in _st["spent"] if n.startswith(fp + "|")]:
            _st["spent"].pop(name)
        _dead.pop(key, None)
        for d in (_spent, _rest):
            for pair in [p for p in d if p[0] == key]:
                d.pop(pair)
        _save_state()


READY, BUSY, RESTING, SPENT, REFUSED = "ready", "busy", "resting", "spent", "refused"


def _usable(k: str, m: str, now: float) -> bool:
    return k not in _dead and _spent.get((k, m), 0) <= now and _rest.get((k, m), 0) <= now


def status(models: Optional[Sequence[str]] = None) -> List[dict]:
    """One dict per key, in the order of Settings: mask, state, lines today,
    why (refused), until (resting / spent), models_left (of `models`, the
    Gemini model or the router's). Never the key itself."""
    with _lock:
        _load_state()
        _new_day()
        now = time.time()
        ms = [m for m in (models or [model()]) if m not in _gone_models] or [model()]
        out = []
        for k in keys():
            fp = fingerprint(k)
            spent = [_spent[(k, m)] for m in ms if _spent.get((k, m), 0) > now]
            rest = [_rest[(k, m)] for m in ms if _rest.get((k, m), 0) > now]
            left = sum(_usable(k, m, now) for m in ms)
            d = {"fp": fp, "mask": settings.mask(k), "lines": int(_st["lines"].get(fp, 0)),
                 "why": "", "until": 0.0, "busy": _busy.get(k, 0),
                 "models_left": 0 if k in _dead else left, "models": len(ms)}
            if k in _dead:
                d.update(state=REFUSED, why=_dead[k])
            elif len(spent) == len(ms):
                d.update(state=SPENT, until=min(spent))
            elif _busy.get(k, 0) > 0:
                d["state"] = BUSY
            elif not left:
                d.update(state=RESTING, until=min(rest + spent))
            else:
                d["state"] = READY
            out.append(d)
        return out


def _thinking(m: str) -> Optional[dict]:
    m = m.lower()
    if m.startswith("gemini-3"):
        return {"thinkingLevel": "low"}
    if m.startswith("gemini-2.5") and "pro" not in m:
        return {"thinkingBudget": 0}
    return None


def _http(url: str, body: Optional[dict], timeout: float = TIMEOUT) -> Tuple[int, dict]:
    import requests

    if body is None:
        r = requests.get(url, timeout=timeout)
    else:
        r = requests.post(url, json=body, timeout=timeout)
    try:
        data = r.json()
    except ValueError:
        data = {"error": {"message": r.text[:300]}}
    return r.status_code, data


def _err_text(data: dict) -> str:
    e = data.get("error") if isinstance(data, dict) else None
    if isinstance(e, dict):
        return f"{e.get('status', '')} {e.get('message', '')}".strip()
    return str(data)[:300]


def _daily(data: dict) -> bool:
    """429 because the quota for the whole DAY is used (not the minute)."""
    t = json.dumps(data).lower()
    return "perday" in t or "per day" in t or "requests_per_day" in t


def _retry_after(data: dict, default: float) -> float:
    try:
        for d in (data.get("error") or {}).get("details") or []:
            v = d.get("retryDelay")
            if v:
                return max(5.0, min(120.0, float(str(v).rstrip("s"))))
    except (AttributeError, TypeError, ValueError):
        pass
    return default


def _next_pair(pool: List[str], ms: List[str]) -> Optional[Tuple[str, str]]:
    """The next (key, model) that may be asked: the first model in the list
    that any key still has, keys in turn."""
    with _lock:
        _load_state()
        _new_day()
        now = time.time()
        for m in ms:
            if m in _gone_models:
                continue
            for _ in range(len(pool)):
                k = pool[_turn["i"] % len(pool)]
                _turn["i"] += 1
                if _usable(k, m, now):
                    return k, m
    return None


def _out_of_keys(pool: List[str], ms: List[str]) -> Optional[Exception]:
    """Every key refused or used up for today (every model): say it at once -
    the caller goes on with Google Translate (or stops) instead of waiting."""
    now = time.time()
    live = [m for m in ms if m not in _gone_models]
    if not live:
        return GeminiError("Model not found: " + "; ".join(
            f"{m} ({_gone_models[m][:80]})" for m in ms))
    if not all(k in _dead or all(_spent.get((k, m), 0) > now for m in live) for k in pool):
        return None
    spent = [k for k in pool if k not in _dead]
    if spent:
        hrs = max(1, round((min(_spent[(k, m)] for k in spent for m in live) - now) / 3600))
        what = f"{len(live)} models" if len(live) > 1 else live[0]
        return QuotaError(f"All Gemini keys have used today's quota ({len(spent)} used up, "
                          f"{len(pool) - len(spent)} refused; {what}) – free again in about "
                          f"{hrs} h")
    return GeminiError(f"Gemini key refused: {_dead[pool[0]]} – all {len(pool)} keys")


def generate(parts: List[dict], want_json: bool = True, max_tokens: int = 16384,
             temperature: float = 0.3, key_list: Optional[List[str]] = None,
             model_name: str = "", should_stop: Optional[Callable[[], bool]] = None,
             fresh: bool = False, models: Optional[Sequence[str]] = None
             ) -> Tuple[str, str]:
    """One generateContent call. Returns (text, finishReason).
    models: the Gemini Router - every key with the first model, then the next...
    fresh: ask with key_list[0] once, whatever its state (Test keys)."""
    pool = key_list if key_list is not None else keys()
    if not pool:
        raise GeminiError("No Gemini API key – add one in Settings › AI engines & API keys")
    ms = list(dict.fromkeys(models)) if models else [model_name or model()]
    no_think = set()
    last = ""
    deadline = time.time() + 300
    while time.time() < deadline:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        pair = (pool[0], ms[0]) if fresh else _next_pair(pool, ms)
        if pair is None:
            gone = _out_of_keys(pool, ms)
            if gone:
                raise gone
            now = time.time()
            soon = [_rest[(k, m)] for k in pool for m in ms
                    if _rest.get((k, m), 0) > now and _spent.get((k, m), 0) <= now
                    and k not in _dead]
            wait = max(1.0, (min(soon) if soon else now + 1) - now)
            if wait > 90:
                raise QuotaError(f"All Gemini keys are over their quota: {last}")
            time.sleep(min(wait, 5.0))      # every key is resting for a minute
            continue
        key, m = pair
        cfg = {"temperature": temperature, "maxOutputTokens": max_tokens}
        if want_json:
            cfg["responseMimeType"] = "application/json"
        think = None if m in no_think else _thinking(m)
        if think:
            cfg["thinkingConfig"] = think
        body = {"contents": [{"role": "user", "parts": parts}], "generationConfig": cfg}
        with _lock:
            _busy[key] = _busy.get(key, 0) + 1
            job = _jobs.get(threading.get_ident())
            if job is not None:
                job.update(key=settings.mask(key), model=m)
        try:
            code, data = _http(f"{API}/models/{m}:generateContent?key={key}", body)
        except Exception as e:                  # network
            last = str(e)[:200]
            if fresh:
                raise GeminiError(last)
            time.sleep(3)
            continue
        finally:
            with _lock:
                _busy[key] = max(0, _busy.get(key, 0) - 1)
        if code == 200:
            _tls.key, _tls.model = key, m
            _mark_ok(key)
            cands = data.get("candidates") or []
            if not cands:
                fb = data.get("promptFeedback", {})
                raise GeminiError(f"Gemini returned nothing ({fb.get('blockReason', 'blocked')})")
            c = cands[0]
            text = "".join(p.get("text", "") for p in (c.get("content") or {}).get("parts", [])
                           if not p.get("thought"))
            return text, c.get("finishReason", "")
        last = _err_text(data)
        if code == 400 and "thinking" in last.lower() and "thinkingConfig" in cfg:
            no_think.add(m)                     # this model does not take the field
            continue
        if code in (429, 503) or "RESOURCE_EXHAUSTED" in last:
            if code == 429 and _daily(data):
                _mark_spent(key, m)             # until Google's daily reset
                print(f"[gemini] key {settings.mask(key)} · {m}: today's quota is used")
            else:
                with _lock:
                    _rest[(key, m)] = time.time() + (_retry_after(data, 60) if code == 429
                                                     else 10)
            if fresh:
                raise QuotaError(f"Gemini quota: {last}")
            continue
        bad_key = (code in (401, 403) and "quota" not in last.lower()) or (
            code == 400 and ("api key not valid" in last.lower()
                             or "api_key_invalid" in last.lower()))
        if bad_key:
            # one dead key (deleted / disabled project) must not stop the work
            # while other keys are fine - and not on the next starts either,
            # until Test keys says it works again
            _mark_refused(key, f"{code} {last}")
            if fresh or all(k in _dead for k in pool):
                raise GeminiError(f"Gemini key refused ({code}): {last}"
                                  + (f" – all {len(pool)} keys" if len(pool) > 1 else ""))
            print(f"[gemini] key {settings.mask(key)} was refused ({code}) – taken out of "
                  f"the queue, replace it in Settings › Gemini; "
                  f"{len(pool) - sum(k in _dead for k in pool)} keys left")
            continue
        if code == 404:
            if len(ms) > 1 and not fresh:       # the router goes on with the next model
                _gone_models[m] = last
                log(f"⚪ Model {m} is not available for these keys – skipped")
                continue
            raise GeminiError(f"Model '{m}' not found – choose another model ({last})")
        if code >= 500:
            time.sleep(3)
            continue
        raise GeminiError(f"Gemini error {code}: {last}")
    raise GeminiError(f"Gemini did not answer: {last}")


def test_key(key: str, model_name: str = "") -> str:
    """'' when the key + model work, else the reason."""
    try:
        text, _ = generate([{"text": "Reply with the single word OK."}], want_json=False,
                           max_tokens=256, key_list=[key], model_name=model_name, fresh=True)
        return "" if text.strip() else "empty answer"
    except Exception as e:
        return str(e)


def list_models(key: str) -> List[str]:
    code, data = _http(f"{API}/models?key={key}&pageSize=200", None, timeout=30)
    if code != 200:
        raise GeminiError(_err_text(data))
    out = []
    for m in data.get("models", []):
        if "generateContent" in (m.get("supportedGenerationMethods") or []):
            out.append(m.get("name", "").replace("models/", ""))
    return sorted((m for m in out if m.startswith("gemini")), reverse=True)


def _json(text: str):
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)
    try:
        return json.loads(text)
    except ValueError:
        m = re.search(r"[\[{].*[\]}]", text, re.S)
        if m:
            return json.loads(m.group(0))
        raise


# --------------------------------------------------------------------------- #
# translation
# --------------------------------------------------------------------------- #
_SCRIPT = {"km": r"[ក-៿]", "th": r"[฀-๿]", "lo": r"[຀-໿]",
           "my": r"[က-႟]", "zh": r"[一-鿿]", "ja": r"[぀-ヿ一-鿿]",
           "ko": r"[가-힯]", "vi": r"[A-Za-zÀ-ỹ]", "en": r"[A-Za-z]"}


def right_script(text: str, lang: str) -> bool:
    """A Khmer voice cannot read Chinese: a 'translation' still in the wrong
    script is treated as missing."""
    pat = _SCRIPT.get(lang)
    return bool(text.strip()) and (pat is None or re.search(pat, text) is not None) \
        and not foreign_bits(text, lang)


# 2.7: a Khmer line with Thai / Chinese letters in it ("ក្នុងเมื่อមេឃ") or English
# glued to a Khmer word ("ជាតិline") - the voice cannot read it: asked again
_FOREIGN = {"km": re.compile(r"[\u0e00-\u0eff\u3040-\u30ff\u4e00-\u9fff]"
                             r"|[\u1780-\u17ff][A-Za-z]|[A-Za-z][\u1780-\u17ff]")}


def stray_english(source: str, text: str, lang: str, names=None) -> str:
    """2.7 (3A号座位的代价 EP001, 12/11): "ដូរ seat ជាមួយខ្ញុំ" - an English word
    in a Khmer line that the original line does not have ("hello", "3A",
    "32D" in the original stay) and that is no name in the glossary."""
    if lang != "km":
        return ""
    src = (source or "").lower()
    keep = " ".join(str(v) for v in (names or {}).values()).lower()
    for w in re.findall(r"[A-Za-z]{2,}", text or ""):
        if w.lower() not in src and w.lower() not in keep:
            return w
    return ""


def clean_foreign(text: str, lang: str) -> str:
    """Take the Thai / Chinese letters and glued English out of a Khmer line."""
    if lang != "km":
        return text
    t = re.sub(r"[\u0e00-\u0eff\u3040-\u30ff\u4e00-\u9fff]+", "", text or "")
    t = re.sub(r"(?<=[\u1780-\u17ff])[A-Za-z]+|[A-Za-z]+(?=[\u1780-\u17ff])", "", t)
    return re.sub(r"\s{2,}", " ", t).strip()


def foreign_bits(text: str, lang: str) -> str:
    """The first piece of another script in a translation ('' = clean)."""
    pat = _FOREIGN.get(lang)
    m = pat.search(text or "") if pat else None
    return m.group(0) if m else ""


def _prompt(lines: List[Tuple[int, str]], src: str, tgt: str, title: str,
            context: List[Tuple[str, str]], names: Dict[str, str],
            after: Optional[List[str]] = None, people: str = "", learned: str = "") -> str:
    from .translate import LANGUAGES

    tname = LANGUAGES.get(tgt, (tgt, ""))[0]
    sname = LANGUAGES.get(src, (src, ""))[0] if src and src != "auto" else "the original language"
    ctx = "\n".join(f"- {s}  =>  {t}" for s, t in context) or "(start of the video)"
    nxt = "\n".join(f"- {s}" for s in (after or [])) or "(end of the video)"
    gl = "\n".join(f"- {a} = {b}" for a, b in list(names.items())[:60]) or "(none yet)"
    numbered = "\n".join(f"{i}: {t}" for i, t in lines)
    return f"""You translate the dialogue of a video{f' titled "{title}"' if title else ''} from {sname} into {tname} for DUBBING (an AI voice will speak your lines over the picture).

Rules:
- Natural, spoken {tname} as people really talk in a TV drama - not word-for-word, not formal writing.
- Follow the story: use the earlier lines to understand who speaks to whom; choose kinship terms, pronouns and politeness that fit the relationship.
- Keep every person's name the SAME all through the video (use the name list); write names the way {tname} viewers read them.
- Keep each line about as short as the original so it fits the same time. Do not add explanations.
- Translate every line, one output per input number. Never leave a line in {sname}.{chr(10) + '- Write only Khmer script: no Thai, Chinese or English words (only names from the name list may stay as they are).' if tgt == 'km' else ''}

Names so far (ALWAYS use exactly these translations):
{gl}
{people}{learned}
Earlier lines (original => translation):
{ctx}

The lines that come right after the ones to translate (only to understand the meaning - do NOT translate them):
{nxt}

Translate these lines:
{numbered}

Answer ONLY with JSON: {{"lines": [{{"i": <number>, "t": "<translation>"}}, ...], "names": {{"<original name>": "<name in {tname}>"}}{', "ranks": {"<label>": "emperor|royal|noble|common|servant|monk"}' if people else ''}}}
In "names" put EVERY person's name in these lines that is not in the name list yet - full names (沈玉兰), surname + title (沈女士, 顾先生, 王总) and nicknames - written in the original script, with the {tname} you used; {{}} when there is none.
Never put the [label: who] part in a translation."""


def translate_lines(lines: List[str], source: str, target: str,
                    progress: Optional[Progress] = None,
                    should_stop: Optional[Callable[[], bool]] = None,
                    on_result: Optional[Callable[[int, str], None]] = None,
                    title: str = "", batch: int = BATCH_LINES,
                    names: Optional[Dict[str, str]] = None,
                    models: Optional[Sequence[str]] = None,
                    speakers: Optional[List[str]] = None,
                    cast: Optional[Dict[str, dict]] = None,
                    ranks: Optional[Dict[str, str]] = None,
                    learned: str = "") -> List[str]:
    """Same contract as translate.translate_lines (1:1, on_result as batches
    finish). Lines Gemini leaves out or answers in the wrong script are
    translated by Google Translate at the end (and counted in the report).
    names: the glossary (kept as given); the names Gemini chooses are added
    to this same dict, so the caller can keep them for the next episodes."""
    out = [(t or "").strip() for t in lines]
    todo = [i for i, t in enumerate(out) if t]
    me = threading.get_ident()
    _view["models"] = list(models) if models else None
    with _lock:
        _jobs[me] = {"title": title or "Translation", "done": 0, "total": len(todo),
                     "key": "", "model": "", "router": bool(models), "start": time.time()}
    try:
        return _translate_lines(out, todo, source, target, progress, should_stop, on_result,
                                title, batch, names, models, speakers, cast, ranks, learned)
    finally:
        with _lock:
            _jobs.pop(me, None)


def _translate_lines(out, todo, source, target, progress, should_stop, on_result, title,
                     batch, names, models, speakers=None, cast=None, ranks=None,
                     learned: str = "") -> List[str]:
    """speakers: who says each line (character labels), cast: label -> name,
    man / woman, rank (core/register.py) - the forms of address follow them;
    ranks: filled with the ranks the AI could tell."""
    from . import register
    from .translate import translate_lines as google_lines

    cast = cast or {}
    spoiled: Dict[int, str] = {}
    who = (lambda i: register.speaker_tag(speakers[i], cast)) \
        if speakers and cast and len(speakers) == len(out) else (lambda i: "")

    me = threading.get_ident()
    result: Dict[int, str] = {}
    names = names if names is not None else {}
    context: List[Tuple[int, Tuple[str, str]]] = []
    queue: List[List[int]] = [todo[k:k + batch] for k in range(0, len(todo), batch)]
    n = max(1, len(todo))
    while queue:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        ids = queue.pop(0)
        last = todo.index(ids[-1])
        after = [out[i] for i in todo[last + 1:last + 1 + AFTER_LINES]]
        people = register.prompt_part(cast, target, [speakers[i] for i in ids]) \
            if speakers and cast and len(speakers) == len(out) else ""
        prompt = _prompt([(i + 1, who(i) + out[i]) for i in ids], source, target, title,
                         [(who(i) + a, b) for i, (a, b) in context[-CONTEXT_LINES:]],
                         names, after, people, learned)
        text, finish = generate([{"text": prompt}], should_stop=should_stop, models=models)
        if finish == "MAX_TOKENS" and len(ids) > 1:     # cut off: halve and ask again
            h = len(ids) // 2
            queue[:0] = [ids[:h], ids[h:]]
            continue
        try:
            data = _json(text)
        except ValueError:
            data = {}
        items = data.get("lines", data) if isinstance(data, dict) else data
        got = {}
        for it in items if isinstance(items, list) else []:
            try:
                i = int(it.get("i")) - 1
            except (TypeError, ValueError, AttributeError):
                continue
            t = re.sub(r"^\s*\[[^\]]{1,60}\]\s*", "", str(it.get("t", ""))).strip()
            stray = stray_english(out[i], t, target, names) if i in ids else ""
            if i in ids and right_script(t, target) and not stray:
                got[i] = t
            elif i in ids and (foreign_bits(t, target) or stray):
                spoiled[i] = t                  # asked again; cleaned if it stays so
        if ranks is not None and isinstance(data, dict) and isinstance(data.get("ranks"), dict):
            for a, b in data["ranks"].items():
                if isinstance(a, str) and isinstance(b, str) and a.strip() in cast:
                    ranks.setdefault(a.strip(), b.strip().lower())
        if isinstance(data, dict) and isinstance(data.get("names"), dict):
            for a, b in data["names"].items():
                if isinstance(a, str) and isinstance(b, str) and a.strip() and b.strip():
                    names.setdefault(a.strip(), b.strip())
        missing = [i for i in ids if i not in got]
        if missing and len(missing) < len(ids) and len(ids) > 1:
            queue.insert(0, missing)                    # ask once more for the gaps
        count_lines(len(got))
        if got:
            with _lock:
                if me in _jobs:
                    _jobs[me]["done"] += len(got)
            if models:
                log(f"{title or 'Translation'} → Key {settings.mask(getattr(_tls, 'key', ''))}"
                    f" · {getattr(_tls, 'model', '')} · {len(got)} lines")
        for i, t in got.items():
            result[i] = t
            if on_result:
                on_result(i, t)
        context += [(i, (out[i], got[i])) for i in ids if i in got]
        if progress:
            progress(int(95 * len(result) / n), f"Gemini translated {len(result)}/{len(todo)} lines")
        if missing and (len(missing) == len(ids) or len(ids) == 1):
            result.update({i: "" for i in missing if i not in result})
    for i in [i for i in todo if not result.get(i) and i in spoiled]:
        t = clean_foreign(spoiled[i], target)    # better than a line without the story
        if right_script(t, target):
            result[i] = t
            if on_result:
                on_result(i, t)
    rest = [i for i in todo if not result.get(i)]
    if rest:
        if progress:
            progress(96, f"{len(rest)} lines left - Google Translate fills them")
        g = google_lines([out[i] for i in rest], source, target, should_stop=should_stop)
        for i, t in zip(rest, g):
            result[i] = t
            if on_result:
                on_result(i, t)
    final = [result.get(i, out[i]) if out[i] else "" for i in range(len(out))]
    if progress:
        progress(100, f"Translated {len(todo)} lines with Gemini"
                      + (f" ({len(rest)} by Google Translate)" if rest else ""))
    return final


# --------------------------------------------------------------------------- #
# speech-to-text
# --------------------------------------------------------------------------- #
def _wav_b64(audio: np.ndarray, sr: int = 16000) -> str:
    pcm = (np.clip(audio, -1, 1) * 32767).astype(np.int16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm.tobytes())
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _secs(v) -> float:
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip()
    parts = [float(p) for p in s.replace(",", ".").split(":") if p]
    t = 0.0
    for p in parts:
        t = t * 60 + p
    return t


def transcribe_piece(audio: np.ndarray, lang: Optional[str],
                     should_stop: Optional[Callable[[], bool]] = None
                     ) -> Tuple[List[Tuple[float, float, str]], str]:
    """Lines (start, end, text) in seconds from the start of `audio` (16 kHz)
    and the language code Gemini heard."""
    from .translate import LANGUAGES

    dur = len(audio) / 16000.0
    lname = LANGUAGES.get(lang, (lang, ""))[0] if lang else ""
    prompt = (f"Transcribe the speech in this {dur:.1f}-second audio clip from a video "
              f"{'in ' + lname + ' ' if lname else ''}exactly as spoken, in the ORIGINAL "
              "language (do not translate). One item per sentence / subtitle line, with its "
              "start and end time in seconds from the beginning of the clip. Leave out music, "
              "sound effects and noises. If nobody speaks, return an empty list.\n"
              'Answer ONLY with JSON: {"language": "<ISO 639-1 code>", '
              '"lines": [{"start": 0.0, "end": 1.5, "text": "..."}]}')
    text, _ = generate([{"inline_data": {"mime_type": "audio/wav", "data": _wav_b64(audio)}},
                        {"text": prompt}], temperature=0.0, should_stop=should_stop)
    try:
        data = _json(text)
    except ValueError:
        return [], ""
    items = data.get("lines", []) if isinstance(data, dict) else data
    out = []
    for it in items if isinstance(items, list) else []:
        try:
            a, b = _secs(it.get("start", 0)), _secs(it.get("end", 0))
            t = str(it.get("text", "")).strip()
        except (TypeError, ValueError, AttributeError):
            continue
        a, b = max(0.0, min(a, dur)), max(0.0, min(b, dur))
        if t and b > a:
            out.append((a, b, t))
    return out, (data.get("language", "") if isinstance(data, dict) else "")
