"""
register.py - 2.7: who speaks to whom - rank of every character, so the
translation uses the right Khmer forms of address (រាជសព្ទ in the palace,
ទូលបង្គំ / ខ្ញុំម្ចាស់ from servants, អាត្មា for a monk ...).

  * A character's rank is chosen in 👥 Characters ("Auto" = the AI decides).
  * Gemini / Gemini Router get the characters (name, man / woman, rank) and
    who says every line; they answer the ranks they could tell, and those are
    kept for the character (rank_ai) - in the series too, so the next episodes
    start with them.
  * Google Translate has no context: ranks are not used there.
"""

from typing import Dict, List, Optional

RANKS = [
    ("", "Auto – the AI decides"),
    ("emperor", "King / Emperor  (ស្តេច · អធិរាជ)"),
    ("royal", "Royal family  (មហាក្សត្រី · ព្រះជាយា · ព្រះអង្គម្ចាស់ · ព្រះនាង)"),
    ("noble", "Official / master / lady  (មន្ត្រី · លោកម្ចាស់ · អ្នកនាង)"),
    ("common", "Ordinary person"),
    ("servant", "Servant / maid / guard  (អ្នកបម្រើ · ទាសី)"),
    ("monk", "Monk / nun  (ព្រះសង្ឃ · ដូនជី)"),
]
RANK_IDS = [k for k, _ in RANKS if k]


def rank_of(c: dict) -> str:
    """The user's choice wins, then what the AI found."""
    r = (c or {}).get("rank") or (c or {}).get("rank_ai") or ""
    return r if r in RANK_IDS else ""


def cast_for_prompt(project) -> Dict[str, dict]:
    """label -> {name, gender, rank} for the characters that speak."""
    from . import speakers

    cast = getattr(project, "cast", {}) or {}
    out = {}
    for lab, c in cast.items():
        name = speakers.display(project, lab)
        if c.get("role") and speakers.is_auto_name(c.get("name") or ""):
            name += f" ({c['role']})"           # 2.7.1: "Woman 2 (flight attendant)"
        out[lab] = {"name": name, "gender": c.get("gender") or "", "rank": rank_of(c)}
    return out


def speaker_tag(label: str, cast: Dict[str, dict]) -> str:
    c = cast.get(label or "")
    if not c:
        return ""
    sign = {"male": "man", "female": "woman"}.get(c.get("gender"), "")
    bits = [c["name"]] + [b for b in (sign, c.get("rank")) if b]
    return f"[{label}: {', '.join(bits)}] "


def prompt_part(cast: Dict[str, dict], target: str, used: List[str]) -> str:
    """The characters + (for Khmer) the rules of address, for the prompt."""
    used = [lab for lab in dict.fromkeys(used) if lab in cast]
    if not used:
        return ""
    unknown = 'unknown - tell it in "ranks" if the lines show it'
    who = "\n".join(f"- {lab}: {cast[lab]['name']}"
                    + (f", {cast[lab]['gender']}" if cast[lab]['gender'] else "")
                    + f", rank: {cast[lab]['rank'] or unknown}"
                    for lab in used)
    text = f"""
Characters (a line starts with [label: who] = who says it):
{who}
"""
    if target == "km":
        text += KHMER_RULES
    return text


KHMER_RULES = """
Khmer forms of address - choose them from the ranks of the speaker and of the person spoken to:
- To or about the king / emperor: royal vocabulary (រាជសព្ទ) - ព្រះករុណា, ព្រះអង្គ, ទ្រង់; the speaker calls himself ទូលបង្គំ (a formal report: ក្រាបបង្គំទូល). Royal words: យាង (go/come), សោយ (eat), ផ្ទំ (sleep), ព្រះរាជបញ្ជា (order), ព្រះទ័យ (mind/heart), ព្រះរាជវាំង (palace).
- To royal family (queen, consort 王妃 = ព្រះជាយា, prince, princess): ព្រះនាង / ព្រះអង្គ / ទ្រង់; the speaker: ទូលបង្គំ or ខ្ញុំម្ចាស់.
- The king / emperor and royals speaking to lower people: call themselves យើង, the other ឯង / អ្នក or the name.
- Servants, maids, guards to their masters: ខ្ញុំម្ចាស់ / ខ្ញុំបាទ (man); call them លោកម្ចាស់, អ្នកនាង, ព្រះនាង as fits; "yes" = ករុណា (to royals), បាទ / ចាស (to others).
- Monks: the monk calls himself អាត្មា; people call him ព្រះតេជព្រះគុណ / លោកម្ចាស់ and themselves ខ្ញុំព្រះករុណា / កូណា.
- Family, friends, equals and modern stories: ordinary spoken Khmer (បង, អូន, ឯង, ខ្ញុំ, ពួកយើង) - no royal words outside the palace.
- Anger and insults stay rude when the story wants it (an enemy may call the consort ស្រីថោកទាប).
"""


def apply_ranks(project, ranks: Optional[Dict[str, str]]) -> int:
    """Ranks the AI told: kept as rank_ai (the user's own choice is never
    changed), and in the series file so the next episodes start with them."""
    cast = getattr(project, "cast", {}) or {}
    new = {}
    for lab, r in (ranks or {}).items():
        r = str(r or "").strip().lower()
        c = cast.get(str(lab).strip())
        if c is not None and r in RANK_IDS and not c.get("rank") and c.get("rank_ai") != r:
            c["rank_ai"] = r
            new[str(lab).strip()] = r
    path = getattr(project, "series_cast", "")
    if new and path:
        try:
            from . import series

            with series._lock:
                data = series.load(path)
                for lab, r in new.items():
                    if lab in data["cast"] and not data["cast"][lab].get("rank"):
                        data["cast"][lab]["rank_ai"] = r
                series.save(path, data)
        except Exception as e:              # never fatal
            print(f"[register] series not updated: {e}")
    return len(new)
