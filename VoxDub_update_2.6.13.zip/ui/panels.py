"""
panels.py - Left panel (upload, languages, voice, AI actions) and right
panel (transcript, translation and subtitle editors).
"""

import bisect
import os
from typing import List, Optional

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPen
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QFrame,
    QGroupBox, QHBoxLayout, QHeaderView, QLabel, QPlainTextEdit, QProgressBar,
    QPushButton, QScrollArea, QStyledItemDelegate, QTableWidget, QTableWidgetItem,
    QTabWidget, QVBoxLayout, QWidget,
)

from core import settings
from core.media import format_time, parse_time
from core.project import Project, Segment, SubtitleClip
from core.transcribe import WHISPER_MODELS
from core.translate import LANGUAGES, SOURCE_LANGUAGES
from core.tts import TTS_ENGINES, voices_for

from core.media import VIDEO_EXT  # noqa: E402


# --------------------------------------------------------------------------- #
# Left panel
# --------------------------------------------------------------------------- #
class LeftPanel(QScrollArea):
    videoChosen = Signal(str)
    autoDubRequested = Signal()
    transcribeRequested = Signal()
    translateRequested = Signal()
    voiceRequested = Signal()
    testVoiceRequested = Signal()
    azureKeyRequested = Signal()
    enginesRequested = Signal(str)      # "gemini" / "voxcpm" tab of AI engines & API keys
    cancelRequested = Signal()
    settingsChanged = Signal()
    presetChosen = Signal(str)          # 2.4: put a saved preset on this project
    presetSaveRequested = Signal()
    presetDeleteRequested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setMinimumWidth(280)
        inner = QWidget()
        inner.setObjectName("SidePanel")
        lay = QVBoxLayout(inner)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(10)

        # the loaded video (open one by dropping it on the preview / File > Open)
        self.file_label = QLabel("No video loaded – drag & drop a video on the preview")
        self.file_label.setObjectName("MutedLabel")
        self.file_label.setWordWrap(True)
        lay.addWidget(self.file_label)

        # preset (2.4) - the same presets as Batch
        g_pre = QGroupBox("⭐  Preset")
        g_pre.setToolTip("A preset keeps languages, voice, subtitle style, logo, blur,\n"
                         "output size and video / audio tools under one name.\n"
                         "The same presets are in Batch (⚙ Settings).")
        pv = QVBoxLayout(g_pre)
        self.cmb_preset = QComboBox()
        self.cmb_preset.setToolTip("Choose a preset: its settings are put on this video")
        self.cmb_preset.activated.connect(self._preset_activated)
        pv.addWidget(self.cmb_preset)
        prow = QHBoxLayout()
        self.btn_preset_save = QPushButton("💾  Save as preset…")
        self.btn_preset_save.setToolTip("Save this video's settings and look as a preset")
        self.btn_preset_save.clicked.connect(self.presetSaveRequested.emit)
        self.btn_preset_del = QPushButton("🗑")
        self.btn_preset_del.setToolTip("Delete the chosen preset")
        self.btn_preset_del.setMaximumWidth(40)
        self.btn_preset_del.clicked.connect(
            lambda: self.cmb_preset.currentData() and
            self.presetDeleteRequested.emit(self.cmb_preset.currentData()))
        prow.addWidget(self.btn_preset_del)          # left: the panel's right edge can be cut
        prow.addWidget(self.btn_preset_save, 1)
        pv.addLayout(prow)
        lay.addWidget(g_pre)
        self.reload_presets()

        # languages
        g_lang = QGroupBox("🌐  Languages")
        f = QFormLayout(g_lang)
        self.cmb_source = QComboBox()
        for code, name in SOURCE_LANGUAGES.items():
            self.cmb_source.addItem(name, code)
        self.cmb_target = QComboBox()
        for code, (name, _g) in LANGUAGES.items():
            self.cmb_target.addItem(name, code)
        self.cmb_translator = QComboBox()
        self.cmb_translator.addItem("Google Translate (free)", "google")
        self.cmb_translator.addItem("Gemini – follows the story (API key)", "gemini")
        self.cmb_translator.setToolTip(
            "Gemini reads the lines around each sentence, keeps names and forms of address "
            "the same and writes natural spoken dialogue. Needs your Google AI Studio key.")
        self.btn_gemini = QPushButton("🔑  Gemini API key…")
        self.btn_gemini.clicked.connect(lambda: self.enginesRequested.emit("gemini"))
        f.addRow("Speech", self.cmb_source)
        f.addRow("Dub to", self.cmb_target)
        f.addRow("Translate", self.cmb_translator)
        f.addRow("", self.btn_gemini)
        lay.addWidget(g_lang)

        # voice
        g_voice = QGroupBox("🎙️  AI Voice")
        fv = QFormLayout(g_voice)
        self.cmb_engine = QComboBox()
        for code, name in TTS_ENGINES.items():
            self.cmb_engine.addItem(name, code)
        self.cmb_voice = QComboBox()
        self.spn_speed = QDoubleSpinBox()
        self.spn_speed.setRange(1.0, 2.0)
        self.spn_speed.setSingleStep(0.1)
        self.spn_speed.setValue(1.5)
        self.spn_speed.setSuffix(" ×")
        self.spn_speed.setToolTip(
            "A translated line LONGER than the original speech is sped up\n"
            "at most this much (1.10 × = still sounds natural).\n"
            "Lines that already fit keep their normal speed.\n"
            "To make the whole video faster: Tools › Video › Speed.")
        self.chk_stretch = QCheckBox("Slow the video for long lines")
        self.chk_stretch.setChecked(False)          # 2.6.2: off by default
        self.chk_stretch.setToolTip(
            "Where a line is still too long, that part of the video plays a\n"
            "little slower, so the voice is not rushed and stays on the lips.\n"
            "Off: the line is sped up more and its end may be cut.")
        self.chk_stretch.toggled.connect(lambda *_: self.settingsChanged.emit())
        from ui.voice_style import PLAIN_TIP

        self.chk_plain = QCheckBox("Piseth / Sreymom as they are\n(first VoxDub)")
        self.chk_plain.setChecked(True)
        self.chk_plain.setToolTip(PLAIN_TIP)
        self.chk_plain.toggled.connect(lambda *_: self.settingsChanged.emit())
        self.chk_two = QCheckBox("One Male + one Female voice\n(no clone from the video)")
        self.chk_two.setToolTip(
            "VoxCPM + Auto: every man speaks with the Male voice, every woman with the\n"
            "Female voice of Voice clone settings - one character always has one voice.\n"
            "Off: each character is cloned from its own lines in the video.\n"
            "Takes effect on the next 3 · Voice (or Auto Dub).")
        self.chk_two.toggled.connect(lambda *_: self.settingsChanged.emit())
        self.btn_test_voice = QPushButton("▶  Test voice")
        self.btn_test_voice.clicked.connect(self.testVoiceRequested.emit)
        self.btn_azure = QPushButton("🔑  Azure key…")
        self.btn_azure.setToolTip("Your own Azure Speech key (official Microsoft API)")
        self.btn_azure.clicked.connect(self.azureKeyRequested.emit)
        self.btn_voxcpm = QPushButton("⚙  Voice clone settings…")
        self.btn_voxcpm.setToolTip("VoxCPM2 Python, male / female reference voices, quality")
        self.btn_voxcpm.clicked.connect(lambda: self.enginesRequested.emit("voxcpm"))
        self.cmb_voice.setToolTip("Auto = male or female voice for each line, "
                                  "from the speaker's voice in the video")
        fv.addRow("Engine", self.cmb_engine)
        fv.addRow("", self.btn_azure)
        fv.addRow("", self.btn_voxcpm)
        fv.addRow("Voice", self.cmb_voice)
        from ui.voice_style import make_voice_style_combo

        self.cmb_style = make_voice_style_combo(self.spn_speed, self.chk_stretch)
        fv.addRow("Voice style", self.cmb_style)
        fv.addRow("Voice speed", self.spn_speed)
        fv.addRow("", self.chk_stretch)
        fv.addRow("", self.chk_plain)
        fv.addRow("", self.chk_two)
        fv.addRow("", self.btn_test_voice)
        lay.addWidget(g_voice)

        # whisper
        g_ai = QGroupBox("🧠  Speech recognition")
        fa = QFormLayout(g_ai)
        self.cmb_model = QComboBox()
        for m in WHISPER_MODELS:
            self.cmb_model.addItem(m, m)
        self.cmb_model.setCurrentText("small")
        self.cmb_model.setToolTip("tiny/base = fast, small = good, medium/large = best but slow, large-v3-turbo = almost the best, fast, half the GPU memory")
        self.cmb_stt = QComboBox()
        self.cmb_stt.addItem("Whisper (offline, free)", "whisper")
        self.cmb_stt.addItem("Gemini (Google API key)", "gemini")
        self.cmb_stt.addItem("Paraformer-zh – Chinese, fast (VoxCPM engine)", "paraformer")
        self.cmb_stt.addItem("SenseVoice-Small – zh/en/ja/ko, fast (VoxCPM engine)", "sensevoice")
        self.cmb_stt.addItem("Fun-ASR-Nano – Chinese, newest (VoxCPM engine, test)", "funasr-nano")
        self.cmb_stt.setToolTip("Whisper runs on this computer. Gemini sends the speech parts "
                                "of the audio to Google (uses your API key quota). "
                                "Paraformer-zh / SenseVoice also run on this computer with the "
                                "VoxCPM engine – much faster, best for Chinese.")
        fa.addRow("Engine", self.cmb_stt)
        fa.addRow("Whisper", self.cmb_model)
        self._fa = fa
        self.chk_ocr = QCheckBox("Double-check with the subtitles\nburned into the video (OCR)")
        self.chk_ocr.setChecked(True)
        self.chk_ocr.setToolTip(
            "Chinese dramas show their own subtitles. They are read from the picture and used "
            "to correct Whisper's words (names, sound-alikes) and to add lines Whisper missed.")
        self.chk_ocr.toggled.connect(lambda *_: self.settingsChanged.emit())
        fa.addRow("", self.chk_ocr)
        lay.addWidget(g_ai)

        lay.addStretch(1)

        # actions - 2.6.4: pinned under the settings (always visible, no
        # scrolling down to AUTO DUB / the progress); only the settings scroll
        self.footer = QWidget(self)
        self.footer.setObjectName("SidePanel")
        flay = QVBoxLayout(self.footer)
        flay.setContentsMargins(10, 6, 10, 8)
        flay.setSpacing(8)
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("color: rgba(139,147,163,70);")
        flay.addWidget(line)
        self.btn_auto = QPushButton("⚡  AUTO DUB")
        self.btn_auto.setObjectName("AutoDubButton")
        self.btn_auto.setMinimumHeight(46)
        self.btn_auto.clicked.connect(self.autoDubRequested.emit)
        flay.addWidget(self.btn_auto)

        steps = QHBoxLayout()
        self.btn_transcribe = QPushButton("1 · Transcribe")
        self.btn_translate = QPushButton("2 · Translate")
        self.btn_voice = QPushButton("3 · Voice")
        self.btn_transcribe.clicked.connect(self.transcribeRequested.emit)
        self.btn_translate.clicked.connect(self.translateRequested.emit)
        self.btn_voice.clicked.connect(self.voiceRequested.emit)
        for b in (self.btn_transcribe, self.btn_translate, self.btn_voice):
            b.setObjectName("StepButton")
            steps.addWidget(b)
        flay.addLayout(steps)

        # progress
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.status = QLabel("Ready")
        self.status.setObjectName("MutedLabel")
        self.status.setWordWrap(True)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self.cancelRequested.emit)
        row = QHBoxLayout()
        row.addWidget(self.progress, 1)
        row.addWidget(self.btn_cancel)
        flay.addLayout(row)
        flay.addWidget(self.status)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setObjectName("LogBox")
        self.log.setMaximumBlockCount(500)
        flay.addWidget(self.log)

        self.setWidget(inner)
        shrink_combos(self)
        self._place_footer()

        self.cmb_target.currentIndexChanged.connect(self._refresh_voices)
        self.cmb_engine.currentIndexChanged.connect(self._refresh_voices)
        for w in (self.cmb_source, self.cmb_target, self.cmb_engine, self.cmb_voice, self.cmb_model,
                  self.cmb_stt, self.cmb_translator):
            w.currentIndexChanged.connect(lambda *_: self.settingsChanged.emit())
        for w in (self.cmb_stt, self.cmb_translator):
            w.currentIndexChanged.connect(self._engines_changed)
        self._engines_changed()
        self.spn_speed.valueChanged.connect(lambda *_: self.settingsChanged.emit())
        self._refresh_voices()

    def reload_presets(self, select: str = ""):
        from core import presets

        self.cmb_preset.blockSignals(True)
        self.cmb_preset.clear()
        self.cmb_preset.addItem("— Choose a preset —", "")
        for name in presets.list_presets():
            self.cmb_preset.addItem(("⭐ " if not presets.is_builtin(name) else "") + name, name)
        idx = self.cmb_preset.findData(select) if select else 0
        self.cmb_preset.setCurrentIndex(max(0, idx))
        self.cmb_preset.blockSignals(False)
        self._preset_buttons()

    def _preset_buttons(self):
        from core import presets

        name = self.cmb_preset.currentData() or ""
        self.btn_preset_del.setEnabled(bool(name) and not presets.is_builtin(name))

    def _preset_activated(self, *_):
        self._preset_buttons()
        name = self.cmb_preset.currentData()
        if name:
            self.presetChosen.emit(name)

    def _engines_changed(self, *_):
        gem = "gemini" in (self.cmb_stt.currentData(), self.cmb_translator.currentData())
        self.btn_gemini.setVisible(gem)
        whisper = self.cmb_stt.currentData() == "whisper"
        self.cmb_model.setVisible(whisper)
        lbl = self._fa.labelForField(self.cmb_model)
        if lbl:
            lbl.setVisible(whisper)

    def _refresh_voices_buttons(self):
        self.btn_azure.setVisible(self.cmb_engine.currentData() == "azure")
        vox = self.cmb_engine.currentData() == "voxcpm"
        self.btn_voxcpm.setVisible(vox)
        self.chk_plain.setVisible(not vox)       # Piseth / Sreymom: Edge / Azure only
        self.chk_two.setVisible(vox)

    def _refresh_voices(self):
        self._refresh_voices_buttons()
        current = self.cmb_voice.currentData()
        self.cmb_voice.blockSignals(True)
        self.cmb_voice.clear()
        for vid, label in voices_for(self.cmb_engine.currentData(), self.cmb_target.currentData()):
            self.cmb_voice.addItem(label, vid)
        idx = self.cmb_voice.findData(current)
        self.cmb_voice.setCurrentIndex(max(0, idx))
        self.cmb_voice.blockSignals(False)

    # settings <-> project
    def apply_to_project(self, p: Project):
        p.source_lang = self.cmb_source.currentData()
        p.target_lang = self.cmb_target.currentData()
        p.tts_engine = self.cmb_engine.currentData()
        p.voice = self.cmb_voice.currentData() or ""
        p.whisper_model = self.cmb_model.currentData()
        p.stt_engine = self.cmb_stt.currentData() or "whisper"
        p.translate_engine = self.cmb_translator.currentData() or "google"
        p.ocr_check = self.chk_ocr.isChecked()
        p.max_speed = float(self.spn_speed.value())
        p.stretch_video = self.chk_stretch.isChecked()
        p.plain_voice = self.chk_plain.isChecked()
        p.voxcpm_two_voices = self.chk_two.isChecked()

    def load_from_project(self, p: Project):
        widgets = (self.cmb_source, self.cmb_target, self.cmb_engine, self.cmb_voice,
                   self.cmb_model, self.spn_speed, self.cmb_stt, self.cmb_translator)
        for w in widgets:
            w.blockSignals(True)
        self._set_combo(self.cmb_source, p.source_lang)
        self._set_combo(self.cmb_target, p.target_lang)
        self._set_combo(self.cmb_engine, p.tts_engine)
        self._refresh_voices()
        self._set_combo(self.cmb_voice, p.voice)
        self._set_combo(self.cmb_model, p.whisper_model)
        self._set_combo(self.cmb_stt, getattr(p, "stt_engine", "whisper"))
        self._set_combo(self.cmb_translator, getattr(p, "translate_engine", "google"))
        self.chk_ocr.blockSignals(True)
        self.chk_ocr.setChecked(bool(getattr(p, "ocr_check", True)))
        self.chk_ocr.blockSignals(False)
        self.spn_speed.setValue(p.max_speed)
        self.chk_stretch.blockSignals(True)
        self.chk_stretch.setChecked(bool(getattr(p, "stretch_video", False)))
        self.chk_stretch.blockSignals(False)
        self.chk_plain.blockSignals(True)
        self.chk_plain.setChecked(bool(getattr(p, "plain_voice", True)))
        self.chk_plain.blockSignals(False)
        self.chk_two.blockSignals(True)
        self.chk_two.setChecked(bool(getattr(p, "voxcpm_two_voices", False)))
        self.chk_two.blockSignals(False)
        for w in widgets:
            w.blockSignals(False)
        self.cmb_style.follow()
        self._engines_changed()
        self._refresh_voices_buttons()
        if p.video_path:
            self.file_label.setText(
                f"🎬 {os.path.basename(p.video_path)}\n"
                f"{p.width}×{p.height} · {format_time(p.video_duration, False)}"
                + ("" if p.has_audio else " · (no audio)"))

    @staticmethod
    def _set_combo(combo: QComboBox, data):
        idx = combo.findData(data)
        if idx >= 0:
            combo.setCurrentIndex(idx)

    def set_busy(self, busy: bool):
        for b in (self.btn_auto, self.btn_transcribe, self.btn_translate, self.btn_voice,
                  self.btn_test_voice):
            b.setEnabled(not busy)
        self.btn_cancel.setEnabled(busy)

    def set_progress(self, pct: int, msg: str):
        self.progress.setValue(max(0, min(100, pct)))
        self.status.setText(msg)

    def add_log(self, msg: str):
        self.log.appendPlainText(msg)

    # the pinned AUTO DUB / progress / log area
    SETTINGS_MIN = 260          # px the settings above always keep
    LOG_MAX = 160

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._place_footer()

    def _place_footer(self):
        log_was = self.log.isVisibleTo(self.footer)
        self.log.setVisible(False)
        fixed = self.footer.sizeHint().height()
        spare = self.height() - self.SETTINGS_MIN - fixed - self.footer.layout().spacing()
        log_h = min(self.LOG_MAX, spare)
        if log_h >= 50:                     # a log smaller than 3 lines is no use
            self.log.setFixedHeight(log_h)
            self.log.setVisible(True)
            h = fixed + self.footer.layout().spacing() + log_h
        else:
            h = fixed
        if log_was != self.log.isVisibleTo(self.footer) and self.log.isVisibleTo(self.footer):
            self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())
        h = min(h, max(0, self.height() - 60))
        self.setViewportMargins(0, 0, 0, h)
        self.footer.setGeometry(0, self.height() - h, self.width(), h)
        self.footer.raise_()


def shrink_combos(root):
    """2.6.4: a combo box no longer asks for the width of its longest item
    ("Original VoxDub – fast voice, video not slow"): in a narrow side panel
    the whole panel was cut off on the right. The text is cut with … instead
    and the full list still opens wide."""
    for c in root.findChildren(QComboBox):
        c.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
        c.setMinimumContentsLength(6)

        def wide_list(*_a, c=c):
            if c.count():
                c.view().setMinimumWidth(c.view().sizeHintForColumn(0) + 30)
        wide_list()
        c.model().rowsInserted.connect(wide_list)
        c.model().modelReset.connect(wide_list)


# --------------------------------------------------------------------------- #
# Right panel
# --------------------------------------------------------------------------- #
def _item(text: str, editable: bool = True, data=None) -> QTableWidgetItem:
    it = QTableWidgetItem(text)
    if not editable:
        it.setFlags(it.flags() & ~Qt.ItemFlag.ItemIsEditable)
    if data is not None:
        it.setData(Qt.ItemDataRole.UserRole, data)
    return it


def _make_table(headers: List[str], stretch_col: int) -> QTableWidget:
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.verticalHeader().setVisible(False)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    t.setWordWrap(True)
    t.setAlternatingRowColors(True)
    h = t.horizontalHeader()
    for i in range(len(headers)):
        mode = QHeaderView.ResizeMode.Stretch if i == stretch_col else \
            QHeaderView.ResizeMode.ResizeToContents
        h.setSectionResizeMode(i, mode)
    return t


GENDER_MARK = {"male": "♂", "female": "♀"}
VAL = Qt.ItemDataRole.UserRole + 1          # the value behind a choice cell
# Translation table columns (Sarika Studio style)
# 2.1: the original line next to the translation (中文 | ខ្មែរ in one row)
T_START, T_END, T_ORIG, T_TEXT, T_VOICE, T_DELIVERY, T_PACE, T_STATUS = range(8)
DELIVERY_LABELS = {"normal": "normal", "happy": "happy", "excited": "excited",
                   "gentle": "gentle", "calm": "calm", "sad": "sad", "angry": "angry",
                   "shout": "shout", "question": "question"}
PACE_LABELS = {"normal": "norm", "fast": "fast", "slow": "slow"}
STATUS = {"ready": ("✓ Ready", "#2fd59a", "The AI voice is made and up to date"),
          "changed": ("⟳ Changed", "#f0a640", "Text, voice or delivery changed – "
                                              "Re-voice to hear it"),
          "none": ("○ No voice", "#8b93a3", "No AI voice yet – run Voice"),
          "empty": ("–", "#6b7280", "Nothing to say")}


class ChoiceDelegate(QStyledItemDelegate):
    """A drop-down in a table cell (Voice / Delivery / Speed): looks like a
    small combo box, opens on one click."""

    def __init__(self, choices, parent=None):
        super().__init__(parent)
        self.choices = choices              # (row) -> [(value, label), ...]

    def paint(self, p, option, index):
        super().paint(p, option, index)
        p.save()
        r = option.rect.adjusted(3, 5, -3, -5)
        p.setPen(QPen(QColor("#3a4150"), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(r, 4, 4)
        p.setPen(QColor("#9aa4b2"))
        p.drawText(r.adjusted(0, 0, -6, 0),
                   Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, "▾")
        p.restore()

    def createEditor(self, parent, option, index):
        cb = QComboBox(parent)
        cb.setMaxVisibleItems(20)
        for choice in self.choices(index.row()):
            value, label = choice[0], choice[1]
            if value is None:                       # a heading between groups
                if cb.count():
                    cb.insertSeparator(cb.count())
                cb.addItem(label)
                it = cb.model().item(cb.count() - 1)
                it.setEnabled(False)
                continue
            if len(choice) > 2 and choice[2]:
                from ui.characters_panel import dot_icon

                cb.addItem(dot_icon(choice[2]), label, value)
            else:
                cb.addItem(label, value)
        cb.activated.connect(lambda *_: (self.commitData.emit(cb), self.closeEditor.emit(cb)))
        return cb

    def setEditorData(self, editor, index):
        editor.setCurrentIndex(max(0, editor.findData(index.data(VAL))))
        QTimer.singleShot(0, editor.showPopup)

    def setModelData(self, editor, model, index):
        if editor.currentData() != index.data(VAL):
            model.setData(index, editor.currentText(), Qt.ItemDataRole.DisplayRole)
            model.setData(index, editor.currentData(), VAL)       # (this one is handled)
FOLLOW_BG = QColor("#17453e")       # the line being played
FOLLOW_GAP = 0.4                    # keep a line lit this long after it ends
BIG_TABLE = 300      # rows; above this, skip per-row auto sizing (2-hour videos)


def _set_big_mode(tbl: QTableWidget, big: bool):
    """Auto-sizing every row/column is slow with thousands of lines: use fixed
    sizes for big tables (text still wraps on 2 lines; hover shows it all)."""
    if tbl.property("big") == big:
        return
    tbl.setProperty("big", big)
    h = tbl.horizontalHeader()
    v = tbl.verticalHeader()
    for i in range(tbl.columnCount()):
        if h.sectionResizeMode(i) == QHeaderView.ResizeMode.Stretch or tbl.property("fixed"):
            continue
        if big:
            width = tbl.columnWidth(i)
            h.setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            tbl.setColumnWidth(i, max(width, 44 if i == 0 and tbl.columnCount() > 3 else 96))
        else:
            h.setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
    if big:
        v.setSectionResizeMode(QHeaderView.ResizeMode.Fixed)
        v.setDefaultSectionSize(44)
    else:
        v.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)


def _finish(tbl: QTableWidget):
    if not tbl.property("big"):
        tbl.resizeRowsToContents()
        cap = tbl.property("max_row_h")         # 2.0: one long line must not fill the table
        if cap:
            for r in range(tbl.rowCount()):
                if tbl.rowHeight(r) > cap:
                    tbl.setRowHeight(r, cap)
    tbl.setUpdatesEnabled(True)


def _tip(item: QTableWidgetItem) -> QTableWidgetItem:
    item.setToolTip(item.text())
    return item


class RightPanel(QTabWidget):
    segmentTextEdited = Signal(str, str)          # seg_id, text
    translationEdited = Signal(str, str)          # seg_id, text
    seekSourceRequested = Signal(float)           # source seconds
    seekTimelineRequested = Signal(float)         # timeline seconds
    translateAllRequested = Signal()
    revoiceRequested = Signal(list)               # list of selected seg ids
    revoiceAllRequested = Signal()
    genderToggled = Signal(str)                    # seg id: switch male <-> female
    autoDeliveryRequested = Signal()
    lineSettingEdited = Signal(list, str, str)     # seg ids, voice/delivery/pace, value
    subtitleEdited = Signal(str, str, str)        # sub_id, field, value
    subtitleSelected = Signal(str)
    addSubtitleRequested = Signal()
    deleteSubtitleRequested = Signal(list)
    rebuildSubtitlesRequested = Signal(bool)      # use translation?
    exportSrtRequested = Signal()
    hideSubtitlesRequested = Signal(list)         # sub ids: hide / show these lines
    checkDoneRequested = Signal(list)             # seg ids: Smart Review - looked at, OK

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumWidth(400)        # 2.6.4: 320 cut the Style / Characters tabs off
        self._loading = False
        # "follow the video": the line being played is lit and kept in view
        self._seg_starts: List[float] = []
        self._seg_ends: List[float] = []
        self._sub_starts: List[float] = []
        self._sub_ends: List[float] = []
        self._cur_seg = -1
        self._cur_sub = -1
        self._follow_on = bool(settings.get("follow_video", True))
        self._follow_boxes: List[QCheckBox] = []

        # --- transcript
        w1 = QWidget()
        l1 = QVBoxLayout(w1)
        l1.setContentsMargins(6, 6, 6, 6)
        self.tbl_transcript = _make_table(["#", "Start", "End", "Original text"], 3)
        self.tbl_transcript.itemChanged.connect(self._transcript_changed)
        self.tbl_transcript.cellDoubleClicked.connect(self._transcript_dbl)
        hint1 = QLabel("Edit text directly. Double-click a time to jump there.")
        hint1.setObjectName("MutedLabel")
        hint1.setWordWrap(True)
        # Smart Review (2.6.2): only the lines worth a look, one click each
        rc = QHBoxLayout()
        self.btn_check = QPushButton("🔍 Lines to check (0)")
        self.btn_check.setToolTip(
            "Go to the next line worth a look before translating:\n"
            "⚠ no subtitle on the video shows these words (noise heard as speech?)\n"
            "? Whisper is not sure of the words\n"
            "Edit the line, delete it, or press ✓ OK when it is right.")
        self.btn_check.clicked.connect(self.next_check)
        self.btn_check_ok = QPushButton("✓ OK")
        self.btn_check_ok.setToolTip("The selected line(s) are right – not to check any more")
        self.btn_check_ok.clicked.connect(self._check_ok)
        rc.addWidget(self.btn_check)
        rc.addWidget(self.btn_check_ok)
        rc.addStretch(1)
        l1.addLayout(rc)
        self._checks: List[tuple] = []          # (row, seg id, reason) of flagged lines
        self._update_check_button()
        l1.addWidget(self.tbl_transcript, 1)
        l1.addWidget(self._follow_box())
        l1.addWidget(hint1)
        self.addTab(w1, "📝 Transcript")

        # --- translation
        w2 = QWidget()
        l2 = QVBoxLayout(w2)
        l2.setContentsMargins(6, 6, 6, 6)
        self._project: Optional[Project] = None
        self.tbl_translation = _make_table(
            ["Start", "End", "Original", "Target text (editable)", "Voice", "Delivery",
             "Speed", "Audio status"], T_TEXT)
        tips = {T_ORIG: "The original line (edit it in 📝 Transcript).",
                T_VOICE: "Who speaks the line and with which voice.\n"
                         "● colour + name = the character (its voice is set in 👥 Characters)\n"
                         "★ = a voice chosen for this line only\n"
                         "↑ ↓ = the voice made a little higher / lower",
                T_DELIVERY: "How the line is said (Edge / Azure voices: pitch and speed).",
                T_PACE: "Speak this line faster or slower.",
                T_STATUS: "✓ Ready = voice made · ⟳ Changed = Re-voice to hear the change"}
        for col, tip in tips.items():
            self.tbl_translation.horizontalHeaderItem(col).setToolTip(tip)
        th = self.tbl_translation.horizontalHeader()
        self.tbl_translation.setProperty("fixed", True)     # sized here, not by content
        # 2.0: a little narrower so "Target text (editable)" gets room; long
        # text rows stop at 3 lines (hover / the box below show the whole line)
        self.tbl_translation.setProperty("max_row_h", 70)
        th.setTextElideMode(Qt.TextElideMode.ElideRight)
        self.tbl_translation.horizontalHeaderItem(T_TEXT).setTextAlignment(
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        for col, width in ((T_START, 92), (T_END, 92), (T_ORIG, 220), (T_VOICE, 104),
                           (T_DELIVERY, 80),
                           (T_PACE, 60), (T_STATUS, 90)):
            th.setSectionResizeMode(col, QHeaderView.ResizeMode.Interactive)
            self.tbl_translation.setColumnWidth(col, width)
        self.tbl_translation.setTextElideMode(Qt.TextElideMode.ElideRight)
        for col in (T_START, T_END):
            self.tbl_translation.horizontalHeaderItem(col).setTextAlignment(
                Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.tbl_translation.setItemDelegateForColumn(
            T_VOICE, ChoiceDelegate(self._voice_choices, self.tbl_translation))
        self.tbl_translation.setItemDelegateForColumn(
            T_DELIVERY, ChoiceDelegate(lambda r: list(DELIVERY_LABELS.items()),
                                       self.tbl_translation))
        self.tbl_translation.setItemDelegateForColumn(
            T_PACE, ChoiceDelegate(lambda r: list(PACE_LABELS.items()), self.tbl_translation))
        self.tbl_translation.clicked.connect(self._translation_clicked)
        self.tbl_translation.currentCellChanged.connect(self._show_original)
        self.tbl_translation.itemChanged.connect(self._translation_changed)
        self.tbl_translation.cellDoubleClicked.connect(self._translation_dbl)
        self.lbl_original = QLabel("")
        self.lbl_original.setObjectName("MutedLabel")
        self.lbl_original.setWordWrap(True)
        self.lbl_original.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        row2 = QHBoxLayout()
        b_tr = QPushButton("🌐 Translate all")
        b_rv = QPushButton("🔊 Re-voice selected")
        b_rva = QPushButton("🔊 Re-voice all")
        b_tr.clicked.connect(self.translateAllRequested.emit)
        b_em = QPushButton("🎭 Auto delivery")
        b_em.setToolTip("Listen to how every line is said in the video (louder, higher, "
                        "quieter, a question ...) and set its Delivery: excited, angry, "
                        "shout, sad, gentle, question ...\nDeliveries you chose by hand "
                        "are kept. Done automatically after Transcribe.")
        b_em.clicked.connect(self.autoDeliveryRequested.emit)
        b_rv.clicked.connect(lambda: self.revoiceRequested.emit(self.selected_segment_ids()))
        b_rva.clicked.connect(self.revoiceAllRequested.emit)
        row2.addWidget(b_tr)
        row2.addWidget(b_em)
        row2.addStretch(1)
        row2.addWidget(self._follow_box())
        row2b = QHBoxLayout()
        row2b.addWidget(b_rv)
        row2b.addWidget(b_rva)
        hint2 = QLabel("Edit a line, or its Voice / Delivery / Speed (with several rows "
                       "selected: all of them), then ‘Re-voice selected’. "
                       "Double-click a time to jump there.")
        hint2.setObjectName("MutedLabel")
        hint2.setWordWrap(True)
        l2.addWidget(self.tbl_translation, 1)
        l2.addWidget(self.lbl_original)
        l2.addLayout(row2)
        l2.addLayout(row2b)
        l2.addWidget(hint2)
        self.addTab(w2, "🌐 Translation")

        # --- subtitles
        w3 = QWidget()
        l3 = QVBoxLayout(w3)
        l3.setContentsMargins(6, 6, 6, 6)
        self.tbl_subs = _make_table(["Start", "End", "Subtitle"], 2)
        self.tbl_subs.itemChanged.connect(self._sub_changed)
        self.tbl_subs.itemSelectionChanged.connect(self._sub_selection)
        self.tbl_subs.cellDoubleClicked.connect(self._sub_dbl)
        row3 = QHBoxLayout()
        b_add = QPushButton("＋ Add")
        b_add.setToolTip("Add a subtitle at the playhead")
        b_del = QPushButton("－ Delete")
        b_rt = QPushButton("↻ From translation")
        b_ro = QPushButton("↻ From original")
        b_srt = QPushButton("💾 Save SRT")
        b_hide = QPushButton("🙈 Hide / show")
        b_hide.setToolTip("Hide the selected subtitles (kept, but not shown or burned).\n"
                          "Select hidden ones and click again to show them.")
        b_hide.clicked.connect(lambda: self.hideSubtitlesRequested.emit(self.selected_sub_ids()))
        b_add.clicked.connect(self.addSubtitleRequested.emit)
        b_del.clicked.connect(lambda: self.deleteSubtitleRequested.emit(self.selected_sub_ids()))
        b_rt.clicked.connect(lambda: self.rebuildSubtitlesRequested.emit(True))
        b_ro.clicked.connect(lambda: self.rebuildSubtitlesRequested.emit(False))
        b_srt.clicked.connect(self.exportSrtRequested.emit)
        for b in (b_add, b_del, b_srt):
            row3.addWidget(b)
        row3.addStretch(1)
        row3.addWidget(self._follow_box())
        row3b = QHBoxLayout()
        row3b.addWidget(b_rt)
        row3b.addWidget(b_ro)
        row3b.addWidget(b_hide)
        hint3 = QLabel("Times: 00:00:01.250 (timeline). Drag clips on the timeline too.")
        hint3.setObjectName("MutedLabel")
        hint3.setWordWrap(True)
        l3.addWidget(self.tbl_subs, 1)
        l3.addLayout(row3)
        l3.addLayout(row3b)
        l3.addWidget(hint3)
        self.addTab(w3, "💬 Subtitles")

        # --- characters (one voice per character)
        from .characters_panel import CharactersPanel

        self.characters = CharactersPanel()
        # 2.0: in a scroll area - the cast table must not make the whole window
        # taller than a 1080p screen (the Export button was cut off)
        self.characters_page = QScrollArea()
        self.characters_page.setWidgetResizable(True)
        self.characters_page.setFrameShape(QScrollArea.Shape.NoFrame)
        self.characters_page.setWidget(self.characters)
        self.addTab(self.characters_page, "👥 Characters")

    # ------------------------------------------------------------------ #
    # Follow the video
    # ------------------------------------------------------------------ #
    def _follow_box(self) -> QCheckBox:
        b = QCheckBox("⇣ Follow video")
        b.setToolTip("While the video plays, light up the line being spoken and keep it "
                     "in view (it does not move while you are typing)")
        b.setChecked(self._follow_on)
        b.toggled.connect(self.set_follow)
        self._follow_boxes.append(b)
        return b

    def set_follow(self, on: bool):
        self._follow_on = bool(on)
        for b in self._follow_boxes:
            if b.isChecked() != self._follow_on:
                b.blockSignals(True)
                b.setChecked(self._follow_on)
                b.blockSignals(False)
        try:
            settings.set("follow_video", self._follow_on)
        except OSError:
            pass
        if not self._follow_on:
            self._light_seg(-1)
            self._light_sub(-1)

    @staticmethod
    def _find(starts: List[float], ends: List[float], t: float) -> int:
        i = bisect.bisect_right(starts, t) - 1
        if i >= 0 and t <= ends[i] + FOLLOW_GAP:
            return i
        return -1

    def _paint_row(self, tbl: QTableWidget, row: int, on: bool):
        if row < 0 or row >= tbl.rowCount():
            return
        was = self._loading
        self._loading = True        # colour changes must not count as text edits
        for c in range(tbl.columnCount()):
            it = tbl.item(row, c)
            if it is None:
                continue
            it.setBackground(QBrush(FOLLOW_BG) if on else QBrush())
            f = it.font()
            f.setBold(on)
            it.setFont(f)
        self._loading = was

    @staticmethod
    def _show_row(tbl: QTableWidget, row: int):
        if row < 0 or tbl.state() == QAbstractItemView.State.EditingState:
            return
        it = tbl.item(row, 0)
        if it is not None:
            tbl.scrollToItem(it, QAbstractItemView.ScrollHint.PositionAtCenter)

    def _light_seg(self, row: int, scroll: bool = False):
        if row != self._cur_seg:
            for tbl in (self.tbl_transcript, self.tbl_translation):
                self._paint_row(tbl, self._cur_seg, False)
                self._paint_row(tbl, row, True)
            self._cur_seg = row
            if scroll:
                self._show_row(self.tbl_transcript, row)
                self._show_row(self.tbl_translation, row)

    def _light_sub(self, row: int, scroll: bool = False):
        if row != self._cur_sub:
            self._paint_row(self.tbl_subs, self._cur_sub, False)
            self._paint_row(self.tbl_subs, row, True)
            self._cur_sub = row
            if scroll:
                self._show_row(self.tbl_subs, row)

    def follow(self, src_t: float, timeline_t: float):
        """Called with the playhead: light up / show the line being played.
        src_t = source seconds (transcript / translation), timeline_t =
        timeline seconds (subtitles)."""
        if not self._follow_on:
            return
        self._light_seg(self._find(self._seg_starts, self._seg_ends, src_t), scroll=True)
        self._light_sub(self._find(self._sub_starts, self._sub_ends, timeline_t), scroll=True)

    # ------------------------------------------------------------------ #
    def load(self, project: Optional[Project]):
        self._project = project
        self.load_segments(project.segments if project else [])
        self.load_subtitles(project.subtitles_sorted() if project else [])
        self.characters.load(project)

    def load_segments(self, segments: List[Segment]):
        self._loading = True
        segs = sorted(segments, key=lambda s: s.start)
        self._seg_starts = [s.start for s in segs]
        self._seg_ends = [s.end for s in segs]
        self._voice_cache = {}              # (2-hour films: thousands of rows)
        sigs = [self._row_sig(s) for s in segs]
        old = getattr(self, "_sigs", None)
        if old and len(old) == len(sigs) and self.tbl_translation.rowCount() == len(segs) \
                and all(a[0] == b[0] for a, b in zip(old, sigs)):
            # same lines as shown: redraw only the rows that changed (fast)
            for r, (s, a, b) in enumerate(zip(segs, old, sigs)):
                if a != b:
                    self.tbl_transcript.item(r, 1).setText(format_time(s.start))
                    self.tbl_transcript.item(r, 2).setText(format_time(s.end))
                    self.tbl_transcript.item(r, 3).setText(s.text)
                    self._fill_translation_row(r, s)
                    self._mark_check(r, getattr(s, "check", ""))
                    if r == self._cur_seg:
                        self._paint_row(self.tbl_transcript, r, True)
                        self._paint_row(self.tbl_translation, r, True)
            self._sigs = sigs
            self._collect_checks(segs)
            self._loading = False
            return
        self._sigs = sigs
        self._cur_seg = -1                  # rows are rebuilt (no colour left)
        big = len(segs) > BIG_TABLE
        for tbl in (self.tbl_transcript, self.tbl_translation):
            tbl.setUpdatesEnabled(False)
            _set_big_mode(tbl, big)
            tbl.setRowCount(len(segs))
        for r, s in enumerate(segs):
            self.tbl_transcript.setItem(r, 0, _item(str(r + 1), False, s.id))
            self.tbl_transcript.setItem(r, 1, _item(format_time(s.start), False))
            self.tbl_transcript.setItem(r, 2, _item(format_time(s.end), False))
            self.tbl_transcript.setItem(r, 3, _tip(_item(s.text)) if big else _item(s.text))
            self._fill_translation_row(r, s)
            self._mark_check(r, getattr(s, "check", ""))
        _finish(self.tbl_transcript)
        _finish(self.tbl_translation)
        self._collect_checks(segs)
        self._loading = False

    # ---- Smart Review
    CHECK_TIPS = {"nosub": "⚠ No subtitle on the video shows these words – noise heard as "
                           "speech, or a wrong word? Listen (double-click the time).",
                  "unsure": "? Whisper is not sure of these words – listen and correct."}
    CHECK_MARK = {"nosub": "⚠", "unsure": "?", "nosub_unsure": "⚠"}

    def _mark_check(self, r: int, reason: str):
        it = self.tbl_transcript.item(r, 0)
        txt = self.tbl_transcript.item(r, 3)
        if it is None:
            return
        mark = self.CHECK_MARK.get(reason, "")
        it.setText(f"{mark} {r + 1}" if mark else str(r + 1))
        from core.i18n import tr
        tip = tr(self.CHECK_TIPS.get(reason.split("_")[0] if reason else "", ""))
        it.setToolTip(tip)
        it.setForeground(QBrush(QColor("#f59e0b")) if mark else QBrush())
        if txt is not None:
            txt.setForeground(QBrush(QColor("#f59e0b")) if mark else QBrush())
            if tip and not self.tbl_transcript.property("big"):
                txt.setToolTip(tip)

    def _collect_checks(self, segs):
        self._checks = [(r, s.id, s.check) for r, s in enumerate(segs)
                        if getattr(s, "check", "")]
        self._update_check_button()

    def _update_check_button(self):
        n = len(self._checks)
        from core.i18n import tr
        self.btn_check.setText(tr(f"🔍 Lines to check ({n})"))
        self.btn_check.setEnabled(n > 0)
        self.btn_check_ok.setEnabled(n > 0)

    def next_check(self):
        """Select the next flagged line after the current one and play from it."""
        if not self._checks:
            return
        cur = self.tbl_transcript.currentRow()
        nxt = next((c for c in self._checks if c[0] > cur), self._checks[0])
        r = nxt[0]
        self.setCurrentIndex(0)
        self.tbl_transcript.selectRow(r)
        self.tbl_transcript.setCurrentCell(r, 3)
        self._show_row(self.tbl_transcript, r)
        try:
            self.seekSourceRequested.emit(parse_time(self.tbl_transcript.item(r, 1).text()))
        except (ValueError, AttributeError):
            pass

    def _check_ok(self):
        rows = sorted({i.row() for i in self.tbl_transcript.selectedIndexes()})
        ids = [self._row_id(self.tbl_transcript, r) for r in rows]
        ids = [i for i in ids if any(c[1] == i for c in self._checks)]
        if ids:
            self._clear_checks(ids)
            self.checkDoneRequested.emit(ids)

    def _clear_checks(self, ids):
        was = self._loading
        self._loading = True
        for r, sid, _why in [c for c in self._checks if c[1] in ids]:
            self._mark_check(r, "")
        self._loading = was
        self._checks = [c for c in self._checks if c[1] not in ids]
        self._update_check_button()

    def load_subtitles(self, subs: List[SubtitleClip]):
        self._loading = True
        tbl = self.tbl_subs
        self._sub_starts = [s.start for s in subs]
        self._sub_ends = [s.end for s in subs]
        # fast path after a timeline edit: same rows -> only update changed cells
        if tbl.rowCount() == len(subs) and len(subs) > 0 and all(
                self._row_id(tbl, r) == s.id for r, s in enumerate(subs)):
            for r, s in enumerate(subs):
                for col, text in ((0, format_time(s.start)), (1, format_time(s.end)),
                                  (2, s.text)):
                    it = tbl.item(r, col)
                    if it.text() != text:
                        it.setText(text)
                self._mark_hidden(tbl, r, s.hidden)
            self._loading = False
            return
        selected = set(self.selected_sub_ids())
        self._cur_sub = -1
        big = len(subs) > BIG_TABLE
        tbl.setUpdatesEnabled(False)
        _set_big_mode(tbl, big)
        tbl.setRowCount(len(subs))
        for r, s in enumerate(subs):
            tbl.setItem(r, 0, _item(format_time(s.start), True, s.id))
            tbl.setItem(r, 1, _item(format_time(s.end)))
            tbl.setItem(r, 2, _tip(_item(s.text)) if big else _item(s.text))
            self._mark_hidden(tbl, r, s.hidden)
            if s.id in selected:
                tbl.selectRow(r)
        _finish(tbl)
        self._loading = False

    @staticmethod
    def _mark_hidden(tbl: QTableWidget, row: int, hidden: bool):
        """Hidden subtitles: grey, struck through."""
        for c in range(tbl.columnCount()):
            it = tbl.item(row, c)
            if it is None:
                continue
            f = it.font()
            if f.strikeOut() != hidden:
                f.setStrikeOut(hidden)
                it.setFont(f)
            it.setForeground(QBrush(QColor("#6b7280")) if hidden else QBrush())
            if c == 2:
                it.setToolTip("🙈 Hidden – not shown or burned (🙈 Hide / show to bring it back)"
                              if hidden else (it.text() if tbl.property("big") else ""))

    def select_subtitle(self, sub_id: str):
        self._loading = True
        for r in range(self.tbl_subs.rowCount()):
            it = self.tbl_subs.item(r, 0)
            if it and it.data(Qt.ItemDataRole.UserRole) == sub_id:
                self.tbl_subs.selectRow(r)
                self.tbl_subs.scrollToItem(it)
                break
        self._loading = False

    @staticmethod
    def _row_id(tbl: QTableWidget, row: int) -> str:
        it = tbl.item(row, 0)
        return it.data(Qt.ItemDataRole.UserRole) if it else ""

    def selected_segment_ids(self) -> List[str]:
        rows = sorted({i.row() for i in self.tbl_translation.selectedIndexes()})
        return [self._row_id(self.tbl_translation, r) for r in rows]

    def selected_sub_ids(self) -> List[str]:
        rows = sorted({i.row() for i in self.tbl_subs.selectedIndexes()})
        return [self._row_id(self.tbl_subs, r) for r in rows]

    # ------------------------------------------------------------------ #
    def _transcript_changed(self, item: QTableWidgetItem):
        if self._loading or item.column() != 3:
            return
        sid = self._row_id(self.tbl_transcript, item.row())
        self.segmentTextEdited.emit(sid, item.text())
        if any(c[1] == sid for c in self._checks):       # corrected = checked
            self._clear_checks([sid])
        # keep the translation tab's "Original" (tooltip) in sync
        self._loading = True
        other = self.tbl_translation.item(item.row(), T_TEXT)
        if other:
            other.setToolTip(f"Original: {item.text()}")
        orig = self.tbl_translation.item(item.row(), T_ORIG)
        if orig:
            orig.setText(item.text())
            orig.setToolTip(item.text())
        self._loading = False

    # ---- the translation table (Sarika Studio style)
    def _fill_translation_row(self, r: int, s: Segment):
        t = self.tbl_translation
        mono = getattr(self, "_mono", None)
        if mono is None:
            mono = self._mono = QFont("Consolas", 9)
            mono.setStyleHint(QFont.StyleHint.Monospace)
        for col in (T_START, T_END):
            it = _item(format_time(s.start if col == T_START else s.end), False,
                       s.id if col == T_START else None)
            it.setFont(mono)
            it.setForeground(QBrush(QColor("#9aa4b2")))
            t.setItem(r, col, it)
        orig = _item(s.text, False)
        orig.setForeground(QBrush(QColor("#9aa4b2")))
        orig.setToolTip(s.text)
        t.setItem(r, T_ORIG, orig)
        txt = _item(s.translation)
        txt.setToolTip(f"Original: {s.text}")
        t.setItem(r, T_TEXT, txt)
        voice = _item(self._voice_text(s), False)
        voice.setData(VAL, self._voice_value(s))
        colour = self._speaker_colour(s)
        if colour:
            from ui.characters_panel import dot_icon

            voice.setIcon(dot_icon(colour))
        voice.setToolTip(self._voice_tip(s))
        voice.setFlags(voice.flags() | Qt.ItemFlag.ItemIsEditable)
        t.setItem(r, T_VOICE, voice)
        for col, value, labels in ((T_DELIVERY, s.delivery or "normal", DELIVERY_LABELS),
                                   (T_PACE, s.pace or "normal", PACE_LABELS)):
            it = _item(labels.get(value, value))
            it.setData(VAL, value)
            t.setItem(r, col, it)
        state = self._status(s)
        text, colour, tip = STATUS[state]
        st = _item(text, False)
        st.setForeground(QBrush(QColor(colour)))
        st.setToolTip(tip)
        t.setItem(r, T_STATUS, st)

    def refresh_segment(self, s: Segment):
        """Re-draw one line of the translation table (e.g. its Audio status)."""
        for r in range(self.tbl_translation.rowCount()):
            if self._row_id(self.tbl_translation, r) == s.id:
                was = self._loading
                self._loading = True
                self._fill_translation_row(r, s)
                if r == self._cur_seg:
                    self._paint_row(self.tbl_translation, r, True)
                self._loading = was
                return

    def _row_sig(self, s: Segment) -> tuple:
        """What a row shows - unchanged rows are not drawn again."""
        return (s.id, s.start, s.end, s.text, s.translation, self._voice_text(s),
                s.delivery, s.pace, self._status(s), getattr(s, "check", ""))

    def _base_voice(self, s: Segment) -> str:
        """The line's voice (cached for the rows of one table fill: the same
        character / own voice gives the same answer)."""
        p = self._project
        cache = getattr(self, "_voice_cache", None)
        if cache is None:
            cache = self._voice_cache = {}
        key = (s.voice, s.speaker, s.gender)
        if key not in cache:
            try:
                cache[key] = p.base_voice_for(s)
            except Exception:
                cache[key] = ""
        return cache[key]

    def _has_character(self, s: Segment) -> bool:
        p = self._project
        return bool(p is not None and s.speaker and s.speaker in (p.cast or {}))

    def _speaker_colour(self, s: Segment) -> str:
        if not self._has_character(s):
            return ""
        from core import speakers

        return speakers.color_of(s.speaker)

    def _voice_value(self, s: Segment) -> str:
        """What the Voice drop-down shows as chosen: the line's own voice, or
        its character ('@A')."""
        if s.voice:
            return s.voice
        return "@" + s.speaker if self._has_character(s) else ""

    def _char_text(self, label: str) -> tuple:
        """(name, 'Sreymom ↑') of a character, cached for one table fill."""
        cache = getattr(self, "_voice_cache", None)
        if cache is None:
            cache = self._voice_cache = {}
        key = ("char", label)
        if key not in cache:
            from core import speakers

            p = self._project
            cache[key] = (speakers.display(p, label), speakers.voice_summary(p, label))
        return cache[key]

    def _voice_text(self, s: Segment) -> str:
        """'Woman 1 · Sreymom ↑' (the character's voice), '★ Piseth' (a voice
        chosen for this line only), or '♀ Sreymom' (no characters)."""
        p = self._project
        if p is None:
            return "Auto"
        from core import speakers

        base = self._base_voice(s)
        key = ("label", base)
        cache = self._voice_cache
        if key not in cache:
            cache[key] = speakers.voice_name(base)
        name = cache[key]
        own = bool(s.voice and base == s.voice)
        if own:
            return f"★ {name or s.voice}"           # a voice chosen for this line only
        # short: "♂ Male" / "♀ Female" - the coloured dot is the character, the
        # tooltip says who and which voice (saves room for the Khmer text)
        gender = s.gender
        if self._has_character(s):
            gender = ((p.cast or {}).get(s.speaker) or {}).get("gender") or gender
        from core.i18n import tr

        return tr("♀ Female") if gender == "female" else tr("♂ Male")

    def _voice_tip(self, s: Segment) -> str:
        if not self._has_character(s):
            name = (self._voice_cache or {}).get(("label", self._base_voice(s)), "")
            return f"Voice: {name}" if name else ""
        who, voice = self._char_text(s.speaker)
        if s.voice:
            return (f"Spoken by {who} – this line has its own voice "
                    f"({self._voice_text(s).split('★ ')[-1]}).\nChoose {who} to give it "
                    "the character's voice again.")
        return f"Spoken by {who} with the voice {voice}.\nClick to give the line to " \
            "another character or its own voice."

    def _voice_choices(self, row: int):
        p = self._project
        if p is None:
            return [("", "Auto")]
        from core import speakers

        voices = [(v, label.replace(" (Male)", "  ♂").replace(" (Female)", "  ♀"))
                  for v, label in voices_for(p.tts_engine, p.target_lang, with_auto=False)]
        cast = p.cast or {}
        if not cast:
            return [("", "Auto (man / woman voice by line)")] + voices
        out = [(None, "Who speaks this line?")]
        for lab in sorted(cast, key=speakers._order):
            who, voice = self._char_text(lab)
            out.append(("@" + lab, f"{who}   ({voice})" if voice else who,
                        speakers.color_of(lab)))
        out.append(("@+", "＋ New character"))
        out.append((None, "Or a voice for this line only"))
        out += [(v, "★ " + label) for v, label in voices]
        return out

    def _status(self, s: Segment) -> str:
        p = self._project
        if not s.voice_text():
            return "empty"
        if p is not None and s.voice_is_current():
            from core.tts import with_delivery

            want = with_delivery(self._base_voice(s), p.tts_engine, s.delivery, s.pace)
            if not s.tts_voice or s.tts_voice == want:
                return "ready"
        if s.tts_path:
            return "changed"
        return "none"

    def _translation_clicked(self, index):
        if index.column() in (T_VOICE, T_DELIVERY, T_PACE):
            self.tbl_translation.edit(index)

    def _show_original(self, row, col, *_):
        it = self.tbl_translation.item(row, T_TEXT) if row >= 0 else None
        tip = it.toolTip() if it else ""
        self.lbl_original.setText(tip.replace("Original: ", "🈶  ", 1) if tip else "")

    def _translation_changed(self, item: QTableWidgetItem):
        if self._loading:
            return
        col, row = item.column(), item.row()
        sid = self._row_id(self.tbl_translation, row)
        if col == T_TEXT:
            self.translationEdited.emit(sid, item.text())
        elif col in (T_VOICE, T_DELIVERY, T_PACE):
            field = {T_VOICE: "voice", T_DELIVERY: "delivery", T_PACE: "pace"}[col]
            ids = self.selected_segment_ids()
            if sid not in ids:
                ids = [sid]
            value = item.data(VAL) or ""
            # after the cell edit is over (the table is filled again)
            QTimer.singleShot(0, lambda: self.lineSettingEdited.emit(ids, field, value))

    def _transcript_dbl(self, row, col):
        if col in (0, 1, 2):
            it = self.tbl_transcript.item(row, 1)
            try:
                self.seekSourceRequested.emit(parse_time(it.text()))
            except (ValueError, AttributeError):
                pass

    def _translation_dbl(self, row, col):
        if col in (T_START, T_END):
            it = self.tbl_transcript.item(row, 1)
            try:
                self.seekSourceRequested.emit(parse_time(it.text()))
            except (ValueError, AttributeError):
                pass

    def _sub_changed(self, item: QTableWidgetItem):
        if self._loading:
            return
        sid = self._row_id(self.tbl_subs, item.row())
        field = {0: "start", 1: "end", 2: "text"}[item.column()]
        self.subtitleEdited.emit(sid, field, item.text())

    def _sub_selection(self):
        if self._loading:
            return
        ids = self.selected_sub_ids()
        if len(ids) == 1:
            self.subtitleSelected.emit(ids[0])

    def _sub_dbl(self, row, col):
        if col in (0, 1):
            it = self.tbl_subs.item(row, 0)
            try:
                self.seekTimelineRequested.emit(parse_time(it.text()))
            except (ValueError, AttributeError):
                pass
