"""
gemini_web.py - 2.7.2: Gemini web (gemini.google.com) through the user's own
Google accounts. 2.7.3 (20/11, Po): customers too - as a paid add-on.

Po asked for it (16/11, 20/11) and takes the whole responsibility: it is not an
official API, Google's terms do not allow automated use of the web app, and
Google may limit, ask to verify or close the accounts. So:

  * it works for the Admin, and for a customer whose licence key carries the
    "gemini_web" add-on (license.has_addon) AND who has read the warning and
    agreed once (consented) - everyone else sees how to get the add-on;
  * the cookies (__Secure-1PSID, __Secure-1PSIDTS) of each account are typed
    by the Admin, kept only in <settings dir>/gemini_web.json on this PC,
    never logged, never shown again - an account shows as "hea***@***";
  * one request per account at a time; the accounts take turns;
  * text only (translation, names, proofreading, shorter lines) - the sound
    of an episode (characters, AI check) still goes to the API keys;
  * mode "fallback" (default): only when every API key is used up;
    mode "first": before the API keys, to save their quota;
  * an account that refuses (limit, sign-in expired, verify) rests an hour;
    the next account, then the API keys / Google Translate go on.

Library: gemini-webapi (pip install gemini-webapi==2.1.1, Python 3.11+).
"""

import asyncio
import json
import os
import threading
import time
from typing import Dict, List, Optional, Tuple

from . import gemini_stats, settings

FILE = "gemini_web.json"
MODES = ("off", "fallback", "first")
REST_S = 3600.0             # after a refusal: an hour without that account
TIMEOUT_S = 180.0

_lock = threading.RLock()
_loop: Optional[asyncio.AbstractEventLoop] = None
_clients: Dict[str, object] = {}
_until: Dict[str, float] = {}           # account id -> resting until
_err: Dict[str, str] = {}
_busy: Dict[str, bool] = {}
_last: dict = {}            # account -> when its last answer came
_used: Dict[str, int] = {}              # answers since the app started
_turn = [0]


# --------------------------------------------------------------------------- #
# settings (cookies on this PC only)
# --------------------------------------------------------------------------- #
def _path() -> str:
    return os.path.join(settings.settings_dir(), FILE)


def _load() -> dict:
    try:
        with open(_path(), "r", encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    if not isinstance(d, dict):
        d = {}
    if "accounts" not in d:                 # the first version: one account
        acc = []
        if d.get("psid"):
            acc.append({"id": "a1", "label": "Account 1", "psid": d.get("psid", ""),
                        "psidts": d.get("psidts", "")})
        d = {"mode": d.get("mode", "fallback"), "model": d.get("model", "gemini-flash"),
             "accounts": acc}
    return d


def _write(d: dict) -> None:
    os.makedirs(os.path.dirname(_path()), exist_ok=True)
    tmp = _path() + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump({"mode": d.get("mode", "fallback"), "model": d.get("model", "gemini-flash"),
                   "accounts": d.get("accounts", [])}, f)
    os.replace(tmp, _path())


def mask(label: str) -> str:
    label = (label or "").strip()
    if "@" in label:
        return label.split("@")[0][:3] + "***@***"
    return label[:3] + "***" if len(label) > 6 else label or "account"


def add(label: str, psid: str, psidts: str = "") -> str:
    d = _load()
    ids = {a["id"] for a in d["accounts"]}
    n = 1
    while f"a{n}" in ids:
        n += 1
    aid = f"a{n}"
    d["accounts"].append({"id": aid, "label": (label or f"Account {n}").strip(),
                          "psid": psid.strip(), "psidts": (psidts or "").strip()})
    _write(d)
    _drop(aid)
    return aid


def update(aid: str, psid: Optional[str] = None, psidts: Optional[str] = None,
           label: Optional[str] = None) -> None:
    d = _load()
    for a in d["accounts"]:
        if a["id"] == aid:
            if psid:
                a["psid"] = psid.strip()
            if psidts:
                a["psidts"] = psidts.strip()
            if label:
                a["label"] = label.strip()
    _write(d)
    _drop(aid)


def remove(aid: str) -> None:
    d = _load()
    d["accounts"] = [a for a in d["accounts"] if a["id"] != aid]
    _write(d)
    _drop(aid)


def set_mode(m: str) -> None:
    if m in MODES:
        d = _load()
        d["mode"] = m
        _write(d)


def save(psid: Optional[str] = None, psidts: Optional[str] = None,
         mode: Optional[str] = None) -> None:
    """The first version's call: one account (a1) + the mode. "" removes it."""
    if mode is not None:
        set_mode(mode)
    if psid == "":
        for a in list(_load()["accounts"]):
            remove(a["id"])
    elif psid:
        accs = _load()["accounts"]
        if accs:
            update(accs[0]["id"], psid, psidts)
        else:
            add("Account 1", psid, psidts or "")


WEB_MODELS = ("gemini-flash", "gemini-flash-lite", "")   # "" = Gemini's own choice (Auto)
# work the API keys answer first even in mode "first". 2.7.2 (16/11): empty -
# Voice's shorter lines go to the web too: the free keys have ~20 requests a
# day per model (3.6-flash was used up by 16:30) and 7 s for 40 lines is
# little next to voicing them; the keys still answer when the web does not
KEYS_FIRST: tuple = ()


def web_model() -> str:
    m = _load().get("model", "gemini-flash")
    return m if m in WEB_MODELS else "gemini-flash"


def set_model(m: str) -> None:
    if m in WEB_MODELS:
        d = _load()
        d["model"] = m
        _write(d)


def mode() -> str:
    m = _load().get("mode", "fallback")
    return m if m in MODES else "fallback"


def _accounts_raw() -> List[dict]:
    return [a for a in _load()["accounts"] if a.get("psid")]


def has_cookies() -> bool:
    return bool(_accounts_raw())


def installed() -> bool:
    try:
        import gemini_webapi  # noqa: F401
        return True
    except Exception:
        return False


ADDON = "gemini_web"         # the licence add-on (sold separately, 2.7.3)


def allowed() -> bool:
    """Admin, or a licence with the Gemini web add-on."""
    if is_admin():
        return True
    try:
        from . import license as lic

        return lic.has_addon(ADDON)
    except Exception:
        return False


def consented() -> bool:
    """The Admin, or a customer who read the warning and agreed (once)."""
    return is_admin() or bool(settings.get("gemini_web_consent", False))


def set_consent(on: bool) -> None:
    settings.set("gemini_web_consent", bool(on))


def is_admin() -> bool:
    try:
        from . import plans

        return bool(plans.is_admin())
    except Exception:
        return False


def _ready(aid: str) -> bool:
    return time.time() >= _until.get(aid, 0.0)


def available() -> bool:
    """Admin / add-on + agreed + an account not resting + library + not off."""
    return (allowed() and consented() and mode() != "off" and installed()
            and any(_ready(a["id"]) for a in _accounts_raw()))


def accounts() -> List[dict]:
    """For the Gateway / the Admin panel - never the cookies."""
    now = time.time()
    out = []
    for a in _accounts_raw():
        aid = a["id"]
        until = _until.get(aid, 0.0)
        if until > now:
            state = "resting"
        elif _busy.get(aid):
            state = "working"
        else:
            state = "ready"
        out.append({"id": aid, "label": a.get("label", ""), "masked": mask(a.get("label", "")),
                     "state": state, "until": until, "error": _err.get(aid, ""),
                     "last": _last.get(aid, 0.0),
                     "used": _used.get(aid, 0),
                     "req5h": gemini_stats.source_counts(mask(a.get("label", "")), 5.0)})
    return out


def status() -> str:
    if not allowed():
        return ""
    if not installed():
        return "Not installed – run install_gemini_web.bat"
    accs = accounts()
    if not accs:
        return "No account yet"
    if mode() == "off":
        return "Off"
    ready = sum(a["state"] != "resting" for a in accs)
    used = sum(a["used"] for a in accs)
    return f"{ready} of {len(accs)} accounts ready" + (f" · {used} answers since start" if used else "")


def _drop(aid: str) -> None:
    """New cookies / removed: a new sign-in next time."""
    with _lock:
        old = _clients.pop(aid, None)
        _until.pop(aid, None)
        _err.pop(aid, None)
    if old is not None and _loop is not None:
        try:
            asyncio.run_coroutine_threadsafe(old.close(), _loop)
        except Exception:
            pass


def reset() -> None:
    for aid in list(_clients) + list(_until):
        _drop(aid)


def stop() -> None:
    """Stop the web thread (closing the app; tests)."""
    global _loop
    reset()
    with _lock:
        loop, _loop = _loop, None
    if loop is not None:
        loop.call_soon_threadsafe(loop.stop)


# --------------------------------------------------------------------------- #
# the clients (one event loop in its own thread)
# --------------------------------------------------------------------------- #
def _ensure_loop() -> asyncio.AbstractEventLoop:
    global _loop
    with _lock:
        if _loop is None or not _loop.is_running():
            _loop = asyncio.new_event_loop()
            t = threading.Thread(target=_loop.run_forever, name="gemini-web", daemon=True)
            t.start()
        return _loop


async def _ask(acc: dict, prompt: str) -> str:
    aid = acc["id"]
    c = _clients.get(aid)
    if c is None:
        from gemini_webapi import GeminiClient

        c = GeminiClient(acc.get("psid", ""), acc.get("psidts", "") or None)
        await c.init(timeout=TIMEOUT_S, auto_close=False, auto_refresh=True)
        _clients[aid] = c
    # 2.7.2 (16/11): a temporary chat - it does not fill the account's chat
    # history (Po's sidebar was full of dubbing chats) and it does not use the
    # account's memory of earlier chats (names of other stories came back)
    # 2.7.2 (16/11): "Gemini Auto" picks a thinking model - slow (Voice waited
    # on every batch). The fast Flash model is asked by name; if the account /
    # library does not know it, the default one.
    m = web_model()
    try:
        r = await c.generate_content(prompt, model=m, temporary=True) if m else \
            await c.generate_content(prompt, temporary=True)
    except TypeError:                   # an older gemini-webapi
        r = await c.generate_content(prompt)
    except Exception as e:
        if not m or "model" not in str(e).lower():
            raise
        r = await c.generate_content(prompt, temporary=True)
    return (getattr(r, "text", "") or "").strip()


def _rest(aid: str, err: str) -> None:
    with _lock:
        _until[aid] = time.time() + REST_S
        _err[aid] = err[:160]
        _clients.pop(aid, None)
    print(f"[gemini-web] {aid} rests an hour: {err[:160]}")


def text_only(parts: List[dict]) -> Optional[str]:
    """The prompt when every part is text (None = sound or images in it)."""
    out = []
    for p in parts or []:
        if set(p) != {"text"}:
            return None
        out.append(str(p["text"]))
    return "\n\n".join(out) if out else None


def _take(should_stop=None) -> Optional[dict]:
    """The next ready account that is not busy (waits while all are busy)."""
    t0 = time.time()
    while True:
        with _lock:
            accs = _accounts_raw()
            if not any(_ready(a["id"]) for a in accs):
                return None
            n = len(accs)
            for k in range(n):
                a = accs[(_turn[0] + k) % n]
                if _ready(a["id"]) and not _busy.get(a["id"]):
                    _turn[0] = (_turn[0] + k + 1) % n
                    _busy[a["id"]] = True
                    return a
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        if time.time() - t0 > TIMEOUT_S:
            return None
        time.sleep(0.3)


def _one(acc: dict, prompt: str, should_stop=None) -> str:
    fut = asyncio.run_coroutine_threadsafe(_ask(acc, prompt), _ensure_loop())
    t0 = time.time()
    while True:
        try:
            return fut.result(timeout=1.0)
        except TimeoutError:
            if should_stop and should_stop():
                fut.cancel()
                raise InterruptedError("Cancelled")
            if time.time() - t0 > TIMEOUT_S:
                fut.cancel()
                raise RuntimeError("did not answer in time")


def generate(parts: List[dict], should_stop=None) -> Tuple[str, str]:
    """(text, "STOP") like gemini.generate - raises RuntimeError when no account
    can answer (the caller goes on with the API keys / Google)."""
    if not available():
        raise RuntimeError("Gemini web is not available")
    prompt = text_only(parts)
    if not prompt:
        raise RuntimeError("Gemini web: text only")
    tried = set()
    while True:
        if should_stop and should_stop():
            raise InterruptedError("Cancelled")
        acc = _take(should_stop)
        if acc is None or acc["id"] in tried:
            if acc is not None:
                _busy[acc["id"]] = False
            raise RuntimeError("Gemini web: no account could answer")
        aid = acc["id"]
        tried.add(aid)
        sid = gemini_stats.start(mask(acc.get("label", "")), "web", "web")
        try:
            text = _one(acc, prompt, should_stop)
        except InterruptedError:
            gemini_stats.end(sid, "retried")
            raise
        except Exception as e:
            gemini_stats.end(sid, "retried")
            _rest(aid, f"{type(e).__name__}: {e}")
            continue
        finally:
            _busy[aid] = False
            _last[aid] = time.time()             # 2.7.2: the Router page
        if not text:
            gemini_stats.end(sid, "retried")
            _rest(aid, "empty answer")
            continue
        gemini_stats.end(sid, "answered")
        with _lock:
            _used[aid] = _used.get(aid, 0) + 1
        return text, "STOP"


def test(aid: Optional[str] = None) -> Tuple[bool, str]:
    """Sign in with one account and ask one short question (the Test button)."""
    if not installed():
        return False, "gemini-webapi is not installed – run install_gemini_web.bat"
    accs = _accounts_raw()
    acc = next((a for a in accs if a["id"] == aid), accs[0] if accs else None)
    if acc is None:
        return False, "Add an account first"
    _drop(acc["id"])
    sid = gemini_stats.start(mask(acc.get("label", "")), "web", "web")
    try:
        text = _one(acc, 'Answer only with JSON: {"ok": true}')
    except Exception as e:
        gemini_stats.end(sid, "retried")
        _rest(acc["id"], f"{type(e).__name__}: {e}")
        return False, f"{type(e).__name__}: {str(e)[:120]}"
    gemini_stats.end(sid, "answered")
    return True, f"{mask(acc.get('label', ''))} signed in – Gemini answered: {text[:60]}"
