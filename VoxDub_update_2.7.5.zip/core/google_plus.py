"""
google_plus.py - 2.7.2 (18/11): Google Translate free, made better.

Po wants to dub without paying for Gemini keys or using the Gemini web
accounts. The merged video with Google Translate free (15/11) showed what goes
wrong, and what can be mended without an AI:

  1. Names in Latin letters: 37 of 414 lines ("Hongmei", "Lin Weidong",
     "Liu Zhiqing" / "Liu Zhiqiang" for the same man). A Khmer voice reads them
     as English. -> the name is found in the Chinese line (by its pinyin), and
     written in Khmer from the Chinese characters - the same way every time.
     Lines where Google translated the name as words (红梅 "red plum") are sent
     again with the Khmer name put in. The names go to the glossary, so the
     next episodes use them too (and the user can change them there).
  2. Lines that came back in English ("WHO?" for 谁？) -> asked again one by one,
     then a short list of everyday words.
  3. Lines the user corrected before (core/learn.py) -> the user's words, when
     the Chinese line is the same.
"""

import re
from typing import Callable, Dict, List, Sequence, Tuple

from .hanzi_pinyin import PINYIN, SYLLABLES

# --------------------------------------------------------------------------- #
# pinyin -> Khmer letters
# --------------------------------------------------------------------------- #
_INITIALS = ("zh", "ch", "sh", "b", "p", "m", "f", "d", "t", "n", "l", "g", "k", "h",
             "j", "q", "x", "r", "z", "c", "s", "y", "w")
_KM_INITIAL = {
    "b": "ប៉", "p": "ផ", "m": "ម", "f": "ហ្វ", "d": "ត", "t": "ថ", "n": "ន", "l": "ល",
    "g": "ក", "k": "ខ", "h": "ហ", "j": "ជ", "q": "ឈ", "x": "ស៊", "zh": "ជ", "ch": "ឆ",
    "sh": "ស", "r": "រ", "z": "ជ", "c": "ឆ", "s": "ស", "y": "យ", "w": "វ", "": "អ",
}
_KM_FINAL = {
    "a": "ា", "o": "ូ", "e": "ឺ", "i": "ី", "u": "ូ", "v": "ុយ", "ai": "ៃ", "ei": "ី",
    "ao": "ៅ", "ou": "ូវ", "an": "ាន", "en": "ិន", "ang": "ាង", "eng": "ឹង", "ong": "ុង",
    "er": "ើ", "ia": "ៀ", "iao": "ៀវ", "ie": "ៀ", "iu": "ីវ", "ian": "ៀន", "in": "ីន",
    "iang": "ៀង", "ing": "ីង", "iong": "ុង", "ua": "ួ", "uo": "ួ", "uai": "ួយ",
    "ui": "ុយ", "uan": "ួន", "un": "ុន", "uang": "ួង", "ue": "ៀ", "ve": "ៀ",
}
# after j q x y the u is ü
_KM_FINAL_JQXY = {"u": "ុយ", "uan": "ៀន", "un": "ីន", "ue": "ៀ"}
# soft letters that take ៉ before a / ai / ao / ei / an / ang (ម៉ី, វ៉ាង ...)
_SOFT = {"m": "ម៉", "y": "យ៉", "w": "វ៉", "r": "រ៉", "l": "ឡ", "n": "ណ"}
_SOFT_FINALS = ("a", "ai", "ao", "ei", "an", "ang")
_SPECIAL = {"wei": "វៃ", "yi": "យី", "ye": "យៀ", "you": "យូវ", "wu": "វូ", "wo": "វ៉ូ",
            "yong": "យុង", "er": "អើ"}
_WHOLE_I = ("zh", "ch", "sh", "r", "z", "c", "s")     # zhi chi shi ri zi ci si: ឺ


def km_syllable(py: str) -> str:
    py = (py or "").lower().replace("ü", "v")
    if py in _SPECIAL:
        return _SPECIAL[py]
    ini = next((i for i in _INITIALS if py.startswith(i) and len(py) > len(i)), "")
    fin = py[len(ini):]
    if ini in _WHOLE_I and fin == "i":
        return _KM_INITIAL[ini] + "ឺ"
    if ini in ("j", "q", "x", "y") and fin in _KM_FINAL_JQXY:
        return _KM_INITIAL[ini] + _KM_FINAL_JQXY[fin]
    head = _SOFT.get(ini, _KM_INITIAL.get(ini, "")) if fin in _SOFT_FINALS \
        else _KM_INITIAL.get(ini, "")
    if ini in ("y", "w") and fin.startswith(("i", "u")) and fin not in ("i", "u"):
        fin = fin[1:] or fin                     # yin -> in, wan -> an handled below
    return head + _KM_FINAL.get(fin, "")


def km_name(zh: str, split_after: int = 0) -> str:
    """Khmer letters for a Chinese name. split_after: a space after that many
    characters (the family name), 0 = one word."""
    syl = [km_syllable(PINYIN[c]) for c in zh if c in PINYIN]
    if split_after and 0 < split_after < len(syl):
        return "".join(syl[:split_after]) + " " + "".join(syl[split_after:])
    return "".join(syl)


_ADDRESS = {"老": "ពូ", "小": "អា", "阿": "អា"}


def km_address(zh: str) -> str:
    """19/11: 老周 -> ពូចូវ, 小王 -> អាវ៉ាង (Khmer forms of address, not 'ឡាវចូវ')."""
    if len(zh) == 2 and zh[0] in _ADDRESS and zh[1] in PINYIN:
        return _ADDRESS[zh[0]] + km_name(zh[1])
    return ""


# --------------------------------------------------------------------------- #
# names: Latin words in the Khmer line <-> characters in the Chinese line
# --------------------------------------------------------------------------- #
_KHMER = re.compile(r"[\u1780-\u17ff]")
_CJK = re.compile(r"[\u4e00-\u9fff]")
_LATIN_RUN = re.compile(r"[A-Z][a-z]+(?:[ \-][A-Z][a-z]+)*")
_HANZI_RUN = re.compile(r"[一-鿿]+")


def is_pinyin(word: str) -> bool:
    """'hongmei', 'liu zhiqiang' -> True ('who', 'hum' -> False)."""
    w = re.sub(r"[^a-z]", "", (word or "").lower())

    def ok(rest: str) -> bool:
        if not rest:
            return True
        return any(rest.startswith(s) and ok(rest[len(s):])
                   for s in sorted((s for s in SYLLABLES if rest.startswith(s)),
                                   key=len, reverse=True))
    return bool(w) and ok(w)


def _dist(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def match_name(latin: str, original: str) -> str:
    """The characters of the Chinese line Google wrote as `latin`, or ''."""
    want = re.sub(r"[^a-z]", "", latin.lower())
    if not want:
        return ""
    best, best_d = "", 99
    for run in _HANZI_RUN.findall(original or ""):
        for n in range(1, min(4, len(run)) + 1):
            for i in range(len(run) - n + 1):
                part = run[i:i + n]
                if any(c not in PINYIN for c in part):
                    continue
                got = "".join(PINYIN[c] for c in part)
                d = _dist(got, want)
                if d < best_d or (d == best_d and len(part) > len(best)):
                    best, best_d = part, d
    # "Zhiqing" for 志强 (zhiqiang): a letter or two off is still that name
    return best if best and best_d <= max(1, len(want) // 5) else ""


def find_names(originals: Sequence[str], outputs: Sequence[str],
               known: Dict[str, str]) -> Dict[str, str]:
    """{Chinese name: Khmer} for the Latin names Google left in the lines."""
    found: Dict[str, str] = {}
    for zh, km in zip(originals, outputs):
        for latin in _LATIN_RUN.findall(km or ""):
            if not is_pinyin(latin):
                continue
            name = match_name(latin, zh)
            if not name or len(name) < 2 and latin.count(" ") == 0 and len(latin) < 3:
                continue
            if name in known or name in found:
                continue
            # family name + given name (林卫东 -> លីន វៃតុង); two characters are
            # one word (卫南 "Wei Nan" -> វៃណាន)
            words = latin.replace("-", " ").split()
            split = 1 if len(words) > 1 and len(name) >= 3 else 0
            found[name] = km_address(name) or km_name(name, split)
    return found


def put_names(original: str, text: str, names: Dict[str, str]) -> str:
    """Latin names in a Khmer line -> the Khmer of the matching Chinese name."""
    def repl(m):
        latin = m.group(0)
        if not is_pinyin(latin):
            return latin
        zh = match_name(latin, original)
        return names.get(zh, latin) if zh else latin
    return _LATIN_RUN.sub(repl, text or "")


_ZWSP = "\u200b"


def unify_names(original: str, text: str, names: Dict[str, str]) -> str:
    """18/11 (merged, Google + Paraformer): Google also writes the names in
    Khmer letters itself, a little differently each time - "លីន វៃដុង",
    "លី វៃតុង", "វៃ ណាន", "យ៉ាណាន", "ហុង​ម៉ី". When the Chinese line says
    the name, the Khmer close to it becomes the one way of writing it."""
    t = (text or "").replace(_ZWSP, "")
    changed = t != (text or "")
    for zh, km in sorted(names.items(), key=lambda x: -len(x[0])):
        want = (km or "").replace(" ", "")
        if not zh or zh not in (original or "") or len(want) < 4 or km in t:
            continue
        top = max(1, len(want) // 4)
        best = None
        for i in range(len(t)):
            if t[i] == " ":
                continue
            for n in range(max(1, len(want) - top), len(want) + top + 2):
                part = t[i:i + n]
                if len(part) < n or part.endswith(" "):
                    continue
                d = _dist(part.replace(" ", ""), want)
                if d <= top and (best is None or d < best[0]):
                    best = (d, i, n)
        if best:
            _, i, n = best
            t = t[:i] + km + t[i + n:]
            changed = True
    return t if changed else text


# English words Google leaves in a Khmer line ("MEAN អ្វី?", "Boss", "Ah")
ENGLISH_KM = {
    "boss": "ថៅកែ", "mean": "មានន័យ", "ah": "អា", "oh": "អូ", "ok": "អូខេ", "okay": "អូខេ",
    "hey": "ហេ", "hi": "សួស្តី", "hello": "សួស្តី", "sorry": "សុំទោស", "mom": "ម៉ាក់",
    "dad": "ប៉ា", "wow": "វ៉ាវ", "yes": "បាទ", "no": "ទេ", "who": "នរណា", "what": "អី",
    "brother": "បង", "sister": "បងស្រី", "uncle": "ពូ", "aunt": "មីង", "go": "ទៅ",
    "come": "មក", "please": "សូម", "thanks": "អរគុណ", "thank you": "អរគុណ", "huh": "ហ៎",
    "hmm": "អឹម", "hum": "ហឹម", "eh": "អេ",
}
_ENGLISH_WORD = re.compile(r"\b(thank you|[A-Za-z]+)\b")


def english_words(text: str) -> str:
    """Common English words left in a Khmer line -> Khmer (names were done before)."""
    if not _KHMER.search(text or ""):
        return text
    return _ENGLISH_WORD.sub(lambda m: ENGLISH_KM.get(m.group(1).lower(), m.group(1)), text)


# --------------------------------------------------------------------------- #
# lines that came back in English
# --------------------------------------------------------------------------- #
_KHMER = re.compile(r"[ក-៿]")
_CJK = re.compile(r"[一-鿿]")
EVERYDAY_KM = {
    "谁": "នរណា", "什么": "អី", "为什么": "ហេតុអី", "怎么了": "មានរឿងអី", "怎么": "ម៉េច",
    "好": "បាទ", "好的": "បាទ", "是": "មែន", "是的": "មែនហើយ", "对": "ត្រូវហើយ",
    "不": "ទេ", "不是": "មិនមែនទេ", "没有": "អត់ទេ", "嗯": "អឹម", "啊": "អា", "哦": "អូ",
    "喂": "អាឡូ", "走": "ទៅ", "走吧": "ទៅៗ", "快": "លឿនឡើង", "等等": "ចាំបន្តិច",
    "谢谢": "អរគុណ", "对不起": "សុំទោស", "妈": "ម៉ាក់", "爸": "ប៉ា", "哥": "បង",
    "姐": "បងស្រី", "行": "បាន", "可以": "បាន", "真的": "ពិតមែន", "真的吗": "ពិតមែនឬ",
    "站住": "ឈប់", "滚": "ចេញទៅ", "闭嘴": "បិទមាត់", "救命": "ជួយផង", "天哪": "ព្រះអើយ",
}


def english_left(original: str, text: str) -> bool:
    return bool(_CJK.search(original or "")) and bool(text.strip()) \
        and not _KHMER.search(text)


def everyday(original: str) -> str:
    core = re.sub(r"[\s，。！？、…,.!?~～\"“”']", "", original or "")
    return EVERYDAY_KM.get(core, "")


# --------------------------------------------------------------------------- #
# the whole thing
# --------------------------------------------------------------------------- #
def improve(project, originals: List[str], outputs: List[str], terms: Dict[str, str],
            source: str, target: str,
            translate: Callable[[List[str]], List[str]],
            one: Callable[[str], str]) -> Tuple[List[str], Dict[str, str], List[str]]:
    """Mends Google's lines. translate(lines) = Google for several lines,
    one(line) = Google for one line, another way. Returns (lines, new names,
    notes)."""
    out = list(outputs)
    notes: List[str] = []
    if target != "km":
        return out, {}, notes
    hanzi = sum(1 for t in originals if _CJK.search(t or "")) >= max(1, len(originals) // 3)
    names: Dict[str, str] = {}
    if hanzi:
        names = find_names(originals, out, terms)
        if names:
            all_names = dict(terms)
            all_names.update(names)
            fixed = 0
            for i, (zh, km) in enumerate(zip(originals, out)):
                new = put_names(zh, km, all_names)
                if new != km:
                    out[i] = new
                    fixed += 1
            # lines that say the name but where Google translated it as words
            again = [i for i, zh in enumerate(originals)
                     if any(n in zh for n in names)
                     and not any(names[n] in out[i] for n in names if n in zh)]
            if again:
                from .glossary import apply_before_google

                try:
                    redo = translate([apply_before_google(originals[i], all_names)
                                      for i in again])
                    for i, t in zip(again, redo):
                        if t and _KHMER.search(t):
                            out[i] = t
                            fixed += 1
                except Exception as e:
                    print(f"[google+] names again: {e}")
            notes.append(f"Google+: {len(names)} names written in Khmer "
                         f"({', '.join(f'{a} {b}' for a, b in list(names.items())[:6])})"
                         f" · {fixed} lines")
    if hanzi:
        # one way of writing each name, also where Google wrote it in Khmer itself
        all_names = dict(terms)
        all_names.update(names)
        same = 0
        for i, zh in enumerate(originals):
            new = unify_names(zh, out[i], all_names)
            if new != out[i]:
                out[i] = new
                same += 1
        if same:
            notes.append(f"Google+: {same} names written the same way")
    # 19/11 (merged): Japanese "は。" left by Google in a Khmer line
    from .gemini import _NOT_KM

    for i, t in enumerate(out):
        new = re.sub(r"\s{2,}", " ", re.sub(_NOT_KM + r"+[\u17b6-\u17d3]*", "", t or "")).strip()
        if new != t and (new or not _KHMER.search(t or "")):
            out[i] = new
    words = 0
    for i, t in enumerate(out):
        new = english_words(t)
        if new != t:
            out[i] = new
            words += 1
    if words:
        notes.append(f"Google+: English words in {words} lines")
    # English left in a Khmer line
    eng = [i for i, (zh, km) in enumerate(zip(originals, out)) if english_left(zh, km)]
    mended = 0
    for i in eng:
        t = ""
        try:
            t = one(originals[i])
        except Exception:
            t = ""
        if not (t and _KHMER.search(t)):
            t = everyday(originals[i])
        if t:
            out[i] = t
            mended += 1
    if eng:
        notes.append(f"Google+: {mended} of {len(eng)} lines that came back in English "
                     f"translated again")
    # the user's own corrections of the same line
    try:
        from . import learn

        mine = {}
        for it in learn.load(learn.path_for(project)) + learn.load(learn.my_path()):
            o, a = (it.get("o") or "").strip(), (it.get("b") or "").strip()
            if o and a:
                mine.setdefault(o, a)
        used = 0
        for i, zh in enumerate(originals):
            a = mine.get((zh or "").strip())
            if a and out[i] != a:
                out[i] = a
                used += 1
        if used:
            notes.append(f"Google+: {used} lines as you corrected them before")
    except Exception as e:
        print(f"[google+] corrections: {e}")
    return out, names, notes
