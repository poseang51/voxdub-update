"""
fit.py - 2.7.2: a translated line too long for its time is said shorter.

A Khmer line is often longer than the Chinese one. Before, the voice was sped
up (or the video slowed, or the end cut) - it sounded rushed. Now, after the
voices are made, the lines whose voice needs more than FIT_RATIO x its time
are given to Gemini once: "say the same thing in about N letters" (same
meaning, names and forms of address). The shorter line is voiced again and
kept only when its voice really is shorter; the long one stays in
Segment.long_translation (shown in the line's tooltip).

Needs a Gemini key (Gemini or Gemini Router). Never fatal: no key, no quota
or a bad answer - the lines stay as they were.
"""

from typing import Dict, List, Optional, Sequence, Tuple

FIT_RATIO = 1.2           # the voice needs > 20 % more time than the line has
FIT_RATIO_NATIVE = 1.4    # Edge / Azure speak up to 40 % faster and still sound
                          # natural (pipeline.MAX_EDGE_RATE): only longer lines are
                          # shortened (a 40-minute film had 75 % of its lines cut)
KEEP = 0.92               # aim a bit under the time: the voice has its pauses
MIN_PART = 0.3            # a "shorter" line under 30 % of the old one lost meaning
MAX_LINES = 40            # per request
TIME_LIMIT = 150.0        # s for one request: it is only an improvement


class FitUnavailable(Exception):
    """Gemini could not be asked (no quota, no answer): stop asking for this Voice."""


def wanted(project) -> bool:
    from . import gemini, settings

    if not settings.get("fit_lines", True) or not gemini.configured():
        return False
    src = project.source_lang if project.source_lang != "auto" else project.detected_lang
    return bool(project.target_lang) and src != project.target_lang


def too_long(durations: Sequence[float], slots: Sequence[float],
             ratio: float = FIT_RATIO) -> List[int]:
    """Indexes of the voices that need more than `ratio` x their time."""
    return [k for k, (d, s) in enumerate(zip(durations, slots))
            if d and s and s != float("inf") and d / s > ratio]


def ratio_for(engine: str) -> float:
    return FIT_RATIO_NATIVE if engine in ("edge", "azure") else FIT_RATIO


def target_len(text: str, dur: float, slot: float) -> int:
    return max(2, int(len(text.strip()) * slot / dur * KEEP))


def _prompt(rows: List[Tuple[int, str, str, float, int]], tname: str) -> str:
    body = "\n".join(f'{i}. original: {o}\n   now ({len(t)} letters): {t}\n'
                     f'   time: {sec:.1f} s - write at most {n} letters'
                     for i, o, t, sec, n in rows)
    return f"""These {tname} lines of a dubbed drama are too long: the AI voice cannot say them in the time the actor speaks.
Rewrite each one SHORTER, to at most the number of letters given, so it can be spoken naturally in that time.
- Keep the meaning, the feeling and who speaks to whom; keep names, pronouns and forms of address (រាជសព្ទ, ទូលបង្គំ, បង, អូន ...).
- Spoken {tname} as people really talk - drop filler words and repeats, never the point of the line.
- Only {tname} script, no other language.

{body}

Answer ONLY with JSON: {{"lines": [{{"i": <number>, "t": "<shorter line>"}}, ...]}}"""


def _ok(old: str, new: str, lang: str) -> bool:
    from .gemini import foreign_bits, right_script

    new = (new or "").strip()
    return (bool(new) and len(new) < len(old.strip()) * 0.97
            and len(new) >= len(old.strip()) * MIN_PART
            and right_script(new, lang) and not foreign_bits(new, lang))


def shorten(project, items: List[Tuple[str, str, float, float]],
            should_stop=None) -> Dict[int, str]:
    """items: (original line, translation, voice seconds, seconds it has).
    Returns {index: shorter translation} for the lines Gemini made shorter."""
    from . import gemini
    from .translate import LANGUAGES

    tname = LANGUAGES.get(project.target_lang, (project.target_lang, ""))[0]
    models = gemini.router_models() if project.translate_engine == "gemini-router" else None
    out: Dict[int, str] = {}
    for b0 in range(0, len(items), MAX_LINES):
        if should_stop and should_stop():
            break
        part = items[b0:b0 + MAX_LINES]
        rows = [(k + 1, o, t, slot, target_len(t, dur, slot))
                for k, (o, t, dur, slot) in enumerate(part)]
        try:
            from . import gemini_stats

            with gemini_stats.work("Shorter lines", len(rows)):
                text, _ = gemini.generate([{"text": _prompt(rows, tname)}], temperature=0.2,
                                          max_tokens=8192, should_stop=should_stop,
                                          models=models, time_limit=TIME_LIMIT)
        except InterruptedError:
            raise
        except Exception as e:                  # no key / no quota: keep the lines
            print(f"[fit] not shortened: {str(e)[:160]}")
            raise FitUnavailable(str(e)[:160])
        try:
            data = gemini._json(text)
        except ValueError:          # 17/11: a broken answer stopped the whole Auto Dub
            print("[fit] not shortened: the answer was not JSON")
            continue
        for it in (data.get("lines") if isinstance(data, dict) else None) or []:
            try:
                k = int(it["i"]) - 1
                new = str(it["t"]).strip()
            except (KeyError, TypeError, ValueError):
                continue
            if 0 <= k < len(part) and _ok(part[k][1], new, project.target_lang):
                out[b0 + k] = new
    return out

