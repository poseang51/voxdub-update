"""
funasr_worker.py - speech-to-text with FunASR (Alibaba, MIT) for SARIKA VOXDUB PRO.

Runs with the VoxCPM Python (venv-voxcpm already has torch + funasr +
modelscope). The app starts it once per transcription:

    python -u funasr_worker.py            (one JSON request on stdin)
    -> {"wav": "C:/.../audio.wav", "model": "paraformer" | "sensevoice" | "funasr-nano" | "qwen3-asr",
        "device": "auto" | "cuda" | "cpu", "start_at": 0.0}

and reads one JSON object per line from stdout:

    {"p": 40, "msg": "..."}                     progress
    {"seg": {"start": 1.2, "end": 3.4, "text": "...", "lang": "zh"}}
    {"ok": true, "lang": "zh", "device": "cuda", "count": 120}   at the end
    {"ok": false, "error": "..."}

paraformer: Paraformer-zh + fsmn-vad + ct-punc (Mandarin, sentence times).
sensevoice: fsmn-vad cuts the speech, SenseVoice-Small reads every part
            (zh / yue / en / ja / ko).
funasr-nano: fsmn-vad cuts the speech, Fun-ASR-Nano-2512 (Tongyi 2025, 0.8 B,
            Apache-2.0; zh / en / ja + Chinese dialects) reads every part.
The models download from ModelScope the first time (about 1 GB), then cached.
"""

import json
import os
import re
import time
import sys
import traceback

# this file sits in the app's core/ folder: keep that folder off the path
_HERE = os.path.normcase(os.path.dirname(os.path.abspath(__file__)))
sys.path[:] = [p for p in sys.path
               if os.path.normcase(os.path.abspath(p or os.getcwd())) != _HERE]

SR = 16000
MAX_PART_MS = 6000           # SenseVoice: one subtitle line is at most ~6 s
                             # (12 s put 4-5 sentences of 2 people in one line)
TAG = re.compile(r"<\|[^|]*\|>")
LANGS = {"zh", "yue", "en", "ja", "ko"}


def say(obj) -> None:
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def _device(want: str) -> str:
    if want in ("cpu", "cuda"):
        return want
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"


def _load_audio(path: str):
    import numpy as np
    import soundfile as sf

    data, sr = sf.read(path, dtype="float32", always_2d=True)
    data = data.mean(axis=1)
    if sr != SR:
        n = int(len(data) * SR / sr)
        data = np.interp(np.linspace(0, len(data), n, endpoint=False),
                         np.arange(len(data)), data).astype("float32")
    return data


CJK = "\u3000-\u303f\u3400-\u9fff\uff00-\uffef"


def _clean(text: str) -> str:
    t = re.sub(r"\s+", " ", TAG.sub("", text or "")).strip()
    return re.sub(f"(?<=[{CJK}]) (?=[{CJK}])", "", t)      # 你 好 -> 你好


INFO = {}                   # 2.7.2 (20/11): where a reading's time goes (crash_trace)
_MODELS = {}                # (name, device) -> model: kept while the worker serves (2.6.8)


def _model(name, dev, make):
    key = (name, dev)
    if key not in _MODELS:
        _MODELS[key] = make()
    return _MODELS[key]


def _roots():
    home = os.path.expanduser("~")
    ms = os.environ.get("MODELSCOPE_CACHE", "")
    return [r for r in (ms, os.path.join(ms, "models") if ms else "",
                        os.path.join(home, ".cache", "modelscope", "models"),
                        os.path.join(home, ".cache", "modelscope", "hub", "models"),
                        os.path.join(home, ".cache", "modelscope", "hub"),
                        os.path.join(home, ".cache", "huggingface", "hub")) if r]


def _model_dir(part: str) -> str:
    """The folder of the model in the ModelScope / Hugging Face cache ('' = none):
    models/FunAudioLLM--Fun-ASR-Nano-2512 or hub/models/FunAudioLLM/Fun-ASR-Nano-2512."""
    key = part.lower()
    for r in _roots():
        if not os.path.isdir(r):
            continue
        try:
            for a in os.listdir(r):
                sub = os.path.join(r, a)
                if key in a.lower() and os.path.isdir(sub):
                    return sub
                if os.path.isdir(sub):
                    for b in os.listdir(sub):
                        if key in b.lower() and os.path.isdir(os.path.join(sub, b)):
                            return os.path.join(sub, b)
        except OSError:
            continue
    return ""


def _size(path: str):
    """(MB in the folder, a file still downloading in it)"""
    total, part = 0, False
    for root, _d, files in os.walk(path):
        for f in files:
            part = part or f.endswith(".incomplete") or f.endswith(".tmp")
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total / 1e6, part


def _cached(part: str) -> bool:
    """2.7.2: is the whole model already on this PC? (no half-downloaded file)"""
    d = _model_dir(part)
    if not d:
        return False
    mb, unfinished = _size(d)
    return mb > 50 and not unfinished


def _load(key: str, dev, make, name: str, part: str, size_mb: int):
    """Load a model; while it downloads (the first time, ~1-2 GB) say how much
    is done every few seconds - before, the bar stood at 25 % for an hour with
    "first time downloads ~2 GB" and looked frozen (13/11)."""
    import threading

    if (key, dev) in _MODELS:
        INFO["load"] = 0.0
        return _MODELS[(key, dev)]
    t0 = time.time()
    if _cached(part):
        say({"p": 5, "msg": f"Loading {name} into memory..."})
        got = _model(key, dev, make)
        INFO["load"] = round(time.time() - t0, 1)
        return got
    say({"p": 5, "msg": f"Downloading {name} (~{size_mb // 1000 or 1} GB, first time only)..."})
    done = threading.Event()

    def watch():
        while not done.wait(5.0):
            d = _model_dir(part)
            if d:
                mb, _u = _size(d)
                say({"p": 5, "msg": f"Downloading {name}: {int(mb)} MB of ~{size_mb} MB "
                                    f"(first time only)..."})
    t = threading.Thread(target=watch, daemon=True)
    t.start()
    try:
        got = _model(key, dev, make)
        INFO["load"] = round(time.time() - t0, 1)
        return got
    finally:
        done.set()


def run_paraformer(req, dev):
    from funasr import AutoModel

    model = _load("paraformer", dev, lambda: AutoModel(
        model="paraformer-zh", vad_model="fsmn-vad", punc_model="ct-punc",
        vad_kwargs={"max_single_segment_time": 20000},
        device=dev, disable_update=True, disable_pbar=True, log_level="ERROR"),
        "Paraformer-zh", "paraformer", 1000)
    say({"p": 20, "msg": f"Paraformer-zh reading the speech on {dev}..."})
    res = model.generate(input=req["wav"], batch_size_s=int(req.get("batch_s") or 300), sentence_timestamp=True)
    count = 0
    start_at = float(req.get("start_at") or 0.0)
    for item in res or []:
        # 19/11: FunASR's sentence_info moves the text a character further at
        # every sentence ("带我走吧红。" "梅不是..."): the item's whole text and
        # its character times are used when they match, cut by split_sentence
        whole = _clean(item.get("text", ""))
        times = item.get("timestamp") or []
        if whole and times and len([c for c in whole if c not in PUNCT]) == len(times):
            for text, a, b in split_sentence(whole, times, times[0][0], times[-1][1]):
                if not has_words(text) or b <= start_at or b - a < 0.15:
                    continue
                say({"seg": {"start": round(a, 3), "end": round(b, 3), "text": text,
                             "lang": "zh"}})
                count += 1
            continue
        for s in item.get("sentence_info") or []:
            for text, a, b in split_sentence(_clean(s.get("text", "")),
                                             s.get("timestamp") or [],
                                             float(s.get("start", 0)), float(s.get("end", 0))):
                if not has_words(text) or b <= start_at or b - a < 0.15:
                    continue
                say({"seg": {"start": round(a, 3), "end": round(b, 3), "text": text,
                             "lang": "zh"}})
                count += 1
    return "zh", count


GAP_MS = 700                 # a pause this long inside a "sentence" starts a new line
PUNCT = set("，。？！、；：,.?!;:…“”\"'‘’（）()《》-— ")


CUT = set("，。？！；：,.?!;:…")
END_CUT = set("。？！?!…")
LINE_S = 2.0                 # pieces are joined into a line of about this long


def split_sentence(text, stamps, start_ms, end_ms):
    """One Paraformer sentence -> subtitle lines [(text, start_s, end_s)].

    2.7.2 (19/11, merged without the OCR check): the lines were cut where the
    character times had a pause - but Paraformer's character times are off by
    a character or three, so the cut fell inside the words ("带我走吧红。" /
    "梅不是我不想娶你我", "不想委屈你我知道。") and the voice said the wrong
    words at the wrong time. Now the lines are cut at the punctuation (，。？),
    which falls between the words, and the character times only give each
    line its start and end. Short pieces are joined up to about LINE_S, and a
    long pause (a music break) still starts a new line."""
    units = [i for i, ch in enumerate(text) if ch not in PUNCT]
    ok = stamps and len(units) == len(stamps) and all(len(t) == 2 for t in stamps)
    if not ok:
        return [(text, start_ms / 1000.0, end_ms / 1000.0)] if text else []
    # pieces: [first unit, last unit, text end index, ends a sentence]
    pieces, first = [], 0
    for k, i in enumerate(units):
        nxt = units[k + 1] if k + 1 < len(units) else len(text)
        tail = text[i + 1:nxt]
        if k + 1 == len(units) or any(c in CUT for c in tail):
            pieces.append((first, k, nxt, any(c in END_CUT for c in tail)))
            first = k + 1
    lines, cur = [], None
    for f, l, end_i, stop in pieces:
        a_s, b_s = stamps[f][0] / 1000.0, stamps[l][1] / 1000.0
        if cur and (a_s - cur[2] > GAP_MS / 1000.0 or cur[2] - cur[1] >= LINE_S
                    or cur[3]):
            lines.append(cur)
            cur = None
        if cur is None:
            cur = [units[f], a_s, b_s, stop, end_i]
        else:
            cur[2], cur[3], cur[4] = b_s, stop, end_i
    if cur:
        lines.append(cur)
    out = []
    for k, (start_i, a_s, b_s, _, end_i) in enumerate(lines):
        stop_i = lines[k + 1][0] if k + 1 < len(lines) else len(text)
        piece = text[start_i:stop_i].strip()
        if piece:
            out.append((piece, a_s, b_s))
    return out


def run_sensevoice(req, dev):
    from funasr import AutoModel

    vad, asr = _load("sensevoice", dev, lambda: (
        AutoModel(model="fsmn-vad", max_single_segment_time=MAX_PART_MS,
                  device=dev, disable_update=True, disable_pbar=True, log_level="ERROR"),
        AutoModel(model="iic/SenseVoiceSmall", device=dev, disable_update=True,
                  disable_pbar=True, log_level="ERROR")),
        "SenseVoice-Small", "SenseVoiceSmall", 1000)
    audio = _load_audio(req["wav"])
    say({"p": 15, "msg": f"Finding speech on {dev}..."})
    parts = []
    for item in vad.generate(input=audio) or []:
        parts += [p for p in item.get("value") or [] if len(p) == 2]
    start_at = float(req.get("start_at") or 0.0)
    parts = [(a, b) for a, b in parts if b / 1000.0 > start_at]
    langs = {}
    count = 0
    found = []
    asked = req.get("language") or "auto"

    def read(piece, language):
        try:        # 2.7.2 (20/11): the word times, when this FunASR gives them
            out = asr.generate(input=piece, language=language, use_itn=True, batch_size=1,
                               output_timestamp=True)
        except Exception:
            out = asr.generate(input=piece, language=language, use_itn=True, batch_size=1)
        return out[0] if out else {}

    heard = []                  # (a, b, piece, res, raw, lang, text)
    for k, (a, b) in enumerate(parts):
        piece = audio[int(a * SR / 1000):int(b * SR / 1000)]
        if len(piece) < SR // 5:
            continue
        res = read(piece, asked)
        raw = res.get("text", "")
        m = re.search(r"<\|(zh|yue|en|ja|ko)\|>", raw)
        lang = m.group(1) if m else ""
        text = _clean(raw)
        if has_words(text) and lang:
            langs[lang] = langs.get(lang, 0) + 1
        heard.append((a, b, piece, res, raw, lang, text))
        if k % 5 == 0:
            say({"p": 15 + int(85 * (k + 1) / max(1, len(parts))),
                 "msg": f"SenseVoice: {k + 1} / {len(parts)} parts"})
    best = max(langs, key=langs.get) if langs else "zh"

    def same(lang):
        return not lang or lang == best or (best in ("zh", "yue") and lang in ("zh", "yue"))
    again = 0
    for a, b, piece, res, raw, lang, text in heard:
        # 2.7.3 (20/11): a short line in a Chinese film heard as Japanese / English
        # ("醒了" -> "う。"), or speech with no words in "auto", was dropped -
        # SenseVoice lost lines Fun-ASR-Nano had ("ដឹងខ្លួនហើយតើ"). Asked again
        # in the film's language (SenseVoice reads a part in ~0.1 s).
        doubtful = (has_words(text) and not same(lang)) or \
            (not has_words(text) and "<|Speech|>" in raw and b - a >= 400)
        if doubtful and asked == "auto" and best in LANGS:
            res2 = read(piece, best)
            text2 = _clean(res2.get("text", ""))
            # speech, not music ("<|BGM|>": a song stays out, as before)
            if has_words(text2) and "<|Speech|>" in (res2.get("text", "") + raw):
                again += 1
                res, text, lang = res2, text2, best
        if not has_words(text):
            continue
        found.append((a, b, text, lang, sense_stamps(text, res, a, b)))
    INFO["asked_again"] = again
    lines = []
    for a, b, text, lang, stamps in found:
        # music / a shout heard as "Yes。" "Okay。" "う。" in a Chinese film: drop it
        if not same(lang):
            continue
        # 2.7.2 (19/11, merged in Fast mode): one VAD part (up to 6 s) was one
        # line with 2-4 sentences of different people - the voice and the
        # subtitles did not go with the film. Cut into sentences, as Nano -
        # at the words' own times when SenseVoice gives them (20/11)
        got = split_sentence(text, stamps, stamps[0][0], stamps[-1][1]) if stamps else []
        if not got:
            got = sense_lines(text, a / 1000.0, b / 1000.0)
        lines += [(line, s0, e0, lang) for line, s0, e0 in got if has_words(line)]
    # 2.7.2 (20/11): "សាច់គោទ្វេដង / ស៊ុបប្រេងខាប់ / មីមិនគ្រាន់ថែម…" - 0.9 s
    # pieces of one sentence (the 6 s VAD cut) read and sound choppy: joined
    for line, s0, e0, lang in join_short(lines):
        say({"seg": {"start": round(s0, 3), "end": round(e0, 3),
                     "text": line, "lang": lang}})
        count += 1
    return ("zh" if best == "yue" else best), count


JOIN_GAP = 0.3               # s: pieces this close ...
JOIN_SHORT = 1.3             # s: ... when one is this short ...
JOIN_MAX = 4.0               # s: ... become one line up to this long


def join_short(lines):
    """[(text, start, end, lang)] -> the same, a short piece joined to its
    neighbour when the sentence goes on (no 。？！ between them)."""
    out = []
    for line in lines:
        if out:
            t, a, b, lg = out[-1]
            gap = line[1] - b
            if gap <= JOIN_GAP and t and t[-1] not in END_CUT \
                    and (b - a < JOIN_SHORT or line[2] - line[1] < JOIN_SHORT) \
                    and line[2] - a <= JOIN_MAX and line[3] == lg:
                sep = "" if t[-1] in CUT else "，"
                out[-1] = (t + sep + line[0], a, line[2], lg)
                continue
        out.append(line)
    return out


def sense_stamps(text, res, a_ms, b_ms):
    """SenseVoice's word times (output_timestamp) -> one [start, end] ms per
    character of `text` that is not punctuation, on the film's clock - or []
    when this FunASR gives none / they do not fit the text."""
    times = res.get("timestamp") or []
    if not times or not text:
        return []
    try:
        times = [[float(t[0]), float(t[1])] for t in times]
    except (TypeError, ValueError, IndexError):
        return []
    dur = (b_ms - a_ms) / 1000.0
    scale = 1000.0 if times[-1][1] <= dur * 1.2 and dur > 1.0 else 1.0   # seconds?
    times = [[a_ms + x * scale, a_ms + y * scale] for x, y in times]
    units = [ch for ch in text if ch not in PUNCT]
    words = res.get("words") or []
    if len(words) == len(times):
        return qwen_stamps(text, [(str(w), x / 1000.0, y / 1000.0)
                                  for w, (x, y) in zip(words, times)])
    return times if len(times) == len(units) else []


def sense_lines(text, a_s, b_s):
    """SenseVoice gives no word times: the part is cut at 。！？ (and at a comma
    when a sentence is longer than LONG_S), each piece gets the part's time by
    its length."""
    text = (text or "").strip()
    pieces = [x for x in re.split(f"(?<=[{re.escape(END)}])", text) if has_words(x)]
    total = sum(len(x) for x in pieces) or 1
    if (b_s - a_s) * max((len(x) for x in pieces), default=0) / total > LONG_S:
        more = []
        for x in pieces:
            if (b_s - a_s) * len(x) / total > LONG_S:
                more += [y for y in re.split(f"(?<=[{re.escape(SOFT)}])", x) if has_words(y)]
            else:
                more.append(x)
        pieces = more
    if len(pieces) <= 1:
        return [(_clean(text), a_s, b_s)] if has_words(text) else []
    out, t = [], a_s
    for x in pieces:
        d = (b_s - a_s) * len(x) / total
        out.append((_clean(x), t, t + d))
        t += d
    return out


NANO_ID = "FunAudioLLM/Fun-ASR-Nano-2512"
NANO_LANG = {"zh": "中文", "en": "英文", "ja": "日文"}


def half_dtype(dev) -> str:
    """2.7.2 (20/11): "bf16" on a CUDA card that has it (RTX 30xx and newer:
    the dtype Qwen3 was made in) - else "" (float32). float16 was tried on
    the RTX 3050: the LLM overflowed and wrote nothing (0 lines, 10 minutes)."""
    if not str(dev).startswith("cuda"):
        return ""
    try:
        import torch

        return "bf16" if torch.cuda.is_bf16_supported() else ""
    except Exception:
        return ""


def gpu_info(dev) -> None:
    """The card and its free memory before the reading (crash_trace)."""
    if not str(dev).startswith("cuda"):
        return
    try:
        import torch

        free, total = torch.cuda.mem_get_info()
        cap = torch.cuda.get_device_capability()
        INFO["gpu"] = f"{torch.cuda.get_device_name(0)} sm{cap[0]}{cap[1]}"
        INFO["vram_free_mb"] = int(free / 2**20)
        INFO["vram_mb"] = int(total / 2**20)
    except Exception:
        pass


def _half_llm(asr, dev) -> None:
    """2.6.13: the Nano's small LLM in half precision on the GPU (~1.2 GB less):
    its config says fp32, which fills a 4 GB card. 2.7.2: bfloat16 only."""
    m = getattr(asr, "model", None)
    if not half_dtype(dev) or m is None or getattr(m, "llm", None) is None:
        return
    try:
        import torch

        m.llm = m.llm.to(torch.bfloat16)
        m.llm_dtype = "bf16"
    except Exception as e:
        say({"msg": f"Fun-ASR-Nano stays in fp32 ({e})"})


END = "。！？!?…"
KANA_ONLY = re.compile(r"^[\u3040-\u30ff\s\W]+$")   # only kana (+ punctuation), no Han
SOFT = "，,；;：:"
NANO_LINE_S = 2.0            # a line with a comma is cut at it after ~2 s (as Paraformer's)
LONG_S = 3.0                 # SenseVoice: a sentence longer than this is cut at its commas


def nano_lines(text, stamps, a_s, b_s):
    """2.6.13: one VAD part (up to 6 s) often holds 2-4 sentences - one long
    line with them all is hard to read and to voice (EP001: 23 lines where
    the others had 38). Cut it into sentences: at 。！？, at a pause in the
    speech, and at a comma when the line is long. `stamps` are the Nano's
    token times inside the part ({"token", "start_time", "end_time"}, s); without
    them the sentences share the part's time by their length."""
    text = (text or "").strip()
    toks = [t for t in (stamps or []) if isinstance(t, dict) and "token" in t]
    if toks and _clean("".join(str(t["token"]) for t in toks)) == _clean(text):
        lines, cur, t0, last_end = [], "", None, None
        for t in toks:
            tok = str(t["token"])
            st, en = float(t.get("start_time", 0)), float(t.get("end_time", 0))
            if cur.strip() and last_end is not None and st - last_end > GAP_MS / 1000.0 \
                    and _has_words(tok):
                lines.append((cur, t0, last_end))
                cur, t0 = "", None
            if t0 is None and _has_words(tok):
                t0 = st
            cur += tok
            if _has_words(tok):
                last_end = en
            stop = any(c in END for c in tok) or \
                (any(c in SOFT for c in tok) and t0 is not None and en - t0 >= NANO_LINE_S)
            if stop and t0 is not None:
                lines.append((cur, t0, last_end))
                cur, t0 = "", None
        if cur.strip() and t0 is not None:
            lines.append((cur, t0, last_end))
        out = [(_clean(x), a_s + s0, a_s + max(s0, e0)) for x, s0, e0 in lines]
        out = [o for o in out if has_words(o[0])]
        if out:
            # the last line keeps the part's end (the voice may run a little longer)
            return out[:-1] + [(out[-1][0], out[-1][1], max(out[-1][2], b_s))]
    # no times: sentences by their length
    parts = [x for x in re.split(f"(?<=[{re.escape(END)}])", text) if has_words(x)]
    if len(parts) <= 1:
        return [(_clean(text), a_s, b_s)] if has_words(text) else []
    total = sum(len(x) for x in parts)
    out, t = [], a_s
    for x in parts:
        d = (b_s - a_s) * len(x) / total
        out.append((_clean(x), t, t + d))
        t += d
    return out


NANO_CHUNK_S = 15            # s: speech parts read together by Fun-ASR-Nano
CHUNK_GAP_S = 2.0            # s: a longer silence starts a new chunk


def group_parts(parts, max_s=NANO_CHUNK_S, gap_s=CHUNK_GAP_S):
    """VAD parts [(a ms, b ms)] -> groups of neighbours, each group at most
    max_s long from its first start to its last end."""
    groups = []
    for a, b in parts:
        g = groups[-1] if groups else None
        if g and a - g[-1][1] <= gap_s * 1000 and b - g[0][0] <= max_s * 1000:
            g.append((a, b))
        else:
            groups.append([(a, b)])
    return groups


def nano_has_times(res) -> bool:
    toks = [t for t in (res.get("timestamps") or []) if isinstance(t, dict) and "token" in t]
    return bool(toks) and _clean("".join(str(t["token"]) for t in toks)) == \
        _clean(res.get("text", "") or "")


def _has_words(tok):
    return bool(WORD.search(tok or ""))


def run_nano(req, dev):
    import tempfile

    import soundfile as sf
    from funasr import AutoModel


    def make():
        vad = AutoModel(model="fsmn-vad", max_single_segment_time=MAX_PART_MS,
                        device=dev, disable_update=True, disable_pbar=True, log_level="ERROR")
        asr = AutoModel(model=NANO_ID, device=dev, disable_update=True,
                        disable_pbar=True, log_level="ERROR")
        _half_llm(asr, dev)
        return vad, asr
    vad, asr = _load("funasr-nano", dev, make, "Fun-ASR-Nano", "Fun-ASR-Nano", 2000)
    audio = _load_audio(req["wav"])
    say({"p": 15, "msg": f"Finding speech on {dev}..."})
    parts = []
    for item in vad.generate(input=audio) or []:
        parts += [p for p in item.get("value") or [] if len(p) == 2]
    start_at = float(req.get("start_at") or 0.0)
    parts = [(a, b) for a, b in parts if b / 1000.0 > start_at]
    lang = NANO_LANG.get((req.get("language") or "").split("-")[0])
    count = 0
    tmp = tempfile.mkdtemp(prefix="voxdub_nano_")
    kw = {"batch_size": 1, "itn": True}
    if lang:
        kw["language"] = lang
    # 2.7.2 (20/11): FunASR's inference takes llm_dtype from the call ("fp32"
    # when not given) and turns the LLM back to fp32 at every part - the half
    # precision of _half_llm was undone: Nano ran in fp32 (2x the VRAM: on a
    # 4 GB card it spilled into normal memory - 1:38 read in 27 s, then 107 s).
    half = half_dtype(dev)

    def set_dtype(name):
        import torch

        want = {"bf16": torch.bfloat16, "fp32": torch.float32}[name]
        m = asr.model
        if next(m.llm.parameters()).dtype != want:
            m.llm = m.llm.to(want)
        m.llm_dtype = name
        kw["llm_dtype"] = name
    if half:
        try:
            set_dtype(half)
        except Exception as e:
            half = ""
            INFO["half_error"] = f"{type(e).__name__}: {e}"[:120]
    gpu_info(dev)

    def ask(a, b):
        piece = audio[int(a * SR / 1000):int(b * SR / 1000)]
        if len(piece) < SR // 5:
            return None
        wav = os.path.join(tmp, "part.wav")
        sf.write(wav, piece, SR)
        # at most ~12 tokens a second of speech: a confused LLM stops soon
        # instead of writing 512 tokens of nothing (20/11: 10 minutes)
        out = asr.generate(input=[wav], cache={}, max_length=int(len(piece) / SR * 12) + 24,
                           **kw)
        return out[0] if out else {}

    def emit(lines):
        n = 0
        for line, s0, e0 in lines:
            if (not lang or lang == "中文") and KANA_ONLY.match(line):
                continue            # a sigh heard as Japanese "はあ" in a Chinese film
            say({"seg": {"start": round(s0, 3), "end": round(e0, 3),
                         "text": line, "lang": ""}})
            n += 1
        return n

    # 2.7.2 (20/11, "Nano is slow"): the speech parts next to each other are
    # read in ONE go (up to NANO_CHUNK_S): the small LLM starts once per chunk
    # instead of once per 1-6 s part. The token times still cut the lines (a
    # pause between the parts starts a new one); a chunk without times is
    # read again part by part, as before.
    groups = group_parts(parts, int(req.get("chunk_s") or NANO_CHUNK_S))
    INFO.update(parts=len(parts), chunks=len(groups), dtype=kw.get("llm_dtype", "fp32"))
    done = 0
    one_by_one = False          # this Nano gives no token times: parts as before
    try:
        for g in groups:
            if one_by_one and len(g) > 1:
                res = None
                got = None
            else:
                a, b = g[0][0], g[-1][1]
                res = ask(a, b)
                got = None
            if res is not None and half and not has_words(res.get("text", "")) \
                    and b - a >= 3000 and not INFO.get("half_checked"):
                # the first real chunk said nothing in half precision: fp32
                INFO["half_off"] = True
                half = ""
                set_dtype("fp32")
                res = ask(a, b)
            if res is not None and has_words(res.get("text", "")):
                INFO["half_checked"] = True
            if res is not None:
                if len(g) == 1 or nano_has_times(res):
                    got = nano_lines(res.get("text", ""), res.get("timestamps"),
                                     a / 1000.0, b / 1000.0)
            if got is not None:
                count += emit(got)
            else:
                if res is not None and len(g) > 1:
                    one_by_one = True
                    INFO["one_by_one"] = True
                for pa, pb in g:
                    r = ask(pa, pb)
                    if r is not None:
                        count += emit(nano_lines(r.get("text", ""), r.get("timestamps"),
                                                 pa / 1000.0, pb / 1000.0))
            done += len(g)
            say({"p": 15 + int(85 * done / max(1, len(parts))),
                 "msg": f"Fun-ASR-Nano: {done} / {len(parts)} parts"})
    finally:
        import shutil

        shutil.rmtree(tmp, ignore_errors=True)
    return "zh" if not lang or lang == "中文" else req.get("language"), count


QWEN_LANG = {"zh": "Chinese", "yue": "Cantonese", "en": "English", "ja": "Japanese",
             "ko": "Korean"}
QWEN_CODE = {"chinese": "zh", "cantonese": "zh", "english": "en", "japanese": "ja",
             "korean": "ko"}


def run_qwen3(req, dev):
    """2.7.2 (19/11): Qwen3-ASR-0.6B (Alibaba Qwen, Apache-2.0) with
    Qwen3-ForcedAligner-0.6B for the character times. It knows 22 Chinese
    dialects. It runs in its own Python (venv-qwen3asr, setup_qwen3asr.bat):
    qwen-asr needs transformers 4.57, VoxCPM's Python has 5.x."""
    import torch
    from modelscope import snapshot_download
    from qwen_asr import Qwen3ASRModel

    cuda = dev.startswith("cuda")
    dtype = (torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16) \
        if cuda else torch.float32
    where = "cuda:0" if cuda else "cpu"

    def make():
        asr = snapshot_download("Qwen/Qwen3-ASR-0.6B")
        fa = snapshot_download("Qwen/Qwen3-ForcedAligner-0.6B")
        return Qwen3ASRModel.from_pretrained(
            asr, dtype=dtype, device_map=where, max_inference_batch_size=2,
            max_new_tokens=1024, forced_aligner=fa,
            forced_aligner_kwargs=dict(dtype=dtype, device_map=where))
    model = _load("qwen3-asr", dev, make, "Qwen3-ASR-0.6B", "Qwen3-ASR-0.6B", 2400)
    say({"p": 20, "msg": f"Qwen3-ASR reading the speech on {dev}..."})
    want = QWEN_LANG.get(req.get("language") or "", None)
    res = model.transcribe(audio=req["wav"], language=want, return_time_stamps=True)
    r = res[0] if res else None
    if r is None:
        return "zh", 0
    text = _clean(r.text or "")
    stamps = qwen_stamps(text, [(getattr(it, "text", ""), float(getattr(it, "start_time", 0)),
                                 float(getattr(it, "end_time", 0)))
                                for it in (r.time_stamps or [])])
    start_at = float(req.get("start_at") or 0.0)
    count = 0
    if stamps:
        lines = split_sentence(text, stamps, stamps[0][0], stamps[-1][1])
    else:
        lines = []
    for line, a, b in lines:
        if not has_words(line) or b <= start_at or b - a < 0.15:
            continue
        say({"seg": {"start": round(a, 3), "end": round(b, 3), "text": line, "lang": "zh"}})
        count += 1
    lang = QWEN_CODE.get((r.language or "").split(",")[0].strip().lower(), "zh")
    return lang, count


def qwen_stamps(text, items):
    """The aligner's words [(text, start s, end s)] -> one [start ms, end ms]
    per character of `text` that is not punctuation (as Paraformer's), so the
    lines are cut by split_sentence. A character the aligner did not give gets
    the time next to it."""
    units = [i for i, ch in enumerate(text) if ch not in PUNCT]
    if not units or not items:
        return []
    out = [None] * len(units)
    pos = 0
    for word, a, b in items:
        for ch in re.sub(r"\s+", "", word or ""):
            k = pos
            while k < len(units) and k < pos + 4 and text[units[k]] != ch:
                k += 1
            if k < len(units) and text[units[k]] == ch:
                out[k] = [a * 1000.0, b * 1000.0]
                pos = k + 1
    last = None
    for k in range(len(out)):                 # gaps: the time before
        if out[k] is None:
            out[k] = [last[1], last[1]] if last else None
        last = out[k] or last
    nxt = None
    for k in range(len(out) - 1, -1, -1):     # a start with no time: the time after
        if out[k] is None:
            out[k] = [nxt[0], nxt[0]] if nxt else [0.0, 0.0]
        nxt = out[k]
    return out


WORD = re.compile(r"[^\W_]", re.UNICODE)


def has_words(text: str) -> bool:
    """Not only punctuation ("，" alone came back as a line)."""
    return bool(WORD.search(text or ""))


def handle(req) -> bool:
    INFO.clear()
    t0 = time.time()
    try:
        dev = _device(req.get("device", "auto"))
        if req.get("model") == "sensevoice":
            lang, count = run_sensevoice(req, dev)
        elif req.get("model") == "funasr-nano":
            lang, count = run_nano(req, dev)
        elif req.get("model") == "qwen3-asr":
            lang, count = run_qwen3(req, dev)
        else:
            lang, count = run_paraformer(req, dev)
        INFO["all"] = round(time.time() - t0, 1)
        INFO["read"] = round(INFO["all"] - INFO.get("load", 0.0), 1)
        say({"ok": True, "lang": lang, "device": dev, "count": count, "info": INFO})
        return True
    except Exception as e:
        traceback.print_exc(file=sys.stderr)
        say({"ok": False, "error": f"{type(e).__name__}: {e}"[:400]})
        return False


def main() -> int:
    if "--serve" not in sys.argv:              # one request, then exit (as before)
        return 0 if handle(json.loads(sys.stdin.readline() or "{}")) else 1
    # 2.6.8 --serve: one request per line, the models stay loaded between them
    # (a Batch no longer loads Paraformer again for every episode). The app
    # closes stdin (or ends the process) when it is idle or quits.
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except ValueError:
            say({"ok": False, "error": "bad request"})
            continue
        handle(req)
    return 0


if __name__ == "__main__":
    sys.exit(main())
