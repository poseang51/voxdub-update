"""
gemini_stats.py - 2.7.2: the Gateway's live traffic (ui/gateway_view.py).

Every Gemini request - an API key or an Admin web account - is one event:
who answered, what work it was (Translate batch, Names, Proofread, Shorter
lines, Characters, AI check), how long it took, answered / retried / lost,
how many lines. Kept in memory only (the last few thousand), never a key or a
cookie - a source is its masked label.
"""

import statistics
import threading
import time
from collections import deque
from contextlib import contextmanager
from typing import Dict, List, Optional, Tuple

_lock = threading.Lock()
_events: deque = deque(maxlen=5000)
_open: Dict[int, dict] = {}            # running requests (id -> event)
_mark = {"t": time.time()}             # start of "this batch"
_tls = threading.local()
_next = [0]

KINDS = ("Translate batch", "Names", "Proofread", "Shorter lines", "Characters",
         "AI check", "Other")


# --------------------------------------------------------------------------- #
# what the current thread is doing
# --------------------------------------------------------------------------- #
@contextmanager
def work(kind: str, lines: int = 0):
    old = (getattr(_tls, "kind", None), getattr(_tls, "lines", 0))
    _tls.kind, _tls.lines = kind, lines
    try:
        yield
    finally:
        _tls.kind, _tls.lines = old


def kind() -> str:
    return getattr(_tls, "kind", None) or "Other"


def mark_batch() -> None:
    with _lock:
        _mark["t"] = time.time()


# --------------------------------------------------------------------------- #
# recording
# --------------------------------------------------------------------------- #
def start(source: str, src_type: str, model: str = "") -> int:
    with _lock:
        _next[0] += 1
        i = _next[0]
        _open[i] = {"id": i, "t0": time.time(), "t1": None, "src": source, "type": src_type,
                    "model": model, "kind": kind(), "lines": getattr(_tls, "lines", 0),
                    "status": "running"}
    return i


def end(i: int, status: str) -> None:
    """status: answered / retried (429, timeout, refused - another one is asked) / lost."""
    with _lock:
        e = _open.pop(i, None)
        if e is None:
            return
        e["t1"], e["status"] = time.time(), status
        _events.append(e)


def lost(source: str = "", src_type: str = "key") -> None:
    """A request nobody could answer (every key / account used up)."""
    i = start(source or "—", src_type)
    end(i, "lost")


# --------------------------------------------------------------------------- #
# reading (the dashboard)
# --------------------------------------------------------------------------- #
def running() -> List[dict]:
    with _lock:
        return [dict(e) for e in _open.values()]


def events(since: float = 0.0) -> List[dict]:
    with _lock:
        return [dict(e) for e in _events if e["t0"] >= since]


def feed(n: int = 40) -> List[dict]:
    """Newest first: running ones, then the finished."""
    with _lock:
        run = sorted((dict(e) for e in _open.values()), key=lambda e: -e["t0"])
        done = [dict(e) for e in list(_events)[-n:]][::-1]
    return (run + done)[:n]


def summary() -> dict:
    now = time.time()
    batch = events(_mark["t"])
    ans = [e for e in batch if e["status"] == "answered"]
    lost_n = sum(1 for e in batch if e["status"] == "lost")
    replies = [e["t1"] - e["t0"] for e in ans if e["kind"] == "Translate batch"] or \
              [e["t1"] - e["t0"] for e in ans]
    recent = [e for e in events(now - 600) if e["status"] == "answered"
              and e["kind"] == "Translate batch"]
    lines10 = sum(e["lines"] for e in recent)
    span = max(60.0, min(600.0, now - min((e["t0"] for e in recent), default=now)))
    run = running()
    return {
        "requests": len(batch) + len(run),
        "running": len(run),
        "delivered": (len(ans) / (len(ans) + lost_n) * 100.0) if (ans or lost_n) else 100.0,
        "lost": lost_n,
        "median": statistics.median(replies) if replies else 0.0,
        "lines_min": lines10 / (span / 60.0) if recent else 0.0,
    }


def per_minute(minutes: int = 30) -> List[Tuple[int, int, int]]:
    """[(answered, retried, lost)] for each of the last `minutes` minutes."""
    now = time.time()
    out = [[0, 0, 0] for _ in range(minutes)]
    for e in events(now - minutes * 60):
        k = minutes - 1 - int((now - e["t0"]) // 60)
        if 0 <= k < minutes:
            out[k][{"answered": 0, "retried": 1, "lost": 2}.get(e["status"], 1)] += 1
    return [tuple(x) for x in out]


def work_mix() -> List[Tuple[str, int]]:
    counts = {k: 0 for k in KINDS}
    for e in events(_mark["t"]):
        counts[e["kind"] if e["kind"] in counts else "Other"] += 1
    for e in running():
        counts[e["kind"] if e["kind"] in counts else "Other"] += 1
    return [(k, n) for k, n in counts.items() if n or k in KINDS[:5]]


def source_counts(src: str, hours: float = 5.0) -> int:
    since = time.time() - hours * 3600
    return sum(1 for e in events(since) if e["src"] == src and e["status"] == "answered")


def busy_sources() -> Dict[str, str]:
    """source -> the work it is doing now."""
    return {e["src"]: e["kind"] for e in running()}


def reset_for_tests() -> None:
    with _lock:
        _events.clear()
        _open.clear()
        _mark["t"] = time.time()
