"""
pipeline.py - The AI dubbing steps glued together.

Each step works on a Project object (the UI passes a COPY so the timeline
can keep drawing while the work runs in a background thread) and reports
progress through progress(percent, message).

Long videos (resume)
  Every step writes its results into the project AS IT GOES and saves
  <work_dir>/autosave.voxdub.json regularly. If a step fails or is
  cancelled, the finished part is kept, and running it again continues:
    * transcribe  - continues after the last recognised line
    * translate   - only lines that have no translation yet
    * voice       - only lines whose voice is missing or out of date
"""

import os
import threading
import time
from typing import Callable, Dict, List, Optional

from .media import compute_peaks, extract_audio, get_media_info, wav_duration
from .project import Project
from .sync import build_audio_clips, build_subtitles, voice_slot
from . import ocr_subs
from . import settings
from . import steptimes
from . import speakers
from .gender import detect_genders
from .hardsub import detect_subtitle_area
from .transcribe import device_label, transcribe_audio

FUNASR = ("paraformer", "sensevoice", "funasr-nano", "qwen3-asr")   # core/funasr_stt.py
from .tts import AUTO_VOICE, FatalTTSError, TooManyFailures
from .translate import translate_lines
from .tts import synthesize_many

MAX_EDGE_RATE = 40      # % faster Edge speech still sounds natural
VOICE_BATCH = 40        # lines per voice batch (progress is saved after each)

Progress = Callable[[int, str], None]
Stop = Callable[[], bool]


def _scaled(progress: Optional[Progress], lo: int, hi: int) -> Progress:
    """Map a 0..100 progress callback into the lo..hi range."""
    def cb(p, msg):
        if progress:
            progress(lo + int((hi - lo) * max(0, min(100, p)) / 100), msg)
    return cb


class Checkpoint:
    """Saves the project to its autosave file now and then (never raises)."""

    def __init__(self, project: Project, every: float = 15.0):
        self.project = project
        self.every = every
        self.last = time.time()

    def maybe(self):
        if time.time() - self.last >= self.every:
            self.now()

    def now(self):
        self.last = time.time()
        path = self.project.autosave_path()
        if not path:
            return
        try:
            self.project.save(path)
        except Exception as e:      # a full disk must not kill the AI work
            print(f"[autosave] failed: {e}")


def prepare_video(project: Project, video_path: str, work_dir: str,
                  progress: Optional[Progress] = None) -> Project:
    """Read video info and extract a 16 kHz mono WAV of its speech."""
    if progress:
        progress(5, "Reading video information...")
    from .media import needs_mp4, to_mp4

    if needs_mp4(video_path):           # .ts / .flv / .wmv ...: an MP4 copy the player opens
        os.makedirs(work_dir, exist_ok=True)
        if progress:
            progress(8, "Copying the video into MP4 (.ts / .flv / ...)...")
        stem = os.path.splitext(os.path.basename(video_path))[0][:80]
        video_path = to_mp4(video_path, os.path.join(work_dir, stem + ".mp4"))
    info = get_media_info(video_path)
    if not info.has_video:
        raise ValueError("This file has no video stream.")
    os.makedirs(work_dir, exist_ok=True)
    project.video_path = os.path.abspath(video_path)
    project.work_dir = os.path.abspath(work_dir)
    project.video_duration = info.duration
    project.width, project.height = info.width, info.height
    project.fps = info.fps
    project.has_audio = info.has_audio
    project.segments, project.audio_clips, project.subtitle_clips = [], [], []
    project.transcribe_done, project.transcribed_until = False, 0.0
    project.reset_video_track()
    project.original_audio = ""
    if info.has_audio:
        if progress:
            progress(30, "Extracting audio with ffmpeg...")
        wav = os.path.join(project.work_dir, "original_16k.wav")
        extract_audio(video_path, wav, 16000)
        project.original_audio = wav
        if progress:
            progress(80, "Drawing the waveform...")
        compute_peaks(wav)                  # cached on disk -> timeline opens instantly
    if progress:
        progress(100, "Video ready")
    return project


def reset_ai_work(project: Project):
    """Forget transcription, translation and voices (Start over)."""
    project.segments = []
    project.audio_clips = [c for c in project.audio_clips if not c.seg_id]
    project.subtitle_clips = []
    project.transcribe_done, project.transcribed_until = False, 0.0
    project.detected_lang = ""


# --------------------------------------------------------------------------- #
# 1. Transcribe
# --------------------------------------------------------------------------- #
def step_transcribe(project: Project, progress: Optional[Progress] = None,
                    should_stop: Optional[Stop] = None, restart: bool = False) -> Project:
    if not project.original_audio or not os.path.isfile(project.original_audio):
        raise ValueError("This video has no audio track to transcribe.")
    if restart:
        reset_ai_work(project)
    if project.transcribe_done and project.segments:
        if progress:
            progress(100, f"Already transcribed ({len(project.segments)} lines) - skipped")
        return project

    ck = Checkpoint(project)
    start_at = project.transcribed_until if project.segments else 0.0
    lang = project.source_lang
    if lang and lang != "auto" and lang == project.target_lang and start_at <= 0:
        # Speech set to the language we dub INTO (e.g. Khmer for a Chinese
        # drama): Whisper then writes Chinese sound as Khmer letters - nonsense
        # lines, nothing translated, a voice that has nothing to do with the
        # story. Listen with Auto detect instead (a Khmer video is still Khmer).
        note = (f"⚠ Speech was set to {lang} = the language to dub into - listened "
                f"with Auto detect instead (set Speech to Auto detect / the video's language)")
        if note not in project.engine_notes:
            project.engine_notes.append(note)
        lang = "auto"
        project.detected_lang = ""
    if lang == "auto" and project.detected_lang and start_at > 0:
        lang = project.detected_lang       # keep the language found in the first part

    def on_segment(seg):
        project.segments.append(seg)
        project.transcribed_until = seg.end
        ck.maybe()

    def on_language(code):
        if not project.detected_lang:
            project.detected_lang = code

    use_ocr = bool(project.ocr_check) and ocr_subs.available() and project.has_video()
    whisper_progress = _scaled(progress, 0, 85) if use_ocr else progress
    engine = project.stt_engine or "whisper"
    listen_to = project.original_audio
    if engine in FUNASR and project.has_video() \
            and settings.get("stt_voice_only", True):
        # FunASR hears thunder / music / a gasp as words: give it the voices only
        try:
            from . import separate

            if whisper_progress:
                whisper_progress(0, "Separating the voices from the music...")
            with steptimes.timed(project, "separate"):
                listen_to = separate.make_voice_track(
                    project, _scaled(whisper_progress, 0, 30) if whisper_progress else None,
                    should_stop)
            whisper_progress = _scaled(whisper_progress, 30, 100) if whisper_progress else None
            print("[transcribe] listening to the voices only (music removed)")
        except InterruptedError:
            raise
        except Exception as e:
            print(f"[transcribe] voices only not used: {e}")
            listen_to = project.original_audio
    try:
        try:
            with steptimes.timed(project, "STT"):
                _segs, detected = transcribe_audio(
                    listen_to, project.whisper_model, lang, whisper_progress,
                    should_stop, start_at=start_at, on_segment=on_segment,
                    on_language=on_language,
                    **({"engine": engine} if engine != "whisper" else {}))
        except InterruptedError:
            raise
        except Exception as e:
            if engine == "whisper":
                raise
            # Gemini out of quota / no key / no internet, FunASR not set up:
            # carry on with the free offline Whisper from where it stopped
            # (a batch queue must not stop half-way through a series)
            name = {"gemini": "Gemini", "paraformer": "Paraformer-zh",
                    "sensevoice": "SenseVoice", "funasr-nano": "Fun-ASR-Nano",
                    "qwen3-asr": "Qwen3-ASR"}.get(engine, engine)
            note = (f"⚠ {name} speech-to-text stopped ({str(e)[:120]}) - "
                    f"continuing with Whisper (offline)")
            print(f"[fallback] {note}")
            project.engine_notes.append(note)
            if progress:
                progress(0, note)
            start_at = project.transcribed_until if project.segments else 0.0
            if lang == "auto" and project.detected_lang:
                lang = project.detected_lang
            with steptimes.timed(project, "STT"):
                _segs, detected = transcribe_audio(
                    project.original_audio, project.whisper_model, lang, whisper_progress,
                    should_stop, start_at=start_at, on_segment=on_segment,
                    on_language=on_language)
    finally:
        ck.now()

    project.detected_lang = project.detected_lang or detected
    if use_ocr and (project.detected_lang or "") in ocr_subs.OCR_LANGS \
            and os.path.isfile(project.video_path):
        try:
            with steptimes.timed(project, "OCR"):
                double_check_with_screen(project, _scaled(progress, 85, 98), should_stop)
        except InterruptedError:
            raise
        except Exception as e:          # the double-check is a bonus, never fatal
            print(f"[ocr] double-check skipped: {e}")
        ck.now()
    from .transcribe import is_filler

    # "yeah" / "huh" / "啊" alone: no Khmer voice for a grunt or a breath
    project.segments = [s for s in project.segments if not is_filler(s.text)]
    if not project.segments:
        raise ValueError("No speech was found in this video.")
    project.transcribe_done = True
    project.transcribed_until = project.video_duration
    project.audio_clips = [c for c in project.audio_clips if not c.seg_id]
    build_subtitles(project, use_translation=False)
    if progress:
        progress(99, "Finding the characters (who speaks which line)...")
    with steptimes.timed(project, "characters"):    # one voice / character
        detect_characters(project, _scaled(progress, 99, 100), should_stop)
    detect_delivery(project)                # excited / sad / question ... from the speech
    ck.now()
    from . import transcribe as _tr

    while _tr._notes:                       # low GPU memory: what Whisper did instead
        note = "⚠ " + _tr._notes.pop(0)
        if note not in project.engine_notes:
            project.engine_notes.append(note)
    if progress:
        progress(100, f"Transcription done: {len(project.segments)} lines "
                      f"[{_stt_label(project)}]")
    return project


GEMINI_TR = ("gemini", "gemini-router")     # translate_engine values that use Gemini


def _stt_label(project: Project) -> str:
    e = project.stt_engine or "whisper"
    if e == "gemini":
        return "Gemini"
    if e in FUNASR:
        return {"paraformer": "Paraformer-zh", "sensevoice": "SenseVoice",
                "funasr-nano": "Fun-ASR-Nano", "qwen3-asr": "Qwen3-ASR"}[e]
    return device_label(project.whisper_model).split(" - ")[0]


def detect_delivery(project: Project) -> int:
    """How each line is said (Delivery column), from the original speech.
    Never fatal."""
    try:
        from . import emotion

        return emotion.detect(project)
    except Exception as e:
        print(f"[emotion] skipped: {e}")
        return 0


def detect_characters(project: Project, progress: Optional[Progress] = None,
                      should_stop: Optional[Stop] = None) -> int:
    """Who speaks each line (characters A, B, ...) + male / female per line.
    Never fatal: without characters each line is judged on its own as before."""
    try:
        n = speakers.find_speakers(project, progress, should_stop)
        if n and getattr(project, "series_cast", ""):
            from . import series

            known, new = series.apply(project, project.series_cast)   # same cast every episode
            print(f"[series] {known} known characters, {new} new")
    except InterruptedError:
        raise
    except Exception as e:
        print(f"[speakers] skipped: {e}")
        n = 0
    if any(not s.gender for s in project.segments):
        detect_genders(project)
    return n


_AREAS: dict = {}           # (folder, width, height) -> subtitle area found there
AREA_MIN_EVENTS = 5         # fewer subtitles read in a reused area: find it again


_AREA_LOCKS: dict = {}
_AREA_GUARD = threading.Lock()


def _area_lock(key) -> "threading.Lock":
    with _AREA_GUARD:
        return _AREA_LOCKS.setdefault(key, threading.Lock())


def _area_key(project: Project) -> tuple:
    folder = os.path.normcase(os.path.dirname(os.path.abspath(project.video_path or "")))
    return folder, int(project.width or 0), int(project.height or 0)


def double_check_with_screen(project: Project, progress: Optional[Progress] = None,
                             should_stop: Optional[Stop] = None) -> str:
    """Correct Whisper's words with the subtitles burned into the picture
    (OCR) and add the lines it missed. Returns a short report."""
    rect = project.cover_rect if project.cover_enabled else None
    reused = False
    key = _area_key(project)
    if rect is None:
        # Batch "At once 4": all episodes reach this step together - the
        # first one looks for the area, the others wait and use it
        with _area_lock(key):
            if key in _AREAS:
                # 2.6.8: the episodes of one story show their subtitles in the
                # same place - finding it took ~30 s per episode
                rect, reused = _AREAS[key], True
            else:
                if progress:
                    progress(0, "Looking for burned-in subtitles...")
                rect = detect_subtitle_area(project.video_path, should_stop=should_stop)
                if rect is not None:
                    _AREAS[key] = list(rect)
        if rect is None:
            msg = "No burned-in subtitles found - Whisper's text is kept"
            if progress:
                progress(100, msg)
            return msg
    events = ocr_subs.read_burned_subtitles(project.video_path, rect, progress, should_stop)
    if reused and len(events) < AREA_MIN_EVENTS:
        # this episode shows its subtitles somewhere else: look for them
        found = detect_subtitle_area(project.video_path, should_stop=should_stop)
        if found is not None and found != rect:
            _AREAS[key] = list(found)
            again = ocr_subs.read_burned_subtitles(project.video_path, found, progress,
                                                   should_stop)
            if len(again) > len(events):
                events = again
        elif found is None and not events:
            _AREAS.pop(key, None)
    if not events:
        return "No burned-in subtitles could be read - Whisper's text is kept"
    segs, fixed, added = ocr_subs.merge_with_segments(project.segments, events)
    project.segments = segs
    # voices of lines that were changed, joined or removed are out of date
    keep = {s.id for s in segs if s.tts_path}
    project.audio_clips = [c for c in project.audio_clips if not c.seg_id or c.seg_id in keep]
    msg = (f"Double-checked with {len(events)} burned-in subtitles: "
           f"{fixed} lines corrected, {added} missed lines added")
    if progress:
        progress(100, msg)
    print(f"[ocr] {msg}")
    return msg


# --------------------------------------------------------------------------- #
# 2. Translate
# --------------------------------------------------------------------------- #
TRANSLATE_RETRIES = 2          # more rounds for lines the translator gave nothing for
RETRY_WAIT = 4.0               # s before round 1 (round 2: twice as long)


def _clock(t: float) -> str:
    t = max(0, int(t))
    return f"{t // 3600}:{t // 60 % 60:02d}:{t % 60:02d}" if t >= 3600 else f"{t // 60}:{t % 60:02d}"


def _google_plus(project, texts, out, terms, src, should_stop, progress):
    """2.7.2 (18/11): Google Translate free made better - names in Khmer, lines
    that came back in English asked again, the user's own corrections
    (core/google_plus.py)."""
    from . import glossary, google_plus
    from .translate import _fallback_one, google_code

    tgt = project.target_lang
    if progress:
        progress(98, "Google+: names and English words…")
    t0 = time.time()
    try:
        new, names, notes = google_plus.improve(
            project, list(texts), list(out), terms, src, tgt,
            translate=lambda ls: translate_lines(ls, src, tgt, None, should_stop),
            one=lambda t: _fallback_one(t, google_code(src), google_code(tgt)))
    except InterruptedError:
        raise
    except Exception as e:
        print(f"[google+] not used: {e}")
        return out
    for n in notes:
        if n not in project.engine_notes:
            project.engine_notes.append(n)
    if names:
        try:
            glossary.learn(project, names)
        except Exception:
            pass
    _trace(f"[google+] {'; '.join(notes) or 'nothing to mend'} ({time.time() - t0:.0f}s)")
    return new


def step_translate(project: Project, progress: Optional[Progress] = None,
                   should_stop: Optional[Stop] = None, only_missing: bool = True) -> Project:
    if not project.segments:
        raise ValueError("Transcribe the video first.")
    from . import gemini_stats
    from .gemini import fix_khmer

    gemini_stats.mark_batch()           # 2.7.2: "Requests · this batch" starts here
    src = project.source_lang if project.source_lang != "auto" else (project.detected_lang or "auto")
    todo = project.untranslated() if only_missing else \
        [s for s in project.segments if s.text.strip()]
    if not todo:
        if progress:
            progress(100, "All lines already translated - skipped")
        if not project.subtitle_clips or all(not c.seg_id for c in project.subtitle_clips):
            build_subtitles(project, use_translation=True)
        return project

    ck = Checkpoint(project)

    done_now = set()
    km = project.target_lang == "km"

    def on_result(i, text):
        done_now.add(i)
        todo[i].translation = fix_khmer(text) if km else text
        todo[i].long_translation = ""           # a new translation: not shortened
        ck.maybe()

    from . import glossary

    terms = glossary.for_project(project)
    try:
        texts = [s.text for s in todo]
        if project.translate_engine in GEMINI_TR:
            from . import gemini

            title = os.path.splitext(os.path.basename(project.video_path or ""))[0]
            # 2.7.2 (16/11): only the glossary names this video says - "my list"
            # held the names of other stories (江浩 = ឈីង ហ៊ូវ, 钱多多 =
            # ហុងស្រីកែវ) and Gemini gave them to this story's people:
            # 林卫东, 林卫南, 卫西 and 卫北 all became "ឈីង ហ៊ូវ"
            said = "\n".join(s.text for s in project.segments)
            names = {a: b for a, b in terms.items() if a and a in said}
            router = project.translate_engine == "gemini-router"
            from . import learn, register

            ranks: dict = {}
            t_tr = time.time()
            try:
                out = gemini.translate_lines(texts, src, project.target_lang, progress,
                                             should_stop, on_result=on_result, title=title,
                                             names=names,
                                             models=gemini.router_models() if router else None,
                                             speakers=[s.speaker for s in todo],
                                             cast=register.cast_for_prompt(project),
                                             ranks=ranks,
                                             learned=learn.prompt_part(
                                                 learn.examples(project, texts)),
                                             first_names=True)
                t_pr = time.time()
                _trace(f"[translate] {len(texts)} lines: {t_pr - t_tr:.0f}s "
                       f"({gemini.parallel_slots(gemini.router_models(False) if router else None)}"
                       f" side by side)")
                if settings.get("proofread", True) and not (should_stop and should_stop()):
                    # 2.7.2: clear mistakes fixed (spelling, a wrong meaning, a name)
                    if progress:
                        progress(97, "Gemini: checking the spelling and meaning…")
                    try:
                        fix = gemini.proofread(texts, out, project.target_lang, names,
                                               gemini.router_models() if router else None,
                                               should_stop)
                    except InterruptedError:
                        raise
                    except Exception as e:      # the translation is kept as it is
                        print(f"[proofread] not done: {str(e)[:120]}")
                        fix = {}
                    for k, t in fix.items():
                        print(f"[proofread] {out[k]} -> {t}")
                        out[k] = t
                    if fix:
                        print(f"[proofread] {len(fix)} lines fixed")
                    _trace(f"[proofread] {len(fix)} lines fixed: {time.time() - t_pr:.0f}s")
                n_g, why = gemini.google_used()
                if n_g and n_g <= gemini.LAST_TRY_LINES and "quota" not in why.lower():
                    # 2.7.2 (16/11): a few lines Gemini would not translate (the keys
                    # work) - say which, so they can be checked; not "quota"
                    at = ", ".join(_clock(todo[k].start) for k in gemini.google_lines_used()
                                   if 0 <= k < len(todo))
                    note = f"⚠ {n_g} lines translated by Google Translate – please check them: {at}"
                    print(f"[fallback] {note}")
                    project.engine_notes.append(note)
                elif n_g:
                    # 2.7.2: said, not silent - these lines read like Google
                    note = (f"⚠ {n_g} lines translated by Google Translate – Gemini did not "
                            f"answer them" + (f" ({why})" if why else ""))
                    print(f"[fallback] {note}")
                    project.engine_notes.append(note)
                if register.apply_ranks(project, ranks):
                    print(f"[register] ranks found: {ranks}")
                new = glossary.learn(project, {a: b for a, b in names.items()
                                               if a not in terms})
                if new:
                    print(f"[glossary] {new} names kept for the next episodes")
            except InterruptedError:
                raise
            except Exception as e:
                out_of_keys = isinstance(e, gemini.QuotaError) or "Gemini key refused" in str(e)
                if out_of_keys and gemini.when_out() == "stop":
                    # Settings › Gemini › "Stop and tell me": the lines done are kept
                    ck.now()
                    raise RuntimeError(f"Gemini keys used up – the translation stopped "
                                       f"({str(e)[:160]}). Add keys, wait for the daily "
                                       f"reset, or choose Google Translate.") from e
                # quota / key / network: the lines Gemini finished are kept (on_result),
                # Google Translate does the rest so the work never stops half-way
                note = (f"⚠ Gemini translation stopped ({str(e)[:120]}) - "
                        f"Google Translate finishes the remaining lines")
                print(f"[fallback] {note}")
                project.engine_notes.append(note)
                if progress:
                    progress(0, note)
                rest = [k for k in range(len(todo)) if k not in done_now]
                more = translate_lines([glossary.apply_before_google(texts[k], terms)
                                        for k in rest], src, project.target_lang,
                                       progress, should_stop,
                                       on_result=lambda i, t: on_result(rest[i], t))
                more = _google_plus(project, [texts[k] for k in rest], more, terms, src,
                                    should_stop, progress)
                out = [s.translation for s in todo]
                for k, t in zip(rest, more):
                    out[k] = t
        else:
            out = translate_lines([glossary.apply_before_google(t, terms) for t in texts],
                                  src, project.target_lang,
                                  progress, should_stop, on_result=on_result)
            out = _google_plus(project, texts, out, terms, src, should_stop, progress)
        for seg, tr in zip(todo, out):
            seg.translation = fix_khmer(tr) if km else tr
        # lines the service gave nothing back for (busy / limit for a moment):
        # ask again a little later - before, they stayed silent in the video
        for round_ in range(TRANSLATE_RETRIES):
            missing = [s for s in todo if s.text.strip() and not s.translation.strip()]
            if not missing:
                break
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            if progress:
                progress(99, f"{len(missing)} lines not translated yet - trying again "
                             f"({round_ + 1}/{TRANSLATE_RETRIES})…")
            time.sleep(RETRY_WAIT * (round_ + 1))
            again = translate_lines([glossary.apply_before_google(s.text, terms)
                                     for s in missing], src, project.target_lang,
                                    None, should_stop)
            for s, t in zip(missing, again):
                if t and t.strip():
                    s.translation = t
        left = [s for s in todo if s.text.strip() and not s.translation.strip()]
        if left:
            note = (f"⚠ {len(left)} lines could not be translated (no voice there) - "
                    f"click 2 · Translate again later")
            if note not in project.engine_notes:
                project.engine_notes.append(note)
    finally:
        build_subtitles(project, use_translation=True)
        ck.now()
    if progress:
        progress(100, f"Translated {len(todo)} lines")
    return project


# --------------------------------------------------------------------------- #
# 3. AI voice
# --------------------------------------------------------------------------- #
def step_voice(project: Project, only_ids: Optional[List[str]] = None,
               progress: Optional[Progress] = None,
               should_stop: Optional[Stop] = None, force: bool = False) -> Project:
    """Generate AI voices and place them on the timeline.

    only_ids  - exactly these lines (Re-voice selected)
    force     - every line again (Re-voice all)
    otherwise - only lines whose voice is missing or out of date (resume)
    """
    project._fit_off = False             # 2.7.2: Gemini is asked again for this Voice
    if not project.segments:
        raise ValueError("Transcribe the video first.")
    tts_dir = os.path.join(project.work_dir, "tts")
    os.makedirs(tts_dir, exist_ok=True)
    stamp = time.strftime("%H%M%S")

    if only_ids is not None:
        wanted = set(only_ids)
        targets = [s for s in project.segments if s.id in wanted and s.voice_text()]
    elif force:
        targets = [s for s in project.segments if s.voice_text()]
    else:
        targets = project.stale_voices()

    if not targets:
        if only_ids is not None:
            raise ValueError("Nothing to voice - the selected lines are empty.")
        _place_missing_clips(project)
        if progress:
            progress(100, "All voices are up to date - skipped")
        return project

    src = project.source_lang if project.source_lang != "auto" else project.detected_lang
    if src != project.target_lang and not any(s.translation.strip() for s in targets):
        raise ValueError("These lines are not translated yet - run Translate (step 2) first.\n"
                         "The target-language voice cannot speak the original language.")

    # characters are found after Transcribe (or with 👥 Find characters); an
    # older project with no genders at all gets them here
    if not project.cast and not any(s.gender for s in project.segments):
        if progress:
            progress(0, "Finding the characters (who speaks which line)...")
        detect_characters(project, None, should_stop)
    elif project.voice == AUTO_VOICE and any(not s.gender for s in targets):
        detect_genders(project)

    full_rebuild = only_ids is None and len(targets) == len(project.segments)
    order = sorted(project.segments, key=lambda s: s.start)
    nxt = {s.id: (order[i + 1].start if i + 1 < len(order) else None)
           for i, s in enumerate(order)}
    ck = Checkpoint(project)
    done_ids: List[str] = []
    failed = 0
    n = len(targets)

    try:
        for b0 in range(0, n, VOICE_BATCH):
            if should_stop and should_stop():
                raise InterruptedError("Cancelled")
            batch = targets[b0:b0 + VOICE_BATCH]
            lo, hi = 92 * b0 // n, 92 * min(n, b0 + VOICE_BATCH) // n

            def batch_progress(p, msg, lo=lo, hi=hi, b0=b0, size=len(batch)):
                if progress:
                    k = b0 + int(size * p / 100)
                    progress(lo + (hi - lo) * p // 100, f"Voice {k}/{n} generated")

            try:
                failed += _voice_batch(project, batch, tts_dir, stamp, nxt,
                                       batch_progress, should_stop)
            except (FatalTTSError, TooManyFailures) as e:
                if project.tts_engine != "voxcpm":
                    raise
                # VoxCPM not set up / out of GPU memory: finish with the free
                # Edge voices instead of stopping half-way
                note = (f"⚠ VoxCPM stopped ({str(e)[:120]}) - continuing with "
                        f"Edge Neural voices")
                print(f"[fallback] {note}")
                project.engine_notes.append(note)
                if progress:
                    progress(lo, note)
                project.tts_engine, project.voice = "edge", AUTO_VOICE
                if any(not s.gender for s in project.segments):
                    detect_genders(project)
                failed += _voice_batch(project, batch, tts_dir, stamp, nxt,
                                       batch_progress, should_stop)
            done_ids += [s.id for s in batch if project.voice_current(s)]
            ck.now()
        # 2.7.2: lines that failed (the internet dropped a moment: "Cannot connect
        # to host speech.platform.bing.com ... getaddrinfo failed") are tried once
        # more at the end, after a short wait - not left for the user to find
        left = [s for s in targets if not project.voice_current(s)]
        if left and len(left) < n and not (should_stop and should_stop()):
            if progress:
                progress(92, f"Trying {len(left)} failed voice lines again…")
            for _w in range(3):          # 2.7.2: 10 s was most of this round
                if should_stop and should_stop():
                    raise InterruptedError("Cancelled")
                time.sleep(1.0)
            for b0 in range(0, len(left), VOICE_BATCH):
                if should_stop and should_stop():
                    raise InterruptedError("Cancelled")
                batch = left[b0:b0 + VOICE_BATCH]
                try:
                    _voice_batch(project, batch, tts_dir, stamp, nxt, None, should_stop)
                except (FatalTTSError, TooManyFailures) as e:   # still no internet
                    print(f"[tts] retry stopped: {str(e)[:120]}")
                    break
                done_ids += [s.id for s in batch if project.voice_current(s)]
                ck.now()
            failed = sum(1 for s in targets if not project.voice_current(s))
    finally:
        # keep what is finished even if we stop / fail part-way
        if progress:
            progress(93, "Syncing voices with the video...")
        if full_rebuild and len(done_ids) == len(targets):
            build_audio_clips(project)
            build_subtitles(project, use_translation=True)
        elif done_ids:
            build_audio_clips(project, only_ids=done_ids)
            _update_subtitle_text(project, done_ids)
        ck.now()

    if failed == n:
        raise RuntimeError("Voice generation failed for every line - check your internet "
                           "connection and that the voice matches the target language.")
    if progress:
        msg = f"{n - failed} voice lines ready"
        if failed:
            msg += f" ({failed} failed - click Voice again to retry them)"
        progress(100, msg)
    return project


def _voice_batch(project, batch, tts_dir, stamp, nxt, progress, should_stop) -> int:
    """Generate one batch of lines. Returns how many failed."""
    # 2.7: the voice reads the words of the reading list its own way (📖 Glossary
    # › Read aloud); the line keeps its written text (tts_text = what is shown)
    from . import reading

    read = reading.for_project(project)
    shown = [s.voice_text() for s in batch]
    items = [(reading.apply(t, read), os.path.join(tts_dir, f"{s.id}_{stamp}.wav"))
             for t, s in zip(shown, batch)]
    voices = [project.voice_for(s) for s in batch]
    if project.tts_engine == "voxcpm":
        # the characters' own voices, cut from the video once; a character
        # whose voice cannot be cut uses the default voice from now on (so its
        # lines do not look out of date forever)
        failed = speakers.ensure_refs(project, voices)
        for v, s in zip(voices, batch):
            if v.startswith("voxcpm-ref:") and not os.path.isfile(v[11:]) \
                    and s.speaker in project.cast and (s.speaker in failed or
                                                       project.cast[s.speaker].get("clone") == "file"):
                project.cast[s.speaker]["clone"] = "library"
        if failed:
            voices = [project.voice_for(s) for s in batch]

    def keep(i, path):
        batch[i].tts_path = path
        batch[i].tts_text = shown[i]
        batch[i].tts_voice = voices[i]

    t0 = time.time()
    paths = synthesize_many(items, project.tts_engine, voices[0], project.target_lang,
                            _scaled(progress, 0, 75), should_stop, on_result=keep,
                            voices=voices)
    paths = list(paths)
    t_voice = time.time() - t0
    # Edge / Azure can speak faster natively, which sounds better than speeding
    # the audio up afterwards. Not when the video is slowed for long lines
    # instead (stretch_video): the voice keeps its natural speed.
    speedup = project.tts_engine in ("edge", "azure") and not project.stretch_video
    fit_info: dict = {}
    _fit_lines(project, batch, items, shown, voices, paths, nxt, keep, should_stop, progress,
               fit_info, speedup=speedup)
    # 2.7.2 (16/11, "very slow"): where a Voice's time goes, in the log
    extra = []
    if fit_info.get("long"):
        extra.append(f"✂ {fit_info.get('long', 0)} too long, {fit_info.get('done', 0)} "
                     f"shortened (Gemini {fit_info.get('ask', 0):.0f}s)")
    if fit_info.get("faster"):
        extra.append(f"{fit_info['faster']} said faster")
    if "revoice" in fit_info:
        extra.append(f"voice again {fit_info['revoice']:.0f}s")
    if project.tts_engine == "edge":
        from .tts import edge_report

        er = edge_report()            # (2.7.2: shared by the videos at once)
        if er:
            extra.append(er)
    _trace(f"[voice] {len(batch)} lines ({project.tts_engine}): voice {t_voice:.0f}s"
           + (" · " + ", ".join(extra) if extra else ""))

    # a line Gemini said shorter but whose new voice was not shorter: still
    # too long with its first voice - said faster (only these, now)
    if speedup:
        redo, rates = [], []
        for k, (seg, path) in enumerate(zip(batch, paths)):
            if not path or k in fit_info.get("sped", ()):
                continue
            slot = voice_slot(seg, nxt[seg.id], project.video_duration or None)
            ratio = wav_duration(path) / slot
            if ratio > 1.05:
                redo.append(k)
                rates.append(min(MAX_EDGE_RATE, int((ratio - 1) * 100) + 5))
        if redo:
            t0 = time.time()
            got = synthesize_many([items[k] for k in redo], project.tts_engine,
                                  voices[redo[0]], project.target_lang,
                                  _scaled(progress, 75, 100), should_stop, rates,
                                  voices=[voices[k] for k in redo])
            for k, p in zip(redo, got):
                if p:
                    keep(k, p)
            _trace(f"[voice] {len(redo)} lines said faster ({project.tts_engine}): "
                   f"{time.time() - t0:.0f}s")
    return sum(1 for s in batch if not project.voice_current(s))


def _trace(text: str) -> None:
    print(text)
    try:
        from . import crashlog

        crashlog.note(text)
    except Exception:
        pass


def _fit_lines(project, batch, items, shown, voices, paths, nxt, keep, should_stop,
               progress, info: Optional[dict] = None, speedup: bool = False) -> int:
    """2.7.2 (core/fit.py): lines whose voice is much longer than their time are
    said shorter by Gemini and voiced again - kept only when the new voice is
    really shorter. Returns how many lines were shortened.
    speedup (Edge / Azure, 19/11): the lines only a little too long are said
    faster in the SAME voicing round as the shorter lines - before, that was a
    third round after this one (EP001: 52 s more for 16 lines)."""
    from . import fit, reading

    info = info if info is not None else {}
    info.setdefault("sped", set())
    lim = project.video_duration or None
    durs = [wav_duration(p) if p else 0.0 for p in paths]
    slots = [voice_slot(s, nxt[s.id], lim) for s in batch]
    new: Dict[int, str] = {}
    long: List[int] = []
    if fit.wanted(project) and not getattr(project, "_fit_off", False):
        # a line shortened once is not shortened again (the user may want it so)
        long = [k for k in fit.too_long(durs, slots, fit.ratio_for(project.tts_engine))
                if batch[k].translation.strip() and not batch[k].long_translation]
    if long:
        info["long"] = len(long)
        if progress:
            progress(76, f"✂ {len(long)} lines too long for their time – saying them shorter…")
        t0 = time.time()
        try:
            new = fit.shorten(project, [(batch[k].text, batch[k].translation, durs[k], slots[k])
                                        for k in long], should_stop) or {}
        except fit.FitUnavailable as e:
            # 2.7.2 (14/11): Gemini hung / no quota - one try per Voice, not one per
            # 40 lines (each cost up to 5 minutes: 415 lines took over an hour)
            project._fit_off = True
            note = "✂ Lines not shortened – Gemini did not answer (the voice is sped up instead)"
            print(f"[fit] {note}: {e}")
            if progress:
                progress(76, note)
            new = {}
        info["ask"] = time.time() - t0
    redo = [long[j] for j in sorted(new)]
    texts = [new[j] for j in sorted(new)]
    read = reading.for_project(project)
    jobs = [(reading.apply(t, read), items[k][1].replace(".wav", "_fit.wav"))
            for k, t in zip(redo, texts)]
    # 2.7.2 (17/11): Edge / Azure say the shorter line at the speed it still
    # needs at once - before, a line still long was voiced a third time faster
    rates: Optional[List[int]] = None
    faster: List[int] = []
    if speedup:
        rates = []
        for k, t in zip(redo, texts):
            guess = durs[k] * len(t) / max(1, len(batch[k].translation)) / max(0.1, slots[k])
            rates.append(min(MAX_EDGE_RATE, int((guess - 1) * 100) + 5) if guess > 1.05 else 0)
        # 2.7.2 (20/11): a shortened line whose new voice is not shorter was
        # said faster in one more round after this one ("4 lines said faster
        # 26 s") - its first text is said faster in THIS round too, in case
        backup: List[int] = []
        for k in redo:
            ratio = durs[k] / slots[k] if slots[k] and slots[k] != float("inf") else 0
            if paths[k] and ratio > 1.05:
                backup.append(k)
                jobs.append((items[k][0], items[k][1].replace(".wav", "_fast.wav")))
                rates.append(min(MAX_EDGE_RATE, int((ratio - 1) * 100) + 5))
        for k in range(len(batch)):
            if k in redo or not paths[k] or not slots[k] or slots[k] == float("inf"):
                continue
            ratio = durs[k] / slots[k]
            if ratio > 1.05:
                faster.append(k)
                jobs.append((items[k][0], items[k][1].replace(".wav", "_fast.wav")))
                rates.append(min(MAX_EDGE_RATE, int((ratio - 1) * 100) + 5))
    else:
        backup = []
    if not jobs:
        return 0
    if progress:
        progress(80, f"✂ Voicing {len(redo)} shorter lines…" if redo and not faster else
                 f"Voicing {len(jobs)} lines again (shorter / faster)…")
    t0 = time.time()
    order = redo + backup + faster
    got = synthesize_many(jobs, project.tts_engine, voices[order[0]],
                          project.target_lang, None, should_stop, rates,
                          voices=[voices[k] for k in order])
    info["revoice"] = time.time() - t0
    done = 0
    for j, (k, t) in enumerate(zip(redo, texts)):
        p = got[j]
        if p and wav_duration(p) < durs[k] * 0.97:
            seg = batch[k]
            seg.long_translation = seg.translation
            seg.translation = t
            shown[k] = t
            items[k] = (jobs[j][0], p)
            paths[k] = p
            keep(k, p)
            done += 1
            if speedup:
                info["sped"].add(k)
    for j, k in enumerate(backup, start=len(redo)):
        p = got[j]
        if p and k not in info["sped"]:     # the shorter text did not help
            paths[k] = p
            keep(k, p)
            info["sped"].add(k)
    for j, k in enumerate(faster, start=len(redo) + len(backup)):
        p = got[j]
        if p:
            paths[k] = p
            keep(k, p)
            info["sped"].add(k)
    info["done"] = done
    info["faster"] = sum(1 for k in faster if k in info["sped"])
    if done:
        note = f"✂ {done} lines said shorter to fit their time"
        print(f"[fit] {note}")
        if progress:
            progress(78, note)
    return done


def _place_missing_clips(project: Project):
    """Lines that have a current voice but no clip on the timeline (e.g. an
    interrupted run) get their clip."""
    have = {c.seg_id for c in project.audio_clips if c.seg_id}
    missing = [s.id for s in project.segments if project.voice_current(s) and s.id not in have]
    if missing:
        build_audio_clips(project, only_ids=missing)
        _update_subtitle_text(project, missing)


def _update_subtitle_text(project: Project, ids: List[str]):
    by_id = {s.id: s for s in project.segments}
    wanted = set(ids)
    have_sub = set()
    for sub in project.subtitle_clips:
        if sub.seg_id in wanted:
            seg = by_id.get(sub.seg_id)
            if seg is not None:
                sub.text = seg.translation or seg.text
                have_sub.add(sub.seg_id)
    if wanted - have_sub and project.segments:
        # some lines have no subtitle yet (first voice run after a resume)
        build_subtitles(project, use_translation=True)


# --------------------------------------------------------------------------- #
# Everything
# --------------------------------------------------------------------------- #
NOISE_MAX_LETTERS = 4
NOISE_CHARS = set("嗯啊呃哦噢哎唉嘿哼呀喔欸诶哇")
# 2.7.2 (19/11, Qwen3-ASR EP001 "ស៊ីស៊ីស៊ីស៊ីស៊ី"): hisses, laughs, sighs heard
# as a line - only these sounds, nothing said
SOUND_CHARS = NOISE_CHARS | set("嘶咝嘻哈呵嘘呼啧噗呜唔咦嗷嚯嘘吁咳")


def is_sound_only(text: str) -> bool:
    core = "".join(c for c in (text or "") if c.isalnum())
    return len(core) >= 2 and all(c in SOUND_CHARS for c in core)


def is_noise_line(seg) -> bool:
    """Smart Review "⚠" line that is almost surely noise heard as speech: no
    subtitle on the video shows it AND it is a grunt (嗯 / 啊 ...) or 1-4
    letters Whisper was not sure of either. Short real words ("对", "八十万",
    "爷爷!", "什么" - heard clearly) are kept: they were real lines."""
    if is_sound_only(seg.text):
        return True
    why = getattr(seg, "check", "")
    if why not in ("nosub", "nosub_unsure"):
        return False
    if any(c in NOISE_CHARS for c in seg.text):
        return True
    core = "".join(c for c in seg.text if c.isalnum())
    return why == "nosub_unsure" and len(core) <= NOISE_MAX_LETTERS


def drop_noise_lines(project: Project) -> int:
    """Auto Dub / Batch: take the noise lines out (no voice, no subtitle) and
    keep them in project.noise_lines. Lines with a voice already are kept."""
    out = [s for s in project.segments if is_noise_line(s) and not s.tts_path]
    if not out:
        return 0
    take_out_lines(project, out)
    print(f"[review] {len(out)} noise lines not voiced: "
          + " · ".join(s.text for s in out[:8]))
    return len(out)


def take_out_lines(project: Project, lines) -> None:
    """Lines heard from noise: out of the dub (no voice, no subtitle), kept in
    project.noise_lines so nothing heard is lost."""
    gone = {s.id for s in lines}
    project.segments = [s for s in project.segments if s.id not in gone]
    project.subtitle_clips = [c for c in project.subtitle_clips
                              if not getattr(c, "seg_id", "") or c.seg_id not in gone]
    project.audio_clips = [c for c in project.audio_clips
                           if not getattr(c, "seg_id", "") or c.seg_id not in gone]
    project.noise_lines += [{"start": s.start, "end": s.end, "text": s.text} for s in lines]


def auto_review(project: Project, progress: Optional[Progress] = None,
                should_stop: Optional[Stop] = None) -> str:
    """2.7: after every Transcribe (Auto Dub, Batch AND the 1 · Transcribe
    button): Gemini listens to the Smart Review lines - right ones lose their
    flag, small misspellings are fixed, noise is taken out; what it heard
    differently is kept as the line's ai_heard (one click: "Use the AI's
    words"). Returns a one-line summary ('' when nothing was flagged)."""
    from . import gemini, verify

    flagged = sum(1 for s in project.segments if getattr(s, "check", "") in verify.FLAGS)
    if not flagged:
        project.ai_review = {}
        drop_noise_lines(project)          # 2.7.2: sound-only lines ("嘶嘶嘶")
        return ""
    stats = verify.verify_flagged(project, progress, should_stop)
    noise = drop_noise_lines(project)
    left = sum(1 for s in project.segments if getattr(s, "check", "") in verify.FLAGS)
    project.ai_review = {"flagged": flagged, "checked": stats.get("checked", 0),
                         "right": stats.get("right", 0),
                         "fixed": stats.get("fixed", 0) + stats.get("replaced", 0),
                         "noise": stats.get("noise", 0) + noise, "left": left,
                         "suggest": sum(1 for s in project.segments
                                        if getattr(s, "check", "") and
                                        getattr(s, "ai_heard", ""))}
    if not stats.get("checked"):
        return ("" if gemini.configured() else
                f"{flagged} lines to check – a Gemini key lets the AI check them for you")
    r = project.ai_review
    return (f"🤖 AI checked {r['checked']} lines: {r['right']} right · {r['fixed']} fixed · "
            f"{r['noise']} noise taken out · {left} left")


def auto_dub(project: Project, progress: Optional[Progress] = None,
             should_stop: Optional[Stop] = None, restart: bool = False) -> Project:
    """Full pipeline: transcribe -> translate -> voice -> sync -> subtitles.
    Without restart it continues an interrupted run (finished parts are skipped)."""
    if restart:
        reset_ai_work(project)
    step_transcribe(project, _scaled(progress, 0, 38), should_stop)
    # nobody is there to look at the unsure lines (Batch): Gemini listens to
    # them, then what is still a grunt / unsure scrap is taken out
    with steptimes.timed(project, "AI check"):
        auto_review(project, _scaled(progress, 38, 40), should_stop)
    with steptimes.timed(project, "translate"):
        step_translate(project, _scaled(progress, 40, 55), should_stop)
    with steptimes.timed(project, "voice"):
        step_voice(project, None, _scaled(progress, 55, 100), should_stop)
    steptimes.report(project)                # (a Batch adds the export to this line)
    if progress:
        progress(100, f"Auto Dub finished: {len(project.segments)} lines dubbed")
    return project
