"""
router_hub.py - 2.7.2 (20/11): the Gemini Router as one live page.

    header   Gemini Router · status · Parts at once · Auto fallback · Test · + Add key
    stats    N keys · N ready · N translating · N lines today
    graph    the keys (and the Admin's Gemini web accounts) around the router;
             a line lights up from the key that is translating
    videos   the translations running now, with their progress
    footer   Activity log (opens under the page)

Only masked keys (••••wxyz) and masked account names are ever shown.
"""

import math
import time
from typing import List, Optional

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import (QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath,
                           QPen, QRadialGradient)
from PySide6.QtWidgets import (QAbstractButton, QFrame, QHBoxLayout, QLabel, QListWidget,
                               QPushButton, QSizePolicy, QSpinBox, QVBoxLayout, QWidget)

from core import gemini, gemini_stats, settings
from core.i18n import tr

BG = "#13111d"
CARD = "#1c1929"
CARD_LINE = "#2c2740"
ACCENT = "#8b5cf6"
ACCENT2 = "#4cc9f0"
TEXT = "#ece9f5"
MUTED = "#8d88a3"
GREEN = "#3ddc97"
AMBER = "#f4b740"
RED = "#ff6b6b"

STATE_COLOR = {gemini.READY: GREEN, gemini.BUSY: ACCENT2, gemini.RESTING: AMBER,
               gemini.SPENT: AMBER, gemini.REFUSED: RED,
               "ready": GREEN, "working": ACCENT2, "resting": AMBER}
PER_SIDE = 4                # cards on each side; more: a "+N more" card
HOLD_S = 6.0                # a line stays lit this long after an answer (short calls:
                            # proofread, characters, AI check last 1-3 s)


def short_model(m: str) -> str:
    return (m or "").replace("gemini-", "")


def _clock(t: float) -> str:
    return time.strftime("%H:%M", time.localtime(t)) if t else ""


def _secs(t: float) -> str:
    s = max(0, int(t - time.time()))
    return f"{s // 60}m {s % 60:02d}s" if s >= 60 else f"{s}s"


def nodes() -> List[dict]:
    """Every source the router can use, as cards: the API keys, then the
    Admin's Gemini web accounts. Busy first, then ready, then the rest."""
    models = gemini.view_models()
    rows = gemini.status(models)
    jobs = gemini.jobs()
    by_key = {j.get("key"): j for j in jobs if j.get("key")}
    # 20/11: every request (characters, AI check, proofread ... not only the
    # translation) - as the Gateway counts them; a source that answered a
    # moment ago stays lit
    now = time.time()
    working = gemini_stats.busy_sources()
    just = {}
    for e in gemini_stats.feed(60):
        if e.get("t1") and now - e["t1"] < HOLD_S and e["src"] not in just:
            just[e["src"]] = e["kind"]
    out = []
    for i, r in enumerate(rows):
        st = r["state"]
        job = by_key.get(r["mask"])
        if r["mask"] in working:
            line = tr("Working") + " · " + tr(working[r["mask"]])
        elif st == gemini.READY:
            line = tr("Ready") + " · " + tr("free for the next part")
        elif st == gemini.BUSY:
            line = tr("Translating") + (f" · {job['title'][:22]}" if job else "")
        elif st == gemini.RESTING:
            line = tr("Resting") + f" · {_secs(r['until'])}"
        elif st == gemini.SPENT:
            line = tr("Used up today") + (f" · {tr('back at')} {_clock(r['until'])}"
                                          if r["until"] else "")
        else:
            line = tr("Refused") + (f" · {r['why'][:28]}" if r.get("why") else "")
        out.append({"title": f"{tr('Key')} {i + 1}  {r['mask'][-8:]}", "state": st,
                    "line": line, "count": r["lines"], "unit": tr("lines today"),
                    "badge": short_model(job["model"]) if job and job.get("model")
                    else "Gemini API",
                    "busy": st == gemini.BUSY or bool(job) or r["mask"] in working
                    or r["mask"] in just or now - r.get("last", 0) < HOLD_S,
                    "dead": st == gemini.REFUSED})
    try:
        from core import gemini_web

        if gemini_web.allowed() and gemini_web.mode() != "off":
            for a in gemini_web.accounts():
                st = a["state"]
                line = {"ready": tr("Ready") + " · " + tr("free for the next part"),
                        "working": tr("Working"),
                        "resting": tr("Resting") + f" · {_secs(a['until'])}"}.get(st, st)
                if a["masked"] in working:
                    line = tr("Working") + " · " + tr(working[a["masked"]])
                out.append({"title": a["masked"] or tr("Web account"), "state": st,
                            "line": line, "count": a.get("used", 0), "unit": tr("answers"),
                            "badge": "Gemini web",
                            "busy": st == "working" or a["masked"] in working
                            or a["masked"] in just or now - a.get("last", 0) < HOLD_S,
                            "dead": False})
    except Exception:
        pass
    rank = {gemini.READY: 1, "ready": 1, gemini.RESTING: 2, "resting": 2, gemini.SPENT: 3,
            gemini.REFUSED: 4}
    return sorted(out, key=lambda n: 0 if n["busy"] else rank.get(n["state"], 2))


class Switch(QAbstractButton):
    """A small on / off switch."""

    def __init__(self, on: bool = False, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(on)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def sizeHint(self):
        return QSize(38, 20)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(1, 1, self.width() - 2, self.height() - 2)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(ACCENT if self.isChecked() else "#3a3550"))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        d = r.height() - 6
        x = r.right() - d - 3 if self.isChecked() else r.left() + 3
        p.setBrush(QColor("#ffffff"))
        p.drawEllipse(QRectF(x, r.top() + 3, d, d))
        p.end()


class HubView(QWidget):
    """Painted: the sources around the router, lines that light up."""
    more_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(420)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.items: List[dict] = []
        self.running = 0
        self.fallback = True
        self.phase = 0.0
        self._more_rect: Optional[QRectF] = None
        self.setMouseTracking(True)

    def set_data(self, items, running, fallback):
        self.items, self.running, self.fallback = items, running, fallback
        self.update()

    def tick(self):
        self.phase = (self.phase + 1.2) % 360
        if self.isVisible():
            self.update()

    def mousePressEvent(self, e):
        if self._more_rect is not None and self._more_rect.contains(e.position()):
            self.more_clicked.emit()

    def mouseMoveEvent(self, e):
        on = self._more_rect is not None and self._more_rect.contains(e.position())
        self.setCursor(Qt.CursorShape.PointingHandCursor if on else Qt.CursorShape.ArrowCursor)

    # ------------------------------------------------------------------ paint
    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = float(self.width()), float(self.height())
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(BG))
        p.drawRoundedRect(QRectF(0, 0, W, H), 12, 12)
        center = QPointF(W / 2, H / 2 - 14)
        R = max(46.0, min(66.0, H * 0.14))
        shown = self.items[:PER_SIDE * 2]
        more = len(self.items) - len(shown)
        if more > 0:                     # the last place on the right: "+N more"
            shown = self.items[:PER_SIDE * 2 - 1]
        left = shown[:-(-len(shown) // 2)] if shown else []
        right = shown[len(left):]
        cw, ch = min(250.0, W * 0.2), 64.0
        slots = PER_SIDE
        step = (H - 40) / slots
        cards = []
        for side, group in ((0, left), (1, right)):
            n_here = len(group) + (1 if side == 1 and more > 0 else 0)
            for k in range(n_here):
                y = 20 + step * (k + (slots - n_here) / 2) + (step - ch) / 2
                # a gentle arc: the middle cards a little closer to the router
                bend = abs((k + 0.5) - n_here / 2) / max(1, n_here / 2)
                inset = 40 + (1 - bend) * W * 0.05
                x = inset if side == 0 else W - inset - cw
                rect = QRectF(x, y, cw, ch)
                item = group[k] if k < len(group) else None
                cards.append((side, rect, item))
        self._more_rect = None
        for side, rect, item in cards:          # lines under the cards
            if item is None:
                continue
            a = QPointF(rect.right() if side == 0 else rect.left(), rect.center().y())
            b = QPointF(center.x() + (-R if side == 0 else R) * 0.92, center.y())
            self._curve(p, a, b, QColor(STATE_COLOR.get(item["state"], MUTED)),
                        item["busy"], item["dead"])
        for side, rect, item in cards:
            if item is None:
                self._more(p, rect, more)
                self._more_rect = rect
            else:
                self._card(p, rect, item)
        self._router(p, center, R)
        if not self.items:
            f = QFont(self.font())
            f.setPointSizeF(10)
            p.setFont(f)
            p.setPen(QColor(MUTED))
            p.drawText(QRectF(0, center.y() + R + 60, W, 40), Qt.AlignmentFlag.AlignCenter,
                       tr("No key yet – click “+ Add key” to make a free one"))
        p.end()

    def _curve(self, p, a, b, col, active, dead):
        path = QPainterPath(a)
        dx = (b.x() - a.x()) * 0.5
        path.cubicTo(QPointF(a.x() + dx, a.y()), QPointF(b.x() - dx, b.y()), b)
        c = QColor(col if active else "#4b4566")
        c.setAlpha(170 if active else 120)
        pen = QPen(c, 2.2 if active else 1.4)
        if dead:
            pen.setStyle(Qt.PenStyle.DotLine)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
        if active:                      # light running along the line
            glow = QPen(QColor(col).lighter(140), 3.2)
            glow.setDashPattern([1.5, 9])
            glow.setDashOffset(-self.phase / 2)
            glow.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(glow)
            p.drawPath(path)

    def _card(self, p, rect, it):
        col = QColor(STATE_COLOR.get(it["state"], MUTED))
        if it["line"].startswith(tr("Working")) or it["line"].startswith(tr("Translating")):
            col = QColor(ACCENT2)
        p.setPen(QPen(QColor(col if it["busy"] else CARD_LINE), 1.3 if it["busy"] else 1))
        p.setBrush(QColor("#221d36" if it["busy"] else CARD))
        p.drawRoundedRect(rect, 10, 10)
        x = rect.left() + 14
        # the spark
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(ACCENT if it["badge"] != "Gemini web" else ACCENT2))
        cy = rect.top() + 17
        star = QPainterPath()
        for k in range(8):
            r = 6.0 if k % 2 == 0 else 2.0
            ang = k * math.pi / 4 - math.pi / 2
            pt = QPointF(x + r * math.cos(ang), cy + r * math.sin(ang))
            star.moveTo(pt) if k == 0 else star.lineTo(pt)
        star.closeSubpath()
        p.drawPath(star)
        f = QFont(self.font())
        f.setBold(True)
        f.setPointSizeF(9)
        p.setFont(f)
        p.setPen(QColor(TEXT))
        w = rect.width() - 52
        p.drawText(QRectF(x + 12, rect.top() + 8, w, 18), Qt.AlignmentFlag.AlignVCenter,
                   p.fontMetrics().elidedText(it["title"], Qt.TextElideMode.ElideRight, int(w)))
        p.setPen(QColor(MUTED))
        p.drawText(QRectF(rect.right() - 30, rect.top() + 6, 20, 16),
                   Qt.AlignmentFlag.AlignCenter, "···")
        f.setBold(False)
        f.setPointSizeF(8.3)
        p.setFont(f)
        word, _, rest = it["line"].partition(" · ")
        fm = p.fontMetrics()
        p.setPen(col)
        p.drawText(QPointF(x - 4, rect.top() + 40), word)
        if rest:
            p.setPen(QColor("#b9b4cc"))
            room = int(rect.width() - 26 - fm.horizontalAdvance(word + " · "))
            p.drawText(QPointF(x - 4 + fm.horizontalAdvance(word), rect.top() + 40),
                       " · " + fm.elidedText(rest, Qt.TextElideMode.ElideRight, room))
        f.setPointSizeF(7.8)
        p.setFont(f)
        p.setPen(QColor(MUTED))
        p.drawText(QPointF(x - 4, rect.top() + 56), f"{it['count']:,} {it['unit']}")
        # the engine badge
        bw = p.fontMetrics().horizontalAdvance(it["badge"]) + 14
        br = QRectF(rect.right() - bw - 10, rect.top() + 44, bw, 16)
        p.setPen(QPen(QColor("#3a3452"), 1))
        p.setBrush(QColor("#17142a"))
        p.drawRoundedRect(br, 4, 4)
        p.setPen(QColor("#cfc9e6"))
        p.drawText(br, Qt.AlignmentFlag.AlignCenter, it["badge"])

    def _more(self, p, rect, n):
        pen = QPen(QColor("#5b4a96"), 1.2)
        pen.setStyle(Qt.PenStyle.DashLine)
        p.setPen(pen)
        p.setBrush(QColor(28, 22, 48, 160))
        p.drawRoundedRect(rect, 10, 10)
        f = QFont(self.font())
        f.setBold(True)
        f.setPointSizeF(9.5)
        p.setFont(f)
        p.setPen(QColor("#b79cff"))
        p.drawText(QRectF(rect.left(), rect.top() + 12, rect.width(), 20),
                   Qt.AlignmentFlag.AlignCenter, f"+{n} {tr('more')}")
        f.setBold(False)
        f.setPointSizeF(8)
        p.setFont(f)
        p.setPen(QColor(MUTED))
        p.drawText(QRectF(rect.left(), rect.top() + 32, rect.width(), 18),
                   Qt.AlignmentFlag.AlignCenter, tr("click to see them all"))

    def _router(self, p, c, R):
        running = self.running > 0
        breathe = 0.5 + 0.5 * math.sin(math.radians(self.phase * (3 if running else 1)))
        # glow
        g = QRadialGradient(c, R * 2.3)
        g.setColorAt(0, QColor(139, 92, 246, int(70 + 50 * breathe) if running else 55))
        g.setColorAt(1, QColor(139, 92, 246, 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(g))
        p.drawEllipse(c, R * 2.3, R * 2.3)
        # outer ring
        ring = QLinearGradient(QPointF(c.x() - R, c.y() - R), QPointF(c.x() + R, c.y() + R))
        ring.setColorAt(0, QColor("#a78bfa"))
        ring.setColorAt(1, QColor(ACCENT2))
        p.setPen(QPen(QBrush(ring), 3))
        p.setBrush(QColor("#1a1530"))
        p.drawEllipse(c, R + 6, R + 6)
        if running:                        # a turning arc while translating
            arc = QPen(QColor("#ffffff"), 3)
            arc.setCapStyle(Qt.PenCapStyle.RoundCap)
            p.setPen(arc)
            p.setBrush(Qt.BrushStyle.NoBrush)
            box = QRectF(c.x() - R - 6, c.y() - R - 6, 2 * R + 12, 2 * R + 12)
            p.drawArc(box, int(-self.phase * 6 * 16), 60 * 16)
        inner = QRadialGradient(QPointF(c.x() - R / 3, c.y() - R / 3), R * 1.5)
        inner.setColorAt(0, QColor("#4b2fa3"))
        inner.setColorAt(1, QColor("#170f33"))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(inner))
        p.drawEllipse(c, R - 2, R - 2)
        # a voice wave + "AI"
        wave = QPainterPath()
        for k in range(41):
            t = k / 40
            x = c.x() - R * 0.62 + t * R * 1.1
            amp = math.sin(t * math.pi) * R * 0.32
            y = c.y() + 6 + amp * math.sin(t * 22 + math.radians(self.phase * 4)) * \
                (0.6 + 0.4 * breathe if running else 0.7)
            wave.moveTo(x, y) if k == 0 else wave.lineTo(x, y)
        wp = QPen(QColor("#e9d5ff"), 2)
        wp.setCapStyle(Qt.PenCapStyle.RoundCap)
        p.setPen(wp)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(wave)
        f = QFont(self.font())
        f.setBold(True)
        f.setPointSizeF(max(11.0, R * 0.3))
        p.setFont(f)
        p.setPen(QColor("#ffffff"))
        p.drawText(QRectF(c.x() + R * 0.05, c.y() - R * 0.62, R * 0.6, R * 0.5),
                   Qt.AlignmentFlag.AlignCenter, "AI")
        f.setPointSizeF(11)
        p.setFont(f)
        p.drawText(QRectF(c.x() - 120, c.y() + R + 14, 240, 22), Qt.AlignmentFlag.AlignCenter,
                   tr("Router"))
        f.setBold(False)
        f.setPointSizeF(8.5)
        p.setFont(f)
        p.setPen(QColor("#b9b4cc"))
        state = (tr("Working") + f" {self.running}") if running else tr("Idle")
        p.drawText(QRectF(c.x() - 160, c.y() + R + 36, 320, 18), Qt.AlignmentFlag.AlignCenter,
                   state + " · " + (tr("fallback on") if self.fallback else tr("fallback off")))


class VideosStrip(QWidget):
    """The translations running now: one card each, with its progress."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(96)
        self.jobs: List[dict] = []

    def set_jobs(self, jobs):
        self.jobs = jobs
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = float(self.width()), float(self.height())
        f = QFont(self.font())
        if not self.jobs:
            f.setPointSizeF(9)
            p.setFont(f)
            p.setPen(QColor(MUTED))
            p.drawText(QRectF(0, 0, W, H), Qt.AlignmentFlag.AlignCenter,
                       tr("The videos show here while the router translates them"))
            p.end()
            return
        n = min(4, len(self.jobs))
        gap = 12.0
        cw = (W - gap * (n - 1)) / n
        for k, j in enumerate(self.jobs[:n]):
            r = QRectF(k * (cw + gap), 8, cw, H - 16)
            p.setPen(QPen(QColor(ACCENT2), 1.2))
            p.setBrush(QColor("#191f33"))
            p.drawRoundedRect(r, 10, 10)
            done, total = j.get("done", 0), max(1, j.get("total", 1))
            f.setBold(True)
            f.setPointSizeF(9.5)
            p.setFont(f)
            p.setPen(QColor(TEXT))
            p.drawText(QRectF(r.left() + 14, r.top() + 10, r.width() - 28, 20),
                       Qt.AlignmentFlag.AlignVCenter,
                       p.fontMetrics().elidedText(j.get("title", ""),
                                                  Qt.TextElideMode.ElideRight,
                                                  int(r.width() - 28)))
            f.setBold(False)
            f.setPointSizeF(8.3)
            p.setFont(f)
            p.setPen(QColor(MUTED))
            took = int(time.time() - j.get("start", time.time()))
            p.drawText(QRectF(r.left() + 14, r.top() + 32, r.width() - 28, 18),
                       Qt.AlignmentFlag.AlignVCenter,
                       f"{done}/{total} {tr('lines')} · "
                       + (short_model(j["model"]) if j.get("model") else "…")
                       + f" · {took // 60}:{took % 60:02d}")
            bar = QRectF(r.left() + 14, r.bottom() - 18, r.width() - 28, 5)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor("#2a2f48"))
            p.drawRoundedRect(bar, 2.5, 2.5)
            g = QLinearGradient(bar.topLeft(), bar.topRight())
            g.setColorAt(0, QColor(ACCENT))
            g.setColorAt(1, QColor(ACCENT2))
            p.setBrush(QBrush(g))
            p.drawRoundedRect(QRectF(bar.left(), bar.top(), bar.width() * min(1.0, done / total),
                                     bar.height()), 2.5, 2.5)
        p.end()


def _pill_color(lb: QLabel, color: str) -> None:
    lb.setStyleSheet(f"QLabel {{ color: {color}; border: 1px solid {color}55; "
                     f"background: {color}18; border-radius: 10px; padding: 2px 10px; "
                     "font-size: 8.5pt; }")


def _pill(text: str, color: str) -> QLabel:
    lb = QLabel(text)
    _pill_color(lb, color)
    return lb


class RouterHub(QWidget):
    """The page. test_keys / add_key / show_keys: set by the dialog."""

    def __init__(self, parent=None, test_keys=None, add_key=None, show_keys=None):
        super().__init__(parent)
        self.setObjectName("RouterHub")
        self.setStyleSheet(f"#RouterHub {{ background: {BG}; }} "
                           f"QLabel {{ color: {TEXT}; }}")
        # ---- header
        logo = QLabel("🔀")
        logo.setFixedSize(34, 34)
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo.setStyleSheet(f"background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 {ACCENT}, "
                           f"stop:1 {ACCENT2}); border-radius: 9px; font-size: 15pt;")
        title = QLabel(tr("Gemini Router"))
        title.setStyleSheet(f"color: {TEXT}; font-size: 14pt; font-weight: 700;")
        self.pill_state = _pill(tr("Idle"), MUTED)
        self.pill_src = _pill("", GREEN)
        self.sp_at_once = QSpinBox()
        self.sp_at_once.setRange(1, gemini.PARALLEL_MAX)
        self.sp_at_once.setValue(max(1, min(gemini.PARALLEL_MAX,
                                            int(settings.get("gemini_parallel",
                                                             gemini.PARALLEL_MAX) or 1))))
        self.sp_at_once.setToolTip(tr("How many parts of a video are translated side by "
                                      "side (each by its own key)"))
        self.sp_at_once.valueChanged.connect(lambda v: settings.set("gemini_parallel", int(v)))
        self.sw_fallback = Switch(gemini.when_out() == "google")
        self.sw_fallback.setToolTip(tr("When every key is used up: Google Translate finishes "
                                       "the lines (off: stop and tell me)"))
        self.sw_fallback.toggled.connect(
            lambda on: settings.set("gemini_when_out", "google" if on else "stop"))
        self.b_test = QPushButton("⟳  " + tr("Test keys"))
        self.b_test.setToolTip(tr("Ask Google with every key (a refused key that works again "
                                  "is put back in the queue)"))
        self.b_add = QPushButton("+  " + tr("Add key"))
        self.b_add.setStyleSheet(f"QPushButton {{ background: {ACCENT}; color: white; "
                                 "border: none; border-radius: 7px; padding: 6px 14px; "
                                 "font-weight: 700; } QPushButton:hover { background: #9d74ff; }")
        if test_keys:
            self.b_test.clicked.connect(test_keys)
        if add_key:
            self.b_add.clicked.connect(add_key)
        head = QHBoxLayout()
        head.setSpacing(10)
        head.addWidget(logo)
        head.addWidget(title)
        head.addWidget(self.pill_state)
        head.addWidget(self.pill_src)
        head.addStretch(1)
        lb_at = QLabel(tr("Parts at once"))
        lb_at.setStyleSheet(f"color: {MUTED};")
        head.addWidget(lb_at)
        head.addWidget(self.sp_at_once)
        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.VLine)
        sep.setStyleSheet(f"color: {CARD_LINE};")
        head.addWidget(sep)
        lb_fb = QLabel(tr("Auto fallback"))
        lb_fb.setStyleSheet(f"color: {MUTED};")
        head.addWidget(lb_fb)
        head.addWidget(self.sw_fallback)
        head.addWidget(self.b_test)
        head.addWidget(self.b_add)
        # ---- stats
        self.lb_stats = QLabel()
        self.lb_stats.setTextFormat(Qt.TextFormat.RichText)
        self.lb_stats.setStyleSheet(f"color: {MUTED}; font-size: 9.5pt;")
        # ---- graph, videos, log
        self.view = HubView(self)
        if show_keys:
            self.view.more_clicked.connect(show_keys)
        self.lb_videos = QLabel()
        self.lb_videos.setTextFormat(Qt.TextFormat.RichText)
        self.lb_videos.setStyleSheet(f"color: {MUTED}; font-size: 9pt;")
        self.videos = VideosStrip(self)
        # 20/11: the Live traffic feed, here (newest first)
        self.feed = QLabel()
        self.feed.setTextFormat(Qt.TextFormat.RichText)
        self.feed.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.feed.setFixedWidth(400)
        self.feed.setMinimumHeight(96)
        self.feed.setStyleSheet(f"QLabel {{ background: {CARD}; border: 1px solid {CARD_LINE}; "
                                "border-radius: 10px; padding: 6px 8px; }")
        self.log = QListWidget()
        self.log.setMaximumHeight(150)
        self.log.setVisible(False)
        self.log.setStyleSheet(f"QListWidget {{ background: #0f0d18; border: 1px solid "
                               f"{CARD_LINE}; border-radius: 8px; color: #c9c4dd; "
                               "font-family: Consolas, monospace; font-size: 9pt; }")
        self.b_log = QPushButton("☰  " + tr("Activity log") + "  ›")
        self.b_log.setCheckable(True)
        self.b_log.toggled.connect(self._toggle_log)
        foot = QHBoxLayout()
        foot.addWidget(self.lb_videos)
        foot.addStretch(1)
        foot.addWidget(self.b_log)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(10)
        lay.addLayout(head)
        lay.addWidget(self.lb_stats)
        lay.addWidget(self.view, 1)
        lay.addLayout(foot)
        bottom = QHBoxLayout()
        bottom.setSpacing(12)
        bottom.addWidget(self.videos, 1)
        bottom.addWidget(self.feed)
        lay.addLayout(bottom)
        lay.addWidget(self.log)
        self._log_sig = None
        self._n = 0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(50)
        self.refresh()

    def _toggle_log(self, on):
        self.log.setVisible(on)
        self.b_log.setText("☰  " + tr("Activity log") + ("  ⌄" if on else "  ›"))
        self._log_sig = None
        self.refresh()

    def _tick(self):
        self.view.tick()
        self._n += 1
        if self._n % 20 == 0 and self.isVisible():        # data every second
            self.refresh()

    def refresh(self):
        items = nodes()
        jobs = gemini.jobs()
        fallback = gemini.when_out() == "google"
        # working = any request now (characters, AI check ... too), not only
        # a translation
        working = len(gemini_stats.running())
        self.view.set_data(items, max(len(jobs), working), fallback)
        self.videos.set_jobs(jobs)
        ready = sum(1 for n in items if n["state"] in (gemini.READY, "ready"))
        busy = sum(1 for n in items if n["busy"])
        lines = sum(n["count"] for n in items if n["unit"] == tr("lines today"))
        keys = sum(1 for n in items if n["badge"] != "Gemini web")
        web = len(items) - keys
        sm = gemini_stats.summary()
        self.feed.setText(self._feed_html())
        self.lb_stats.setText(
            f"<b style='color:{TEXT}'>{keys}</b> {tr('keys')}"
            + (f" · <b style='color:{TEXT}'>{web}</b> {tr('web accounts')}" if web else "")
            + f" &nbsp;&nbsp; <span style='color:{GREEN}'>●</span> <b style='color:{TEXT}'>"
            f"{ready}</b> {tr('ready')} &nbsp;&nbsp; <span style='color:{ACCENT2}'>●</span> "
            f"<b style='color:{TEXT}'>{busy}</b> {tr('working')} &nbsp;&nbsp; "
            f"<b style='color:{TEXT}'>{lines:,}</b> {tr('lines today')} &nbsp;&nbsp; "
            f"<b style='color:{TEXT}'>{sm['requests']}</b> {tr('requests')} · "
            f"<b style='color:{GREEN if sm['delivered'] >= 99 else AMBER}'>"
            f"{sm['delivered']:.0f}%</b> {tr('answered')}"
            + (f" · {tr('median reply')} <b style='color:{TEXT}'>{sm['median']:.1f} s</b>"
               if sm["median"] >= 0.1 else ""))
        if jobs or working:
            self.pill_state.setText(f"● {tr('Translating')} {len(jobs)}" if jobs else
                                    f"● {tr('Working')} {working}")
            _pill_color(self.pill_state, ACCENT2)
        else:
            self.pill_state.setText(f"● {tr('Idle')}")
            _pill_color(self.pill_state, MUTED)
        self.pill_src.setText(f"🔑 {ready}/{len(items)} {tr('ready')}")
        self.lb_videos.setText(f"<b style='color:{TEXT}'>{tr('VIDEOS')}</b> &nbsp; "
                               f"{len(jobs)} {tr('translating now')}")
        if self.sw_fallback.isChecked() != fallback:
            self.sw_fallback.blockSignals(True)
            self.sw_fallback.setChecked(fallback)
            self.sw_fallback.blockSignals(False)
        if self.log.isVisible():
            acts = gemini.activity(80)
            sig = (len(acts), acts[-1][0] if acts else 0)
            if sig != self._log_sig:
                self._log_sig = sig
                self.log.clear()
                for t, text in reversed(acts):
                    self.log.addItem(time.strftime("%H:%M:%S", time.localtime(t)) + "   " + text)
                if not acts:
                    self.log.addItem(tr("Nothing yet – the router writes here what each "
                                        "key does."))

    def _feed_html(self) -> str:
        rows = []
        for e in gemini_stats.feed(5):
            col, word = {"running": (ACCENT2, "Working"), "answered": (GREEN, "Done"),
                         "retried": (AMBER, "Retried"),
                         "lost": (RED, "Lost")}.get(e["status"], (MUTED, e["status"]))
            model = short_model(e.get("model") or "")
            rows.append(
                f"<tr><td style='color:{col}'>●</td>"
                f"<td style='color:{MUTED};font-family:Consolas'>"
                f"{time.strftime('%H:%M:%S', time.localtime(e['t0']))}</td>"
                f"<td style='color:{TEXT};font-family:Consolas'>{e['src'][-8:]}</td>"
                f"<td style='color:{MUTED}'>{tr(e['kind'])}{' · ' + model if model else ''}</td>"
                f"<td align='right' style='color:{col}'>{tr(word)}</td></tr>")
        if not rows:
            return (f"<b style='color:{TEXT}'>{tr('Live feed')}</b><br>"
                    f"<span style='color:{MUTED}'>{tr('Nothing yet – translate a video')}</span>")
        return (f"<b style='color:{TEXT}'>{tr('Live feed')}</b>"
                "<table width='100%' cellspacing='0' cellpadding='2'>" + "".join(rows)
                + "</table>")
