"""
gateway_view.py - 2.7.2: "SARIKA Gateway · Live Traffic" (Po's picture, 16/11).

Every Gemini request the Dubber sends: which source answers it (an API key,
or - Admin only - a Gemini web account), what work it is, how long, and how
much is left. Top: 5 numbers. Middle: the request flow (cards around the
gateway, a light runs along the link while that source answers) and the live
feed. Bottom: requests per minute (30 min) and the work mix of this batch.

Never a key or a cookie: sources are masked ("hea***@***", "••••7t0w").
"""

import math
import time
from typing import List

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer
from PySide6.QtGui import (QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath,
                           QPen)
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton,
                               QScrollArea, QSizePolicy, QVBoxLayout, QWidget)

from core import gemini, gemini_stats, settings

BG = "#0b0f14"
CARD = "#11161d"
LINE = "#232a33"
GOLD = QColor("#d9b45a")
GREEN = QColor("#3fb950")
RED = QColor("#f85149")
ORANGE = QColor("#f0883e")
TEXT = QColor("#e6edf3")
MUTED = QColor("#8b949e")


def tr(t: str) -> str:
    try:
        from core.i18n import tr as _tr

        return _tr(t)
    except Exception:
        return t


def _web():
    try:
        from core import gemini_web

        return gemini_web if gemini_web.allowed() else None
    except Exception:
        return None


def _left(until: float) -> str:
    s = max(0, int(until - time.time()))
    if s >= 86400:
        return f"{s // 86400}d {s % 86400 // 3600}h"
    return f"{s // 3600}h {s % 3600 // 60:02d}m" if s >= 3600 else f"{s // 60}m"


# --------------------------------------------------------------------------- #
# the sources (cards)
# --------------------------------------------------------------------------- #
def sources() -> List[dict]:
    """One card per Admin web account, then per API key."""
    busy = gemini_stats.busy_sources()
    out = []
    web = _web()
    if web is not None:
        for a in web.accounts():
            st = a["state"]
            doing = busy.get(a["masked"])
            out.append({
                "name": a["masked"], "badge": "WEB",
                "dot": GOLD if doing else (RED if st == "resting" else GREEN),
                "state": (f"Working · {doing}" if doing else
                          f"Resting · {_left(a['until'])}" if st == "resting" else "Ready"),
                "warn": st == "resting", "busy": bool(doing),
                "count": f"{a['req5h']} req/5h",
                "bars": [("Web", 0.0 if st == "resting" else 1.0,
                          _left(a["until"]) if st == "resting" else "ready"),
                         ("5 hours", min(1.0, a["req5h"] / 200.0), f"{a['req5h']} answers")]})
    try:
        ms = gemini.router_models(ask_google=False)[:2]
    except Exception:
        ms = [gemini.model()]
    now = time.time()
    infos = {d["mask"]: d for d in gemini.status(ms)}
    for k in gemini.keys():
        mk = settings.mask(k)
        info = infos.get(mk, {})
        doing = busy.get(mk)
        st = info.get("state", "")
        refused = st == gemini.REFUSED
        bars = []
        for m in ms:
            until = max(gemini._spent.get((k, m), 0), 0)
            short = m.replace("gemini-", "").replace("-preview", "")
            if refused:
                bars.append((short, 0.0, "refused"))
            elif until > now:
                bars.append((short, 0.0, f"reset {_left(until)}"))
            else:
                bars.append((short, 1.0, "today"))
        out.append({
            "name": mk, "badge": "KEY",
            "dot": RED if refused else GOLD if doing else
            (ORANGE if st in (gemini.SPENT, gemini.RESTING) else GREEN),
            "state": ("Refused (Google)" if refused else f"Working · {doing}" if doing else
                      "Used up today" if st == gemini.SPENT else
                      "Resting" if st == gemini.RESTING else "Ready"),
            "warn": refused, "busy": bool(doing),
            "count": f"{gemini_stats.source_counts(mk, 5.0)} req/5h",
            "bars": bars})
    return out


# --------------------------------------------------------------------------- #
# small pieces
# --------------------------------------------------------------------------- #
class _Stat(QFrame):
    def __init__(self, title: str):
        super().__init__()
        self.setObjectName("stat")
        self.setStyleSheet("QFrame#stat { background:%s; border:1px solid %s; border-radius:10px; }"
                           " QLabel { border:none; background:transparent; }" % (CARD, LINE))
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(2)
        t = QLabel(tr(title).upper())
        t.setStyleSheet("color:#8b949e; font-size:10px; letter-spacing:1px;")
        self.val = QLabel("–")
        self.val.setStyleSheet("color:#e6edf3; font-size:24px; font-weight:700;")
        self.sub = QLabel("")
        self.sub.setStyleSheet("color:#8b949e; font-size:11px;")
        for w in (t, self.val, self.sub):
            lay.addWidget(w)

    def set(self, val: str, sub: str = "", color: str = "#e6edf3"):
        self.val.setText(val)
        self.val.setStyleSheet(f"color:{color}; font-size:24px; font-weight:700;")
        self.sub.setText(tr(sub))


def _panel(title: str, note: str = "") -> QFrame:
    f = QFrame()
    f.setObjectName("p")
    f.setStyleSheet("QFrame#p { background:%s; border:1px solid %s; border-radius:12px; }"
                    " QLabel { border:none; background:transparent; }" % (CARD, LINE))
    lay = QVBoxLayout(f)
    lay.setContentsMargins(14, 10, 14, 12)
    head = QLabel(f"<b style='color:#e6edf3'>{tr(title)}</b>"
                  + (f"&nbsp;&nbsp;<span style='color:#8b949e;font-size:11px'>{tr(note)}</span>"
                     if note else ""))
    lay.addWidget(head)
    return f


class FlowView(QWidget):
    """Cards on both sides of the gateway; a light runs along a working link."""
    CW, CH, GAP = 300, 86, 12

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cards: List[dict] = []
        self.phase = 0.0
        self.setMinimumHeight(260)

    def set_cards(self, cards: List[dict]):
        self.cards = cards
        rows = max(1, math.ceil(len(cards) / 2))
        self.setMinimumHeight(max(260, rows * (self.CH + self.GAP) + 30))
        self.update()

    def tick(self):
        self.phase = (self.phase + 0.035) % 1.0
        if any(c["busy"] for c in self.cards):
            self.update()

    def _rects(self):
        w = self.width()
        left = [c for i, c in enumerate(self.cards) if i % 2 == 0]
        right = [c for i, c in enumerate(self.cards) if i % 2 == 1]
        out = []
        for side, cs in ((0, left), (1, right)):
            x = 8 if side == 0 else w - self.CW - 8
            total = len(cs) * (self.CH + self.GAP) - self.GAP
            y0 = max(14, (self.height() - total) / 2)
            for n, c in enumerate(cs):
                out.append((c, QRectF(x, y0 + n * (self.CH + self.GAP), self.CW, self.CH), side))
        return out

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        hub = QRectF(w / 2 - 88, h / 2 - 90, 176, 180)
        rects = self._rects()
        # links
        for c, r, side in rects:
            a = QPointF(r.right() if side == 0 else r.left(), r.center().y())
            b = QPointF(hub.left() if side == 0 else hub.right(), hub.center().y())
            path = QPainterPath(a)
            mx = (a.x() + b.x()) / 2
            path.cubicTo(QPointF(mx, a.y()), QPointF(mx, b.y()), b)
            col = QColor(GOLD if c["busy"] else MUTED)
            col.setAlpha(200 if c["busy"] else 70)
            p.setPen(QPen(col, 1.6 if c["busy"] else 1.0,
                          Qt.SolidLine if c["busy"] else Qt.DashLine))
            p.setBrush(Qt.NoBrush)
            p.drawPath(path)
            if c["busy"]:                       # the light running to the gateway
                t = self.phase if side == 0 else 1 - self.phase
                pt = path.pointAtPercent(t)
                glow = QColor(GOLD)
                glow.setAlpha(90)
                p.setPen(Qt.NoPen)
                p.setBrush(glow)
                p.drawEllipse(pt, 7, 7)
                p.setBrush(QColor("#fff3c4"))
                p.drawEllipse(pt, 3, 3)
        # hub
        p.setPen(QPen(QColor(GOLD.red(), GOLD.green(), GOLD.blue(), 120), 1.2))
        p.setBrush(QColor("#151b23"))
        p.drawRoundedRect(hub, 16, 16)
        icon = QRectF(hub.center().x() - 30, hub.top() + 18, 60, 60)
        g = QLinearGradient(icon.topLeft(), icon.bottomRight())
        g.setColorAt(0, QColor("#f3d27a"))
        g.setColorAt(1, QColor("#b8892f"))
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(g))
        p.drawRoundedRect(icon, 14, 14)
        p.setPen(QColor("#1b1408"))
        f = QFont(self.font())
        f.setPointSize(22)
        f.setBold(True)
        p.setFont(f)
        p.drawText(icon, Qt.AlignCenter, "✦")
        f.setPointSize(11)
        p.setFont(f)
        p.setPen(TEXT)
        p.drawText(QRectF(hub.left(), icon.bottom() + 8, hub.width(), 20), Qt.AlignCenter,
                   "SARIKA Gateway")
        f.setPointSize(8)
        f.setBold(False)
        p.setFont(f)
        p.setPen(MUTED)
        run = sum(c["busy"] for c in self.cards)
        p.drawText(QRectF(hub.left(), icon.bottom() + 28, hub.width(), 16), Qt.AlignCenter,
                   tr("1 request per account"))
        p.drawText(QRectF(hub.left(), icon.bottom() + 44, hub.width(), 16), Qt.AlignCenter,
                   tr("{} working").replace("{}", str(run)) if run else tr("queue empty"))
        # cards
        for c, r, _side in rects:
            self._card(p, c, r)
        if not self.cards:
            p.setPen(MUTED)
            p.drawText(QRectF(0, h - 30, w, 20), Qt.AlignCenter,
                       tr("No Gemini key yet – Keys tab › Get a free key"))
        p.end()

    def _card(self, p: QPainter, c: dict, r: QRectF):
        border = GOLD if c["busy"] else (RED if c["warn"] else QColor(LINE))
        bc = QColor(border)
        bc.setAlpha(230 if c["busy"] or c["warn"] else 255)
        p.setPen(QPen(bc, 1.3))
        p.setBrush(QColor("#151b23"))
        p.drawRoundedRect(r, 10, 10)
        f = QFont(self.font())
        f.setPointSize(9)
        f.setBold(True)
        f.setFamily("Consolas")
        p.setFont(f)
        p.setPen(Qt.NoPen)
        p.setBrush(c["dot"])
        p.drawEllipse(QPointF(r.left() + 13, r.top() + 15), 4, 4)
        p.setPen(TEXT)
        p.drawText(QRectF(r.left() + 24, r.top() + 6, 160, 18), Qt.AlignVCenter, c["name"])
        badge = QRectF(r.right() - 48, r.top() + 7, 40, 16)
        p.setPen(QPen(MUTED, 0.8))
        p.setBrush(QColor("#1c232d"))
        p.drawRoundedRect(badge, 4, 4)
        f.setPointSize(7)
        f.setFamily(self.font().family())
        p.setFont(f)
        p.drawText(badge, Qt.AlignCenter, c["badge"])
        f.setPointSize(8)
        p.setFont(f)
        p.setPen(GOLD if c["busy"] else (RED if c["warn"] else GREEN))
        p.drawText(QRectF(r.left() + 12, r.top() + 24, 170, 16), Qt.AlignVCenter,
                   tr(c["state"]) if "·" not in c["state"] else c["state"])
        f.setBold(False)
        p.setFont(f)
        p.setPen(MUTED)
        p.drawText(QRectF(r.right() - 100, r.top() + 24, 92, 16),
                   Qt.AlignRight | Qt.AlignVCenter, c["count"])
        for n, (label, frac, note) in enumerate(c["bars"][:2]):
            y = r.top() + 48 + n * 17
            p.setPen(MUTED)
            p.drawText(QRectF(r.left() + 12, y - 6, 76, 14), Qt.AlignVCenter, label)
            track = QRectF(r.left() + 90, y - 2, r.width() - 200, 5)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#232a33"))
            p.drawRoundedRect(track, 2.5, 2.5)
            if frac > 0:
                fill = QRectF(track.left(), track.top(), track.width() * frac, track.height())
                g = QLinearGradient(fill.topLeft(), fill.topRight())
                g.setColorAt(0, QColor("#b8892f") if n == 0 else QColor("#6e7681"))
                g.setColorAt(1, QColor("#f3d27a") if n == 0 else QColor("#c9d1d9"))
                p.setBrush(QBrush(g))
                p.drawRoundedRect(fill, 2.5, 2.5)
            p.setPen(MUTED)
            p.drawText(QRectF(track.right() + 6, y - 6, 104, 14), Qt.AlignVCenter,
                       f"{int(frac * 100)}% · {note}")


class ChartView(QWidget):
    """Requests per minute, last 30 minutes: answered (gold area), retried, lost."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = [(0, 0, 0)] * 30
        self.setMinimumHeight(150)

    def set_data(self, data):
        self.data = data
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(34, 8, self.width() - 44, self.height() - 30)
        top = max(4, max(sum(d) for d in self.data))
        top = int(math.ceil(top / 4.0) * 4)
        p.setPen(QPen(QColor("#232a33"), 1))
        f = QFont(self.font())
        f.setPointSize(7)
        p.setFont(f)
        for k in range(3):
            y = r.bottom() - r.height() * k / 2
            p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y))
            p.setPen(MUTED)
            p.drawText(QRectF(0, y - 7, 28, 14), Qt.AlignRight | Qt.AlignVCenter,
                       str(int(top * k / 2)))
            p.setPen(QPen(QColor("#232a33"), 1))
        n = len(self.data)

        def pts(i):
            return [QPointF(r.left() + r.width() * k / max(1, n - 1),
                            r.bottom() - r.height() * d[i] / top) for k, d in enumerate(self.data)]
        a = pts(0)
        area = QPainterPath(QPointF(r.left(), r.bottom()))
        for q in a:
            area.lineTo(q)
        area.lineTo(QPointF(r.right(), r.bottom()))
        g = QLinearGradient(r.topLeft(), r.bottomLeft())
        g.setColorAt(0, QColor(217, 180, 90, 110))
        g.setColorAt(1, QColor(217, 180, 90, 10))
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(g))
        p.drawPath(area)
        for i, col in ((0, GOLD), (1, ORANGE), (2, RED)):
            path = QPainterPath(pts(i)[0])
            for q in pts(i)[1:]:
                path.lineTo(q)
            p.setPen(QPen(col, 1.6))
            p.setBrush(Qt.NoBrush)
            p.drawPath(path)
        p.setPen(GOLD)
        p.setBrush(GOLD)
        p.drawEllipse(a[-1], 3.5, 3.5)
        p.setPen(MUTED)
        p.drawText(QRectF(r.left(), r.bottom() + 6, 80, 14), Qt.AlignLeft, "-30 min")
        p.drawText(QRectF(r.right() - 60, r.bottom() + 6, 60, 14), Qt.AlignRight, tr("now"))
        p.end()


class MixView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.mix = []
        self.setMinimumHeight(130)

    def set_mix(self, mix):
        self.mix = mix
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        top = max([n for _k, n in self.mix] + [1])
        f = QFont(self.font())
        f.setPointSize(9)
        p.setFont(f)
        for i, (k, n) in enumerate(self.mix[:6]):
            y = 6 + i * 22
            p.setPen(TEXT)
            p.drawText(QRectF(0, y, 120, 18), Qt.AlignVCenter, tr(k))
            track = QRectF(126, y + 7, max(40, self.width() - 170), 5)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor("#232a33"))
            p.drawRoundedRect(track, 2.5, 2.5)
            if n:
                fill = QRectF(track.left(), track.top(), track.width() * n / top, 5)
                g = QLinearGradient(fill.topLeft(), fill.topRight())
                g.setColorAt(0, QColor("#b8892f"))
                g.setColorAt(1, QColor("#f3d27a"))
                p.setBrush(QBrush(g))
                p.drawRoundedRect(fill, 2.5, 2.5)
            p.setPen(TEXT)
            p.drawText(QRectF(self.width() - 36, y, 34, 18), Qt.AlignRight | Qt.AlignVCenter,
                       str(n))
        p.end()


# --------------------------------------------------------------------------- #
# the page
# --------------------------------------------------------------------------- #
class GatewayView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(
            "QWidget#gw { background:%s; } QLabel { color:#e6edf3; }"
            " QPushButton { background:#151b23; color:#e6edf3; border:1px solid #30363d;"
            " border-radius:6px; padding:4px 14px; } QPushButton:checked { color:#d9b45a; }"
            " QScrollBar:vertical { background:transparent; width:8px; margin:0; }"
            " QScrollBar::handle:vertical { background:#30363d; border-radius:4px; min-height:30px; }"
            " QScrollBar::add-line, QScrollBar::sub-line { height:0; }"
            " QScrollBar:horizontal { height:0; }" % BG)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setObjectName("gw")
        self.paused = False
        # header
        icon = QLabel("✦")
        icon.setFixedSize(46, 46)
        icon.setAlignment(Qt.AlignCenter)
        icon.setStyleSheet("background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #f3d27a,"
                           "stop:1 #b8892f); color:#1b1408; font-size:22px; border-radius:10px;")
        title = QLabel("<span style='font-size:18px;font-weight:700;color:#e6edf3'>SARIKA "
                       "Gateway</span> <span style='font-size:18px;color:#d9b45a'>· Live Traffic"
                       "</span>")
        sub = QLabel(tr("Every request the Dubber sends, which account answers it, and how "
                        "much quota is left."))
        sub.setStyleSheet("color:#8b949e; font-size:11px;")
        tcol = QVBoxLayout()
        tcol.setSpacing(0)
        tcol.addWidget(title)
        tcol.addWidget(sub)
        self.lbl_live = QLabel("● Live")
        self.lbl_live.setStyleSheet("color:#3fb950; border:1px solid #2ea043; border-radius:11px;"
                                    " padding:2px 10px;")
        self.lbl_upd = QLabel("")
        self.lbl_upd.setStyleSheet("color:#8b949e; font-family:Consolas;")
        self.btn_pause = QPushButton(tr("Pause"))
        self.btn_pause.setCheckable(True)
        self.btn_pause.toggled.connect(self._pause)
        head = QHBoxLayout()
        head.addWidget(icon)
        head.addSpacing(8)
        head.addLayout(tcol, 1)
        for w in (self.lbl_live, self.lbl_upd, self.btn_pause):
            head.addWidget(w)
        # numbers
        self.s_acc = _Stat("Accounts ready")
        self.s_req = _Stat("Requests · this batch")
        self.s_del = _Stat("Delivered")
        self.s_med = _Stat("Median reply")
        self.s_lpm = _Stat("Lines / minute")
        stats = QHBoxLayout()
        for s in (self.s_acc, self.s_req, self.s_del, self.s_med, self.s_lpm):
            stats.addWidget(s)
        # flow + feed
        flow = _panel("Request flow", "a light runs along the link while that account answers")
        self.flow = FlowView()
        sc = QScrollArea()
        sc.setWidgetResizable(True)
        sc.setFrameShape(QFrame.NoFrame)
        sc.setStyleSheet("QScrollArea { background:transparent; } QScrollArea > QWidget > QWidget"
                         " { background:transparent; }")
        sc.setWidget(self.flow)
        flow.layout().addWidget(sc, 1)
        feed = _panel("Live feed", "all accounts")
        self.feed = QLabel()
        self.feed.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.feed.setTextFormat(Qt.RichText)
        fs = QScrollArea()
        fs.setWidgetResizable(True)
        fs.setFrameShape(QFrame.NoFrame)
        fs.setWidget(self.feed)
        fs.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget { background:transparent; }")
        feed.layout().addWidget(fs, 1)
        feed.setFixedWidth(300)
        mid = QHBoxLayout()
        mid.addWidget(flow, 1)
        mid.addWidget(feed)
        # chart + mix
        ch = _panel("Requests per minute", "last 30 min")
        legend = QLabel("<span style='color:#d9b45a'>● Answered</span>&nbsp;&nbsp;"
                        "<span style='color:#f0883e'>● Retried (429 / slow)</span>&nbsp;&nbsp;"
                        "<span style='color:#f85149'>● Lost</span>")
        legend.setStyleSheet("font-size:10px;")
        ch.layout().addWidget(legend)
        self.chart = ChartView()
        ch.layout().addWidget(self.chart, 1)
        mx = _panel("Work mix", "this batch")
        self.mix = MixView()
        mx.layout().addWidget(self.mix, 1)
        note = QLabel(tr("Bars: an API key's models today (0% = used up until the daily "
                         "reset); a web account: ready or resting. The counts are the "
                         "Dubber's real requests."))
        note.setWordWrap(True)
        note.setStyleSheet("color:#8b949e; font-size:10px;")
        mx.layout().addWidget(note)
        mx.setFixedWidth(300)
        bot = QHBoxLayout()
        bot.addWidget(ch, 1)
        bot.addWidget(mx)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(10)
        lay.addLayout(head)
        lay.addLayout(stats)
        lay.addLayout(mid, 3)
        lay.addLayout(bot, 2)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh)
        self.timer.start(1000)
        self.anim = QTimer(self)
        self.anim.timeout.connect(self.flow.tick)
        self.anim.start(50)
        self.refresh()

    def _pause(self, on: bool):
        self.paused = on
        self.btn_pause.setText(tr("Resume") if on else tr("Pause"))
        self.lbl_live.setText("❚❚ Paused" if on else "● Live")

    def refresh(self):
        if self.paused or not self.isVisible() and self.lbl_upd.text():
            return
        cards = sources()
        self.flow.set_cards(cards)
        ready = sum(1 for c in cards if not c["warn"] and "Used up" not in c["state"])
        bad = sum(1 for c in cards if c["warn"])
        self.s_acc.set(f"{ready} / {len(cards)}",
                       f"{bad} need attention" if bad else "all fine",
                       "#e6edf3")
        s = gemini_stats.summary()
        self.s_req.set(str(s["requests"]), f"{s['running']} in flight · {s['lost']} lost",
                       "#d9b45a")
        self.s_del.set(f"{s['delivered']:.0f}%", "nothing lost" if not s["lost"] else
                       f"{s['lost']} lost", "#3fb950" if s["delivered"] >= 99 else "#f0883e")
        self.s_med.set(f"{s['median']:.1f} s" if s["median"] else "–",
                       "per translate batch")
        self.s_lpm.set(f"{s['lines_min']:.0f}" if s["lines_min"] else "–",
                       "dialogue lines translated", "#d9b45a")
        self.chart.set_data(gemini_stats.per_minute(30))
        self.mix.set_mix(gemini_stats.work_mix())
        self.feed.setText(self._feed_html())
        self.lbl_upd.setText(tr("Updated") + " " + time.strftime("%H:%M:%S"))

    def _feed_html(self) -> str:
        rows = []
        for e in gemini_stats.feed(40):
            st = e["status"]
            col, word = {"running": ("#d9b45a", "Running"), "answered": ("#3fb950", "Done"),
                         "retried": ("#f0883e", "Retried"),
                         "lost": ("#f85149", "Lost")}.get(st, ("#8b949e", st))
            model = (e.get("model") or "").replace("gemini-", "")
            rows.append(
                "<table width='100%' cellspacing='0' cellpadding='3' style='margin-bottom:4px;"
                "background:#151b23;border:1px solid #232a33'><tr>"
                f"<td width='14' style='color:{col}'>●</td>"
                f"<td style='color:#8b949e;font-family:Consolas'>{time.strftime('%H:%M:%S', time.localtime(e['t0']))}</td>"
                f"<td><b style='color:#e6edf3;font-family:Consolas'>{e['src']}</b><br>"
                f"<span style='color:#8b949e;font-size:10px'>{tr(e['kind'])}"
                f"{' · ' + model if model else ''}</span></td>"
                f"<td align='right' style='color:{col}'>{tr(word)}</td></tr></table>")
        return "".join(rows) or f"<span style='color:#8b949e'>{tr('Nothing yet – translate a video')}</span>"
