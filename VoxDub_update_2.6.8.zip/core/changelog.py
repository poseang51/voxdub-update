"""
changelog.py - What changed in each version (newest first).

Version numbers are MAJOR.MINOR.PATCH, always three numbers:
  1.1.0 -> 1.2.0   a new release with new features (the usual step)
  1.2.0 -> 1.2.1   only fixes, nothing new to learn
  1.x.x -> 2.0.0   a very big change (new look, old projects need care)
Every release: put the number in core/__init__.py (__version__) AND add it at
the top of CHANGES here - a test checks the two agree. build_exe.bat names the
installer after it: installer_output\\SARIKA_VOXDUB_PRO_Setup_<version>.exe
"""

CHANGES = [
    ("2.6.8", "2026-11-03", [
        "Batch: one line per episode in the log with the time of every step (separate · STT · OCR · characters · AI check · translate · voice · export).",
        "Burned-in subtitles are read faster, and the place of the subtitles is found once per story instead of for every episode (about 30 s less per episode).",
        "Lines a speech engine invents on music (\"please like and subscribe\", channel names, in simplified or traditional Chinese) are no longer voiced.",
        "Paraformer-zh stays loaded between episodes on graphics cards with 7 GB or more (a 4 GB card keeps its memory free).",
        "Batch: a video that was moved or deleted after it was added says so, instead of \"FFmpeg failed – the video may be damaged\".",
    ]),
    ("2.6.7", "2026-11-01", [
        "Timeline: a video dragged from Media lands on the track you aim at (Video or Video 2), like Filmora.",
        "Batch: the voice starts with its burned-in subtitle – a line no longer starts seconds before it; a subtitle read wrongly for one frame is no longer voiced twice.",
    ]),
    ("2.6.6", "2026-10-30", [
        "AI check: the AI's words replace a line only when it hears them again in the line's own time – a correct line is no longer swapped for the line next to it.",
        "New installer: the subtitle reading (OCR) and the music separation run on the graphics card (DirectX 12) – a Batch is up to 3 × faster.",
    ]),
    ("2.6.5", "2026-10-30", [
        "Home: a cleaner sidebar – line icons, a bar on the page you are on, a smaller licence card.",
        "Media bin: thumbnails keep the video's shape (9:16 is no longer cut to a strip), names on one line.",
        "Edit › 🔇 Detach audio (Ctrl+Alt+D, like Filmora): the video's sound becomes clips on the Music track to move, cut or delete – the same again attaches it back.",
        "Video 2 track (picture in picture): put a second video over the video, move, trim and split it, drag and resize it on the preview – exported with its own sound.",
        "Main video track: drag a piece left or right to put it before or after the others.",
        "Audio › Noise Removal › AI: clear speech in street, room or crowd noise (a voice AI model, offline).",
        "AI check: a line the speech engine misheard, that no subtitle on the video shows, now takes the words the AI heard (年级 → 找死).",
        "Batch \"At once 2\": two episodes separating the music on the GPU at the same moment no longer close the app.",
    ]),
    ("2.6.4", "2026-10-27", [
        "Dub tab: ⚡ AUTO DUB, the 3 steps and the progress stay at the bottom of the left panel – only the settings above scroll.",
        "The right panel (Style, Characters …) and the Tools (Color, Audio, Crop) are no longer cut off on the right – long names end with … and open in full.",
    ]),
    ("2.6.3", "2026-10-27", [
        "Help › ✅ System check: is this PC ready to dub (FFmpeg, NVIDIA GPU, Whisper, disk space, Gemini key, OCR, Isolate BGM, VoxCPM) – shown by itself when something must be fixed.",
        "Help › 📨 Send problem report: one zip on the Desktop (logs, version, this PC – no API key, password or licence) to send to the admin on Telegram.",
        "Help › 🎓 Video tutorials (also in Help › About).",
        "Updates now come over the internet: Help › Check for updates finds every new version by itself.",
    ]),
    ("2.6.2", "2026-10-27", [
        "The app no longer closes by itself while playing a video on NVIDIA cards (the video is decoded with Direct3D 11, smooth and safe).",
        "If the app ever closes by itself, the reason is written to logs\\crash_trace.log for the admin.",
        "🔍 Lines to check (📝 Transcript): the lines worth a look – no subtitle on the video shows them, or Whisper is not sure – one click each, ✓ OK when right.",
        "Batch / Auto Dub: Gemini listens to the unsure lines and confirms them; grunts heard as words get no voice. ✅ Quality check lists what is left – double-click opens the episode.",
        "A subtitle read twice by the OCR is voiced once (no more \"1,400 km 1,400 km\"), and pieces repeating the line next to them are dropped.",
        "Voice style is now \"Original VoxDub\" by default: the video is never slowed (it looked like slow motion); when it is chosen, at most to 0.75 ×.",
        "New speech engines to try: Paraformer-zh and SenseVoice-Small (fast, with the VoxCPM engine) – Whisper stays the best for dubbing.",
        "Batch: two episodes reading the subtitles on the GPU at once no longer close the app.",
    ]),
    ("2.6.1", "2026-10-25", [
        "🟩 Green screen clips (Style › Green screen): intro, outro, Like & Subscribe and a "
        "moving logo over the exported video – the green / blue background is cut out; "
        "choose the place, size, when it shows (start, end, every few minutes, all the "
        "time) and its sound. Presets and Batch keep it for every episode.",
        "New bottom bar: Load BGM · Isolate BGM | Import SRT · Export SRT · Export Video. "
        "Import SRT: Khmer subtitles are ready for the AI voice at once; other languages "
        "go to Translate.",
        "Timeline bar: Text, Flip ↔, Flip ↕, Logo, Blur the original subtitles and a Ratio "
        "menu (Original, 9:16, 16:9, 1:1, 4:5, 3:4, 4:3, 21:9) – one click each.",
        "🔊 Even loudness: the exported sound is made as loud as YouTube / TikTok play it "
        "(-15 LUFS), on by default (Export, Batch and AI Recap).",
        "Lines that are only \"yeah\", \"huh\", \"啊\" … get no Khmer voice any more.",
        "VoxCPM: \"One Male + one Female voice\" (every man the Male voice, every woman "
        "the Female voice) and \"Steady voice\" (a line that sounds like another person "
        "is made again); the words typed for a recording keep the voice closer, words "
        "heard wrongly are not used.",
        "Voice Library › Hear it listens in Khmer (Gemini first, then Whisper).",
        "The Voice column shows ♂ Male / ♀ Female (point at it: who speaks and with which "
        "voice) – more room for the Khmer text.",
        "Export asks first when some lines still have their old voice.",
        "AI Recap: Khmer subtitles come out right on every PC.",
        "Help › About: Check for updates, Facebook, Telegram, YouTube and Contact admin.",
        "The desktop / Start menu shortcuts show the SARIKA VOXDUB logo.",
    ]),
    ("2.6.0", "2026-10-22", [
        "🌐 English / ខ្មែរ: the whole app in two languages (English first). Change it with "
        "🌐 on the Home top bar or Tools › 🎨 Appearance & language – at once, no restart.",
        "🎨 Colours and 🌓 Light / Dark / Auto: choose the app colour (SARIKA, purple, blue, "
        "teal, green, orange, pink, red) and Light, Dark or Auto (follows Windows, changes "
        "with it). The video, timeline and waveforms stay dark.",
        "🏠 New look (deep blue / purple): a top bar with 🔍 search (tools and recent "
        "projects), 🔔 notifications, ⚙ settings and your licence; a new sidebar (AI Dubbing, "
        "Edit video, Batch, AI Recap, 🗣 Voice Library, 📂 My Projects); an AI Recap card on "
        "Home – drop the videos of a story on it.",
        "💳 New Plan & Licence page: your licence (Active, expiry date, days left, Machine "
        "ID hidden as ••••-F2C4 – 👁 shows it), the plans as cards (Monthly, Quarterly, "
        "Half-Yearly, Annual – price per month and how much you save), How to Buy or Renew, "
        "payment methods, Contact seller, the features of every licence, the licence "
        "policy, Current Plan Details and Recent Activity.",
        "Get Started / Renew Now copies the buy message with your Machine ID and an Order "
        "ID; the seller makes your key after the payment is checked.",
        "A message 7 days and 3 days before the licence ends (Renew now / Later).",
        "Price per month by whole months: 1 year $119 = $9.92 a month (save 34%).",
        "Admin – Customers & keys: 📋 Paste request (customer, Machine ID, order and length "
        "from their message). Each order is Waiting → Paid – checked (by you) → Key made, "
        "or Rejected / Cancelled; a key is made only for a checked order, and never twice "
        "for the same order. 🧾 Payments & audit: every request and a log of what was done "
        "(prices, approvals, keys) that shows if a line was changed.",
        "A last reminder on the final day of the licence.",
    ]),
    ("2.5.0", "2026-10-21", [
        "🎬 AI Recap (Home › AI Recap, Tools › AI Recap): a long drama - one video or a whole "
        "story of episodes - told again in 5-10 minutes in Khmer. ① Whisper reads what is "
        "said, ② Gemini understands the whole story and writes a Khmer narration in short "
        "beats, each with the moments of the videos that show it, ③ the narration is spoken "
        "(Piseth / Sreymom, or a cloned voice from the Voice Library), ④ the scenes are cut "
        "to the narration, the drama's sound is turned down under the voice, music and "
        "Khmer subtitles -> MP4 (16:9, 9:16 or 1:1). The script and the moments can be "
        "edited between the steps; ⚡ does all of them at once.",
        "🎬 AI Recap page: ① Upload & Analyze (video files, YouTube / a link, a folder of "
        "episodes; duration, resolution, size; ✨ Analyze with AI) · ② AI Story Intelligence "
        "(characters, plot, key scenes, script) · ③ Customize Recap Style (style, narrator "
        "voice, emotion, speed, music, Auto Scene Sync, Khmer subtitle, intro hook, "
        "▶ Preview Recap, ⚙ More) · ④ Generate & Edit (Script, Timeline, Scenes, Subtitles, "
        "🧠 Story, Key Scenes) · ⑤ Export (MP4 + .srt, MP3, WAV; 720p / 1080p / 4K; "
        "watermark logo). On the right: ▣ Preview player, Recap Script / Timestamps / "
        "AI Summary, Recap Quality Score, Recap Library.",
        "From YouTube / a link: uses Node.js (or deno) and yt-dlp-ejs, tries 3 ways, and "
        "the error says plainly why a video cannot be downloaded.",
        "Gemini: a refused API key (deleted / disabled) is skipped and the next key is used.",
        "Recap: 🧠 Story Brain (characters with their Khmer names, timeline - kept in the "
        "Glossary for every episode), 🎣 hook, 🎭 key lines in the actors' own voice, the "
        "mood of each beat sets the narration's pace and pauses, ✔ every beat checked "
        "against what is said in its moments, 👁 the AI can also look at the pictures.",
        "📚 Voice Library for VoxCPM2 voice cloning (Settings › AI engines › Voice clone, "
        "and 👥 Characters): voices as cards with ▶ preview; use one as the man / woman / "
        "child / elder voice or for one character; + Add voice from a short recording. "
        "What is said in a recording is typed in or heard by Whisper (🎧) - a better clone. "
        "On the Admin PC the voices of SARIKA VOICE are in the library too.",
    ]),
    ("2.4.0", "2026-10-20", [
        "⭐ Presets: save all the settings of a dub under one name - languages, voice, "
        "voice style, subtitle style, logo, brand text, blur box, output size / ratio and "
        "the video / audio tools - e.g. “រឿងចិន → ខ្មែរ (F2 Movie)”, “TikTok 9:16”, "
        "“YouTube 1080p 16:9”. The SAME presets are in the Editor and in Batch: one "
        "click puts them on a video or on the whole queue.",
        "Editor: ⭐ Preset at the top of the left panel - choose a preset, 💾 Save as "
        "preset…, 🗑 delete your own.",
        "Batch: the settings are a rail on the right edge, like SARIKA Studio - ⚙ Dub · "
        "⬆ Output · 🛠 Tools · ✨ Auto · 🔔 Finish. Click a page to open it beside the "
        "queue, click it again (or » / ⚙ Settings) to fold it away so the Preview and the "
        "queue get the whole width.",
        "Our subtitles are no longer glued to the box that hides the original subtitles: "
        "🔍 Auto detect only places the box, our subtitles stay where you put them, and "
        "they can always be grabbed and dragged anywhere (also when they sit on the box).",
        "Editor: the hide box (Hide the original subtitles) can be dragged up / down / "
        "sideways in the video preview, and its corner resizes it.",
        "Batch › Tools: a hide box you drag into place is used for EVERY video exactly "
        "there (each video no longer looks for its own and moves it) - your layout of "
        "logo, brand text, subtitles and box stays as you set it.",
        "Batch: a summary bar above the queue always shows what the queue makes, e.g. "
        "“中文 → ខ្មែរ · Piseth/Sreymom · Logo · Blur · 9:16” (orange with ⚠ when Speech "
        "and Dub to are the same language) - click it for ⚙ Settings; ⭐ Preset next to it.",
        "Batch › Start checks the queue first: videos set to dub into ANOTHER language than "
        "the queue (e.g. a story added as Chinese) are listed - “Use ខ្មែរ” fixes them in "
        "one click, or keep them as they are.",
        "Reading the burned-in subtitles (OCR) now runs beside the video decoding "
        "instead of stopping it for every subtitle.",
        "A logo / brand text / extra logo dragged right up to the edge of the picture "
        "stays exactly there (it jumped back a little when the video played and in the "
        "export).",
        "Logo, brand text and extra logos can be dragged right up to the edge of the "
        "picture and stay exactly there - they no longer jump a little when the video "
        "plays or in the export.",
        "Batch: a preset with a hide box uses that box for every video; ▶ Start asks "
        "once when each video would look for its own instead.",
        "Reading burned-in subtitles (OCR) is faster: the graphics card decodes the "
        "video and the reading runs beside the decoding (on the GPU too where "
        "onnxruntime-directml is installed).",
        "Batch › Tools: Style Studio - a toolbar above the preview (T Text, 🖼 Logo, "
        "💬 Subtitle, ▭ Blur box, ✂ Crop, ⟳ Rotate, ◑ Color, 📐 Ratio). Click one: it "
        "appears on the video, drag it to its place, and only its own details are shown.",
    ]),
    ("2.3.1", "2026-10-21", [
        "⬆ Update now (Help › Check for updates): a new version can now be installed "
        "from inside the app - it downloads only the changed program code, checks that "
        "it really comes from SARIKA (signed), installs it and restarts. No new "
        "installer for every change. If an update does not start, the app goes back to "
        "the installed version by itself; Help › Remove update goes back by hand.",
        "Check for updates also takes a file on this PC / the network "
        "(D:\\updates\\version.json); “Change link…” sets another place.",
        "Seller: make_update.bat makes the signed update package + version.json.",
    ]),
    ("2.3.0", "2026-10-19", [
        "GPU & AI monitor: bottom right of the window (and at the top of the Batch "
        "queue) - GPU use, GPU memory (VRAM), temperature, RAM and what is running; "
        "orange / red when almost full.",
        "Not enough GPU memory for the Whisper model: a smaller model is used on the GPU "
        "(or, if you choose so by clicking the monitor, the same model on the CPU) - "
        "instead of failing. The log says what was done.",
        "Batch queue: a Preview on the left (click a row: its picture at once, ▶ plays it; "
        "Original | Dubbed after it is done), the queue in the middle, Dub / Output / "
        "Tools on the right as before. The picture is shown AS EXPORTED with the queue's "
        "tools (logo, brand text, hidden original subtitles, crop, colour, subtitles) and "
        "changes as soon as Tools › OK is clicked. The clicked video is made first (the "
        "small row pictures wait), the next 6 rows are made ahead so they show at once; "
        "“⏳ Making the export look…” while it is being made. ▶ Play (or a click on the "
        "picture) plays the video with its sound.",
        "Whisper: choosing another model (large-v3 → medium) frees the old one from the GPU "
        "first. The monitor shows an almost full GPU memory in orange, not red - large-v3 "
        "takes nearly all of a 4 GB card, and that works.",
        "Batch › Stop: a second click (⏹ Stop now) stops at once - no waiting for the "
        "piece Whisper is working on (slow on the CPU). Start warns when Speech is set to "
        "the same language as Dub to (e.g. Khmer for a Chinese video). If it still runs "
        "so, Whisper listens with Auto detect instead (Khmer for a Chinese drama made "
        "nonsense lines and a voice that did not match the story). Right-click › "
        "↺ Dub again from the start redoes such videos - and ↻ Retry does it too once "
        "Speech was changed (the old transcript is not reused).",
        "Batch: BASE SETTINGS shows Speech → Dub to (e.g. “Speech: Auto detect → Khmer”), "
        "orange with ⚠ when both are the same language.",
        "Quality check – translation: nonsense lines (heard in a wrong language), Chinese "
        "left in the translation, a translation too long for its line or only a word for a "
        "long line, very few lines for the length of the video.",
        "Quality check – sound (Batch, on every exported video): clipping, too loud / too "
        "quiet (LUFS), an episode much louder or quieter than the rest of its story. The "
        "export now never peaks above -1 dB (a limiter only on the peaks – no crackle).",
        "Batch: ✅ Quality check button in the top bar - checks the finished videos (the "
        "selected ones, or all) any time, not only when the queue ends.",
        "Translate: lines Google Translate gave nothing back for (busy for a moment) are "
        "asked again twice - before they stayed silent in the video (EP079: 11 lines). "
        "Quality check: “too long” only for lines without a voice yet (it listed 900 "
        "lines), and a new “video slowed a lot” (e.g. 98 s → 127 s).",
        "Batch queue: a frame of every video on the left of its row; the Dub settings "
        "show only what matters (Dub to, Translate, Voice, Voice style, After dubbing) - "
        "speed, speech recognition and API keys are under ▸ More settings.",
    ]),
    ("2.2.0", "2026-10-19", [
        "👥 Characters: a character can have its own way of speaking (calm, gentle, angry …) "
        "and speed (fast / slow) for all its lines - kept for the next episodes of a "
        "series. A voice pitch chosen here now counts with the plain voice too; the "
        "automatic pitch still does not (Piseth / Sreymom stay as they are).",
        "Export Center: presets (YouTube, Facebook / TikTok, Telegram, 4K master), sizes "
        "2K (1440p) and 4K (2160p), frame rate, audio quality (128 – 320 kbps) and the "
        "file size before you export (e.g. 1080×1350 · 30 fps · about 44 MB). "
        "Batch queue: 2K / 4K too.",
    ]),
    ("2.1.0", "2026-10-19", [
        "Translation: the Translation table shows the Original line next to the "
        "translation (中文 | ខ្មែរ in one row). Gemini now also reads the next lines "
        "(not only the earlier ones), so a line is translated with what comes after it.",
        "Smart sync: a line a little too long starts up to 0.35 s earlier, in the silence "
        "before it - not sped up, and the video is slowed less (or not at all). "
        "Quality check lists a voice that runs into the next line.",
        "Backups: every Save keeps the old project file in a backups folder (newest 5; "
        "the autosave every 10 min). File › Open a backup… brings an older version back.",
        "Export › Remove the original dialogue: the music & effects go 10 dB lower while "
        "the AI voice speaks (preview too) - the voice is clear, and what is left of the "
        "original voices is no longer heard under it.",
    ]),
    ("2.0.0", "2026-10-18", [
        "New look: one calm dark theme everywhere (slate + teal) - top bar, panels, "
        "timeline, preview and Home. Your projects open exactly as before.",
        "Top bar: ⚡ Auto Dub is the one main button; ◀ / ▶ (or Ctrl+\\) hides the left "
        "panel for a bigger preview - remembered next time.",
        "The window fits a 1080p screen with the taskbar: the Export button is never "
        "cut off (the 👥 Characters tab scrolls).",
        "Timeline: each track has its colour stripe (dimmed when hidden / muted), "
        "🔍 zoom buttons. Translation table: the Target text header is readable and a "
        "long line takes at most 3 rows.",
        "Admin – Customers & keys is now Ctrl+Alt+Shift+A (Ctrl+Shift+K = Split a video).",
        "Fix: Speed (e.g. 150 %) kept the video's frame rate also with the newer FFmpeg on "
        "Windows (a 25 fps video came out at 17 fps). Files dragged from Explorer keep "
        "their Windows path (C:\\…).",
    ]),
    ("1.8.0", "2026-10-18", [
        "Stability: if the app closes without warning (crash, power cut, Task Manager), "
        "the next start offers to open the unsaved work again (from the autosave).",
        "Clear error messages: a wrong API key, a used-up quota, no internet, a busy AI "
        "service, a full disk, the GPU out of memory … now say what happened and what to "
        "do (the technical text stays below it).",
        "Batch queue: a video that failed because of the internet, a busy service or a "
        "quota is tried again by itself (after 1 min, then 5 min) – finished work is kept.",
    ]),
    ("1.7.0", "2026-10-18", [
        "🎵 Music track (like Filmora's audio track): import mp3 / m4a / wav in Media and "
        "double-click it (or File › Add music…) – it goes on the new Music row of the "
        "timeline at the playhead. Move, trim, split (S), delete; click it for its volume "
        "and fades in 🔊 Audio. Played in the preview, mixed in the export; it never mutes "
        "the original speech.",
        "Drag music from Media straight onto the timeline (it lands where you drop it). "
        "Delete on the last video clip (or File › Close video) asks once, then empties the "
        "timeline for another video.",
        "Faster: export / Edit a whole folder ~30 % quicker (Temperature / Tint colour in "
        "one fast step, Speed drops the unseen frames first); smoother playback (the "
        "timeline redraws only the playhead); no freeze when starting or adding a song.",
        "Voice as in the first VoxDub: every man is Piseth, every woman is Sreymom – the "
        "same voice every time (no pitch per character, no higher voice for a man taken "
        "for a child, no pitch for happy / sad). Older videos: click 3 · Voice again.",
    ]),
    ("1.6.1", "2026-10-18", [
        "Edit a whole folder › Join all: says “Step 1 of 2 / Step 2 of 2” – the N-minute "
        "parts are made after the last episode; the parts go straight into the Save in "
        "folder and the whole episodes are removed after (or kept, if you tick it).",
    ]),
    ("1.6.0", "2026-10-18", [
        "Edit looks like Filmora: on the left a library – Media (import, thumbnails, "
        "double-click to open), Titles (brand text, subtitle looks), Stickers (logos from "
        "your logo folder), Filters (colour looks with a preview).",
        "On the right the inspector: 🎬 Video (Transform: Scale up to 300 %, Position X / Y, "
        "Rotate, Flip horizontal / vertical · Crop · Fades), 🔊 Audio, ⏩ Speed, 🎨 Color. "
        "The timeline stays as it was.",
    ]),
    ("1.5.1", "2026-10-18", [
        "Edit a whole folder: ✏️ Set up the edit on episode 1 – opens it in Edit; set the "
        "logo, speed, colour …, then 📂 Apply to the folder (top bar) brings the list back. "
        "The window says where each setting is.",
    ]),
    ("1.5.0", "2026-10-17", [
        "📂 Edit a whole folder (Home › Quick tools, Tools menu): set up ONE episode in Edit "
        "(speed, logo, text, size, hidden subtitles …) and every episode of the folder gets "
        "the same edit – no dubbing. Then keep them, cut each into parts, or join the whole "
        "story and cut it into parts of N minutes (ភាគ01, ភាគ02 …).",
        "Video › Speed: the player and the timeline now show the length of the exported "
        "video (e.g. 41:59 at 128% → 32:48).",
    ]),
    ("1.4.0", "2026-10-17", [
        "Export: type the Title of the video yourself (the file name, also saved inside "
        "the MP4) and choose the folder; the folder is remembered.",
        "Export: Cut into parts – a whole film is cut every N minutes after the export "
        "(e.g. រឿងអធិរាជ ភាគ{n} → ភាគ01, ភាគ02 …), in its own “… - parts” folder.",
    ]),
    ("1.3.1", "2026-10-17", [
        "Hide original subtitles › Auto detect now READS the Chinese text (OCR), so it finds "
        "the subtitle line – not faces, jewels or the channel logo – also in reframed "
        "4:5 / 9:16 videos.",
    ]),
    ("1.3.1", "2026-10-17", [
        "Auto detect (hide the original subtitles) finds small subtitles in a reframed "
        "4:5 / 9:16 video with a blurred background – it no longer picks the middle of "
        "the picture.",
    ]),
    ("1.3.0", "2026-10-17", [
        "🔄 Reframe (Home › Quick tools, Tools menu): turn a sideways video 90° / 180°, "
        "mirror it back left ↔ right, or change the shape 16:9 ↔ 9:16 / 1:1 / 4:5.",
        "Reframe: blurred background, black bars or fill; Before / After picture; "
        "a whole folder at once; then Open in Dub or Edit.",
    ]),
    ("1.2.0", "2026-10-14", [
        "New Home: a clearer start page with 3 easy steps, icons and your licence at a glance.",
        "Plan & licence: prices by month / 3 / 6 / 12 months, days left, copy your Machine ID "
        "and a ready message to buy or renew.",
        "Admin: set the prices yourself (💲 Prices) – customers see them on Plan & licence.",
        "Batch: changing Voice style with 100 videos no longer freezes.",
    ]),
    ("1.1.0", "2026-10-14", [
        "Home dashboard with Edit / Dub / Batch workspaces.",
        "© Copyright check, AI man / woman voices, series glossary and quality check.",
        "Merge with part names per story; Help › Check for updates.",
    ]),
    ("1.0.0", "2026-10-04", [
        "First release of SARIKA VOXDUB PRO: Chinese → Khmer dubbing, one voice per "
        "character, Khmer subtitles, Batch, licence keys.",
    ]),
]


def latest():
    return CHANGES[0]


def notes(version: str):
    for v, _date, items in CHANGES:
        if v == version:
            return items
    return []
